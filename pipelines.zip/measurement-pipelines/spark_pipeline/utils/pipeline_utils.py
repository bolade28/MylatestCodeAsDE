import hashlib
import time
import traceback
from typing import Any, List, Tuple, Optional
from datetime import date
from spark_pipeline.common.variables import PipelineRunType
import pendulum
import pyspark.sql
from pyspark.sql import DataFrame, SparkSession, functions as F
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def json_safe(value: Any) -> Any:
    """
    Convert date-like values to ISO-8601 strings so they are safe to pass to json.dumps.

    Args:
        value: The value to convert. May be None, a primitive, or a date-like object.

    Returns:
        None, an ISO-8601 string, or the original primitive value.
    """
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return value


def safe_float_conversion(value):
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def safe_decimal_conversion(value, decimal_places=9):
    if value is None:
        return None

    try:
        float_value = float(value)
        return round(float_value, decimal_places)
    except (TypeError, ValueError):
        return None


def safe_div(num_expr, denom_expr):
    """
    Safely divide two PySpark column expressions, handling nulls and zero denominators.

    Args:
        num_expr: Numerator column expression
        denom_expr: Denominator column expression

    Returns:
        Column expression that returns 0.0 for null or zero denominators
    """
    return F.when(
        denom_expr > 0,
        F.coalesce(num_expr / denom_expr, F.lit(0.0).cast("double"))
    ).otherwise(F.lit(0.0).cast("double"))


def validate_pipeline_run_type(pipeline_run_type: str) -> str:
    """Raises ValueError for unrecognised values; returns the validated pipeline_run_type string."""
    pipeline_run_type_config = PipelineRunType()
    valid = (pipeline_run_type_config.pollen_run_type, pipeline_run_type_config.dtp_run_type)
    if pipeline_run_type not in valid:
        raise ValueError(
            f"Unknown pipeline_run_type '{pipeline_run_type}'. "
            f"Expected '{pipeline_run_type_config.pollen_run_type}' or '{pipeline_run_type_config.dtp_run_type}'."
        )
    return pipeline_run_type


def is_dtp_run(pipeline_run_type: str) -> bool:
    """Validates pipeline_run_type and returns True if it is a DTP run."""
    return validate_pipeline_run_type(pipeline_run_type) == PipelineRunType().dtp_run_type


def get_tz_date(d: date) -> str:
    # The date input has the following format: (YYY-MM-DD)
    tz = pendulum.timezone("Europe/London")
    return pendulum.from_format(d.strftime('%Y-%m-%d'), 'YYYY-MM-DD', tz).to_atom_string()


def get_model_dates(weekly_dates: pyspark.sql.DataFrame) -> Tuple[str, str]:
    # TODO: maybe use below (or dunno maybe don't, i'm not your mother)
    # agg_df = (
    #     weekly_dates
    #     .agg(
    #         F.min("week_start_date").alias("min_dt"),
    #         F.max("week_start_date").alias("max_dt")
    #     )
    #     .select(
    #         "min_dt",
    #         "max_dt"
    #     )
    # )
    # row = agg_df.collect()[0]
    # return row.min_dt, row.max_dt

    # TODO:: revist on optimisation - its not best practice to use sort
    sorted_df = weekly_dates.orderBy("week_start_date")
    dates = sorted_df.select("week_start_date").rdd.map(lambda row: row[0]).collect()
    return dates[0], dates[-1]


# TODO: unit test
def get_start_end_dates(spark: SparkSession, campaign_start_end_dates_parquet_path: str) -> Tuple[date, date]:
    start_end_date_df = (
        spark
        .read
        .parquet(campaign_start_end_dates_parquet_path)
        .select(
            "start_date",
            "end_date",
        )
        .agg(
            F.min("start_date").alias("start_date"),
            F.max("end_date").alias("end_date"),
        )
        .select(
            "start_date",
            "end_date"
        )
    )
    coll = start_end_date_df.collect()
    start_date = coll[0].start_date
    end_date = coll[0].end_date
    print(f"get_start_end_dates() Read start & end dates from parquet: start {start_date} / end {end_date}")
    return start_date, end_date


def collect_distinct_values(df: DataFrame, column_name: str) -> List[str]:
    """
    Return a sorted list of distinct non-null values for a column.

    Returns an empty list when the column does not exist on the DataFrame

    Args:
        df: The Spark DataFrame to inspect.
        column_name: Name of the column whose values should be collected.

    Returns:
        Sorted list of distinct non-null string values, or ``[]`` if the column is absent.
    """
    if column_name not in df.columns:
        return []

    return [
        row[column_name]
        for row in (
            df.select(column_name)
            .filter(F.col(column_name).isNotNull())
            .distinct()
            .orderBy(column_name)
            .collect()
        )
    ]


# custom annotation to figure out how long a function takes
def timed(my_func):
    def time_a_thing(*args, **more_args):
        start_time = time.perf_counter()
        ret = my_func(*args, **more_args)
        end_time = time.perf_counter()
        print(f"--> {my_func.__name__}() took {end_time - start_time} s btw")
        return ret
    return time_a_thing


def get_latest_data(
    data: DataFrame,
    campaigns_df: DataFrame,
    join_condition: List[str],
):
    """
    Scopes a DataFrame to active campaigns and keeps only the latest snapshot.

    Performs an inner join to campaigns_df on the given join_condition to
    restrict data to in-scope bookings, then retains only rows whose load_ts
    equals the maximum load_ts per booking_id, discarding stale partitions.

    Parameters:
        data (DataFrame): The input DataFrame containing campaign data.
        campaigns_df (DataFrame): Active-campaigns DataFrame used as the join
            filter (e.g. all_campaigns_df from
            apply_campaign_duration_identifier_flag).
        join_condition (List[str]): Column name(s) to join on.

    Returns:
        DataFrame: Filtered DataFrame containing only the latest records per
            booking_id that match the given join condition.
    """
    try:
        campaign_related_data = (
            data
            .join(campaigns_df, on=join_condition, how='inner')
        )

        latest_data = (
            campaign_related_data
            .join(
                campaign_related_data.groupBy("booking_id")
                .agg(F.max("load_ts").alias("max_load_ts")),
                ["booking_id"]
            )
            .filter(F.col("load_ts") == F.col("max_load_ts"))
            .drop("max_load_ts")
        )
        return latest_data

    except Exception as e:
        error_msg = f"Exception occurred: {type(e).__name__}: {str(e)}"
        traceback_msg = traceback.format_exc()
        raise ValueError(f"{error_msg}\n\nFull traceback:\n{traceback_msg}")


def load_parquet_dataset(
    spark: SparkSession,
    path: str,
    dataset_name: str,
    slack_notifier: Optional[Any] = None,
    columns: Optional[List[str]] = None,
    fallback_schema=None,
) -> DataFrame:
    """
    Args:
        spark: SparkSession instance.
        path: S3 path to the parquet dataset.
        dataset_name: Human-readable name used in logs and error messages.
        slack_notifier: Notifier instance for sending error alerts.
                        This parameter is optional because some scripts do not use
                        the Slack notifier.
        columns: List of columns to select. If None, all columns are read.
        fallback_schema: If provided, returns an empty DataFrame with this schema on failure
                         instead of raising an exception.

    Returns:
        DataFrame.
    """
    try:
        df = spark.read.parquet(path)
        df = df.toDF(*[c.lower() for c in df.columns])
    except Exception as e:
        if fallback_schema is not None:
            return spark.createDataFrame([], fallback_schema)
        error_msg = f"Failed to load {dataset_name} from {path}: {str(e)}"

        if slack_notifier is not None:
            slack_notifier.send_data_loading_error(error_msg, f"{dataset_name}_loading")
        raise RuntimeError(error_msg) from e

    if columns:
        normalized_columns = [c.lower() for c in columns]
        missing = set(normalized_columns) - set(df.columns)
        if missing:
            raise RuntimeError(f"Columns not found in {dataset_name}: {sorted(missing)}")
        return df.select(*normalized_columns)
    return df


def write_parquet_dataset(
    df: DataFrame,
    path: str,
    slack_notifier: Any,
) -> None:
    """
    Args:
        df: Spark DataFrame to write.
        path: S3 path to write the parquet dataset.
        dataset_name: Name used in logs and error messages.
        slack_notifier: Notifier instance for sending error alerts.
    """
    try:

        spark_s3_overwrite(path, df)
    except Exception as e:
        error_msg = f"Failed to write {path}: {str(e)}"
        if slack_notifier is not None:
            slack_notifier.send_data_loading_error(error_msg, f"{path}_writing")
        raise RuntimeError(error_msg) from e


def schema_without_fields(schema, excluded_fields: set[str]):
    """Return a schema of the same type excluding the given field names."""
    return schema.__class__([field for field in schema.fields if field.name not in excluded_fields])


def make_unique_key(campaign_id, subchannel_name, booking_id):
    """
    Returns an 8-character numeric hash uniquely
    identifying a campaign/subchannel/booking combination.
    """
    raw = f"{campaign_id}|{subchannel_name}|{booking_id}"
    return str(int(hashlib.md5(raw.encode()).hexdigest(), 16))[:8]
