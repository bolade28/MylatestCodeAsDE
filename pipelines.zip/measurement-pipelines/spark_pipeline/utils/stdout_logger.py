import logging
import sys
from datetime import timedelta
import time


MAIN_TASK = "main_task"
SUB_TASK = "subtask"


def get_stdout_logger():
    return StdOutLogger()


def start_timing_logger(task_name: str, task_type: str):
    timer = TimingLogger(task_name=task_name, task_type=task_type)
    timer.start()
    return timer


class StdOutLogger:

    __logger = None

    def __init__(self):
        self.timings = {}

        if StdOutLogger.__logger is None:
            logger = logging.getLogger("StdOutLogger")
            logger.setLevel(logging.DEBUG)

            std_out_handler = logging.StreamHandler(sys.stdout)
            std_out_handler.setLevel(logging.DEBUG)
            std_out_formatter = logging.Formatter(
                fmt="%(levelname)-8s | %(asctime)-16s | %(log_type)-20s || %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            )
            std_out_handler.formatter = std_out_formatter
            logger.addHandler(std_out_handler)

            std_err_handler = logging.StreamHandler(sys.stderr)
            std_err_handler.setLevel(logging.ERROR)
            std_err_handler.formatter = std_out_formatter
            logger.addHandler(std_err_handler)

            StdOutLogger.__logger = logger
            self.__logger = logger
        else:
            self.__logger = StdOutLogger.__logger

    def info(self, message: str, log_type=None):
        """ Logs message at info level to StdOut

        :param message: Message to log
        :param log_type: Optional log_type to print, defaults to GENERAL_INFO
        :return: None
        """
        if log_type is None:
            log_type = "GENERAL_INFO"

        detail = {"log_type": log_type.upper()}
        self.__logger.info(message, extra=detail)

    def debug(self, message: str, log_type=None):
        """ Logs message at debug level to StdOut
        :param message: Message to log
        :param log_type: Optional log_type to print, defaults to GENERAL_INFO
        :return: None
        """
        if log_type is None:
            log_type = "GENERAL_DEBUG"

        detail = {"log_type": log_type.upper()}
        self.__logger.debug(message, extra=detail)

    def warning(self, message: str, log_type=None):
        """ Logs message at warning level to StdOut

        :param message: Message to log
        :param log_type: Optional log_type to print, defaults to WARNING
        :return: None
        """
        if log_type is None:
            log_type = "WARNING"

        detail = {"log_type": log_type.upper()}
        self.__logger.warning(message, extra=detail)

    def error(self, message: str, log_type=None):
        """ Logs message at error level to StdOut, as well as sending an error log to StdError

        :param message: Message to log
        :param log_type: Optional log_type to print, defaults to ERROR
        :return: None
        """
        if log_type is None:
            log_type = "ERROR"

        detail = {"log_type": log_type.upper()}
        self.__logger.log(level=logging.ERROR, msg=message, extra=detail)

    def log_start_event(self, event_name: str, detail: dict = None):
        """
        Stores the start time of the given event, and logs an info level log stating the event has started.

        e.g for event_name = input_event and detail = {"log_type": "SUB_TASK_STARTED"}, logs to StdOut:
         -- INFO     | 2020-11-30 15:33:24 | SUB_TASK_STARTED || Task starting: input_event

        :param event_name: The name of the event being started
        :param detail: A dict containing {"log_type": a string describing the type of log being logged, e.g MAIN_TASK}
        :return: None
        """
        if detail is None:
            detail = {"log_type": "_STARTED"}

        if event_name in self.timings:
            self.__logger.warning(f"{event_name} has already been logged starting.", extra=detail)
        else:
            self.timings[event_name] = time.perf_counter()

        self.__logger.info(f"{event_name} has started.", extra=detail)

    def log_end_event(self, event_name: str, detail: dict = None):
        """Takes the current time, and compares to the start time for the given event, and writes a log detailing time
        to complete the event.

        e.g for event_name = input_event and detail = {"log_type": "SUB_TASK_COMPLETED"}, logs to StdOut:
         -- INFO     | 2020-11-30 15:33:24 | SUB_TASK_COMPLETED || input_event has completed! Time taken: hh:mm:ss

        :param event_name: The name of the event being completed
        :param detail: A dict containing {"log_type": a string describing the type of log being logged, e.g MAIN_TASK}
        :return: None
        """
        if detail is None:
            detail = {"log_type": "_COMPLETED"}

        if event_name not in self.timings:
            self.__logger.warning(f"{event_name} has not been logged as starting", extra=detail)
        else:
            seconds_taken = time.perf_counter() - self.timings[event_name]
            self.__logger.info(
                f"{event_name} has completed! Time taken: {str(timedelta(seconds=int(seconds_taken)))}", extra=detail
            )


class TimingLogger(StdOutLogger):
    """
    A class which can be used to log how long different events or tasks take to complete.

    There are two main usage patterns which are functionally identical:

    1) Create a TimingLogger object, and then use .start() to start the logging, and .stop() once the event is finished
        -- best used in long complex blocks of code

    2) with TimingLogger(x,y): in a block around the code to time
        -- best used to time single isolated function calls

    """

    def __init__(self, task_name: str, task_type: str):
        """ Init a TimingLogger object

        :param task_name: the name of the task to log (snake case)
        :param task_type: what sort of task is being logged (usually one of MAIN_TASK or SUB_TASK)
        """
        super().__init__()
        self.task_name = task_name
        self.task_type = task_type

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.stop()

    def start(self):
        detail = {"log_type": f"{self.task_type.upper()}_STARTED"}
        self.log_start_event(self.task_name, detail=detail)

    def stop(self):
        detail = {"log_type": f"{self.task_type.upper()}_COMPLETED"}
        self.log_end_event(self.task_name, detail=detail)
