import json
from typing import Dict

import boto3


class MetricsPublisher(object):

    def __init__(self, topic_arn: str):
        self.sns = boto3.client("sns", region_name='eu-west-1')
        self.topic_arn = topic_arn

    def publish_event(self, message_subject: str, event):
        event_fields_dict = vars(event)
        self.publish_to_sns(event_fields_dict, message_subject)

    def publish_to_sns(self, event_fields_dict: Dict, message_subject: str):
        self.sns.publish(
            TopicArn=self.topic_arn,
            Subject=message_subject,
            MessageStructure="json",
            Message=json.dumps({
                'default': json.dumps(event_fields_dict)
            })
        )
