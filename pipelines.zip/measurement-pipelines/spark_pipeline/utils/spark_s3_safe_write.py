"""
S3 Custom Overwrite Module for PySpark

This module implements a custom, two-step overwrite strategy for PySpark/S3 to avoid common
issues with Spark's built-in overwrite mode on S3 (specifically, preserving files not
part of the current job, which is common with partitioned data).

The core logic of hard-deleting the entire prefix before writing is a valid and robust pattern,
particularly in environments where S3 eventual consistency is a concern, or when ensuring a
complete cleanup of old data is paramount.
"""

import boto3
from urllib.parse import urlparse
from pyspark.sql import DataFrame

s3 = boto3.client("s3")


def spark_s3_overwrite(s3_uri: str, df: DataFrame, type: str = 'parquet') -> None:
    """
    Safely overwrite data in S3 by:
      1. Validating and parsing the S3 URI
      2. Hard-deleting all existing objects under the S3 prefix
      3. Writing the DataFrame using Spark's overwrite mode - parquet by default, or json if specified

    Args:
        s3_uri (str): S3 target path (e.g., "s3://bucket/path/to/output/")
        df (DataFrame): Spark DataFrame to write
        type (str): File format to write, either 'parquet' (default) or 'json'

    Raises:
        ValueError: If the S3 URI is invalid or points to root of bucket
        botocore.exceptions.ClientError: For AWS permission or API failures
    """
    # ----------------------------------------------------
    # Step 1: Parse S3 URI + safety checks
    # ----------------------------------------------------
    parsed = urlparse(s3_uri)
    if parsed.scheme != "s3":
        raise ValueError(f"Invalid S3 URI: {s3_uri}")

    bucket = parsed.netloc
    prefix = parsed.path.lstrip("/")

    # Prevent deleting entire bucket
    if not prefix or prefix == "/":
        raise ValueError(
            f"DANGER: S3 URI '{s3_uri}' represents the entire bucket '{bucket}'. "
            f"Provide a specific prefix to avoid deleting all bucket contents."
        )

    if not prefix.endswith("/"):
        prefix += "/"

    # ----------------------------------------------------
    # Step 2: Delete all objects under the prefix
    # ----------------------------------------------------
    paginator = s3.get_paginator("list_objects_v2")

    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        contents = page.get("Contents")
        if not contents:
            continue

        objects_to_delete = [{"Key": obj["Key"]} for obj in contents]

        s3.delete_objects(
            Bucket=bucket,
            Delete={"Objects": objects_to_delete}
        )

    # ----------------------------------------------------
    # Step 3: Spark overwrite write
    # ----------------------------------------------------
    if type == 'json':
        (
            df.write
            .mode("overwrite")
            .json(s3_uri)
        )

    else:
        (
            df.write
            .mode("overwrite")
            .parquet(s3_uri)
        )
