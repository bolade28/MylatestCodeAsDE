class PostgreSQLColumn:
    def __init__(self, name: str, type: str, nullable: bool = True):
        self.name = name
        self.type = type
        self.nullable = nullable


def get_schema(columns):
    schema = {}

    for column in columns:
        if column.nullable:
            schema[column.name] = column.type
        else:
            schema[column.name] = f'{column.type} NOT NULL'
    return schema


class PGDataType:
    text = "text"
    boolean = "boolean"
    decimal = "decimal"
    bigint = "bigint"
    timestamp = "timestamp"
    json = "jsonb"
