
from enum import Enum

import spark_pipeline.utils.postgresql_types as PT
from spark_pipeline.utils.postgresql_types import PGDataType


class WriteOperation(Enum):
    # There are two types of write operations:
    # 1. INSERT: This is used for inserting multiple records with same correlation_id
    #    This should only be used in special cases when you want to insert multiple records with the same correlation_id.
    # 2. UPSERT: This is used for inserting new records or updating existing records.
    #    This is the default operation and should be used in all cases.
    #    This means if we rerun our pipeline, the existing metrics will be updated with the new values.
    #    In order to update already published metrics, name and correlation has to be the same.

    INSERT = "insert"
    UPSERT = "upsert"


class CampaignMetricsSchema():
    def __init__(
            self,
            table_name: str = 'campaign_metrics',
            schema: str = 'metrics',
            write_operation: WriteOperation = WriteOperation.UPSERT
    ):
        self.table_schema = PT.get_schema([
            PT.PostgreSQLColumn("correlation_id", PGDataType.text, True),
            PT.PostgreSQLColumn("name", PGDataType.text, True),
            PT.PostgreSQLColumn("value", PGDataType.decimal, True),
            PT.PostgreSQLColumn("int_value", PGDataType.bigint, True),
            PT.PostgreSQLColumn("type", PGDataType.text, True),
            PT.PostgreSQLColumn("create_timestamp", PGDataType.timestamp, True),
            PT.PostgreSQLColumn("load_timestamp", PGDataType.timestamp, True)
        ])
        # Change table name if INSERT operation is selected
        if write_operation == WriteOperation.INSERT:
            self.table_name = f"{table_name}_insert"
        else:
            self.table_name = table_name
        self.schema = schema
        self.write_operation = write_operation.value


class ClusterMetricsSchema():
    def __init__(
            self,
            table_name: str = 'cluster_metrics',
            schema: str = 'metrics',
            write_operation: WriteOperation = WriteOperation.UPSERT
    ):
        self.table_schema = PT.get_schema([
            PT.PostgreSQLColumn("correlation_id", PGDataType.text, True),
            PT.PostgreSQLColumn("cluster_id", PGDataType.text, True),
            PT.PostgreSQLColumn("value", PGDataType.decimal, True),
            PT.PostgreSQLColumn("int_value", PGDataType.bigint, True),
            PT.PostgreSQLColumn("type", PGDataType.text, True),
            PT.PostgreSQLColumn("create_timestamp", PGDataType.timestamp, True),
            PT.PostgreSQLColumn("load_timestamp", PGDataType.timestamp, True)
        ])
        # Change table name if UPSERT operation is selected
        if write_operation == WriteOperation.INSERT:
            self.table_name = f"{table_name}_insert"
        else:
            self.table_name = table_name
        self.schema = schema
        self.write_operation = write_operation.value


class UCMIncrementalitySchema():
    def __init__(
            self,
            table_name: str = 'ucm_incrementality_metrics',
            schema: str = 'metrics',
            write_operation: WriteOperation = WriteOperation.UPSERT
    ):
        self.table_schema = PT.get_schema([
            PT.PostgreSQLColumn("correlation_id", PGDataType.text, True),
            PT.PostgreSQLColumn("name", PGDataType.text, True),
            PT.PostgreSQLColumn("value", PGDataType.decimal, True),
            PT.PostgreSQLColumn("metadata", PGDataType.json, True),
            PT.PostgreSQLColumn("create_timestamp", PGDataType.timestamp, True),
            PT.PostgreSQLColumn("load_timestamp", PGDataType.timestamp, True),
        ])
        if write_operation == WriteOperation.INSERT:
            self.table_name = f"{table_name}_insert"
        else:
            self.table_name = table_name

        self.schema = schema
        self.write_operation = write_operation.value


class CampaignReportingSchema():
    def __init__(
            self,
            table_name: str = 'measurement_campaign_reporting',
            schema: str = 'metrics',
            write_operation: WriteOperation = WriteOperation.INSERT
    ):
        self.table_schema = PT.get_schema([
            PT.PostgreSQLColumn("correlation_id", PGDataType.text, True),
            PT.PostgreSQLColumn("name", PGDataType.text, True),
            PT.PostgreSQLColumn("batch_id", PGDataType.text, True),
            PT.PostgreSQLColumn("campaign_id", PGDataType.text, True),
            PT.PostgreSQLColumn("booking_id", PGDataType.text, True),
            PT.PostgreSQLColumn("campaign_duration", PGDataType.text, True),
            PT.PostgreSQLColumn("journey_type", PGDataType.text, True),
            PT.PostgreSQLColumn("marketing_type", PGDataType.text, True),
            PT.PostgreSQLColumn("channel_name", PGDataType.text, True),
            PT.PostgreSQLColumn("subchannel_name", PGDataType.text, True),
            PT.PostgreSQLColumn("sub_category_name", PGDataType.text, True),
            PT.PostgreSQLColumn("attributed_conversions", PGDataType.decimal, True),
            PT.PostgreSQLColumn("incremental_sales_amt_exposed", PGDataType.decimal, True),
            PT.PostgreSQLColumn("super_category_name", PGDataType.text, True),
            PT.PostgreSQLColumn("campaign_name", PGDataType.text, True),
            PT.PostgreSQLColumn("attributed_recalibrated_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("attributed_recalibrated_units_qty", PGDataType.decimal, True),
            PT.PostgreSQLColumn("incremental_units_qty_exposed", PGDataType.decimal, True),
            PT.PostgreSQLColumn("attributed_units_qty", PGDataType.decimal, True),
            PT.PostgreSQLColumn("attributed_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("conversions_recalibrated", PGDataType.decimal, True),
            PT.PostgreSQLColumn("recalibration_factor", PGDataType.decimal, True),
            PT.PostgreSQLColumn("job_bag_number", PGDataType.text, True),
            PT.PostgreSQLColumn("nectar_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("non_nectar_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("media_spend_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("campaign_type", PGDataType.text, True),
            PT.PostgreSQLColumn("nectar_weights", PGDataType.decimal, True),
            PT.PostgreSQLColumn("non_nectar_weights", PGDataType.decimal, True),
            PT.PostgreSQLColumn("new_nectar_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("new_non_nectar_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("new_nectar_units_qty", PGDataType.decimal, True),
            PT.PostgreSQLColumn("new_non_nectar_units_qty", PGDataType.decimal, True),
            PT.PostgreSQLColumn("new_nectar_weight", PGDataType.decimal, True),
            PT.PostgreSQLColumn("new_nectar_qty_weight", PGDataType.decimal, True),
            PT.PostgreSQLColumn("incremental_nectar_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("new_non_nectar_weights", PGDataType.decimal, True),
            PT.PostgreSQLColumn("incremental_nectar_units_qty", PGDataType.decimal, True),
            PT.PostgreSQLColumn("new_non_nectar_qty_weights", PGDataType.decimal, True),
            PT.PostgreSQLColumn("incremental_non_nectar_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("total_incremental_nectar_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("incremental_non_nectar_units_qty", PGDataType.decimal, True),
            PT.PostgreSQLColumn("total_incremental_nectar_units_qty", PGDataType.decimal, True),
            PT.PostgreSQLColumn("base_sales_amt_nectar_exposed", PGDataType.decimal, True),
            PT.PostgreSQLColumn("roas_exposed", PGDataType.decimal, True),
            PT.PostgreSQLColumn("iroas_exposed", PGDataType.decimal, True),
            PT.PostgreSQLColumn("iroas_exposed_nectar", PGDataType.decimal, True),
            PT.PostgreSQLColumn("base_sales_amt_exposed", PGDataType.decimal, True),
            PT.PostgreSQLColumn("uplift_exposed_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("uplift_exposed_units_qty", PGDataType.decimal, True),
            PT.PostgreSQLColumn("uplift_exposed_nectar_sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("uplift_exposed_nectar_units_qty", PGDataType.decimal, True),
            PT.PostgreSQLColumn("num_user_journeys", PGDataType.decimal, True),
            PT.PostgreSQLColumn("num_conversions", PGDataType.decimal, True),
            PT.PostgreSQLColumn("attributed_recalibrated_sales_amt_per_uj", PGDataType.decimal, True),
            PT.PostgreSQLColumn("attributed_recalibrated_sales_amt_per_conversion", PGDataType.decimal, True),
            PT.PostgreSQLColumn("conversion_per_uj", PGDataType.decimal, True),
            PT.PostgreSQLColumn("conversion_rate", PGDataType.decimal, True),
            PT.PostgreSQLColumn("load_ts", PGDataType.timestamp, True),
            PT.PostgreSQLColumn("create_timestamp", PGDataType.timestamp, True),
            PT.PostgreSQLColumn("load_timestamp", PGDataType.timestamp, True),
        ])
        # Change table name if UPSERT operation is selected
        if write_operation == WriteOperation.INSERT:
            self.table_name = f"{table_name}_insert"
        else:
            self.table_name = table_name
        self.schema = schema
        self.write_operation = write_operation.value


class ReachEngagementDetailsSchema():
    def __init__(
            self,
            table_name: str = 'reach_engagement_details',
            schema: str = 'metrics',
            write_operation: WriteOperation = WriteOperation.UPSERT
    ):
        self.table_schema = PT.get_schema([
            PT.PostgreSQLColumn("correlation_id", PGDataType.text, True),
            PT.PostgreSQLColumn("name", PGDataType.text, True),
            PT.PostgreSQLColumn("batch_id", PGDataType.text, True),
            PT.PostgreSQLColumn("campaign_id", PGDataType.text, True),
            PT.PostgreSQLColumn("booking_id", PGDataType.text, True),
            PT.PostgreSQLColumn("marketing_type", PGDataType.text, True),
            PT.PostgreSQLColumn("channel_name", PGDataType.text, True),
            PT.PostgreSQLColumn("subchannel_name", PGDataType.text, True),
            PT.PostgreSQLColumn("reach_cnt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("dedup_campaign_reach", PGDataType.decimal, True),
            PT.PostgreSQLColumn("clicks_cnt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("impressions_cnt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("sales_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("conversions_cnt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("media_spend_amt", PGDataType.decimal, True),
            PT.PostgreSQLColumn("engagement_ctr_pct", PGDataType.decimal, True),
            PT.PostgreSQLColumn("load_ts", PGDataType.timestamp, True),
            PT.PostgreSQLColumn("dag_run_ts", PGDataType.timestamp, True),
            PT.PostgreSQLColumn("create_timestamp", PGDataType.timestamp, True),
            PT.PostgreSQLColumn("load_timestamp", PGDataType.timestamp, True),
        ])

        if write_operation == WriteOperation.INSERT:
            self.table_name = f"{table_name}_insert"
        else:
            self.table_name = table_name
        self.schema = schema
        self.write_operation = write_operation.value


class BaselineValidationMetricsSchema():
    def __init__(
            self,
            table_name: str = 'baseline_validation_check',
            schema: str = 'metrics',
            write_operation: WriteOperation = WriteOperation.UPSERT
    ):
        self.table_schema = PT.get_schema([
            PT.PostgreSQLColumn("correlation_id", PGDataType.text, True),
            PT.PostgreSQLColumn("name", PGDataType.text, True),
            PT.PostgreSQLColumn("type", PGDataType.text, True),
            PT.PostgreSQLColumn("severity", PGDataType.text, True),
            PT.PostgreSQLColumn("comment", PGDataType.text, True),
            PT.PostgreSQLColumn("value", PGDataType.decimal, True),
            PT.PostgreSQLColumn("metadata", PGDataType.text, True),
            PT.PostgreSQLColumn("channel_name", PGDataType.text, True),
            PT.PostgreSQLColumn("load_timestamp", PGDataType.timestamp, True),
            # TODO:: add a description column to describe the validation metric in more detail
        ])
        if write_operation == WriteOperation.UPSERT:
            self.table_name = f"{table_name}_upsert"
        else:
            self.table_name = table_name
        self.schema = schema
        self.write_operation = write_operation.value


class MTAValidationMetricSchema():
    def __init__(
            self,
            table_name: str = 'mta_validation_check',
            schema: str = 'metrics',
            write_operation: WriteOperation = WriteOperation.UPSERT
    ):
        self.table_schema = PT.get_schema([
            PT.PostgreSQLColumn("correlation_id", PGDataType.text, True),
            PT.PostgreSQLColumn("name", PGDataType.text, True),
            PT.PostgreSQLColumn("type", PGDataType.text, True),
            PT.PostgreSQLColumn("severity", PGDataType.text, True),
            PT.PostgreSQLColumn("comment", PGDataType.text, True),
            PT.PostgreSQLColumn("value", PGDataType.decimal, True),
            PT.PostgreSQLColumn("metadata", PGDataType.text, True),
            PT.PostgreSQLColumn("channel_name", PGDataType.text, True),
            PT.PostgreSQLColumn("load_timestamp", PGDataType.timestamp, True),
        ])
        # Using UPSERT (the codebase default) so reruns update existing rows when (correlation_id, name) matches
        if write_operation == WriteOperation.UPSERT:
            self.table_name = f"{table_name}_upsert"
        else:
            self.table_name = table_name
        self.schema = schema
        self.write_operation = write_operation.value


class PipelineSummaryMetricsSchema():
    def __init__(
            self,
            table_name: str = 'pipeline_summary_metrics',
            schema: str = 'metrics',
            write_operation: WriteOperation = WriteOperation.UPSERT
    ):
        self.table_schema = PT.get_schema([
            PT.PostgreSQLColumn("correlation_id", PGDataType.text, True),
            PT.PostgreSQLColumn("name", PGDataType.text, True),
            PT.PostgreSQLColumn("data_group", PGDataType.text, True),
            PT.PostgreSQLColumn("data_sources", PGDataType.text, True),
            PT.PostgreSQLColumn("severity", PGDataType.text, True),
            PT.PostgreSQLColumn("metadata", PGDataType.text, True),
            PT.PostgreSQLColumn("load_timestamp", PGDataType.timestamp, True),
        ])
        if write_operation == WriteOperation.UPSERT:
            self.table_name = f"{table_name}_upsert"
        else:
            self.table_name = table_name
        self.schema = schema
        self.write_operation = write_operation.value


class QAChecksSchema():
    def __init__(
            self,
            table_name: str = 'qa_validation_check_metrics',
            schema: str = 'metrics',
            write_operation: WriteOperation = WriteOperation.UPSERT
    ):
        self.table_schema = PT.get_schema([
            PT.PostgreSQLColumn("correlation_id", PGDataType.text, True),
            PT.PostgreSQLColumn("type", PGDataType.text, True),
            PT.PostgreSQLColumn("name", PGDataType.text, True),
            PT.PostgreSQLColumn("expected_value", PGDataType.text, True),
            PT.PostgreSQLColumn("outcome", PGDataType.text, True),
            PT.PostgreSQLColumn("details", PGDataType.text, True),
            PT.PostgreSQLColumn("additional_metadata", PGDataType.json, True),
            PT.PostgreSQLColumn("load_timestamp", PGDataType.timestamp, True),
        ])
        if write_operation == WriteOperation.UPSERT:
            self.table_name = f"{table_name}_upsert"
        else:
            self.table_name = table_name
        self.schema = schema
        self.write_operation = write_operation.value
