from dataclasses import dataclass, field
from typing import Dict, Optional

from spark_pipeline.utils.dates_utils import current_timestamp
from spark_pipeline.utils.metrics_schema import (
    CampaignReportingSchema,
    MTAValidationMetricSchema as MTAValidationMetricTableSchema,
    PipelineSummaryMetricsSchema as PipelineSummaryMetricsTableSchema,
    QAChecksSchema as QAChecksTableSchema,
    ReachEngagementDetailsSchema,
)


@dataclass
class CampaignReporting():
    correlation_id: str
    name: str
    batch_id: str
    campaign_id: str
    booking_id: str
    campaign_duration: str
    journey_type: str
    marketing_type: str
    channel_name: str
    subchannel_name: str
    sub_category_name: str
    attributed_conversions: float
    incremental_sales_amt_exposed: float
    super_category_name: str
    campaign_name: str
    attributed_recalibrated_sales_amt: float
    attributed_recalibrated_units_qty: float
    incremental_units_qty_exposed: float
    attributed_units_qty: float
    attributed_sales_amt: float
    conversions_recalibrated: float
    recalibration_factor: float
    job_bag_number: str
    nectar_sales_amt: float
    non_nectar_sales_amt: float
    media_spend_amt: float
    campaign_type: str
    roas_exposed: float
    iroas_exposed: float
    base_sales_amt_exposed: float
    uplift_exposed_sales_amt: float
    uplift_exposed_units_qty: float
    num_conversions: int
    num_user_journeys: float
    attributed_recalibrated_sales_amt_per_uj: float
    attributed_recalibrated_sales_amt_per_conversion: float
    conversion_per_uj: float
    conversion_rate: float
    load_ts: str
    create_timestamp: str = field(default_factory=current_timestamp)
    event_schema: Dict = field(init=False)

    def __post_init__(self):
        self.event_schema = vars(CampaignReportingSchema())


@dataclass
class ReachEngagementDetails():
    correlation_id: str
    name: str
    batch_id: str
    campaign_id: str
    booking_id: str
    marketing_type: str
    channel_name: str
    subchannel_name: str
    reach_cnt: float
    dedup_campaign_reach: float
    clicks_cnt: float
    impressions_cnt: float
    sales_amt: float
    conversions_cnt: float
    media_spend_amt: float
    engagement_ctr_pct: float
    load_ts: str
    dag_run_ts: str
    create_timestamp: str = field(default_factory=current_timestamp)
    event_schema: Dict = field(init=False)

    def __post_init__(self):
        self.event_schema = vars(ReachEngagementDetailsSchema())


@dataclass
class MTAValidationMetricSchema():
    correlation_id: str
    name: str
    type: str
    severity: str
    comment: str
    value: str
    metadata: str
    channel_name: Optional[str] = None
    load_timestamp: str = field(default_factory=current_timestamp)
    event_schema: Dict = field(init=False)

    def __post_init__(self):
        self.event_schema = vars(MTAValidationMetricTableSchema())


@dataclass
class PipelineSummaryMetrics():
    correlation_id: str
    name: str
    data_group: str
    data_sources: str
    severity: str
    metadata: str
    load_timestamp: str = field(default_factory=current_timestamp)
    event_schema: Dict = field(init=False)

    def __post_init__(self):
        self.event_schema = vars(PipelineSummaryMetricsTableSchema())


@dataclass
class QAChecksMetric():
    correlation_id: str
    type: str
    name: str
    expected_value: Optional[str]
    outcome: str
    details: str
    additional_metadata: str
    load_timestamp: str
    event_schema: Dict = field(init=False)

    def __post_init__(self):
        self.event_schema = vars(QAChecksTableSchema())
