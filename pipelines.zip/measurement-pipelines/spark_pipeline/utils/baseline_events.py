from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from spark_pipeline.utils.dates_utils import current_timestamp
from spark_pipeline.utils.metrics_schema import (
    CampaignMetricsSchema,
    ClusterMetricsSchema,
    BaselineValidationMetricsSchema,
    UCMIncrementalitySchema,
)


@dataclass
class CampaignMetrics():
    correlation_id: str
    name: str
    value: float = None
    int_value: int = None
    type: str = None
    create_timestamp: str = field(default_factory=current_timestamp)
    event_schema: Dict = field(init=False)

    def __post_init__(self):
        self.event_schema = vars(CampaignMetricsSchema())


@dataclass
class ClusterMetrics():
    correlation_id: str
    cluster_id: str
    value: float
    type: str
    create_timestamp: str = field(default_factory=current_timestamp)
    event_schema: Dict = field(init=False)

    def __post_init__(self):
        self.event_schema = vars(ClusterMetricsSchema())


@dataclass
class UCMIncrementalityMetrics():
    correlation_id: str
    name: str
    value: Optional[float] = None
    metadata: Optional[Dict[str, Any]] = None  # json format
    create_timestamp: str = field(default_factory=current_timestamp)
    event_schema: Dict = field(init=False)

    def __post_init__(self):
        self.event_schema = vars(UCMIncrementalitySchema())


@dataclass
class BaselineValidationMetrics():
    correlation_id: str
    name: str
    type: str
    severity: str
    comment: str
    value: str
    metadata: str
    channel_name: str = None
    load_timestamp: str = field(default_factory=current_timestamp)
    event_schema: Dict = field(init=False)

    def __post_init__(self):
        self.event_schema = vars(BaselineValidationMetricsSchema())
