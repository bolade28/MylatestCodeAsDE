from datetime import datetime, timezone


def current_timestamp() -> str:
    """
    Returns current timestamp in UTC format
    """
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'


def metrics_timestamp(date: str) -> str:
    """
    Returns timestamp with fixed time 12:00 for the supplied date
    :param date: date with no time details.
    """
    return str(datetime.strptime(date, '%Y-%m-%d').replace(hour=12, minute=00, second=00).isoformat()) + '.000Z'
