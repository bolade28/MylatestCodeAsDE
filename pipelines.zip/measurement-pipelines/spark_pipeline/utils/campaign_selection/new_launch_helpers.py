from pyspark.sql import DataFrame, Window
from typing import Tuple, List, Optional
from pyspark.sql import functions as F, SparkSession
from datetime import datetime, timedelta

from spark_pipeline.schemas.campaign_selection import CampaignSelection


def get_modelling_period(weekly_dates_df: DataFrame):
    """
    Determines the modelling period based on the minimum and maximum WEEK_START_DT in the input DataFrame.

    Args:
        weekly_dates_df (DataFrame): Spark DataFrame containing a column 'WEEK_START_DT' with date values.

    Returns:
        Tuple:
            - model_start_date: Earliest date in 'WEEK_START_DT'.
            - model_end_date: Latest date in 'WEEK_START_DT'.
            - date_1_yr: Date one year before the model_end_date (used for new launch filtering).
    """
    # Set the modelling period to filter the sales data by
    # Compute the date one year before the model end date to filter for new launches
    date_row = weekly_dates_df.agg(
        F.min("WEEK_START_DT").alias("model_start_date"),
        F.max("WEEK_START_DT").alias("model_end_date")
    ).first()

    model_start_date = date_row["model_start_date"]
    model_end_date = date_row["model_end_date"]
    date_1_yr = model_end_date - timedelta(days=365)

    return model_start_date, model_end_date, date_1_yr


def filter_campaigns(
        unified_campaign_df: DataFrame,
        manual_run_flag: bool,
        manual_campaign_list: Optional[List[str]] = None,
        campaign_list_type: str = "BOOKING_ID"
) -> DataFrame:
    """
    Filters campaigns to process based on manual run parameters.

    Args:
        unified_campaign_df (DataFrame): Spark DataFrame containing campaign data.
        manual_run_flag (bool): If True, filter using the provided campaign list.
        manual_campaign_list (Optional[List[str]]): List of campaign JOB_BAG_NUMBERs to process if manual run is enabled.

    Returns:
        DataFrame: Filtered DataFrame with columns 'CAMPAIGN_ID' and 'JOB_BAG_NUMBER'.
    """
    if manual_run_flag and manual_campaign_list:
        return unified_campaign_df.filter(F.col(campaign_list_type).isin(manual_campaign_list))
    else:
        return unified_campaign_df.filter(F.col("CAMPAIGN_STATUS").isNull())


def aggregate_media_spend(
        unified_campaign_df: DataFrame,
        campaign_type_column: str = 'booking_id'
) -> DataFrame:
    """
    Aggregates the media_spend_amt per booking/job_bag (Pollen/DTP) in unified_campaign_df
    So we can use this value downstream for the iroas based penalty in the UCM selection criteria.

    Args:
        unified_campaign_df (DataFrame): Spark DataFrame containing campaign data.
        campaign_type_column (str): The column to aggregate by, either 'booking_id' for Pollen or 'job_bag_number' for DTP.

    Returns:
        DataFrame: Filtered DataFrame with columns 'CAMPAIGN_ID' and 'JOB_BAG_NUMBER'.

    """

    # Separate the campaigns by their marketing type - coupon at till + ecoupons campaigns have the same marketing type as instore/onsite respectively,
    # but we want to bucket them separately as they are a different type of campaign, and we want to be able to identify them separately for the shrinkage logic since they have different behaviour.
    campaign_source_mapping = {
        "coupon-at-till": ["2050", "2051"],
        "ecoupon": ["4013"],
    }

    campaign_source_expr = (
        F.when(
            F.col("marketing_hierarchy_cd").isin(campaign_source_mapping["coupon-at-till"]),
            F.lit("coupon-at-till"),
        )
        .when(
            F.col("marketing_hierarchy_cd").isin(campaign_source_mapping["ecoupon"]),
            F.lit("ecoupon"),
        )
        .otherwise(F.col("marketing_type"))
    )

    media_spend_buckets = (
        unified_campaign_df
        .withColumn("campaign_source", campaign_source_expr)
        .groupBy(
            "super_category_name",
            "unique_brand_name",
            campaign_type_column,
            "campaign_source",
        )
        .agg(F.sum("media_spend_amt").alias("total_media_spend"))
        .select(
            campaign_type_column,
            "super_category_name",
            "unique_brand_name",
            "campaign_source",
            "total_media_spend",
        )
    )

    media_spend_by_source = (
        media_spend_buckets
        .groupBy("super_category_name", "unique_brand_name", campaign_type_column)
        .agg(
            F.map_from_entries(
                F.collect_list(
                    F.struct(F.col("campaign_source"), F.col("total_media_spend"))
                )
            ).alias("media_spend_by_source")
        )
        .select(
            campaign_type_column,
            "super_category_name",
            "unique_brand_name",
            "media_spend_by_source",
        )
    )

    media_spend_df = (
        unified_campaign_df
        .groupBy("super_category_name", "unique_brand_name", campaign_type_column)
        .agg(
            F.min("campaign_start_dt").alias("min_campaign_start_dt"),
            F.max("campaign_end_dt").alias("max_campaign_end_dt"),
            F.max("post_campaign_dt").alias("max_post_campaign_dt"),
            F.sum("media_spend_amt").alias("total_media_spend"),
            # Add in specific case when for marketing hierarchy code in coupon at till to list as its own marketing type
            F.collect_set(F.when(F.col("marketing_hierarchy_cd").isin(campaign_source_mapping["coupon-at-till"]), "COUPON-AT-TILL").otherwise(F.col("marketing_type"))).alias("marketing_types"),
        )
        .join(
            media_spend_by_source,
            on=["super_category_name", "unique_brand_name", campaign_type_column],
            how="inner",
        )
        .select(
            "super_category_name",
            "unique_brand_name",
            "min_campaign_start_dt",
            "max_campaign_end_dt",
            "max_post_campaign_dt",
            "total_media_spend",
            "media_spend_by_source",
            "marketing_types",
        )
    )

    enriched_unified_campaign_df = (
        unified_campaign_df
        .join(
            media_spend_df,
            on=["super_category_name", "unique_brand_name"],
            how="left"
        )

    )

    return enriched_unified_campaign_df


def get_modelling_period_by_weeks(sales_df: DataFrame):
    """
    Extracts the most recent 104 unique week start dates from the sales DataFrame and splits them into two periods.

    Args:
        sales_df (DataFrame): Spark DataFrame containing a 'WEEK_START_DT' column.

    Returns:
        Tuple[List, List, List]:
            - last_104_weeks_dates: List of the most recent 104 week start dates (descending order).
            - last_52_weeks_dates: List of the most recent 52 week start dates.
            - first_52_weeks_dates: List of the previous 52 week start dates (weeks 53-104).
    """
    last_104_weeks = (
        sales_df.select("WEEK_START_DT")
        .distinct()
        .orderBy(F.col("WEEK_START_DT").desc())
        .limit(104)
    )
    last_104_weeks_dates = [row["WEEK_START_DT"] for row in last_104_weeks.collect()]
    last_52_weeks_dates = last_104_weeks_dates[:52]
    first_52_weeks_dates = last_104_weeks_dates[52:]
    return last_104_weeks_dates, last_52_weeks_dates, first_52_weeks_dates


def get_new_launch_flags(
    sales_df,
    first_52_weeks_dates,
    last_52_weeks_dates,
    date_1_yr
):
    """
    Computes new launch flags for each brand × super category based on sales activity in the first and last 52 weeks.

    Args:
        sales_df (DataFrame): Spark DataFrame containing sales data with columns 'WEEK_START_DT', 'ITEM_CD', 'UNIQUE_BRAND_NAME', 'SUPER_CATEGORY_NAME', 'TOTAL_SALES_AMT', and 'KEY'.
        first_52_weeks_dates (List): List of week start dates for the first 52 weeks of the modelling period.
        last_52_weeks_dates (List): List of week start dates for the last 52 weeks of the modelling period.
        date_1_yr (date): Date representing one year before the end of the modelling period.

    Returns:
        DataFrame: DataFrame with columns:
            - UNIQUE_BRAND_NAME
            - SUPER_CATEGORY_NAME
            - PART (1 = first 52 weeks, 2 = last 52 weeks)
            - FIRST_TRANSACTION_DT (first non-zero sales date in the period)
            - FIRST_TRANSACTION_DT_OVERALL (earliest non-zero sales date across both periods)
            - RECENT_AVAILABLE (sum of PARTs with non-zero sales)
            - IS_NEW_TRANSACTION_DT (1 if first transaction is within the last year, else 0)
            - AVAILABILITY_FLAG (1 if sales in either period, else 0)
            - NEW_LAUNCH_FLAG (1 if new launch criteria met, else 0)
    """
    # Assign time partition flag (PART: 1 = first 52 weeks, 2 = last 52 weeks) for new launch calculation
    sales_df = (
        sales_df.withColumn(
            "PART",
            F.when(F.col("WEEK_START_DT").isin(first_52_weeks_dates), F.lit(1))
            .when(F.col("WEEK_START_DT").isin(last_52_weeks_dates), F.lit(2))
            .otherwise(F.lit(0))
        )
        .select(
            "WEEK_START_DT",
            "ITEM_CD",
            "UNIQUE_BRAND_NAME",
            "SUPER_CATEGORY_NAME",
            "TOTAL_SALES_AMT",
            "KEY",
            "PART"
        )
    )

    # Get the first sale date for each brand/category/part combination
    first_sale_by_part = (
        sales_df
        .filter(F.col("TOTAL_SALES_AMT") != 0)
        .groupBy("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "PART")
        .agg(F.min("WEEK_START_DT").alias("FIRST_TRANSACTION_DT"))
    )

    # First sale date across both periods for each brand/category
    first_sale_overall = (
        first_sale_by_part
        .groupBy("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME")
        .agg(F.min("FIRST_TRANSACTION_DT").alias("FIRST_TRANSACTION_DT_OVERALL"))
    )

    # Count of non-zero sale periods (PART=1 and/or PART=2) per brand/category
    recent_availability = (
        first_sale_by_part
        .groupBy("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME")
        .agg(F.sum("PART").alias("RECENT_AVAILABLE"))
    )

    # Merge these into one df to be used for the new launch calculation
    first_sale_by_part = (
        first_sale_by_part
        .join(first_sale_overall, ["UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME"], "left")
        .join(recent_availability, ["UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME"], "left")
        .select(
            "UNIQUE_BRAND_NAME",
            "SUPER_CATEGORY_NAME",
            "PART",
            "FIRST_TRANSACTION_DT",
            "FIRST_TRANSACTION_DT_OVERALL",
            "RECENT_AVAILABLE"
        )
    )

    # Compute new launch status based on recency and availability
    # If the first transaction date is more than a year ago, it's a new launch
    new_launch_flags_df = (
        first_sale_by_part
        .withColumn(
            "IS_NEW_TRANSACTION_DT",
            F.when(F.col("FIRST_TRANSACTION_DT_OVERALL") > F.lit(date_1_yr), F.lit(1)).otherwise(F.lit(0))
        )
        .withColumn(
            "AVAILABILITY_FLAG",
            F.when(F.col("RECENT_AVAILABLE") == 1, F.lit(1)).otherwise(F.lit(0))
        )
        .withColumn(
            "NEW_LAUNCH_FLAG",
            F.when(F.col("IS_NEW_TRANSACTION_DT") + F.col("AVAILABILITY_FLAG") > 0, F.lit(1)).otherwise(F.lit(0))
        )
        .select(
            "UNIQUE_BRAND_NAME",
            "SUPER_CATEGORY_NAME",
            "PART",
            "FIRST_TRANSACTION_DT",
            "FIRST_TRANSACTION_DT_OVERALL",
            "RECENT_AVAILABLE",
            "IS_NEW_TRANSACTION_DT",
            "AVAILABILITY_FLAG",
            "NEW_LAUNCH_FLAG"
        )
    )
    return new_launch_flags_df


def calculate_sparsity(
        sales_df: DataFrame,
        sales_threshold_for_sparsity: int
) -> DataFrame:
    """
    Calculates the sparsity measure for each brand × super category group in the sales data.

    Main purpose is to identify whether a sales series for a proxy is too sparse
    (sparsity criteria fails - top 80% of sales comes from only at-most 30% of weeks).


    Args:
        :param spark: Spark session object
        :param sales_df: DataFrame containing sales data
        :param sales_threshold_for_sparsity: Weekly sales threshold used to detect sparse SKUs (e.g., 80 for 80%).

    Returns:
        DataFrame:
            Contains columns 'UNIQUE_BRAND_NAME', 'SUPER_CATEGORY_NAME', and 'SPARSITY_VALUE' (int).
    """

    sales_threshold = sales_threshold_for_sparsity

    # Sort and calculate cumulative sum and percentage
    window_spec = Window.partitionBy("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME").orderBy(
        F.col("TOTAL_SALES_AMT").desc())
    group_window = Window.partitionBy("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME")

    sales_df = sales_df.withColumn(
        "TOTAL_SUM", F.sum("TOTAL_SALES_AMT").over(group_window)
    ).withColumn(
        "CUM_SUM", F.sum("TOTAL_SALES_AMT").over(window_spec.rowsBetween(Window.unboundedPreceding, 0))  # sum up to current row
    ).withColumn(
        "CUM_PCT", (F.col("CUM_SUM") / F.col("TOTAL_SUM")) * 100
    ).withColumn(  # This tells you how close the cumulative sales up to that week are to the threshold
        "DIFF", F.abs(F.col("CUM_PCT") - F.lit(sales_threshold))
    )

    sales_df = sales_df.withColumn(
        "ROW_NUM", F.row_number().over(window_spec)
    )
    min_diff_window = Window.partitionBy("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME")

    sales_df = sales_df.withColumn(
        "MIN_DIFF", F.min("DIFF").over(min_diff_window)
    ).withColumn(
        "IS_CLOSEST", F.when(F.col("DIFF") == F.col("MIN_DIFF"), F.col("ROW_NUM")).otherwise(None)
    )

    # The number of weeks needed to reach this threshold
    # Max of closest will be the week where cumulative sales is closest to the threshold
    result_df = sales_df.groupBy("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME").agg(
        F.count("*").alias("NO_OF_WEEKS"),
        F.max("IS_CLOSEST").alias("NO_OF_WEEKS_WITH_MAXSALESSHARE")
    )
    # If the sales are concentrated in a few weeks, the sparsity value will be high
    result_df = result_df.withColumn(
        "SPARSITY_VALUE",
        F.ceil((F.col("NO_OF_WEEKS") - F.col("NO_OF_WEEKS_WITH_MAXSALESSHARE")) / F.col("NO_OF_WEEKS") * 100)
    )

    return result_df.select("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "SPARSITY_VALUE")


def proxy_brands_identifier(
        spark: SparkSession,
        sc_list: List[str],
        sales_df: DataFrame,
        new_launch_df: DataFrame,
        classifier_cases_week_no_threshold: int,
        sales_threshold_for_sparsity: int,
        sparsity_threshold: int,
) -> DataFrame:
    """
    Funtion to identify proxy brands for a new launch

    Objective:
        To ensure that proxies must have enough sales data for running clustering and hence performing UCM.
        We are excluding those brands from the proxy list that have not either sales in latest year of
        modelling period, or sales in at-least 52 weeks of modelling period, or sales data is too sparse
        (sparsity criteria fails - top 80% of sales comes from only at-most 30% of weeks)


    Args:
        :param spark: Spark session object
        :param sc_list: Super categories for which we need to identify proxy brands
        :param sales_df: Data Frame containing Sales data
        :param new_launch_df: Contains all new launch cases (NEW_LAUNCH_FLAG = 1)
        :param classifier_cases_week_no_threshold: Minimum number of weeks required to consider a case for classification.
        :param sales_threshold_for_sparsity: Weekly sales threshold used to detect sparse SKUs.
        :param sparsity_threshold: Number of sparse weeks to qualify a SKU as sparse.


    Returns:
        all_brand_req_df (pd.DataFrame): Contains info for suitable proxy brands along with
            what to run for each proxy brand X super category
    """

    sc_list = [item for item in sc_list if item is not None]

    concat_list = [row["CONCAT"] for row in new_launch_df.select("CONCAT").distinct().collect()]

    # Get a list of unique brands in the same super category and ignoring those that are already a new launch case
    all_brand_req_df = (
        sales_df
        .select("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME")
        .distinct()
        .filter(F.col("SUPER_CATEGORY_NAME").isin(sc_list))
        .withColumn("CONCAT", F.concat_ws("", F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME")))
        .filter(~F.col("CONCAT").isin(concat_list))
    )

    sales_data_filter = (
        sales_df
        .filter(F.col("SUPER_CATEGORY_NAME").isin(sc_list))
        .withColumn("CONCAT", F.concat_ws("", F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME")))
        .filter(~F.col("CONCAT").isin(concat_list))
    )

    # The following logic ensures proxies have sufficient sales data for clustering and running UCM
    if all_brand_req_df.count() > 0:

        # Finding cases where we have 0 sales in latest 1 year of modelling period
        max_value_df = sales_data_filter.agg(F.max("WEEK_START_DT").alias("MAX_DATE"))
        latest_date = max_value_df.first()["MAX_DATE"]
        count_latest_weeks_no_sales = classifier_cases_week_no_threshold

        try:
            dt = datetime.strptime(str(latest_date), "%Y-%m-%d")
        except ValueError:
            dt = datetime.strptime(str(latest_date), "%Y-%m-%d %H:%M:%S")

        one_year_ago = (dt - timedelta(weeks=count_latest_weeks_no_sales)).strftime("%Y-%m-%d")

        # Get last year of data in modelling period from sales
        df_last_year = (
            sales_data_filter
            .filter(F.to_date("WEEK_START_DT") >= F.lit(one_year_ago))
            .groupBy("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "CONCAT", "WEEK_START_DT")
            .agg(F.sum("TOTAL_SALES_AMT").alias("TOTAL_SALES_AMT"))
        )

        brands_with_zero_sales = (
            df_last_year
            .groupBy("CONCAT")
            .agg(F.sum(F.when(F.col("TOTAL_SALES_AMT") == 0, 1).otherwise(0)).alias("zero_sales_weeks"),
                 F.count("*").alias("total_weeks"))
            .filter(F.col("zero_sales_weeks") == F.col("total_weeks"))
            .select("CONCAT")
        )

        brands_zero_sales_list = [row["CONCAT"] for row in brands_with_zero_sales.collect()]

        # Finding cases where we don't have at least 52 weeks of sales
        sales_data_group = (
            sales_data_filter
            .filter(F.col("TOTAL_SALES_AMT") != 0)
            .groupBy("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "CONCAT", "WEEK_START_DT")
            .agg(F.sum("TOTAL_SALES_AMT").alias("TOTAL_SALES_AMT"))
            .groupBy("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "CONCAT")
            .agg(F.count("TOTAL_SALES_AMT").alias("COUNT"))
            .filter(F.col("COUNT") < count_latest_weeks_no_sales)
            .select("CONCAT")
        )

        brands_not_52_week_sales_list = [row["CONCAT"] for row in sales_data_group.collect()]

        # Finding cases where sparsity criteria fails (top 80% sales is due to at most 30% of weeks)
        brands_with_high_sparsity = []

        exclude_list = brands_zero_sales_list + brands_not_52_week_sales_list

        # Filter and aggregate the data so we get sales data that have least 52 weeks of data
        sales_data_sparsity = (
            sales_data_filter
            .filter(~F.col("CONCAT").isin(exclude_list))
            .groupBy('UNIQUE_BRAND_NAME', 'SUPER_CATEGORY_NAME', 'CONCAT', 'WEEK_START_DT')
            .agg(F.sum("TOTAL_SALES_AMT").alias("TOTAL_SALES_AMT"))
        )

        if sales_data_sparsity.count() > 0:
            # Calculate sparsity for each brand and super category
            sales_data_sparsity = calculate_sparsity(sales_data_sparsity, sales_threshold_for_sparsity)

            sales_data_sparsity = sales_data_sparsity.withColumn(
                "SPARSITY_FLAG",
                F.when(F.col("sparsity_value") >= sparsity_threshold, "NOT REQUIRED").otherwise("REQUIRED")
            )

            sales_data_sparsity = sales_data_sparsity.withColumn(
                "CONCAT", F.concat(F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME"))
            )

            brands_with_high_sparsity_df = (
                sales_data_sparsity
                .filter(F.col("SPARSITY_FLAG") == "NOT REQUIRED")
                .select("CONCAT")
                .distinct()
            )

            brands_with_high_sparsity = [row["CONCAT"] for row in brands_with_high_sparsity_df.collect()]

        # Getting final proxy brands list
        all_brand_req_df = (
            all_brand_req_df
            .filter(~F.col("CONCAT").isin(brands_zero_sales_list))
            .filter(~F.col("CONCAT").isin(brands_not_52_week_sales_list))
            .filter(~F.col("CONCAT").isin(brands_with_high_sparsity))
            .withColumn("STATUS", F.lit("CLUSTERING"))
            .select("SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "STATUS")
        )
    else:
        schema = CampaignSelection.proxy_schema
        all_brand_req_df = spark.createDataFrame([], schema)

    return all_brand_req_df


def old_sc_case_runner(
        spark: SparkSession,
        old_sc_cases_df: DataFrame,
        sales_df: DataFrame,
        cam_selection_tbl: DataFrame,
        classifier_cases_week_no_threshold: int,
        sales_threshold_for_sparsity: int,
        sparsity_threshold: int
) -> Tuple[DataFrame, DataFrame]:
    """
    Determines proxy brands for the new launch case when super category is old.

    Args:
        :param spark: The SparkSession object.
        :param old_sc_cases_df : New launch cases with old super categories.
        :param sales_df : Sales data.
        :param cam_selection_tbl : All new launch cases.
        :param classifier_cases_week_no_threshold: Minimum number of weeks required to consider a case for classification.
        :param sales_threshold_for_sparsity: Weekly sales threshold used to detect sparse SKUs.
        :param sparsity_threshold: Number of sparse weeks to qualify a SKU as sparse.

    Returns:
        Tuple[SparkDataFrame, SparkDataFrame]:
            - all_brand_req_df_old_sc_case: proxy brand modeling info
            - mapping_df_old_sc_case: new launch to proxy brand mapping
    """

    cam_selection_tbl = cam_selection_tbl.withColumn(
        "CONCAT", F.concat_ws("", F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME"))
    )
    old_sc_cases_df = old_sc_cases_df.withColumn(
        "CONCAT", F.concat_ws("", F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME"))
    )

    new_manufacturers_by_supercat_df = (
        cam_selection_tbl
        .select("SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME")
        .dropDuplicates()
        .withColumn("CONCAT", F.concat_ws("", F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME")))
    )

    # Get list of super categories to fetch proxies for
    target_sc_list = [row["SUPER_CATEGORY_NAME"] for row in old_sc_cases_df.select("SUPER_CATEGORY_NAME").distinct().collect()]

    proxy_brands_df = proxy_brands_identifier(
        spark, target_sc_list, sales_df, new_manufacturers_by_supercat_df,
        classifier_cases_week_no_threshold, sales_threshold_for_sparsity, sparsity_threshold
    )

    proxy_brands_df_for_mapping = (
        proxy_brands_df
        .selectExpr("SUPER_CATEGORY_NAME as PROXY_SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME as PROXY_BRANDS")
    )

    # Initialize outputs
    all_brand_req_df_old_sc_case = None
    mapping_df_old_sc_case = None

    # Loop over each unique brand-sc combo
    concat_values = [row["CONCAT"] for row in old_sc_cases_df.select("CONCAT").distinct().collect()]

    # Iterating through old super category cases
    for concat_val in concat_values:
        req_df_temp = old_sc_cases_df.filter(F.col("CONCAT") == concat_val)

        sc_name = req_df_temp.select("SUPER_CATEGORY_NAME").first()["SUPER_CATEGORY_NAME"]
        brand_name = req_df_temp.select("UNIQUE_BRAND_NAME").first()["UNIQUE_BRAND_NAME"]

        all_brand_req_df_dum = proxy_brands_df.filter(F.col("SUPER_CATEGORY_NAME") == sc_name)
        mapping_df_dum = proxy_brands_df_for_mapping.filter(F.col("PROXY_SUPER_CATEGORY_NAME") == sc_name)

        if mapping_df_dum.count() > 0:
            mapping_df_dum = (
                mapping_df_dum
                .withColumn("UNIQUE_BRAND_NAME", F.lit(brand_name))
                .withColumn("SUPER_CATEGORY_NAME", F.lit(sc_name))
            )
        else:
            all_brand_req_df_dum = spark.createDataFrame([], proxy_brands_df.schema)
            mapping_df_dum = spark.createDataFrame([], proxy_brands_df_for_mapping.schema)

        if all_brand_req_df_old_sc_case is None:
            all_brand_req_df_old_sc_case = all_brand_req_df_dum
        else:
            all_brand_req_df_old_sc_case = all_brand_req_df_old_sc_case.union(all_brand_req_df_dum)

        if mapping_df_old_sc_case is None:
            mapping_df_old_sc_case = mapping_df_dum
        else:
            mapping_df_old_sc_case = mapping_df_old_sc_case.union(mapping_df_dum)

    return all_brand_req_df_old_sc_case, mapping_df_old_sc_case


def new_sc_case_helper_1(
    spark: SparkSession,
    check_old_sc_df: DataFrame,
    current_sc: str,
    itr: str
) -> DataFrame:
    """
    Checks whether a super category is a rename of a previous one for a given brand × super category.

    Objective:
        Helps new_sc_case_runner determine if a super category is a renamed version of a previous one,
        and identifies the most recent previous super category if applicable.

    Args:
        :param spark: The SparkSession object.
        :param check_old_sc_df: DataFrame with historical ITEM_CD to SUPER_CAT_NAME mappings.
        :param current_sc: Current super category name.
        :param itr: Current brand + super category key (used as CONCAT key).

    Returns:
        :return: Spark DataFrame with columns: CONCAT, RENAME_FLAG, OLD_SC_PREVIOUS.
                 - CONCAT (str): Brand + super category key.
                 - RENAME_FLAG (int): 1 if renamed, 0 otherwise.
                 - OLD_SC_PREVIOUS (str): Most recent previous super category name if renamed, else None.
    """
    if check_old_sc_df.count() == 0:
        return spark.createDataFrame([], CampaignSelection.new_super_category_schema)

    # Get unique super categories excluding current_sc
    check_old_sc_list = (
        check_old_sc_df
        .select(F.upper(F.col("SUPER_CAT_NAME")).alias("SUPER_CAT_NAME"))
        .distinct()
        .rdd.flatMap(lambda x: x)
        .filter(lambda x: x != current_sc.upper())
        .collect()
    )

    # For each item_cd, get set of super_cat_names
    item_sc_df = check_old_sc_df.select("ITEM_CD", "SUPER_CAT_NAME").distinct()
    item_sets = (
        item_sc_df
        .groupBy("ITEM_CD")
        .agg(F.collect_set("SUPER_CAT_NAME").alias("sc_set"))
        .select("sc_set")
        .distinct()
        .count()
    )

    rename_flag = 0
    old_sc_recent = None

    if item_sets == 1 and len(check_old_sc_list) > 0:
        # Aggregate min(VALID_FROM_DT), max(VALID_UNTIL_DT) by SUPER_CAT_NAME
        df_agg = (
            check_old_sc_df
            .groupBy("SUPER_CAT_NAME")
            .agg(
                F.min("VALID_FROM_DT").alias("min_valid_from"),
                F.max("VALID_UNTIL_DT").alias("max_valid_until")
            )
            .filter(F.col("SUPER_CAT_NAME") != current_sc)
            .orderBy(F.col("max_valid_until").desc())
        )
        row = df_agg.select("SUPER_CAT_NAME").first()
        if row:
            rename_flag = 1
            old_sc_recent = row["SUPER_CAT_NAME"]

    result = [(itr, rename_flag, old_sc_recent)]
    return spark.createDataFrame(result, CampaignSelection.new_super_category_schema)


# ToDo This function is a bit mess but is rarely called, refactor at some point
def new_sc_case_helper_2(
        spark,
        req_df_temp: DataFrame,
        proxy_brands_df: DataFrame,
        proxy_brands_df_for_mapping: DataFrame
):
    """
    Helps new_sc_case_runner filter and identify proxy brands for a new super category case.

    Args:
        :param spark: The SparkSession object.
        :param req_df_temp: DataFrame containing a new launch case where the super category is new.
        :param proxy_brands_df: DataFrame containing proxy brand and super category for the current new launch case, with modelling stream info.
        :param proxy_brands_df_for_mapping: DataFrame containing only proxy brand and super category information for the current new launch case.

    Returns:
        all_brand_req_df_dum (DataFrame): Info for proxy brands regarding what to run for each brand × super category, for new super category case.
        mapping_df_dum (DataFrame): Mapping between new launch and their proxies for new super category case.
    """
    # Get current super category name
    ls_sc_name = req_df_temp.select("SUPER_CATEGORY_NAME").distinct().limit(1).collect()
    ls_sc_name = ls_sc_name[0]["SUPER_CATEGORY_NAME"] if ls_sc_name else None

    all_brand_req_df_v1 = proxy_brands_df.filter(F.col("SUPER_CATEGORY_NAME") == ls_sc_name)
    mapping_df_v1 = proxy_brands_df_for_mapping.filter(F.col("PROXY_SUPER_CATEGORY_NAME") == ls_sc_name)

    if mapping_df_v1.count() > 0:
        brand_row = req_df_temp.select("SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME").distinct().limit(1).collect()[0]
        mapping_df_v1 = (
            mapping_df_v1
            .withColumn("UNIQUE_BRAND_NAME", F.lit(brand_row["UNIQUE_BRAND_NAME"]))
            .withColumn("SUPER_CATEGORY_NAME", F.lit(brand_row["SUPER_CATEGORY_NAME"]))
        )
    else:
        all_brand_req_df_v1 = spark.createDataFrame([], proxy_brands_df.schema)
        mapping_df_v1 = spark.createDataFrame([], proxy_brands_df_for_mapping.schema.add("UNIQUE_BRAND_NAME", "string").add("SUPER_CATEGORY_NAME", "string"))

    # Get previous super category name
    pv_sc_name = req_df_temp.select("OLD_SC_PREVIOUS").distinct().limit(1).collect()
    pv_sc_name = pv_sc_name[0]["OLD_SC_PREVIOUS"] if pv_sc_name else None

    all_brand_req_df_v2 = proxy_brands_df.filter(F.col("SUPER_CATEGORY_NAME") == pv_sc_name)
    mapping_df_v2 = proxy_brands_df_for_mapping.filter(F.col("PROXY_SUPER_CATEGORY_NAME") == pv_sc_name)

    if mapping_df_v2.count() > 0:
        brand_row = req_df_temp.select("SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME").distinct().limit(1).collect()[0]
        mapping_df_v2 = (
            mapping_df_v2
            .withColumn("UNIQUE_BRAND_NAME", F.lit(brand_row["UNIQUE_BRAND_NAME"]))
            .withColumn("SUPER_CATEGORY_NAME", F.lit(brand_row["SUPER_CATEGORY_NAME"]))
        )
    else:
        all_brand_req_df_v2 = spark.createDataFrame([], proxy_brands_df.schema)
        mapping_df_v2 = spark.createDataFrame([], proxy_brands_df_for_mapping.schema.add("UNIQUE_BRAND_NAME", "string").add("SUPER_CATEGORY_NAME", "string"))

    if all_brand_req_df_v1.count() > all_brand_req_df_v2.count():
        return all_brand_req_df_v1, mapping_df_v1
    else:
        return all_brand_req_df_v2, mapping_df_v2


def new_sc_case_runner(
        spark: SparkSession,
        new_sc_cases_df,
        sales_df,
        dim_item_hist_tbl,
        cam_selection_tbl,
        classifier_cases_week_no_threshold: int,
        sales_threshold_for_sparsity: int,
        sparsity_threshold: int,
        model_start_date,
        model_end_date
):
    """
        Determines proxy brands for the new launch case when super category is new.

        Objective:
            Main purpose of this function is to get proxy brands × super category for the new launch case
            when super category is new, along with the modelling stream to run for each proxy
            brands × super category.

        Args:
            :param spark: The SparkSession object.
            :param new_sc_cases_df: DataFrame containing new launch cases where super category is new.
            :param sales_df: DataFrame containing sales data for each brand × super category.
            :param dim_item_hist_tbl: DataFrame mapping item codes to historical super categories.
            :param cam_selection_tbl: DataFrame containing all new launch cases (NEW_LAUNCH_FLAG = 1).
            :param classifier_cases_week_no_threshold: Minimum number of weeks required to consider a case for classification.
            :param sales_threshold_for_sparsity: Weekly sales threshold used to detect sparse SKUs.
            :param sparsity_threshold: Number of sparse weeks to qualify a SKU as sparse.
            :param model_start_date: Start date of the modelling period (YYYY-MM-DD).
            :param model_end_date: End date of the modelling period (YYYY-MM-DD).

        Returns:
            all_brand_req_df_new_sc_case (DataFrame): Info for proxy brands regarding what to run for each brand × super category, for new super category case.
            mapping_df_new_sc_case (DataFrame): Mapping between new launch and their proxies for new super category case.
        """

    add_check_df = new_sc_cases_df.select("ITEM_CD", "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME").dropDuplicates()
    add_check_df = add_check_df.withColumn("CONCAT", F.concat_ws("", "UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME"))

    # Replace any null value ToDo make this use run_date
    dim_item_hist_tbl = (
        dim_item_hist_tbl
        .withColumn("VALID_FROM_DT", F.coalesce("VALID_FROM_DT", F.current_date()))
        .withColumn("VALID_UNTIL_DT", F.coalesce("VALID_UNTIL_DT", F.current_date()))
    )

    filtr_dim_item_hist = dim_item_hist_tbl.filter(
        (F.col("VALID_FROM_DT") <= F.lit(model_end_date)) &
        (F.col("VALID_UNTIL_DT") >= F.lit(model_start_date))
    )

    status_df = None

    # Loop through each brand x super category combination in add_check_df
    for row in add_check_df.select("CONCAT").distinct().collect():
        concat_key = row["CONCAT"]
        current_sc = add_check_df.filter(F.col("CONCAT") == concat_key).select("SUPER_CATEGORY_NAME").first()[0]
        item_cd_list = add_check_df.filter(F.col("CONCAT") == concat_key).select("ITEM_CD").distinct()

        check_old_sc_df = (
            filtr_dim_item_hist
            .join(item_cd_list, on="ITEM_CD", how="inner")
            .withColumn("SUPER_CAT_NAME", F.upper("SUPER_CAT_NAME"))
        )

        # Checking whether a super category is renamed
        result = new_sc_case_helper_1(spark, check_old_sc_df, current_sc, concat_key)
        status_df = result if status_df is None else status_df.union(result)

    add_check_df = add_check_df.join(status_df, on="CONCAT", how="left")
    new_sc_cases_df = new_sc_cases_df.join(
        add_check_df.select("ITEM_CD", "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "RENAME_FLAG", "OLD_SC_PREVIOUS"),
        on=["ITEM_CD", "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME"],
        how="left"
    )

    cam_selection_tbl = cam_selection_tbl.withColumn("CONCAT",
                                                     F.concat_ws("", "UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME"))
    new_sc_cases_df = new_sc_cases_df.withColumn("CONCAT", F.concat_ws("", "UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME"))

    new_manufacturers_by_supercat_df = (
        cam_selection_tbl
        .select("SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME")
        .dropDuplicates()
        .withColumn("CONCAT", F.concat_ws("", "UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME"))
    )

    target_sc_list = (
        new_sc_cases_df
        .select("SUPER_CATEGORY_NAME")
        .union(new_sc_cases_df.select("OLD_SC_PREVIOUS").filter(F.col("OLD_SC_PREVIOUS").isNotNull()))
        .distinct()
        .rdd.flatMap(lambda x: x)
        .collect()
    )

    # Get proxy brands
    proxy_brands_df = proxy_brands_identifier(spark, target_sc_list, sales_df, new_manufacturers_by_supercat_df,
                                              classifier_cases_week_no_threshold, sales_threshold_for_sparsity,
                                              sparsity_threshold
                                              )
    proxy_brands_df_for_mapping = (
        proxy_brands_df
        .select("SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME")
        .withColumnRenamed("SUPER_CATEGORY_NAME", "PROXY_SUPER_CATEGORY_NAME")
        .withColumnRenamed("UNIQUE_BRAND_NAME", "PROXY_BRANDS")
    )

    all_brand_req_df_new_sc_case = None
    mapping_df_new_sc_case = None

    for row in new_sc_cases_df.select("CONCAT").distinct().collect():
        concat_key = row["CONCAT"]
        req_df_temp = new_sc_cases_df.filter(F.col("CONCAT") == concat_key)

        if req_df_temp.filter(F.col("OLD_SC_PREVIOUS").isNotNull()).count() > 0:
            # Find proxies for a new super category case
            all_brand_req_df_dum, mapping_df_dum = new_sc_case_helper_2(spark, req_df_temp, proxy_brands_df,
                                                                        proxy_brands_df_for_mapping)
        else:
            # Get proxy brands for each brand x super category in the new launch case
            ls_sc_name = req_df_temp.select("SUPER_CATEGORY_NAME").first()["SUPER_CATEGORY_NAME"]

            all_brand_req_df_dum = proxy_brands_df.filter(F.col("SUPER_CATEGORY_NAME") == ls_sc_name)
            mapping_df_dum = proxy_brands_df_for_mapping.filter(F.col("PROXY_SUPER_CATEGORY_NAME") == ls_sc_name)

            if mapping_df_dum.count() > 0:
                brand_name = req_df_temp.select("UNIQUE_BRAND_NAME").first()["UNIQUE_BRAND_NAME"]
                sc_name = req_df_temp.select("SUPER_CATEGORY_NAME").first()["SUPER_CATEGORY_NAME"]

                mapping_df_dum = (
                    mapping_df_dum
                    .withColumn("UNIQUE_BRAND_NAME", F.lit(brand_name))
                    .withColumn("SUPER_CATEGORY_NAME", F.lit(sc_name))
                )
            else:
                all_brand_req_df_dum = spark.createDataFrame([], proxy_brands_df.schema)
                mapping_df_dum = spark.createDataFrame([], proxy_brands_df_for_mapping.schema)

        if all_brand_req_df_new_sc_case is None:
            all_brand_req_df_new_sc_case = all_brand_req_df_dum
        else:
            all_brand_req_df_new_sc_case = all_brand_req_df_new_sc_case.union(all_brand_req_df_dum)

        if mapping_df_new_sc_case is None:
            mapping_df_new_sc_case = mapping_df_dum
        else:
            mapping_df_new_sc_case = mapping_df_new_sc_case.union(mapping_df_dum)

    return all_brand_req_df_new_sc_case, mapping_df_new_sc_case


def sc_case_runner(
        spark: SparkSession,
        new_launch_case_df: DataFrame,
        sales_data: DataFrame,
        dim_item_hist: DataFrame,
        classifier_cases_week_no_threshold: int,
        sales_threshold_for_sparsity: int,
        sparsity_threshold: int,
        model_start_date,
        model_end_date
) -> Tuple[DataFrame, DataFrame, DataFrame, DataFrame]:
    """
    Handles both new launch cases with old and new Super Categories.

    Args:
        :param spark: The SparkSession object.
        :param new_launch_case_df: DataFrame containing all new launch Brand x Super Category combinations.
        :param sales_data: Sales DataFrame containing weekly sales by SKU.
        :param dim_item_hist: DataFrame mapping item codes to historical super categories.
        :param classifier_cases_week_no_threshold: Minimum number of weeks required to consider a case for classification.
        :param sales_threshold_for_sparsity: Weekly sales threshold used to detect sparse SKUs.
        :param sparsity_threshold: Number of sparse weeks to qualify a SKU as sparse.
        :param model_start_date: Start date of the modelling period (YYYY-MM-DD).
        :param model_end_date: End date of the modelling period (YYYY-MM-DD).

    Returns:
        Tuple[DataFrame, DataFrame, DataFrame, DataFrame]:
            - old_sc_case_reqd
            - old_sc_case_mapping_df
            - new_sc_case_reqd
            - new_sc_case_mapping_df
    """

    # Filter for old super category new launch case (NEW_SC_LAUNCH == 0)
    old_sc_case_df = new_launch_case_df.filter(new_launch_case_df["NEW_SC_LAUNCH"] == 0)

    if old_sc_case_df.count() > 0:
        old_sc_case_output, old_sc_case_mapping_df = old_sc_case_runner(
            spark, old_sc_case_df, sales_data, new_launch_case_df,
            classifier_cases_week_no_threshold, sales_threshold_for_sparsity,
            sparsity_threshold
        )
    else:
        empty_schema = new_launch_case_df.schema
        old_sc_case_output = new_launch_case_df.sparkSession.createDataFrame([], empty_schema)
        old_sc_case_mapping_df = new_launch_case_df.sparkSession.createDataFrame([], empty_schema)

    # Filter for new super category new launch case (NEW_SC_LAUNCH == 1)
    new_sc_case_df = new_launch_case_df.filter(new_launch_case_df["NEW_SC_LAUNCH"] == 1)

    if new_sc_case_df.count() > 0:
        new_sc_case_output, new_sc_case_mapping_df = new_sc_case_runner(
            spark, new_sc_case_df, sales_data, dim_item_hist, new_launch_case_df,
            classifier_cases_week_no_threshold, sales_threshold_for_sparsity,
            sparsity_threshold, model_start_date, model_end_date
        )
    else:
        empty_schema = new_launch_case_df.schema
        new_sc_case_output = new_launch_case_df.sparkSession.createDataFrame([], empty_schema)
        new_sc_case_mapping_df = new_launch_case_df.sparkSession.createDataFrame([], empty_schema)

    return old_sc_case_output, old_sc_case_mapping_df, new_sc_case_output, new_sc_case_mapping_df
