classifier_cases_week_no_threshold: int = 52  # Number of weeks to be considered in latest year
sales_threshold_for_sparsity: int = 80  # Top Percentage of sales used to check for Seasonality in a cluster
sparsity_threshold: int = 70  # Maximum Permissible Sparsity Percentage
# Campaign list type - determines whether to use JOB_BAG_NUMBER or BOOKING_ID
# Valid values: ["JOB_BAG_NUMBER"] or ["BOOKING_ID"]
classifier_cases_campaign_run_type = ["BOOKING_ID"]
DTP_CAMPAIGN_TYPE = "JOB_BAG_NUMBER"
POLLEN_CAMPAIGN_TYPE = "BOOKING_ID"
