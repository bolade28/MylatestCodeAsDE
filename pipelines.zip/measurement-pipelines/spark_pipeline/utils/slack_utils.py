import json
from typing import Optional

import boto3

from spark_pipeline.utils.stdout_logger import get_stdout_logger


CAMPAIN_COUNT = "Campaign Count"


class SlackMessenger:

    def __init__(self, topic_arn: str, correlation_id: str = ""):
        self.topic_arn = topic_arn
        self.correlation_id = correlation_id
        self.client = boto3.client("sns", region_name="eu-west-1")

    def __format__payload(self, text, event_type, data):
        payload = {}
        if text:
            payload["text"] = text
        if event_type:
            payload["eventType"] = event_type
        if data:
            payload["data"] = data
        if self.correlation_id:
            payload["correlation_id"] = self.correlation_id
        return payload

    def send_message(self, text: Optional[str] = None, event_type: Optional[str] = None, data: Optional[dict] = None):
        """
        Sends message through Slack Messenger Lambda handler to send to Slack.

        :param text: The main body of the text to send (in plaintext).
        :param event_type: The header of the event to send through. Can be any string, or one of the EventType enums.
        :param data: A dict containing key, value pairs of information to show
        """
        try:
            payload = self.__format__payload(text, event_type, data)

            self.client.publish(
                TopicArn=self.topic_arn,
                Subject="Slack Messenger event",
                MessageStructure="json",
                Message=json.dumps({"default": json.dumps(payload)})
            )
        except Exception as e:
            logger = get_stdout_logger()
            logger.error(f"Slack message send has failed.\nReason: {e}")
