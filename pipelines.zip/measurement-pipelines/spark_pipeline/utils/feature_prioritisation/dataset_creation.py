from pyspark.sql import DataFrame, functions as F
from typing import Tuple, List

from spark_pipeline.schemas.feature_prioritisation import FeaturePrioritisation
from spark_pipeline.utils.feature_prioritisation.feature_generation import seasonality_index_creator, \
    std_dev_control_creator_all, week_start_control_creator_all, list_independent_ext_factors, melt_dataframe
from spark_pipeline.utils.feature_prioritisation.modelling_functions import create_correlation_processor, \
    apply_min_max_scaling

from spark_pipeline.common.variables import FeaturePrioritisationConfig


def initial_dataset_creation(
    baseline_modelling_dataset: DataFrame,
    primary_metric_df: DataFrame,
    model_start: str,
    model_end: str
) -> Tuple[DataFrame, DataFrame]:
    """
    Prepares the dependent variable and modeling dataset for feature prioritization.

    Objective:
        Function used to retrieve the dependent variable for feature prioritization.
        We filter for required modelling period and filter and rename columns as per requirement of Feature Prioritization input.

    Args:
        ads_df (DataFrame): Weekly cluster-level marketing dataset.
        primary_metric_df (DataFrame): Reference table defining primary and investment metrics.
        model_start: Start date for the modeling period.
        model_end: End date for the modeling period.

    Returns:
        fp_input_df (DataFrame): Filtered dataset containing dependent variable (TOTAL_SALES).
        master (DataFrame): Full dataset within modeling period, joined with metric info.
    """

    bmd_df = (
        baseline_modelling_dataset
        .withColumnRenamed("week_start_dt", "week_start_date")
        .withColumnRenamed("unique_brand_name", "unique_brand")
        .withColumnRenamed("marketing_type_name", "marketing_type")
        .withColumnRenamed("marketing_channel_name", "marketing_channel")
        .withColumnRenamed("marketing_sub_channel_name", "marketing_sub_channel")
        .withColumnRenamed("metric_name", "metric")
        .withColumnRenamed("metric_value", "value")
        .withColumnRenamed("job_run_id", "job_id")
        .withColumnRenamed("variable_cd", "variable")
    )

    primary_metric_df = (
        primary_metric_df
        .withColumnRenamed("marketing_type_name", "marketing_type")
        .withColumnRenamed("marketing_channel_name", "marketing_channel")
        .withColumnRenamed("marketing_sub_channel_name", "marketing_sub_channel")
        .withColumnRenamed("metric_name", "metric")
        .withColumnRenamed("primary_metric_cd", "primary_metric")
        .withColumnRenamed("investment_metric_cd", "investment_metric")
    )

    # Join primary metric info into main dataset
    # We drop the load_ts column from primary_metric_df to avoid duplication
    bmd_df = bmd_df.join(
        F.broadcast(primary_metric_df.drop("load_ts")),
        on=["marketing_type", "marketing_channel", "marketing_sub_channel", "metric"],
        how="left"
    )

    # Filter by modeling date range
    bmd_df = (
        bmd_df
        .withColumn("week_start_date", F.to_date("week_start_date"))
        .filter(
            (F.col("week_start_date") >= F.lit(model_start)) &
            (F.col("week_start_date") <= F.lit(model_end))
        )
    )

    # Return a copy
    baseline_modelling_dataset = bmd_df.withColumnRenamed("cluster_num", "cluster")

    # Filter for dependent variable (sales)
    fp_input_y_df = (
        bmd_df
        .filter((F.col("marketing_channel") == "SALES") & (F.col("metric") == "TOTAL_SALES"))
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand",
            F.col("cluster_num").alias("final_cluster"),
            F.col("value").alias("feature_prioritization_y")
        )
    )

    return fp_input_y_df, baseline_modelling_dataset


def dataset_variable_creation(
        baseline_modelling_df: DataFrame,
        fp_config: FeaturePrioritisationConfig
) -> tuple[DataFrame, DataFrame]:
    """
    Separates the Dependent and Independent variables in a Dataset for Feature Prioritization

    Objective:
        This function collates the dependent and independent variables for Feature Prioritization (FP).
        It filters the Baseline Modelling Dataset also caled Analytical Dataset (ADS) for relevant modeling metrics, applies transformation
        controls (seasonality, std deviation, week start), and extracts only the relevant external
        variables used for final FP testing.

    Args:
        baseline_modelling_df (DataFrame): Analytical dataset with marketing metrics and sales data
        fp_config (FeaturePrioritisationConfig): Configuration object containing feature prioritization settings
    Returns:
        external_ads_df (DataFrame): Final filtered dataset for external variables
        non_external_ads_df (DataFrame): Remaining internal (non-external) variables
    """

    rename_map = {
        "week_start_date": "week_date",
        "super_category_name": "super_category_name",
        "unique_brand": "unique_brand",
        "cluster": "cluster",
        "marketing_type": "marketing_type",
        "marketing_channel": "marketing_channel",
        "marketing_sub_channel": "marketing_sub_channel",
        "metric": "metric",
        "value": "value",
        "variable": "variable",
        "job_id": "job_id",
        "load_ts": "load_ts",
        "primary_metric": "primary_metric",
        "investment_metric": "investment_metric"
    }

    for old, new in rename_map.items():
        if old in baseline_modelling_df.columns:
            baseline_modelling_df = baseline_modelling_df.withColumnRenamed(old, new)

    master_sales = baseline_modelling_df.filter(
        (F.col("marketing_channel") == "SALES") &
        (F.col("metric") == "TOTAL_SALES")
    )

    # Generate Control Features
    seasonality_df = seasonality_index_creator(master_sales, fp_config).withColumn(
        "variable", F.upper(F.col("variable"))
    )

    stddev_df = std_dev_control_creator_all(master_sales, fp_config).withColumn(
        "variable", F.upper(F.col("variable"))
    )

    dairy_sales = master_sales.filter(F.col("super_category_name") == "DAIRY")

    weekstart_df = week_start_control_creator_all(dairy_sales, fp_config).withColumn(
        "variable", F.upper(F.col("variable"))
    )

    # Add control features to the baseline modelling dataset
    baseline_modelling_df = baseline_modelling_df.unionByName(seasonality_df, allowMissingColumns=True)
    baseline_modelling_df = baseline_modelling_df.unionByName(stddev_df, allowMissingColumns=True)
    baseline_modelling_df = baseline_modelling_df.unionByName(weekstart_df, allowMissingColumns=True)

    # Revert naming of columns in baseline_modelling_df
    for new, old in rename_map.items():
        if old in baseline_modelling_df.columns:
            baseline_modelling_df = baseline_modelling_df.withColumnRenamed(old, new)

    external_variables_df = list_independent_ext_factors(baseline_modelling_df, fp_config)
    external_variables_df = external_variables_df.select(F.upper(F.col("variable")).alias("variable")).distinct()

    # Append control variables into external list
    # ToDo Remove double distinct calls if not needed (check upstream where data is being duplicated)
    for df in [seasonality_df, stddev_df, weekstart_df]:
        external_variables_df = external_variables_df.unionByName(
            df.select(F.upper(F.col("variable")).alias("variable")).distinct()
        ).distinct()

    baseline_modelling_df = (
        baseline_modelling_df
        .withColumn("variable", F.upper(F.col("variable")))
        .join(external_variables_df, on="variable", how="inner")
        .filter(F.col("primary_metric") == "Y")
        .withColumnRenamed("week_start_date", "date")
    )

    # Separate External and Internal Data
    external_ads_df = baseline_modelling_df.filter(F.col("marketing_type") == "EXTERNAL")
    non_external_ads_df = baseline_modelling_df.filter(F.col("marketing_type") != "EXTERNAL")

    return external_ads_df, non_external_ads_df


def dataset_preprocessing(
    input_df_y: DataFrame,
    external_vars_df: DataFrame,
    non_external_vars_df: DataFrame,
    cluster_df: DataFrame
) -> Tuple[List[str], DataFrame, DataFrame, DataFrame]:
    """
    Preprocesses datasets for feature prioritization by scaling, pivoting, and filtering data.

    Objective:
        This function prepares the input datasets for modeling by applying preprocessing steps such as:
        - Filtering clusters based on valid grouping keys.
        - Pivoting external variables and dependent variables for correlation and modelling.
        - Scaling independent and dependent variables.
        - Generating a correlation matrix for feature prioritization.

    Args:
        input_df_y (DataFrame): Contains dependent variable (Y values) with cluster information.
        external_vars_df (DataFrame): External variables (independent variables) dataset.
        non_external_vars_df (DataFrame): Non-external variables dataset.
        cluster_df (DataFrame): Filtered modeling cluster keys.

    Returns:
        Tuple containing:
            - List of dependent variable names (clusters).
            - Normalized full input DataFrame (independent and dependent variables combined).
            - Normalized non-external variables DataFrame.
            - Correlation matrix DataFrame.
    """
    print("Starting preprocessing...")

    # Add group_key column to input_df_y for joins
    input_df_y = input_df_y.withColumn(
        "group_key",
        F.concat_ws("~", "unique_brand", "super_category_name", "final_cluster")
    )

    # Filter to valid clusters
    input_df_y = input_df_y.join(
        cluster_df,
        input_df_y["group_key"] == cluster_df["modelling_cluster_list"],
        how="left_semi"
    )

    # Drop unnecessary brand columns from external vars
    external_vars_df = external_vars_df.drop("unique_brand", "super_category_name")

    # Pivot external variables by date
    input_df_x = (
        external_vars_df
        .withColumn("date", F.to_date("date"))
        .groupBy("date")
        .pivot("variable")
        .sum("value")
    )

    # Ensure dates are properly typed
    input_df_y = input_df_y.withColumn("week_start_date", F.to_date("week_start_date"))
    non_external_vars_df = non_external_vars_df.withColumn("date", F.to_date("date"))

    # Add group_key to non-external vars
    non_external_vars_df = non_external_vars_df.withColumn(
        "group_key",
        F.concat_ws("~", "unique_brand", "super_category_name", "cluster")
    )

    # Collect unique dependent variable names (cluster IDs), this will always be small so collect is fine
    list_of_dependent_vars = [
        row["final_cluster"]
        for row in input_df_y.select("final_cluster").distinct().collect()
    ]

    # Pivot Y values for correlation and modelling
    input_df_y_pivot = (
        input_df_y
        .groupBy("week_start_date", "group_key")
        .pivot("final_cluster")
        .agg(F.first("feature_prioritization_y"))
    )

    # Prepare data for correlation calculation
    corr_df = (
        input_df_x
        .join(input_df_y_pivot, input_df_x["date"] == input_df_y_pivot["week_start_date"], how="left")
        .drop("date", "week_start_date")
    )

    # Correlation processor
    processor = create_correlation_processor(list_of_dependent_vars, FeaturePrioritisation.correlation_schema)
    corr_df = processor(corr_df)
    corr_df = corr_df.filter(F.col("correlation").isNotNull())

    # Merge X and Y again for modeling
    input_df = (
        input_df_x
        .join(input_df_y_pivot, input_df_x["date"] == input_df_y_pivot["week_start_date"], how="inner")
        .drop("week_start_date")
    )

    # Melt to long format: date | group_key | variable | value
    input_df_melted = melt_dataframe(input_df)

    # Split by dependent/independent
    input_df_independent = input_df_melted.filter(~F.col("variable").isin(list_of_dependent_vars))
    input_df_dependent = input_df_melted.filter(F.col("variable").isin(list_of_dependent_vars))

    # Scale both dependent/independent vars
    input_df_independent_scaled = apply_min_max_scaling(
        input_df_independent, ["group_key", "variable"], value_col="value"
    )
    input_df_dependent_scaled = apply_min_max_scaling(
        input_df_dependent, ["group_key", "variable"], value_col="value"
    )
    non_external_vars_scaled = apply_min_max_scaling(
        non_external_vars_df, ["group_key", "variable"], value_col="value"
    )

    # Combine features into one Dataset
    input_df_final = input_df_independent_scaled.unionByName(input_df_dependent_scaled)
    input_df_final = input_df_final.filter(F.col("value").isNotNull())

    print("Completed global preprocessing.")

    return (
        list_of_dependent_vars,
        input_df_final,
        non_external_vars_scaled,
        corr_df
    )
