from pyspark.sql import DataFrame, functions as F
from pyspark.sql.window import Window


def fp_data_post_processing(results_df: DataFrame) -> DataFrame:
    """
    Post-processes feature prioritization results for final output.

    - Standardizes column names (strips spaces).
    - Removes any rows related to 'festive' features.
    - Renames 'CLUSTER' to 'FINAL_CLUSTER' if present.
    - Recomputes FINAL_RANK using row_number per group_key.

    Args:
        results_df (DataFrame): Spark DataFrame with feature prioritization results.

    Returns:
        DataFrame: cleaned and processed Spark DataFrame.
    """

    # Standardize column names
    for col in results_df.columns:
        # I've removed the upper() call to keep the original case
        new_col = col.strip().replace(" ", "_")
        results_df = results_df.withColumnRenamed(col, new_col)

    # Remove rows where FEATURE contains 'festive'
    results_df = results_df.filter(~F.col("feature").contains("festive"))

    # Rename CLUSTER to FINAL_CLUSTER if present
    if "cluster" in results_df.columns:
        results_df = results_df.withColumnRenamed("cluster", "final_cluster")

    # Recalculate FINAL_RANK using row_number per group
    window_spec = Window.partitionBy("group_key").orderBy("final_rank")
    results_df = results_df.withColumn("final_rank", F.row_number().over(window_spec))

    return results_df


def fp_final_output(fp_result_df: DataFrame, master: DataFrame) -> DataFrame:
    """
    Formats feature prioritization results to match pipeline output schema.

    - Deduplicates and renames master metadata columns for join.
    - Selects and renames relevant columns in FP results.
    - Adds placeholder JOB_RUN_ID column.
    - Joins FP results with master metadata to enrich variables.
    - Applies hierarchy logic via a user-defined function.
    - Normalizes VARIABLE_CD casing before and after hierarchy fix.

    Args:
        fp_result_df (DataFrame): Feature prioritization results (PySpark DataFrame).
        master (DataFrame): Metadata DataFrame with modeling variables.
        fix_control_variable_hierarchy (function): Function applying hierarchy logic on the joined DataFrame.

    Returns:
        DataFrame: Final formatted DataFrame with enriched ADS hierarchy fields.
    """

    # Deduplicate and rename columns in master metadata for clarity and join keys
    master_renamed = (
        master.select(
            "variable",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "metric"
        )
        .dropDuplicates()
        .withColumnRenamed("variable", "variable_cd")
        .withColumnRenamed("marketing_type", "marketing_type_name")
        .withColumnRenamed("marketing_channel", "marketing_channel_name")
        .withColumnRenamed("marketing_sub_channel", "marketing_sub_channel_name")
        .withColumnRenamed("metric", "metric_name")
    )

    fp_result_df = (
        fp_result_df
        .withColumn(
            "unique_brand_name", F.split(F.col("group_key"), "~").getItem(0)
        )
        .withColumn(
            "super_category_name", F.split(F.col("group_key"), "~").getItem(1)
        )
        .withColumn(
            "final_cluster", F.split(F.col("group_key"), "~").getItem(2)
        )
        .drop("group_key")
    )

    # Select only relevant columns from FP results and fix missing comma
    fp_selected = fp_result_df.select(
        "super_category_name",
        "unique_brand_name",
        "final_cluster",
        "feature",
        "final_rank"
    )

    # Rename columns for pipeline output consistency
    fp_renamed = (
        fp_selected
        .withColumnRenamed("final_rank", "variable_importance_rank")
        .withColumnRenamed("feature", "variable_cd")
        .withColumnRenamed("final_cluster", "cluster_num")
    )

    # Join FP results with master metadata on VARIABLE_CD for enrichment
    joined_df = fp_renamed.join(master_renamed, on="variable_cd", how="left")

    # Normalize VARIABLE_CD to lowercase before applying hierarchy fix function
    joined_df = joined_df.withColumn("variable_cd", F.lower(F.col("variable_cd")))

    # Apply user-defined hierarchy correction logic on joined DataFrame
    joined_df = fix_control_variable_hierarchy(joined_df)

    # Restore VARIABLE_CD casing to uppercase for final output consistency
    joined_df = joined_df.withColumn("variable_cd", F.upper(F.col("variable_cd")))

    return joined_df


def fix_control_variable_hierarchy(df: DataFrame) -> DataFrame:
    """
    Updates ADS hierarchy columns for control variables in the DataFrame.

    Marks specific control variables with standardized labels for marketing hierarchy fields.

    Args:
        df (DataFrame): Input DataFrame with VARIABLE_CD and hierarchy columns.

    Returns:
        DataFrame: Updated DataFrame with adjusted hierarchy values for control variables.
    """
    # ToDo adding these to the variables.py file
    # Define labels for control variable groups
    STD_DEV_DUMMY = 'STD DEV DUMMY'
    SEASONALITY_INDEX = 'SEASONALITY INDEX'
    WEEK_START_DUMMY = 'WEEK START DUMMY'

    # Static control variables mapped to their labels
    static_control_vars = {
        'nec_xxx_xxx_xxx_xxx_pea_dum': STD_DEV_DUMMY,
        'nec_xxx_xxx_xxx_xxx_dip_dum': STD_DEV_DUMMY,
        'nec_xxx_xxx_xxx_sea_pea_dum': SEASONALITY_INDEX,
        'nec_xxx_xxx_xxx_sea_dip_dum': SEASONALITY_INDEX,
    }

    # Dynamic control variables for week start dummy (nec_xxx_xxx_xxx_xxx_pe1_dum ... pe4_dum)
    dynamic_week_start_vars = {f'nec_xxx_xxx_xxx_xxx_pe{i}_dum' for i in range(1, 5)}

    # Apply static control variable labels
    for label in {STD_DEV_DUMMY, SEASONALITY_INDEX}:
        vars_for_label = [var for var, lab in static_control_vars.items() if lab == label]
        df = df.withColumn(
            "marketing_type_name",
            F.when(F.col("variable_cd").isin(vars_for_label), label).otherwise(F.col("marketing_type_name"))
        ).withColumn(
            "marketing_channel_name",
            F.when(F.col("variable_cd").isin(vars_for_label), label).otherwise(F.col("marketing_channel_name"))
        ).withColumn(
            "marketing_sub_channel_name",
            F.when(F.col("variable_cd").isin(vars_for_label), "TOTAL").otherwise(F.col("marketing_sub_channel_name"))
        ).withColumn(
            "metric_name",
            F.when(F.col("variable_cd").isin(vars_for_label), label).otherwise(F.col("metric_name"))
        )

    df = df.withColumn(
        "marketing_type_name",
        F.when(F.col("variable_cd").isin(dynamic_week_start_vars), WEEK_START_DUMMY).otherwise(F.col("marketing_type_name"))
    ).withColumn(
        "marketing_channel_name",
        F.when(F.col("variable_cd").isin(dynamic_week_start_vars), WEEK_START_DUMMY).otherwise(F.col("marketing_channel_name"))
    ).withColumn(
        "marketing_sub_channel_name",
        F.when(F.col("variable_cd").isin(dynamic_week_start_vars), "TOTAL").otherwise(F.col("marketing_sub_channel_name"))
    ).withColumn(
        "metric_name",
        F.when(F.col("variable_cd").isin(dynamic_week_start_vars), WEEK_START_DUMMY).otherwise(F.col("metric_name"))
    )

    return df
