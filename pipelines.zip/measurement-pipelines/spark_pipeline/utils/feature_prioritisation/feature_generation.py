from pyspark.sql import DataFrame, Window, functions as F
from pyspark.sql import types as T
from spark_pipeline.common.variables import FeaturePrioritisationConfig


# ToDo This function produces slight differences in the output compared to the original function.
# Which seem to affect the random forest model output slightly but not the others
def seasonality_index_creator(master: DataFrame, fp_config: FeaturePrioritisationConfig) -> DataFrame:
    """
    Identifies recurring peaks and dips in sales due to seasonality by comparing
    week-over-week percentage changes with the same period in future years.

    Args:
        master (DataFrame): Input DataFrame with sales data

    Returns:
        DataFrame: Long-format DataFrame with seasonality dummy variables and modelling metadata
    """
    group_cols = ["unique_brand", "super_category_name", "cluster"]
    w = Window.partitionBy(*group_cols).orderBy("week_date")

    # Compute week-over-week percent change in sales
    master = master.withColumn(
        "sales_pct_change",
        (F.col("value") - F.lag("value", 1).over(w)) / F.lag("value", 1).over(w)
    ).fillna({"sales_pct_change": 0})

    window_length = fp_config.seasonality_index_window_length
    min_threshold = fp_config.seasonality_index_min_threshold
    threshold_2 = fp_config.seasonality_index_strict_threshold

    # Compare each change to similar weeks (3 week window) ~1 year later
    for i in range(window_length):
        shifted = F.lead("sales_pct_change", 51 + i).over(w)
        shifted_col = f"shifted_value_{i}"
        diff_col = f"shifted_valuediff_{i}"

        # Apply filter conditions

        # Ignore small changes
        condition_1 = F.when(
            (F.abs(shifted) < min_threshold) | (F.abs(F.col("sales_pct_change")) < min_threshold),
            F.lit(None)
        ).otherwise(shifted)
        # Ignore changes that are in opposite direction
        condition_2 = F.when(
            ((condition_1 < 0) & (F.col("sales_pct_change") > 0)) |
            ((condition_1 > 0) & (F.col("sales_pct_change") < 0)),
            F.lit(None)
        ).otherwise(condition_1)

        filtered = F.when(
            (F.abs(condition_2) < threshold_2) & (F.abs(F.col("sales_pct_change")) < threshold_2),
            F.lit(None)
        ).otherwise(condition_2)

        # Store filtered values and calculate difference with current week
        master = master.withColumn(shifted_col, filtered)
        master = master.withColumn(diff_col, F.abs(F.col("sales_pct_change") - F.col(shifted_col)))

    # Identify which shifted comparison was most similar
    diff_cols = [f"shifted_valuediff_{i}" for i in range(window_length)]

    master = master.withColumn(
        "min_column_idx",
        F.expr(f"array_position(array({','.join(diff_cols)}), array_min(array({','.join(diff_cols)}))) - 1")
    )
    master = master.withColumn(
        "min_column",
        F.when(F.col("min_column_idx") >= 0, F.col("min_column_idx").cast("string"))
    )
    # Flag seasonal peaks and dips
    master = master.withColumn(
        "seasonality_index_pea",
        F.when((F.col("sales_pct_change") > min_threshold) & F.col("min_column").isNotNull(), 1).otherwise(0)
    )
    master = master.withColumn(
        "seasonality_index_dip",
        F.when((F.col("sales_pct_change") < -min_threshold) & F.col("min_column").isNotNull(), 1).otherwise(0)
    )

    # Project seasonal pattern flags to future dates
    projected = (
        master
        .filter(F.col("min_column").isNotNull())
        .withColumn("min_column_int", F.col("min_column").cast("int"))
        .withColumn("future_date", F.expr("date_add(week_date, 7 * (51 + min_column_int))"))
    )

    pea_dates = (
        projected
        .filter(F.col("seasonality_index_pea") == 1)
        .select(
            *group_cols,
            F.col("future_date").alias("week_date"),
            F.lit(1).alias("future_pea")
        )
    )

    dip_dates = (
        projected
        .filter(F.col("seasonality_index_dip") == 1)
        .select(
            *group_cols,
            F.col("future_date").alias("week_date"),
            F.lit(1).alias("future_dip")
        )
    )

    # Join back projected patterns to original DataFrame
    master = (
        master
        .join(pea_dates, on=group_cols + ["week_date"], how="left")
        .join(dip_dates, on=group_cols + ["week_date"], how="left")
        .withColumn(
            "seasonality_index_pea",
            F.when(F.col("future_pea") == 1, 1).otherwise(F.col("seasonality_index_pea"))
        ).withColumn(
            "seasonality_index_dip",
            F.when(F.col("future_dip") == 1, 1).otherwise(F.col("seasonality_index_dip"))
        )
    )
    # Select relevant columns for the stack function
    out_cols = ["week_date", *group_cols, "seasonality_index_pea", "seasonality_index_dip"]
    master = master.select(*out_cols)

    # Convert to long format with variable and value columns
    master = master.selectExpr(
        "week_date", *group_cols,
        "stack(2, 'seasonality_index_pea', seasonality_index_pea, 'seasonality_index_dip', seasonality_index_dip) as (variable, value)"
    )
    # Add meta-data to the baseline modelling dataset
    master = (
        master
        .withColumn("marketing_type", F.lit(fp_config.seasonality_index_name))
        .withColumn("marketing_channel", F.lit(fp_config.seasonality_index_name))
        .withColumn("marketing_sub_channel", F.lit(fp_config.seasonality_index_name))
        .withColumn("metric", F.lit(fp_config.seasonality_index_name))
        .withColumn("primary_metric", F.lit(fp_config.seasonality_primary_metric))
        .withColumn("investment_metric", F.lit(fp_config.seasonality_investment_metric))
    )

    # Rename variables
    master = master.withColumn(
        "variable",
        F.when(F.col("variable") == "seasonality_index_pea", fp_config.seasonality_index_pea_name)
         .when(F.col("variable") == "seasonality_index_dip", fp_config.seasonality_index_dip_name)
         .otherwise(F.col("variable"))
    )
    # Remove all-zero variables per group
    non_zero_vars = (
        master
        .groupBy("unique_brand", "super_category_name", "cluster", "variable")
        .agg(F.max(F.when(F.col("value") != 0, 1).otherwise(0)).alias("has_nonzero"))
        .filter(F.col("has_nonzero") == 1)
        .select("unique_brand", "super_category_name", "cluster", "variable")
    )

    master = master.join(
        non_zero_vars,
        on=["unique_brand", "super_category_name", "cluster", "variable"],
        how="inner"
    )
    return master


def std_dev_control_creator_all(sales_ads: DataFrame, fp_config: FeaturePrioritisationConfig) -> DataFrame:
    """
    Create standard deviation-based peak and dip dummy variables by group.

    Args:
        sales_ads (DataFrame): weekly sales-level with brand, category, and cluster dimensions.

    Returns:
        DataFrame: Long-format DataFrame with peak and dip dummies for ML modeling
    """

    baseline_modelling_dataset = sales_ads.withColumnRenamed("value", fp_config.dependent_variable)

    baseline_modelling_dataset = identify_peaks_and_dips_std_by_group(
        df=baseline_modelling_dataset,
        column_name=fp_config.dependent_variable,
        peak_dummy_name=fp_config.peak_dummy_name,
        dip_dummy_name=fp_config.dip_dummy_name,
        ucm_pass_no=fp_config.ucm_pass_no,
        group_cols=["unique_brand", "super_category_name", "cluster"]
    )

    # Convert to long format with variable and value columns
    base_cols = ["week_date", "super_category_name", "unique_brand", "cluster"]
    baseline_modelling_dataset = baseline_modelling_dataset.selectExpr(
        *base_cols,
        f"stack(2, '{fp_config.peak_dummy_name}', {fp_config.peak_dummy_name}, '{fp_config.dip_dummy_name}', {fp_config.dip_dummy_name}) as (variable, value)"
    )

    # Add meta-data to the baseline modelling dataset
    job_id = sales_ads.select("job_id").first()["job_id"]
    load_ts = sales_ads.select("load_ts").first()["load_ts"]

    baseline_modelling_dataset = (
        baseline_modelling_dataset
        .withColumn("marketing_type", F.lit(fp_config.std_dev_control_index_name))
        .withColumn("marketing_channel", F.lit(fp_config.std_dev_control_index_name))
        .withColumn("marketing_sub_channel", F.lit(fp_config.std_dev_control_index_name))
        .withColumn("metric", F.lit(fp_config.std_dev_control_index_name))
        .withColumn("primary_metric", F.lit(fp_config.std_dev_primary_metric))
        .withColumn("investment_metric", F.lit(fp_config.std_dev_investment_metric))
        .withColumn("job_id", F.lit(job_id))
        .withColumn("load_ts", F.lit(load_ts))
    )

    # Group by both the grouping columns AND variable to filter within each group
    non_zero_vars = (
        baseline_modelling_dataset.groupBy("unique_brand", "super_category_name", "cluster", "variable")
        .agg(F.max(F.abs(F.col("value"))).alias("max_abs_val"))
        .filter(F.col("max_abs_val") > 0)
        .select("unique_brand", "super_category_name", "cluster", "variable")  # Include all join keys
    )

    # Join back using all the grouping columns + variable
    final = baseline_modelling_dataset.join(
        non_zero_vars,
        on=["unique_brand", "super_category_name", "cluster", "variable"],
        how="inner"
    )

    return final


def week_start_control_creator_all(sales_ads: DataFrame, fp_config: FeaturePrioritisationConfig) -> DataFrame:
    """
    Create dummy variables for the start of each week in the month,
    vectorized across the full DataFrame

    Args:
        sales_ads (DataFrame): Input DataFrame with 'week_date', 'job_id', 'load_ts',
                               and other identifying columns.

    Returns:
        DataFrame: Long-format DataFrame with week start dummy variables.
    """
    # Check for empty DataFrame
    if not sales_ads.count() > 0:
        schema = T.StructType([
            T.StructField("week_date", T.DateType()),
            T.StructField("super_category_name", T.StringType()),
            T.StructField("unique_brand", T.StringType()),
            T.StructField("cluster", T.StringType()),
            T.StructField("variable", T.StringType()),
            T.StructField("value", T.IntegerType()),
            T.StructField("marketing_type", T.StringType()),
            T.StructField("marketing_channel", T.StringType()),
            T.StructField("marketing_sub_channel", T.StringType()),
            T.StructField("metric", T.StringType()),
            T.StructField("primary_metric", T.StringType()),
            T.StructField("investment_metric", T.StringType()),
            T.StructField("job_id", T.StringType()),
            T.StructField("load_ts", T.TimestampType()),
        ])
        return sales_ads.sparkSession.createDataFrame([], schema)

    df = sales_ads.withColumn(
        "week_of_month", ((F.dayofmonth("week_date") - 1) / 7 + 1).cast("int")
    )

    # One hot encode week_of_month into 4 dummy variables
    for i in range(1, 5):
        col_name = f"nec_xxx_xxx_xxx_xxx_pe{i}_dum"
        df = df.withColumn(col_name, F.when(F.col("week_of_month") == i, 1).otherwise(0))

    # Convert to long format with variable and value columns
    base_cols = ["week_date", "super_category_name", "unique_brand", "cluster"]
    stack_expr = ", ".join([
        f"'nec_xxx_xxx_xxx_xxx_pe{i}_dum', nec_xxx_xxx_xxx_xxx_pe{i}_dum" for i in range(1, 5)
    ])
    df = df.selectExpr(*base_cols, f"stack(4, {stack_expr}) as (variable, value)")

    # Extract metadata
    job_id = sales_ads.select("job_id").first()["job_id"]
    load_ts = sales_ads.select("load_ts").first()["load_ts"]

    # Add metadata columns
    meta_values = {
        "marketing_type": fp_config.week_start_control_index_name,
        "marketing_channel": fp_config.week_start_control_index_name,
        "marketing_sub_channel": fp_config.week_start_control_index_name,
        "metric": fp_config.week_start_control_index_name,
        "primary_metric": fp_config.week_start_primary_metric,
        "investment_metric": fp_config.week_start_investment_metric,
        "job_id": job_id,
        "load_ts": load_ts
    }

    for k, v in meta_values.items():
        df = df.withColumn(k, F.lit(v))

    return df


def identify_peaks_and_dips_std_by_group(
    df: DataFrame,
    column_name: str,
    peak_dummy_name: str,
    dip_dummy_name: str,
    ucm_pass_no: str,
    group_cols: list
) -> DataFrame:
    """
    Identifies peaks and dips in grouped time series using group-level mean and std deviation.

    Args:
        df (DataFrame): Input DataFrame
        column_name (str): Column to analyze
        peak_dummy_name (str): Output peak flag column
        dip_dummy_name (str): Output dip flag column
        ucm_pass_no (str): Threshold set (e.g., 'set_3' uses 2.5)
        group_cols (list): Columns to group by for mean/std calc

    Returns:
        DataFrame: With peak/dip flags added
    """
    threshold = 2.5 if ucm_pass_no == 'set_3' else 2.0

    group_window = Window.partitionBy(*group_cols)

    df = df.withColumn("mean_val", F.mean(column_name).over(group_window))
    df = df.withColumn("std_val", F.stddev(column_name).over(group_window))

    df = (
        df
        .withColumn(
            peak_dummy_name,
            F.when(F.col(column_name) > F.col("mean_val") + threshold * F.col("std_val"), F.lit(1)).otherwise(F.lit(0))
        )
        .withColumn(
            dip_dummy_name,
            F.when(F.col(column_name) < F.col("mean_val") - threshold * F.col("std_val"), F.lit(1)).otherwise(F.lit(0))
        )
    )

    return df.drop("mean_val", "std_val")


def list_independent_ext_factors(df: DataFrame, fp_config) -> DataFrame:
    """
    Gets a DataFrame of distinct external variable names
    (lowercase), based on marketing type and metric filters from fp_config.

    Args:
        df (DataFrame): The input dataset.
        fp_config: Config dictionary with FP inputs.

    Returns:
        DataFrame: Distinct lowercase variable names as a single-column Spark DataFrame.
    """
    ext_marketing_types = set(x.lower() for x in fp_config.external_marketing_type_names)
    ext_metrics = set(x.lower() for x in fp_config.external_metric)

    # Filter by marketing type (case-insensitive)
    by_type = df.filter(
        F.lower(F.col("marketing_type")).isin(ext_marketing_types)
    ).select(F.lower(F.col("variable")).alias("variable")).distinct()

    # Filter by metric name (case-insensitive)
    by_metric = df.filter(
        F.lower(F.col("metric")).isin(ext_metrics)
    ).select(F.lower(F.col("variable")).alias("variable")).distinct()

    # Union results and return distinct lowercase variable names
    return by_type.union(by_metric).distinct()


def melt_dataframe(df: DataFrame) -> DataFrame:
    """Convert wide format to long format (melt operation)"""
    value_cols = [col for col in df.columns if col != "date" and col != "group_key"]

    melt_expr = "stack({}, {}) as (variable, value)".format(
        len(value_cols),
        ", ".join(["'{}', {}".format(col, col) for col in value_cols])
    )

    melted_df = df.select("date", "group_key", F.expr(melt_expr))
    return melted_df
