from typing import List, Callable, Tuple

import pandas as pd
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StructType
from pyspark.sql.window import Window

from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LassoCV
from xgboost import XGBRegressor

import numpy as np
from sklearn.metrics import (
    mean_absolute_error,
    mean_absolute_percentage_error,
    r2_score,
)

from spark_pipeline.common.variables import FeaturePrioritisationConfig


def create_correlation_processor(
        list_of_dependent_vars: List[str],
        correlation_schema: StructType
) -> Callable[[DataFrame], DataFrame]:

    def process_group(pdf: pd.DataFrame) -> pd.DataFrame:
        """
        Processes correlations with the given dependent variables
        """
        # Extract the group key so it's not part of the correlation calculation
        group_key = pdf["group_key"].iloc[0]
        data_for_corr = pdf.drop(columns=["group_key"])

        corr_matrix = data_for_corr.corr(method="pearson")
        corr_df = corr_matrix[list_of_dependent_vars].drop(index=list_of_dependent_vars)
        corr_df = corr_df.reset_index(names="feature")
        corr_df = pd.melt(
            corr_df,
            id_vars="feature",
            var_name="cluster",
            value_vars=list_of_dependent_vars,
            value_name="correlation"
        )
        corr_df["group_key"] = group_key
        return corr_df

    def apply_func(df: DataFrame) -> DataFrame:
        return df.groupBy("group_key").applyInPandas(process_group, schema=correlation_schema)

    return apply_func


def apply_min_max_scaling(
        df: DataFrame,
        group_cols: List[str],
        value_col: str = "VALUE",
        feature_range: Tuple[float, float] = (0.0, 1.0)
) -> DataFrame:
    """
    Apply Min-Max scaling to a value column within each group.

    This transformation scales each value in value_col to a specified range
    (default [0, 1]) based on the group's min and max values.

    (Based on sklearn's implementation of MinMaxScaler)

    Formula:
        X_scaled = ((X - X_min) / (X_max - X_min)) * (max - min) + min

    Args:
        df (DataFrame): Input Spark DataFrame.
        group_cols (list or str): Columns to group by when computing min/max.
        value_col (str): Column to scale. Defaults to "VALUE".
        feature_range (tuple): Desired value range after scaling. Defaults to (0.0, 1.0).

    Returns:
        DataFrame: Spark DataFrame with the scaled value column.
    """
    min_val, max_val = feature_range
    scale = max_val - min_val

    window_spec = Window.partitionBy(group_cols)

    df_scaled = (
        df
        .withColumn("min_val", F.min(value_col).over(window_spec))
        .withColumn("max_val", F.max(value_col).over(window_spec))
        .withColumn(
            value_col,
            F.when(F.col("max_val") == F.col("min_val"), F.lit(min_val))
            .otherwise(((F.col(value_col) - F.col("min_val")) / (F.col("max_val") - F.col("min_val"))) * scale + min_val)
        )
        .drop("min_val", "max_val")
    )

    return df_scaled


def feature_prioritization_ensemble(
    list_of_dependent_vars: List[str],
    input_df: DataFrame,
    non_external_vars_df_x: DataFrame,
    corr_df: DataFrame,
    model_schema: StructType,
    fp_config: FeaturePrioritisationConfig
) -> DataFrame:
    """
    Combines results from multiple ML models and correlation rankings
    into a final ranked feature list for each group.

    Args:
        list_of_dependent_vars (list): List of Y-variable names to exclude as features.
        input_df (DataFrame): DataFrame containing internal feature time series + group_key.
        non_external_vars_df_x (DataFrame): DataFrame with external variables.
        corr_df (DataFrame): Precomputed correlation scores for each feature.
        fp_config (class): Data class containning of weights for RF, XGB, and Lasso ranks and model params

    Returns:
        DataFrame: Final combined and ranked output with Calculated_Rank and Final_Rank.
    """
    # Extract weights for ensemble rank calculation
    rf_wt = fp_config.ensemble_config.rf_weight
    xgb_wt = fp_config.ensemble_config.xgb_weight
    lasso_wt = fp_config.ensemble_config.lasso_weight

    non_external_df_clean = (
        non_external_vars_df_x
        .orderBy("variable", "date")
        .select("date", "variable", "value", "group_key")
    )

    # Align schemas
    input_df_clean = input_df.select("date", "variable", "value", "group_key")

    # Union Internal + External features into final input
    df_final = input_df_clean.unionByName(non_external_df_clean)

    # Build UDF to run ML models
    run_models_udf = run_ml_models(list_of_dependent_vars, model_schema, fp_config)

    # Apply grouped ML UDF over group_key
    ml_results = run_models_udf(df_final)

    # Join ML ranks with correlation results
    combined_results = (
        ml_results.join(
            corr_df,
            on=["feature", "cluster", "group_key"],
            how="left"
        )
    )

    # Weighted ensemble rank calculation
    combined_results = combined_results.withColumn(
        "calculated_rank",
        (F.col("rf_rank") * rf_wt) +
        (F.col("xgb_rank") * xgb_wt) +
        (F.col("lasso_rank") * lasso_wt)
    )

    # Assign final rank per group using window
    window_spec = Window.partitionBy("group_key").orderBy(F.col("calculated_rank").asc())

    combined_results = combined_results.withColumn(
        "final_rank", F.row_number().over(window_spec)
    )

    return combined_results


def run_ml_models(
        list_of_dependent_vars: List[str],
        model_schema: StructType,
        fp_config: FeaturePrioritisationConfig
) -> Callable[[DataFrame], DataFrame]:

    def process_group(pdf: pd.DataFrame) -> pd.DataFrame:
        try:
            group_key = pdf["group_key"].iloc[0]
            dependant_variable = group_key.split("~")[2]
            data_model = pdf.drop(columns=["group_key"])

            # Pivot to a wide format for ml modelling
            inputs = data_model.pivot_table(
                index="date", columns="variable", values="value", aggfunc="first"
            )
            # Separate features and target variable
            X = inputs.drop(columns=list_of_dependent_vars, errors="ignore")
            y = inputs[dependant_variable]

            # Drop rows with NaN in target variable
            valid_rows = y.notna()
            X = X[valid_rows]
            y = y[valid_rows]

            # Ensure consistent column order
            feature_cols = list(X.columns)

            # Return empty DataFrame if no features are available
            if X.empty or not feature_cols:
                return pd.DataFrame([])

            results = {}

            try:
                rf = RandomForestRegressor(
                    random_state=fp_config.ensemble_config.random_forest_random_state,
                    n_estimators=fp_config.ensemble_config.random_forest_n_estimators,
                    max_depth=fp_config.ensemble_config.random_forest_max_depth,
                )
                rf.fit(X, y)
                rf_pred = rf.predict(X)
                results["rf_importance"] = rf.feature_importances_
                results["rf_mae"] = mean_absolute_error(y, rf_pred)
                results["rf_mape"] = mean_absolute_percentage_error(y, rf_pred)
                results["rf_r2"] = r2_score(y, rf_pred)
            except Exception:
                results["rf_importance"] = np.zeros(len(feature_cols))
                results["rf_mae"] = results["rf_mape"] = results["rf_r2"] = 0.0

            try:
                xgb = XGBRegressor(
                    random_state=fp_config.ensemble_config.xgboost_random_state,
                    n_estimators=fp_config.ensemble_config.xgboost_n_estimators,
                    max_depth=fp_config.ensemble_config.xgboost_max_depth,
                )
                xgb.fit(X, y)
                xgb_pred = xgb.predict(X)
                results["xgb_importance"] = xgb.feature_importances_
                results["xgb_mae"] = mean_absolute_error(y, xgb_pred)
                results["xgb_mape"] = mean_absolute_percentage_error(y, xgb_pred)
                results["xgb_r2"] = r2_score(y, xgb_pred)
            except Exception:
                results["xgb_importance"] = np.zeros(len(feature_cols))
                results["xgb_mae"] = results["xgb_mape"] = results["xgb_r2"] = 0.0

            try:
                lasso = LassoCV(
                    cv=fp_config.ensemble_config.lasso_cross_validation_k_fold,
                    random_state=fp_config.ensemble_config.lasso_random_state,
                )
                lasso.fit(X, y)
                lasso_pred = lasso.predict(X)
                results["lasso_importance"] = np.abs(lasso.coef_)
                results["lasso_mae"] = mean_absolute_error(y, lasso_pred)
                results["lasso_mape"] = mean_absolute_percentage_error(y, lasso_pred)
                results["lasso_r2"] = r2_score(y, lasso_pred)
            except Exception:
                results["lasso_importance"] = np.zeros(len(feature_cols))
                results["lasso_mae"] = results["lasso_mape"] = results["lasso_r2"] = 0.0

            df_out = pd.DataFrame({
                "feature": feature_cols,
                "rf_importance": results["rf_importance"],
                "xgb_importance": results["xgb_importance"],
                "lasso_importance": results["lasso_importance"],
                "rf_mae": results["rf_mae"],
                "rf_mape": results["rf_mape"],
                "rf_r2": results["rf_r2"],
                "xgb_mae": results["xgb_mae"],
                "xgb_mape": results["xgb_mape"],
                "xgb_r2": results["xgb_r2"],
                "lasso_mae": results["lasso_mae"],
                "lasso_mape": results["lasso_mape"],
                "lasso_r2": results["lasso_r2"]
            })

            df_out["rf_rank"] = df_out["rf_importance"].rank(ascending=False, method="max").astype(int)
            df_out["xgb_rank"] = df_out["xgb_importance"].rank(ascending=False, method="max").astype(int)
            df_out["lasso_rank"] = df_out["lasso_importance"].rank(ascending=False, method="max").astype(int)
            df_out["cluster"] = dependant_variable
            df_out["group_key"] = group_key

            return df_out

        except Exception as e:
            return pd.DataFrame([{
                "feature": f"Error: {str(e)}",
                "rf_importance": -999,
                "rf_rank": -1,
                "xgb_importance": -999,
                "xgb_rank": -1,
                "lasso_importance": -999,
                "lasso_rank": -1,
                "rf_mae": -1,
                "rf_mape": -1,
                "rf_r2": -1,
                "xgb_mae": -1,
                "xgb_mape": -1,
                "xgb_r2": -1,
                "lasso_mae": -1,
                "lasso_mape": -1,
                "lasso_r2": -1,
                "cluster": None,
                "group_key": pdf["group_key"].iloc[0] if "group_key" in pdf else None
            }])

    def apply_func(df: DataFrame) -> DataFrame:
        return df.groupBy("group_key").applyInPandas(process_group, schema=model_schema)

    return apply_func
