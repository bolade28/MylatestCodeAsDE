from dataclasses import dataclass, field
from datetime import date
from enum import Enum, StrEnum
from typing import Dict, List, Optional

dbt_config = {
    "new_launch_feature_columns": ["TOTAL_SALES_AMT", "PRICE_PER_POINT", "PACK_SIZE", "AVG_PURCHASE_PER_CUSTOMER_CNT",
                                   "ONLINE_SALES_PCT", "SUPERMARKET_SALES_PCT", "CONVENIENCE_SALES_PCT"],
    "new_launch_recency_wt": 0.5,
    "new_launch_sales_prop_wt": 0.3,
    "new_launch_feature_distance_wt": 0.2,
    "clust_sales_threshold_for_sparsity": 80,
    "clust_sparsity_threshold": 70
}

UNTARGETED_CHANNELS = ['onsite-gol', 'in-store', 'magazine']  # List of channels that are not targeted for the model.
DTP_OFFSITE_CHANNELS = ['meta', 'youtube', 'dv360']  # List of offsite channels for DTP pipeline
META_STATIC_RECALIBRATION_FACTOR = 0.16  # Static recalibration factor used for legacy Meta bookings.
META_AA_EFFECTIVE_DATE = date(2026, 7, 27)
MODELLING_WEIGHT_ZERO_TOLERANCE = 1e-8  # Tolerance used to treat modelling_weight as effectively zero.
NUM_USER_JOURNEY_PARTITIONS = 500
HISTORICAL_LOOKBACK_WEEKS = 104  # Lookback window in weeks for historical product/sales data in campaign metrics


@dataclass
class PipelineRunType():
    pollen_run_type: str = "Pollen"
    dtp_run_type: str = "DTP"


@dataclass
class EventType():
    campaign_selection: str = "Campaign Selection"
    brand_modelling_status: str = "Brand Modelling Status"
    refactoring: str = "Refactoring"
    pipeline_status_notification: str = "Pipeline Status Notification"
    sku_level_attributed_sales_and_units: str = "SKU Level Attributed Sales and Units"
    user_journey: str = "User Journey"
    new_launch_estimation: str = "New Launch Estimation"
    baseline_attribution_integration: str = "Baseline Attribution Integration"
    baseline_attribution_integration_sku_level: str = "Baseline Attribution Integration (SKU Level)"
    measurement_reporting: str = "Measurement Campaign Reporting"
    attribution_pre_requisite: str = "Attribution Pre-Requisite"
    sku_cluster_mapping: str = "SkuClusterMapping"


@dataclass
class RefactoringParameters():
    features_list: List[str] = field(default_factory=lambda: [
        'total_sales_amt',
        'avg_purchase_per_customer_cnt',
        'online_sales_pct',
        'supermarket_sales_pct',
        'convenience_sales_pct'
    ])

    feature_distance_wt: float = 0.50
    recency_wt: float = 0.50
    recency_threshold: float = 0.2


@dataclass
class EnsembleModelConfig:
    rf_weight: float = 0.3
    xgb_weight: float = 0.2
    lasso_weight: float = 0.5

    random_forest_random_state: int = 42
    random_forest_n_estimators: int = 1000
    random_forest_max_depth: int = 3

    xgboost_random_state: int = 42
    xgboost_n_estimators: int = 1000
    xgboost_max_depth: int = 3

    lasso_random_state: int = 0
    lasso_cross_validation_k_fold: int = 5


@dataclass
class FeaturePrioritisationConfig:
    external_marketing_type_names: List[str] = field(
        default_factory=lambda: [
            'EXTERNAL',
            'PROMOTIONAL DISCOUNT',
            'VALUE INDEX',
            'PLANOGRAM'])
    external_metric: List[str] = field(default_factory=lambda: ['BASE_UNIT_PRICE_AMT'])

    dependent_variable: str = "nec_sal_tot_xxx_xxx_xxx_sls"

    seasonality_index_name: str = 'SEASONAL_INDEX'
    seasonality_index_pea_name: str = "nec_xxx_xxx_xxx_sea_pea_dum"
    seasonality_index_dip_name: str = "nec_xxx_xxx_xxx_sea_dip_dum"
    seasonality_primary_metric: str = "Y"
    seasonality_investment_metric: str = "N"

    std_dev_control_index_name: str = 'STD_DEV_DUMMY'
    peak_dummy_name: str = "nec_xxx_xxx_xxx_xxx_pea_dum"
    dip_dummy_name: str = "nec_xxx_xxx_xxx_xxx_dip_dum"
    std_dev_primary_metric: str = "Y"
    std_dev_investment_metric: str = "N"

    week_start_control_index_name: str = 'WEEK_START_DUMMY'
    week_start_primary_metric: str = "Y"
    week_start_investment_metric: str = "N"

    seasonality_index_strict_threshold: float = 0.25
    seasonality_index_min_threshold: float = 0.1
    seasonality_index_window_length: int = 3

    ucm_pass_no: str = "set_1"
    std_dev_dummy_threshold: int = 2

    ensemble_config: EnsembleModelConfig = field(default_factory=EnsembleModelConfig)


@dataclass
class ForecastingConfig:
    """Configuration for baseline forecasting pipeline"""
    forecasting_train_share: float = 0.70
    forecasting_test_share: float = 0.30
    forecasting_wsmape_wt: float = 0.45
    forecasting_inc_diff_wt: float = 0.45
    forecasting_trend_flag_wt: float = 0.10


@dataclass
class AttributionPreRequisitesConfig:
    # List of variables used in the regression model, this is used in the attribution pre requisite scripts
    regression_variable_list: List[str] = field(default_factory=lambda: ['marketing_type', 'subchannel_name', 'campaign_id'])


@dataclass
class ConversionRateThresholdsConfig:
    """
    Configuration for conversion rate threshold validation.
    Defines maximum acceptable conversion rates by marketing type.
    Used to detect anomalous conversion rates and publish alerts to Grafana.
    Conversion rates are expressed as percentages (0-100).
    """

    # Maximum conversion rate thresholds by marketing type (percentage)
    offsite_max_threshold: float = 10.0
    offsite_min_threshold: float = 0.0

    onsite_max_threshold: float = 10.0
    onsite_min_threshold: float = 0.0

    instore_max_threshold: float = 30.0
    instore_min_threshold: float = 0.0

    # Listing the different variants of instore used in the codebase to ensure all are covered by the instore threshold
    instore_variants: List[str] = field(
        default_factory=lambda: ["instore", "in-store"]
    )

    def get_marketing_type_threshold(self, marketing_type: str) -> Optional[tuple]:
        """
        Gets the minimum and maximum conversion rate thresholds for a given marketing type.

        Args:
            marketing_type: Marketing type value (will be lowercased for comparison)

        Returns:
            Tuple of (min_threshold, max_threshold) as percentages, or None if the marketing type is not configured
        """
        marketing_type_lower = marketing_type.lower().strip()

        if marketing_type_lower in self.instore_variants:
            return (self.instore_min_threshold, self.instore_max_threshold)
        elif marketing_type_lower == "offsite":
            return (self.offsite_min_threshold, self.offsite_max_threshold)
        elif marketing_type_lower == "onsite":
            return (self.onsite_min_threshold, self.onsite_max_threshold)
        else:
            return None  # No threshold required


@dataclass
class RecalibrationFactorsConfig:
    """Configuration for offsite and non-offsite channel recalibration factors used in measurement campaign reporting."""
    meta_recalibration_factor: float = META_STATIC_RECALIBRATION_FACTOR
    non_offsite_recalibration_factor: float = 1.00
    # Validation thresholds for offsite channel recalibration factors
    offsite_recalibration_min_threshold: float = 0.00  # Exclusive minimum (must be > 0.00)
    offsite_recalibration_max_threshold: float = 1.00  # Inclusive maximum (must be <= 1.00)


@dataclass
class ChannelSalesRatioConfig:
    """Configuration for the ratio of ATTRIBUTED_RECALIBRATED_UNITS_QTY / CONVERSIONS_RECALIBRATED for how many units are bought per conversion"""
    higher_unit_ratio_warning: float = 4.0
    median_ratio_deviation_threshold: float = 0.30  # ±30% from median


@dataclass
class LowMediaSpendConfig:
    """Configuration for low media spend validation check."""
    low_spend_threshold: float = 50.0  # Threshold for low media spend in the campaign period


@dataclass
class IncrementalSalesIROASConfig:
    """Configuration for incremental sales and iROAS validation check."""
    low_incremental_sales_threshold: float = 0.0  # Threshold for low incremental sales in the campaign period
    low_iroas_threshold: float = 0.0  # Threshold for low iROAS in the campaign period
    high_iroas_threshold: float = 20.0  # Threshold for high iROAS in the campaign period


@dataclass
class AttributionModelResultConfig:
    """Configuration for attribution/classification training."""

    label_col: str = "isconversion"  # Binary conversion indicator column used across attribution modelling.

    # Version control
    use_bdv_version: bool = False

    # Core configuration
    schema: str = "ANALYTICS"
    regression_variable_list: List[str] = field(
        default_factory=lambda: AttributionPreRequisitesConfig().regression_variable_list
    )

    # Table names (for output)
    attribution_model_results_offer: str = "attribution_model_results_offer"
    synergy_values: str = "synergy_values"

    # Model hyperparameters
    test_size: float = 0.30
    n_bags: int = 1
    bal_ratio: float = 0.04
    f1_score_limit: float = 0.80
    high_conversion_bal_ratio: float = 0.50
    minimum_conversion_lower_limit: int = 50
    minimum_conversion_upper_limit: int = 1000
    balance_increment: float = 0.10
    balance_decrement_small: float = 0.002
    balance_decrement_large: float = 0.15
    balance_ratio_factor: float = 0.25
    random_state: int = 42
    solver: str = "lbfgs"
    max_iter: int = 1000
    max_executors: int = 5

    # Performance tuning
    max_parallel_campaigns: int = 10
    output_partitions: int = 200

    def __post_init__(self):
        """Adjust parameters based on version after initialization."""
        if self.use_bdv_version:
            # BDV version uses different values for these parameters
            self.solver = "auto"
            self.max_iter = 100


class Severity(str, Enum):
    """Alert severity levels for baseline validation events.

    HIGH   -- Immediate action required. Data quality issue that will likely impact modelling results.
    MEDIUM -- Investigate soon. Anomaly detected but may not directly break the model.
    LOW    -- Informational. Minor deviation worth monitoring but no immediate action needed.
    """
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class ProductType(Enum):
    """Product type enumeration."""
    OFFER = 'Offer'
    BRAND = 'Brand'
    AISLE = 'Aisle'


class EventName(Enum):
    """Customer event type enumeration used across pipeline and user journey logic."""
    TOUCHPOINT = 'touchpoint'
    TRANSACTION = 'transaction'


@dataclass
class BaselineAttributionIntegrationSKULevel:
    """Baseline attribution integration skel."""
    # Default 6 weeks; pre-camp must have 6 weeks of data, those 6 weeks of data is used to calculate pre-campaign sales proportions to be used for SKU-level attribution
    # Number of weeks before the campaign considered as pre-campaign period, this is used in calculating sales proportions (calculate_sales_proportion function)
    pre_campaign_weeks = 6  # TODO:: add this to global variables

    # Minimum sales threshold for pre-campaign period, this is used in calculating sales proportions (calculate_sales_proportion function)
    # Default 10%; pre-camp must have 10% of campaign sales for pre-campaign sales proportions to be used for SKU-level attribution
    min_pre_camp_sales_threshold = 0.1  # TODO:: add this to global variables


@dataclass
class UCMModelConfig:
    # APL parameters used to create apl features
    apl_ad: List[int] = field(default_factory=lambda: [0, 10, 20, 30])
    apl_pw: List[int] = field(default_factory=lambda: [80, 90, 100])
    apl_lg: List[int] = field(default_factory=lambda: [0, 1])

    # UCM model parameters (grid search over all combos)
    level_variance: List[str] = field(default_factory=lambda: ["0.05", "0.10", "0.15", "0.20", "0.25", "0.30", "0.35", "0.40", "0.45", "0.50"])
    seasonal: List[str] = field(default_factory=lambda: ["False"])
    cycle: List[str] = field(default_factory=lambda: ["True", "False"])
    cycle_period_bounds: List[List[int]] = field(default_factory=lambda: [[26, 104], [52, 104]])


@dataclass
class SpecialSKUFlaggingConfig:
    """Configuration for special SKU flagging in clustering."""
    # Christmas spike parameters
    christmas_spike_threshold: float = 0.8
    christmas_period_weeks_before: int = 8
    christmas_period_weeks_after: int = 2

    # Easter spike parameters
    easter_spike_threshold: float = 0.8
    easter_period_weeks_before: int = 2
    easter_period_weeks_after: int = 2

    # Discontinued SKU parameters
    discontinued_zero_sales_weeks_threshold: int = 12

    # Low selling SKU parameters
    low_selling_weekly_threshold: int = 20
    low_selling_window_num_weeks: int = 52
    low_selling_min_weeks_with_sales: int = 4


@dataclass
class BaselineModellingDataSetConfig:
    """Configuration for baseline modelling dataset generation."""
    post_period_clamped_marketing_types: List[str] = field(
        default_factory=lambda: [
            "INSTORE",
            "OFFSITE",
            "ECOUPON",
            "COUPON-AT-TILL",
            "ONSITE",
        ]
    )
    post_period_clamped_marketing_type_names: List[str] = field(
        default_factory=lambda: ["IN-STORE", "OFFSITE", "TARGETED MEDIA", "ONSITE"]
    )


@dataclass
class BaselineModellingOutputConfig:
    # Variable lists to seperate marketing, external and target features
    marketing_type_list: List[str] = field(default_factory=lambda: ['OFFSITE', 'ONSITE', 'TARGETED MEDIA', 'IN-STORE', 'PLANOGRAM'])
    external_marketing_type_names: List[str] = field(
        default_factory=lambda: ['EXTERNAL', 'PROMOTIONAL DISCOUNT', 'VALUE INDEX', 'PLANOGRAM'])
    external_metric: List[str] = field(default_factory=lambda: ['BASE_UNIT_PRICE_AMT'])
    negative_metric_name: List[str] = field(default_factory=lambda: ['BASE_UNIT_PRICE_AMT'])
    negative_marketing_variable_patterns: Dict[str, str] = field(
        default_factory=lambda: {'ons_ons_': 'onsite', 'ons_eco': 'ecoupon', 'in-_in-_': 'instore', 'off_met_': 'offsite', 'off_you_': 'offsite', 'tar_cou_': 'coupon-at-till', 'off_dv3_': 'offsite', 'off_dv2_': 'offsite'}
    )

    # Proportion of top external factors from Feature Prioritization Output to be tested in Baseline Modelling
    proportion_of_ext_vars: int = 20
    # List of variable types (marketing_type) that we accept multiple variables
    # from the group (rather than exlcusively the top 1)
    accept_multiple_within_type: Optional[List[str]] = field(
        default_factory=lambda: ['PROMOTIONAL DISCOUNT'])
    # Lower bound for Baseline Sales as percentage of Total Sales in Best Iteration logic
    baseline_lower_bound: int = 70

    # Proportion of weeks we check from the last week in the period to check if there are no sales to remove clusters
    count_latest_weeks_no_sales: int = 52

    # Bounds for impression-like metric weekly value validation (Check 2)
    min_impressions_threshold: int = 0
    max_impressions_threshold: int = 2_000_000

    # Bounds for spend metric weekly value validation (Check 3)
    # NOTE — instore budget concentration: for INSTORE/IN-STORE campaigns, the full campaign
    # budget is sometimes assigned to the first week only rather than spread evenly. This can
    # cause legitimate single-week spikes above max_spend_threshold. Confirm with the DS team
    # before treating high-spend instore weeks as errors.
    min_spend_threshold: float = 0.0
    max_spend_threshold: float = 50_000.0

    # Marketing types excluded from signal/impression validation metric lookups
    validation_excluded_marketing_types: List[str] = field(
        default_factory=lambda: ["EXTERNAL", "SALES", "VALUE INDEX", "PROMOTIONAL DISCOUNT", "PLANOGRAM"]
    )

    # Sales validation settings used by sales_validation_metrics.py
    sales_validation_lookback_weeks: int = 104
    sales_zero_streak_warning_weeks: int = 4
    sales_near_zero_threshold: float = 10.0
    sales_outlier_multiplier: float = 3.0

    # Seasonality features involved in create dummy seasonality variables
    seasonality_index_strict_threshold: float = 0.25
    seasonality_index_min_threshold: float = 0.1
    seasonality_index_window_length: int = 3

    seasonality_index_name: str = 'SEASONAL_INDEX'
    seasonality_index_pea_name: str = "nec_xxx_xxx_xxx_sea_pea_dum"
    seasonality_index_dip_name: str = "nec_xxx_xxx_xxx_sea_dip_dum"
    seasonality_primary_metric: str = "Y"
    seasonality_investment_metric: str = "N"

    # Weekly sales features involved in create dummy weekly sales variables
    week_start_control_index_name: str = 'WEEK_START_DUMMY'
    week_start_primary_metric: str = "Y"
    week_start_investment_metric: str = "N"

    # Marketing channels and variables to be considered for total seasonality
    seasonality_bucket_channel_list: List[str] = field(
        default_factory=lambda: ["HOLIDAYS", "FESTIVALS", "WEATHER", "SCHOOL HOLIDAY"])
    seasonality_bucket_variable_list: List[str] = field(default_factory=lambda: [
        "nec_xxx_xxx_xxx_sea_pea_dum", "nec_xxx_xxx_xxx_sea_dip_dum",
        "nec_xxx_xxx_xxx_xxx_pe1_dum", "nec_xxx_xxx_xxx_xxx_pe2_dum",
        "nec_xxx_xxx_xxx_xxx_pe3_dum", "nec_xxx_xxx_xxx_xxx_pe4_dum"
    ])

    # List to seperate dummy variables
    dummy_variable_list: List[str] = field(default_factory=lambda: [
        "nec_xxx_xxx_xxx_xxx_pea_dum", "nec_xxx_xxx_xxx_xxx_dip_dum",
        "nec_xxx_xxx_xxx_sea_pea_dum", "nec_xxx_xxx_xxx_sea_dip_dum",
        "nec_xxx_xxx_xxx_xxx_pe1_dum", "nec_xxx_xxx_xxx_xxx_pe2_dum",
        "nec_xxx_xxx_xxx_xxx_pe3_dum", "nec_xxx_xxx_xxx_xxx_pe4_dum"
    ])

    wsmape_wt: float = 0.25
    rsq_wt: float = 0.25
    last_run_wt: float = 0
    Inc_Perc_wt: float = 0.5

    so_wsmape_wt: float = 0.30
    so_rsq_wt: float = 0.30
    so_last_run_wt: float = 0
    so_base_contri_wt: float = 0.10
    so_seasonality_wt: float = 0.05

    highest_permissible_wsmape: float = 0.20
    least_permissible_rsq: float = 0.70

    # RSQ and WMAPE scores we filter by when selecting the best iteration
    rsq_lower_bound: float = 0.80
    wsmape_upper_bound: float = 0.15

    # ===== Parameters for best iteration logic ======
    # p-value penalty threshold
    alpha: float = 0.05

    # Penalty weights for best interaction scores
    weight_pvalue = 0.3
    weight_rsq = 0.2
    weight_wsmape = 0.2
    weight_iroas = 0.3

    beta_prefix_pattern: str = "^beta\\."
    external_variable_pattern: str = "ext"
    marketing_variables_pattern: str = "_ons_|_off_|_in-_|_tar_"

    # Seasonality index and thresholds to check for expected seaonality from UCM model when we filter for the best iteration
    expected_seasonality_index: Dict[str, str] = field(default_factory=lambda: {
        "ACCESSRIES&FURNITURE": "HIGH",
        "BACON & FSH/SSGES": "HIGH",
        "BEELINE JEWELLERY": "HIGH",
        "BEERS": "HIGH",
        "BRD CAKE & MNG GDS": "HIGH",
        "BWS": "HIGH",
        "CAKE": "HIGH",
        "CANNED GOODS/PRESERV": "MEDIUM",
        "CAR WASH": "HIGH",
        "CARDS": "MEDIUM",
        "CARDS & WRAP CONV": "LOW",
        "CARDS AND WRAP DS": "HIGH",
        "CHEESE COUNTER": "MEDIUM",
        "CHILDRENSWEAR": "HIGH",
        "CHILLED DESSERTS": "HIGH",
        "CLOTHING": "HIGH",
        "COLD CONVENIENCE": "HIGH",
        "COLES": "HIGH",
        "CONFECTIONERY": "HIGH",
        "COSMETICS": "HIGH",
        "CRISPS & SNACKS": "HIGH",
        "CUSTOMERORDERING NSE": "HIGH",
        "DAIRY": "HIGH",
        "DAIRY FARM": "LOW",
        "DELI COUNTER": "MEDIUM",
        "DRIVE OFF/PMP TEST": "HIGH",
        "DUMP": "LOW",
        "ELECTRICAL": "HIGH",
        "ELECTRONIC GIFT CARD": "HIGH",
        "ENTERTAINMENT": "HIGH",
        "ETHNIC": "HIGH",
        "ETU/NON JS CARDS": "HIGH",
        "FABRIC": "HIGH",
        "FABRIS LANE JV": "LOW",
        "FISH": "HIGH",
        "FISH COUNTER": "HIGH",
        "FLORAL": "MEDIUM",
        "FOOD PREP INGREDIENT": "HIGH",
        "FOOD PREP SELLABLES": "HIGH",
        "FOOD TO GO": "HIGH",
        "FORECOURT LINES": "HIGH",
        "FOYER": "HIGH",
        "FRESH FOODS": "MEDIUM",
        "FROZEN FOODS": "HIGH",
        "FROZEN MFP": "HIGH",
        "GLASS LOAN": "LOW",
        "GM DUMP": "MEDIUM",
        "GROC/FROZ/CONFECT": "LOW",
        "HEALTH & BEAUTY": "HIGH",
        "HEALTH&BEAUTY": "MEDIUM",
        "HOME": "HIGH",
        "HOME & LIFESTYLE": "LOW",
        "HOMESHOP": "HIGH",
        "HOT BEVERAGES": "HIGH",
        "HOT CURRY/CHICKEN": "HIGH",
        "HOUSEHOLD": "HIGH",
        "ICON LIVE": "HIGH",
        "ICW WATCHES": "MEDIUM",
        "IN STORE ADVERTISING": "HIGH",
        "INTERNATIONAL": "HIGH",
        "ISB BRD/CKE RCPE": "HIGH",
        "ISB BRD/CKE SOLD": "HIGH",
        "ISB INGREDIENTS": "HIGH",
        "JEWELLERY": "HIGH",
        "JSR ORDERED": "HIGH",
        "JSR SELLABLE": "HIGH",
        "JSR STANDARD": "HIGH",
        "KIDS SHOP": "HIGH",
        "KOSHER WINE": "HIGH",
        "LEISURE": "HIGH",
        "MAJOR ELECTRICAL": "HIGH",
        "MEAL SOLUTIONS": "HIGH",
        "MEAT & PRODUCE": "MEDIUM",
        "MEAT FISH & POULTRY": "HIGH",
        "MENSWEAR": "HIGH",
        "MEST/FISH COUNTER": "HIGH",
        "MOBILES & ACC": "HIGH",
        "MONEY CARD": "LOW",
        "NEWS & MAGS": "HIGH",
        "NON SALES": "LOW",
        "PACKAGED GROCERY": "HIGH",
        "PAYPOINT": "LOW",
        "PETCARE": "HIGH",
        "PHARMACY SENIOR MGR": "HIGH",
        "POSTAGE STAMPS": "HIGH",
        "PRODUCE": "HIGH",
        "SAINSBURYS TO YOU": "HIGH",
        "SALES EXCLUDE": "HIGH",
        "SC  ENTRTMNT DGTAL": "LOW",
        "SEASONAL": "HIGH",
        "SENIOR MANAGR.PETROL": "HIGH",
        "SMRTBXS & CRRIER BGS": "HIGH",
        "SOFT DRINKS": "HIGH",
        "SPIRITS/FORTFD WINES": "HIGH",
        "STATIONERY": "HIGH",
        "STATIONERY & TOYS": "MEDIUM",
        "TOBACCO SNR MANAGER": "HIGH",
        "TOYS": "HIGH",
        "TPB BRANDS": "HIGH",
        "TRADING SYSTEMS": "MEDIUM",
        "TU LEATHER GOODS": "HIGH",
        "UHT MILK": "HIGH",
        "WINES": "HIGH",
        "WOMENSWEAR": "HIGH"
    })
    seasonality_threshold: Dict[str, List[str]] = field(default_factory=lambda: {
        "SEASONALITY_LEVEL": ["HIGH", "MEDIUM", "LOW"],
        "SEASONALITY_BENCHMARK": ["2-20", "0-12", "0-5"]
    })

    # Total sales
    dependent: str = "nec_sal_tot_xxx_xxx_xxx_sls"
    constant_varchar_1000: str = "varchar(1000)"

    # Static variable used to remove apl labels and other column splitting
    var_len: int = 27

    ucm_config: UCMModelConfig = field(default_factory=UCMModelConfig)

    # Define external + internal metrics in a structured object
    primary_metrics: List[tuple] = field(default_factory=lambda: [
        # ==== External Metrics ====
        ("EXTERNAL", "HOLIDAYS", "2ND_JANUARY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "FESTIVALS", "CHRISTIAN", "FESTIVAL_FLAG", "N", "N"),
        ("EXTERNAL", "FESTIVALS", "MUSLIM", "FESTIVAL_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "CHINESE_NEW_YEAR", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "VALENTINES_DAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "ST._DAVIDS_DAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "ST_PATRICKS_DAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "EASTER_MONDAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "ST._GEORGES_DAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "FATHERS_DAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "WINDRUSH_DAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "BATTLE_OF_THE_BOYNE", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "HALLOWEEN", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "GUY_FAWKES_DAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "REMEMBRANCE_SUNDAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "FIRST_SUNDAY_OF_ADVENT", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "ST_ANDREWS_DAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "NEW_YEARS_DAY_HOLIDAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "MOTHERING_SUNDAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "SHAKESPEARE_DAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "EASTER_SUNDAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "EARLY_MAY_BANK_HOLIDAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "GOOD_FRIDAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "STEPHEN_LAWRENCE_DAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "NEW_YEARS_EVE", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "SUMMER_BANK_HOLIDAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "QUEENS_BIRTHDAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "SPRING_BANK_HOLIDAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "CHRISTMAS_DAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "BOXING_DAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "FESTIVALS", "HINDUISM", "FESTIVAL_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "DIWALI_DEEPAVALI", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "EARLY_MAY_BANK_HOLIDAY___VE_DAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "VICTORY_IN_EUROPE_DAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "THE_QUEENS_DIAMOND_JUBILEE", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "ROYAL_WEDDING_BANK_HOLIDAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "SIX_NATIONS_RUGBY_UNION", "EVENT_FLAG", "Y", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "ENGLISH_PREMIER_LEAGUE_22_23_FOOTBALL", "EVENT_FLAG", "N", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "AUTUMN_INTERNATIONALS_RUGBY_UNION", "EVENT_FLAG", "N", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "ENGLISH_PREMIER_LEAGUE_23_24_FOOTBALL", "EVENT_FLAG", "N", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "WORLD_CUP_2023_FOOTBALL", "EVENT_FLAG", "Y", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "EUROPA_LEAGUE_23_24_FOOTBALL", "EVENT_FLAG", "N", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "EUROPA_LEAGUE_22_23_FOOTBALL", "EVENT_FLAG", "N", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "WORLD_CUP_2022_FOOTBALL", "EVENT_FLAG", "Y", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "RUGBY_WORLD_CUP_2023_RUGBY_UNION", "EVENT_FLAG", "Y", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "ICC_WORLD_CUP_2023_CRICKET", "EVENT_FLAG", "Y", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "ENGLISH_PREMIER_LEAGUE_21_22_FOOTBALL", "EVENT_FLAG", "N", "N"),
        ("EXTERNAL", "UNEMPLOYEMENT", "TOTAL", "UNEMPLOYEMENT_INDEX", "Y", "N"),
        ("EXTERNAL", "WEATHER", "TOTAL", "AVERAGE_PRECIPITATION_MINUTES", "N", "N"),
        ("EXTERNAL", "WEATHER", "TOTAL", "AVERAGE_TEMPERATURE", "Y", "N"),
        ("EXTERNAL", "WEATHER", "TOTAL", "MAXIMUM_TEMPERATURE", "N", "N"),
        ("EXTERNAL", "WEATHER", "TOTAL", "MINIMUM_TEMPERATURE", "N", "N"),
        ("EXTERNAL", "WEATHER", "TOTAL", "AVERAGE_SNOWFALL", "Y", "N"),
        ("EXTERNAL", "WEATHER", "TOTAL", "AVERAGE_PRECIPITATION_MM", "Y", "N"),
        ("EXTERNAL", "CCI", "TOTAL", "CCI_INDEX", "Y", "N"),
        ("EXTERNAL", "CPI", "TOTAL", "CPIH_INDEX", "N", "N"),
        ("EXTERNAL", "CPI", "TOTAL", "CPI_INDEX", "Y", "N"),
        ("EXTERNAL", "CPI", "TOTAL", "OOH_INDEX", "N", "N"),
        ("EXTERNAL", "GDP", "TOTAL", "GDP", "N", "N"),
        ("EXTERNAL", "SCHOOL HOLIDAY", "TOTAL", "SCHOOL_HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "FUEL PRICES", "TOTAL", "ULSP_PENCE_PER_LITRE", "Y", "N"),
        ("EXTERNAL", "FUEL PRICES", "TOTAL", "ULSD_PENCE_PER_LITRE", "N", "N"),
        ("EXTERNAL", "FUEL PRICES", "TOTAL", "ULSP_VAT", "N", "N"),
        ("EXTERNAL", "FUEL PRICES", "TOTAL", "ULSD_VAT", "N", "N"),
        ("EXTERNAL", "FUEL PRICES", "TOTAL", "ULSD_DUTY", "N", "N"),
        ("EXTERNAL", "BCI", "TOTAL", "BCI_INDEX", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "EASTER", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "BLACK_FRIDAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "CYBER_MONDAY", "HOLIDAY_FLAG", "Y", "N"),
        ("EXTERNAL", "HOLIDAYS", "2ND_JANUARY_SUBSTITUTE_DAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "WIMBLEDON_TENNIS", "EVENT_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "DAY_OFF_FOR_ST_PATRICKS_DAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "FORMULA_1_GP_MOTORACING", "EVENT_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "NEW_YEARS_DAY", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "EURO_2024_FOOTBALL", "EVENT_FLAG", "N", "N"),
        ("EXTERNAL", "SPORTS EVENTS", "ENGLISH_PREMIER_LEAGUE_24_25_FOOTBALL", "EVENT_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "ST_ANDREWS_DAY_OBSERVED", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "NEW_YEARS_DAY_OBSERVED", "HOLIDAY_FLAG", "N", "N"),
        ("EXTERNAL", "HOLIDAYS", "PRE_CHRISTMAS", "HOLIDAY_FLAG", "N", "N"),

        # ==== In-store ====
        ("INSTORE", "INSTORE", "TOTAL", "TOTAL_MEDIA_COST", "N", "Y"),  # Todo check spelling upstream
        ("INSTORE", "INSTORE", "TOTAL", "EXPOSED_CUSTOMERS", "Y", "N"),
        ("IN-STORE", "IN-STORE", "TOTAL", "TOTAL_MEDIA_COST", "N", "Y"),
        ("IN-STORE", "IN-STORE", "TOTAL", "EXPOSED_CUSTOMERS", "Y", "N"),

        # ==== Targeted Media ====
        ("TARGETED MEDIA", "COUPON AT TILL", "TOTAL", "BASE_VALUE", "N", "Y"),
        ("TARGETED MEDIA", "COUPON AT TILL", "TOTAL", "COUPON_VALUE", "Y", "N"),

        # ==== Offsite (Youtube, DV360, Meta) ====
        ("OFFSITE", "YOUTUBE", "TOTAL", "CLICKS", "N", "N"),
        ("OFFSITE", "YOUTUBE", "TOTAL", "IMPRESSIONS", "Y", "N"),
        ("OFFSITE", "YOUTUBE", "TOTAL", "MEASUREABLE_IMPRESSIONS", "N", "N"),  # Todo check spelling upstream
        ("OFFSITE", "YOUTUBE", "TOTAL", "MEASURABLE_IMPRESSIONS", "N", "N"),
        ("OFFSITE", "YOUTUBE", "TOTAL", "CAMPAIGN_SPEND", "N", "Y"),
        ("OFFSITE", "YOUTUBE", "TOTAL", "VIEWABLE_IMPRESSIONS", "N", "N"),
        ("OFFSITE", "DV360", "TOTAL", "CLICKS", "N", "N"),
        ("OFFSITE", "DV360", "TOTAL", "IMPRESSIONS", "Y", "N"),
        ("OFFSITE", "DV360", "TOTAL", "MEASUREABLE_IMPRESSIONS", "N", "N"),  # Todo check spelling upstream
        ("OFFSITE", "DV360", "TOTAL", "MEASURABLE_IMPRESSIONS", "N", "N"),
        ("OFFSITE", "DV360", "TOTAL", "CAMPAIGN_SPEND", "N", "Y"),
        ("OFFSITE", "DV360", "TOTAL", "VIEWABLE_IMPRESSIONS", "N", "N"),
        ("OFFSITE", "DV360_YOUTUBE", "TOTAL", "CLICKS", "N", "N"),
        ("OFFSITE", "DV360_YOUTUBE", "TOTAL", "MEASUREABLE_IMPRESSIONS", "N", "N"),
        ("OFFSITE", "DV360_YOUTUBE", "TOTAL", "CAMPAIGN_SPEND", "N", "N"),
        ("OFFSITE", "DV360_YOUTUBE", "TOTAL", "IMPRESSIONS", "N", "N"),
        ("OFFSITE", "DV360_YOUTUBE", "TOTAL", "VIEWABLE_IMPRESSIONS", "N", "N"),
        ("OFFSITE", "META", "TOTAL", "IMPRESSIONS", "Y", "N"),
        ("OFFSITE", "META", "TOTAL", "EXTERNALS_MEDIA_SPEND", "N", "N"),
        ("OFFSITE", "META", "TOTAL", "INTERNALS_MEDIA_SPEND", "N", "Y"),
        ("OFFSITE", "META", "TOTAL", "CLICKS", "N", "N"),

        # ==== Onsite (Gol and e-coupon) ====
        ("ONSITE", "ECOUPON", "TOTAL", "COUPON_VALUE", "Y", "N"),
        ("ONSITE", "ECOUPON", "TOTAL", "BASE_VALUE", "N", "Y"),
        ("ONSITE", "ONSITE-GOL", "TOTAL", "SALES_REVENUE", "N", "N"),
        ("ONSITE", "ONSITE-GOL", "TOTAL", "AD_REVENUE", "N", "N"),
        ("ONSITE", "ONSITE-GOL", "TOTAL", "AD_SPEND", "N", "Y"),
        ("ONSITE", "ONSITE-GOL", "TOTAL", "IMPRESSIONS", "Y", "N"),
        ("ONSITE", "ONSITE-GOL", "TOTAL", "CLICKS", "N", "N"),
        ("ONSITE", "ONSITE-GOL", "TOTAL", "CONVERSIONS", "N", "N"),
        ("ONSITE", "ONSITE-GOL", "TOTAL", "UNIT_SALES", "N", "N"),

        ("PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE", "Y", "N"),
        ("PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", "Y", "N"),

        # ==== Promotions & Value Index & Sales ====
        ("PROMOTIONAL DISCOUNT", "DISCOUNT", "TOTAL", "DISCOUNT_PERC", "Y", "N"),
        ("PROMOTIONAL DISCOUNT", "NON_CLUSTER", "TOTAL", "NON_CLUSTER_DISCOUNT_PERC", "Y", "N"),
        ("SALES", "SALES", "TOTAL", "TOTAL_SALES", "Y", "N"),
        ("SALES", "SALES", "TOTAL", "BASE_UNIT_PRICE_AMT", "Y", "N"),
        ("VALUE INDEX", "VALUE INDEX", "TOTAL", "ALL_RETAILER_VALUE_INDEX", "Y", "N"),
        ("VALUE INDEX", "VALUE INDEX", "TOTAL", "KEY_RETAILER_VALUE_INDEX", "N", "N"),
    ])


class BaselineProcessedData:
    """Configuration for baseline processed data pipelines."""

    # This determines the granularity we want to filter the campaign product type table too
    sku_cluster_product_filter: str = 'Brand'

    sku_cluster_modelling_type: str = 'CLUSTERING'

    # Standard columns to select from SKU cluster mapping across all processed data scripts
    sku_cluster_mapping_cols = ["item_cd", "super_category_name", "sub_category_name", "unique_brand_name", "cluster_num"]

    base_price_data_config = {
        'site_type_filter': 'Supermarket',
        'metric': 'TOTAL_SALES',
        'metric_name': 'BASE_UNIT_PRICE_AMT',
        'marketing_type_name': 'SALES',
        'marketing_channel_name': 'SALES',
        'marketing_sub_channel_name': 'TOTAL',
    }

    sales_data_config = {
        'metric_name': 'TOTAL_SALES',
        'marketing_type_name': 'SALES',
        'marketing_channel_name': 'SALES',
        'marketing_sub_channel_name': 'TOTAL',
    }

    promotional_discount_config = {
        'item_type_sale_value': 'Sale',
        'item_type_return_value': 'Return',
        'marketing_type_name': 'PROMOTIONAL DISCOUNT',
        'marketing_sub_channel_name': 'TOTAL',
        'discount_perc_metric': 'discount_perc',
        'non_cluster_discount_perc_metric': 'non_cluster_discount_perc',
        'num_brands_metric': 'num_brands',
        'discount_metric_cluster_label': 'DISCOUNT',
        'discount_metric_non_cluster_label': 'NON_CLUSTER',
        'discount_metrics': ['discount_perc', 'non_cluster_discount_perc', 'num_brands']
    }

    value_index_config = {
        'marketing_type_name': 'VALUE INDEX',
        'marketing_channel_name': 'VALUE INDEX',
        'marketing_sub_channel_name': 'TOTAL',
        'value_index_metrics': ['all_retailer_value_index', 'key_retailer_value_index'],
        'key_retailer_patterns': ['ALDI%', 'TESCO%'],
    }

    secondary_space_config = {
        'marketing_type_name': 'PLANOGRAM',
        'marketing_channel_name_promo': 'PROMO',
        'marketing_channel_name_core': 'CORE',
        'marketing_sub_channel_name': 'TOTAL',
        'metric_name_promo': 'RANGED_SECONDARY_SPACE',
        'metric_name_core': 'RANGED_CORE_SPACE'

    }

    citrus_processed_data_config = {
        'item_id_column': 'ITEM_ID',
        'marketing_type_name': 'ONSITE',
        'marketing_channel_name': 'ONSITE-GOL',
        'marketing_sub_channel_name': 'TOTAL',

        'metric_column_mappings': {
            'sales_revenue_amt': 'sales_revenue',
            'advertising_revenue_amt': 'ad_revenue',
            'advertising_spend_amt': 'ad_spend',
            'impressions_cnt': 'impressions',
            'clicks_cnt': 'clicks',
            'conversions_cnt': 'conversions',
            'unit_sales_cnt': 'unit_sales',
        },

        'metric_columns': [
            'sales_revenue',
            'ad_revenue',
            'ad_spend',
            'impressions',
            'clicks',
            'conversions',
            'unit_sales',
        ],
    }

    # Specific metric name for Citrus onsite impressions condition
    citrus_onsite_impressions_metric = 'IMPRESSIONS'

    channel_validation_config = {
        'non_marketing_feature_types': ['SALES', 'PROMOTIONAL DISCOUNT', 'VALUE INDEX', 'PLANOGRAM', 'EXTERNAL'],
        'weather_metrics': ['AVERAGE_TEMPERATURE', 'AVERAGE_SNOWFALL', 'AVERAGE_PRECIPITATION_MM'],
        'economic_metrics': ['UNEMPLOYEMENT_INDEX', 'CPI_INDEX'],
        'discount_metrics': ['DISCOUNT_PERC', 'NON_CLUSTER_DISCOUNT_PERC'],
        'expected_weeks': 104,
        'ads_check_excluded_marketing_types': ['PROMOTIONAL DISCOUNT', 'PLANOGRAM'],
        'ads_check_excluded_marketing_channels': ['HOLIDAYS', 'FESTIVALS', 'WEATHER', 'SCHOOL HOLIDAY', 'SPORTS EVENTS'],
        'zero_weeks_threshold': 50,
        'spike_ratio': 3.0,
    }


class EcouponConfig:
    """Configuration constants for eCoupon processing"""
    CHANNEL_TYPE = "onsite"
    MEDIA_PROVIDER = "ecoupon"
    BOOKING_STATUS = "completed"
    MEDIA_BUSINESS_GROUP_FILTER = "%sainsbury%"
    FINAL_STATUS = "CLUSTERING"
    MARKETING_TYPE = "ONSITE"
    MARKETING_CHANNEL = "eCoupon"
    MARKETING_SUB_CHANNEL = "TOTAL"
    METRIC_NAME = "COUPON_VALUE"

    # Coupon value patterns
    COUPON_99_PATTERN = "99%"
    COUPON_28_PATTERN = "28%"
    COUPON_28_MULTIPLIER = 0.5


class InstoreConfig:
    """Configuration constants for In-store processing"""
    CHANNEL_TYPE = "instore"  # ToDo use media hierarchy instead
    MEDIA_PROVIDER = "coupon_at_till"  # This is used to filter out the cat campaigns from the instore ones, ToDo use media hierarchy value instead
    BOOKING_STATUS = ["completed", "active"]  # Both completed and active bookings are relevant for in-store as the effect of in-store media can be seen before the end of the campaign
    MEDIA_BUSINESS_GROUP_FILTER = "%sainsbury%"
    FINAL_STATUS = "CLUSTERING"
    # These constants are used for marketing variable creation for the UCM
    MARKETING_TYPE = "IN-STORE"
    MARKETING_CHANNEL = "IN-STORE"
    MARKETING_SUB_CHANNEL = "TOTAL"
    TOTAL_MEDIA_COST_METRIC = "total_media_cost"
    EXPOSED_CUSTOMERS_METRIC = "exposed_customers"
    METRIC_NAME = "EXPOSED_CUSTOMERS"
    METRIC_COLUMNS = [TOTAL_MEDIA_COST_METRIC, EXPOSED_CUSTOMERS_METRIC]


class CouponAtTillConfig:
    """Configuration constants for Coupon At Till processing"""
    DTP_SERVICE_TYPE = "COUPON AT TILL"
    DTP_MEDIA_HOST_NAME = "SAINSBUR%"
    DTP_CAMPAIGN_STATUS = "Campaign completed"

    CHANNEL_TYPE = "instore"
    MEDIA_PROVIDER = "coupon_at_till"
    BOOKING_STATUS = ["completed", "active"]  # Both completed and active bookings are relevant for cat as the effect of cat media can be seen before the end of the campaign
    MEDIA_BUSINESS_GROUP_FILTER = "%sainsbury%"
    FINAL_STATUS = "CLUSTERING"
    MARKETING_TYPE = "TARGETED MEDIA"
    MARKETING_CHANNEL = "COUPON AT TILL"
    MARKETING_SUB_CHANNEL = "TOTAL"
    METRIC_NAME = "COUPON_VALUE"


@dataclass
class CampaignSelectionConfig:
    """Configuration values used by the campaign selection pipeline."""

    campaign_source_mapping: Dict[str, List[str]] = field(
        default_factory=lambda: {
            "coupon-at-till": ["2050", "2051"],
            "ecoupon": ["4013"],
        }
    )
    coupon_at_till_marketing_type: str = "COUPON-AT-TILL"


class MetaConfig:
    """Configuration constants for Meta processing"""
    FINAL_STATUS = "CLUSTERING"
    MARKETING_TYPE = "OFFSITE"
    MARKETING_CHANNEL = "META"
    MARKETING_SUB_CHANNEL = "TOTAL"


class DV360Config:
    """Configuration constants for DV360 processing"""
    FINAL_STATUS = "CLUSTERING"
    MARKETING_TYPE = "OFFSITE"
    MARKETING_CHANNEL = "DV360"
    MARKETING_SUB_CHANNEL = "TOTAL"

    IMPRESSIONS_METRIC = "impressions"
    CLICKS_METRIC = "clicks"
    CAMPAIGN_SPEND_METRIC = "campaign_spend"
    MEASURABLE_IMPRESSIONS_METRIC = "measurable_impressions"
    VIEWABLE_IMPRESSIONS_METRIC = "viewable_impressions"

    METRIC_COLUMNS = [
        IMPRESSIONS_METRIC,
        CLICKS_METRIC,
        MEASURABLE_IMPRESSIONS_METRIC,
        VIEWABLE_IMPRESSIONS_METRIC,
        CAMPAIGN_SPEND_METRIC,
    ]


class YoutubeConfig:
    """Configuration constants for Youtube processing"""
    FINAL_STATUS = "CLUSTERING"
    MARKETING_TYPE = "OFFSITE"
    MARKETING_CHANNEL = "YOUTUBE"
    MARKETING_SUB_CHANNEL = "TOTAL"


class CampaignDurations:
    """Configuration constants for Campaign Durations"""
    CAMPAIGN_DURATION_POST = "Post"
    CAMPAIGN_DURATION_DURING = "During"


class MarketingTypes:
    """Configuration constants for Marketing Types"""
    OFFSITE = "offsite"
    ONSITE = "onsite"


class CitrusConfig:
    """Configuration constants for Citrus processing"""
    # In-scope subchannels for citrus that are currently in scope
    INSCOPE_SUBCHANNELS = [
        # Argos channels
        "sponsored products - argos browse app",
        "sponsored products - argos homepage app",
        "sponsored products - argos pdp featured",
        "sponsored products - argos pdp featured app",
        "sponsored products - argos search app",

        # Argos or Sainsburys combined channels
        "sponsored products - argos or sainsburys browse",
        "sponsored products - argos or sainsburys homepage",
        "sponsored products - argos or sainsburys search",

        # Sainsburys channels
        "sponsored products - sainsburys checkout before you go",
        "sponsored products - sainsburys checkout before you go app",
        "sponsored products - sainsburys cross sell",
        "sponsored products - sainsburys offers",
        "sponsored products - sainsburys pdp similar items",
        "sponsored products - sainsburys search app",
        "sponsored products - sainsburys search below grid",
        "sponsored products - sainsburys zone",
    ]

    # this is the list of citrus subchannels that are out of scope for citrus
    NOT_IN_SCOPE_CHANNELS = [
        "Banner X"
    ]


@dataclass(frozen=True)
class BaselineModellingShrinkageConfig:
    """Configuration constants for Baseline Modelling Shrinkage."""

    # Whether to winsorize inputs before shrinkage modelling.
    winsorize: bool = True

    # Whether to apply a log transform to shrinkage inputs.
    log_transform: bool = True

    # Whether to filter observations using the revenue quality rules.
    revenue_filter_flag: bool = True

    # Revenue grouping parameters used by the shrinkage logic.
    rev_group_1: int = 4
    rev_group_2: int = 3
    rev_threshold_score: float = 0.25

    # Minimum number of campaigns required to form a prior group.
    minimum_campaigns_for_prior_group: int = 5

    # Supplier Analytics guardrails for shrinkage outputs.
    spend_min_threshold: int = 500
    iroas_max_threshold: int = 20
    iroas_min_threshold: int = -5
    pcnt_uplift_max_threshold: int = 500
    min_avg_weekly_spend: int = 1000
    allowed_super_cat_count: int = 1

    incrementality_metric: str = 'TOTAL_INCREMENTAL_AMT'
    # Total sales
    sales_column: str = "nec_sal_tot_xxx_xxx_xxx_sls"

    incrementality_filter_all: str = 'all'
    incrementality_filter_bypass: str = 'bypass-only'

    punctuation_regex: str = r'[\s\.\,\-\_\&\/\(\)\[\]\{\}\:\;\'\"\!\?]+'

    instore_split_cats: List[str] = field(
        default_factory=lambda: [
            "PACKAGED GROCERY",
            "CONFECTIONERY",
            "HEALTH & BEAUTY",
            "CRISPS & SNACKS",
            "DAIRY",
            "FROZEN FOODS",
            "BEERS",
            "WINES",
        ]
    )

    instore_channel: str = 'instore'

    allowed_sources_by_duration: Dict[str, List[str]] = field(
        default_factory=lambda: {
            CampaignDurations.CAMPAIGN_DURATION_DURING: ["INSTORE", "OFFSITE", "ECOUPON", "COUPONATTILL", "ONSITE"],
            CampaignDurations.CAMPAIGN_DURATION_POST: ["INSTORE", "OFFSITE", "ECOUPON", "COUPONATTILL", "ONSITE"],
        }
    )

    # These are the regex patterns for the features that bypass calibration for post-periods
    post_bypass_marketing_variable_patterns: Dict[str, str] = field(
        default_factory=lambda: {
            'ONSITE': 'ons_ons_',
            'ECOUPON': 'ons_eco_',
            'COUPONATTILL': 'tar_cou_'
        }
    )

    during_bypass_marketing_variable_patterns: Dict[str, str] = field(
        default_factory=lambda: {
            'ONSITE': 'ons_ons_'
        }
    )

    random_seed: int = 1409

    # Exponential coefficient is strictly positive
    scaling_exponential_coeff: float = 0.5
    initial_percentage_window: float = 0.1
    step_size: float = 0.05
    max_passes: int = 4
    min_n: Dict[str, Dict[str, int]] = field(
        default_factory=lambda: {
            'pass_1': {"INSTORE": 50, "COUPONATTILL": 50, "OFFSITE": 35, "ECOUPON": 35},
            'pass_2': {"INSTORE": 35, "COUPONATTILL": 35, "OFFSITE": 20, "ECOUPON": 20},
            'pass_3': {"INSTORE": 35, "COUPONATTILL": 35, "OFFSITE": 35, "ECOUPON": 35},
            'pass_4': {"INSTORE": 20, "COUPONATTILL": 20, "OFFSITE": 20, "ECOUPON": 20},
            'overall': 20
        }
    )

    # Alpha used for scaling the ratio of the campaign media spend and the median historic media spend from the benchmark data
    alpha: float = 0.4


class ValidationStatus(StrEnum):
    """Canonical outcomes for QA validation checks."""

    PASS = "pass"
    WARNING = "warning"
    FAIL = "fail"
    SKIPPED = "skipped"


class QAValidationType(str, Enum):
    """Validation domains persisted to the QA metrics tables."""

    HYPERCARE = "hypercare"
    ANALYTICS = "analytics"


class HypercareValidationConfig:
    """Default thresholds and stable names for hypercare checks."""

    CHECK_TYPE = QAValidationType.HYPERCARE.value
    NEAR_ZERO_SALES_THRESHOLD = 1.0
    CHANNEL_DOMINANCE_THRESHOLD = 0.80
    UNITS_PER_CONV_SPREAD_WARNING = 3.0
    INCREMENTAL_PCT_WARNING = 0.50
    IROAS_WARNING_THRESHOLD = 10.0
    OFFSITE_CONVERSION_RATE_WARNING = 3.0
    ONSITE_CONVERSION_RATE_MIN = 1.0
    ONSITE_CONVERSION_RATE_MAX = 10.0
    INSTORE_CONVERSION_RATE_MIN = 1.0
    ROAS_WARNING_THRESHOLD = 100.0
    RECALIBRATED_SALES_TOLERANCE = 0.01
    POST_SALES_WARNING_MULTIPLIER = 1.50
    POST_CONVERSIONS_WARNING_MULTIPLIER = 1.50
    POST_INCREMENTAL_SALES_WARNING_MULTIPLIER = 1.70
    DECIMAL_CAST_TYPE = "decimal(38, 10)"
    POST_SALES_EXPECTED_VALUE = f"DURING+POST >= POST; warn > {POST_SALES_WARNING_MULTIPLIER}x"
    POST_CONVERSIONS_EXPECTED_VALUE = f"DURING+POST >= POST; warn > {POST_CONVERSIONS_WARNING_MULTIPLIER}x"
    POST_INCREMENTAL_SALES_EXPECTED_VALUE = (
        f"DURING+POST >= POST; warn > {POST_INCREMENTAL_SALES_WARNING_MULTIPLIER}x"
    )
    SUBCHANNEL_CONSISTENCY_EXPECTED_VALUE = "MCR subchannels = reach-engagement subchannels"
    MISSING_INSCOPE_SUBCHANNEL_EXPECTED_VALUE = "all in-scope subchannels exist in MCR"
    BOOKING_ID_CHECK = "booking_id"
    CORRELATION_ID_CHECK = "correlation_id"
    CHANNEL_COVERAGE_CHECK = "channel_coverage"
    NEAR_ZERO_SALES_CHECK = "near_zero_sales"
    CHANNEL_DOMINANCE_CHECK = "channel_dominance"
    UNITS_PER_CONVERSION_CHECK = "units_per_conversion"
    BRAND_VS_OFFER_SALES_CHECK = "brand_vs_offer_sales"
    CONVERSION_RATE_CHECK = "conversion_rate"
    INCREMENTAL_SALES_CHECK = "incremental_sales"
    IROAS_CHECK = "iroas"
    ROAS_CHECK = "roas"
    MEDIA_SPEND_CHECK = "media_spend"
    RECALIBRATION_FACTOR_CHECK = "recalibration_factor"
    ATTRIBUTED_SALES_CHECK = "attributed_vs_recalibrated_sales"
    POST_SALES_CHECK = "post_period_sales"
    POST_CONVERSIONS_CHECK = "post_period_conversions"
    POST_INCREMENTAL_SALES_CHECK = "post_period_incremental_sales"
    SUBCHANNEL_CONSISTENCY_CHECK = "subchannel_consistency"
    ROUNDED_MEDIA_SPEND_CHECK = "rounded_media_spend"
    MISSING_INSCOPE_SUBCHANNEL_CHECK = "missing_inscope_subchannel"


class AnalyticsValidationConfig:
    """
    Booking-level analytics checks

    Thresholds are a starting point and expected to be tuned. Conversion rate is a
    percentage (0-100); exposed sales uplift is a ratio (0.2 = 20%). ROAS/iROAS
    use booking/period/journey totals; uplift also groups by marketing type.
    """

    CHECK_TYPE = QAValidationType.ANALYTICS.value
    INSTORE_MARKETING_TYPES = ("instore", "in-store")

    INSTORE_CONVERSION_RATE_MAX = 10.0
    DEFAULT_CHANNEL_CONVERSION_RATE_MAX = 20.0
    ROAS_MAX = 20.0
    IROAS_MAX = 2.0
    INSTORE_EXPOSED_SALES_UPLIFT_MAX = 0.20
    DEFAULT_CHANNEL_EXPOSED_SALES_UPLIFT_MAX = 0.80
    OFFSITE_MEDIA_SPEND_MULTIPLE = 1000.0

    # Check names
    OFFER_VS_BRAND_SALES_CHECK = "offer_vs_brand_sales"
    CONVERSION_RATE_CHECK = "conversion_rate_check"
    ROAS_CHECK = "roas_check"
    IROAS_CHECK = "iroas_check"
    EXPOSED_SALES_UPLIFT_CHECK = "exposed_sales_uplift_check"
    OFFSITE_MEDIA_SPEND_CHECK = "offsite_media_spend_check"


class MtaValidationConfig:
    """Configuration constants for MTA model validation checks (Check 4 & 5)."""

    # Check 4 — Normalized Weight Distribution
    WEIGHT_CHECK_NAME: str = "mta_normalized_weight_sum_check"
    WEIGHT_CHECK_TYPE: str = "mta_weight_validation"
    WEIGHT_SUM_TOLERANCE: float = 1e-5

    # Check 5 — Channel Contribution Distribution
    CONTRIBUTION_CHECK_TYPE: str = "mta_channel_contribution_validation"
    CONTRIBUTION_VS_SALES_CHECK_NAME: str = (
        "mta_channel_contribution_vs_attributed_sales_rank_check"
    )
    CONTRIBUTION_VS_RECALIBRATED_UNITS_CHECK_NAME: str = (
        "mta_channel_contribution_vs_recalibrated_units_rank_check"
    )

    # Spearman ρ thresholds
    SPEARMAN_HIGH_THRESHOLD: float = 0.4   # below this → HIGH severity, at or above → OK

    # ROAS Threshold Validation
    ROAS_CHECK_NAME: str = "roas_threshold_validation_summary"
    ROAS_CHECK_TYPE: str = "roas_validation"
    ROAS_MAX_THRESHOLD: float = 50.0

    # Shared
    MESSAGE_SUBJECT: str = "MTA Validation Metrics Event"

    # User journey validation thresholds
    # Minimum number of distinct converted journeys required at MTA input.
    # Campaigns below this count may produce unreliable attribution weights.
    MIN_THRESHOLD_FOR_CONVERTED_JOURNEYS: int = 1000

    # Minimum acceptable conversion ratio (converted / non_converted) per channel.
    # Channels below this rate likely have insufficient signal for attribution.
    MIN_RATIO_FOR_JOURNEY_CONVERSION: float = 0.001

    # Maximum acceptable conversion ratio (converted / non_converted) per channel.
    # Channels above this rate may indicate data leakage or incorrect journey assignment.
    MAX_RATIO_FOR_JOURNEY_CONVERSION: float = 0.3

    # Minimum number of distinct converted journeys a channel must appear in.
    # Channels below this count are flagged as having insufficient conversion exposure.
    MIN_CONVERTED_JOURNEYS: int = 100

    # Minimum number of distinct non-converted journeys a channel must appear in.
    # Channels below this count lack a meaningful control population for ratio calculation.
    MIN_NON_CONVERTED_JOURNEYS: int = 100

    # Minimum number of journeys that must contain two or more distinct channels.
    # Campaigns with fewer multi-touchpoint journeys cannot produce reliable MTA weights.
    MIN_MULTI_TOUCHPOINT_JOURNEYS: int = 10

    # Proportion of journeys (0–1) above which a single channel combination triggers a
    # co-occurrence warning. Near-uniform co-occurrence may indicate full-store instore
    # campaigns or a data quality issue.
    CHANNEL_COMBINATION_FREQUENCY_THRESHOLD: float = 0.9

    # Maximum total net sales (inclusive) for a channel across all converted journeys
    # before a high-severity low-sales warning is raised.
    LOW_SALES_THRESHOLD: float = 100.0


@dataclass(frozen=True)
class IncrementalityFallbackConfig:
    """Config for the fallback solution
    Triggers when recalibrated attributed sales < incrementality"""

    # List of marketing types where if fallback state,
    # we take the legacy control/test lift measure
    # NB: Fallback code assumes the same fallback incrementality for offer and brand
    # when this control lift is used.
    control_lift_marketing_types: List[str] = field(
        default_factory=lambda: ['COUPON AT TILL',])

    # Product type to compare estimated incrementality to control campaign uplift
    # Either 'Offer' or 'Brand'
    control_fallback_product_type: str = 'BRAND'

    # Percentile of published incrementality ratios
    # to take as the fallback ratio
    fallback_percentile: float = 0.9

    # Minimum sample size for published incrementality ratios
    # for a valid fallback
    min_published_campaigns: int = 3

    # A guardrail - the fallback ratio should never cause
    # incrementality >= attributed
    # Maximum value = 1.0
    max_fallback_ratio: float = 1.0

    # Floor negative Post incrementality at 0 (and zero it where Post attributed is <= 0).
    floor_post_incrementality: bool = True

    # Floor negative control lift incrementality at 0 if enabled
    floor_control_lift_incrementality: bool = True


class FallbackTypes:
    """Configuration constants for Fallback Types"""
    FALLBACK_CONTROL = "control"
    FALLBACK_PUBLISHED = "published"


class MarketingMetricNames:
    """Canonical metric name constants used across marketing channel pipelines."""
    IMPRESSIONS = "IMPRESSIONS"


class PipelineSummaryMetricsConfig:
    """Configuration constants for pipeline summary metrics."""
    EXTERNAL_MARKETING_TYPE = "EXTERNAL"

    VARIABLE_GROUP_COLS = [
        "variable_cd",
        "marketing_type_name",
        "marketing_channel_name",
        "marketing_sub_channel_name",
        "metric_name",
    ]

    UCM_HYPERPARAMETER_VARIABLES = ["level", "cycle", "level_base"]

    INCREMENTALITY_METRIC_NAMES = [
        "ucm_incrementality",
        "calibrated_incrementality",
        "bypass_incrementality",
        "during_incrementality",
        "adjusted_calibrated_incrementality",
    ]

    CALIBRATION_AUDIT_COLS = [
        "marketing_type",
        "mean_log_uplift",
        "var_log_uplift",
        "count_campaigns",
        "distribution_type",
        "shift_parameter",
        "rev_similarity_percentile",
        "scaling_factor",
        "sample_median",
        "sample_mode",
        "z_score",
        "channel_prior_failures",
    ]

    # Campaign details input columns (as they appear in source data)
    CAMPAIGN_DETAILS_INPUT_COLS = [
        "campaign_id",
        "booking_id",
        "campaign_start_dt",
        "campaign_end_dt",
        "post_campaign_dt",
        "subchannel_name",
        "media_spend_amt",
        "unique_brand_name",
        "super_category_name",
    ]

    # Campaign details output column mappings (from input to standardized names)
    CAMPAIGN_DETAILS_ALIASES = {
        "campaign_start_dt": "campaign_start_date",
        "campaign_end_dt": "campaign_end_date",
        "post_campaign_dt": "post_campaign_date",
    }

    # Marketing join key columns used for aggregating baseline marketing data
    MARKETING_KEY_COLS = ["super_category_name", "unique_brand_name"]

    # Campaign marketing keys columns for joining with baseline data
    CAMPAIGN_MARKETING_KEYS_COLS = [
        "campaign_id",
        "booking_id",
        "campaign_start_date",
        "campaign_end_date",
        "unique_brand_name",
        "super_category_name",
        "correlation_id",
    ]

    # Product details columns
    PRODUCT_DETAILS_BASE_COLS = [
        "campaign_id",
        "booking_id",
        "item_cd",
        "sku_name",
        "product_type",
        "brand_name",
        "unique_brand_name",
        "channel_name",
        "load_ts",
    ]

    # Sales amount column candidates (in order of precedence)
    SALES_AMOUNT_CANDIDATES = [
        "sales_amt",
        "total_sales_amt",
        "total_sales_amt_104w",
    ]

    # Canonical column names for aggregation
    AGGREGATION_KEY_COLS = ["correlation_id", "campaign_id", "booking_id"]

    # Join key columns (subset of aggregation keys)
    JOIN_KEY_COLS = ["campaign_id", "booking_id"]

    # Correlation ID column (for single-key joins and groupings)
    CORRELATION_ID_COL = "correlation_id"

    # Product type filter patterns
    PRODUCT_TYPE_OFFER = "offer"
    PRODUCT_TYPE_BRAND = "brand"

    # Summary data group names
    DATA_GROUP_CAMPAIGN = "campaign_definition"
    DATA_GROUP_PRODUCT = "product_details"
    DATA_GROUP_MARKETING = "marketing_details"

    # Data source names
    DATA_SOURCE_UNIFIED_CAMPAIGN = "unified_campaign"
    DATA_SOURCE_CAMPAIGN_PRODUCT = "campaign_product_type"
    DATA_SOURCE_BASELINE_DATASET = "baseline_modelling_dataset"
