"""
There is an alternative available for this class create as part of KRAN-3736.
Use the general_entrypoint function instead if you want to speed up the development process.
"""
import argparse


class ArgumentParserError(Exception):
    pass


class ThrowingArgumentParser(argparse.ArgumentParser):
    """
    There is an alternative available for this class create as part of KRAN-3736.
    Use the general_entrypoint function instead if you want to speed up the development process.
    """
    def error(self, message):
        raise ArgumentParserError(message)


def str_to_bool(input_str: str):
    if input_str.lower() in ['true', '1', 't']:
        return True
    else:
        return False
