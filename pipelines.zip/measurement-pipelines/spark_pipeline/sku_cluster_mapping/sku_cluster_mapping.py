import datetime
from typing import List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession, functions as F

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser, str_to_bool
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def _read_input_data(
    spark: SparkSession,
    campaign_selection_input_path: str,
    unified_campaign_input_path: str,
    campaign_product_type_input_path: str,
    sales_data_input_path: str
) -> Tuple[DataFrame, DataFrame, DataFrame, DataFrame]:
    """
    Args:
        spark (SparkSession): Spark session object.
        campaign_selection_input_path (str): S3 path to the input dataset containing the brand we're currently running through baseline
        unified_campaign_input_path (str): S3 path to the input dataset containing campaign information for all campaigns
        campaign_product_type_input_path (str): S3 path to the input dataset representing the product type information for each campaign and SKU.
        sales_data_input_path (str): S3 path to the input dataset containing sales data, we filter out any skus that don't have sales (these are usually test skus)

    Returns:
        Tuple[DataFrame, DataFrame, DataFrame, DataFrame]:
            A tuple containing:
            - campaign_product_type_df: DataFrame representing the product type information for each campaign and SKU.
            - unified_campaign_df: DataFrame representing each campaign we ingest.
            - selected_campaigns_df: DataFrame representing the brand (of a campaign) we're running for the current run.
            - sales_filter_df: DataFrame representing the sold SKUs we should keep in the output.
    """
    unified_campaign_df = (
        spark
        .read
        .parquet(unified_campaign_input_path)
        .select(
            "job_bag_number",
            "campaign_id",
        )
    )

    campaign_product_type_df = (
        spark
        .read
        .parquet(campaign_product_type_input_path)
        .withColumnRenamed("sub_cat_name", "sub_category_name")
        .select(
            "campaign_id",
            "item_cd",
            "product_type",
            "unique_brand_name",
            "sub_category_name",
        )
    )

    selected_campaigns_df = (
        spark
        .read
        .parquet(campaign_selection_input_path)
        .select(
            "unique_brand_name",
            "super_category_name",
            "sub_category_name",
        )
    )

    sales_filter_df = (
        spark
        .read
        .parquet(sales_data_input_path)
        .select("item_cd")
        .distinct()
    )

    return campaign_product_type_df, unified_campaign_df, selected_campaigns_df, sales_filter_df


def _parse_manual_campaign_list(
    manual_run_flag: bool,
    manual_campaign_list: Optional[str],
) -> Optional[List[str]]:
    """
    Return parsed manual campaign ids only when manual mode is enabled.

    Args:
        manual_run_flag (bool): Flag indicating whether this run is a manual execution. If True, the function will filter campaigns based on the provided manual_campaign_list. Default is False.
        manual_campaign_list (Optional[str]): Comma-separated string of campaign IDs to include in the run when manual_run_flag is True. If None or empty

    Returns:
        Optional[List[str]]: String list of campaign IDs if manual_run_flag is True and manual_campaign_list is provided, otherwise None.
    """
    if not manual_run_flag or not manual_campaign_list:
        return None

    campaign_ids = [campaign_id.strip() for campaign_id in manual_campaign_list.split(",")]
    return [campaign_id for campaign_id in campaign_ids if campaign_id]


def get_brand_skus(
    campaign_product_type_df: DataFrame,
    unified_campaign_df: DataFrame,
    selected_campaigns_df: DataFrame,
    sales_filter_df: DataFrame,
    manual_booking_list: Optional[List[str]] = None
) -> DataFrame:
    """
    Keep only brand SKUs in selected campaigns based on unique brand and sub category,
    optionally filters for specific campaign we're running in the pipeline.

    Args:
        campaign_product_type_df (DataFrame): DataFrame representing the product type information for each campaign and SKU.
        unified_campaign_df (DataFrame): DataFrame representing each campaign we ingest.
        selected_campaigns_df (DataFrame): DataFrame representing the brand (of a campaign) we're running for the current run.
        sales_filter_df (DataFrame): DataFrame representing sales data; we filter out any SKUs that do not have sales.
        manual_booking_list (Optional[List[str]]): List of booking IDs (job_bag_numbers) to filter for if this is a manual run, otherwise None.

    Returns:
        DataFrame: A DataFrame containing the filtered SKUs that are of product type "Brand" and belong to the campaigns selected for the current run

    Note:
        The DTP unified campaign object uses job_bag_number to represent a booking, in the pollen version we use the booking id from the BDV and rename it to job_bag_number for compatibility
    """
    # Default value will always be "Brand", as we run baseline at the brand level
    product_type_filter = BaselineProcessedData.sku_cluster_product_filter

    if manual_booking_list:
        unified_campaign_df = (
            unified_campaign_df
            .filter(
                F.col("job_bag_number").isin(manual_booking_list)
            )
            .distinct()
        )

    sku_cluster_filtered = (
        campaign_product_type_df
        .join(F.broadcast(unified_campaign_df), on="campaign_id", how="inner")
        .join(F.broadcast(selected_campaigns_df), on=["unique_brand_name", "sub_category_name"], how="inner")
        .join(sales_filter_df, on="item_cd", how="inner")
        .filter(F.col("product_type") == product_type_filter)
        .select(
            "job_bag_number",
            "super_category_name",
            "sub_category_name",
            "unique_brand_name",
            "item_cd",
        )
    )

    return sku_cluster_filtered


def run_assignment(
    spark: SparkSession,
    correlation_id: str,
    sales_data_input_path: str,
    campaign_selection_input_path: str,
    unified_campaign_input_path: str,
    campaign_product_type_input_path: str,
    final_output_path: str,
    manual_run_flag: bool = False,
    manual_campaign_list: Optional[str] = None,
) -> None:
    """
    This function assigns all the brand skus to a cluster to be run by the UCM model downstream.

    Args:
        spark (SparkSession): SparkSession object for Spark operations.
        correlation_id (str): Unique identifier for the current run, used for tracking and logging.
        sales_data_input_path (str): S3 path to the input dataset containing sales data, we filter out any skus that don't have sales (these are usually test skus)
        campaign_selection_input_path (str): S3 path to the input dataset containing selected campaigns for the baseline pipeline.
        unified_campaign_input_path (str): S3 path to the input dataset containing campaign information.
        campaign_product_type_input_path (str): S3 path to the input dataset containing campaign product type information, this source identifies which skus are considered the brand skus for each campaign.
        final_output_path (str): S3 path where the final output of the SKU cluster mapping will be written in Parquet format.
        manual_run_flag (bool): Flag indicating whether this run is a manual execution. If True, the function will filter campaigns based on the provided manual_campaign_list. Default is False.
        manual_campaign_list (Optional[str]): Comma-separated string of campaign IDs to include in the run when manual_run_flag is True. If None or empty

    Side Effects:
        - Reads multiple input datasets from S3 in Parquet format.
        - Writes the final DataFrame to the specified output_path in Parquet format.
    """

    run_ts: str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    parsed_campaign_list = _parse_manual_campaign_list(manual_run_flag, manual_campaign_list)

    campaign_product_type_df, unified_campaign_df, selected_campaigns_df, sales_filter_df = _read_input_data(
        spark,
        campaign_selection_input_path,
        unified_campaign_input_path,
        campaign_product_type_input_path,
        sales_data_input_path
    )

    sku_clustering_filtered = get_brand_skus(
        campaign_product_type_df,
        unified_campaign_df,
        selected_campaigns_df,
        sales_filter_df,
        parsed_campaign_list
    )

    sku_clustering_output = (
        sku_clustering_filtered
        .withColumn("cluster_num", F.upper(F.col("job_bag_number")))  # Prepare the data for multi-booking runs, each cluster is now the booking ID (job_bag_number)
        .withColumn("modelling_type", F.lit(BaselineProcessedData.sku_cluster_modelling_type))
        .withColumn("job_run_id", F.lit(correlation_id))
        .withColumn("load_ts", F.lit(run_ts))
        .select(
            "cluster_num",
            "super_category_name",
            "sub_category_name",
            "unique_brand_name",
            "item_cd",
            "modelling_type",
            "job_run_id",
            "load_ts"
        )
        .distinct()
    )

    spark_s3_overwrite(final_output_path, sku_clustering_output)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="SKU Cluster Mapping")
    parser.add_argument(
        "--correlation-id", type=str, required=True,
        help="Correlation ID for this run"
    )
    parser.add_argument(
        "--sales-data-input-path", type=str, required=True,
        help="S3 path for sales data",
    )
    parser.add_argument(
        "--campaign-selection-input-path", type=str, required=True,
        help="S3 path for those campaigns that were selected for this run",
    )
    parser.add_argument(
        "--unified-campaign-path", type=str, required=True,
        help="S3 path for unified campaign data",
    )
    parser.add_argument(
        "--campaign-product-type-path", type=str, required=True,
        help="S3 path for campaign product type data",
    )
    parser.add_argument(
        "--final-output-path", type=str, required=True,
        help="S3 path for final output of the clustering, incl. (possibly) k-means, time series clustering & iteration",
    )
    parser.add_argument(
        "--manual-run-flag", type=str, required=True,
        help="Flag to indicate manual execution."
    )
    parser.add_argument(
        "--manual-campaign-list", type=str, required=False, default="",
        help="Comma-separated list of campaign IDs for manual run."
    )
    parser.add_argument(
        "--slack-topic-arn", type=str, required=True,
        help="The ARN of the Slack topic for notifications."
    )
    known_args, _ = parser.parse_known_args(command_line_args)

    run_assignment(
        spark,
        known_args.correlation_id,
        known_args.sales_data_input_path,
        known_args.campaign_selection_input_path,
        known_args.unified_campaign_path,
        known_args.campaign_product_type_path,
        known_args.final_output_path,
        str_to_bool(known_args.manual_run_flag),
        known_args.manual_campaign_list,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName(__file__).getOrCreate())
