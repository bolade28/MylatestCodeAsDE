from pyspark.sql import types as T


class MTAValidationMetrics:
    user_journey_validation_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("comment", T.StringType(), True),
        T.StructField("metadata", T.StringType(), True),
        T.StructField("check_name", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True),
    ])

    user_journey_input_schema = T.StructType([
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("event_name", T.StringType(), True),
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("transaction_key", T.StringType(), True),
        T.StructField("event_ts", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("isconversion", T.IntegerType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("job_run_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("net_sales_amt", T.DoubleType(), True),
        T.StructField("units_qty", T.IntegerType(), True),
        T.StructField("journey_type", T.StringType(), True),
        T.StructField("purchase_type", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
    ])
