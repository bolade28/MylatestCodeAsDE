"""
Test schemas for the user_journey_rebuild unit tests.

These mirror the minimal DataFrames that flow between the helper functions in
user_journey_rebuild_helper.py. Keep them in sync with get_latest_campaign_customer_data's
select() output and the in-progress campaigns broadcast.
"""

from pyspark.sql import types as T


class UserJourney():

    MeasurementCampaignExecution = (
        T.StructType([
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("campaign_duration", T.StringType(), True),
            T.StructField("job_status", T.StringType(), True)
        ])
    )
    CampaignProductTypeSchema = (
        T.StructType([
            T.StructField("item_cd", T.StringType(), True),
            T.StructField("product_type", T.StringType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("unique_brand_name", T.StringType(), True)
        ])
    )

    CustomerDataCollection = (
        T.StructType([
            T.StructField("loyalty_id", T.StringType(), True),
            T.StructField("transaction_key", T.StringType(), True),
            T.StructField("event_ts", T.TimestampType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("campaign_name", T.StringType(), True),
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("event_name", T.StringType(), True),
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("item_cd", T.StringType(), True),
            T.StructField("product_type", T.StringType(), True),
            T.StructField("net_sales_amt", T.DecimalType(38, 4), True),
            T.StructField("units_qty", T.DecimalType(38, 4), True),
            T.StructField("unique_brand_name", T.StringType(), True),
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField("load_ts", T.TimestampType(), True),
            T.StructField("purchase_type", T.StringType(), True)
        ])
    )

    TrimPostConversionEventsInput = (
        T.StructType([
            T.StructField("loyalty_id", T.StringType(), True),
            T.StructField("transaction_key", T.StringType(), True),
            T.StructField("event_ts", T.TimestampType(), True),
            T.StructField("event_name", T.StringType(), True),
            T.StructField("channel_name", T.StringType(), True),
        ])
    )

    UserJourneySchema = (
        T.StructType([
            T.StructField("loyalty_id", T.StringType(), True),
            T.StructField("transaction_key", T.StringType(), True),
            T.StructField("event_ts", T.TimestampType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("event_name", T.StringType(), True),
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("sub_path", T.LongType(), True),
            T.StructField("userjourney_id", T.StringType(), True),
            T.StructField("rank", T.LongType(), True),
            T.StructField("position", T.StringType(), True),
            T.StructField("isconversion", T.IntegerType(), True),
            T.StructField("load_ts", T.TimestampType(), True),
            T.StructField("campaign_duration", T.StringType(), True),
            T.StructField("job_run_id", T.StringType(), True),
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField("net_sales_amt", T.DecimalType(38, 4), True),
            T.StructField("units_qty", T.DecimalType(38, 4), True),
            T.StructField("journey_type", T.StringType(), True),
            T.StructField("purchase_type", T.StringType(), True)
        ])
    )
    # Production schemas — re-exported here so test files have a single import point.
    CDC_SCHEMA = CustomerDataCollection
    MCE_SCHEMA = MeasurementCampaignExecution

    # Matches the output of get_latest_campaign_customer_data.
    # item_cd is included so dedup_purchases_across_campaigns can distinguish
    # items with identical price/qty; it is dropped in build_user_journey_pollen
    # after dedup.
    POLLEN_EVENTS_SCHEMA = T.StructType([
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("transaction_key", T.StringType(), True),
        T.StructField("event_ts", T.TimestampType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("event_name", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("net_sales_amt", T.DecimalType(38, 4), True),
        T.StructField("units_qty", T.DecimalType(38, 4), True),
    ])

    # Minimal in-progress campaigns schema (booking_id + campaign_duration only).
    # Used by structure_events_into_user_journey tests.
    IN_PROGRESS_SCHEMA = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
    ])

    # Single-field variant used when only booking_id is needed for a join
    # (e.g. get_latest_campaign_customer_data tests).
    BOOKING_ID_ONLY_SCHEMA = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
    ])

    # Columns that must be invariant across every row in a Pollen user journey.
    # Used by unit tests to assert isconversion, sub_path, and userjourney_id together.
    INVARIANTS_SCHEMA = T.StructType([
        T.StructField("isconversion", T.IntegerType()),
        T.StructField("sub_path", T.LongType()),
        T.StructField("userjourney_id", T.StringType()),
    ])
