from pyspark.sql import types as T


class CustomerDataCollection:
    schema = T.StructType([
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("transaction_key", T.StringType(), True),
        T.StructField("event_dt", T.DateType(), True),
        T.StructField("event_ts", T.TimestampType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), False),
        T.StructField("subchannel_name", T.StringType(), False),
        T.StructField("campaign_name", T.StringType(), False),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("event_name", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("item_cd", T.StringType(), False),
        T.StructField("product_type", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("net_sales_amt", T.DecimalType(30, 4), True),
        T.StructField("units_qty", T.IntegerType(), False),
        T.StructField("job_run_id", T.StringType(), False),
        T.StructField("purchase_type", T.StringType(), True),
    ])

    # Schema for channel source files loaded by prepare_customer_data_collection.
    # Upstream data now includes purchase_type directly.
    channel_data_schema = schema

    # Minimal schema for the date-window inputs to apply_date_window_filter.
    date_window_schema = T.StructType([
        T.StructField("overlapping_campaign_flag", T.BooleanType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
    ])

    # Full campaign execution table schema (15 columns).
    campaign_execution_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("campaign_name", T.StringType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("job_status", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("job_run_id", T.StringType(), True),
        T.StructField("overlapping_campaign_flag", T.BooleanType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True),
    ])

    # Marketing channel hierarchy table schema.
    hierarchy_schema = T.StructType([
        T.StructField("marketing_hierarchy_cd", T.StringType(), True),
    ])

    # Subset schema used to verify purchase-field derivation in tests.
    purchase_fields_schema = T.StructType([
        T.StructField("event_name", T.StringType(), True),
        T.StructField("purchase_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
    ])
