from pyspark.sql import types as T


class AttributionPreRequisiteSchema:

    regression_variable_schema = (
        T.StructType([
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("campaign_id", T.StringType(), True)
        ]))

    # TODO:: I changed all nullables to true, but probably can discuss whether we are going to allow null
    attribution_pre_requisite_schema = (
        T.StructType([
            T.StructField("loyalty_id", T.StringType(), True),
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("purchase_type", T.StringType(), True),
            T.StructField("event_ts", T.TimestampType(), True),
            T.StructField("event_name", T.StringType(), True),
            T.StructField("net_sales_amt", T.DecimalType(38, 4), True),
            T.StructField("transaction_key", T.StringType(), True),
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("userjourney_id", T.StringType(), True),
            T.StructField("position", T.StringType(), True),
            T.StructField("isconversion", T.IntegerType(), True),
            T.StructField("campaign_duration", T.StringType(), True),
            T.StructField("journey_type", T.StringType(), True),
            T.StructField("customer_journey_type", T.StringType(), True),
            T.StructField("regression_variable", T.StringType(), True),
            T.StructField("load_ts", T.TimestampType(), True),
            T.StructField("job_run_id", T.StringType(), True),
        ])
    )

    aisle_reporting_schema = (
        T.StructType([
            T.StructField("userjourney_id", T.StringType(), True),
            T.StructField("isconversion", T.IntegerType(), True),
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("campaign_duration", T.StringType(), True),
            T.StructField("load_ts", T.TimestampType(), True)
        ]))
