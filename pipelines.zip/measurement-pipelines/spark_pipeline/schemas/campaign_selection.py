from pyspark.sql import types as T


class CampaignSelection:
    proxy_schema = T.StructType([
        T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
        T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
        T.StructField("PROXY_BRANDS_COUNT", T.IntegerType(), True),
    ])

    proxy_mapping_schema = T.StructType([
        T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
        T.StructField("PROXY_SUPER_CATEGORY_NAME", T.StringType(), True),
        T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
        T.StructField("PROXY_BRANDS", T.StringType(), True),
        T.StructField("LOAD_TS", T.StringType(), True),
    ])

    new_super_category_schema = T.StructType([
        T.StructField("CONCAT", T.StringType(), True),
        T.StructField("RENAME_FLAG", T.IntegerType(), True),
        T.StructField("OLD_SC_PREVIOUS", T.StringType(), True),
    ])

    sales_data_schema = T.StructType([
        T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
        T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
        T.StructField("WEEK_START_DT", T.DateType(), True),
        T.StructField("TOTAL_SALES_AMT", T.FloatType(), True),
        T.StructField("CONCAT", T.StringType(), True)
    ])

    sku_schema = T.StructType([
        T.StructField("ITEM_CD", T.LongType(), True),
        T.StructField("MODELLING_TYPE", T.StringType(), True),
    ])

    unified_campaign_output_schema = T.StructType([
        T.StructField("CAMPAIGN_ID", T.StringType(), True),
        T.StructField("JOB_BAG_NUMBER", T.StringType(), True),
        T.StructField("BOOKING_ID", T.StringType(), True),
    ])

    campaign_selection_schema = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("final_status", T.StringType(), True),
        T.StructField("product_type", T.StringType(), True),
        T.StructField("marketing_types", T.StringType(), True),
        T.StructField("channel_name", T.ArrayType(T.StringType()), True),
        T.StructField("subchannel_name", T.ArrayType(T.StringType()), True),
    ])

    campaign_selection_dates_schema = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("min_campaign_start_dt", T.DateType(), True),
        T.StructField("max_campaign_end_dt", T.DateType(), True),
    ])

    campaign_selection_with_dates_schema = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("final_status", T.StringType(), True),
        T.StructField("product_type", T.StringType(), True),
        T.StructField("min_campaign_start_dt", T.DateType(), True),
        T.StructField("max_campaign_end_dt", T.DateType(), True),
        T.StructField("max_post_campaign_dt", T.DateType(), True),
    ])
