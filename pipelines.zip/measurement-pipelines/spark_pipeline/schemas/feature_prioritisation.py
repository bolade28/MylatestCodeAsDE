from pyspark.sql import types as T


class FeaturePrioritisation:

    empty_campaign_selection_schema = T.StructType([
        T.StructField("MODELLING_CLUSTER_LIST", T.StringType(), True)
    ])

    correlation_schema = T.StructType([
        T.StructField("feature", T.StringType(), True),
        T.StructField("cluster", T.StringType(), True),
        T.StructField("correlation", T.DoubleType(), True),
        T.StructField("group_key", T.StringType(), True),
    ])

    correlation_test_input_schema = T.StructType([
        T.StructField("group_key", T.StringType(), True),
        T.StructField("feature1", T.DoubleType(), True),
        T.StructField("feature2", T.DoubleType(), True),
        T.StructField("feature3", T.DoubleType(), True),
        T.StructField("cluster1", T.DoubleType(), True),
        T.StructField("cluster2", T.DoubleType(), True),
    ])

    sales_schema = T.StructType([
        T.StructField("week_date", T.DateType(), True),
        T.StructField("unique_brand", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True)
    ])

    primary_metric_schema = T.StructType([
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("primary_metric_cd", T.StringType(), True),
        T.StructField("investment_metric_cd", T.StringType(), True),
    ])

    baseline_input_dataset_schema = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("variable_cd", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
        T.StructField("job_run_id", T.StringType(), True),
    ])

    intermediate_input_dataset_schema = T.StructType([
        T.StructField("week_date", T.DateType(), True),
        T.StructField("unique_brand", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True),
        T.StructField("job_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("variable", T.StringType(), True),
        T.StructField("primary_metric", T.StringType(), True),
        T.StructField("investment_metric", T.StringType(), True),
    ])

    pre_processed_input_y_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("unique_brand", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("final_cluster", T.StringType(), True),
        T.StructField("feature_prioritization_y", T.DoubleType(), True)
    ])

    pre_processed_input_x_schema = T.StructType([
        T.StructField("date", T.DateType(), True),
        T.StructField("unique_brand", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster", T.StringType(), True),
        T.StructField("variable", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True)
    ])

    pre_processed_output_schema = T.StructType([
        T.StructField("date", T.DateType(), True),
        T.StructField("group_key", T.StringType(), True),
        T.StructField("variable", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True)
    ])

    pre_processed_external_output_schema = T.StructType([
        T.StructField("date", T.DateType(), True),
        T.StructField('unique_brand', T.StringType(), True),
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('cluster', T.StringType(), True),
        T.StructField("group_key", T.StringType(), True),
        T.StructField("variable", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True)
    ])

    sales_schema_with_meta_data = T.StructType([
        T.StructField("week_date", T.DateType(), True),
        T.StructField("unique_brand", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True),
        T.StructField("job_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
    ])

    list_independent_ext_factors_schema = T.StructType([
        T.StructField("variable", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("metric", T.StringType(), True)
    ])

    melt_test_schema = T.StructType([
        T.StructField("date", T.StringType(), True),
        T.StructField("group_key", T.StringType(), True),
        T.StructField("col1", T.IntegerType(), True),
        T.StructField("col2", T.IntegerType(), True),
    ])

    model_outputs_schema = T.StructType([
        T.StructField("feature", T.StringType(), True),
        T.StructField("rf_importance", T.DoubleType(), True),
        T.StructField("rf_rank", T.IntegerType(), True),
        T.StructField("xgb_importance", T.DoubleType(), True),
        T.StructField("xgb_rank", T.IntegerType(), True),
        T.StructField("lasso_importance", T.DoubleType(), True),
        T.StructField("lasso_rank", T.IntegerType(), True),
        T.StructField("rf_mae", T.DoubleType(), True),
        T.StructField("rf_mape", T.DoubleType(), True),
        T.StructField("rf_r2", T.DoubleType(), True),
        T.StructField("xgb_mae", T.DoubleType(), True),
        T.StructField("xgb_mape", T.DoubleType(), True),
        T.StructField("xgb_r2", T.DoubleType(), True),
        T.StructField("lasso_mae", T.DoubleType(), True),
        T.StructField("lasso_mape", T.DoubleType(), True),
        T.StructField("lasso_r2", T.DoubleType(), True),
        T.StructField("cluster", T.StringType(), True),
        T.StructField("group_key", T.StringType(), True)
    ])

    fp_data_post_processing_input_schema = T.StructType([
        T.StructField("feature", T.StringType(), True),
        T.StructField("cluster", T.StringType(), True),
        T.StructField("group_key", T.StringType(), True),
        T.StructField("rf_importance", T.DoubleType(), True),
        T.StructField("rf_rank", T.IntegerType(), True),
        T.StructField("xgb_importance", T.DoubleType(), True),
        T.StructField("xgb_rank", T.IntegerType(), True),
        T.StructField("lasso_importance", T.DoubleType(), True),
        T.StructField("lasso_rank", T.IntegerType(), True),
        T.StructField("rf_mae", T.DoubleType(), True),
        T.StructField("rf_mape", T.DoubleType(), True),
        T.StructField("rf_r2", T.DoubleType(), True),
        T.StructField("xgb_mae", T.DoubleType(), True),
        T.StructField("xgb_mape", T.DoubleType(), True),
        T.StructField("xgb_r2", T.DoubleType(), True),
        T.StructField("lasso_mae", T.DoubleType(), True),
        T.StructField("lasso_mape", T.DoubleType(), True),
        T.StructField("lasso_r2", T.DoubleType(), True),
        T.StructField("correlation", T.DoubleType(), True),
        T.StructField("calculated_rank", T.DoubleType(), True),
        T.StructField("final_rank", T.IntegerType(), True),
    ])

    fp_data_post_processing_output_schema = T.StructType([
        T.StructField("feature", T.StringType(), True),
        T.StructField("final_cluster", T.StringType(), True),
        T.StructField("group_key", T.StringType(), True),
        T.StructField("rf_importance", T.DoubleType(), True),
        T.StructField("rf_rank", T.IntegerType(), True),
        T.StructField("xgb_importance", T.DoubleType(), True),
        T.StructField("xgb_rank", T.IntegerType(), True),
        T.StructField("lasso_importance", T.DoubleType(), True),
        T.StructField("lasso_rank", T.IntegerType(), True),
        T.StructField("rf_mae", T.DoubleType(), True),
        T.StructField("rf_mape", T.DoubleType(), True),
        T.StructField("rf_r2", T.DoubleType(), True),
        T.StructField("xgb_mae", T.DoubleType(), True),
        T.StructField("xgb_mape", T.DoubleType(), True),
        T.StructField("xgb_r2", T.DoubleType(), True),
        T.StructField("lasso_mae", T.DoubleType(), True),
        T.StructField("lasso_mape", T.DoubleType(), True),
        T.StructField("lasso_r2", T.DoubleType(), True),
        T.StructField("correlation", T.DoubleType(), True),
        T.StructField("calculated_rank", T.DoubleType(), True),
        T.StructField("final_rank", T.IntegerType(), True),
    ])

    output_schema = T.StructType([
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("variable_cd", T.StringType(), True),
        T.StructField("variable_importance_rank", T.LongType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
    ])
