from pyspark.sql import types as T


class CampaignDecayType:
    campaign_decay_rate_dtp_schema = T.StructType([
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("reporting_dt", T.StringType(), True),
        T.StructField("impressions_cnt", T.IntegerType(), True),
        T.StructField("cumulative_impressions_cnt", T.IntegerType(), True),
        T.StructField("offsite_impressions_pct", T.DoubleType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("job_run_id", T.StringType(), True)
    ])

    campaign_decay_rate_pollen_schema = T.StructType([
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("reporting_dt", T.StringType(), True),
        T.StructField("impressions_cnt", T.IntegerType(), True),
        T.StructField("cumulative_impressions_cnt", T.IntegerType(), True),
        T.StructField("offsite_impressions_pct", T.DoubleType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("job_run_id", T.StringType(), True)
    ])
