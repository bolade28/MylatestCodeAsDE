from pyspark.sql import types as T


class SecondarySpace:
    baseline_specific_attributes_schema = T.StructType([
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True)
    ])

    secondary_space_planogram_schema = T.StructType([
        T.StructField("date_dt", T.DateType(), True),
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("store_cd", T.StringType(), True),
        T.StructField("section_id", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
    ])

    secondary_space_dim_section_schema = T.StructType([
        T.StructField("section_id", T.StringType(), True),
        T.StructField("section_type_desc", T.StringType(), True),
        T.StructField("section_created_ts", T.TimestampType(), True),
        T.StructField("section_expired_ts", T.TimestampType(), True),
    ])

    secondary_space_filtered_planogram_schema = T.StructType([
        T.StructField("date_dt", T.DateType(), True),
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("store_cd", T.StringType(), True),
        T.StructField("section_id", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
    ])

    secondary_space_baseline_specific_attributes_schema = T.StructType([
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
    ])

    secondary_space_ranged_items_schema = T.StructType([
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
    ])

    secondary_space_metric_grid_schema = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
    ])
