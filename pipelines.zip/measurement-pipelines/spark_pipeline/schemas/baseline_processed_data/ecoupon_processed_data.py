from pyspark.sql import types as T


class EcouponProcessedData:

    ecoupon_base_finance_assets_input_schema = T.StructType([
        T.StructField("asset_actual_start_date", T.DateType(), True),
        T.StructField("asset_actual_end_date", T.DateType(), True),
        T.StructField("media_host_name", T.StringType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("timeid", T.IntegerType(), True),
        T.StructField("campaign_status", T.StringType(), True),
        T.StructField("asset_value_unweighted", T.DoubleType(), True),
        T.StructField("asset_unique_id", T.StringType(), True),
    ])

    ecoupon_oc_campaign_input_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("base_asset_id", T.StringType(), True),
        T.StructField("start_date", T.DateType(), True),
        T.StructField("expiry_date", T.DateType(), True),
    ])

    ecoupon_oc_products_input_schema = T.StructType([
        T.StructField("product_key", T.StringType(), True),
        T.StructField("base_asset_id", T.StringType(), True),
    ])

    ecoupon_customer_selection_input_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("base_asset_id", T.StringType(), True),
        T.StructField("status", T.StringType(), True),
        T.StructField("coupon_id", T.StringType(), True),
    ])

    ecoupon_base_brand_campaign_schema = T.StructType([
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("base_start_date", T.DateType(), True),
        T.StructField("base_end_date", T.DateType(), True),
        T.StructField("value_", T.DoubleType(), True),
        T.StructField("cid", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("base_asset_id", T.StringType(), True),
        T.StructField("start_date", T.DateType(), True),
        T.StructField("expiry_date", T.DateType(), True),
    ])

    ecoupon_base_value_brand_sku_schema = T.StructType([
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("base_start_date", T.DateType(), True),
        T.StructField("base_end_date", T.DateType(), True),
        T.StructField("base_value", T.DoubleType(), True),
        T.StructField("cid", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("base_asset_id", T.StringType(), True),
        T.StructField("start_date", T.DateType(), True),
        T.StructField("expiry_date", T.DateType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
    ])

    ecoupon_performance_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("base_asset_id", T.StringType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("base_start_date", T.DateType(), True),
        T.StructField("base_end_date", T.DateType(), True),
        T.StructField("base_value", T.DoubleType(), True),
        T.StructField("cid", T.StringType(), True),
        T.StructField("start_date", T.DateType(), True),
        T.StructField("expiry_date", T.DateType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("coupon_value", T.DoubleType(), True),
    ])

    ecoupon_campaign_booking_input_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), False),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("channel_type", T.StringType(), True),
        T.StructField("booking_status", T.StringType(), True),
        T.StructField("media_provider", T.StringType(), True),
        T.StructField("media_business_group", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("booking_media_live_start_dt", T.DateType(), True),
        T.StructField("booking_media_live_end_dt", T.DateType(), True),
        T.StructField("item_cd_list", T.StringType(), True),
    ])

    ecoupon_pollen_base_schema = T.StructType([
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("base_start_date", T.DateType(), True),
        T.StructField("base_end_date", T.DateType(), True),
        T.StructField("base_value", T.DoubleType(), True),
        T.StructField("cid", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("coupon_value", T.DoubleType(), True),
    ])

    ecoupon_onsite_campaigns_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
    ])

    ecoupon_unpivot_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("value_", T.DoubleType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
    ])
