from pyspark.sql import types as T


class BasePriceDataSchema:
    base_price_schema = T.StructType([
        T.StructField('week_start_dt', T.DateType(), True),
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('marketing_type_name', T.StringType(), True),
        T.StructField('marketing_channel_name', T.StringType(), True),
        T.StructField('marketing_sub_channel_name', T.StringType(), True),
        T.StructField('cluster_num', T.StringType(), True),
        T.StructField('metric', T.StringType(), True),
        T.StructField('metric_name', T.StringType(), True),
        T.StructField('metric_value', T.DoubleType(), True),
        T.StructField('job_run_id', T.StringType(), True),
        T.StructField('load_ts', T.TimestampType(), True),
        T.StructField('technical_metadata', T.StringType(), True),
    ])

    base_price_no_dates_schema = T.StructType([
        T.StructField('week_start_dt', T.DateType(), True),
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('marketing_type_name', T.StringType(), True),
        T.StructField('marketing_channel_name', T.StringType(), True),
        T.StructField('marketing_sub_channel_name', T.StringType(), True),
        T.StructField('cluster_num', T.StringType(), True),
        T.StructField('metric', T.StringType(), True),
        T.StructField('metric_name', T.StringType(), True),
        T.StructField('metric_value', T.DoubleType(), True),
        T.StructField('job_run_id', T.StringType(), True),
    ])

    # Intermediates for unit tests
    fact_sales_base_price_schema = T.StructType([
        T.StructField("transaction_dt", T.TimestampType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("store_cd", T.StringType(), True),
        T.StructField("base_unit_price_amt", T.DoubleType(), True),
    ])

    weekly_item_base_price_schema = T.StructType([
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("base_unit_price_amt", T.DoubleType(), True),
    ])

    transactions_with_cluster_information_schema = T.StructType([
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("base_unit_price_amt", T.DoubleType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
    ])
