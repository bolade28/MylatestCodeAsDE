from pyspark.sql import types as T


class InstoreProcessedData:
    instore_ie_product_input_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("product_key", T.StringType(), True),
    ])

    instore_ie_location_input_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("media_no", T.IntegerType(), True),
        T.StructField("location_key", T.StringType(), True),
    ])

    instore_ie_campaign_filt_input_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("start_date", T.DateType(), True),
        T.StructField("end_date", T.DateType(), True),
        T.StructField("media_cost", T.DoubleType(), True),
        T.StructField("npd", T.StringType(), True),
    ])

    instore_media_instore_init_input_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("targeted_id", T.StringType(), True),
        T.StructField("media_no", T.IntegerType(), True),
    ])

    instore_is_active_filter_input_schema = T.StructType([
        T.StructField("media_no", T.IntegerType(), True),
    ])

    instore_processed_data_schema = T.StructType([
        T.StructField('week_start_dt', T.DateType(), True),
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('cluster_num', T.StringType(), True),
        T.StructField('marketing_type_name', T.StringType(), True),
        T.StructField('marketing_channel_name', T.StringType(), True),
        T.StructField('marketing_sub_channel_name', T.StringType(), True),
        T.StructField('metric_name', T.StringType(), True),
        T.StructField('metric_value', T.DecimalType(10, 0), True)
    ])

    instore_dtp_output_schema = instore_processed_data_schema

    instore_processed_data_pollen_schema = T.StructType([
        T.StructField('week_start_dt', T.DateType(), True),
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('cluster_num', T.StringType(), True),
        T.StructField('marketing_type_name', T.StringType(), True),
        T.StructField('marketing_channel_name', T.StringType(), True),
        T.StructField('marketing_sub_channel_name', T.StringType(), True),
        T.StructField('metric_name', T.StringType(), True),
        T.StructField('metric_value', T.DecimalType(18, 5), True)
    ])

    instore_campaign_booking_input_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), False),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("channel_type", T.StringType(), True),
        T.StructField("booking_status", T.StringType(), True),
        T.StructField("media_provider", T.StringType(), True),
        T.StructField("media_business_group", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("booking_media_live_start_dt", T.StringType(), True),
        T.StructField("booking_media_live_end_dt", T.StringType(), True),
        T.StructField("item_cd_list", T.StringType(), True),
        T.StructField("store_cd_list", T.StringType(), True),
    ])

    instore_campaign_bookings_output_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), False),
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("invalid_date_range", T.BooleanType(), True),
        T.StructField("store_cd_list", T.ArrayType(T.StringType()), True),
        T.StructField(
            "item_cd_list",
            T.ArrayType(
                T.StructType([
                    T.StructField("skuId", T.StringType(), True),
                ])
            ),
            True,
        ),
    ])

    instore_store_flattened_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), False),
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("location_key", T.StringType(), True),
    ])

    instore_items_flattened_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), False),
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
    ])

    instore_campaign_items_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), False),
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
    ])

    instore_campaigns_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("invalid_date_range", T.BooleanType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("location_key", T.StringType(), True),
    ])

    instore_campaigns_location_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("invalid_date_range", T.BooleanType(), True),
        T.StructField("location_key", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
    ])

    instore_campaign_durations_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("media_cost", T.DoubleType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("campaign_days", T.IntegerType(), True),
    ])

    instore_split_costs_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("media_cost", T.DoubleType(), True),
        T.StructField("split_media_cost", T.DoubleType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("number_skus", T.LongType(), True),
        T.StructField("campaign_days", T.IntegerType(), True),
    ])

    instore_daily_costs_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("media_cost_per_day", T.DoubleType(), True),
        T.StructField("date_", T.DateType(), True),
    ])

    instore_weekly_media_schema = T.StructType([
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("total_media_cost", T.DoubleType(), True),
    ])

    instore_cust_by_location_schema = T.StructType([
        T.StructField("date_", T.TimestampType(), True),
        T.StructField("store_cd", T.StringType(), True),
        T.StructField("distinct_customers", T.LongType(), True),
    ])

    instore_weekly_exposed_schema = T.StructType([
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("exposed_customers", T.LongType(), True),
    ])

    instore_weekly_brand_metrics_schema = T.StructType([
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("total_media_cost", T.DoubleType(), True),
        T.StructField("exposed_customers", T.LongType(), True),
    ])

    instore_hierarchy_schema = T.StructType([
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("total_media_cost", T.DecimalType(10, 0), True),
        T.StructField("exposed_customers", T.DecimalType(10, 0), True),
    ])

    instore_unpivot_schema = T.StructType([
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("value", T.DecimalType(10, 0), True),
        T.StructField("job_run_id", T.StringType(), True),
    ])

    instore_merge_input_schema = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
    ])

    instore_merge_output_schema = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("metric_value", T.DecimalType(18, 5), True),
        T.StructField("job_run_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
    ])

    # Explicit aliases for formerly test-local shared schemas
    INSTORES_CAMPAIGNS_LOCATION_SCHEMA = instore_campaigns_location_schema
    CUST_BY_LOCATION_SCHEMA = instore_cust_by_location_schema
