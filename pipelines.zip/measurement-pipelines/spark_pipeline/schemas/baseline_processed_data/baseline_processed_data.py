from pyspark.sql import types as T


def _build_processed_output_schema(
    week_start_type,
    metric_value_type,
    *,
    include_job_run_id=False,
    include_load_ts=False,
    load_ts_type=None,
    include_run_date=False,
    job_run_id_nullable=True,
    load_ts_nullable=True,
    run_date_nullable=True,
):
    """
    Return a standard output for the processed-data scripts with optional runtime fields.

    The base schema contains the common processed-data dimensions plus
    `metric_name` and `metric_value`. Keyword-only flags can be used to append
    `job_run_id`, `load_ts`, and `run_date` as they differ slightly across scripts and are not always needed.

    Args:
        week_start_type: Spark type for `week_start_dt`.
        metric_value_type: Spark type for `metric_value`.
        include_job_run_id: Include `job_run_id`.
        include_load_ts: Include `load_ts`.
        load_ts_type: Spark type for `load_ts`; defaults to `T.TimestampType()`.
        include_run_date: Include `run_date`.
        job_run_id_nullable: Nullability of `job_run_id`.
        load_ts_nullable: Nullability of `load_ts`.
        run_date_nullable: Nullability of `run_date`.

    Returns:
        T.StructType for the requested processed-data schema.
    """

    fields = [
        T.StructField("week_start_dt", week_start_type, True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("metric_value", metric_value_type, True),
    ]

    if include_job_run_id:
        fields.append(T.StructField("job_run_id", T.StringType(), job_run_id_nullable))

    if include_load_ts:
        fields.append(T.StructField("load_ts", load_ts_type or T.TimestampType(), load_ts_nullable))

    if include_run_date:
        fields.append(T.StructField("run_date", T.StringType(), run_date_nullable))

    return T.StructType(fields)


class ProcessedData:
    """
    Shared schema definitions for all processed data scripts and
    schema definitions used for unit tests across all processed data scripts.
    """

    # Defines the schema for column item_cd_list coming from the campaign_booking_media_channel source.
    # So we can parse it from a JSON string into an array.
    item_schema = T.ArrayType(
        T.StructType([
            T.StructField("skuId", T.StringType(), True),
        ])
    )

    # Common shared schemas across processed data scripts
    store_hierarchy_schema = T.StructType([
        T.StructField("store_cd", T.StringType(), True),
        T.StructField("site_type", T.StringType(), True),
    ])

    weekly_dates_schema = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
    ])

    temp_unified_product_input_schema = T.StructType([
        T.StructField("product_key", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
    ])

    sku_cluster_mapping_schema = T.StructType([
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
    ])

    weekly_cluster_base_price_schema = T.StructType([
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
    ])

    filled_weekly_cluster_base_price_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("final_value", T.DoubleType(), True),
    ])

    # Shared final / merge schemas used by multiple processed-data pipelines.
    # ToDo: Unify all processed data outputs and tests so they use the same schema
    shared_date_output_with_load_ts_double_schema = _build_processed_output_schema(
        T.DateType(),
        T.DoubleType(),
        include_job_run_id=True,
        include_load_ts=True,
    )

    shared_date_output_decimal_38_2_schema = _build_processed_output_schema(
        T.DateType(),
        T.DecimalType(38, 2),
        include_job_run_id=True,
    )

    shared_timestamp_output_with_load_ts_decimal_38_10_schema = _build_processed_output_schema(
        T.DateType(),
        T.DecimalType(38, 10),
        include_job_run_id=True,
        include_load_ts=True,
    )

    shared_date_merge_input_schema = _build_processed_output_schema(
        T.DateType(),
        T.DoubleType(),
    )

    citrus_output_schema = _build_processed_output_schema(
        T.DateType(),
        T.DecimalType(38, 0),
    )

    meta_output_schema = _build_processed_output_schema(
        T.DateType(),
        T.DecimalType(18, 5),
    )

    shared_timestamp_output_with_job_run_id_double_schema = _build_processed_output_schema(
        T.TimestampType(),
        T.DoubleType(),
        include_job_run_id=True,
    )

    shared_date_output_with_load_ts_decimal_18_5_schema = _build_processed_output_schema(
        T.DateType(),
        T.DecimalType(18, 5),
        include_job_run_id=True,
        include_load_ts=True,
    )

    shared_timestamp_output_with_load_ts_decimal_18_5_schema = _build_processed_output_schema(
        T.TimestampType(),
        T.DecimalType(18, 5),
        include_job_run_id=True,
        include_load_ts=True,
    )

    promotional_discount_output_no_load_ts_schema = _build_processed_output_schema(
        T.DateType(),
        T.DoubleType(),
        include_job_run_id=True,
    )

    secondary_space_output_no_load_ts_schema = _build_processed_output_schema(
        T.DateType(),
        T.DoubleType(),
        include_job_run_id=True,
        include_run_date=True,
    )

    validation_metrics_input_schema = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("metric_value", T.DecimalType(38, 10), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
    ])
