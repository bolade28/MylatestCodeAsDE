from pyspark.sql import types as T


class CouponAtTillProcessedData:
    weekly_dates_schema = T.StructType([
        T.StructField('week_start_dt', T.DateType(), True)
    ])

    unified_product_schema = T.StructType([
        T.StructField('item_cd', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('super_cat_name', T.StringType(), True),
    ])

    base_finance_assets_input_schema = T.StructType([
        T.StructField("asset_actual_start_date", T.DateType(), True),
        T.StructField("asset_actual_end_date", T.DateType(), True),
        T.StructField("service_type", T.StringType(), True),
        T.StructField("media_host_name", T.StringType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("timeid", T.IntegerType(), True),
        T.StructField("campaign_status", T.StringType(), True),
        T.StructField("asset_value_unweighted", T.DecimalType(38, 2), True),
        T.StructField("asset_unique_id", T.StringType(), True),
    ])

    coupon_schema = T.StructType([
        T.StructField('coupon_key', T.StringType(), True),
        T.StructField('start_date', T.DateType(), True),
        T.StructField('expiry_date', T.DateType(), True),
        T.StructField('coupon_value', T.DecimalType(38, 2), True)
    ])

    coupon_cell_schema = T.StructType([
        T.StructField('cell_key', T.StringType(), True),
        T.StructField('coupon_key', T.StringType(), True)
    ])

    cell_schema = T.StructType([
        T.StructField('campaign_id', T.StringType(), True),
        T.StructField('cell_key', T.StringType(), True)
    ])

    campaign_schema = T.StructType([
        T.StructField('campaign_id', T.StringType(), True),
        T.StructField('pre_period', T.StringType(), True),
        T.StructField('post_period', T.StringType(), True)
    ])

    coupon_to_product_schema = T.StructType([
        T.StructField('coupon_key', T.StringType(), True),
        T.StructField('product_key', T.StringType(), True),
        T.StructField('correct_brand', T.StringType(), True),
        T.StructField('correct_offer', T.StringType(), True)
    ])

    coupon_at_till_processed_schema = T.StructType([
        T.StructField('week_start_dt', T.DateType(), True),
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('cluster_num', T.StringType(), True),
        T.StructField('marketing_type_name', T.StringType(), True),
        T.StructField('marketing_channel_name', T.StringType(), True),
        T.StructField('marketing_sub_channel_name', T.StringType(), True),
        T.StructField('metric_name', T.StringType(), True),
        T.StructField('metric_value', T.DecimalType(38, 2), True),
        T.StructField('job_run_id', T.StringType(), True)
    ])

    coupon_at_till_campaign_booking_input_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), False),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("channel_type", T.StringType(), True),
        T.StructField("booking_status", T.StringType(), True),
        T.StructField("media_provider", T.StringType(), True),
        T.StructField("media_business_group", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("booking_media_live_start_dt", T.DateType(), True),
        T.StructField("booking_media_live_end_dt", T.DateType(), True),
        T.StructField("item_cd_list", T.StringType(), True),
    ])
