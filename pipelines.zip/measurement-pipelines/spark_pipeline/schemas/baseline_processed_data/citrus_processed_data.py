from pyspark.sql import types as T


class CitrusProcessedData:
    advertise_request_realised_schema = T.StructType([
        T.StructField('item_id', T.StringType(), True),
    ])

    sku_cluster_mapping_schema = T.StructType([
        T.StructField('item_cd', T.DecimalType(38, 0), True),
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('cluster_num', T.StringType(), True),
        T.StructField('load_ts', T.StringType(), True),
        T.StructField('excluded_from_ucm_flag', T.IntegerType(), True)
    ])

    weekly_dates_schema = T.StructType([
        T.StructField('week_start_dt', T.DateType(), True)
    ])

    citrus_processed_data_schema = T.StructType([
        T.StructField('week_start_dt', T.DateType(), True),
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('cluster_num', T.StringType(), True),
        T.StructField('marketing_type_name', T.StringType(), True),
        T.StructField('marketing_channel_name', T.StringType(), True),
        T.StructField('marketing_sub_channel_name', T.StringType(), True),
        T.StructField('metric_name', T.StringType(), True),
        T.StructField('metric_value', T.DecimalType(38, 0), True)
    ])

    citrus_loaded_request_schema = T.StructType([
        T.StructField("ingressed_at_dt", T.TimestampType(), True),
        T.StructField("sales_revenue_amt", T.DoubleType(), True),
        T.StructField("advertising_revenue_amt", T.DoubleType(), True),
        T.StructField("advertising_spend_amt", T.DoubleType(), True),
        T.StructField("impressions_cnt", T.DoubleType(), True),
        T.StructField("clicks_cnt", T.DoubleType(), True),
        T.StructField("conversions_cnt", T.DoubleType(), True),
        T.StructField("unit_sales_cnt", T.DoubleType(), True),
        T.StructField("item_cd", T.StringType(), True),
    ])

    citrus_ad_request_realised_schema = T.StructType([
        T.StructField("ingressed_at_dt", T.TimestampType(), True),
        T.StructField("sales_revenue_amt", T.DoubleType(), True),
        T.StructField("advertising_revenue_amt", T.DoubleType(), True),
        T.StructField("advertising_spend_amt", T.DoubleType(), True),
        T.StructField("impressions_cnt", T.DoubleType(), True),
        T.StructField("clicks_cnt", T.DoubleType(), True),
        T.StructField("unit_sales_cnt", T.DoubleType(), True),
        T.StructField("conversions_cnt", T.DoubleType(), True),
        T.StructField("item_id", T.StringType(), True),
    ])

    citrus_unpivoted_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True),
    ])

    citrus_item_cluster_schema = T.StructType([
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("ingressed_at_dt", T.TimestampType(), True),
        T.StructField("sales_revenue_amt", T.DoubleType(), True),
        T.StructField("advertising_revenue_amt", T.DoubleType(), True),
        T.StructField("advertising_spend_amt", T.DoubleType(), True),
        T.StructField("impressions_cnt", T.DoubleType(), True),
        T.StructField("clicks_cnt", T.DoubleType(), True),
        T.StructField("conversions_cnt", T.DoubleType(), True),
        T.StructField("unit_sales_cnt", T.DoubleType(), True),
    ])

    citrus_weekly_cluster_metrics_schema = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("sales_revenue", T.DoubleType(), True),
        T.StructField("ad_revenue", T.DoubleType(), True),
        T.StructField("ad_spend", T.DoubleType(), True),
        T.StructField("impressions", T.DoubleType(), True),
        T.StructField("clicks", T.DoubleType(), True),
        T.StructField("conversions", T.DoubleType(), True),
        T.StructField("unit_sales", T.DoubleType(), True),
    ])

    citrus_metric_grid_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("sales_revenue", T.DoubleType(), True),
        T.StructField("ad_revenue", T.DoubleType(), True),
        T.StructField("ad_spend", T.DoubleType(), True),
        T.StructField("impressions", T.DoubleType(), True),
        T.StructField("clicks", T.DoubleType(), True),
        T.StructField("conversions", T.DoubleType(), True),
        T.StructField("unit_sales", T.DoubleType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
    ])
