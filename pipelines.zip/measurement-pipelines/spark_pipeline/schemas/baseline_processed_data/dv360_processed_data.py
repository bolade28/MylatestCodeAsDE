from pyspark.sql import types as T


class DV360ProcessedData:
    dv360_normalised_dtp_input_schema = T.StructType([
        T.StructField("start_dt", T.DateType(), True),
        T.StructField("end_dt", T.DateType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("jobbagid", T.StringType(), True),
        T.StructField("channel", T.StringType(), True),
    ])

    dv360_normalised_pollen_input_schema = T.StructType([
        T.StructField("start_dt", T.DateType(), True),
        T.StructField("end_dt", T.DateType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
    ])

    dv360_media_report_dtp_input_schema = T.StructType([
        T.StructField("jobbag_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("measurable_impressions", T.DoubleType(), True),
        T.StructField("viewable_impressions", T.DoubleType(), True),
        T.StructField("clicks", T.DoubleType(), True),
        T.StructField("impressions", T.DoubleType(), True),
        T.StructField("revenue", T.DoubleType(), True),
    ])

    dv60_pollen_media_report_input_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("insertion_order_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("measurable_impressions", T.DecimalType(38, 2), True),
        T.StructField("viewable_impressions", T.DecimalType(38, 2), True),
        T.StructField("clicks", T.DecimalType(38, 2), True),
        T.StructField("impressions", T.DecimalType(38, 2), True),
        T.StructField("revenue", T.DecimalType(38, 2), True),
    ])

    dv360_sku_counts_schema = T.StructType([
        T.StructField("jobbagid", T.StringType(), True),
        T.StructField("number_of_skus", T.LongType(), True),
    ])

    dv360_campaign_sku_metrics_schema = T.StructType([
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("jobbagid", T.StringType(), True),
        T.StructField("sku_no", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("impressions", T.DoubleType(), True),
        T.StructField("clicks", T.DoubleType(), True),
        T.StructField("campaign_spend", T.DoubleType(), True),
        T.StructField("measurable_impressions", T.DoubleType(), True),
        T.StructField("viewable_impressions", T.DoubleType(), True),
    ])

    dv360_weekly_sku_metrics_schema = T.StructType([
        T.StructField("master_campaign_id", T.StringType(), True),
        T.StructField("sku_no", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("impressions", T.DoubleType(), True),
        T.StructField("clicks", T.DoubleType(), True),
        T.StructField("campaign_spend", T.DoubleType(), True),
        T.StructField("measurable_impressions", T.DoubleType(), True),
        T.StructField("viewable_impressions", T.DoubleType(), True),
    ])

    dv360_cluster_metrics_schema = T.StructType([
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("impressions", T.DoubleType(), True),
        T.StructField("clicks", T.DoubleType(), True),
        T.StructField("measurable_impressions", T.DoubleType(), True),
        T.StructField("viewable_impressions", T.DoubleType(), True),
        T.StructField("campaign_spend", T.DoubleType(), True),
    ])

    dv360_unpivot_schema = T.StructType([
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
    ])
