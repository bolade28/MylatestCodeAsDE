from pyspark.sql import types as T


class PromotionalDiscountProcessedData:
    promotional_discount_transaction_sale_return_schema = T.StructType([
        T.StructField("transaction_id", T.StringType(), True),
        T.StructField("transaction_dt", T.TimestampType(), True),
        T.StructField("net_retail_sales_amt", T.DoubleType(), True),
        T.StructField("pre_promotional_sale_amt", T.DoubleType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("item_type_sale_or_return", T.StringType(), True),
        T.StructField("uom_cd", T.StringType(), True),
        T.StructField("item_qty", T.DoubleType(), True),
    ])

    promotional_discount_item_brand_hist_input_schema = T.StructType([
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("sub_cat_name", T.StringType(), True),
        T.StructField("super_cat_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
    ])

    promotional_discount_item_brand_hist_schema = T.StructType([
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
    ])

    promotional_discount_transactional_item_data_schema = T.StructType([
        T.StructField("transaction_id", T.StringType(), True),
        T.StructField("transaction_dt", T.TimestampType(), True),
        T.StructField("net_retail_sales_amt", T.DoubleType(), True),
        T.StructField("pre_promotional_sale_amt", T.DoubleType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("item_type_sale_or_return", T.StringType(), True),
        T.StructField("uom_cd", T.StringType(), True),
        T.StructField("item_qty", T.DoubleType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("item_sale_qty", T.IntegerType(), True),
        T.StructField("item_return_qty", T.IntegerType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
    ])

    promotional_discount_sales_per_cluster_schema = T.StructType([
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("net_sales_in_cluster", T.DoubleType(), True),
        T.StructField("pre_promo_sales_in_cluster", T.DoubleType(), True),
        T.StructField("cluster_num_brands", T.LongType(), True),
    ])

    promotional_discount_sales_per_supercategory_schema = T.StructType([
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("total_net_sales_subcat", T.DoubleType(), True),
        T.StructField("total_pre_promo_sales_subcat", T.DoubleType(), True),
        T.StructField("total_num_brands_subcat", T.LongType(), True),
    ])

    promotional_discount_per_cluster_schema = T.StructType([
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("non_cluster_num_brands", T.LongType(), True),
        T.StructField("discount_perc", T.DoubleType(), True),
        T.StructField("non_cluster_discount_perc", T.DoubleType(), True),
    ])

    promotional_discount_skeleton_metrics_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("discount_perc", T.DoubleType(), True),
        T.StructField("non_cluster_discount_perc", T.DoubleType(), True),
        T.StructField("num_brands", T.LongType(), True),
    ])

    promotional_discount_unpivoted_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
    ])
