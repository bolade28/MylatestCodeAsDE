from pyspark.sql import types as T


class ValueIndexProcessedData:
    value_index_dashboard_input_schema = T.StructType([
        T.StructField("primary_item_cd", T.StringType(), True),
        T.StructField("primary_annual_sales_amt", T.DecimalType(38, 2), True),
        T.StructField("secondary_annual_sales_amt", T.DecimalType(38, 2), True),
        T.StructField("secondary_retailer_cd", T.StringType(), True),
        T.StructField("process_dt", T.DateType(), True),
    ])

    value_index_skeleton_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
    ])

    value_index_dashboard_renamed_schema = T.StructType([
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("primary_annual_sales_amt", T.DecimalType(38, 2), True),
        T.StructField("secondary_annual_sales_amt", T.DecimalType(38, 2), True),
        T.StructField("secondary_retailer_cd", T.StringType(), True),
        T.StructField("process_dt", T.DateType(), True),
    ])

    value_index_item_cd_cluster_schema = T.StructType([
        T.StructField("primary_annual_sales_amt", T.DecimalType(38, 2), True),
        T.StructField("secondary_annual_sales_amt", T.DecimalType(38, 2), True),
        T.StructField("secondary_retailer_cd", T.StringType(), True),
        T.StructField("process_dt", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
    ])

    value_index_all_metrics_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("all_retailer_value_index", T.DecimalType(38, 2), True),
        T.StructField("key_retailer_value_index", T.DecimalType(38, 2), True),
    ])

    value_index_joined_skeleton_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
        T.StructField("all_retailer_value_index", T.DecimalType(38, 2), True),
        T.StructField("key_retailer_value_index", T.DecimalType(38, 2), True),
    ])

    value_index_unpivoted_schema = T.StructType([
        T.StructField("week_start_date", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("value", T.DecimalType(38, 2), True),
        T.StructField("job_run_id", T.StringType(), True),
    ])
