from pyspark.sql import types as T


class SalesProcessedData:

    sales_data_transaction_input_schema = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("total_sales_amt", T.DoubleType(), True),
    ])
