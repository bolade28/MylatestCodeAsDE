from pyspark.sql import types as T


class YouTubeProcessedData:
    youtube_normalised_input_schema = T.StructType([
        T.StructField("start_dt", T.DateType(), True),
        T.StructField("end_dt", T.DateType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
    ])

    youtube_normalize_dtp_input_schema = T.StructType([
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("jobbagid", T.StringType(), True),
        T.StructField("start_dt", T.DateType(), True),
        T.StructField("end_dt", T.DateType(), True),
    ])

    youtube_media_report_dtp_input_schema = T.StructType([
        T.StructField("jobbag_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("impressions", T.DecimalType(38, 2), True),
        T.StructField("clicks", T.DecimalType(38, 2), True),
        T.StructField("revenue", T.DecimalType(38, 2), True),
        T.StructField("measurable_impressions", T.DecimalType(38, 2), True),
        T.StructField("viewable_impressions", T.DecimalType(38, 2), True),
    ])

    youtube_required_campaigns_schema = T.StructType([
        T.StructField("start_dt", T.DateType(), True),
        T.StructField("end_dt", T.DateType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
    ])

    youtube_sku_counts_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("number_of_skus", T.LongType(), True),
    ])

    youtube_cluster_metrics_schema = T.StructType([
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("impressions", T.DecimalType(38, 8), True),
        T.StructField("clicks", T.DecimalType(38, 8), True),
        T.StructField("campaign_spend", T.DecimalType(38, 8), True),
        T.StructField("measurable_impressions", T.DecimalType(38, 8), True),
        T.StructField("viewable_impressions", T.DecimalType(38, 8), True),
    ])

    youtube_unpivot_schema = T.StructType([
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("value", T.DecimalType(38, 8), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
    ])

    youtube_output_schema = T.StructType([
        T.StructField("week_start_dt", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("metric_value", T.DecimalType(38, 8), True),
        T.StructField("job_run_id", T.StringType(), True),
    ])

    youtube_processed_data_output_schema = T.StructType([
        T.StructField("week_start_dt", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("metric_value", T.DecimalType(38, 2), True),
        T.StructField("job_run_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField(
            "technical_metadata",
            T.StructType([
                T.StructField("effective_ts", T.TimestampType(), True),
            ]),
            True,
        ),
    ])
