from pyspark.sql import types as T


class MetaProcessedData:

    meta_campaign_normalize_schema = T.StructType([
        T.StructField("jobbagid", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("start_dt", T.DateType(), True),
        T.StructField("end_dt", T.DateType(), True),
        T.StructField("item_cd", T.StringType(), True),
    ])

    meta_insight_normalize_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("start_dt", T.TimestampType(), True),
        T.StructField("clicks", T.LongType(), True),
        T.StructField("impressions", T.LongType(), True),
        T.StructField("internals_media_spend", T.DoubleType(), True),
        T.StructField("externals_media_spend", T.DoubleType(), True),
    ])

    meta_campaign_skus_schema = T.StructType([
        T.StructField("job_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("start_dt", T.DateType(), True),
        T.StructField("end_dt", T.DateType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("item_cd_upper", T.StringType(), True),
    ])

    meta_metrics_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("clicks", T.LongType(), True),
        T.StructField("impressions", T.LongType(), True),
        T.StructField("internals_media_spend", T.DoubleType(), True),
        T.StructField("externals_media_spend", T.DoubleType(), True),
    ])

    meta_required_campaigns_schema = T.StructType([
        T.StructField("job_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("start_dt", T.DateType(), True),
        T.StructField("end_dt", T.DateType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("item_cd_upper", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
    ])

    meta_required_campaigns_columns_schema = T.StructType([
        T.StructField("job_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
    ])

    meta_reqd_metrics_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("clicks", T.LongType(), True),
        T.StructField("impressions", T.LongType(), True),
        T.StructField("internals_media_spend", T.DoubleType(), True),
        T.StructField("externals_media_spend", T.DoubleType(), True),
        T.StructField("job_id", T.StringType(), True),
    ])

    meta_metrics_jb_schema = T.StructType([
        T.StructField("job_id", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("clicks", T.LongType(), True),
        T.StructField("impressions", T.LongType(), True),
        T.StructField("internals_media_spend", T.DoubleType(), True),
        T.StructField("externals_media_spend", T.DoubleType(), True),
    ])

    meta_metrics_jb_sku_schema = T.StructType([
        T.StructField("job_id", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("clicks", T.LongType(), True),
        T.StructField("impressions", T.LongType(), True),
        T.StructField("internals_media_spend", T.DoubleType(), True),
        T.StructField("externals_media_spend", T.DoubleType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
    ])

    meta_num_skus_schema = T.StructType([
        T.StructField("job_id", T.StringType(), True),
        T.StructField("number_of_skus", T.LongType(), True),
    ])

    meta_camp_skus_split_schema = T.StructType([
        T.StructField("job_id", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("number_of_skus", T.LongType(), True),
        T.StructField("clicks", T.DoubleType(), True),
        T.StructField("impressions", T.DoubleType(), True),
        T.StructField("externals_media_spend", T.DoubleType(), True),
        T.StructField("internals_media_spend", T.DoubleType(), True),
    ])

    meta_camp_cluster_schema = T.StructType([
        T.StructField("job_id", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("number_of_skus", T.LongType(), True),
        T.StructField("clicks", T.DoubleType(), True),
        T.StructField("impressions", T.DoubleType(), True),
        T.StructField("externals_media_spend", T.DoubleType(), True),
        T.StructField("internals_media_spend", T.DoubleType(), True),
        T.StructField("cluster_num", T.StringType(), True),
    ])

    meta_unique_brand_cluster_schema = T.StructType([
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("week_start_date", T.TimestampType(), True),
        T.StructField("clicks", T.DoubleType(), True),
        T.StructField("impressions", T.DoubleType(), True),
        T.StructField("internals_media_spend", T.DoubleType(), True),
        T.StructField("externals_media_spend", T.DoubleType(), True),
    ])

    meta_skeleton_schema = T.StructType([
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
    ])

    meta_processed_data_intermediate_schema = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True),
    ])

    meta_unique_brand_cluster_unpivot_schema = T.StructType([
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("metric", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("marketing_sub_channel", T.StringType(), True),
    ])
