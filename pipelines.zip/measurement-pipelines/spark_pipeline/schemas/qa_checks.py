from pyspark.sql import types as T


class QAChecks:
    detail_schema = T.StructType([
        T.StructField("correlation_id", T.StringType(), False),
        T.StructField("type", T.StringType(), False),
        T.StructField("name", T.StringType(), False),
        T.StructField("expected_value", T.StringType(), True),
        T.StructField("outcome", T.StringType(), False),
        T.StructField("details", T.StringType(), False),
        T.StructField("additional_metadata", T.StringType(), False),
        T.StructField("load_timestamp", T.TimestampType(), False),
    ])

    # Schemas used in analytics unit tests
    # Subset of the measurement campaign reporting schema, used for QA checks and analytics validation metrics.
    measurement_campaign_reporting_schema = T.StructType([
        T.StructField("correlation_id", T.StringType()),
        T.StructField("campaign_duration", T.StringType()),
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_id", T.StringType()),
        T.StructField("journey_type", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType()),
        T.StructField("conversion_rate", T.DoubleType()),
        T.StructField("roas_exposed", T.DoubleType()),
        T.StructField("iroas_exposed", T.DoubleType()),
        T.StructField("uplift_exposed_sales_amt", T.DoubleType()),
        T.StructField("media_spend_amt", T.DoubleType()),
        T.StructField("incremental_sales_amt_exposed", T.DoubleType()),
        T.StructField("base_sales_amt_exposed", T.DoubleType()),
    ])

    # Diagnostics retained for each failed reporting row, in production sort order.
    analytics_failed_row_schema = T.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_id", T.StringType()),
        T.StructField("journey_type", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("value", T.DoubleType()),
        T.StructField("threshold", T.DoubleType()),
    ])

    # One aggregate row passed from the row-counting helpers to the QA formatter.
    analytics_validation_stats_schema = T.StructType([
        T.StructField("checked_count", T.LongType(), False),
        T.StructField("failed_count", T.LongType(), False),
        T.StructField("failed_rows", T.ArrayType(analytics_failed_row_schema), False),
    ])
