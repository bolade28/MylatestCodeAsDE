from pyspark.sql import types as T


class CampaignProductType:
    ean_br_schema = T.StructType([
        T.StructField('item_nk1', T.StringType(), True),
        T.StructField('brand_name', T.StringType(), True),
        T.StructField('brand_owner_name', T.StringType(), True),
        T.StructField('load_ts', T.TimestampType(), True),
        T.StructField('valid_from_dt', T.DateType(), True),
        T.StructField('record_deleted_flag', T.StringType(), True)
    ])

    dim_item_schema = T.StructType([
        T.StructField('item_cd', T.DecimalType(38, 0), True),
        T.StructField('item_name', T.StringType(), True),
        T.StructField('sub_cat_name', T.StringType(), True)
    ])

    unified_campaign_schema = T.StructType([
        T.StructField('item_cd_list', T.StringType(), True),
        T.StructField('channel_name', T.StringType(), True),
        T.StructField('subchannel_name', T.StringType(), True),
        T.StructField('sub_category_name', T.StringType(), True),
        T.StructField('booking_id', T.StringType(), True),
        T.StructField('campaign_id', T.StringType(), True),
        T.StructField('campaign_start_dt', T.DateType(), True),
        T.StructField('campaign_end_dt', T.DateType(), True)
    ])

    campaign_product_type_schema = T.StructType([
        T.StructField('item_cd', T.IntegerType(), True),
        T.StructField('product_type', T.StringType(), True),
        T.StructField('channel_name', T.StringType(), True),
        T.StructField('subchannel_name', T.StringType(), True),
        T.StructField('booking_id', T.StringType(), True),
        T.StructField('campaign_id', T.StringType(), True),
        T.StructField('job_run_id', T.StringType(), True),
        T.StructField('sku_name', T.StringType(), True),
        T.StructField('sub_cat_name', T.StringType(), True),
        T.StructField('brand_name', T.StringType(), True),
        T.StructField('brand_owner_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('load_ts', T.TimestampType(), True),
    ])
