from pyspark.sql import types as T


class SalesDataTransaction:
    ie_location_schema = T.StructType([
        T.StructField('location_cd', T.StringType(), True),
        T.StructField('site_type', T.StringType(), True)
    ])

    week_start_date_schema = T.StructType([
        T.StructField('week_start_dt', T.DateType(), True),
    ])

    unified_product_schema = T.StructType([
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('super_cat_name', T.StringType(), True),
        T.StructField('sku_no', T.DecimalType(38, 0), True),
        T.StructField('item_cd', T.DecimalType(38, 0), True),
        T.StructField('item_name', T.StringType(), True),
        T.StructField('std_item_total_wgt_or_vol_qty', T.DecimalType(38, 4), True),
        T.StructField('unit_or_item_weight_or_vol_qty', T.DecimalType(38, 4), True),
        T.StructField('base_price_amt', T.DecimalType(38, 4), True)
    ])

    fact_sales_transaction_item_schema = T.StructType([
        T.StructField('transaction_id', T.StringType(), True),
        T.StructField('transaction_dt', T.DateType(), True),
        T.StructField('net_retail_sales_amt', T.DecimalType(38, 4), True),
        T.StructField('item_cd', T.StringType(), True),
        T.StructField('store_cd', T.StringType(), True),
        T.StructField('item_sale_qty', T.DecimalType(38, 4), True),
        T.StructField('item_return_qty', T.DecimalType(38, 4), True)
    ])

    fact_sales_transaction_basket_schema = T.StructType([
        T.StructField('sales_origination_channel_cd', T.StringType(), True),
        T.StructField('transaction_id', T.StringType(), True),
        T.StructField('nectar_card_num_hash', T.StringType(), True)
    ])

    sales_data_transaction = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("item_cd", T.DecimalType(38, 0), True),
        T.StructField("total_sales_amt", T.DecimalType(38, 4), True),
        T.StructField("nectar_sales_amt", T.DecimalType(38, 4), True),
        T.StructField("non_nectar_sales_amt", T.DecimalType(38, 4), True),
        T.StructField("frequency_of_purchase", T.DecimalType(30, 0), True),
        T.StructField("distinct_customer_cnt", T.DecimalType(30, 0), True),
        T.StructField("avg_purchase_per_customer_cnt", T.DecimalType(36, 6), True),
        T.StructField("online_sales_pct", T.DecimalType(38, 10), True),
        T.StructField("supermarket_sales_pct", T.DecimalType(38, 10), True),
        T.StructField("convenience_sales_pct", T.DecimalType(38, 10), True),
        T.StructField("pack_size", T.DecimalType(38, 12), True),
        T.StructField("price_per_point", T.DecimalType(38, 12), True),
        T.StructField("base_price_amt", T.DecimalType(38, 12), True),
    ])
