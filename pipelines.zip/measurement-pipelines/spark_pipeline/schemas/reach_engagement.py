from pyspark.sql import types as T


class ReachEngagementSchema():
    measures_schema = T.StructType([
        T.StructField("conversion", T.StructType([
            T.StructField("acquired", T.IntegerType()),
            T.StructField("instore", T.IntegerType()),
            T.StructField("lapsed", T.IntegerType()),
            T.StructField("online", T.IntegerType()),
            T.StructField("percentage", T.IntegerType()),
            T.StructField("retained", T.IntegerType()),
            T.StructField("totals", T.IntegerType())
        ])),
        T.StructField("internals", T.StructType([
            T.StructField("cpa", T.IntegerType()),
            T.StructField("cpm_actual", T.DoubleType()),
            T.StructField("cpm_booked", T.DoubleType()),
            T.StructField("media_spend", T.DoubleType())
        ])),
        T.StructField("sales", T.StructType([
            T.StructField("instore", T.IntegerType()),
            T.StructField("online", T.IntegerType()),
            T.StructField("spend_per_customer", T.IntegerType()),
            T.StructField("total", T.DoubleType())
        ])),
        T.StructField("summary", T.StructType([
            T.StructField("clicks", T.IntegerType()),
            T.StructField("conversionrate", T.DoubleType()),
            T.StructField("ctr", T.IntegerType()),
            T.StructField("frequency", T.IntegerType()),
            T.StructField("impressions", T.IntegerType()),
            T.StructField("reach", T.IntegerType())
        ]))
    ])

    camp_request_link_schema = T.StructType([
        T.StructField("advertising_campaign_nk1", T.StringType(), True),
        T.StructField("ingressed_at_dt", T.DateType(), True),
        T.StructField("sales_revenue_amt", T.DoubleType(), True),
        T.StructField("conversions_cnt", T.IntegerType(), True),
        T.StructField("impressions_cnt", T.IntegerType(), True),
        T.StructField("clicks_cnt", T.IntegerType(), True),
    ])
