from pyspark.sql import types as T


class InStoreDataPollen:
    schema = T.StructType([
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("transaction_key", T.StringType(), True),
        T.StructField("event_dt", T.DateType(), True),
        T.StructField("event_ts", T.TimestampType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("campaign_name", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("event_name", T.StringType(), True),
        T.StructField("purchase_type", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("product_type", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("net_sales_amt", T.DecimalType(30, 4), True),
        T.StructField("units_qty", T.IntegerType(), True),
        T.StructField("job_run_id", T.StringType(), True),
    ])
