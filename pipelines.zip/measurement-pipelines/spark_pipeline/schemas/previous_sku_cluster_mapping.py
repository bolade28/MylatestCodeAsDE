from pyspark.sql import types as T


class PreviousSkuClusterMapping:

    schema = T.StructType([
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("job_run_id", T.StringType(), True),
        T.StructField("load_ts", T.StringType(), True),
        T.StructField("modelling_type", T.StringType(), True),
    ])
