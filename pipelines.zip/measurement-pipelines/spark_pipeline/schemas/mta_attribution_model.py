from pyspark.sql import types as T


class AttributionModel:

    schema = T.StructType([
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("transaction_key", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("customer_journey_type", T.StringType(), True),
        T.StructField("journey_type", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("isconversion", T.IntegerType(), True),
        T.StructField("regression_variable", T.StringType(), True),
        T.StructField("normalized_weights", T.DoubleType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("job_run_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
    ])

    reporting_aisle_schema = T.StructType([
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("normalized_weights", T.DoubleType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
    ])
