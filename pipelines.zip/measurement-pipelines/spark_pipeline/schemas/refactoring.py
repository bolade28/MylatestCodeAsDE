from pyspark.sql import types as T


class Refactoring:
    product_df_input_schema = T.StructType([
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('item_cd', T.StringType(), True)
    ])

    sales_cluster_schema = T.StructType([
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('item_cd', T.StringType(), True),
        T.StructField('week_start_dt', T.TimestampType(), True),
        T.StructField('total_sales_amt', T.DecimalType(38, 4), True),
        T.StructField('avg_purchase_per_customer_cnt', T.DecimalType(36, 6), True),
        T.StructField('online_sales_pct', T.DecimalType(38, 10), True),
        T.StructField('supermarket_sales_pct', T.DecimalType(38, 10), True),
        T.StructField('convenience_sales_pct', T.DecimalType(38, 10), True),
        T.StructField('price_per_point', T.DecimalType(38, 12), True),
        T.StructField('pack_size', T.DecimalType(38, 12), True),
        T.StructField('cluster_num', T.StringType(), True)
    ])

    cluster_features_df_schema = T.StructType([
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('load_ts', T.StringType(), True),
        T.StructField('cluster_num', T.StringType(), True),
        T.StructField('cluster_type', T.StringType(), True),
        T.StructField('feature', T.StringType(), True),
        T.StructField('cluster_average_value', T.DoubleType(), True),
        T.StructField('job_run_id', T.StringType(), True)
    ])

    fact_sale_transaction_item_schema = T.StructType([
        T.StructField('item_cd', T.StringType(), True),
        T.StructField('transaction_dt', T.TimestampType(), True)
    ])

    udf_cov_matrix_schema = T.StructType([
        T.StructField("super_category_name", T.StringType()),
        T.StructField("unique_brand_name", T.StringType()),
        T.StructField("covariance_json", T.StringType())
    ])

    skus_tagging_final_schema = T.StructType([
        T.StructField('item_cd', T.DecimalType(38, 0), True),
        T.StructField('super_category_name', T.StringType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('cluster_num', T.StringType(), True),
        T.StructField('job_run_id', T.StringType(), False),
        T.StructField('load_ts', T.TimestampType(), False),
        T.StructField('modelling_type', T.StringType(), False)
    ])
