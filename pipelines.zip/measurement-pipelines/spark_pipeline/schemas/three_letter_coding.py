from pyspark.sql.types import StructType, StructField, StringType, TimestampType, DoubleType


class ThreeLetterCoding():

    channel_processed_data_schema = StructType([
        StructField("marketing_sub_channel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
        StructField("unique_brand_name", StringType(), True),
        StructField("metric_name", StringType(), True),
        StructField("week_start_dt", StringType(), True),
        StructField("super_category_name", StringType(), True),
        StructField("job_run_id", StringType(), True),
        StructField("marketing_type_name", StringType(), True),
        StructField("cluster_num", StringType(), True),
        StructField("metric_value", DoubleType(), True),
        StructField("marketing_channel_name", StringType(), True)
    ])

    three_letter_coding_schema = StructType([
        StructField("final_code", StringType(), True),
        StructField("column_name", StringType(), True),
        StructField("original_column_value", StringType(), True)
    ])

    baseline_modelling_dataset_schema = StructType([
        StructField("marketing_channel_name", StringType(), True),
        StructField("variable_cd", StringType(), True),
        StructField("cluster_num", StringType(), True),
        StructField("marketing_type_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
        StructField("week_start_dt", StringType(), True),
        StructField("super_category_name", StringType(), True),
        StructField("metric_value", DoubleType(), True),
        StructField("unique_brand_name", StringType(), True),
        StructField("marketing_sub_channel_name", StringType(), True),
        StructField("metric_name", StringType(), True)
    ])
