from pyspark.sql import types as T


class SkuLevelAttributedSalesAndUnits:

    data_schema = (
        T.StructType([
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("campaign_duration", T.StringType(), True),
            T.StructField("load_ts", T.TimestampType(), True)
        ])
    )

    booking_schema = (
        T.StructType([
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("campaign_duration", T.StringType(), True)
        ])
    )

    sku_schema = (
        T.StructType([
            T.StructField('userjourney_id', T.StringType(), True),
            T.StructField('loyalty_id', T.StringType(), True),
            T.StructField('transaction_key', T.StringType(), True),
            T.StructField('booking_id', T.StringType(), True),
            T.StructField('customer_journey_type', T.StringType(), True),
            T.StructField('journey_type', T.StringType(), True),
            T.StructField('isconversion', T.BooleanType(), True),
            T.StructField('regression_variable', T.StringType(), True),
            T.StructField('normalized_weights', T.DoubleType(), True),
            T.StructField('avg_f1_score_test', T.DoubleType(), True),
            T.StructField('campaign_duration', T.StringType(), True),
            T.StructField('job_run_id', T.StringType(), True),
            T.StructField('load_ts', T.TimestampType(), True),
            T.StructField('channel_name', T.StringType(), True),
            T.StructField('subchannel_name', T.StringType(), True),
            T.StructField('marketing_type', T.StringType(), True),
            T.StructField('avg_f1_score_train', T.DoubleType(), True),
            T.StructField('event_dt', T.DateType(), True),
            T.StructField('item_cd', T.StringType(), True),
            T.StructField('net_sales_amt', T.DoubleType(), True),
            T.StructField('units_qty', T.IntegerType(), True),
            T.StructField('unique_brand_name', T.StringType(), True),
            T.StructField('week_start_dt', T.DateType(), True),
            T.StructField('campaign_start_dt', T.DateType(), True),
            T.StructField('campaign_end_dt', T.DateType(), True),
            T.StructField('campaign_id', T.StringType(), True)
        ])
    )

    # Schema for sku_level_attribution_result
    sku_level_attribution_schema = T.StructType([
        T.StructField('campaign_id', T.StringType(), True),
        T.StructField('channel_name', T.StringType(), True),
        T.StructField('userjourney_id', T.StringType(), True),
        T.StructField('loyalty_id', T.StringType(), True),
        T.StructField('booking_id', T.StringType(), True),
        T.StructField('customer_journey_type', T.StringType(), True),
        T.StructField('journey_type', T.StringType(), True),
        T.StructField('isconversion', T.IntegerType(), True),
        T.StructField('normalized_weights', T.FloatType(), True),
        T.StructField('campaign_duration', T.StringType(), True),
        T.StructField('event_dt', T.DateType(), True),
        T.StructField('item_cd', T.DecimalType(18, 5), True),
        T.StructField('net_sales_amt', T.DecimalType(30, 4), True),
        T.StructField('units_qty', T.DecimalType(30, 4), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('week_start_dt', T.StringType(), True),
        T.StructField('regression_variable', T.StringType(), True),
        T.StructField('subchannel_name', T.StringType(), True),
        T.StructField('attributed_sales_amt', T.FloatType(), True),
        T.StructField('attributed_units_qty', T.FloatType(), True),
        T.StructField('attributed_recalibrated_sales_amt', T.FloatType(), True),
        T.StructField('attributed_recalibrated_units_qty', T.FloatType(), True),
        T.StructField('job_run_id', T.StringType(), True),
        T.StructField('load_ts', T.TimestampType(), True),
        T.StructField('marketing_type', T.StringType(), True)
    ])

    reporting_aisle_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("normalized_weights", T.DoubleType(), True),
        T.StructField("journey_type", T.StringType(), True),
    ])

    dedup_based_on_item_cd = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("subchannel", T.StringType(), True),
        T.StructField("date", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("metric_value", T.DoubleType(), True)
    ])

    channel_hierarchy_schema = T.StructType([
        T.StructField("marketing_subchannel", T.StringType(), True),
        T.StructField("channel_type", T.StringType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True),
    ])

    transaction_schema = T.StructType([
        T.StructField('transaction_key', T.StringType(), True),
        T.StructField('campaign_id', T.StringType(), True),
        T.StructField('event_dt', T.DateType(), True),
        T.StructField('item_cd', T.StringType(), True),
        T.StructField('net_sales_amt', T.DoubleType(), True),
        T.StructField('units_qty', T.IntegerType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('week_start_dt', T.DateType(), True),
        T.StructField('campaign_start_dt', T.DateType(), True),
        T.StructField('campaign_end_dt', T.DateType(), True),
    ])

    transaction_window_schema = T.StructType([
        T.StructField('campaign_week_start_date', T.StringType(), True),
        T.StructField('campaign_week_end_date', T.StringType(), True),
    ])

    sku_result_schema = T.StructType([
        T.StructField('campaign_id', T.StringType(), True),
        T.StructField('userjourney_id', T.StringType(), True),
        T.StructField('loyalty_id', T.StringType(), True),
        T.StructField('transaction_key', T.StringType(), True),
        T.StructField('booking_id', T.StringType(), True),
        T.StructField('customer_journey_type', T.StringType(), True),
        T.StructField('journey_type', T.StringType(), True),
        T.StructField('isconversion', T.BooleanType(), True),
        T.StructField('regression_variable', T.StringType(), True),
        T.StructField('normalized_weights', T.DoubleType(), True),
        T.StructField('campaign_duration', T.StringType(), True),
        T.StructField('load_ts', T.TimestampType(), True),
        T.StructField('channel_name', T.StringType(), True),
        T.StructField('subchannel_name', T.StringType(), True),
        T.StructField('marketing_type', T.StringType(), True),
        T.StructField('event_dt', T.DateType(), True),
        T.StructField('item_cd', T.StringType(), True),
        T.StructField('net_sales_amt', T.DoubleType(), True),
        T.StructField('units_qty', T.IntegerType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('week_start_dt', T.DateType(), True),
        T.StructField('campaign_start_dt', T.DateType(), True),
        T.StructField('campaign_end_dt', T.DateType(), True),
    ])

    sku_result_window_schema = T.StructType([
        T.StructField('campaign_week_start_date', T.StringType(), True),
        T.StructField('campaign_week_end_date', T.StringType(), True),
    ])

    recalibrated_base_schema = T.StructType([
        T.StructField('campaign_id', T.StringType(), True),
        T.StructField('userjourney_id', T.StringType(), True),
        T.StructField('loyalty_id', T.StringType(), True),
        T.StructField('transaction_key', T.StringType(), True),
        T.StructField('booking_id', T.StringType(), True),
        T.StructField('customer_journey_type', T.StringType(), True),
        T.StructField('journey_type', T.StringType(), True),
        T.StructField('isconversion', T.BooleanType(), True),
        T.StructField('regression_variable', T.StringType(), True),
        T.StructField('normalized_weights', T.DoubleType(), True),
        T.StructField('campaign_duration', T.StringType(), True),
        T.StructField('channel_name', T.StringType(), True),
        T.StructField('subchannel_name', T.StringType(), True),
        T.StructField('marketing_type', T.StringType(), True),
        T.StructField('event_dt', T.DateType(), True),
        T.StructField('item_cd', T.StringType(), True),
        T.StructField('net_sales_amt', T.DoubleType(), True),
        T.StructField('units_qty', T.IntegerType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('week_start_dt', T.DateType(), True),
        T.StructField('campaign_start_dt', T.DateType(), True),
        T.StructField('campaign_end_dt', T.DateType(), True),
        T.StructField('factor', T.DoubleType(), True),
        T.StructField('is_offsite_channel', T.BooleanType(), True),
    ])

    recalibrated_enriched_schema = T.StructType([
        T.StructField('campaign_id', T.StringType(), True),
        T.StructField('userjourney_id', T.StringType(), True),
        T.StructField('loyalty_id', T.StringType(), True),
        T.StructField('transaction_key', T.StringType(), True),
        T.StructField('booking_id', T.StringType(), True),
        T.StructField('customer_journey_type', T.StringType(), True),
        T.StructField('journey_type', T.StringType(), True),
        T.StructField('isconversion', T.BooleanType(), True),
        T.StructField('regression_variable', T.StringType(), True),
        T.StructField('normalized_weights', T.DoubleType(), True),
        T.StructField('campaign_duration', T.StringType(), True),
        T.StructField('channel_name', T.StringType(), True),
        T.StructField('subchannel_name', T.StringType(), True),
        T.StructField('marketing_type', T.StringType(), True),
        T.StructField('event_dt', T.DateType(), True),
        T.StructField('item_cd', T.StringType(), True),
        T.StructField('net_sales_amt', T.DoubleType(), True),
        T.StructField('units_qty', T.IntegerType(), True),
        T.StructField('unique_brand_name', T.StringType(), True),
        T.StructField('week_start_dt', T.DateType(), True),
        T.StructField('campaign_start_dt', T.DateType(), True),
        T.StructField('campaign_end_dt', T.DateType(), True),
        T.StructField('factor', T.DoubleType(), True),
        T.StructField('attributed_sales_amt', T.DoubleType(), True),
        T.StructField('attributed_units_qty', T.DoubleType(), True),
        T.StructField('attributed_recalibrated_sales_amt', T.DoubleType(), True),
        T.StructField('attributed_recalibrated_units_qty', T.DoubleType(), True),
        T.StructField('underscore_count', T.IntegerType(), True),
        T.StructField('avg_factor', T.DoubleType(), True),
        T.StructField('is_offsite_channel', T.BooleanType(), True),
    ])
