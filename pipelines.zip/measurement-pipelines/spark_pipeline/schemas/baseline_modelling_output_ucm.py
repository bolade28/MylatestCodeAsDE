from pyspark.sql import types as T


class BaselineModellingOutput:

    expected_seasonality = T.StructType([
        T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
        T.StructField("SEASONALITY_LEVEL", T.StringType(), True)
    ])

    seasonality_threshold = T.StructType([
        T.StructField("SEASONALITY_LEVEL", T.StringType(), True),
        T.StructField("SEASONALITY_BENCHMARK", T.StringType(), True)
    ])

    old_baseline_output = T.StructType([
        T.StructField("super_category_name", T.StringType()),
        T.StructField("unique_brand_name", T.StringType()),
        T.StructField("cluster_num_old", T.StringType()),
        T.StructField("cluster_type", T.StringType()),
        T.StructField("total_baseline_amt_old", T.DoubleType()),
        T.StructField("total_incremental_amt_old", T.DoubleType()),
        T.StructField("total_sales_amt_old", T.DoubleType()),
        T.StructField("total_seasonality_amt_old", T.DoubleType()),
        T.StructField("baseline_sales_perc_old", T.DoubleType())
    ])

    new_baseline_output = T.StructType([
        T.StructField("super_category_name", T.StringType()),
        T.StructField("unique_brand_name", T.StringType()),
        T.StructField("cluster_num_new", T.StringType()),
        T.StructField("cluster_type", T.StringType()),
        T.StructField("total_baseline_amt_new", T.DoubleType()),
        T.StructField("total_incremental_amt_new", T.DoubleType()),
        T.StructField("total_sales_amt_new", T.DoubleType()),
        T.StructField("total_seasonality_amt_new", T.DoubleType()),
        T.StructField("baseline_sales_perc_new", T.DoubleType())
    ])

    ucm_output = T.StructType([
        T.StructField("variable_apl", T.StringType()),
        T.StructField("estimate", T.DoubleType()),
        T.StructField("approx_std_err", T.DoubleType()),
        T.StructField("zvalue", T.DoubleType()),
        T.StructField("pvalue_zdist", T.DoubleType()),
        T.StructField("base_variable_name", T.StringType()),
        T.StructField("variable", T.StringType()),
    ])

    full_ucm_output = T.StructType([
        T.StructField("variable_apl", T.StringType(), True),
        T.StructField("estimate", T.DoubleType(), True),
        T.StructField("approx_std_err", T.DoubleType(), True),
        T.StructField("zvalue", T.DoubleType(), True),
        T.StructField("pvalue_zdist", T.DoubleType(), True),
        T.StructField("modelling_cluster", T.StringType(), True),
        T.StructField("level_variance", T.DoubleType(), True),
        T.StructField("cycle", T.BooleanType(), True),
        T.StructField("cycle_period_bounds", T.StringType(), True),
        T.StructField("iteration_number", T.StringType(), True),
        T.StructField("selected_variables", T.StringType(), True),
        T.StructField("level_std", T.StringType(), True),
        T.StructField("slope_std", T.StringType(), True),
        T.StructField("cycle_std", T.StringType(), True),
        T.StructField("ucm_fin_1_serialized", T.StringType(), True)
    ])

    master_empty = T.StructType([
        T.StructField("week_date", T.DateType()),
        T.StructField("super_category_name", T.StringType()),
        T.StructField("unique_brand", T.StringType()),
        T.StructField("cluster", T.StringType()),
        T.StructField("variable", T.StringType()),
        T.StructField("value", T.IntegerType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("marketing_channel", T.StringType()),
        T.StructField("marketing_sub_channel", T.StringType()),
        T.StructField("metric", T.StringType()),
        T.StructField("primary_metric", T.StringType()),
        T.StructField("investment_metric", T.StringType()),
        T.StructField("job_id", T.StringType()),
        T.StructField("load_ts", T.TimestampType()),
    ])

    apl_variables = T.StructType([
        T.StructField("modelling_cluster", T.StringType()),
        T.StructField("wdate", T.DateType()),
        T.StructField("variable", T.StringType()),
        T.StructField("value", T.DoubleType()),
    ])

    grid_params = T.StructType([
        T.StructField("modelling_cluster", T.StringType(), True),
        T.StructField("level_variance", T.DoubleType(), True),  # float/double
        T.StructField("cycle", T.BooleanType(), True),  # boolean
        T.StructField("cycle_period_bounds", T.ArrayType(T.IntegerType()), True),
        T.StructField("Iteration_Number", T.StringType(), True)  # int
    ])

    incremental_check_bool_schema = T.StructType([
        T.StructField("modelling_cluster", T.StringType(), True),
        T.StructField("iteration_not_found", T.BooleanType(), True)
    ])

    primary_metrics_schema = T.StructType([
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("primary_metric_cd", T.StringType(), True),
        T.StructField("investment_metric_cd", T.StringType(), True)
    ])
