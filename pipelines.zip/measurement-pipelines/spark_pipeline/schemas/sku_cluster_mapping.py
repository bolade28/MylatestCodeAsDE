from pyspark.sql import types as T


class SkuClusterMapping:

    campaign_selection_input_schema = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
    ])

    unified_campaign_input_schema = T.StructType([
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
    ])

    campaign_product_type_input_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("product_type", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("sub_cat_name", T.StringType(), True),
    ])

    campaign_product_type_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("product_type", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
    ])

    sales_data_input_schema = T.StructType([
        T.StructField("item_cd", T.StringType(), True),
    ])

    brand_skus_schema = T.StructType([
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
    ])

    final_output_schema = T.StructType([
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("modelling_type", T.StringType(), True),
        T.StructField("job_run_id", T.StringType(), True),
        T.StructField("load_ts", T.StringType(), True),
    ])
