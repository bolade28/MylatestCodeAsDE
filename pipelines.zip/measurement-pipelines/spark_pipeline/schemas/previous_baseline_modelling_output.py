from pyspark.sql import types as T


class PreviousBaselineModellingOutput:

    schema = T.StructType([
        T.StructField("week_start_dt", T.TimestampType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("iteration", T.IntegerType(), True),
        T.StructField("modelling_type", T.StringType(), True),
        T.StructField("job_run_id", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("load_ts", T.StringType(), True),
        T.StructField("cluster_type", T.StringType(), True),
        T.StructField("best_iteration", T.IntegerType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
        T.StructField("rsq", T.DoubleType(), True),
        T.StructField("wsmape", T.DoubleType(), True),
        T.StructField("baseline_perc", T.DoubleType(), True),
    ])
