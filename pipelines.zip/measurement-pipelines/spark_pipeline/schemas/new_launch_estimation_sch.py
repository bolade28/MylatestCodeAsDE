from pyspark.sql import types as T

new_launch_baseline_output_schema = T.StructType([
    T.StructField("WEEK_START_DT", T.DateType(), True),
    T.StructField("METRIC_NAME", T.StringType(), True),
    T.StructField("METRIC_VALUE", T.DoubleType(), True),
    T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
    T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
    T.StructField("CLUSTER_NUM", T.StringType(), False),  # 'CL1' or 'TOTAL' as string
    T.StructField("ITERATION", T.StringType(), True),
    T.StructField("MODELLING_TYPE", T.StringType(), True),
    T.StructField("CLUSTER_TYPE", T.StringType(), True),
    T.StructField("BEST_ITERATION", T.StringType(), True),
    T.StructField("JOB_RUN_ID", T.StringType(), False),
    T.StructField("RSQ", T.DoubleType(), True),
    T.StructField("WSMAPE", T.DoubleType(), True),
    T.StructField("BASELINE_PERC", T.DoubleType(), True),
    T.StructField("LOAD_TS", T.TimestampType(), False),
])

top_3_distinct_brands_output_schema = T.StructType([
    T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
    T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
    T.StructField("CLUSTER_NUM", T.StringType(), True),
    T.StructField("New_Launch", T.StringType(), True),
    T.StructField("SUPER_CATEGORY_NAME_NEW", T.StringType(), True),
    T.StructField("UNIQUE_BRAND_NAME_NEW", T.StringType(), True),
    T.StructField("Final_Rank", T.DoubleType(), True)
])

output_schema = T.StructType([
    T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
    T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
    T.StructField("CLUSTER_NUM", T.StringType(), True),
    T.StructField("CONCAT", T.StringType(), True),  # CONCAT from cl_feature_data_df
    T.StructField("Distance", T.DoubleType(), True),
    T.StructField("New_Launch", T.StringType(), True),  # CONCAT from skus_df
    T.StructField("SUPER_CATEGORY_NAME_NEW", T.StringType(), True),
    T.StructField("UNIQUE_BRAND_NAME_NEW", T.StringType(), True)
])

skus_cluster_map_new_launch_schema = T.StructType([
    T.StructField("ITEM_CD", T.LongType(), True),
    T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
    T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
    T.StructField("CLUSTER_NUM", T.StringType(), False),
    T.StructField("JOB_RUN_ID", T.StringType(), False),
    T.StructField("LOAD_TS", T.TimestampType(), False),  # CONCAT from skus_df
    T.StructField("MODELLING_TYPE", T.StringType(), False)
])

# sales_data_df (SALES_DATA_TRANSFORMATION_OUTPUT)
sales_data_schema = T.StructType([
    T.StructField("WEEK_START_DT", T.DateType(), True),
    T.StructField("ITEM_CD", T.LongType(), True),
    T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
    T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
    T.StructField("TOTAL_SALES_AMT", T.DecimalType(), True),
    T.StructField("AVG_PURCHASE_PER_CUSTOMER_CNT", T.DoubleType(), True),
    T.StructField("ONLINE_SALES_PCT", T.DoubleType(), True),
    T.StructField("SUPERMARKET_SALES_PCT", T.DoubleType(), True),
    T.StructField("CONVENIENCE_SALES_PCT", T.DoubleType(), True),
    T.StructField("PRICE_PER_POINT", T.DoubleType(), True),
    T.StructField("PACK_SIZE", T.DoubleType(), True)
])


new_launch_estimation_schema = T.StructType([
    T.StructField("WEEK_START_DT", T.DateType(), True),
    T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
    T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
    T.StructField("CLUSTER_NUM", T.StringType(), True),
    T.StructField("ITERATION", T.StringType(), True),
    T.StructField("MODELLING_TYPE", T.StringType(), True),
    T.StructField("JOB_RUN_ID", T.StringType(), True),
    T.StructField("METRIC_NAME", T.StringType(), True),
    T.StructField("LOAD_TS", T.TimestampType(), True),
    T.StructField("CLUSTER_TYPE", T.StringType(), True),
    T.StructField("BEST_ITERATION", T.StringType(), True),
    T.StructField("METRIC_VALUE", T.FloatType(), True),
    T.StructField("RSQ", T.FloatType(), True),
    T.StructField("WSMAPE", T.FloatType(), True),
    T.StructField("BASELINE_PERC", T.FloatType(), True)
])

skus_tagging_final_schema = T.StructType([
    T.StructField("ITEM_CD", T.LongType(), True),
    T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
    T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
    T.StructField("CLUSTER_NUM", T.StringType(), True),
    T.StructField("JOB_RUN_ID", T.StringType(), True),
    T.StructField("LOAD_TS", T.TimestampType(), True),
    T.StructField("MODELLING_TYPE", T.StringType(), True)
])
