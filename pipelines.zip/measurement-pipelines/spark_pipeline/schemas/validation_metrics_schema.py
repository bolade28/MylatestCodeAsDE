from pyspark.sql import types as T


class ValidationMetrics:
    INCREMENTAL_SALES_IROAS_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("incremental_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("iroas_exposed", T.DoubleType(), True),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType(), True),
    ])

    ROAS_VALIDATION_SCHEMA = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("roas_exposed", T.DoubleType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
    ])

    METRICS_SCHEMA = T.StructType([
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
    ])

    SIGNAL_METRICS_SCHEMA = T.StructType([
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("signal_type", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
    ])

    BASELINE_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
    ])

    CAMPAIGN_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("min_campaign_start_dt", T.DateType(), True),
        T.StructField("max_campaign_end_dt", T.DateType(), True),
        T.StructField("marketing_types", T.ArrayType(T.StringType()), True),
        T.StructField("subchannel_name", T.ArrayType(T.StringType()), True),
    ])

    RESOLVE_CHANNELS_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("min_campaign_start_dt", T.DateType(), True),
        T.StructField("max_campaign_end_dt", T.DateType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
    ])

    RANGE_CHECK_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("out_of_range_weeks", T.LongType(), True),
        T.StructField("out_of_range_week_dates", T.ArrayType(T.StructType([
            T.StructField("week", T.StringType(), True),
            T.StructField("value", T.DoubleType(), True),
        ])), True),
        T.StructField("min_value", T.DoubleType(), True),
        T.StructField("max_value", T.DoubleType(), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("message", T.StringType(), True),
    ])

    SIGNAL_CHECK_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("signal_type", T.StringType(), True),
        T.StructField("zero_signal_weeks", T.LongType(), True),
        T.StructField("total_campaign_weeks", T.LongType(), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("message", T.StringType(), True),
    ])

    ALL_CHECKS_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("message", T.StringType(), True),
        T.StructField("check_name", T.StringType(), True),
        T.StructField("metadata", T.StringType(), True),
    ])

    SALES_BASELINE_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
    ])

    SALES_CAMPAIGN_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("min_campaign_start_dt", T.DateType(), True),
        T.StructField("max_campaign_end_dt", T.DateType(), True),
        T.StructField("max_post_campaign_dt", T.DateType(), True),
    ])

    SALES_ZERO_STREAK_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("longest_zero_sales_streak", T.LongType(), True),
        T.StructField("zero_sales_week_dates", T.ArrayType(T.StructType([
            T.StructField("week", T.StringType(), True),
            T.StructField("value", T.DoubleType(), True),
        ])), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("message", T.StringType(), True),
    ])

    SALES_NEAR_ZERO_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("near_zero_weeks", T.LongType(), True),
        T.StructField("near_zero_week_dates", T.ArrayType(T.StructType([
            T.StructField("week", T.StringType(), True),
            T.StructField("value", T.DoubleType(), True),
        ])), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("message", T.StringType(), True),
    ])

    SALES_OUTLIER_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("median_sales", T.DoubleType(), True),
        T.StructField("median_outlier_weeks", T.LongType(), True),
        T.StructField("median_outlier_week_dates", T.ArrayType(T.StructType([
            T.StructField("week", T.StringType(), True),
            T.StructField("value", T.DoubleType(), True),
        ])), True),
        T.StructField("isolated_extreme_weeks", T.LongType(), True),
        T.StructField("isolated_extreme_week_dates", T.ArrayType(T.StructType([
            T.StructField("week", T.StringType(), True),
            T.StructField("value", T.DoubleType(), True),
        ])), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("message", T.StringType(), True),
    ])

    SALES_PERIOD_CHECK_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("period_type", T.StringType(), True),
        T.StructField("period_start_dt", T.StringType(), True),
        T.StructField("period_end_dt", T.StringType(), True),
        T.StructField("near_zero_weeks", T.LongType(), True),
        T.StructField("near_zero_week_dates", T.ArrayType(T.StructType([
            T.StructField("week", T.StringType(), True),
            T.StructField("value", T.DoubleType(), True),
        ])), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("message", T.StringType(), True),
    ])

    SALES_ALL_CHECKS_SCHEMA = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("message", T.StringType(), True),
        T.StructField("check_name", T.StringType(), True),
        T.StructField("metadata", T.StringType(), True),
    ])
