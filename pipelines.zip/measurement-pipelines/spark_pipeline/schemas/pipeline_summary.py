from pyspark.sql import functions as F
from pyspark.sql import types as T


class PipelineSummaryMetricsSchema:
    INTERMEDIATE_METRICS_SCHEMA = T.StructType([
        T.StructField("correlation_id", T.StringType(), True),
        T.StructField("name", T.StringType(), True),
        T.StructField("value", T.DecimalType(38, 10), True),
        T.StructField("metadata", T.StringType(), True),
    ])

    PIPELINE_SUMMARY_METRICS_SCHEMA = T.StructType([
        T.StructField("correlation_id", T.StringType(), True),
        T.StructField("name", T.StringType(), True),
        T.StructField("data_group", T.StringType(), True),
        T.StructField("data_sources", T.StringType(), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("metadata", T.StringType(), True),
        T.StructField("load_timestamp", T.TimestampType(), True),
    ])

    ucm_output_schema = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("iteration", T.StringType(), True),
        T.StructField("modelling_type", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("best_iteration", T.StringType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
        T.StructField("rsq", T.DoubleType(), True),
        T.StructField("wsmape", T.DoubleType(), True),
        T.StructField("baseline_perc", T.DoubleType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("job_run_id", T.StringType(), True),
    ])

    ucm_base_schema = T.StructType([
        T.StructField("wdate", T.DateType(), True),
        T.StructField("modelling_cluster", T.StringType(), True),
        T.StructField("iteration", T.StringType(), True),
        T.StructField("variable", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True),
        T.StructField("time_stamp", T.TimestampType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
    ])

    fp_schema = T.StructType([
        T.StructField("variable_cd", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("variable_importance_rank", T.DoubleType(), True),
    ])

    input_schema = T.StructType([
        T.StructField("variable_cd", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("marketing_sub_channel_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
    ])

    pipeline_summary_metric_schema = T.StructType([
        T.StructField("correlation_id", T.StringType(), True),
        T.StructField("name", T.StringType(), True),
        T.StructField("data_group", T.StringType(), True),
        T.StructField("data_sources", T.StringType(), True),
        T.StructField("severity", T.StringType(), True),
        T.StructField("metadata", T.StringType(), True),
        T.StructField("load_timestamp", T.StringType(), True),
    ])

    calibration_audit_schema = T.StructType([
        T.StructField("run_date", T.DateType(), True),
        T.StructField("correlation_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("mean_log_uplift", T.DoubleType(), True),
        T.StructField("var_log_uplift", T.DoubleType(), True),
        T.StructField("count_campaigns", T.LongType(), True),
        T.StructField("distribution_type", T.StringType(), True),
        T.StructField("shift_parameter", T.DoubleType(), True),
        T.StructField("rev_similarity_percentile", T.DoubleType(), True),
        T.StructField("scaling_factor", T.DoubleType(), True),
        T.StructField("sample_median", T.DoubleType(), True),
        T.StructField("sample_mode", T.DoubleType(), True),
        T.StructField("z_score", T.DoubleType(), True),
        T.StructField("channel_prior_failures", T.LongType(), True),
    ])

    calibration_output_schema = T.StructType([
        T.StructField("run_date", T.DateType(), True),
        T.StructField("correlation_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("metric_name", T.StringType(), True),
        T.StructField("metric_value", T.FloatType(), True),
    ])

    @staticmethod
    def feature_overview_metadata_struct() -> F.Column:
        """Standard metadata JSON struct for variable-level pipeline summary rows."""
        return F.to_json(
            F.struct(
                F.col("features_overview"),
            )
        )

    @staticmethod
    def incrementality_output_metadata_struct() -> F.Column:
        """Metadata JSON struct for incrementality output pipeline summary rows."""
        return F.to_json(
            F.struct(
                F.col("unique_brand_name"),
                F.col("ucm_incrementality").alias("total_ucm_booking_period_incrementality"),
                F.col("calibrated_incrementality").alias("total_calibrated_incrementality"),
                F.col("bypass_incrementality").alias("total_bypass_incrementality"),
                F.col("during_incrementality").alias("total_during_incrementality"),
                F.col("adjusted_calibrated_incrementality").alias("total_adjusted_calibrated_incrementality"),
            )
        )

    @staticmethod
    def ucm_details_metadata_struct() -> F.Column:
        """Metadata JSON struct for UCM details pipeline summary rows."""
        return F.to_json(
            F.struct(
                F.col("rsq"),
                F.col("wsmape"),
                F.col("iteration"),
                F.col("level"),
                F.col("cycle"),
                F.col("level_base"),
                F.col("distinct_features"),
            )
        )

    @staticmethod
    def calibration_details_metadata_struct() -> F.Column:
        """Metadata JSON struct for calibration details pipeline summary rows."""
        return F.to_json(
            F.struct(
                F.col("calibration_details"),
            )
        )

    @staticmethod
    def campaign_definition_metadata_struct() -> F.Column:
        """Standard metadata JSON struct for campaign-definition summary rows."""
        return F.to_json(
            F.struct(
                F.array(
                    F.lit("campaign_dates"),
                    F.lit("count_distinct_subchannels"),
                    F.lit("total_spend"),
                    F.lit("unique_brand_name"),
                    F.lit("super_cat"),
                    F.lit("store_count_from_unified_campaign"),
                ).alias("campaign_definition_overview"),
            )
        )

    @staticmethod
    def product_details_metadata_struct() -> F.Column:
        """Standard metadata JSON struct for product-details summary rows."""
        return F.to_json(
            F.struct(
                F.array(
                    F.lit("count_skus_by_brand_offer"),
                    F.lit("sum_item_cd_for_sku_group_fingerprint"),
                    F.lit("sum_sales_over_104w_by_brand_offer"),
                ).alias("product_details_overview"),
            )
        )

    @staticmethod
    def marketing_details_metadata_struct() -> F.Column:
        """Standard metadata JSON struct for marketing-details summary rows."""
        return F.to_json(
            F.struct(
                F.array(
                    F.lit("count_targeted_stores_for_measurement_booking"),
                    F.lit("sum_impressions_for_instore"),
                    F.lit("sum_impressions_for_onsite"),
                    F.lit("sum_impressions_for_offsite"),
                    F.lit("sum_base_value_for_coupon_at_till"),
                    F.lit("sum_base_value_for_ecoupon"),
                    F.lit("distinct_historic_offsite_campaigns_for_brand_skus"),
                    F.lit("distinct_historic_onsite_campaigns_for_brand_skus"),
                    F.lit("distinct_historic_instore_campaigns_for_brand_skus"),
                ).alias("marketing_details_overview"),
            )
        )

    @staticmethod
    def canonical_metadata_struct() -> F.Column:
        """Canonical metadata JSON struct used for one-row campaign-details summary."""
        return F.to_json(
            F.struct(
                F.array(
                    F.lit("campaign_dates"),
                    F.lit("count_distinct_subchannels"),
                    F.lit("total_spend"),
                    F.lit("unique_brand_name"),
                    F.lit("super_cat"),
                    F.lit("store_count_from_unified_campaign"),
                ).alias("campaign_definition_overview"),
                F.array(
                    F.lit("count_skus_by_brand_offer"),
                    F.lit("sum_item_cd_for_sku_group_fingerprint"),
                    F.lit("sum_sales_over_104w_by_brand_offer"),
                ).alias("product_details_overview"),
                F.array(
                    F.lit("count_targeted_stores_for_measurement_booking"),
                    F.lit("sum_impressions_for_instore"),
                    F.lit("sum_impressions_for_onsite"),
                    F.lit("sum_impressions_for_offsite"),
                    F.lit("sum_base_value_for_coupon_at_till"),
                    F.lit("sum_base_value_for_ecoupon"),
                    F.lit("distinct_historic_offsite_campaigns_for_brand_skus"),
                    F.lit("distinct_historic_onsite_campaigns_for_brand_skus"),
                    F.lit("distinct_historic_instore_campaigns_for_brand_skus"),
                ).alias("marketing_details_overview"),
            )
        )

    @staticmethod
    def canonical_metadata_struct_with_values(
        metric_values: F.Column,
        campaign_dates_value: F.Column,
        unique_brand_names_value: F.Column,
        super_category_names_value: F.Column,
        offer_sku_count: F.Column,
        brand_sku_count: F.Column,
        offer_sales_amt_104w: F.Column,
        brand_sales_amt_104w: F.Column,
        brand_sku_group_fingerprint: F.Column = None,
        offer_sku_group_fingerprint: F.Column = None,
    ) -> F.Column:
        """Canonical metadata JSON with per-section metric/value entries."""
        return F.to_json(
            F.struct(
                F.array(
                    F.struct(
                        F.lit("campaign_dates").alias("metric"),
                        F.to_json(campaign_dates_value).alias("value"),
                    ),
                    F.struct(
                        F.lit("count_distinct_subchannels").alias("metric"),
                        F.element_at(metric_values, F.lit("distinct_subchannels")).cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("total_spend").alias("metric"),
                        F.element_at(metric_values, F.lit("total_media_spend")).cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("unique_brand_name").alias("metric"),
                        unique_brand_names_value.cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("super_cat").alias("metric"),
                        super_category_names_value.cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("store_count_from_unified_campaign").alias("metric"),
                        F.element_at(metric_values, F.lit("unique_store_count")).cast("string").alias("value"),
                    ),
                ).alias("campaign_definition_overview"),
                F.array(
                    F.struct(
                        F.lit("count_skus_by_brand_offer").alias("metric"),
                        F.to_json(
                            F.struct(
                                offer_sku_count.alias("offer_sku_count"),
                                brand_sku_count.alias("brand_sku_count"),
                            )
                        ).alias("value"),
                    ),
                    F.struct(
                        F.lit("sum_item_cd_for_sku_group_fingerprint").alias("metric"),
                        F.to_json(
                            F.struct(
                                F.element_at(metric_values, F.lit("sku_group_fingerprint")).alias(
                                    "sum_sku_group_fingerprint"
                                ),
                                (brand_sku_group_fingerprint if brand_sku_group_fingerprint is not None
                                 else F.lit(None)).alias("brand_sku_group_fingerprint"),
                                (offer_sku_group_fingerprint if offer_sku_group_fingerprint is not None
                                 else F.lit(None)).alias("offer_sku_group_fingerprint"),
                                offer_sku_count.alias("offer_sku_count"),
                                brand_sku_count.alias("brand_sku_count"),
                            )
                        ).alias("value"),
                    ),
                    F.struct(
                        F.lit("sum_sales_over_104w_by_brand_offer").alias("metric"),
                        F.to_json(
                            F.struct(
                                offer_sales_amt_104w.alias("offer_sales_amt_104w"),
                                brand_sales_amt_104w.alias("brand_sales_amt_104w"),
                            )
                        ).alias("value"),
                    ),
                ).alias("product_details_overview"),
                F.array(
                    F.struct(
                        F.lit("count_targeted_stores_for_measurement_booking").alias("metric"),
                        F.element_at(metric_values, F.lit("targeted_stores")).cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("sum_impressions_for_instore").alias("metric"),
                        F.element_at(metric_values, F.lit("instore_impressions")).cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("sum_impressions_for_onsite").alias("metric"),
                        F.element_at(metric_values, F.lit("onsite_impressions")).cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("sum_impressions_for_offsite").alias("metric"),
                        F.element_at(metric_values, F.lit("offsite_impressions")).cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("sum_base_value_for_coupon_at_till").alias("metric"),
                        F.element_at(metric_values, F.lit("coupon_at_till_base_value")).cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("sum_base_value_for_ecoupon").alias("metric"),
                        F.element_at(metric_values, F.lit("ecoupon_base_value")).cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("distinct_historic_offsite_campaigns_for_brand_skus").alias("metric"),
                        F.element_at(metric_values, F.lit("distinct_offsite_campaigns")).cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("distinct_historic_onsite_campaigns_for_brand_skus").alias("metric"),
                        F.element_at(metric_values, F.lit("distinct_onsite_campaigns")).cast("string").alias("value"),
                    ),
                    F.struct(
                        F.lit("distinct_historic_instore_campaigns_for_brand_skus").alias("metric"),
                        F.element_at(metric_values, F.lit("distinct_instore_campaigns")).cast("string").alias("value"),
                    ),
                ).alias("marketing_details_overview"),
            )
        )
