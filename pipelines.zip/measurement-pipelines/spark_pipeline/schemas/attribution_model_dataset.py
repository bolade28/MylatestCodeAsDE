from pyspark.sql import types as T


class AttributionModelDatasetSchema:
    """
    Spark schemas for the Attribution Model Dataset pipeline.

    Column name lists are derived directly from schema fields, so they are
    always in sync — no need to maintain separate lists.
    """

    @staticmethod
    def columns(schema: T.StructType) -> list[str]:
        """Return an ordered list of column names from a StructType schema."""
        return [field.name for field in schema.fields]

    measurement_campaign_execution_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("campaign_name", T.StringType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("job_status", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("job_run_id", T.StringType(), True),
    ])

    attribution_prerequisite_schema = T.StructType([
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("event_ts", T.TimestampType(), True),
        T.StructField("event_name", T.StringType(), True),
        T.StructField("net_sales_amt", T.DecimalType(38, 4), True),
        T.StructField("journey_type", T.StringType(), True),
        T.StructField("transaction_key", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("position", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("job_run_id", T.StringType(), True),
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("regression_variable", T.StringType(), True),
        T.StructField("customer_journey_type", T.StringType(), True),
        T.StructField("isconversion", T.IntegerType(), True),
        T.StructField("marketing_type", T.StringType(), True),
    ])

    # Maps each userjourney_id to its channel/campaign metadata written by process_attribution_model_dataset
    journey_channel_metadata_schema = T.StructType([
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("regression_variable", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
    ])

    # create a nested schema for flattend_df to support dynamic schemas within this dataframe
    regression_variable_struct = T.StructType([
        T.StructField("name", T.StringType(), nullable=False),
        T.StructField("value", T.DoubleType(), nullable=False),
    ])

    journey_schema = T.StructType([
        T.StructField("userjourney_id", T.StringType(), nullable=True),
        T.StructField("transaction_key", T.StringType(), nullable=True),
        T.StructField("regression_variables", T.ArrayType(regression_variable_struct), nullable=True),
    ])

    attribution_model_dataset_schema = T.StructType([
        T.StructField("loyalty_id", T.StringType(), nullable=True),
        T.StructField("isconversion", T.IntegerType(), nullable=True),
        T.StructField("booking_id", T.StringType(), nullable=True),
        T.StructField("customer_journey_type", T.StringType(), nullable=True),
        T.StructField("campaign_duration", T.StringType(), nullable=True),
        T.StructField("journey_type", T.StringType(), nullable=True),
        T.StructField("user_journeys", T.ArrayType(journey_schema), nullable=True),
    ])
