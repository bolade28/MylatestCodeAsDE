from pyspark.sql import types as T


class BaselineModellingShrinkage:

    incrementality_metrics = T.StructType(
        [
            T.StructField("metric_name", T.StringType(), False),
            T.StructField("metric_value", T.DoubleType(), True),
        ]
    )

    audit = T.StructType(
        [
            T.StructField("run_date", T.DateType(), True),
            T.StructField("correlation_id", T.StringType(), True),
            T.StructField("load_ts", T.TimestampType(), True),
            T.StructField("unique_brand_name", T.StringType(), True),
            T.StructField("super_category_name", T.StringType(), True),
            T.StructField("sub_category_name", T.StringType(), True),
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField("mean_log_uplift", T.DoubleType(), True),
            T.StructField("var_log_uplift", T.DoubleType(), True),
            T.StructField("count_campaigns", T.IntegerType(), True),
            T.StructField("distribution_type", T.StringType(), True),
            T.StructField("shift_parameter", T.DoubleType(), True),
            T.StructField("rev_similarity_percentile", T.DoubleType(), True),
            T.StructField("scaling_factor", T.DoubleType(), True),
            T.StructField("sample_median", T.DoubleType(), True),
            T.StructField("sample_mode", T.DoubleType(), True),
            T.StructField("z_score", T.DoubleType(), True),
            T.StructField("channel_prior_failures", T.StringType(), True),
        ]
    )

    # Input schema: item-level measurement_legacy_campaign_performance parquet
    legacy_campaign_performance = T.StructType(
        [
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("item_cd", T.StringType(), True),
            T.StructField("campaign_source", T.StringType(), True),
            T.StructField("period", T.StringType(), True),
            T.StructField("campaign_start_date", T.DateType(), True),
            T.StructField("campaign_end_date", T.DateType(), True),
            T.StructField("test", T.DoubleType(), True),
            T.StructField("control", T.DoubleType(), True),
            T.StructField("uplift", T.DoubleType(), True),
            T.StructField("media_cost", T.DoubleType(), True),
        ]
    )

    # Input schema: baseline modelling output (UCM weekly results)
    baseline_output_input = T.StructType(
        [
            T.StructField("week_start_dt", T.DateType(), True),
            T.StructField("super_category_name", T.StringType(), True),
            T.StructField("unique_brand_name", T.StringType(), True),
            T.StructField("metric_name", T.StringType(), True),
            T.StructField("metric_value", T.DoubleType(), True),
            T.StructField("iteration", T.StringType(), True),
            T.StructField("best_iteration", T.StringType(), True),
        ]
    )

    # Input schema: item-level average weekly spend table
    avg_weekly_spend = T.StructType(
        [
            T.StructField("item_cd", T.StringType(), True),
            T.StructField("week", T.DateType(), True),
            T.StructField("year", T.IntegerType(), True),
            T.StructField("super_cat_cd", T.StringType(), True),
            T.StructField("super_cat_name", T.StringType(), True),
            T.StructField("sub_cat_cd", T.StringType(), True),
            T.StructField("sub_cat_name", T.StringType(), True),
            T.StructField("inflation_ratio", T.DoubleType(), True),
            T.StructField("avg_weekly_spend", T.DoubleType(), True),
            T.StructField("avg_weekly_spend_inf_adj", T.DoubleType(), True),
        ]
    )

    # Input schema: unified_products parquet used to enrich item-level sources.
    unified_products = T.StructType(
        [
            T.StructField("item_cd", T.StringType(), True),
            T.StructField("super_cat_name", T.StringType(), True),
            T.StructField("sub_cat_name", T.StringType(), True),
            T.StructField("unique_brand_name", T.StringType(), True),
        ]
    )

    # Input schema: campaign selection output
    campaign_selection_input = T.StructType(
        [
            T.StructField("unique_brand_name", T.StringType(), True),
            T.StructField("super_category_name", T.StringType(), True),
            T.StructField("sub_category_name", T.StringType(), True),
            T.StructField("min_campaign_start_dt", T.DateType(), True),
            T.StructField("max_campaign_end_dt", T.DateType(), True),
            T.StructField("max_post_campaign_dt", T.DateType(), True),
            T.StructField("total_media_spend", T.DoubleType(), True),
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField(
                "media_spend_by_source",
                T.MapType(T.StringType(), T.DoubleType(), True),
                True,
            ),
        ]
    )
