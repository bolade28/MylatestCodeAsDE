from pyspark.sql import types as T


class ProductETL:
    ab_tests = T.ArrayType(T.StructType([
        T.StructField('test_id', T.StringType(), True),
        T.StructField('group_id', T.StringType(), True),
    ]), False)

    l2_customers_schema = T.StructType([
        T.StructField('ec_id', T.StringType(), False),
        T.StructField('ab_tests', ab_tests, True)
    ])
