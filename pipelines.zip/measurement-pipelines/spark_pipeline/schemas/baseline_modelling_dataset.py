from pyspark.sql import types as T
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, DoubleType


class BaselineModellingDataset():

    weekly_dates_schema = StructType([
        StructField("week_start_dt", StringType(), True)
    ])

    channel_processed_data_schema = StructType([
        StructField("week_start_dt", StringType(), True),
        StructField("metric_value", DoubleType(), True),
        StructField("super_category_name", StringType(), True),
        StructField("unique_brand_name", StringType(), True),
        StructField("cluster_num", StringType(), True),
        StructField("marketing_type_name", StringType(), True),
        StructField("marketing_channel_name", StringType(), True),
        StructField("marketing_sub_channel_name", StringType(), True),
        StructField("metric_name", StringType(), True),
        StructField("job_run_id", StringType(), True),
        StructField("load_ts", TimestampType(), True)
    ])

    three_letter_coding_schema = StructType([
        StructField("column_name", StringType(), True),
        StructField("original_column_value", StringType(), True),
        StructField("final_code", StringType(), True)
    ])

    baseline_modelling_dataset_final_schema = StructType([
        StructField("week_start_dt", StringType(), True),
        StructField("super_category_name", StringType(), True),
        StructField("unique_brand_name", StringType(), True),
        StructField("cluster_num", StringType(), True),
        StructField("marketing_type_name", StringType(), True),
        StructField("marketing_channel_name", StringType(), True),
        StructField("marketing_sub_channel_name", StringType(), True),
        StructField("metric_name", StringType(), True),
        StructField("metric_value", DoubleType(), True),
        StructField("variable_cd", StringType(), True),
        StructField("load_ts", TimestampType(), True),
        StructField("correlation_id", StringType(), True)
    ])

    baseline_modelling_validation_ads_schema = T.StructType([
        T.StructField("week_start_dt", T.DateType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("cluster_num", T.StringType(), True),
        T.StructField("marketing_type_name", T.StringType(), True),
        T.StructField("marketing_channel_name", T.StringType(), True),
        T.StructField("variable_cd", T.StringType(), True),
        T.StructField("metric_value", T.DoubleType(), True),
    ])
