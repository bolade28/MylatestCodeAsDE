from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from typing import List, Optional

from spark_pipeline.reach_engagement.data_quality import (
    JoinValidationError, DiagnosticMessage, DiagnosticQuery)


def calculate_combined_reach(
    meta_campaigns_df: DataFrame,
    instore_onsite_loyalty_ids_df: DataFrame,
    offsite_reported_reach: dict,
    channel_name: str = "Meta"
) -> dict:
    """
    Calculates combined reach estimates using loyalty_id overlap between offsite campaign DataFrame and instore/onsite campaign DataFrame,
    using the reported reach from the specified offsite channel (e.g., 'Meta') from a provided reach dictionary.

    Args:
        meta_campaigns_df (DataFrame): DataFrame with column 'LOYALTY_ID' for the offsite exposure (Meta or other).
        instore_onsite_loyalty_ids_df (DataFrame): DataFrame with column 'LOYALTY_ID' for instore/onsite exposure.
        offsite_reported_reach (dict): Dictionary containing {channel_name: reported_reach_count}
        channel_name (str): The key for the relevant offsite channel in the reported reach dictionary. Default: 'Meta'.

    Returns:
        dict: {
            "meta_loyalty_id_count": int,
            "instore_loyalty_id_count": int,
            "overlap_count": int,
            "unique_in_meta": int,
            "unique_in_instore": int,
            "union_loyalty_ids": int,
            "meta_reported_reach": float,
            "overlap_rate": float,
            "exposure_only_to_meta": float,
            "reach_estimate": float,
            "reach_estimate_rounded": int
        }
    """
    # Get distinct loyalty IDs
    meta_ids_df = meta_campaigns_df.select("LOYALTY_ID").distinct()
    instore_ids_df = instore_onsite_loyalty_ids_df.select("LOYALTY_ID").distinct()

    meta_loyalty_id_count = meta_ids_df.count()
    instore_loyalty_id_count = instore_ids_df.count()

    # Overlap and unique counts
    overlap_df = meta_ids_df.intersect(instore_ids_df)
    overlap_count = overlap_df.count()

    unique_in_meta_df = meta_ids_df.subtract(instore_ids_df)
    unique_in_meta = unique_in_meta_df.count()

    unique_in_instore_df = instore_ids_df.subtract(meta_ids_df)
    unique_in_instore = unique_in_instore_df.count()

    # Union of the sets of IDs that are unique to each source (Meta-only + Instore-only).
    # NOTE: May need to rename later, but this doesn't get used later just used
    # for debugging/validation.
    union_ids_df = unique_in_meta_df.union(unique_in_instore_df).distinct()
    union_loyalty_ids = union_ids_df.count()

    # Get reported reach for the channel (default "Meta").
    meta_reported_reach = offsite_reported_reach.get(channel_name, 0)

    overlap_rate = overlap_count / meta_loyalty_id_count if meta_loyalty_id_count > 0 else 0.0
    exposure_only_to_meta = meta_reported_reach * (1 - overlap_rate)
    reach_estimate = instore_loyalty_id_count + exposure_only_to_meta

    return {
        "meta_loyalty_id_count": meta_loyalty_id_count,
        "instore_loyalty_id_count": instore_loyalty_id_count,
        "overlap_count": overlap_count,
        "unique_in_meta": unique_in_meta,
        "unique_in_instore": unique_in_instore,
        "union_loyalty_ids": union_loyalty_ids,
        "meta_reported_reach": meta_reported_reach,
        "overlap_rate": overlap_rate,
        "exposure_only_to_meta": exposure_only_to_meta,
        "reach_estimate": reach_estimate,
        "reach_estimate_rounded": round(reach_estimate),
    }


def aggregate_campaign_metrics(
    camp_request_link_df: DataFrame,
    campaign_info_df: DataFrame,
    validate_joins_func: Optional[callable] = None,
    enable_validation: bool = False
) -> DataFrame:
    """
    Process campaign request data by filtering and aggregating metrics.

    Args:
        camp_request_link_df: Campaign request link dataframe
        campaign_info_df: Campaign info dataframe with campaign_id, campaign_start_dt, campaign_end_dt
        validate_joins_func: Optional validation function to call if join produces no results
        enable_validation: Whether to perform comprehensive validation (raises error if no rows)

    Returns:
        DataFrame with aggregated campaign metrics (campaign_id, sales, conversions, impressions, clicks)
    """

    # Filter campaign requests by date range
    campaign_requests_filtered = (
        camp_request_link_df.alias("crl")
        .join(
            F.broadcast(
                campaign_info_df.select("campaign_id", "campaign_start_dt", "campaign_end_dt").alias("ci")
            ),
            F.col("crl.advertising_campaign_nk1") == F.col("ci.campaign_id"),
            "inner"
        )
        .filter(
            F.col("crl.ingressed_at_dt").between(
                F.col("ci.campaign_start_dt"),
                F.col("ci.campaign_end_dt")
            )
        )
    )

    # Comprehensive validation (optional)
    if enable_validation and campaign_requests_filtered.isEmpty():
        if validate_joins_func:
            error_msg = validate_joins_func(
                left_df=camp_request_link_df,
                right_df=campaign_info_df,
                join_query=DiagnosticQuery.CITRUS_RECORDS_JOIN_QUERY.value,
                heading="Citrus records JOIN VALIDATION FAILED - No rows fetched.",
                left_df_name='camp_request_link_df',
                right_df_name='campaign_info_df'
            )

            error_msg += DiagnosticMessage.CITRUS_RECORDS_FAILURE_SUGGESTION.value

            raise JoinValidationError(error_msg)
        else:
            raise ValueError("Campaign request filtering produced no results")

    # Aggregate metrics per campaign
    campaign_metrics_df = (
        campaign_requests_filtered
        .groupBy("advertising_campaign_nk1")
        .agg(
            F.sum("sales_revenue_amt").alias("sales"),
            F.sum("conversions_cnt").alias("conversions"),
            F.sum("impressions_cnt").alias("impressions"),
            F.sum("clicks_cnt").alias("clicks")
        )
        .withColumnRenamed("advertising_campaign_nk1", "campaign_id")
    )

    return campaign_metrics_df


def join_completed_campaigns(
    meta_job_bag_join: DataFrame,
    meta_insights_with_measures: DataFrame
) -> DataFrame:
    """
    Joins the `meta_job_bag_join` DataFrame with `meta_insights_with_measures` DataFrame
    for completed campaigns using exact date matches.

    Args:
        meta_job_bag_join (DataFrame): DataFrame containing campaign metadata and job bag details.
        meta_insights_with_measures (DataFrame): DataFrame containing Meta insights with measures.

    Returns:
        DataFrame: A DataFrame containing the joined insights for completed campaigns.
    """
    return meta_job_bag_join.join(
        meta_insights_with_measures,
        (
            meta_job_bag_join["digital_trading_campaign_channel_nk1"] ==
            meta_insights_with_measures["digital_trading_campaign_nk1"]
        ) &
        (meta_insights_with_measures["reporting_start_dt"] == meta_job_bag_join["campaign_start_dt"]) &
        (meta_insights_with_measures["reporting_end_dt"] == meta_job_bag_join["campaign_end_dt"]),
        how="inner"
    )


def join_ongoing_campaigns(
    meta_job_bag_join: DataFrame,
    meta_insights_with_measures: DataFrame
) -> DataFrame:
    """
    Joins the `meta_job_bag_join` DataFrame with `meta_insights_with_measures` DataFrame
    for ongoing campaigns by fetching the latest available data based on `reporting_end_dt`.

    Args:
        meta_job_bag_join (DataFrame): DataFrame containing campaign metadata and job bag details.
        meta_insights_with_measures (DataFrame): DataFrame containing Meta insights with measures.

    Returns:
        DataFrame: A DataFrame containing the joined insights for ongoing campaigns.
    """
    latest_snapshot = meta_insights_with_measures.join(
        meta_job_bag_join.select(
            F.col("digital_trading_campaign_channel_nk1").alias("campaign_nk"),
            F.col("campaign_start_dt")
        ),
        (meta_insights_with_measures["digital_trading_campaign_nk1"] == F.col("campaign_nk")) &
        (meta_insights_with_measures["reporting_start_dt"] == F.col("campaign_start_dt")),
        "inner"
    ).groupBy("campaign_nk").agg(
        F.max("reporting_end_dt").alias("latest_end_dt")
    )

    return meta_job_bag_join.join(
        meta_insights_with_measures,
        (
            meta_job_bag_join["digital_trading_campaign_channel_nk1"] ==
            meta_insights_with_measures["digital_trading_campaign_nk1"]
        ) &
        (meta_insights_with_measures["reporting_start_dt"] == meta_job_bag_join["campaign_start_dt"]),
        "inner"
    ).join(
        latest_snapshot,
        (meta_job_bag_join["digital_trading_campaign_channel_nk1"] == latest_snapshot["campaign_nk"]) &
        (meta_insights_with_measures["reporting_end_dt"] == latest_snapshot["latest_end_dt"]),
        "inner"
    ).drop("campaign_nk", "latest_end_dt")


def extract_hierarchy_codes(config: dict, key: str) -> List[int]:
    """
    Extract hierarchy codes from configuration dictionary.

    Args:
        config: Configuration dictionary with hierarchy mappings
        key: Key to extract (e.g., 'channel_codes')

    Returns:
        List of integer codes, empty list if key not found
    """
    codes = config.get(key, [])
    if not codes:
        return []
    # Ensure it's always a list
    return codes if isinstance(codes, list) else [codes]
