"""
/**************************************************************************
* Script Name: reach_engagement.py
*
* Objective:
* This script is designed to compute reach and engagement metrics for
* various marketing channels. It processes data from multiple upstream
* sources, applies advanced business logic, and generates detailed results
* for further analysis and reporting. The script calculates metrics such as
* reach, engagement click through rate along with clicks and impression for digital channels,
* sales and noting down the media spend based on the specific requirements of each
* channel. It handles potential errors, and logs issues for troubleshooting.
* Channels Covered:
* - reach is calculated for the following channels:
*   - Meta
*   - DV360
*   - Onsite-GOL
*   - In-store
*   - Ecoupons
*   - Coupon at Till
*   - YouTube
*   - Magazine
* - Engagement is calculated for the following channels:
*   - Meta
*   - DV360
*   - Onsite-GOL
*   - YouTube
*
* Confluence Link: https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/657261818/reach+and+Engagement
*
* Upstream:
* - USER_JOURNEY_OFFER
*
* Downstream:
* - SKU_LEVEL_ATTRIBUTED_sales_AND_UNITS_OFFER
# - MEASUREMENT_CAMPAIGN_REPORTING
*

# Set these configurations before your join. However, this auto skewness resolution did not work
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.skewedPartitionFactor", "5")
spark.conf.set("spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes", "256MB")
**************************************************************************/
"""

from datetime import datetime

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.window import Window
from pyspark.sql import functions as F
from typing import Optional, List
from functools import reduce

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.reach_engagement.data_quality import (
    DataQualityError, JoinValidationError,
    DiagnosticMessage, DiagnosticQuery,
    validate_media_spend_amt,
    validate_joins)
from spark_pipeline.schemas.reach_engagement import ReachEngagementSchema
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.reach_engagement.re_utils import (
    calculate_combined_reach, aggregate_campaign_metrics)
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


# Ask to return all cammpaigns and not just the first record.
def fetch_in_progress_campaigns(df: DataFrame) -> DataFrame:
    """
    df: Input dataframe is measurement_campaign_execution
    Retrieves all campaigns that are currently "In-progress".
    Returns a DataFrame containing all matching rows.
    """
    in_progress_campaigns = df.select(
        "booking_id",
        "campaign_duration"
    ).cache()

    if in_progress_campaigns.count() == 0:
        raise ValueError("Error: no campaign found to execute the model!")

    return in_progress_campaigns


def get_latest_data_for_campaigns(data: DataFrame, filter_df: DataFrame) -> DataFrame:
    """
    Retrieves the latest records for all booking IDs, handling cases where:
    - Both booking_id and campaign_duration are not null
    - booking_id is not null but campaign_duration is null

    Args:
        data: DataFrame containing the full dataset
        filter_df: DataFrame containing booking_id and campaign_duration columns

    Returns:
        DataFrame with the latest records for each in-progress booking
    """
    # Validate input columns
    required_columns = {"booking_id", "campaign_duration"}
    missing_columns = required_columns - set(filter_df.columns)
    if missing_columns:
        raise ValueError(f"Input DataFrame missing required columns: {missing_columns}")

    has_campaign_duration = "campaign_duration" in filter_df.columns
    join_keys = ["booking_id", "campaign_duration"] if (has_campaign_duration and "campaign_duration" in data.columns) else ["booking_id"]

    # Broadcast the small filter_df
    broadcast_filter_df = F.broadcast(filter_df)

    # Step 1: Detect skewed keys dynamically (e.g., keys with > 100,000 records)
    key_counts = (
        data.join(broadcast_filter_df, join_keys, "inner")
        .groupBy("booking_id")
        .count()
    )
    skewed_keys = [row.booking_id for row in key_counts.filter(F.col("count") > 100000).collect()]

    # Step 2: Salt the data and filter DataFrames separately for skewed vs. normal keys
    # Salt data for skewed keys: Add a random salt value (0-99)
    data_salted = data.withColumn(
        "salt",
        F.when(F.col("booking_id").isin(skewed_keys), (F.rand() * 100).cast("int")).otherwise(F.lit(0))
    )

    # For filter_df, explode skewed keys to all salt values (0-99), and keep normal keys with salt=0
    # Avoid nesting explode() in CASE WHEN by using separate operations
    filter_skewed = broadcast_filter_df.filter(F.col("booking_id").isin(skewed_keys))
    filter_normal = broadcast_filter_df.filter(~F.col("booking_id").isin(skewed_keys))

    # Explode skewed keys to generate salt values (0-99)
    salt_values = [F.lit(i) for i in range(100)]
    filter_skewed_salted = filter_skewed.withColumn("salt", F.explode(F.array(salt_values)))

    # For normal keys, assign salt=0
    filter_normal_salted = filter_normal.withColumn("salt", F.lit(0))

    # Combine skewed and normal salted filter DataFrames
    filter_salted = filter_skewed_salted.unionByName(filter_normal_salted)

    # Step 3: Perform the salted join
    joined_df = data_salted.join(
        filter_salted,
        join_keys + ["salt"],
        "inner"
    ).drop("salt")

    return joined_df


def calculate_reach(journey_data: DataFrame, unified_campaign_df: DataFrame, group_by_column: str) -> DataFrame:
    """
    Optimized function to calculate marketing campaign reach, sales, and conversions for multiple campaigns.

    This function avoids iterating over the input DataFrame and instead uses a single, efficient join
    and aggregation strategy to compute metrics for all campaigns in parallel.

    Parameters:
        journey_data (DataFrame): The input DataFrame containing user journey data.
        unified_campaign_df (DataFrame): A DataFrame containing campaign details ('campaign_id', 'marketing_type', 'channel_name').
        group_by_column (str): The column to group by, specific to certain marketing types.

    Returns:
        DataFrame: A DataFrame with aggregated insights for all specified campaigns.
    """

    # 1. Enrich the journey data with campaign-specific information from the input_df.
    # This join is crucial for performing all subsequent operations in a distributed manner,
    # avoiding the need for a costly .collect() call and Python loops.

    # Detect skew campaigns dynamically
    campaign_stats = (
        journey_data.groupBy("campaign_id")
        .agg(F.count("*").alias("record_count"))
        .filter(F.col("record_count") > 100000)  # Adjust threshold as needed
    )

    skewed_campaigns = [row.campaign_id for row in campaign_stats.collect()]

    # 2. Add salt to journey data for skewed campaigns
    journey_salted = journey_data.withColumn(
        "salt",
        F.when(F.col("campaign_id").isin(skewed_campaigns),
               (F.rand() * 100).cast("int"))
        .otherwise(F.lit(0))
    )

    # 3. Prepare unified campaign data with salt for skewed campaigns
    unified_skewed = unified_campaign_df.filter(F.col("campaign_id").isin(skewed_campaigns))
    unified_normal = unified_campaign_df.filter(~F.col("campaign_id").isin(skewed_campaigns))

    # Create salted version for skewed campaigns
    salt_values = [F.lit(i) for i in range(100)]
    unified_skewed_salted = unified_skewed.withColumn("salt", F.explode(F.array(salt_values)))
    unified_normal_salted = unified_normal.withColumn("salt", F.lit(0))

    unified_salted = unified_skewed_salted.unionByName(unified_normal_salted)

    # 4. Perform salted join
    j = journey_salted.alias("j")
    u = unified_salted.alias("u")

    join_condition = F.when(
        F.col("j.marketing_type") == "In-store",
        (F.col("j.campaign_id") == F.col("u.campaign_id")) &
        (F.col("j.salt") == F.col("u.salt"))
    ).otherwise(
        (F.col("j.campaign_id") == F.col("u.campaign_id")) &
        (F.col("j.channel_name") == F.col("u.channel_name")) &
        (F.col("j.salt") == F.col("u.salt"))
    )

    joined_df = j.join(u, join_condition, "inner").select(
        "j.campaign_id",
        "u.marketing_type",
        "u.channel_name",
        "j.subchannel_name",
        "j.loyalty_id",
        "j.userjourney_id",
        "j.isconversion",
        "j.net_sales_amt",
        "j.booking_id"
    ).drop("salt")

    coupon_channels = ["coupon at till", "ecoupons"]

    # Partition for join key branching
    coupon_df = joined_df.filter(F.lower(F.col("channel_name")).isin([c.lower() for c in coupon_channels]))
    other_df = joined_df.filter(~F.lower(F.col("channel_name")).isin([c.lower() for c in coupon_channels]))

    # Dynamic group keys
    group_keys_coupon = ["booking_id", "campaign_id", "channel_name", group_by_column]
    group_keys_other = ["booking_id", "campaign_id", "channel_name", "subchannel_name", group_by_column]

    group_keys_coupon = list(set(group_keys_coupon))
    group_keys_other = list(set(group_keys_other))

    # Aggregation
    # Coupon channels
    coupon_agg = (
        coupon_df.groupBy(*group_keys_coupon)
        .agg(
            F.countDistinct("loyalty_id").alias("reach"),
            F.sum("net_sales_amt").alias("sales"),
            F.countDistinct("userjourney_id").alias("conversions")
        ).withColumn("clicks", F.lit(0))
         .withColumn("impressions", F.lit(0))
    )

    # Other channels
    other_agg = (
        other_df.groupBy(*group_keys_other)
        .agg(
            F.countDistinct("loyalty_id").alias("reach"),
            F.sum("net_sales_amt").alias("sales"),
            F.countDistinct("userjourney_id").alias("conversions"),
        ).withColumn("clicks", F.lit(0))
         .withColumn("impressions", F.lit(0))
    )

    # Final union and column alignment
    all_data = coupon_agg.unionByName(other_agg, allowMissingColumns=True)

    # Propagate marketing_type via left join from spark_df
    marketing_type_map = (
        u
        .select("campaign_id", "channel_name", F.col("marketing_type").alias("U_marketing_type"))
        .dropDuplicates()
    )
    final_df = (
        all_data.join(
            marketing_type_map,
            on=["campaign_id", "channel_name"],
            how="left"
        )
    )

    # Standard column ordering
    return (
        final_df
        .withColumn("marketing_type", F.col("U_marketing_type"))
        .select(
            "campaign_id",
            "channel_name",
            "subchannel_name",
            "reach",
            "clicks",
            "impressions",
            "sales",
            "conversions",
            "booking_id",
            "marketing_type"
        )
    )


def meta_processor(
    digital_trading_campaign_sat_df: DataFrame,
    digital_trading_campaign_link_df: DataFrame,
    digital_trading_lineitem_facebook_insight_df: DataFrame,
    unified_campaign_df: DataFrame,
) -> DataFrame:
    """
    Extracts and aggregates Meta (Facebook) reach and engagement metrics
    for campaigns, optimized for PySpark.

    This function joins campaign metadata, campaign link data, and Facebook
    line-item insights to produce a unified DataFrame containing key
    performance metrics for each campaign in `unified_campaign_df`. It is
    specifically designed to work with Meta's (Facebook) advertising
    reporting data.

    Args:
        digital_trading_campaign_sat_df (DataFrame):
            Snapshot table containing campaign-level attributes, such as
            campaign name, objectives, and platform details.

        digital_trading_campaign_link_df (DataFrame):
            Mapping table linking trading campaigns to line items
            (ads/ad sets), allowing the join between campaign-level and
            line-item-level data.

        digital_trading_lineitem_facebook_insight_df (DataFrame):
            Fact table containing Facebook line-item metrics such as
            impressions, reach, clicks, spend, and engagement KPIs.

        unified_campaign_df (DataFrame):
            Filtered list of campaigns to process, containing:
            - booking_id
            - job_bag_number
            - channel_name
            - campaign_start_dt
            - campaign_end_dt
            - marketing_type
            - campaign_id
            - subchannel_name

    Returns:
        DataFrame:
            Aggregated metrics per campaign for Meta reach & engagement,
            typically including:
            - booking_id
            - campaign_id
            - reach
            - impressions
            - MEDIA_AMT_spend
            - ENGAGEMENTS
            - Any other relevant KPIs from Facebook insights

    Notes:
        - The function assumes that the date ranges in `unified_campaign_df`
          match the available data in the Facebook insights table.
        - Metrics are aggregated at the campaign level and filtered only
          for campaigns present in `unified_campaign_df`.
        - This function is intended for Meta (Facebook) data only, not
          cross-channel processing.
    """

    # --- Load Meta job bag data (only required cols, no MapType here) ---
    meta_jobbag = (
        digital_trading_campaign_sat_df
        .select("digital_trading_campaign_nk1",
                "job_bag_id")
        .dropDuplicates()
    )

    # --- Load Meta campaign link data ---
    meta_campaign_link = (
        digital_trading_campaign_link_df
        .select("digital_trading_campaign_nk1",
                "digital_trading_campaign_channel_nk1")
        .dropDuplicates()
    )

    # --- Join job bag with campaign link ---
    meta_job_bag_join = meta_jobbag.join(
        meta_campaign_link, on="digital_trading_campaign_nk1", how="inner"
    )

    unified_campaign_info = unified_campaign_df.select(
        "job_bag_number",  # or campaign_id depending on processor
        "campaign_start_dt",
        "campaign_end_dt",
        "channel_name",
        "booking_id",
        "marketing_type",
        "subchannel_name"  # only if needed
    )

    # --- Join unified campaign params ---
    meta_job_bag_join = meta_job_bag_join.join(
        unified_campaign_info,
        meta_job_bag_join["job_bag_id"] == unified_campaign_info["job_bag_number"],
        how="inner"
    )

    # Join again with original insights DF (to keep measures) without dropDuplicates
    meta_insights_with_measures = digital_trading_lineitem_facebook_insight_df

    # --- Join with date filtering ---
    meta_with_insights = meta_job_bag_join.join(
        meta_insights_with_measures,
        (
            meta_job_bag_join["digital_trading_campaign_channel_nk1"] ==
            meta_insights_with_measures["digital_trading_campaign_nk1"]
        ) &
        (meta_insights_with_measures["reporting_start_dt"] == meta_job_bag_join["campaign_start_dt"]) &
        (meta_insights_with_measures["reporting_end_dt"] == meta_job_bag_join["campaign_end_dt"]),
        how="inner"
    )

    if meta_with_insights.isEmpty():
        error_msg = validate_joins(meta_job_bag_join,
                                   meta_insights_with_measures,
                                   DiagnosticQuery.META_WITH_INSIGHTS_JOIN_QUERY.value,
                                   heading="META meta_with_insights FAILED - No rows found for this join",
                                   left_df_name='meta_job_bag_join',
                                   right_df_name='meta_insights_with_measures'
                                   )

        error_msg += DiagnosticMessage.META_WITH_INSIGHTS_SUGGESTION.value

        raise JoinValidationError(error_msg)

    measures_schema = ReachEngagementSchema().measures_schema

    meta_with_insights = meta_with_insights.withColumn("measures", F.from_json(F.col("measures"), measures_schema))

    # --- Extract KPIs ---
    kpi_df = (
        meta_with_insights
        .withColumn("total_reach", F.col("measures")["summary"]["reach"].cast("int"))
        .withColumn("total_clicks", F.col("measures")["summary"]["clicks"].cast("int"))
        .withColumn("total_impressions", F.col("measures")["summary"]["impressions"].cast("int"))
        .withColumn("total_sales", F.col("measures")["sales"]["total"].cast("int"))
        .withColumn("total_conversions", F.col("measures")["conversion"]["totals"].cast("int"))
        .withColumn("media_spend_amt", F.col("measures")["internals"]["media_spend"].cast("int"))
    )

    # --- Keep only latest records using row_number() ---
    window_spec = Window.partitionBy(
        "job_bag_id",
        "digital_trading_insight_id",
        "digital_trading_lineitem_nk1"
    ).orderBy(F.col("record_arrival_ts").desc())

    latest_df = (
        kpi_df
        .withColumn("rn", F.row_number().over(window_spec))
        .filter(F.col("rn") == 1)
    )

    # --- Aggregate ---
    final_meta_df = (
        latest_df
        .groupBy("job_bag_id",
                 "channel_name",
                 "subchannel_name",
                 "marketing_type",
                 "booking_id")
        .agg(
            F.sum("total_reach").cast("int").alias("reach"),
            F.sum("total_clicks").cast("int").alias("clicks"),
            F.sum("total_impressions").cast("int").alias("impressions"),
            F.sum("total_sales").cast("int").alias("sales"),
            F.sum("total_conversions").cast("int").alias("conversions"),
            F.sum("media_spend_amt").cast("int").alias("media_spend_amt"),
        )
        .withColumnRenamed("job_bag_id", "campaign_id")
    )

    # Check for NULL media_spend_amt
    bad_rows = final_meta_df.filter(F.col("media_spend_amt").isNull())

    if bad_rows is not None and not bad_rows.isEmpty():
        error_msg = validate_media_spend_amt(
            bad_rows,
            heading="META media_spend_amt has a null value",
            derived="measures->internal->media_spend"
        )

        raise DataQualityError(error_msg)
    return final_meta_df


def youtube_processor(
    dv360_media_report_df: DataFrame,
    dv360_order_report_df: DataFrame,
    dv360_floodlight_report_df: DataFrame,
    unified_campaign_df: DataFrame
) -> DataFrame:
    """
    Extracts and aggregates YouTube campaign performance metrics
    from DV360 reports, filtered to only the campaigns present in
    `unified_campaign_df`.

    This processor joins media, order, and floodlight reports from
    Display & Video 360 (DV360) to produce campaign-level metrics
    such as impressions, views, reach, and spend, specifically for
    YouTube campaigns.

    Args:
        dv360_media_report_df (DataFrame):
            DV360 media report containing delivery metrics such as
            impressions, clicks, and video views at the placement level.

        dv360_order_report_df (DataFrame):
            DV360 order report containing campaign and insertion order
            details, mapping delivery data to campaign-level attributes.

        dv360_floodlight_report_df (DataFrame):
            DV360 floodlight report containing conversion metrics,
            including actions, purchases, and other post-click or
            post-view KPIs.

        unified_campaign_df (DataFrame):
            Filtered list of campaigns to process, containing:
            - job_bag_id
            - campaign_start_dt
            - campaign_end_dt
            - channel_name
            - booking_id
            - marketing_type
            - subchannel_name

    Returns:
        DataFrame:
            Aggregated campaign-level YouTube metrics, typically including:
            - booking_id
            - job_bag_id
            - impressions
            - reach
            - VIEWS
            - VIEW_RATE
            - MEDIA_AMT_spend
            - conversions
            - Any other KPIs from DV360 reports

    Notes:
        - Only campaigns in `unified_campaign_df` are processed.
        - The function assumes date ranges in `unified_campaign_df` align
          with the reporting periods of the DV360 reports.
        - Intended for YouTube campaign data only; other DV360 placements
          are excluded.
    """

    unified_campaign_info = unified_campaign_df.select(
        "job_bag_number",  # or campaign_id depending on processor
        "campaign_start_dt",
        "campaign_end_dt",
        "channel_name",
        "booking_id",
        "marketing_type",
        "subchannel_name"  # only if needed
    )

    # Alias for clarity
    ucd = unified_campaign_info.alias("ucd")

    # Prepare media report with join filter based on unified_campaign_df params
    # Join media report with unified_campaign_df on job_bag_id == jobbag_id to get parameters per row
    media_with_params = (
        dv360_media_report_df
        .dropDuplicates().drop("subchannel_name")
        .join(
            ucd,
            dv360_media_report_df["jobbag_id"] == ucd["job_bag_number"],
            "inner"
        )
        # Filter on campaign date range from unified_campaign_df columns
        .filter(
            (F.col("campaign_date") >= F.col("campaign_start_dt")) &
            (F.col("campaign_date") <= F.col("campaign_end_dt"))
        )
        # Add subchannel_name from unified_campaign_df
        .withColumn("subchannel_name", F.col("ucd.subchannel_name"))
    )

    # Cache for multiple operations
    media_with_params.cache()

    if media_with_params.isEmpty():
        error_msg = validate_joins(
            ucd, dv360_media_report_df, DiagnosticQuery.MEDIA_WITH_PARAMS_JOIN_QUERY.value,
            heading="Youtube/DV360 MEDIA WITH PARAMS JOIN VALIDATION FAILED - No rows fetched after applying join and filter",
            left_df_name='ucd',
            right_df_name='dv360_media_report_df'
        )

        error_msg += DiagnosticMessage.MEDIA_WITH_PARAMS_FAILURE_SUGGESTION.value

        raise JoinValidationError(error_msg)

    # First aggregation: group by finer granularity to sum metrics and get latest run_at
    media_agg_1 = (
        media_with_params
        .groupBy(
            "line_item_id", "jobbag_id", "subchannel_name",
            "time_of_day", "device_type", "campaign_date"
        )
        .agg(
            F.sum("clicks").cast("int").alias("clicks"),
            F.sum("impressions").cast("int").alias("impressions"),
            F.sum("total_conversions").cast("int").alias("conversions"),
            F.max("run_at").alias("run_at"),
            F.sum("revenue").alias("media_spend_amt")
        )
    )

    # Check for NULL media_spend_amt
    bad_rows = media_agg_1.filter(F.col("media_spend_amt").isNull())

    if bad_rows is not None and not bad_rows.isEmpty():
        error_msg = validate_media_spend_amt(bad_rows,
                                             heading="Youtube/DV360 media_spend_amt has a null value",
                                             derived="revenue")

        raise DataQualityError(error_msg)

    # Second aggregation: collapse to line_item_id, jobbag_id, subchannel_name
    media_agg_2 = (
        media_agg_1
        .groupBy("line_item_id", "jobbag_id", "subchannel_name")
        .agg(
            F.sum("clicks").cast("int").alias("clicks"),
            F.sum("impressions").cast("int").alias("impressions"),
            F.sum("conversions").alias("conversions"),
            F.sum("media_spend_amt").cast("int").alias("media_spend_amt")
        )
    )

    # Process dv360_order_report: filter using unified_campaign_df campaign dates and country
    order_with_params = media_agg_2.join(dv360_order_report_df.dropDuplicates(), on="line_item_id", how="left")

    # Join with unified_campaign_df on jobbag_id ↔ job_bag_number
    order_with_params = (order_with_params.join(
        unified_campaign_df,
        order_with_params["jobbag_id"] == unified_campaign_df["job_bag_number"],
        how="left"
    ).filter(
            (F.col("date_from") == F.col("campaign_start_dt")) &
            (F.col("date_until") == F.col("campaign_end_dt")) &
            (F.col("country") == "GB")
    ))

    dv360_order_report_filtered = (
        order_with_params
        .groupBy("line_item_id", "country")
        .agg(
            (F.sum("total_reach") / F.countDistinct("job_bag_number")).cast("int").alias("reach")
        )
        .filter(F.col("country") == "GB")
    )

    # Process floodlight report similarly
    floodlight_with_params = media_agg_2.join(dv360_floodlight_report_df.dropDuplicates(), on="line_item_id", how="left")

    floodlight_with_params = (floodlight_with_params.join(
        unified_campaign_df,
        floodlight_with_params["jobbag_id"] == unified_campaign_df["job_bag_number"],
        how="left"
    ).filter(
            (F.col("campaign_date") == F.col("campaign_start_dt")) &
            (F.col("campaign_date") == F.col("campaign_end_dt"))
    ))

    dv360_floodlight_report_filtered = (
        floodlight_with_params
        .groupBy("line_item_id")
        .agg(
            (F.sum("spend") / F.countDistinct("job_bag_number")).cast("int").alias("sales")
        )
    )

    # Join media with order report on line_item_id
    dv360_insights = (
        media_agg_2
        .join(dv360_order_report_filtered.drop("country"), on="line_item_id", how="left")
        .join(dv360_floodlight_report_filtered, on="line_item_id", how="left")
    )

    # Join back unified_campaign_df params on jobbag_id == job_bag_id to get campaign-level columns
    dv360_insights = dv360_insights.join(
        ucd.drop("subchannel_name"),
        dv360_insights["jobbag_id"] == ucd["job_bag_number"],
        "left"
    )

    # Add fixed columns and rename
    dv360_insights = (
        dv360_insights
        .withColumnRenamed("jobbag_id", "campaign_id")
        .withColumn("channel_name", F.col("channel_name"))
        .withColumn("booking_id", F.col("booking_id"))
        .withColumn("marketing_type", F.col("marketing_type"))
    )

    # Clean subchannel_name as before
    split_subchannel = F.split(F.col("subchannel_name"), "\\|")
    dv360_insights = dv360_insights.withColumn(
        "subchannel_name", F.regexp_replace(split_subchannel[0], r"[^A-Za-z0-9_|, -]", "")
    )

    # Select final columns and fill nulls in numeric columns with 0
    youtube_final_df = (
        dv360_insights
        .select(
            "campaign_id",
            "channel_name",
            "subchannel_name",
            "reach",
            "clicks",
            "impressions",
            "sales",
            "conversions",
            "booking_id",
            "marketing_type",
            "media_spend_amt"
        )
        .fillna(0)
    )

    return youtube_final_df


def citrus_processor(
    camp_request_link_df: DataFrame,       # ADVERTISING_CAMPAIGN_REQUEST_REALISED_LINK
    unified_campaign_df: DataFrame,        # Columns: campaign_id, campaign_start_dt, campaign_end_dt, channel_name, booking_id, marketing_type, job_bag_number
    campaign_citcam_sat_df: DataFrame,     # ADVERTISING_CAMPAIGN_CITCAM_SAT
    user_journey_data_filtered: DataFrame  # Pre-filtered journey data
) -> DataFrame:
    """
    Processes Citrus campaign data to produce campaign-level performance
    metrics by combining campaign metadata, request link mappings,
    Citrus-specific attributes, and filtered user journey interactions.

    The function:
        1. Extracts unique campaign identifiers and attributes from
           `unified_campaign_df`.
        2. Links campaigns to Citrus-specific request data via
           `camp_request_link_df`.
        3. Merges with `campaign_citcam_sat_df` to bring in additional
           Citrus campaign metadata or metrics.
        4. Joins with `user_journey_data_filtered` to integrate
           engagement and conversion information.
        5. Produces a final dataset containing consolidated Citrus
           campaign performance results.

    Args:
        camp_request_link_df (DataFrame):
            Source table `ADVERTISING_CAMPAIGN_REQUEST_REALISED_LINK`
            Mapping of campaign IDs to request/realisation references.

        unified_campaign_df (DataFrame):
            Canonical list of campaigns to process. Expected columns:
            - campaign_id
            - campaign_start_dt
            - campaign_end_dt
            - channel_name
            - booking_id
            - marketing_type
            - job_bag_number

        campaign_citcam_sat_df (DataFrame):
            Source table `ADVERTISING_CAMPAIGN_CITCAM_SAT`
            Contains Citrus-specific campaign attributes, such as
            targeting information, format, and delivery metrics.

        user_journey_data_filtered (DataFrame):
            Pre-filtered user journey dataset aligned to the campaigns
            of interest, containing interactions, conversions, and
            engagement events.

    Returns:
        DataFrame:
            Consolidated Citrus campaign dataset containing:
            - Campaign identifiers (campaign_id, booking_id)
            - Metadata from unified campaigns
            - Citrus-specific attributes and metrics
            - Engagement/conversion KPIs from user journeys

    Notes:
        - Only campaigns in `unified_campaign_df` are processed.
        - Joins are typically performed on campaign_id and/or booking_id.
        - Date ranges from `unified_campaign_df` are expected to bound
          the relevant data in the source tables.
    """
    # --- Step 1: Get unique campaign parameters ---
    campaign_info = unified_campaign_df.select(
        "campaign_id", "campaign_start_dt", "campaign_end_dt",
        "channel_name", "booking_id", "marketing_type"
    ).dropDuplicates(["campaign_id"])

    latest_records_df = aggregate_campaign_metrics(
        camp_request_link_df=camp_request_link_df,
        campaign_info_df=campaign_info,
        validate_joins_func=validate_joins,
        enable_validation=True
    )

    # --- Step 3: Join with unified campaign metadata ---
    joined_data_df = (
        latest_records_df
        .join(campaign_info, on="campaign_id", how="inner")
    )

    # --- Step 4: Join with subchannel info ---
    campaign_citcam_sat_trimmed = campaign_citcam_sat_df.select(
        F.col("campaign_placements").alias("subchannel_name"),
        "advertising_campaign_nk1"
    )

    final_data_citrus = (
        joined_data_df
        .join(
            campaign_citcam_sat_trimmed,
            F.col("campaign_id") == F.col("advertising_campaign_nk1"),
            "inner"
        ).distinct()
    )

    # --- Step 5: reach data aggregation ---
    reach_data = (
        user_journey_data_filtered
        .groupBy("campaign_id", "booking_id", "channel_name", "subchannel_name")
        .agg(F.countDistinct("loyalty_id").alias("reach"))
    )

    # --- Step 6: Clean subchannel name ---
    split_subchannel = F.expr(
        """TRIM(CASE WHEN POSITION('-', subchannel_name) = 0
        THEN '' ELSE SUBSTR(subchannel_name, POSITION('-', subchannel_name) + 1) END)"""
    )

    final_data_citrus = final_data_citrus.withColumn("subchannel_name", split_subchannel)

    # --- Step 7: Final campaign-level aggregation ---
    final_data_citrus = (
        final_data_citrus
        .groupBy("campaign_id", "channel_name", "subchannel_name", "marketing_type", "booking_id")
        .agg(
            F.sum("clicks").cast("int").alias("clicks"),
            F.sum("impressions").cast("int").alias("impressions"),
            F.sum("sales").cast("double").alias("sales"),
            F.sum("conversions").cast("int").alias("conversions"),
        )
    )

    # --- Step 8: Merge reach data ---
    citrus_insights_data = (
        final_data_citrus
        .join(
            reach_data.drop("booking_id"),
            on=["campaign_id", "channel_name", "subchannel_name"],
            how="inner"
        )
    )

    # --- Step 9: Final select ---
    return citrus_insights_data.select(
        "campaign_id",
        "channel_name",
        "subchannel_name",
        "reach",
        "clicks",
        "impressions",
        "sales",
        "conversions",
        "booking_id",
        "marketing_type"
    )


def process_all_campaigns(measurement_campaign_execution_df: DataFrame,
                          user_journey_offer_df: DataFrame,
                          digital_trading_campaign_sat_df: DataFrame,
                          digital_trading_campaign_link_df: DataFrame,
                          digital_trading_lineitem_facebook_insight_df: DataFrame,
                          dv360_media_report_df: DataFrame,
                          dv360_order_report_df: DataFrame,
                          dv360_floodlight_report_df: DataFrame,
                          camp_request_link_df: DataFrame,
                          campaign_citcam_sat_df: DataFrame,
                          meta_campaigns_df: DataFrame,
                          unified_campaign_df: DataFrame,
                          correlation_id: str) -> DataFrame:
    """
    Processes all active marketing campaigns across multiple channels,
    aggregating reach, engagement, and conversion metrics into a single
    consolidated DataFrame.

    This function:
        1. Identifies all campaigns from
           `measurement_campaign_execution_df`.
        2. Filters campaigns by duration ("During").
        3. Processes channel-specific data for:
           - Facebook/Meta (via `digital_trading_*` datasets)
           - YouTube (via DV360 media, order, and floodlight reports)
           - Citrus retail media campaigns (via `camp_request_link_df`
             and `campaign_citcam_sat_df`)
           - Offer-based campaigns (via `user_journey_offer_df`)
        4. Joins channel metrics with `unified_campaign_df` to align with
           master campaign metadata.
        5. Returns a DataFrame containing combined performance results
           for all active campaigns.

    Args:
        measurement_campaign_execution_df (DataFrame):
            Source of campaign execution details, including booking_id,
            campaign_id, channel, and job status.

        user_journey_offer_df (DataFrame):
            Offer campaign user journey dataset containing touchpoints
            and conversion events.

        digital_trading_campaign_sat_df (DataFrame):
            Digital trading campaign details table (Meta/Facebook).

        digital_trading_campaign_link_df (DataFrame):
            Links digital trading campaigns to execution metadata.

        digital_trading_lineitem_facebook_insight_df (DataFrame):
            Facebook/Meta insights dataset containing delivery and
            engagement metrics.

        dv360_media_report_df (DataFrame):
            DV360 media performance metrics for YouTube campaigns.

        dv360_order_report_df (DataFrame):
            DV360 order-level campaign mapping for YouTube.

        dv360_floodlight_report_df (DataFrame):
            DV360 floodlight conversions for YouTube campaigns.

        camp_request_link_df (DataFrame):
            Citrus campaign request-to-realisation mapping.

        campaign_citcam_sat_df (DataFrame):
            Citrus-specific campaign metadata and performance metrics.

        meta_campaigns_df (DataFrame):
            DataFrame containing user journey records for Meta (Facebook) campaigns,
            including all touchpoints and conversion events. This dataset is used
            to identify the distinct loyalty IDs that were targeted and sent to Meta.

        unified_campaign_df (DataFrame):
            Master list of campaigns, with identifiers and metadata such
            as campaign_id, booking_id, date ranges, and channel.

        correlation_id (str):
            Unique ID for correlating logs, events, and downstream
            notifications for this execution.

    Returns:
        DataFrame:
            Consolidated campaign performance dataset containing:
            - Campaign identifiers (booking_id, campaign_id)
            - Channel-specific metrics (reach, impressions, spend,
              conversions, engagement KPIs)
            - Metadata from `unified_campaign_df`

    Notes:
        - Only campaigns with campaign_duration == "During" are processed.
        - Each channel's processing is handled by its respective
          processor (Meta, YouTube, Citrus, Offer).
        - The function assumes column naming conventions from source
          tables remain consistent.
    """

    # Fetch current in-progress campaign booking_id and duration
    in_progress_df_result = fetch_in_progress_campaigns(measurement_campaign_execution_df)

    in_progress_df_result = in_progress_df_result.filter(F.col("campaign_duration") == "During")

    unified_campaign_df = (unified_campaign_df.join(
        F.broadcast(in_progress_df_result),
        unified_campaign_df["booking_id"] == in_progress_df_result["booking_id"],
        "inner").select(unified_campaign_df["*"]).cache())

    # Get latest load_ts per campaign to get only latest records
    unified_campaign_max_load_ts = unified_campaign_df.groupBy(
        "campaign_id",
        "channel_name",
        "subchannel_name",
        "marketing_type",
        "media_spend_amt",
        "campaign_start_dt",
        "campaign_end_dt",
        "booking_id",
        "job_bag_number"
    ).agg(F.max("load_ts").alias("load_ts"))

    unified_campaign_df = unified_campaign_max_load_ts

    # Add salt to the skewed key
    user_journey_salted = user_journey_offer_df.withColumn(
        "salt", (F.rand() * 100).cast("int")
    )

    in_progress_salted = in_progress_df_result.withColumn(
        "salt", F.explode(F.array([F.lit(i) for i in range(100)]))
    )

    # Join with salted keys
    user_journey_filtered = user_journey_salted.join(
        F.broadcast(in_progress_salted),
        ["booking_id", "campaign_duration", "salt"],
        "inner"
    ).drop("salt")

    # Get latest user journey data (assuming this filters for latest load_ts)
    user_journey_latest = get_latest_data_for_campaigns(user_journey_filtered,
                                                        in_progress_df_result)

    # --- ADD: Compute dedup_campaign_reach_df KPI here
    dedup_campaign_reach_df = (
        user_journey_latest
        .groupBy("booking_id")
        .agg(F.countDistinct("loyalty_id").alias("dedup_campaign_reach"))
    )

    # ----------------------------------------------------------------------------
    # Process all channel campaigns in bulk, no explicit Python loops over campaign_rows
    # ----------------------------------------------------------------------------

    dfs_to_union = []

    # --- Meta Channel Processing ---

    meta_unified_campaigns_df = unified_campaign_df.filter(F.col("channel_name") == "Meta").cache()
    if not meta_unified_campaigns_df.isEmpty():
        meta_final = (meta_processor(digital_trading_campaign_sat_df,
                                     digital_trading_campaign_link_df,
                                     digital_trading_lineitem_facebook_insight_df,
                                     meta_unified_campaigns_df))
        meta_final = meta_final.withColumn(
            "engagement_ctr_pct", F.when(F.col("impressions") > 0, (F.col("clicks") / F.col("impressions")) * 100).otherwise(0.0)
        )
        dfs_to_union.append(meta_final)

    # --- Youtube Channel Processing ---
    dv_channels = ["DV360", "YouTube"]
    youtube_unified_campaigns_df = unified_campaign_df.filter(F.col("channel_name").isin(dv_channels))
    if not youtube_unified_campaigns_df.isEmpty():
        youtube_final = (youtube_processor(dv360_media_report_df,
                                           dv360_order_report_df,
                                           dv360_floodlight_report_df,
                                           youtube_unified_campaigns_df))
        youtube_final = youtube_final.withColumn(
            "engagement_ctr_pct", F.when(F.col("impressions") > 0, (F.col("clicks") / F.col("impressions")) * 100).otherwise(0.0)
        )
        dfs_to_union.append(youtube_final)

    instore_unified_campaigns_df = unified_campaign_df.filter(F.col("marketing_type").isin("In-store", "Magazine"))
    if not instore_unified_campaigns_df.isEmpty():
        instore_final = (calculate_reach(user_journey_latest,
                                         instore_unified_campaigns_df,
                                         group_by_column="marketing_type"))
        instore_final = instore_final.withColumn("media_spend_amt", F.lit(0.0)).withColumn("engagement_ctr_pct", F.lit(0.0))
        dfs_to_union.append(instore_final)

    gol_unified_campaigns_df = unified_campaign_df.filter(F.col("channel_name").rlike("(?i)gol"))
    if not gol_unified_campaigns_df.isEmpty():
        citrus_final = (citrus_processor(camp_request_link_df,
                                         gol_unified_campaigns_df,
                                         campaign_citcam_sat_df,
                                         user_journey_filtered))
        citrus_final = citrus_final.withColumn(
            "media_spend_amt", F.lit(0.0)
        ).withColumn(
            "engagement_ctr_pct", F.when(F.col("impressions") > 0, (F.col("clicks") / F.col("impressions")) * 100).otherwise(0.0)
        )
        dfs_to_union.append(citrus_final)

    coupon_unified_campaigns_df = unified_campaign_df.filter(
        F.lower("channel_name").isin(["coupon at till", "ecoupons"])
    )
    if not coupon_unified_campaigns_df.isEmpty():
        coupon_final = (calculate_reach(user_journey_latest,
                                        coupon_unified_campaigns_df,
                                        "subchannel_name"))
        coupon_final = coupon_final.withColumn("media_spend_amt", F.lit(0.0)).withColumn("engagement_ctr_pct", F.lit(0.0))
        dfs_to_union.append(coupon_final)

    # --- Combine all channel insights ---

    if len(dfs_to_union) == 1:
        reach_engagement = dfs_to_union[0]
    else:
        reach_engagement = reduce(lambda df1, df2: df1.unionByName(df2), dfs_to_union)

    reach_engagement = reach_engagement.withColumn("load_ts", F.current_timestamp())
    reach_engagement = reach_engagement.dropDuplicates()

    # Rename columns to naming standard
    reach_engagement = (reach_engagement.withColumnRenamed("reach", "reach_cnt")
                        .withColumnRenamed("impressions", "impressions_cnt")
                        .withColumnRenamed("conversions", "conversions_cnt")
                        .withColumnRenamed("clicks", "clicks_cnt")
                        .withColumnRenamed("sales", "sales_amt"))

    unified_campaign_df = (
        unified_campaign_df.withColumnRenamed("campaign_id", "campaign_id_uni")
        .withColumnRenamed("subchannel_name", "subchannel_name_uni")
        .withColumnRenamed("channel_name", "channel_name_uni")
        .withColumnRenamed("marketing_type", "marketing_type_uni")
        .withColumnRenamed("media_spend_amt", "media_spend_amt_uni"))

    unified_campaign_df = unified_campaign_df.groupBy(
        "channel_name_uni",
        "subchannel_name_uni",
        "campaign_id_uni",
        "marketing_type_uni"
    ).agg(F.sum("media_spend_amt_uni").alias("media_spend_amt_uni"))

    # 2. Define join condition
    join_condition = (
        (F.lower(reach_engagement["campaign_id"]) == F.lower(unified_campaign_df["campaign_id_uni"])) &
        (F.lower(reach_engagement["subchannel_name"]) == F.lower(unified_campaign_df["subchannel_name_uni"])) &
        (F.lower(reach_engagement["channel_name"]) == F.lower(unified_campaign_df["channel_name_uni"])) &
        (F.lower(reach_engagement["marketing_type"]) == F.lower(unified_campaign_df["marketing_type_uni"]))
    )

    # 3. Perform join (exclude meta/youtube/dv360 later)
    reach_engagement = (
        reach_engagement
        .join(unified_campaign_df, join_condition, "left")
    )

    # 4. Select media spend based on channel
    final_reach_engagement_df = reach_engagement.withColumn(
        "media_spend_amt",
        F.when(
            ~F.lower(F.col("channel_name")).isin("meta", "youtube", "dv360"),
            F.col("media_spend_amt_uni")
        ).otherwise(F.col("media_spend_amt"))
    ).drop("media_spend_amt_uni", "campaign_id_uni", "subchannel_name_uni", "channel_name_uni", "marketing_type_uni")

    final_reach_engagement_df = (final_reach_engagement_df.withColumn("media_spend_amt",
                                                                      F.coalesce(F.col("media_spend_amt"), F.lit(0))))

    # -- instore_onsite_loyalty_ids_df: Actual loyalty IDs exposed in in-store/onsite campaigns
    instore_onsite_loyalty_ids_df = (
        user_journey_latest
        .filter(F.lower(F.col("marketing_type")).isin(["instore", "in-store", "onsite", "targeted media"]))
        .select("loyalty_id")
        .distinct()
    )

    offsite_reported_reach = dict(
        final_reach_engagement_df
        .filter(F.lower(F.col("marketing_type")) == "offsite")
        .groupBy("channel_name")
        .agg(F.sum("reach_cnt").alias("reported_reach"))
        .select("channel_name", "reported_reach")
        .collect()
    )

    # Check if only 'offsite' marketing_type exists in the reach engagement
    distinct_marketing_types = (
        final_reach_engagement_df
        .select(F.lower(F.col("marketing_type")).alias("marketing_type"))
        .distinct()
    )

    types_list = [row["marketing_type"] for row in distinct_marketing_types.collect()]
    offsite_only = len(types_list) == 1 and types_list[0] == "offsite"

    # TODO: The current implementation for identifying 'Meta'/'Social' campaigns relies
    # on string matching.
    # This should be refactored to use a media hierarchy or standardized channel codes,
    # enabling more robust, maintainable, and less error-prone channel matching.
    # TODO: To be fixed during Hierarchy implementation
    print("Offsite Reported Reach Meta:", offsite_reported_reach.get("Meta", 0))
    print("meta_campaigns_df is None:", meta_campaigns_df is None)
    print("offsite_reported_reach.get(\"Meta\", 0) > 0 :", offsite_reported_reach.get("Meta", 0) > 0)
    print("offsite_reported_reach.get(\"Social - Meta\", 0) > 0 :", offsite_reported_reach.get("Social", 0) > 0)
    print("offsite_only:", offsite_only)
    print(distinct_marketing_types.show(truncate=False))
    if (
        any(offsite_reported_reach.get(channel, 0) > 0 for channel in ("Meta", "Social")) and
            meta_campaigns_df is not None and
            not offsite_only
    ):

        # Calculate combined reach for Instore/Onsite campaigns + Meta for now
        # TODO: Extend to other offsite channels (DV360 and Youtube) with Instore/Onsite combinations
        # in future we have more test data to validate especially for Pollen campaigns.
        # TODO: Replace string-based matching for identifying 'Social'/'Meta' campaigns with a lookup
        # using the media hierarchy mapping table.
        # This will ensure robust, maintainable channel identification and prevent errors
        # if channel names change.
        final_reach_metrics = calculate_combined_reach(
            meta_campaigns_df,
            instore_onsite_loyalty_ids_df,
            offsite_reported_reach
        )
        reach_estimate_rounded = final_reach_metrics.get("reach_estimate_rounded", 0)
        print("Final Reach Metrics All:", final_reach_metrics)
        print("Final Reach Estimate:", final_reach_metrics)
        print("Final Reach Estimate Rounded:", reach_estimate_rounded)

        # Add dedup_campaign_reach estimate to final DataFrame as the estimated reach
        final_reach_engagement_df = (
            final_reach_engagement_df
            .withColumn("dedup_campaign_reach", F.lit(reach_estimate_rounded))
        )
    else:
        # set the deduped campaign reach to the same as the sum of the reach_cnt offsite only campaigns
        if offsite_only:
            window_spec = Window.partitionBy("booking_id")
            dedup_col = F.sum("reach_cnt").over(window_spec)
        else:
            # Add dedup_campaign_reach estimate based on the booking id level de-duped Loyalty IDs
            dedup_col = F.col("dedup_campaign_reach")
            final_reach_engagement_df = final_reach_engagement_df.join(
                dedup_campaign_reach_df, on="booking_id", how="left"
            )
        final_reach_engagement_df = final_reach_engagement_df.withColumn(
            "dedup_campaign_reach", dedup_col
        )

    # Add invocation id as job_run_id metadata column
    final_reach_engagement_df = final_reach_engagement_df.withColumn("job_run_id", F.lit(correlation_id))

    print(f'\n\nreach Engagement Count: {final_reach_engagement_df.count()}')

    # Take one final look to ensure that we are not returning an empty dataframe.
    if final_reach_engagement_df.isEmpty():
        error_msg = DiagnosticMessage.REACH_ENGAGEMENT_EMPTY_DATASET.value
        raise ValueError(error_msg)

    # Return final DataFrame
    return final_reach_engagement_df


def prepare_reach_engagement(
    spark: SparkSession,
    measurement_campaign_execution_path: str,
    user_journey_offer_path: str,
    unified_campaigns_path: str,
    digital_trading_campaign_dmfbca_sat_path: str,
    digital_trading_campaign_channel_dmfbca_link_path: str,
    digital_trading_lineitem_insight_dmfbin_link_path: str,
    media_report_path: str,
    unique_reach_lineitem_report_path: str,
    floodlight_report_path: str,
    advertising_campaign_request_realised_link_path: str,
    advertising_campaign_citcam_sat_path: str,
    meta_data_path: str,
    output_reporting_path: str,
    correlation_id: str,
    run_date: str,
    run_type: str,
    slack_topic_arn: str
) -> DataFrame:
    """
    Orchestrates the end-to-end preparation of reach and engagement metrics
    for marketing campaigns by loading input datasets from given S3 paths,
    processing campaign data from multiple channels, and saving the final
    consolidated output back to S3.

    This function serves as a high-level pipeline coordinator that:
      - Reads various campaign, media, and user journey datasets from S3 in Parquet format.
      - Selects and projects relevant columns for downstream processing.
      - Invokes the core campaign processing logic to aggregate reach, engagement,
        conversions, and media spend metrics across channels including Meta, YouTube, Citrus, and offer campaigns.
      - Persists the processed output DataFrame to the specified output path in S3.

    Args:
        spark (SparkSession): SparkSession object for Spark operations.
        measurement_campaign_execution_path (str): S3 path to measurement campaign execution data.
        user_journey_offer_path (str): S3 path to user journey offer campaign data.
        unified_campaign_path (str): S3 path to unified campaign master data.
        digital_trading_campaign_dmfbca_sat_path (str): S3 path to digital trading campaign satellite data (Meta/Facebook).
        digital_trading_campaign_channel_dmfbca_link_path (str): S3 path to digital trading campaign channel linkage data.
        digital_trading_lineitem_insight_dmfbin_link_path (str): S3 path to digital trading Facebook line item insights.
        media_report_path (str): S3 path to YouTube media report data.
        unique_reach_lineitem_report_path (str): S3 path to unique reach line item report.
        floodlight_report_path (str): S3 path to DV360 floodlight conversion report.
        advertising_campaign_request_realised_link_path (str): S3 path to Citrus advertising campaign request-realised linkage.
        advertising_campaign_citcam_sat_path (str): S3 path to Citrus campaign satellite metadata.
        meta_data_path (str): S3 path to Meta campaign user journey data.
        output_path (str): S3 path to write the final processed reach and engagement DataFrame.
        correlation_id (str): Unique identifier for tracking this pipeline execution.
        run_date (str): Execution date for the pipeline run, used for logging and auditing.

    Returns:
        DataFrame: A Spark DataFrame containing the consolidated reach and engagement metrics
        for all processed campaigns, ready for downstream analytics or reporting.

    Side Effects:
        - Reads multiple input datasets from S3 in Parquet format.
        - Writes the final aggregated DataFrame to the specified output_path in Parquet format.
        - Prints the count of records in the final DataFrame to the console/logs.

    Notes:
        - Assumes the input Parquet files have consistent schema and column naming conventions.
        - The function filters campaigns based on in-progress status and campaign duration internally.
        - This function is designed to replace legacy DBT SQL logic with PySpark processing for improved scalability and maintainability.
    """
    slack_messenger = SlackMessenger(
        topic_arn=slack_topic_arn,
        correlation_id=correlation_id
    )

    measurement_campaign_execution_df = (
        spark.read.parquet(measurement_campaign_execution_path).select(
            "campaign_id",
            "booking_id",
            "marketing_type",
            "campaign_duration",
            "job_status"
        )
    )

    digital_trading_campaign_dmfbca_sat_df = (
        spark.read.parquet(digital_trading_campaign_dmfbca_sat_path).select(
            "digital_trading_campaign_nk1",
            "digital_trading_campaign_nk3",
            "record_arrival_ts",
            "campaign_name",
            "job_bag_id"
        )
    )

    digital_trading_campaign_channel_dmfbca_link_df = (
        spark.read.parquet(digital_trading_campaign_channel_dmfbca_link_path).select(
            "digital_trading_campaign_nk1",
            "digital_trading_campaign_nk3",
            "digital_trading_campaign_channel_nk1",
            "digital_trading_campaign_channel_nk3",
            "digital_trading_advertiser_nk1",
            "digital_trading_advertiser_nk3",
            "digital_trading_brand_nk1",
            "digital_trading_brand_nk3"
        )
    )

    digital_trading_lineitem_facebook_insight_df = (
        spark.read.parquet(digital_trading_lineitem_insight_dmfbin_link_path).select(
            "digital_trading_campaign_nk1",
            "digital_trading_campaign_nk3",
            "digital_trading_brand_nk1",
            "digital_trading_brand_nk3",
            "digital_trading_lineitem_nk1",
            "digital_trading_lineitem_nk3",
            "digital_trading_insight_id",
            "record_arrival_ts",
            "reporting_start_dt",
            "reporting_end_dt",
            "measures"
        )
    )

    media_report_df = (
        spark.read.parquet(media_report_path).select(
            "jobbag_id",
            "line_item_id",
            "clicks",
            "impressions",
            "total_conversions",
            "time_of_day",
            "device_type",
            "campaign_date",
            "run_at",
            "revenue"
        )
    )

    unique_reach_lineitem_report_df = (
        spark.read.parquet(unique_reach_lineitem_report_path).select(
            "date_from",
            "date_until",
            "line_item_id",
            "total_reach",
            "country"
        )
    )

    floodlight_report_df = (
        spark.read.parquet(floodlight_report_path).select(
            "run_at",
            "campaign_date",
            "floodlight_id",
            "insertion_order_id",
            "insertion_order_name",
            "line_item_id",
            "total_conversions",
            "spend"
        )
    )

    user_journey_offer_df = (
        spark.read.parquet(user_journey_offer_path).select(
            "campaign_id",
            "isconversion",
            "net_sales_amt",
            "subchannel_name",
            "channel_name",
            "booking_id",
            "load_ts",
            "loyalty_id",
            "marketing_type",
            "userjourney_id",
            "campaign_duration"
        )
    )

    advertising_campaign_request_realised_link_df = (
        spark.read.parquet(advertising_campaign_request_realised_link_path).select(
            "advertising_campaign_nk1",
            "ingressed_at_dt",
            "sales_revenue_amt",
            "conversions_cnt",
            "impressions_cnt",
            "clicks_cnt",
        )
    )

    advertising_campaign_citcam_sat_df = (
        spark.read.parquet(advertising_campaign_citcam_sat_path).select(
            "advertising_campaign_nk1",
            "advertising_campaign_nk3",
            "campaign_name",
            "campaign_type",
            "campaign_subtype",
            "campaign_valid_state",
            "campaign_placements"
        )
    )

    unified_campaign_df = (
        spark.read.parquet(unified_campaigns_path).select(
            "campaign_id",
            "media_spend_amt",
            "job_bag_number",
            "campaign_start_dt",
            "campaign_end_dt",
            "subchannel_name",
            "channel_name",
            "campaign_name",
            "booking_id",
            "load_ts",
            "marketing_type",
            "unique_brand_name"
        )
    )

    try:
        # --- Load Meta campaign user journeys to find the loyalty ids sent to meta ---
        meta_campaigns_df = spark.read.parquet(meta_data_path).select("LOYALTY_ID")
    except FileNotFoundError as e:
        print(f"Error: File not found at path '{meta_data_path}': {e}")
        meta_campaigns_df = None
    except Exception as e:
        print(f"Unexpected error reading parquet file at '{meta_data_path}': {e}")
        meta_campaigns_df = None
    finally:
        print(f"Completed parquet read attempt for path: '{meta_data_path}'")

    try:
        distinct_booking_ids = (
            measurement_campaign_execution_df
            .select(F.collect_set("booking_id").alias("booking_ids"))
            .first()["booking_ids"]
        ) or []
        # Convert to comma-separated string
        booking_ids_string = ", ".join(distinct_booking_ids) if distinct_booking_ids else ""

        reach_engagement_df = process_all_campaigns(
            measurement_campaign_execution_df,
            user_journey_offer_df,
            digital_trading_campaign_dmfbca_sat_df,
            digital_trading_campaign_channel_dmfbca_link_df,
            digital_trading_lineitem_facebook_insight_df,
            media_report_df,
            unique_reach_lineitem_report_df,
            floodlight_report_df,
            advertising_campaign_request_realised_link_df,
            advertising_campaign_citcam_sat_df,
            meta_campaigns_df,
            unified_campaign_df,
            correlation_id
        )

    except ValueError as ve:
        slack_text = f"""❌ Reach Engagement failure:\n
                                    Correlation_id: {correlation_id}\n
                                        Booking_ids: {booking_ids_string}\n
                    """
        # Send the formatted message to Slack
        slack_messenger.send_message(
            event_type="Reach Engagemen Notification",
            text=slack_text,
            data={"Reach Engagement Failure Diagnosis": f"```\n{ve}\n```"},
        )
        raise

    # TODO: consider timezones also - should probably pass ZoneInfo("Europe/London") to this as well?
    current_ts = datetime.now()

    # Output reporting output

    df2 = (reach_engagement_df
           .withColumn("run_type", F.lit(run_type))
           .withColumn("dag_run_ts", F.lit(current_ts))
           .select(
               "campaign_id",
               "channel_name",
               "subchannel_name",
               "marketing_type",
               "booking_id",
               "reach_cnt",
               "dedup_campaign_reach",
               "clicks_cnt",
               "impressions_cnt",
               "sales_amt",
               "conversions_cnt",
               "media_spend_amt",
               "engagement_ctr_pct",
               "load_ts",
               "job_run_id",
               "run_type",
               "dag_run_ts"
           ))

    spark_s3_overwrite(output_reporting_path, df2)

    return reach_engagement_df


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    """
    Entry point for the New Launch Estimation baseline pipeline.

    Parses required command-line arguments for input and output S3 paths, along with
    metadata parameters, then invokes the main processing function to run the pipeline.

    Args:
        spark (SparkSession): Active SparkSession for Spark operations.
        command_line_args (Optional[List[str]]): List of command-line arguments to parse.
            If None, uses sys.argv by default.

    Command-line Arguments:
        --measurement-campaign-execution-path (str): S3 path for measurement campaign execution data.
        --digital-trading-campaign-dmfbca-sat-path (str): S3 path for campaign selection data.
        --digital-trading-campaign-channel-dmfbca-link-path (str): S3 path for campaign channel linkage data.
        --digital-trading-lineitem-insight-dmfbin-link-path (str): S3 path for DV360 processed line item insights.
        --media-report-path (str): S3 path for SKU cluster mapping report.
        --unique-reach-lineitem-report-path (str): S3 path for unique reach line item report.
        --floodlight-report-path (str): S3 path for floodlight baseline modelling output.
        --user-journey-offer-path (str): S3 path for user journey offer data.
        --advertising-campaign-request-realised-link-path (str): S3 path for advertising campaign request data.
        --advertising-campaign-citcam-sat-path (str): S3 path for advertising campaign satellite data.
        --meta-data-path (str): S3 path for Meta user journey data.
        --unified-campaigns-path (str): S3 path for unified campaign data.
        --output-reporting-path (str): S3 path where the pipeline reporting output will be saved.
        --correlation-id (str): Unique identifier for the pipeline run for traceability.
        --run-date (str): Date of pipeline execution in YYYY-MM-DD format.
        --run-type (str): Run type for this execution, either 'Pollen' or 'DTP'.
        --slack-topic-arn (str): ARN of the Slack topic for notifications.

    Raises:
        ArgumentError: If required command-line arguments are missing or invalid.

    Side Effects:
        Reads input datasets from specified S3 paths, executes the data processing workflow,
        writes output back to S3, and logs relevant progress information.
    """
    parser = ThrowingArgumentParser(description="New Launch Estimation for baseline pipeline.")
    parser.add_argument(
        "--measurement-campaign-execution-path",
        type=str,
        required=True,
        help="S3 path for measurement campaign execution."
    )
    parser.add_argument(
        "--digital-trading-campaign-dmfbca-sat-path",
        type=str,
        required=True,
        help="The output S3 path for the campaign selection python."
    )
    parser.add_argument(
        "--digital-trading-campaign-channel-dmfbca-link-path",
        type=str,
        required=True,
        help="The output S3 path for the new launch proxy mapping."
    )
    parser.add_argument(
        "--digital-trading-lineitem-insight-dmfbin-link-path",
        type=str,
        required=True,
        help="The output S3 path for the dv360 processed data."
    )
    parser.add_argument(
        "--media-report-path",
        type=str,
        required=True,
        help="S3 path for sku cluster mapping."
    )
    parser.add_argument(
        "--unique-reach-lineitem-report-path",
        type=str,
        required=True,
        help="S3 path for fact sale transaction item path."
    )
    parser.add_argument(
        "--floodlight-report-path",
        type=str,
        required=True,
        help="S3 path for baseline modelling output."
    )
    parser.add_argument(
        "--user-journey-offer-path",
        type=str,
        required=True,
        help="S3 path for user journey data."
    )
    parser.add_argument(
        "--advertising-campaign-request-realised-link-path",
        type=str,
        required=True,
        help="S3 path for sku cluster mapping."
    )
    parser.add_argument(
        "--advertising-campaign-citcam-sat-path",
        type=str,
        required=True,
        help="S3 path for fact sale transaction item path."
    )
    parser.add_argument(
        "--meta-data-path",
        type=str,
        required=True,
        help="S3 path for Meta user journey data."
    )
    parser.add_argument(
        "--unified-campaigns-path",
        type=str,
        required=True,
        help="S3 path for unified campaign path."
    )
    parser.add_argument(
        "--output-reporting-path",
        type=str,
        required=True,
        help="The path in S3 to output reporting data"
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="unique correlation id."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--run-type",
        type=str,
        required=True,
        help="Run type for this run, either 'Pollen' or DTP'"
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN of the Slack topic for notifications."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    _ = prepare_reach_engagement(
        spark=spark,
        measurement_campaign_execution_path=known_args.measurement_campaign_execution_path,
        user_journey_offer_path=known_args.user_journey_offer_path,
        unified_campaigns_path=known_args.unified_campaigns_path,
        digital_trading_campaign_dmfbca_sat_path=known_args.digital_trading_campaign_dmfbca_sat_path,
        digital_trading_campaign_channel_dmfbca_link_path=known_args.digital_trading_campaign_channel_dmfbca_link_path,
        digital_trading_lineitem_insight_dmfbin_link_path=known_args.digital_trading_lineitem_insight_dmfbin_link_path,
        media_report_path=known_args.media_report_path,
        unique_reach_lineitem_report_path=known_args.unique_reach_lineitem_report_path,
        floodlight_report_path=known_args.floodlight_report_path,
        advertising_campaign_request_realised_link_path=known_args.advertising_campaign_request_realised_link_path,
        advertising_campaign_citcam_sat_path=known_args.advertising_campaign_citcam_sat_path,
        meta_data_path=known_args.meta_data_path,
        output_reporting_path=known_args.output_reporting_path,
        correlation_id=known_args.correlation_id,
        run_date=known_args.run_date,
        run_type=known_args.run_type,
        slack_topic_arn=known_args.slack_topic_arn

    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("reachEngagement").getOrCreate())
