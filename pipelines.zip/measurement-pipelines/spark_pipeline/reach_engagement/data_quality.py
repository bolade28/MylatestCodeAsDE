"""
Data Quality Validation Module

This module provides diagnostic tools for validating PySpark DataFrame joins and data quality.
It includes custom exceptions, diagnostic messages, query templates, and validation functions
to help identify and troubleshoot data pipeline issues.

Classes:
    DataQualityError: Base exception for data quality issues
    JoinValidationError: Exception for join validation failures
    DiagnosticMessage: Enum containing diagnostic messages for common failures
    DiagnosticQuery: Enum containing query templates for debugging

Functions:
    spark_df_to_prettytable: Convert PySpark DataFrame to formatted table
    validate_joins: Validate join operations and generate diagnostic output
    validate_media_spend_amt: Validate media spend calculations
"""

from prettytable import PrettyTable
from pyspark.sql import DataFrame
from enum import Enum


# ============================================================================
# CUSTOM EXCEPTIONS
# ============================================================================

class DataQualityError(ValueError):
    """
    Base exception for data quality issues.

    This exception serves as the parent class for all data quality-related
    errors in the data pipeline. It extends ValueError to indicate that
    data values don't meet expected quality standards.

    Examples:
        >>> raise DataQualityError("Invalid data format detected")

        >>> try:
        ...     validate_data(df)
        ... except DataQualityError as e:
        ...     print(f"Data quality issue: {e}")
    """
    pass


class JoinValidationError(DataQualityError):
    """
    Raised when join validation fails.

    This exception is raised when DataFrame join operations produce unexpected
    results, such as empty result sets, missing keys, or data mismatches.

    Attributes:
        message (str): Description of the join validation failure

    Examples:
        >>> if result_df.count() == 0:
        ...     raise JoinValidationError("Join returned empty result set")

        >>> try:
        ...     validate_join_result(df1, df2, result)
        ... except JoinValidationError as e:
        ...     generate_diagnostic_report(e)
    """
    pass


# ============================================================================
# DIAGNOSTIC MESSAGES
# ============================================================================

class DiagnosticMessage(Enum):
    """
    Enumeration of diagnostic messages for data validation failures.

    This enum provides standardized diagnostic messages for common data quality
    issues encountered in the data pipeline. Each message includes specific
    possible causes and troubleshooting suggestions.

    Usage:
        >>> error_msg = DiagnosticMessage.META_WITH_INSIGHTS_SUGGESTION.value
        >>> print(error_msg)

        >>> raise JoinValidationError(
        ...     DiagnosticMessage.CITRUS_RECORDS_FAILURE_SUGGESTION.value
        ... )

    Attributes:
        META_WITH_INSIGHTS_SUGGESTION: Diagnostics for Meta insights join failures
        CITRUS_RECORDS_JOIN_QUERY: Query template for Citrus records
        CITRUS_RECORDS_FAILURE_SUGGESTION: Citrus join failure diagnostics
        MEDIA_WITH_PARAMS_FAILURE_SUGGESTION: Media parameters join diagnostics
        DV360_MEDIA_REPORT_PROCESSED_SUGGESTION: DV360 report diagnostics
        CITRUS_CAMPAIGN_REQUEST_FILTERED_FAILURE_SUGGESTION: Campaign request diagnostics
        USER_JOURNEY_DATA_FILTERED_SUGGESTION: User journey data diagnostics
        POLLEN_CITRUS_INSIGHT_SUGGESTION: Pollen-Citrus insight diagnostics
        REACH_ENGAGEMENT_EMPTY_DATASET: Reach engagement empty dataset error
    """

    # Meta insights join diagnostics
    META_WITH_INSIGHTS_SUGGESTION = (
        "\nPossible causes:\n"
        "  - No combination of all 3 keys exists in both datasets\n"
        "  - No match for digital_trading_campaign_channel_nk1 and digital_trading_campaign_nk1\n"
        "  - Date misalignment between reporting dates and campaign dates\n"
        "  - NULL values in date columns\n"
        "  - Date format/type mismatches\n"
        f"{'=' * 80}\n"
    )

    # Citrus records query
    CITRUS_RECORDS_JOIN_QUERY = """
  campaign_requests_filtered = (
        camp_request_link_df.alias("crl")
        .join(campaign_info.alias("uc"),
              F.col("crl.advertising_campaign_nk1") == F.col("uc.campaign_id"),
              "inner")
        .groupBy("uc.campaign_id")
        .agg(
            F.sum("crl.sales_revenue_amt").alias("sales"),
            F.sum("crl.conversions_cnt").alias("conversions"),
            F.sum("crl.impressions_cnt").alias("impressions"),
            F.sum("crl.clicks_cnt").alias("clicks")
        )
    )
"""

    # Citrus failure diagnostics
    CITRUS_RECORDS_FAILURE_SUGGESTION = (
        "\nPossible causes:\n"
        "  - No matching campaign IDs (if join failed)\n"
        "  - ingressed_at_dt outside campaign date ranges (if filter removed all)\n"
        "  - NULL values in join keys or date columns\n"
        "  - Data type mismatches\n"
        "  - Campaign requests ingressed before/after campaign windows\n"
        f"{'=' * 80}\n"
    )

    MEDIA_WITH_PARAMS_FAILURE_SUGGESTION = (
        f"\nPossible causes:\n"
        f"  - No matching job_bag_number values.\n"
        f"  - campaign_date outside campaign date ranges\n"
        f"  - NULL values in join keys or date columns\n"
        f"  - Data type mismatches\n"
        f"  - Campaign dates in media report don't align with campaign windows in UCD\n"
        f"{'=' * 80}\n"
    )

    DV360_MEDIA_REPORT_PROCESSED_SUGGESTION = (
        "\nPossible causes:\n"
        "  - The join-keys values for insertion_order_id does not match campaign_id\n"
        "  - No overlap between media dates and campaign date ranges\n"
        "  - Date format mismatches\n"
        "  - NULL values in date columns\n"
    )

    CITRUS_CAMPAIGN_REQUEST_FILTERED_FAILURE_SUGGESTION = (
        f"\nPossible causes:\n"
        f"  - No matching campaign_id values\n"
        f"  - ingressed_at_dt outside campaign date ranges\n"
        f"  - NULL values in join keys or date columns\n"
        f"  - Date format/type mismatches\n"
        f"{'=' * 80}\n"
    )

    USER_JOURNEY_DATA_FILTERED_SUGGESTION = (
        f"\nPossible causes:\n"
        f"  - No matching values between subchannel_name and marketing_subchannel\n"
        f"  - Case sensitivity issues (e.g., 'Email' vs 'email')\n"
        f"  - Leading/trailing whitespace\n"
        f"  - NULL values in join keys\n"
        f"  - Different naming conventions\n"
        f"{'=' * 80}\n"
    )

    POLLEN_CITRUS_INSIGHT_SUGGESTION = (
        "\nPossible causes:\n"
        "  - No combination of all 3 keys exists in both datasets\n"
        "  - Naming convention differences (e.g., subchannel vs media_placement)\n"
        "  - Case sensitivity or whitespace issues\n"
        "  - NULL values in join keys\n"
        "  - Data granularity mismatch\n"
    )

    # Reach engagement error
    REACH_ENGAGEMENT_EMPTY_DATASET = (
        f"{'=' * 80}\n"
        "Reach Engagement Error because the final dataset is empty. This will lead to\n"
        "downstream dataset (measurement_campaign_reporting) failure because of media_spend_amt\n"
        f"{'=' * 80}\n"
    )


# ============================================================================
# DIAGNOSTIC QUERIES
# ============================================================================

class DiagnosticQuery(Enum):
    """
    Enumeration of diagnostic query templates for debugging join operations.

    This enum provides standardized PySpark query templates that can be used
    to reproduce and debug join failures. Each query shows the exact join
    conditions and filters that should be applied.

    Usage:
        >>> query = DiagnosticQuery.META_WITH_INSIGHTS_JOIN_QUERY.value
        >>> logger.info(f"Failed query:\n{query}")

        >>> diagnostic_msg = validate_joins(
        ...     left_df, right_df,
        ...     join_query=DiagnosticQuery.CITRUS_RECORDS_JOIN_QUERY.value
        ... )

    Attributes:
        MEDIA_WITH_PARAMS_JOIN_QUERY: Media report with parameters join
        POLLEN_DV360_MEDIA_REPORT_PROCESSED: DV360 media report processing
        META_WITH_INSIGHTS_JOIN_QUERY: Meta insights join with date filtering
        CITRUS_RECORDS_JOIN_QUERY: Citrus campaign request aggregation
        POLLEN_CAMPAIGN_REQUEST_FILTERED_QUERY: Campaign request filtering
        USER_JOURNEY_DATA_FILTERED_QUERY: User journey data subchannel mapping
        POLLEN_CITRUS_INSIGHT_QUERY: Pollen-Citrus metrics with reach data
    """

    MEDIA_WITH_PARAMS_JOIN_QUERY = """
        media_with_params = (
            dv360_media_report_df
            .dropDuplicates().drop("subchannel_name")
            .join(
                ucd,
                dv360_media_report_df["jobbag_id"] == ucd["job_bag_number"],
                "inner"
            )
            # Filter on campaign date range from unified_campaign_df columns
            .filter(
                (F.col("campaign_date") >= F.col("campaign_start_dt")) &
                (F.col("campaign_date") <= F.col("campaign_end_dt"))
            )
            # Add subchannel_name from unified_campaign_df
            .withColumn("subchannel_name", F.col("ucd.subchannel_name"))
        )
    """

    POLLEN_DV360_MEDIA_REPORT_PROCESSED = """
        dv360_media_report
            .join(campaign_params,
                (dv360_media_report[join_key] == campaign_params["campaign_id"]) &
                (dv360_media_report["campaign_date"].between(
                    campaign_params["campaign_start_dt"],
                    campaign_params["campaign_end_dt"]
                )),
                "inner")
    """

    META_WITH_INSIGHTS_JOIN_QUERY_COMPLETED = """
        meta_with_insights = meta_job_bag_join.join(
            meta_insights_with_measures,
            (
                meta_job_bag_join["digital_trading_campaign_channel_nk1"] ==
                meta_insights_with_measures["digital_trading_campaign_nk1"]
            ) &
            (meta_insights_with_measures["reporting_start_dt"] == meta_job_bag_join["campaign_start_dt"]) &
            (meta_insights_with_measures["reporting_end_dt"] == meta_job_bag_join["campaign_end_dt"]),
            how="inner"
        )
    """

    META_WITH_INSIGHTS_JOIN_QUERY_ONGOING = """
       latest_snapshot = meta_insights_with_measures.join(
            meta_job_bag_join.select(
                F.col("digital_trading_campaign_channel_nk1").alias("campaign_nk"),
                F.col("campaign_start_dt")
            ),
            (meta_insights_with_measures["digital_trading_campaign_nk1"] == F.col("campaign_nk")) &
            (meta_insights_with_measures["reporting_start_dt"] == F.col("campaign_start_dt")),
            "inner"
        ).groupBy("campaign_nk").agg(
            F.max("reporting_end_dt").alias("latest_end_dt")
        )

        return meta_job_bag_join.join(
            meta_insights_with_measures,
            (
                meta_job_bag_join["digital_trading_campaign_channel_nk1"] ==
                meta_insights_with_measures["digital_trading_campaign_nk1"]
            ) &
            (meta_insights_with_measures["reporting_start_dt"] == meta_job_bag_join["campaign_start_dt"]),
            "inner"
        ).join(
            latest_snapshot,
            (meta_job_bag_join["digital_trading_campaign_channel_nk1"] == latest_snapshot["campaign_nk"]) &
            (meta_insights_with_measures["reporting_end_dt"] == latest_snapshot["latest_end_dt"]),
            "inner"
        ).drop("campaign_nk", "latest_end_dt")
    """

    CITRUS_RECORDS_JOIN_QUERY = """
    campaign_requests_filtered = (
            camp_request_link_df.alias("crl")
            .join(campaign_info.alias("uc"),
                F.col("crl.advertising_campaign_nk1") == F.col("uc.campaign_id"),
                "inner")
            .filter(
                F.col("crl.INGRESSED_AT_DT").between(F.col("uc.campaign_start_dt"), F.col("uc.campaign_end_dt"))
            )
            .groupBy("uc.campaign_id")
            .agg(
                F.sum("crl.sales_revenue_amt").alias("sales"),
                F.sum("crl.conversions_cnt").alias("conversions"),
                F.sum("crl.impressions_cnt").alias("impressions"),
                F.sum("crl.clicks_cnt").alias("clicks")
            )
        )
    """

    POLLEN_CAMPAIGN_REQUEST_FILTERED_QUERY = """
    campaign_requests_filtered = (
        camp_request_link_df
        .join(
            F.broadcast(unified_campaign_df.select("campaign_id", "campaign_start_dt", "campaign_end_dt")),
            camp_request_link_df["advertising_campaign_nk1"] == unified_campaign_df["campaign_id"],
            "inner"
        )
        .filter(
            F.col("ingressed_at_dt").between(
                F.col("campaign_start_dt"), F.col("campaign_end_dt")
            )
        )
    )
    """

    USER_JOURNEY_DATA_FILTERED_QUERY = """
    user_journey_data_filtered_result = user_journey_data_filtered.join(map_df,
                                                                 user_journey_data_filtered['subchannel_name'] ==
                                                                 map_df['marketing_subchannel'])
    """

    POLLEN_CITRUS_INSIGHT_QUERY = """
    citrus_insights_df = (
        aggregated_metrics_df
        .join(
            reach_df.drop("booking_id"),
            (aggregated_metrics_df.campaign_id == reach_df.campaign_id_new) &
            (aggregated_metrics_df.channel_name == reach_df.channel_name_new) &
            (aggregated_metrics_df.subchannel_name_new == reach_df.media_placement),  # prevent duplicate columns
            how="inner"
        )
    )
    """


# ============================================================================
# VALIDATION FUNCTIONS
# ============================================================================

def spark_df_to_prettytable(df: DataFrame, limit: int = 20) -> PrettyTable:
    """
    Convert a PySpark DataFrame to a PrettyTable for formatted display.

    This function collects a limited number of rows from a PySpark DataFrame
    and formats them as a PrettyTable for easy visualization. The table is
    printed to stdout and returned for further use.

    Args:
        df (DataFrame): The PySpark DataFrame to convert.
        limit (int, optional): Maximum number of rows to display. Defaults to 20.
            Use a small limit to avoid memory issues with large DataFrames.

    Returns:
        PrettyTable: A formatted table object containing the DataFrame data.
            The table has left-aligned columns and no width limitation.

    Side Effects:
        Prints the formatted table to stdout.

    Warnings:
        - This function calls .collect() which brings data to the driver node.
          Only use with small DataFrames or appropriate limits.
        - Large limits may cause memory issues or performance degradation.

    Examples:
        >>> df = spark.createDataFrame([(1, "Alice"), (2, "Bob")], ["id", "name"])
        >>> table = spark_df_to_prettytable(df, limit=10)
        +----+-------+
        | id | name  |
        +----+-------+
        | 1  | Alice |
        | 2  | Bob   |
        +----+-------+

        >>> # Use in validation context
        >>> if result_df.count() == 0:
        ...     spark_df_to_prettytable(source_df.distinct(), limit=5)

    Note:
        The function configures the PrettyTable with:
        - Left alignment for all columns
        - No maximum width constraint
        - All DataFrame columns included
    """
    # Collect rows to the driver (safe for small datasets)
    rows = df.limit(limit).collect()

    # Create PrettyTable with DataFrame column names
    table = PrettyTable()
    table.field_names = df.columns

    # Add each row to the table
    for row in rows:
        # Convert Row object to list of values
        table.add_row([row[c] for c in df.columns])

    # Disable width limitation
    table.max_width = None

    # Optional: align columns and adjust formatting
    table.align = "l"
    return table


def validate_joins(
    left_df: DataFrame,
    right_df: DataFrame,
    join_query: str,
    left_df_name: str = None,
    right_df_name: str = None,
    heading: str = None
) -> str:
    """
    Validate join operations and generate diagnostic output.

    This function creates a comprehensive diagnostic message when a join operation
    produces unexpected results (e.g., empty result set). It displays both input
    DataFrames with their distinct values to help identify join key mismatches,
    data quality issues, or incorrect join conditions.

    Args:
        left_df (DataFrame): The left DataFrame in the join operation.
        right_df (DataFrame): The right DataFrame in the join operation.
        join_query (str): The PySpark join query code that failed. This is displayed
            in the diagnostic output to show what was attempted.
        left_df_name (str, optional): Descriptive name for the left DataFrame
            (e.g., "campaigns_table"). Defaults to None, which displays as "None".
        right_df_name (str, optional): Descriptive name for the right DataFrame
            (e.g., "metrics_table"). Defaults to None, which displays as "None".
        heading (str, optional): Custom heading for the diagnostic message
            (e.g., "Join Validation Failed"). Defaults to None.

    Returns:
        str: A formatted diagnostic message containing:
            - Custom heading (if provided)
            - Separator line (80 characters)
            - The join query that was executed
            - Left DataFrame name and distinct values (as PrettyTable)
            - Right DataFrame name and distinct values (as PrettyTable)

    Side Effects:
        - Prints PrettyTables for both DataFrames to stdout via spark_df_to_prettytable()
        - Calls .distinct() on both DataFrames, which triggers Spark computations

    Raises:
        None: This function does not raise exceptions but is typically used
            within try-except blocks or data validation pipelines.

    Examples:
        >>> # Basic usage
        >>> campaigns = spark.createDataFrame([("C1", "2024-01-01")], ["id", "date"])
        >>> metrics = spark.createDataFrame([("M1", 1000)], ["id", "value"])
        >>>
        >>> if result.count() == 0:
        ...     error_msg = validate_joins(
        ...         left_df=campaigns,
        ...         right_df=metrics,
        ...         join_query="campaigns.join(metrics, on='id', how='inner')",
        ...         left_df_name="campaigns_table",
        ...         right_df_name="metrics_table",
        ...         heading="❌ Join Failed: No Matching IDs"
        ...     )
        ...     print(error_msg)

        >>> # With diagnostic enums
        >>> error_msg = validate_joins(
        ...     left_df=job_bag_df,
        ...     right_df=insights_df,
        ...     join_query=DiagnosticQuery.META_WITH_INSIGHTS_JOIN_QUERY.value,
        ...     left_df_name="job_bag",
        ...     right_df_name="insights",
        ...     heading="Date Filter Removed All Rows"
        ... )
        >>> raise JoinValidationError(error_msg)

    Usage Pattern:
        >>> result_df = left.join(right, on='key', how='inner')
        >>> if result_df.count() == 0:
        ...     diagnostic = validate_joins(
        ...         left_df=left,
        ...         right_df=right,
        ...         join_query="left.join(right, on='key', how='inner')",
        ...         left_df_name="source",
        ...         right_df_name="target",
        ...         heading="Empty Join Result"
        ...     )
        ...     # Log or raise with diagnostic information
        ...     print(diagnostic)

    Note:
        - The function calls .distinct() on both DataFrames to show only unique
          values, which helps identify join key issues more clearly.
        - For large DataFrames, only the first 20 distinct rows are displayed
          (default limit in spark_df_to_prettytable).
        - The diagnostic output is designed to be human-readable for debugging.
    """
    error_msg = (
        f"{heading}\n"
        f"{'=' * 80}\n"
        f"\n{join_query}\n"
    )

    # Show sample IDs from both sides
    error_msg += f"\nLeft_df {left_df_name}:\n{spark_df_to_prettytable(left_df.distinct())}\n"
    error_msg += f"\nRight_df {right_df_name}:\n{spark_df_to_prettytable(right_df.distinct())}\n"

    return error_msg


def validate_media_spend_amt(
    bad_rows: DataFrame,
    heading: str = None,
    derived: str = None
) -> str:
    """
    Validate media spend amount calculations and generate diagnostic output.

    This function validates that media_spend_amt has been calculated correctly
    by checking for problematic rows. If issues are found, it generates a
    diagnostic message showing the bad rows and the derivation logic used.

    Args:
        bad_rows (DataFrame): DataFrame containing rows with invalid or problematic
            media_spend_amt values. This could include NULL values, negative amounts,
            or values that don't match expected calculations.
        heading (str, optional): Custom heading for the diagnostic message
            (e.g., "Media Spend Validation Failed"). Defaults to None.
        derived (str, optional): Description of how media_spend_amt should be
            calculated (e.g., "SUM(impressions * cpm / 1000)"). This helps
            developers understand the expected calculation. Defaults to None.

    Returns:
        str or None:
            - If bad_rows is empty: Returns None (validation passed)
            - If bad_rows has data: Returns formatted diagnostic message containing:
                * Separator line (80 characters)
                * Custom heading
                * Explanation of calculation method
                * PrettyTable showing problematic rows
                * Closing separator line

    Side Effects:
        - Checks if RDD is empty using .isEmpty(), which triggers Spark computation
        - Prints PrettyTable of bad rows to stdout if issues are found

    Examples:
        >>> # Check for NULL media spend values
        >>> bad_rows = final_df.filter(F.col("media_spend_amt").isNull())
        >>> error_msg = validate_media_spend_amt(
        ...     bad_rows=bad_rows,
        ...     heading="NULL Media Spend Detected",
        ...     derived="impressions * cpm / 1000"
        ... )
        >>> if error_msg:
        ...     print(error_msg)
        ...     raise DataQualityError(error_msg)

        >>> # Validate calculation logic
        >>> bad_rows = df.filter(
        ...     F.col("media_spend_amt") != (F.col("impressions") * F.col("cpm") / 1000)
        ... )
        >>> error_msg = validate_media_spend_amt(
        ...     bad_rows=bad_rows,
        ...     heading="Media Spend Calculation Mismatch",
        ...     derived="SUM(impressions * cpm / 1000) per campaign"
        ... )

        >>> # Check for negative values
        >>> bad_rows = df.filter(F.col("media_spend_amt") < 0)
        >>> error_msg = validate_media_spend_amt(
        ...     bad_rows=bad_rows,
        ...     heading="Negative Media Spend Values",
        ...     derived="aggregated from daily_spend"
        ... )

    Usage Pattern:
        >>> # Validate after aggregation
        >>> aggregated_df = df.groupBy("campaign_id").agg(
        ...     F.sum("daily_spend").alias("media_spend_amt")
        ... )
        >>> bad_rows = aggregated_df.filter(
        ...     F.col("media_spend_amt").isNull() |
        ...     (F.col("media_spend_amt") <= 0)
        ... )
        >>> validation_msg = validate_media_spend_amt(
        ...     bad_rows=bad_rows,
        ...     heading="Invalid Media Spend After Aggregation",
        ...     derived="SUM(daily_spend)"
        ... )
        >>> if validation_msg:
        ...     handle_validation_failure(validation_msg)

    Note:
        - Returns None if validation passes (no bad rows), which allows for
          clean conditional error handling.
        - Uses .isEmpty() for efficient empty check without collecting data.
        - Shows sample of problematic rows (default 20) via spark_df_to_prettytable.
        - Particularly important for downstream datasets that depend on accurate
          media_spend_amt values (e.g., measurement_campaign_reporting).

    Warnings:
        - The function displays potentially sensitive financial data.
        - Ensure appropriate access controls when logging or displaying output.
        - For large datasets of bad rows, only a sample is shown.
    """
    error_msg = None
    if not bad_rows.isEmpty():
        # Extract a small sample of problematic rows (for debugging)

        error_msg = (
            f"{'=' * 80}\n"
            f"{heading}\n"
            f"media_spend_amt is calculated by suming the value {derived}\n"
            f"\n{spark_df_to_prettytable(bad_rows)}\n"
            f"{'=' * 80}\n"
        )
    return error_msg
