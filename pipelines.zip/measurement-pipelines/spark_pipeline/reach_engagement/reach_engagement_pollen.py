"""
/**************************************************************************
* Script Name: reach_engagement.py
*
* Objective:
* This script is designed to compute reach and engagement metrics for
* various marketing channels. It processes data from multiple upstream
* sources, applies advanced business logic, and generates detailed results
* for further analysis and reporting. The script calculates metrics such as
* reach, engagement click through rate along with clicks and impression for digital channels,
* sales and noting down the media spend based on the specific requirements of each
* channel. It handles potential errors, and logs issues for troubleshooting.
* Channels Covered:
* - Reach is calculated for the following channels:
*   - Meta
*   - DV360
*   - Onsite-GOL
*   - In-store
*   - Ecoupons
*   - Coupon at Till
*   - YouTube
*   - Magazine
* - Engagement is calculated for the following channels:
*   - Meta
*   - DV360
*   - Onsite-GOL
*   - YouTube
*
* Confluence Link: https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/657261818/Reach+and+Engagement
*
* Upstream:
* - USER_JOURNEY_OFFER
*
* Downstream:
* - SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_OFFER
# - MEASUREMENT_CAMPAIGN_REPORTING
*

# Set these configurations before your join. However, this auto skewness resolution did not work
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.skewedPartitionFactor", "5")
spark.conf.set("spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes", "256MB")
**************************************************************************/
"""
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import types as T
from pyspark.sql import functions as F
from typing import Optional, List
from functools import reduce
from pyspark.sql.window import Window
import json

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser, str_to_bool
from spark_pipeline.reach_engagement.data_quality import (
    DataQualityError, JoinValidationError,
    DiagnosticMessage, DiagnosticQuery,
    validate_media_spend_amt,
    validate_joins)
from spark_pipeline.schemas.reach_engagement import ReachEngagementSchema
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.reach_engagement.re_utils import (
    calculate_combined_reach, aggregate_campaign_metrics,
    join_completed_campaigns, join_ongoing_campaigns, extract_hierarchy_codes)
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


# Ask to return all cammpaigns and not just the first record.
def fetch_in_progress_campaigns(df: DataFrame) -> DataFrame:
    """
    df: Input dataframe is measurement_campaign_execution
    Retrieves all campaigns that are currently "In-progress".
    Returns a DataFrame containing all matching rows.
    """
    in_progress_campaigns = df.select(
        "booking_id",
        "campaign_duration"
    ).cache()

    if in_progress_campaigns.count() == 0:
        raise ValueError("Error: no campaign found to execute the model!")

    return in_progress_campaigns


def get_latest_data_for_campaigns(data: DataFrame, filter_df: DataFrame) -> DataFrame:
    """
    Retrieves the latest records for all booking IDs, handling cases where:
    - Both BOOKING_ID and CAMPAIGN_DURATION are not null
    - BOOKING_ID is not null but CAMPAIGN_DURATION is null

    Args:
        data: DataFrame containing the full dataset
        filter_df: DataFrame containing BOOKING_ID and CAMPAIGN_DURATION columns

    Returns:
        DataFrame with the latest records for each in-progress booking
    """
    # Validate input columns
    required_columns = {"booking_id", "campaign_duration"}
    missing_columns = required_columns - set(filter_df.columns)
    if missing_columns:
        raise ValueError(f"Input DataFrame missing required columns: {missing_columns}")

    # Normalize column names to lowercase for case-insensitive comparison
    data_cols = [col.lower() for col in data.columns]
    filter_cols = [col.lower() for col in filter_df.columns]

    # Check if 'campaign_duration' exists in both DataFrames (case-insensitively)
    has_campaign_duration = "campaign_duration" in filter_cols and "campaign_duration" in data_cols

    # Define join keys accordingly
    join_keys = ["booking_id", "campaign_duration"] if has_campaign_duration else ["booking_id"]

    # Broadcast the small filter_df
    broadcast_filter_df = F.broadcast(filter_df)

    # Step 1: Detect skewed keys dynamically (e.g., keys with > 100,000 records)
    key_counts = (
        data.join(broadcast_filter_df, join_keys, "inner")
        .groupBy("booking_id")
        .count()
    )
    skewed_keys = [row.booking_id for row in key_counts.filter(F.col("count") > 100000).collect()]

    # Step 2: Salt the data and filter DataFrames separately for skewed vs. normal keys
    # Salt data for skewed keys: Add a random salt value (0-99)
    data_salted = data.withColumn(
        "salt",
        F.when(F.col("booking_id").isin(skewed_keys), (F.rand() * 100).cast("int")).otherwise(F.lit(0))
    )

    # For filter_df, explode skewed keys to all salt values (0-99), and keep normal keys with salt=0
    # Avoid nesting explode() in CASE WHEN by using separate operations
    filter_skewed = broadcast_filter_df.filter(F.col("booking_id").isin(skewed_keys))
    filter_normal = broadcast_filter_df.filter(~F.col("booking_id").isin(skewed_keys))

    # Explode skewed keys to generate salt values (0-99)
    salt_values = [F.lit(i) for i in range(100)]
    filter_skewed_salted = filter_skewed.withColumn("salt", F.explode(F.array(salt_values)))

    # For normal keys, assign salt=0
    filter_normal_salted = filter_normal.withColumn("salt", F.lit(0))

    # Combine skewed and normal salted filter DataFrames
    filter_salted = filter_skewed_salted.unionByName(filter_normal_salted)

    # Step 3: Perform the salted join
    joined_df = data_salted.join(
        filter_salted,
        join_keys + ["salt"],
        "inner"
    ).drop("salt")

    return joined_df


def process_media_report_data(
    dv360_media_report: DataFrame,
    campaign_params: DataFrame,
    join_key: str
) -> DataFrame:
    """
        Creates a processed media report DataFrame by joining the DV360 media report

        Args:
            dv360_media_report (DataFrame):
                DV360 media report containing delivery metrics such as
                impressions, clicks, and video views at the placement level.

            campaign_params (DataFrame):
                Filtered list of campaigns to process, containing:
                - campaign_start_dt
                - campaign_end_dt
                - channel_name
                - booking_id
                - marketing_type
                - subchannel_name

            join_key: str:
                The key to join on, either 'insertion_order_id' or 'campaign_id'
                depending on the channel type

        Returns:
            DataFrame:
                dv360_media_report_processed object, ready to be aggregated downstream
        """

    # ===== MEDIA REPORT PROCESSING =====

    # Join with campaign_params to filter and get multiple campaigns
    dv360_media_report_processed = (
        dv360_media_report
        .join(campaign_params,
              (dv360_media_report[join_key] == campaign_params["campaign_id"]) &
              (dv360_media_report["campaign_date"].between(
                  campaign_params["campaign_start_dt"],
                  campaign_params["campaign_end_dt"]
              )),
              "inner")
        .select(
            dv360_media_report["line_item_id"],
            dv360_media_report["clicks"],
            dv360_media_report["impressions"],
            dv360_media_report["total_conversions"],
            dv360_media_report["revenue"],
            dv360_media_report["run_at"],
            campaign_params["campaign_id"],
            campaign_params["channel_name"],
            campaign_params["booking_id"],
            campaign_params["marketing_type"],
            campaign_params["subchannel_name"]
        )
        .dropDuplicates(["line_item_id", "campaign_id", "subchannel_name"])
    )

    if dv360_media_report_processed.count() == 0:
        # ToDo: This is a check for the youtube data, it should join on campaign_id not insertion_order_id
        # However, in the mock data this doesn't work, so I try this first then default to insertion order id if it can't find any records
        dv360_media_report_processed = (
            dv360_media_report
            .join(campaign_params,
                  (dv360_media_report['insertion_order_id'] == campaign_params["campaign_id"]) &
                  (dv360_media_report["campaign_date"].between(
                      campaign_params["campaign_start_dt"],
                      campaign_params["campaign_end_dt"]
                  )),
                  "inner")
            .select(
                dv360_media_report["line_item_id"],
                dv360_media_report["clicks"],
                dv360_media_report["impressions"],
                dv360_media_report["total_conversions"],
                dv360_media_report["revenue"],
                dv360_media_report["run_at"],
                campaign_params["campaign_id"],
                campaign_params["channel_name"],
                campaign_params["booking_id"],
                campaign_params["marketing_type"],
                campaign_params["subchannel_name"]
            )
            .dropDuplicates(["line_item_id", "campaign_id", "subchannel_name"])
        )

    # Comprehensive validation with Diagnostics
    if dv360_media_report_processed.isEmpty():
        error_msg = validate_joins(dv360_media_report,
                                   campaign_params,
                                   DiagnosticQuery.POLLEN_DV360_MEDIA_REPORT_PROCESSED.value,
                                   heading="Youtube/DV360 join processed FAILED - due to No rows found.",
                                   left_df_name='dv360_media_report',
                                   right_df_name='campaign_params'
                                   )

        error_msg += DiagnosticMessage.DV360_MEDIA_REPORT_PROCESSED_SUGGESTION.value

        raise JoinValidationError(error_msg)

    return dv360_media_report_processed


def calculate_reach(journey_data: DataFrame, unified_campaign_df: DataFrame, group_by_column: str, subchannel_hierarchy_codes: dict = None) -> DataFrame:
    """
    Optimized function to calculate marketing campaign reach, sales, and conversions for multiple campaigns.

    This function avoids iterating over the input DataFrame and instead uses a single, efficient join
    and aggregation strategy to compute metrics for all campaigns in parallel.

    Parameters:
        journey_data (DataFrame): The input DataFrame containing user journey data.
        unified_campaign_df (DataFrame): A DataFrame containing campaign details ('campaign_id', 'marketing_type', 'channel_name').
        group_by_column (str): The column to group by, specific to certain marketing types.
        channel_hierarchy_code_df: Hierarchy reference table

    Returns:
        DataFrame: A DataFrame with aggregated insights for all specified campaigns.
    """

    # 1. Enrich the journey data with campaign-specific information from the input_df.
    # This join is crucial for performing all subsequent operations in a distributed manner,
    # avoiding the need for a costly .collect() call and Python loops.

    # Detect skew campaigns dynamically
    campaign_stats = (
        journey_data.groupBy("campaign_id")
        .agg(F.count("*").alias("record_count"))
        .filter(F.col("record_count") > 100000)  # Adjust threshold as needed
    )

    skewed_campaigns = [row.campaign_id for row in campaign_stats.collect()]

    # 2. Add salt to journey data for skewed campaigns
    journey_salted = journey_data.withColumn(
        "salt",
        F.when(F.col("campaign_id").isin(skewed_campaigns),
               (F.rand() * 100).cast("int"))
        .otherwise(F.lit(0))
    )

    # 3. Prepare unified campaign data with salt for skewed campaigns
    unified_skewed = unified_campaign_df.filter(F.col("campaign_id").isin(skewed_campaigns))
    unified_normal = unified_campaign_df.filter(~F.col("campaign_id").isin(skewed_campaigns))

    # Create salted version for skewed campaigns to reduce data skew during join
    salt_values = [F.lit(i) for i in range(100)]
    unified_skewed_salted = unified_skewed.withColumn("salt", F.explode(F.array(salt_values)))
    unified_normal_salted = unified_normal.withColumn("salt", F.lit(0))

    unified_salted = unified_skewed_salted.unionByName(unified_normal_salted)

    # 4. Perform salted join
    j = journey_salted.alias("j")
    u = unified_salted.alias("u")

    join_condition = (
        ((F.col("j.marketing_type").isin(["INSTORE", "ATHOME"])) &
         (F.col("j.campaign_id") == F.col("u.campaign_id")) &
         (F.col("j.salt") == F.col("u.salt"))) |
        ((~F.col("j.marketing_type").isin(["INSTORE", "ATHOME"])) &
         (F.col("j.campaign_id") == F.col("u.campaign_id")) &
         (F.col("j.channel_name") == F.col("u.channel_name")) &
         (F.col("j.salt") == F.col("u.salt")))
    )

    joined_df = j.join(u, join_condition, "inner").select(
        "j.campaign_id",
        "u.marketing_type",
        "u.channel_name",
        "u.marketing_hierarchy_cd",
        "j.subchannel_name",
        "j.loyalty_id",
        "j.userjourney_id",
        "j.isconversion",
        "j.net_sales_amt",
        "j.booking_id"
    ).drop("salt")
    joined_df.cache()

    # Get coupon hierarchy codes from subchannel_hierarchy_codes dictionary
    coupon_hierarchy_codes = (
        extract_hierarchy_codes(subchannel_hierarchy_codes, 'ecoupons') +
        extract_hierarchy_codes(subchannel_hierarchy_codes, 'coupon_at_till')
    )

    print(f"Coupon hierarchy codes for filtering: {coupon_hierarchy_codes}")

    # Partition for join key branching using hierarchy codes
    coupon_df = joined_df.filter(F.col("marketing_hierarchy_cd").isin(coupon_hierarchy_codes))
    other_df = joined_df.filter(~F.col("marketing_hierarchy_cd").isin(coupon_hierarchy_codes))

    # Dynamic group keys
    group_keys_coupon = ["booking_id", "campaign_id", "channel_name", group_by_column]
    group_keys_other = ["booking_id", "campaign_id", "channel_name", "subchannel_name", group_by_column]

    group_keys_coupon = list(set(group_keys_coupon))
    group_keys_other = list(set(group_keys_other))

    # Aggregation
    # Coupon channels
    coupon_agg = (
        coupon_df.groupBy(*group_keys_coupon)
        .agg(
            F.countDistinct("loyalty_id").alias("reach"),
            F.sum("net_sales_amt").alias("sales"),
            F.countDistinct("userjourney_id").alias("conversions")
        ).withColumn("clicks", F.lit(0))
        .withColumn("impressions", F.lit(0))
    )

    # Other channels
    other_agg = (
        other_df.groupBy(*group_keys_other)
        .agg(
            F.countDistinct("loyalty_id").alias("reach"),
            F.sum("net_sales_amt").alias("sales"),
            F.countDistinct("userjourney_id").alias("conversions"),
        ).withColumn("clicks", F.lit(0))
        .withColumn("impressions", F.lit(0))
    )

    # Final union and column alignment
    all_data = coupon_agg.unionByName(other_agg, allowMissingColumns=True)

    # Propagate MARKETING_TYPE via left join from spark_df
    marketing_type_map = (
        u
        .select("campaign_id", "channel_name", F.col("marketing_type").alias("u_marketing_type"))
        .dropDuplicates()
    )

    final_df = (
        all_data.join(
            marketing_type_map,
            on=["campaign_id", "channel_name"],
            how="left"
        )
    )

    # Standard column ordering
    return (
        final_df
        .withColumn("marketing_type", F.col("u_marketing_type"))
        .select(
            "campaign_id",
            "channel_name",
            "subchannel_name",
            "reach",
            "clicks",
            "impressions",
            "sales",
            "conversions",
            "booking_id",
            "marketing_type"
        )
    )


def meta_processor(
    digital_trading_campaign_link_df: DataFrame,
    digital_trading_campaign_facebook_insight_df: DataFrame,
    unified_campaign_df: DataFrame,
    campaign_complete: bool
) -> DataFrame:
    """
    Extracts and aggregates Meta (Facebook) reach and engagement metrics
    for campaigns, optimized for PySpark.

    This function joins campaign metadata, campaign link data, and Facebook
    line-item insights to produce a unified DataFrame containing key
    performance metrics for each campaign in `unified_campaign_df`. It is
    specifically designed to work with Meta's (Facebook) advertising
    reporting data.

    Args:

        digital_trading_campaign_link_df (DataFrame):
            Mapping table linking trading campaigns to line items
            (ads/ad sets), allowing the join between campaign-level and
            line-item-level data.

        digital_trading_campaign_facebook_insight_df (DataFrame):
            Fact table containing Facebook line-item metrics such as
            impressions, reach, clicks, spend, and engagement KPIs.

        unified_campaign_df (DataFrame):
            Filtered list of campaigns to process, containing:
            - BOOKING_ID
            - CHANNEL_NAME
            - CAMPAIGN_START_DT
            - CAMPAIGN_END_DT
            - MARKETING_TYPE
            - CAMPAIGN_ID
            - SUBCHANNEL_NAME

    Returns:
        DataFrame:
            Aggregated metrics per campaign for Meta reach & engagement,
            typically including:
            - booking_id
            - campaign_id
            - reach
            - impressions
            - media_amt_spend
            - engagements
            - Any other relevant KPIs from Facebook insights

    Notes:
        - The function assumes that the date ranges in `unified_campaign_df`
          match the available data in the Facebook insights table.
        - Metrics are aggregated at the campaign level and filtered only
          for campaigns present in `unified_campaign_df`.
        - This function is intended for Meta (Facebook) data only, not
          cross-channel processing.
    """
    meta_campaign_link = digital_trading_campaign_link_df.distinct()
    meta_insights_report = digital_trading_campaign_facebook_insight_df
    ucampaign_df = unified_campaign_df.distinct()

    unified_campaign_info = ucampaign_df.select(
        "campaign_id",  # or campaign_id depending on processor
        "campaign_start_dt",
        "campaign_end_dt",
        "channel_name",
        "booking_id",
        "marketing_type",
        "subchannel_name"  # only if needed
    )

    # --- Join unified campaign params ---
    meta_job_bag_join = meta_campaign_link.join(
        unified_campaign_info,
        meta_campaign_link["digital_trading_campaign_channel_nk1"] == unified_campaign_info["campaign_id"],
        how="inner"
    )

    # Join again with original insights DF (to keep MEASURES) without dropDuplicates
    meta_insights_with_measures = meta_insights_report

    # --- Join with date filtering ---
    if campaign_complete:
        meta_with_insights = join_completed_campaigns(
            meta_job_bag_join,
            meta_insights_with_measures
        )
        diagnostic_query = DiagnosticQuery.META_WITH_INSIGHTS_JOIN_QUERY_COMPLETED.value
    else:
        meta_with_insights = join_ongoing_campaigns(
            meta_job_bag_join,
            meta_insights_with_measures
        )
        diagnostic_query = DiagnosticQuery.META_WITH_INSIGHTS_JOIN_QUERY_ONGOING.value

    if meta_with_insights.isEmpty():
        job_bag_fld_list = [
            "digital_trading_campaign_channel_nk1",
            "campaign_id",
            "channel_name",
            "campaign_start_dt",
            "campaign_end_dt",
            "booking_id",
            "marketing_type",
            "subchannel_name"
        ]
        meta_insights_measures = [
            "digital_trading_campaign_nk1",
            "reporting_start_dt",
            "reporting_end_dt"
        ]
        error_msg = validate_joins(
            meta_job_bag_join.select(*job_bag_fld_list),
            meta_insights_with_measures.select(*meta_insights_measures),
            diagnostic_query,
            heading="Reach Engagement Pollen META meta_with_insights FAILED - No rows found for this join",
            left_df_name="meta_job_bag_join",
            right_df_name="meta_insights_with_measures"
        )

        error_msg += DiagnosticMessage.META_WITH_INSIGHTS_SUGGESTION.value

        raise JoinValidationError(error_msg)

    measures_schema = ReachEngagementSchema().measures_schema

    meta_with_insights = meta_with_insights.withColumn("measures", F.from_json(F.col("measures"), measures_schema))

    # --- Extract KPIs ---
    kpi_df = (
        meta_with_insights
        .withColumn("total_reach", F.col("measures")["summary"]["reach"].cast("int"))
        .withColumn("total_clicks", F.col("measures")["summary"]["clicks"].cast("int"))
        .withColumn("total_impressions", F.col("measures")["summary"]["impressions"].cast("int"))
        .withColumn("total_sales", F.col("measures")["sales"]["total"].cast("int"))
        .withColumn("total_conversions", F.col("measures")["conversion"]["totals"].cast("int"))
        .withColumn("media_spend_amt", F.col("measures")["internals"]["media_spend"].cast("int"))
        .withColumn("channel_name", F.col("channel_name"))
        .withColumn("subchannel_name", F.col("subchannel_name"))
    )

    # Identify latest records by arrival timestamp
    latest_records = (
        kpi_df
        .groupBy(
            "digital_trading_campaign_channel_nk1",
            "digital_trading_insight_id"
        )
        .agg(F.max("record_arrival_ts").alias("max_record_arrival_ts"))
    )

    k = kpi_df.alias("k")
    ll = latest_records.alias("ll")

    # Join with fully qualified columns
    latest_insights = (
        k.join(
            ll,
            on=(
                (k["digital_trading_campaign_channel_nk1"] == ll["digital_trading_campaign_channel_nk1"]) &
                (k["digital_trading_insight_id"] == ll["digital_trading_insight_id"]) &
                (k["record_arrival_ts"] == ll["max_record_arrival_ts"])
            ),
            how="inner"
        )
    )

    # Drop duplicate columns from `latest_records` if not needed
    latest_insights = latest_insights.drop(
        ll["digital_trading_campaign_channel_nk1"],
        ll["digital_trading_insight_id"],
        ll["max_record_arrival_ts"]
    )

    # Final select and aggregation
    final_metrics = (
        latest_insights
        .select(
            F.col("digital_trading_campaign_channel_nk1").alias("campaign_id"),
            "channel_name",
            "subchannel_name",
            "total_reach",
            "total_clicks",
            "total_impressions",
            "total_sales",
            "total_conversions",
            "media_spend_amt",
            "marketing_type",
            "booking_id"
        )
        .groupBy("campaign_id", "channel_name", "subchannel_name", "marketing_type", "booking_id")
        .agg(
            F.sum("total_reach").alias("reach"),
            F.sum("total_clicks").alias("clicks"),
            F.sum("total_impressions").alias("impressions"),
            F.sum("total_sales").alias("sales"),
            F.sum("total_conversions").alias("conversions"),
            F.sum("media_spend_amt").alias("media_spend_amt")
        )
    )

    # Check for NULL media_spend_amt
    bad_rows = final_metrics.filter(F.col("media_spend_amt").isNull())

    if bad_rows is not None and not bad_rows.isEmpty():
        error_msg = validate_media_spend_amt(
            bad_rows,
            heading="Reach Engagement META media_spend_amt has a null value",
            derived="measures->internal->media_spend"
        )
        raise DataQualityError(error_msg)

    return final_metrics


def youtube_and_dv360_processor(
        dv360_media_report: DataFrame,
        dv360_order_report: DataFrame,
        dv360_floodlight_report: DataFrame,
        unified_campaign_df: DataFrame,
        channel_type: str
):
    """
    Extracts and aggregates YouTube and DV360 campaign performance metrics
    from DV360 reports, filtered to only the campaigns present in
    `unified_campaign_df`.

    This processor joins media, order, and floodlight reports from
    Display & Video 360 (DV360) to produce campaign-level metrics
    such as impressions, views, reach, and spend, specifically for
    YouTube and DV360 campaigns.

    Args:
        dv360_media_report (DataFrame):
            DV360 media report containing delivery metrics such as
            impressions, clicks, and video views at the placement level.

        dv360_order_report (DataFrame):
            DV360 order report containing campaign and insertion order
            details, mapping delivery data to campaign-level attributes.

        dv360_floodlight_report (DataFrame):
            DV360 floodlight report containing conversion metrics,
            including actions, purchases, and other post-click or
            post-view KPIs.

        unified_campaign_df (DataFrame):
            Filtered list of campaigns to process, containing:
            - campaign_start_dt
            - campaign_end_dt
            - channel_name
            - booking_id
            - marketing_type
            - subchannel_name

        channel_type: str:
            The channel type of the campaign which
            determines how to filter the media report by

    Returns:
        DataFrame:
            Aggregated campaign-level YouTube metrics, typically including:
            - booking_id
            - impressions
            - reach
            - views
            - view_rate
            - media_amt_spend
            - conversions
            - Any other KPIs from DV360 reports

    Notes:
        - Only campaigns in `unified_campaign_df` are processed.
        - The function assumes date ranges in `unified_campaign_df` align
          with the reporting periods of the DV360 reports.
        - Intended for YouTube campaign data only; other DV360 placements
          are excluded.
    """
    campaign_params = unified_campaign_df.select(
        "campaign_id",
        "campaign_start_dt",
        "campaign_end_dt",
        "channel_name",
        "booking_id",
        "marketing_type",
        "subchannel_name"
    ).distinct()

    # ===== MEDIA REPORT PROCESSING. Requires validation =====
    # If it's dv360 we use insertion order id to join, if it's youtube we use campaign id to join
    if channel_type == 'dv360':
        dv360_media_report_processed = process_media_report_data(dv360_media_report, campaign_params,
                                                                 'insertion_order_id')
    elif channel_type == 'youtube':
        dv360_media_report_processed = process_media_report_data(dv360_media_report, campaign_params,
                                                                 'campaign_id')
    else:
        dv360_media_report_processed = process_media_report_data(dv360_media_report, campaign_params,
                                                                 'insertion_order_id')
    # Aggregate media metrics
    dv360_media_report_processed = (
        dv360_media_report_processed
        .withColumn("clicks", F.col("clicks").cast("int"))
        .withColumn("impressions", F.col("impressions").cast("int"))
        .withColumn("total_conversions", F.col("total_conversions").cast("int"))
        .withColumn("revenue", F.col("revenue").cast("int"))
    )

    dv360_media_agg = dv360_media_report_processed.groupBy(
        "line_item_id", "campaign_id", "channel_name",
        "booking_id", "marketing_type", "subchannel_name"
    ).agg(
        F.sum("clicks").alias("clicks"),
        F.sum("impressions").alias("impressions"),
        F.sum("total_conversions").alias("conversions"),
        F.sum("revenue").alias("media_spend_amt")
    )

    # Check for NULL media_spend_amt
    bad_rows = dv360_media_agg.filter(F.col("media_spend_amt").isNull())

    if bad_rows is not None and not bad_rows.isEmpty():
        error_msg = validate_media_spend_amt(bad_rows,
                                             heading="Youtube/DV360 media_spend_amt has null value",
                                             derived="revenue")

        raise DataQualityError(error_msg)

    # ===== ORDER REPORT PROCESSING =====
    # Join with campaign_params to handle multiple campaigns. Validation NOT needed
    dv360_order_report_processed = (
        dv360_order_report
        .join(campaign_params,
              (dv360_order_report["date_from"] == campaign_params["campaign_start_dt"]) &
              (dv360_order_report["date_until"] == campaign_params["campaign_end_dt"]),
              "inner")
        .filter(F.col("country") == "GB")
        .select(
            dv360_order_report["line_item_id"],
            dv360_order_report["total_reach"],
            campaign_params["campaign_id"]
        )
        .dropDuplicates(["line_item_id", "campaign_id"])
    )

    dv360_order_report_processed = dv360_order_report_processed.withColumn(
        "total_reach",
        F.col("total_reach").cast("int")
    )

    dv360_order_agg = dv360_order_report_processed.groupBy("line_item_id", "campaign_id").agg(
        F.sum("total_reach").alias("reach")
    )

    # ===== FLOODLIGHT REPORT PROCESSING =====
    # Join with campaign_params to handle multiple campaigns
    dv360_floodlight_processed = (
        dv360_floodlight_report
        .join(campaign_params,
              (dv360_floodlight_report["campaign_date"].between(
                  campaign_params["campaign_start_dt"],
                  campaign_params["campaign_end_dt"]
              )),
              "inner")
        .select(
            dv360_floodlight_report["line_item_id"],
            dv360_floodlight_report["spend"],
            campaign_params["campaign_id"]
        )
        # .dropDuplicates(["line_item_id", "campaign_id"]) -- this expression is removed as it is dropping sales and units amount which are valid"
    )

    # Aggregate sales metrics

    dv360_floodlight_processed = dv360_floodlight_processed.withColumn(
        "spend",
        F.col("spend").cast(T.DoubleType())
    )

    dv360_floodlight_agg = dv360_floodlight_processed.groupBy("line_item_id", "campaign_id").agg(
        F.sum("spend").alias("sales")
    )

    # ===== CONSOLIDATE ALL DATA =====
    # Join all datasets
    dv360_insights_data = (
        dv360_media_agg
        .join(dv360_order_agg, ["line_item_id", "campaign_id"], "left")
        .join(dv360_floodlight_agg, ["line_item_id", "campaign_id"], "left")
        .fillna(0)
    )

    columns_to_cast = {
        "clicks": "int",
        "impressions": "int",
        "conversions": "int",
        "media_spend_amt": "double",
        "reach": "int",
        "sales": "double"
    }

    for col_name, col_type in columns_to_cast.items():
        dv360_insights_data = dv360_insights_data.withColumn(
            col_name,
            F.coalesce(F.col(col_name).cast(col_type), F.lit(0 if col_type == "int" else 0.0))
        )

    # Then aggregate normally
    final_result = dv360_insights_data.groupBy(
        "campaign_id", "channel_name", "subchannel_name",
        "booking_id", "marketing_type"
    ).agg(
        F.sum("clicks").alias("clicks"),
        F.sum("impressions").alias("impressions"),
        F.sum("conversions").alias("conversions"),
        F.sum("media_spend_amt").alias("media_spend_amt"),
        F.sum("reach").alias("reach"),
        F.sum("sales").alias("sales")
    )

    return final_result.select(
        "campaign_id", "channel_name", "subchannel_name", "reach",
        "clicks", "impressions", "sales", "conversions",
        "booking_id", "marketing_type", "media_spend_amt"
    )


def citrus_processor(
    camp_request_link_df: DataFrame,  # ADVERTISING_CAMPAIGN_REQUEST_REALISED_LINK
    unified_campaign_df: DataFrame,  # Contains CAMPAIGN_ID, CAMPAIGN_START_DT, etc.
    campaign_citcam_sat_df: DataFrame,  # ADVERTISING_CAMPAIGN_CITCAM_SAT
    user_journey_data_filtered: DataFrame,  # Pre-filtered journey data
    map_df: DataFrame,
    channel_hierarchy_code_df: DataFrame
) -> DataFrame:
    """
    Processes Citrus campaign data to produce campaign-level performance
    metrics by combining campaign metadata, request link mappings,
    Citrus-specific attributes, and filtered user journey interactions.

    The function:
        1. Extracts unique campaign identifiers and attributes from
           `unified_campaign_df`.
        2. Links campaigns to Citrus-specific request data via
           `camp_request_link_df`.
        3. Merges with `campaign_citcam_sat_df` to bring in additional
           Citrus campaign metadata or metrics.
        4. Joins with `user_journey_data_filtered` to integrate
           engagement and conversion information.
        5. Produces a final dataset containing consolidated Citrus
           campaign performance results.

    Args:
        camp_request_link_df (DataFrame):
            Source table `ADVERTISING_CAMPAIGN_REQUEST_REALISED_LINK`
            Mapping of campaign IDs to request/realisation references.

        unified_campaign_df (DataFrame):
            Canonical list of campaigns to process. Expected columns:
            - campaign_id
            - campaign_start_dt
            - campaign_end_dt
            - channel_name
            - booking_id
            - marketing_type
            - channel_hierarchy_code_df: DataFrame

        campaign_citcam_sat_df (DataFrame):
            Source table `ADVERTISING_CAMPAIGN_CITCAM_SAT`
            Contains Citrus-specific campaign attributes, such as
            targeting information, format, and delivery metrics.

        user_journey_data_filtered (DataFrame):
            Pre-filtered user journey dataset aligned to the campaigns
            of interest, containing interactions, conversions, and
            engagement events.

    Returns:
        DataFrame:
            Consolidated Citrus campaign dataset containing:
            - Campaign identifiers (CAMPAIGN_ID, BOOKING_ID)
            - Metadata from unified campaigns
            - Citrus-specific attributes and metrics
            - Engagement/conversion KPIs from user journeys

    Notes:
        - Only campaigns in `unified_campaign_df` are processed.
        - Joins are typically performed on CAMPAIGN_ID and/or BOOKING_ID.
        - Date ranges from `unified_campaign_df` are expected to bound
          the relevant data in the source tables.
    """
    campaign_metrics_df = aggregate_campaign_metrics(
        camp_request_link_df=camp_request_link_df,
        campaign_info_df=unified_campaign_df,
        validate_joins_func=validate_joins,
        enable_validation=True
    )

    # Step 3: Join with campaign metadata
    campaign_with_meta = (
        campaign_metrics_df
        .join(F.broadcast(unified_campaign_df), on="campaign_id", how="inner")
    )

    campaign_with_meta = campaign_with_meta.drop("subchannel_name")

    # Step 4: Get subchannel names from CITCAM table
    subchannel_df = (
        campaign_citcam_sat_df
        .select(
            F.col("advertising_campaign_nk1").alias("campaign_id"),
            F.lower(F.col("campaign_placements")).alias("subchannel_name")
        )
    )

    # Step 5: Join to get subchannel names
    campaign_with_subchannel_df = (
        campaign_with_meta
        .join(subchannel_df, on="campaign_id", how="left").distinct()
    )

    # Step 6: Extract meaningful part of subchannel name
    campaign_with_subchannel_df = campaign_with_subchannel_df.withColumn(
        "subchannel_name",
        F.expr("""
            TRIM(CASE
                WHEN POSITION('-', subchannel_name) = 0
                THEN ''
                ELSE SUBSTR(subchannel_name, POSITION('-', subchannel_name) + 1)
            END)
        """)
    )

    # Step 7: Aggregate metrics per campaign, subchannel, etc.
    aggregated_metrics_df = (
        campaign_with_subchannel_df
        .select(
            "campaign_id",
            "channel_name",
            "subchannel_name",
            "marketing_type",
            "booking_id",
            "clicks",
            "impressions",
            "sales",
            "conversions"
        )
        .groupBy("campaign_id", "channel_name", "subchannel_name", "marketing_type", "booking_id")
        .agg(
            F.sum("clicks").cast("int").alias("clicks"),
            F.sum("impressions").cast("int").alias("impressions"),
            F.sum("sales").cast("double").alias("sales"),
            F.sum("conversions").cast("int").alias("conversions")
        )
    )
    window_spec = (
        Window.partitionBy(
            "mapping_type",
            "channel_type",
            "media_provider",
            "media_type",
            "media_subtype",
            "store_type",
            "store_location",
            "template_type",
            "media_placement"
        )
        .orderBy(F.col("load_ts").desc()))
    # Add row number column
    ranked_df = map_df.withColumn("rn", F.row_number().over(window_spec))
    ranked_df = ranked_df.withColumn("record_deleted_flag", F.get_json_object(F.col("technical_metadata"), "$.record_deleted_flag"))
# Apply filters (row_number = 1 and RECORD_DELETED_FLAG = 'N')
    map_df = ranked_df.filter((F.col("rn") == 1) & (F.coalesce(F.col("record_deleted_flag"), F.lit("N")) == "N")).drop("rn")

    map_df = map_df.filter(F.col('mapping_type') == 'INTERACTION_EVENT')

    map_df = map_df.withColumn(
        "media_placement",
        F.lower(
            F.trim(
                F.expr(
                    "substring(media_placement, instr(media_placement, '-') + 1, length(media_placement))"
                )
            )
        )
    )

    # Filter channel_hierarchy_code_df for in-scope and measurement-ready subchannels
    inscope_hierarchy_df = (
        channel_hierarchy_code_df
        .filter(
            F.col("in_scope_flag") &
            F.col("measurement_campaign_ready")
        )
        .select("marketing_subchannel", "marketing_hierarchy_cd")
        .distinct()
    )

    # Join map_df with inscope_hierarchy_df to filter only in-scope and measurement-ready subchannels
    map_df = (
        map_df
        .join(
            F.broadcast(inscope_hierarchy_df),
            F.lower(map_df["marketing_subchannel"]) == F.lower(inscope_hierarchy_df["marketing_subchannel"]),
            "inner"
        )
        .drop(inscope_hierarchy_df["marketing_subchannel"])
    )

    user_journey_data_filtered_result = user_journey_data_filtered.join(map_df,
                                                                        user_journey_data_filtered['subchannel_name'] ==
                                                                        map_df['marketing_subchannel'])

    # Cache for multiple operations
    user_journey_data_filtered_result.cache()

    if user_journey_data_filtered_result.isEmpty():
        error_msg = validate_joins(map_df,
                                   user_journey_data_filtered,
                                   DiagnosticQuery.USER_JOURNEY_DATA_FILTERED_QUERY.value,
                                   heading="Reach Engagement Pollen Citrus user_journey_data filtered FAILED - No rows found for this join",
                                   left_df_name='map_df',
                                   right_df_name='user_journey_data_filtered'
                                   )

        error_msg += DiagnosticMessage.USER_JOURNEY_DATA_FILTERED_SUGGESTION.value

        raise JoinValidationError(error_msg)

    # Step 8: Calculate reach from user journey data
    reach_df = (
        user_journey_data_filtered_result
        .groupBy("campaign_id", "booking_id", "channel_name", "subchannel_name", "media_placement")
        .agg(
            F.countDistinct("loyalty_id").alias("reach")
        )
    )

    reach_df = reach_df.withColumnRenamed("campaign_id", "campaign_id_new").withColumnRenamed("channel_name",
                                                                                              "channel_name_new")
    aggregated_metrics_df = aggregated_metrics_df.withColumnRenamed("subchannel_name", "subchannel_name_new")

    # Step 9: Join reach with campaign metrics
    citrus_insights_df = (
        aggregated_metrics_df
        .join(
            reach_df.drop("booking_id"),
            (aggregated_metrics_df.campaign_id == reach_df.campaign_id_new) &
            (aggregated_metrics_df.channel_name == reach_df.channel_name_new) &
            (aggregated_metrics_df.subchannel_name_new == reach_df.media_placement),  # prevent duplicate columns
            how="inner"
        )
    )

    # Cache for multiple operations
    citrus_insights_df.cache()

    # Validate with diagnostics
    if citrus_insights_df.isEmpty():
        error_msg = validate_joins(aggregated_metrics_df,
                                   reach_df,
                                   DiagnosticQuery.POLLEN_CITRUS_INSIGHT_QUERY.value,
                                   heading="Reach Engagement Pollen Citrus Insights FAILED - No rows found for this join",
                                   left_df_name='aggregated_metrics_df',
                                   right_df_name='reach_df'
                                   )

        error_msg += DiagnosticMessage.POLLEN_CITRUS_INSIGHT_SUGGESTION.value

        raise JoinValidationError(error_msg)

    # Step 10: Final column selection
    final_output = citrus_insights_df.select(
        "campaign_id",
        "channel_name",
        "subchannel_name",
        "reach",
        "clicks",
        "impressions",
        "sales",
        "conversions",
        "booking_id",
        "marketing_type"
    )

    return final_output


def process_all_campaigns(measurement_campaign_execution_df: DataFrame,
                          user_journey_offer_df: DataFrame,
                          digital_trading_campaign_link_df: DataFrame,
                          digital_trading_campaign_facebook_insight_df: DataFrame,
                          dv360_media_report_df: DataFrame,
                          dv360_order_report_df: DataFrame,
                          dv360_floodlight_report_df: DataFrame,
                          camp_request_link_df: DataFrame,
                          campaign_citcam_sat_df: DataFrame,
                          meta_campaigns_df: DataFrame,
                          unified_campaign_df: DataFrame,
                          correlation_id: str,
                          map_df: DataFrame,
                          channel_hierarchy_code_df: DataFrame,
                          campaign_complete: str,
                          subchannel_hierarchy_codes: dict
                          ) -> DataFrame:
    """
    Processes all active marketing campaigns across multiple channels,
    aggregating reach, engagement, and conversion metrics into a single
    consolidated DataFrame.

    This function:
        1. Identifies all campaigns from
           `measurement_campaign_execution_df`.
        2. Filters campaigns by duration ("During").
        3. Processes channel-specific data for:
           - Facebook/Meta (via `digital_trading_*` datasets)
           - YouTube (via DV360 media, order, and floodlight reports)
           - Citrus retail media campaigns (via `camp_request_link_df`
             and `campaign_citcam_sat_df`)
           - Offer-based campaigns (via `user_journey_offer_df`)
        4. Joins channel metrics with `unified_campaign_df` to align with
           master campaign metadata.
        5. Returns a DataFrame containing combined performance results
           for all active campaigns.

    Args:
        measurement_campaign_execution_df (DataFrame):
            Source of campaign execution details, including BOOKING_ID,
            CAMPAIGN_ID, channel, and job status.

        user_journey_offer_df (DataFrame):
            Offer campaign user journey dataset containing touchpoints
            and conversion events.

        digital_trading_campaign_sat_df (DataFrame):
            Digital trading campaign details table (Meta/Facebook).

        digital_trading_campaign_link_df (DataFrame):
            Links digital trading campaigns to execution metadata.

        digital_trading_campaign_facebook_insight_df (DataFrame):
            Facebook/Meta insights dataset containing delivery and
            engagement metrics.

        dv360_media_report_df (DataFrame):
            DV360 media performance metrics for YouTube campaigns.

        dv360_order_report_df (DataFrame):
            DV360 order-level campaign mapping for YouTube.

        dv360_floodlight_report_df (DataFrame):
            DV360 floodlight conversions for YouTube campaigns.

        camp_request_link_df (DataFrame):
            Citrus campaign request-to-realisation mapping.

        campaign_citcam_sat_df (DataFrame):
            Citrus-specific campaign metadata and performance metrics.

        meta_campaigns_df (DataFrame):
            DataFrame containing user journey records for Meta (Facebook) campaigns,
            including all touchpoints and conversion events. This dataset is used
            to identify the distinct loyalty IDs that were targeted and sent to Meta.

        unified_campaign_df (DataFrame):
            Master list of campaigns, with identifiers and metadata such
            as CAMPAIGN_ID, BOOKING_ID, date ranges, and channel.

        correlation_id (str):
            Unique ID for correlating logs, events, and downstream
            notifications for this execution.

    Returns:
        DataFrame:
            Consolidated campaign performance dataset containing:
            - Campaign identifiers (BOOKING_ID, CAMPAIGN_ID)
            - Channel-specific metrics (reach, impressions, spend,
              conversions, engagement KPIs)
            - Metadata from `unified_campaign_df`

    Notes:
        - Only campaigns with CAMPAIGN_DURATION == "During" are processed.
        - Each channel's processing is handled by its respective
          processor (Meta, YouTube, Citrus, Offer).
        - The function assumes column naming conventions from source
          tables remain consistent.
    """

    # Fetch current in-progress campaign booking_id and duration
    in_progress_df_result = fetch_in_progress_campaigns(measurement_campaign_execution_df)

    in_progress_df_result = in_progress_df_result.filter(F.col("campaign_duration") == "During")

    unified_campaign_df = (unified_campaign_df.join(
        F.broadcast(measurement_campaign_execution_df),
        (unified_campaign_df["booking_id"] == measurement_campaign_execution_df["booking_id"]) &
        (unified_campaign_df["campaign_id"] == measurement_campaign_execution_df["campaign_id"]),
        "inner").select(unified_campaign_df["*"]).cache())

    # Get latest load_ts per campaign to get only latest records
    unified_campaign_max_load_ts = unified_campaign_df.groupBy(
        "campaign_id",
        "channel_name",
        "subchannel_name",
        "marketing_type",
        "media_spend_amt",
        "campaign_start_dt",
        "campaign_end_dt",
        "booking_id",
        "marketing_hierarchy_cd"
    ).agg(F.max("load_ts").alias("load_ts"))

    unified_campaign_df = unified_campaign_max_load_ts

    # Add salt to the skewed key
    user_journey_salted = user_journey_offer_df.withColumn(
        "salt", (F.rand() * 100).cast("int")
    )

    in_progress_salted = in_progress_df_result.withColumn(
        "salt", F.explode(F.array([F.lit(i) for i in range(100)]))
    )

    # Join with salted keys
    user_journey_filtered = user_journey_salted.join(
        F.broadcast(in_progress_salted),
        ["booking_id", "campaign_duration", "salt"],
        "inner"
    ).drop("salt")

    # Get latest user journey data (assuming this filters for latest load_ts)
    user_journey_latest = get_latest_data_for_campaigns(user_journey_filtered,
                                                        in_progress_df_result)

    dfs_to_union = []
    # -- ADD: Compute dedup_campaign_reach_df KPI here
    dedup_campaign_reach_df = (
        user_journey_latest
        .groupBy("booking_id")
        .agg(F.countDistinct("loyalty_id").alias("dedup_campaign_reach"))
    )

    # ----------------------------------------------------------------------------
    # Process all channel campaigns in bulk, no explicit Python loops over campaign_rows
    # ----------------------------------------------------------------------------

    # --- Meta Channel Processing ---
    meta_hierarchy_codes = subchannel_hierarchy_codes.get('meta', [])
    if meta_hierarchy_codes:
        meta_unified_campaigns_df = (
            unified_campaign_df
            .filter(F.col("marketing_hierarchy_cd").isin(meta_hierarchy_codes))
        )
        if not meta_unified_campaigns_df.isEmpty():
            meta_final = (meta_processor(
                digital_trading_campaign_link_df,
                digital_trading_campaign_facebook_insight_df,
                meta_unified_campaigns_df,
                campaign_complete
            ))
            meta_final = meta_final.withColumn(
                "engagement_ctr_pct",
                F.when(F.col("impressions") > 0, (F.col("clicks") / F.col("impressions")) * 100).otherwise(0.0)
            )
            dfs_to_union.append(meta_final)
    # --- DV360 Channel Processing ---

    dv360_hierarchy_codes = subchannel_hierarchy_codes.get('dv360', [])
    if dv360_hierarchy_codes:
        dv360_unified_campaigns_df = (
            unified_campaign_df
            .filter(F.col("marketing_hierarchy_cd").isin(dv360_hierarchy_codes))
        )
        if not dv360_unified_campaigns_df.isEmpty():
            dv360_final = (youtube_and_dv360_processor(
                dv360_media_report_df,
                dv360_order_report_df,
                dv360_floodlight_report_df,
                dv360_unified_campaigns_df,
                'dv360'
            ))
            dv360_final = (
                dv360_final
                .withColumn(
                    "engagement_ctr_pct",
                    F.when(F.col("impressions") > 0, (F.col("clicks") / F.col("impressions")) * 100).otherwise(0.0)
                )
            )
            dfs_to_union.append(dv360_final)
    # --- Youtube Channel Processing ---

    youtube_hierarchy_codes = subchannel_hierarchy_codes.get('youtube', [])
    if youtube_hierarchy_codes:
        youtube_unified_campaigns_df = (
            unified_campaign_df
            .filter(F.col("marketing_hierarchy_cd").isin(youtube_hierarchy_codes))
        )
        if not youtube_unified_campaigns_df.isEmpty():
            youtube_final = (youtube_and_dv360_processor(
                dv360_media_report_df,
                dv360_order_report_df,
                dv360_floodlight_report_df,
                youtube_unified_campaigns_df,
                'youtube'
            ))
            youtube_final = (
                youtube_final
                .withColumn(
                    "engagement_ctr_pct",
                    F.when(F.col("impressions") > 0, (F.col("clicks") / F.col("impressions")) * 100).otherwise(0.0)
                )
            )
            dfs_to_union.append(youtube_final)

    instore_unified_campaigns_df = unified_campaign_df.filter(F.col("marketing_type").isin("INSTORE", "ATHOME"))
    if not instore_unified_campaigns_df.isEmpty():
        instore_final = (calculate_reach(user_journey_latest,
                                         instore_unified_campaigns_df,
                                         group_by_column="marketing_type",
                                         subchannel_hierarchy_codes=subchannel_hierarchy_codes))
        instore_final = instore_final.withColumn("media_spend_amt", F.lit(0.0)).withColumn("engagement_ctr_pct", F.lit(0.0))
        dfs_to_union.append(instore_final)

    gol_unified_campaigns_df = (unified_campaign_df.filter(
        (F.col("marketing_type") == F.lit("ONSITE")) &
        (F.col("channel_name") != F.lit("ecoupon"))
    )
    )
    if not gol_unified_campaigns_df.isEmpty():
        citrus_final = (citrus_processor(camp_request_link_df,
                                         gol_unified_campaigns_df,
                                         campaign_citcam_sat_df,
                                         user_journey_filtered,
                                         map_df,
                                         channel_hierarchy_code_df))
        citrus_final = citrus_final.withColumn(
            "media_spend_amt", F.lit(0.0)
        ).withColumn(
            "engagement_ctr_pct",
            F.when(F.col("impressions") > 0, (F.col("clicks") / F.col("impressions")) * 100).otherwise(0.0)
        )
        dfs_to_union.append(citrus_final)

    # --- Coupon Channel Processing (Ecoupons + Coupon at Till) ---
    coupon_hierarchy_codes = (
        extract_hierarchy_codes(subchannel_hierarchy_codes, 'ecoupons') +
        extract_hierarchy_codes(subchannel_hierarchy_codes, 'coupon_at_till')
    )

    if coupon_hierarchy_codes:
        coupon_unified_campaigns_df = (
            unified_campaign_df
            .filter(F.col("marketing_hierarchy_cd").isin(coupon_hierarchy_codes))
        )
        if not coupon_unified_campaigns_df.isEmpty():
            coupon_final = (calculate_reach(user_journey_latest,
                                            coupon_unified_campaigns_df,
                                            "subchannel_name",
                                            subchannel_hierarchy_codes))
            coupon_final = coupon_final.withColumn("media_spend_amt", F.lit(0.0)).withColumn("engagement_ctr_pct", F.lit(0.0))
            dfs_to_union.append(coupon_final)

    # --- Combine all channel insights ---
    if len(dfs_to_union) == 1:
        reach_engagement = dfs_to_union[0]
    else:
        reach_engagement = reduce(lambda df1, df2: df1.unionByName(df2), dfs_to_union)

    reach_engagement = reach_engagement.withColumn("load_ts", F.current_timestamp())
    reach_engagement = reach_engagement.dropDuplicates()

    hierarchy_lookup = unified_campaign_df.select(
        "campaign_id",
        "channel_name",
        "subchannel_name",
        "marketing_hierarchy_cd"
    ).distinct()

    reach_engagement = reach_engagement.join(
        F.broadcast(hierarchy_lookup),
        on=["campaign_id", "channel_name", "subchannel_name"],
        how="left"
    )

    # Rename columns to naming standard
    reach_engagement = (reach_engagement.withColumnRenamed("reach", "reach_cnt")
                        .withColumnRenamed("impressions", "impressions_cnt")
                        .withColumnRenamed("conversions", "conversions_cnt")
                        .withColumnRenamed("clicks", "clicks_cnt")
                        .withColumnRenamed("sales", "sales_amt"))

    unified_campaign_df = (
        unified_campaign_df.withColumnRenamed("campaign_id", "campaign_id_uni")
        .withColumnRenamed("subchannel_name", "subchannel_name_uni")
        .withColumnRenamed("channel_name", "channel_name_uni")
        .withColumnRenamed("marketing_type", "marketing_type_uni")
        .withColumnRenamed("media_spend_amt", "media_spend_amt_uni")
        .withColumnRenamed("marketing_hierarchy_cd", "marketing_hierarchy_cd_uni")
    )

    unified_campaign_df = unified_campaign_df.groupBy(
        "channel_name_uni",
        "subchannel_name_uni",
        "campaign_id_uni",
        "marketing_type_uni",
        "marketing_hierarchy_cd_uni"
    ).agg(F.sum("media_spend_amt_uni").alias("media_spend_amt_uni"))

    # 2. Define join condition
    join_condition = (
        (F.lower(reach_engagement["campaign_id"]) == F.lower(unified_campaign_df["campaign_id_uni"])) &
        (F.lower(reach_engagement["subchannel_name"]) == F.lower(unified_campaign_df["subchannel_name_uni"])) &
        (F.lower(reach_engagement["channel_name"]) == F.lower(unified_campaign_df["channel_name_uni"])) &
        (F.lower(reach_engagement["marketing_type"]) == F.lower(unified_campaign_df["marketing_type_uni"])) &
        (F.lower(reach_engagement["marketing_hierarchy_cd"]) == F.lower(unified_campaign_df["marketing_hierarchy_cd_uni"]))
    )

    # 3. Perform join (exclude meta/youtube/dv360 later)
    reach_engagement = (
        reach_engagement
        .join(unified_campaign_df, join_condition, "left")
    )

    # 4. Select media spend based on channel
    digital_hierarchy_codes = (
        subchannel_hierarchy_codes["meta"] +
        subchannel_hierarchy_codes["dv360"] +
        subchannel_hierarchy_codes["youtube"]
    )
    print(f"\n1. Digital hierarchy codes: {digital_hierarchy_codes}")
    final_reach_engagement_df = reach_engagement.withColumn(
        "media_spend_amt",
        F.when(
            F.col("marketing_hierarchy_cd_uni").isNull(),
            F.coalesce(F.col("media_spend_amt"), F.lit(0.0))
        ).when(
            ~F.col("marketing_hierarchy_cd_uni").isin(digital_hierarchy_codes),
            F.col("media_spend_amt_uni")
        ).otherwise(F.col("media_spend_amt_uni"))
    ).withColumn(
        "marketing_hierarchy_cd",
        F.coalesce(F.col("marketing_hierarchy_cd"), F.col("marketing_hierarchy_cd_uni"))
    ).drop("media_spend_amt_uni", "campaign_id_uni", "subchannel_name_uni", "channel_name_uni", "marketing_type_uni", "marketing_hierarchy_cd_uni")
    final_reach_engagement_df = (final_reach_engagement_df.withColumn("media_spend_amt",
                                                                      F.coalesce(F.col("media_spend_amt"), F.lit(0))))
    # -- instore_onsite_loyalty_ids_df: Actual loyalty IDs exposed in in-store/onsite campaigns
    instore_onsite_loyalty_ids_df = (
        user_journey_latest
        .filter(F.lower(F.col("marketing_type")).isin(["instore", "in-store", "onsite", "targeted media"]))
        .select("loyalty_id")
        .distinct()
    )

    offsite_reported_reach = dict(
        final_reach_engagement_df
        .filter(F.lower(F.col("marketing_type")) == "offsite")
        .groupBy("channel_name")
        .agg(F.sum("reach_cnt").alias("reported_reach"))
        .select("channel_name", "reported_reach")
        .collect()
    )

    # Check if only 'offsite' marketing_type exists in the reach engagement
    distinct_marketing_types = (
        final_reach_engagement_df
        .select(F.lower(F.col("marketing_type")).alias("marketing_type"))
        .distinct()
    )

    # Get Meta hierarchy codes for matching
    meta_hierarchy_codes = subchannel_hierarchy_codes.get("meta", [])
    print("Meta hierarchy codes:", meta_hierarchy_codes)

    # Get channel names that match Meta hierarchy codes
    meta_channel_names = [
        row.channel_name for row in
        final_reach_engagement_df
        .filter(F.col("marketing_hierarchy_cd").isin(meta_hierarchy_codes))
        .select("channel_name")
        .distinct()
        .collect()
    ]
    types_list = [row["marketing_type"] for row in distinct_marketing_types.collect()]
    offsite_only = len(types_list) == 1 and types_list[0] == "offsite"

    print("Meta hierarchy codes:", meta_hierarchy_codes)
    print("Meta channel names:", meta_channel_names)
    print("Offsite Reported Reach:", offsite_reported_reach)
    print("meta_campaigns_df is None:", meta_campaigns_df is None)
    print("offsite_only:", offsite_only)
    print(distinct_marketing_types.show(truncate=False))
    if (
        any(offsite_reported_reach.get(channel, 0) > 0 for channel in meta_channel_names) and
        meta_campaigns_df is not None and
        not offsite_only
    ):
        final_reach_metrics = calculate_combined_reach(
            meta_campaigns_df,
            instore_onsite_loyalty_ids_df,
            offsite_reported_reach,
            meta_channel_names[0]
        )

        reach_estimate_rounded = final_reach_metrics.get("reach_estimate_rounded", 0)
        print("Final Reach Estimate:", final_reach_metrics)
        print("Final Reach Estimate Rounded:", reach_estimate_rounded)

        # Add dedup_campaign_reach estimate to final DataFrame as the estimated reach
        final_reach_engagement_df = (
            final_reach_engagement_df
            .withColumn("dedup_campaign_reach", F.lit(reach_estimate_rounded))
        )
    else:
        # set the deduped campaign reach to the same as the sum of the reach_cnt offsite only campaigns
        if offsite_only:
            print("offsite_only is True: Setting dedup_campaign_reach as sum of reach_cnt")
            window_spec = Window.partitionBy("booking_id")
            dedup_col = F.sum("reach_cnt").over(window_spec)
        else:
            # Add dedup_campaign_reach estimate based on the booking id level de-duped Loyalty IDs
            dedup_col = F.col("dedup_campaign_reach")
            final_reach_engagement_df = final_reach_engagement_df.join(
                dedup_campaign_reach_df, on="booking_id", how="left"
            )
        final_reach_engagement_df = final_reach_engagement_df.withColumn(
            "dedup_campaign_reach", dedup_col
        )

    # Add invocation id as job_run_id metadata column
    final_reach_engagement_df = final_reach_engagement_df.withColumn("job_run_id", F.lit(correlation_id))

    final_reach_engagement_df = (
        final_reach_engagement_df.filter(
            F.col("subchannel_name").isNotNull() &
            (F.col("subchannel_name") != '')))
    final_reach_engagement_df.cache()

    print(f'\n\nReach Engagement Count: {final_reach_engagement_df.count()}')

    # Take one final look to ensure that we are not returning an empty dataframe.
    if final_reach_engagement_df.isEmpty():
        error_msg = DiagnosticMessage.REACH_ENGAGEMENT_EMPTY_DATASET.value
        raise ValueError(error_msg)

    # Return final DataFrame
    return final_reach_engagement_df


def prepare_reach_engagement(
    spark: SparkSession,
    measurement_campaign_execution_path: str,
    user_journey_offer_path: str,
    unified_campaigns_path: str,
    digital_trading_campaign_channel_dmfbca_link_path: str,
    digital_trading_campaign_insight_dmfbin_link_path: str,
    media_report_path: str,
    unique_reach_lineitem_report_path: str,
    floodlight_report_path: str,
    advertising_campaign_request_realised_link_path: str,
    advertising_campaign_citcam_sat_path: str,
    meta_data_path: str,
    output_reporting_path: str,
    correlation_id: str,
    run_date: str,
    marketing_media_hierarchy_mkthrc_ref_path: str,
    measurement_marketing_channel_hierarchy_path: str,
    slack_topic_arn: str,
    campaign_complete: str,
    subchannel_hierarchy_codes: dict
) -> DataFrame:
    """
    Orchestrates the end-to-end preparation of reach and engagement metrics
    for marketing campaigns by loading input datasets from given S3 paths,
    processing campaign data from multiple channels, and saving the final
    consolidated output back to S3.

    This function serves as a high-level pipeline coordinator that:
      - Reads various campaign, media, and user journey datasets from S3 in Parquet format.
      - Selects and projects relevant columns for downstream processing.
      - Invokes the core campaign processing logic to aggregate reach, engagement,
        conversions, and media spend metrics across channels including Meta, YouTube, Citrus, and offer campaigns.
      - Persists the processed output DataFrame to the specified output path in S3.

    Args:
        spark (SparkSession): SparkSession object for Spark operations.
        measurement_campaign_execution_path (str): S3 path to measurement campaign execution data.
        user_journey_offer_path (str): S3 path to user journey offer campaign data.
        digital_trading_campaign_channel_dmfbca_link_path (str): S3 path to digital trading campaign channel linkage data.
        digital_trading_campaign_insight_dmfbin_link_path (str): S3 path to digital trading Facebook line item insights.
        media_report_path (str): S3 path to YouTube media report data.
        unique_reach_lineitem_report_path (str): S3 path to unique reach line item report.
        floodlight_report_path (str): S3 path to DV360 floodlight conversion report.
        advertising_campaign_request_realised_link_path (str): S3 path to Citrus advertising campaign request-realised linkage.
        advertising_campaign_citcam_sat_path (str): S3 path to Citrus campaign satellite metadata.
        meta_data_path (str): S3 path to Meta campaign user journey data.
        correlation_id (str): Unique identifier for tracking this pipeline execution.
        run_date (str): Execution date for the pipeline run, used for logging and auditing.

    Returns:
        DataFrame: A Spark DataFrame containing the consolidated reach and engagement metrics
        for all processed campaigns, ready for downstream analytics or reporting.

    Side Effects:
        - Reads multiple input datasets from S3 in Parquet format.
        - Writes the final aggregated DataFrame to the specified output_path in Parquet format.
        - Prints the count of records in the final DataFrame to the console/logs.

    Notes:
        - Assumes the input Parquet files have consistent schema and column naming conventions.
        - The function filters campaigns based on in-progress status and campaign duration internally.
        - This function is designed to replace legacy DBT SQL logic with PySpark processing for improved scalability and maintainability.
    """
    slack_messenger = SlackMessenger(
        topic_arn=slack_topic_arn,
        correlation_id=correlation_id
    )

    measurement_campaign_execution_df = (
        spark.read.parquet(measurement_campaign_execution_path).select(
            "campaign_id",
            "booking_id",
            "marketing_type",
            "campaign_duration",
            "job_status"
        )
    )

    digital_trading_campaign_channel_dmfbca_link_df = (
        spark.read.parquet(digital_trading_campaign_channel_dmfbca_link_path).select(
            "digital_trading_campaign_nk1",
            "digital_trading_campaign_nk3",
            "digital_trading_campaign_channel_nk1",
            "digital_trading_campaign_channel_nk3",
            "digital_trading_advertiser_nk1",
            "digital_trading_advertiser_nk3",
            "digital_trading_brand_nk1",
            "digital_trading_brand_nk3"
        )
    )

    digital_trading_campaign_facebook_insight_df = (
        spark.read.parquet(digital_trading_campaign_insight_dmfbin_link_path).select(
            "digital_trading_campaign_nk1",
            "digital_trading_campaign_nk3",
            "digital_trading_brand_nk1",
            "digital_trading_brand_nk3",
            "digital_trading_insight_id",
            "record_arrival_ts",
            "reporting_start_dt",
            "reporting_end_dt",
            "measures"
        )
    )

    media_report_df = (
        spark.read.parquet(media_report_path).select(
            "campaign_id",
            "insertion_order_id",
            "line_item_id",
            "clicks",
            "impressions",
            "total_conversions",
            "time_of_day",
            "device_type",
            "campaign_date",
            "run_at",
            "revenue"
        )
    )

    unique_reach_lineitem_report_df = (
        spark.read.parquet(unique_reach_lineitem_report_path).select(
            "date_from",
            "date_until",
            "line_item_id",
            "total_reach",
            "country"
        )
    )

    floodlight_report_df = (
        spark.read.parquet(floodlight_report_path).select(
            "run_at",
            "campaign_date",
            "floodlight_id",
            "insertion_order_id",
            "insertion_order_name",
            "line_item_id",
            "total_conversions",
            "spend"
        )
    )

    user_journey_offer_df = (
        spark.read.parquet(user_journey_offer_path).select(
            "campaign_id",
            "isconversion",
            "net_sales_amt",
            "subchannel_name",
            "channel_name",
            "booking_id",
            "load_ts",
            "loyalty_id",
            "marketing_type",
            "userjourney_id",
            "campaign_duration"
        )
    )

    advertising_campaign_request_realised_link_df = (
        spark.read.parquet(advertising_campaign_request_realised_link_path).select(
            "advertising_campaign_nk1",
            "ingressed_at_dt",
            "sales_revenue_amt",
            "conversions_cnt",
            "impressions_cnt",
            "clicks_cnt",
        )
    )

    advertising_campaign_citcam_sat_df = (
        spark.read.parquet(advertising_campaign_citcam_sat_path).select(
            "advertising_campaign_nk1",
            "advertising_campaign_nk3",
            "campaign_name",
            "campaign_type",
            "campaign_subtype",
            "campaign_valid_state",
            "campaign_placements"
        )
    )

    unified_campaign_df = (
        spark.read.parquet(unified_campaigns_path).select(
            "campaign_id",
            "media_spend_amt",
            "campaign_start_dt",
            "campaign_end_dt",
            "subchannel_name",
            "channel_name",
            "campaign_name",
            "booking_id",
            "load_ts",
            "marketing_type",
            "unique_brand_name",
            "marketing_hierarchy_cd",
        )
    )

    map_df = spark.read.parquet(marketing_media_hierarchy_mkthrc_ref_path).select(
        "media_placement",
        "marketing_channel",
        "marketing_subchannel",
        "mapping_type",
        "channel_type",
        "media_provider",
        "media_type",
        "media_subtype",
        "store_type",
        "store_location",
        "template_type",
        "technical_metadata",
        "load_ts"
    )

    channel_hierarchy_code_df = (
        spark
        .read
        .parquet(measurement_marketing_channel_hierarchy_path)
        .select(
            'marketing_hierarchy_cd',
            'marketing_subchannel'
        )
    )

    try:
        # --- Load Meta campaign user journeys to find the loyalty ids sent to meta ---
        meta_campaigns_df = spark.read.parquet(meta_data_path).select("LOYALTY_ID")
    except FileNotFoundError as e:
        print(f"Error: File not found at path '{meta_data_path}': {e}")
        meta_campaigns_df = None
    except Exception as e:
        print(f"Unexpected error reading parquet file at '{meta_data_path}': {e}")
        meta_campaigns_df = None
    finally:
        print(f"Completed parquet read attempt for path: '{meta_data_path}'")

    try:
        distinct_booking_ids = (
            measurement_campaign_execution_df
            .select(F.collect_set("booking_id").alias("booking_ids"))
            .first()["booking_ids"]
        ) or []
        # Convert to comma-separated string
        booking_ids_string = ", ".join(distinct_booking_ids) if distinct_booking_ids else ""

        reach_engagement_df = process_all_campaigns(
            measurement_campaign_execution_df,
            user_journey_offer_df,
            digital_trading_campaign_channel_dmfbca_link_df,
            digital_trading_campaign_facebook_insight_df,
            media_report_df,
            unique_reach_lineitem_report_df,
            floodlight_report_df,
            advertising_campaign_request_realised_link_df,
            advertising_campaign_citcam_sat_df,
            meta_campaigns_df,
            unified_campaign_df,
            correlation_id,
            map_df,
            channel_hierarchy_code_df,
            campaign_complete,
            subchannel_hierarchy_codes
        )

    except ValueError as ve:
        slack_text = f"""❌ Reach Engagement failure:\n
                                    Correlation_id: {correlation_id}\n
                                        Booking_ids: {booking_ids_string}\n
                    """
        # Send the formatted message to Slack
        slack_messenger.send_message(
            event_type="Reach Engagemen Notification",
            text=slack_text,
            data={"Reach Engagement Failure Diagnosis": f"```\n{ve}\n```"},
        )
        raise

    # Output reporting output
    df2 = reach_engagement_df.select(
        "campaign_id",
        "channel_name",
        "subchannel_name",
        "marketing_type",
        "booking_id",
        "reach_cnt",
        "dedup_campaign_reach",
        "clicks_cnt",
        "impressions_cnt",
        "sales_amt",
        "conversions_cnt",
        "media_spend_amt",
        "engagement_ctr_pct",
        "load_ts",
        "job_run_id",
        "marketing_hierarchy_cd"
    )

    spark_s3_overwrite(output_reporting_path, df2)

    return reach_engagement_df


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    """
    Entry point for the New Launch Estimation baseline pipeline.

    Parses required command-line arguments for input and output S3 paths, along with
    metadata parameters, then invokes the main processing function to run the pipeline.

    Args:
        spark (SparkSession): Active SparkSession for Spark operations.
        command_line_args (Optional[List[str]]): List of command-line arguments to parse.
            If None, uses sys.argv by default.

    Command-line Arguments:
        --measurement-campaign-execution-path (str): S3 path for measurement campaign execution data.
        --digital-trading-campaign-dmfbca-sat-path (str): S3 path for campaign selection data.
        --digital-trading-campaign-channel-dmfbca-link-path (str): S3 path for campaign channel linkage data.
        --digital-trading-lineitem-insight-dmfbin-link-path (str): S3 path for DV360 processed line item insights.
        --media-report-path (str): S3 path for SKU cluster mapping report.
        --unique-reach-lineitem-report-path (str): S3 path for unique reach line item report.
        --floodlight-report-path (str): S3 path for floodlight baseline modelling output.
        --user-journey-offer-path (str): S3 path for user journey offer data.
        --advertising-campaign-request-realised-link-path (str): S3 path for advertising campaign request data.
        --advertising-campaign-citcam-sat-path (str): S3 path for advertising campaign satellite data.
        --unified-campaigns-path (str): S3 path for unified campaign data.
        --output-path (str): S3 path where the pipeline output will be saved.
        --correlation-id (str): Unique identifier for the pipeline run for traceability.
        --run-date (str): Date of pipeline execution in YYYY-MM-DD format.
        -- mapping-path(str): S3 path for mapping table
        --slack-topic-arn(str): For slack notification

    Raises:
        ArgumentError: If required command-line arguments are missing or invalid.

    Side Effects:
        Reads input datasets from specified S3 paths, executes the data processing workflow,
        writes output back to S3, and logs relevant progress information.
    """
    parser = ThrowingArgumentParser(description="New Launch Estimation for baseline pipeline.")
    parser.add_argument(
        "--measurement-campaign-execution-path",
        type=str,
        required=True,
        help="S3 path for measurement campaign execution."
    )
    parser.add_argument(
        "--digital-trading-campaign-channel-dmfbca-link-path",
        type=str,
        required=True,
        help="The output S3 path for the new launch proxy mapping."
    )
    parser.add_argument(
        "--digital-trading-campaign-insight-dmfbin-link-path",
        type=str,
        required=True,
        help="The output S3 path for the dv360 processed data."
    )
    parser.add_argument(
        "--media-report-path",
        type=str,
        required=True,
        help="S3 path for sku cluster mapping."
    )
    parser.add_argument(
        "--unique-reach-lineitem-report-path",
        type=str,
        required=True,
        help="S3 path for fact sale transaction item path."
    )
    parser.add_argument(
        "--floodlight-report-path",
        type=str,
        required=True,
        help="S3 path for baseline modelling output."
    )
    parser.add_argument(
        "--user-journey-offer-path",
        type=str,
        required=True,
        help="S3 path for user journey data."
    )

    parser.add_argument(
        "--advertising-campaign-request-realised-link-path",
        type=str,
        required=True,
        help="S3 path for sku cluster mapping."
    )
    parser.add_argument(
        "--advertising-campaign-citcam-sat-path",
        type=str,
        required=True,
        help="S3 path for fact sale transaction item path."
    )
    parser.add_argument(
        "--meta-data-path",
        type=str,
        required=True,
        help="S3 path for Meta user journey data."
    )
    parser.add_argument(
        "--unified-campaigns-path",
        type=str,
        required=True,
        help="S3 path for unified campaign path."
    )

    parser.add_argument(
        "--output-reporting-path",
        type=str,
        required=True,
        help="The path in S3 to output the reporting data."
    )

    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="unique correlation id."
    )

    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--marketing-media-hierarchy-mkthrc-ref-path",
        type=str,
        required=True,
        help="S3 path for marketing_media_hierarchy_mkthrc_ref path."
    )
    parser.add_argument(
        "--measurement-marketing-channel-hierarchy-path",
        type=str,
        required=True,
        help="S3 path for measurement marketing channel hierarchy data."
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN of the Slack topic for notifications."
    )
    parser.add_argument(
        "--campaign-complete",
        type=str,
        required=True,
        help="Boolean flag indicating whether the campaign is complete (True) or ongoing (False)."
    )
    parser.add_argument(
        "--subchannel-hierarchy-codes",
        type=str,
        required=True,
        help='JSON string of subchannel hierarchy codes (e.g., \'{"citrus": [4013], "dv360": [3001], "meta": [3009], "youtube": [3014]}\')'
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    # Convert campaign_complete to boolean
    campaign_complete = str_to_bool(known_args.campaign_complete)

    try:
        subchannel_hierarchy_codes = json.loads(known_args.subchannel_hierarchy_codes)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON format for subchannel-hierarchy-codes: {e}")

    _ = (prepare_reach_engagement(
        spark=spark,
        measurement_campaign_execution_path=known_args.measurement_campaign_execution_path,
        user_journey_offer_path=known_args.user_journey_offer_path,
        unified_campaigns_path=known_args.unified_campaigns_path,
        digital_trading_campaign_channel_dmfbca_link_path=known_args.digital_trading_campaign_channel_dmfbca_link_path,
        digital_trading_campaign_insight_dmfbin_link_path=known_args.digital_trading_campaign_insight_dmfbin_link_path,
        media_report_path=known_args.media_report_path,
        unique_reach_lineitem_report_path=known_args.unique_reach_lineitem_report_path,
        floodlight_report_path=known_args.floodlight_report_path,
        advertising_campaign_request_realised_link_path=known_args.advertising_campaign_request_realised_link_path,
        advertising_campaign_citcam_sat_path=known_args.advertising_campaign_citcam_sat_path,
        meta_data_path=known_args.meta_data_path,
        output_reporting_path=known_args.output_reporting_path,
        correlation_id=known_args.correlation_id,
        run_date=known_args.run_date,
        marketing_media_hierarchy_mkthrc_ref_path=known_args.marketing_media_hierarchy_mkthrc_ref_path,
        measurement_marketing_channel_hierarchy_path=known_args.measurement_marketing_channel_hierarchy_path,
        slack_topic_arn=known_args.slack_topic_arn,
        campaign_complete=campaign_complete,
        subchannel_hierarchy_codes=subchannel_hierarchy_codes
    )
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("ReachEngagementPollen").getOrCreate())
