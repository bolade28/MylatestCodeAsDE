from functools import reduce
from pyspark.sql import functions as F
from pyspark.sql import DataFrame, SparkSession
from typing import List, Optional
from pyspark.sql import types as T
from spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics import (
    check_feature_sense_checks,
    check_no_nulls_after_imputation,
    check_pre_imputation_nulls_in_non_marketing_features,
)

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite

# --- Helper Functions ---


def load_and_union_processed_data(
    spark: SparkSession,
    s3_paths: List[str],
) -> DataFrame:
    """
    Reads all necessary input DataFrames from S3 paths.

    :param spark: The SparkSession object.
    :param s3_paths: List containing S3 path.
    :return: A DataFrame containing all loaded DataFrames.
    """

    dfs = []
    for s3_path in s3_paths:
        if s3_path is not None:
            df_computed = spark.read.parquet(s3_path).select(
                F.col("week_start_dt"),
                F.col("metric_value"),
                F.col("super_category_name"),
                F.col("unique_brand_name"),
                F.upper(F.col("cluster_num")).alias("cluster_num"),
                F.upper(F.col("marketing_type_name")).alias("marketing_type_name"),
                F.upper(F.col("marketing_channel_name")).alias("marketing_channel_name"),
                F.upper(F.col("marketing_sub_channel_name")).alias("marketing_sub_channel_name"),
                F.upper(F.col("metric_name")).alias("metric_name"))

            dfs.append(df_computed)

    result_union_df = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), dfs)

    return result_union_df


def build_complete_date_skeleton(
        weekly_dates_df: DataFrame,
        union_df: DataFrame
) -> DataFrame:
    """
    Builds a complete weekly date skeleton for all distinct features present in the unioned channel dataset.

    We do this because in the case where we don't get any historic data we won't have the full 104 weeks
    of data, but for UCM we want to have a complete skeleton of 104 weeks for the model, so we fill in
    any missing values with 0s

    :param weekly_dates_df: A DataFrame containing the set of weekly dates to over 104 weeks
    :param union_df: Combined processed dataframes, containing the UCM features
    :return: A DataFrame containing the full 104 weeks per feature with 'metric_value' populated from 'union_df' and defaulted to 0 in the case of no match


    Notes:
        All the input column names are standardised before this function is called.

        Most of the dataset comes from external variables, so we might want to exclude them from the skeleton
        if we run into performance issues, for now on average we get about 100 features which is not too bad
        to cross join with 104 weeks (10k rows) and then left join back to the original data,
        but if we get a lot more features in the future we might want to look into optimising this by excluding some of the external features
        from the skeleton and just unioning them back in at the end, as they will have full date coverage anyway
    """

    # Select the static columns needed to get the distinct features
    dimension_columns = [
        "super_category_name",
        "unique_brand_name",
        "cluster_num",
        "marketing_type_name",
        "marketing_channel_name",
        "marketing_sub_channel_name",
        "metric_name",
    ]
    # Add week_start_dt to the join columns for the final left join to bring in the metric values
    join_columns = ["week_start_dt", *dimension_columns]

    distinct_dimensions_df = union_df.select(*dimension_columns).distinct()

    # Both sides are quite small so this won't have a big performance impact, but we can broadcast the metric values to be explicit about the join strategy
    metric_df = F.broadcast(
        union_df.select(*join_columns, "metric_value")
    )

    # Get the complete data skeleton by cross joining the distinct combinations with the weekly dates,
    # then left join the metric values back on (filling missing combinations with 0s)
    final_output = (
        weekly_dates_df
        .select("week_start_dt")
        .crossJoin(distinct_dimensions_df)
        .join(metric_df, on=join_columns, how="left")
        .withColumn("metric_value", F.coalesce(F.col("metric_value"), F.lit(0)))
    )

    return final_output


def filter_and_cast_transform(weekly_dates_df, union_df, correlation_id):
    """
    Reads all necessary input DataFrames from S3 paths.

    :param weekly_dates_path: weekly dates loaded dataframe
    :param union_df : combined all processed dataframes.
    :param correlation_id unique job run id
    :return: A tuple containing all loaded DataFrames.
    """
    weekly_dates_df = weekly_dates_df.persist()  # To prevent plan mutations.
    min_date, max_date = weekly_dates_df.agg(
        F.min("week_start_dt").alias("min_date"),
        F.max("week_start_dt").alias("max_date")
    ).first()

    # Filter by date range and apply final casting
    return union_df.filter(
        (F.col("week_start_dt") >= min_date) &
        (F.col("week_start_dt") <= max_date)
    ).select(
        F.col("week_start_dt").cast(T.DateType()).alias("week_start_dt"),
        F.col("metric_value").cast(T.DecimalType(38, 10)).alias("metric_value"),
        F.col("super_category_name").cast(T.StringType()).alias("super_category_name"),
        F.col("unique_brand_name").cast(T.StringType()).alias("unique_brand_name"),
        F.col("cluster_num").cast(T.StringType()).alias("cluster_num"),
        F.col("marketing_type_name").cast(T.StringType()).alias("marketing_type_name"),
        F.col("marketing_channel_name").cast(T.StringType()).alias("marketing_channel_name"),
        F.col("marketing_sub_channel_name").cast(T.StringType()).alias("marketing_sub_channel_name"),
        F.col("metric_name").cast(T.StringType()).alias("metric_name"),
        F.lit(correlation_id).cast(T.StringType()).alias("job_run_id"),
        F.current_timestamp().cast(T.TimestampType()).alias("load_ts")
    )


def prepare_channel_processed_data(
    spark: SparkSession,
    metrics_topic_arn: str,
    instore_processed_data_path: str,
    meta_processed_data_path: str,
    dv360_processed_data_path: str,
    citrus_processed_data_path: str,
    external_processed_data_output_path: str,
    coupon_at_till_processed_data_path: str,
    promotional_discount_processed_data_path: str,
    value_index_processed_data_path: str,
    sales_processed_data_path: str,
    youtube_processed_data_path: str,
    base_price_data_path: str,
    secondary_space_data_path: str,
    weekly_dates_path: str,
    ecoupon_processed_data_path: str,
    output_path: str,
    correlation_id: str,  # Added as per previous discussion and usage
    run_date: str
) -> DataFrame:
    """
    Orchestrates the preparation of channel processed data by calling
    smaller, manageable functions. This function effectively replaces
    the original large method, enhancing readability and maintainability.
    The overall purpose of this script is for migrating the legacy system
    originally developed in DBT SQL into PySpark.

    :param spark: The SparkSession object.
    :param instore_processed_data_path: The S3 path for the campaign selection.
    :param meta_processed_data_path: The S3 path for the dv360 normalised.
    :param dv360_processed_data_path: The S3 path for the unified product data.
    :param citrus_processed_data_path: The S3 path for the SKU cluster mapping.
    :param external_processed_data_output_path: The S3 path for the external processed data.
    :param coupon_at_till_processed_data_path: The S3 path for the dv360 media report.
    :param promotional_discount_processed_data_path: The S3 path for the dv360 normalised.
    :param value_index_processed_data_path: The S3 path for the unified product data.
    :param sales_processed_data_path: The S3 path for the SKU cluster mapping.
    :param youtube_processed_data_path: The S3 path for the youtube processed.
    :param base_price_data_path: The S3 path for the dv360 media report.
    :param weekly_dates_path: The S3 path for the weekly dates.
    :param ecoupon_processed_data_path: The S3 path for the ecoupon processed data
    :param output_path: The S3 path for the output channel processed data.
    :param metrics_topic_arn: The ARN for the SNS topic to publish validation metrics.
    :param correlation_id: A unique identifier for the current job run.
    :param run_date: The pipeline run date.
    :return: The final processed DataFrame.
    """

    other_s3_path_list = []
    other_s3_path_list = other_s3_path_list + [
        instore_processed_data_path,
        meta_processed_data_path,
        dv360_processed_data_path,
        citrus_processed_data_path,
        external_processed_data_output_path,
        coupon_at_till_processed_data_path,
        promotional_discount_processed_data_path,
        value_index_processed_data_path,
        sales_processed_data_path,
        youtube_processed_data_path,
        base_price_data_path,
        secondary_space_data_path,
        ecoupon_processed_data_path
    ]

    # Step 1: Load and union all channels of processed data
    union_df = load_and_union_processed_data(
        spark,
        other_s3_path_list)

    weekly_dates_df = (
        spark.read.parquet(weekly_dates_path).select(
            "week_start_dt"
        )
    )

    # Val1: Before imputation, verify non-marketing features have no unexpected nulls
    check_pre_imputation_nulls_in_non_marketing_features(union_df, correlation_id, metrics_topic_arn)

    # Val3: Before imputation, sense-check weather/economic week coverage and discount value ranges
    check_feature_sense_checks(union_df, correlation_id, metrics_topic_arn)

    # Step 2: Build a complete date skeleton to ensure we have a full 104 weeks of data for each feature for UCM, filling in missing metric values with 0s
    complete_skeleton = build_complete_date_skeleton(weekly_dates_df, union_df)

    # Val2: After imputation, verify there are no nulls/NAs in any feature column
    check_no_nulls_after_imputation(complete_skeleton, correlation_id, metrics_topic_arn)

    # Step 3: Apply filter and cast the columns to the appropriate data type.
    final_result_df = filter_and_cast_transform(weekly_dates_df, complete_skeleton, correlation_id)

    # Write output to S3

    final_result_df = (final_result_df
                       .select(
                           "week_start_dt",
                           "super_category_name",
                           "unique_brand_name",
                           "cluster_num",
                           "marketing_type_name",
                           "marketing_channel_name",
                           "marketing_sub_channel_name",
                           "metric_name",
                           "metric_value",
                           "job_run_id",
                           "load_ts"
                       )

                       )
    spark_s3_overwrite(output_path, final_result_df)

    return final_result_df


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Facebook Campaigns for baseline pipeline.")
    parser.add_argument(
        "--instore-processed-data-path",
        type=str,
        required=True,
        help="The output S3 path for the campaign selection python."
    )
    parser.add_argument(
        "--meta-processed-data-path",
        type=str,
        required=True,
        help="The output S3 path for the dv360 normalised."
    )
    parser.add_argument(
        "--dv360-processed-data-path",
        type=str,
        required=True,
        help="The output S3 path for the dv360 processed data."
    )
    parser.add_argument(
        "--citrus-processed-data-path",
        type=str,
        required=True,
        help="S3 path for citrus processed data."
    )
    parser.add_argument(
        "--external-processed-data-output-path",
        type=str,
        required=True,
        help="S3 path for external processed data path."
    )
    parser.add_argument(
        "--coupon-at-till-processed-data-path",
        type=str,
        required=True,
        help="S3 path for citrus processed data."
    )
    parser.add_argument(
        "--promotional-discount-processed-data-path",
        type=str,
        required=True,
        help="S3 path for external processed data path."
    )
    parser.add_argument(
        "--value-index-processed-data-path",
        type=str,
        required=True,
        help="S3 path for external processed data path."
    )
    parser.add_argument(
        "--sales-processed-data-path",
        type=str,
        required=True,
        help="S3 path for external processed data path."
    )
    parser.add_argument(
        "--youtube-processed-data-path",
        type=str,
        required=True,
        help="S3 path for external processed data path."
    )
    parser.add_argument(
        "--base-price-data-path",
        type=str,
        required=True,
        help="S3 path for external processed data path."
    )
    parser.add_argument(
        "--secondary-space-data-path",
        type=str,
        required=True,
        help="S3 path for external processed data path."
    )
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="S3 path for weekly calendar reference data."
    )
    parser.add_argument(
        "--ecoupon-processed-data-path",
        type=str,
        required=True,
        help="S3 path for ecoupon processed data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The path in S3 to output the fb campaigns data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--metrics-topic-arn",
        type=str,
        required=True,
        help="The ARN for the SNS topic to publish validation metrics."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    _ = prepare_channel_processed_data(
        spark=spark,
        metrics_topic_arn=known_args.metrics_topic_arn,
        instore_processed_data_path=known_args.instore_processed_data_path,
        meta_processed_data_path=known_args.meta_processed_data_path,
        dv360_processed_data_path=known_args.dv360_processed_data_path,
        citrus_processed_data_path=known_args.citrus_processed_data_path,
        external_processed_data_output_path=known_args.external_processed_data_output_path,
        coupon_at_till_processed_data_path=known_args.coupon_at_till_processed_data_path,
        promotional_discount_processed_data_path=known_args.promotional_discount_processed_data_path,
        value_index_processed_data_path=known_args.value_index_processed_data_path,
        sales_processed_data_path=known_args.sales_processed_data_path,
        youtube_processed_data_path=known_args.youtube_processed_data_path,
        base_price_data_path=known_args.base_price_data_path,
        secondary_space_data_path=known_args.secondary_space_data_path,
        weekly_dates_path=known_args.weekly_dates_path,
        ecoupon_processed_data_path=known_args.ecoupon_processed_data_path,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id,
        run_date=known_args.run_date
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("ChannelProcessedData").getOrCreate())
