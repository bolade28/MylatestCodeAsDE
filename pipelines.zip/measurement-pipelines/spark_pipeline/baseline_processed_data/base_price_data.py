from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.baseline_processed_data.processed_data_utils import (
    build_cluster_date_skeleton,
    load_shared_processed_data_sources,
)
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def _load_s3_data(
    spark: SparkSession,
    fact_sales_path: str,
    store_hierarchy_path: str,
    sku_cluster_mapping_path: str,
    weekly_dates_path: str,
) -> Tuple[DataFrame, DataFrame, DataFrame, DataFrame]:
    """
    Load all s3 datasets required for base price processing to improve readability.

    Args:
        spark: Active Spark session.
        fact_sales_path: Path to the base sales fact data (transactional data with metrics we need)
        store_hierarchy_path: Path to the store hierarchy data used for store filtering.
        sku_cluster_mapping_path: Path to the SKU cluster mapping used for cluster enrichment/filtering.
        weekly_dates_path: Path to the weekly date skeleton table used for time-series alignment.

    Returns:
        A tuple containing the fact sales, store hierarchy, SKU cluster mapping,
        and weekly dates DataFrames.
    """
    fact_sales_df = (
        spark.read.parquet(fact_sales_path)
        .select(
            "transaction_dt",
            "item_cd",
            "store_cd",
            "base_unit_price_amt",
        )
    )

    store_hierarchy_df = (
        spark.read.parquet(store_hierarchy_path)
        .select("store_cd", "site_type")
    )

    sku_cluster_df, weekly_dates_df = load_shared_processed_data_sources(
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        weekly_dates_path=weekly_dates_path,
        spark=spark,
    )

    return fact_sales_df, store_hierarchy_df, sku_cluster_df, weekly_dates_df


def _filter_to_supermarket_sales(
    fact_sales_df: DataFrame,
    store_hierarchy_df: DataFrame,
    config: Dict[str, Any],
) -> DataFrame:
    """
    Args:
        fact_sales_df: Base price for each transaction at the sku level.
        store_hierarchy_df: Store hierarchy containing site types e.g. Supermarket, Convenience etc. used for filtering to relevant store formats.
        config: Configuration dictionary containing the site type filter value.

    Returns:
        Transaction-level sales data restricted to Supermarket stores.
    """
    return fact_sales_df.join(
        F.broadcast(store_hierarchy_df.filter(F.col("site_type") == config['site_type_filter'])),
        "store_cd",
        "inner",
    )


def _aggregate_weekly_item_base_prices(transaction_daily_df: DataFrame) -> DataFrame:
    """
    We aggregate using the max of the base unit price observed each week following the legacy DBT logic see below for details:
    https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/832536904/Base+price+data

    Args:
        transaction_daily_df: Transaction-level sales data for Supermarket stores.

    Returns:
        Weekly item-level base prices using the maximum base unit price observed in each week.
    """
    return (
        transaction_daily_df
        .withColumn("week_start_date", F.to_date(F.date_trunc("week", "transaction_dt")))
        .groupBy("item_cd", "week_start_date")
        .agg(F.max("base_unit_price_amt").alias("base_unit_price_amt"))
    )


def _enrich_with_sku_clusters(transaction_weekly_df: DataFrame, sku_cluster_df: DataFrame) -> DataFrame:
    """
    Args:
        transaction_weekly_df: Weekly item-level base price data.
        sku_cluster_df: SKU-to-cluster mapping for in-scope brand SKUs.

    Returns:
        Weekly item prices joined to their cluster attributes and filtered to only include the correct brand skus for the baseline model.
    """
    return (
        transaction_weekly_df
        .join(F.broadcast(sku_cluster_df), "item_cd", "inner")
        .select(
            "item_cd",
            "week_start_date",
            "base_unit_price_amt",
            "super_category_name",
            "sub_category_name",
            "unique_brand_name",
            "cluster_num",
        )
    )


def _aggregate_weekly_cluster_base_prices(trans_clustered_df: DataFrame) -> DataFrame:
    """
    Aggregate weekly item prices to granularity we're running the baseline model at (Supercategory, Brand, Cluster)

    Args:
        trans_clustered_df: Weekly item-level base prices enriched with cluster attributes.

    Returns:
        Cluster-level weekly average base prices.
    """
    return (
        trans_clustered_df
        .groupBy("super_category_name", "unique_brand_name", "cluster_num", "week_start_date")
        .agg(F.avg("base_unit_price_amt").alias("metric_value"))
    )


def _build_cluster_metric_grid(
    weekly_cluster_avg_df: DataFrame,
    weekly_dates_df: DataFrame,
    metric: str,
) -> DataFrame:
    """
    Create the full cluster-by-week grid across the modelling period.

    Args:
        weekly_cluster_avg_df: Cluster-level weekly average base prices.
        weekly_dates_df: Weekly date skeleton covering the modelling period.
        metric: Metric label to attach to every row.

    Returns:
        A complete cluster-by-week grid with observed metric values left joined in.
    """
    skeleton = (
        build_cluster_date_skeleton(
            weekly_dates_df=weekly_dates_df,
            cluster_attrs_df=weekly_cluster_avg_df,
        )
        .withColumn("metric", F.lit(metric))
    )

    return skeleton.join(
        weekly_cluster_avg_df.withColumn("metric", F.lit(metric)),
        ["week_start_date", "super_category_name", "unique_brand_name", "cluster_num", "metric"],
        "left",
    )


def _fill_missing_base_price_weeks(full_grid_df: DataFrame) -> DataFrame:
    """
    Ensure every cluster has a full weekly series by applying forward fill,
    backward fill, and finally a zero fallback.

    Args:
        full_grid_df: Complete cluster-by-week for the whole modelling period grid

    Returns:
        The input weekly data with imputed values in a `final_value` column.
    """
    # ToDo: Do we need to keep this logic, seems overkill :owl
    win_fw = Window.partitionBy("super_category_name", "unique_brand_name", "cluster_num").orderBy(
        "week_start_date"
    ).rowsBetween(Window.unboundedPreceding, 0)
    win_bw = Window.partitionBy("super_category_name", "unique_brand_name", "cluster_num").orderBy(
        F.col("week_start_date").desc()
    ).rowsBetween(Window.unboundedPreceding, 0)

    return (
        full_grid_df
        .withColumn("fwd", F.last("metric_value", ignorenulls=True).over(win_fw))
        .withColumn("bwd", F.first("metric_value", ignorenulls=True).over(win_bw))
        .withColumn("final_value", F.coalesce("metric_value", "fwd", "bwd", F.lit(0.0)))
    )


def _format_base_price_output(
    filled_df: DataFrame,
    config: Dict[str, Any],
    correlation_id: str,
) -> DataFrame:
    """
    Apply the final formatting required for baseline processed data scripts.
    Creating the final output for the BASE_UNIT_PRICE_AMT metric.

    Args:
        filled_df: Cluster-level weekly base prices with imputed final values.
        config: Base price configuration values for static output columns.
        correlation_id: Unique identifier for the pipeline run.

    Returns:
        Final base price processed dataset ready to be written.
    """
    timestamp = F.lit(datetime.now())
    return (
        filled_df.select(
            F.to_date(F.col("week_start_date")).alias("week_start_dt"),
            "super_category_name",
            "unique_brand_name",
            F.lit(config["marketing_type_name"]).alias("marketing_type_name"),
            F.lit(config["marketing_channel_name"]).alias("marketing_channel_name"),
            F.lit(config["marketing_sub_channel_name"]).alias("marketing_sub_channel_name"),
            "cluster_num",
            "metric",
            F.lit(config["metric_name"]).alias("metric_name"),
            F.col("final_value").alias("metric_value"),
            F.lit(correlation_id).alias("job_run_id"),
            timestamp.alias("load_ts"),
            F.to_json(F.struct(timestamp.alias("effective_ts"))).alias("technical_metadata"),
        )
    )


def prepare_base_price_data(
    spark: SparkSession,
    fact_sales_path: str,
    sku_cluster_mapping_path: str,
    store_hierarchy_path: str,
    weekly_dates_path: str,
    output_path: str,
    correlation_id: str,
) -> None:
    """
    Generate time series data for base prices at the SKU cluster level.
    producing the base_unit_price_amt feature metric.

    Business Context:
    - Base Price data is an input for Baseline Modelling to estimate baseline sales more accurately.
    - Variations in base price (excluding promotions or discounts) can significantly influence overall sales volumes.

    Confluence: https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/832536904/Base+price+data

    Args:
        spark: Active Spark session.
        fact_sales_path: Path to the base sales fact data.
        sku_cluster_mapping_path: Path to the SKU cluster mapping used for aggregating SKUs into clusters.
        store_hierarchy_path: Path to the store hierarchy data for location and zone type filtering.
        weekly_dates_path: Path to the weekly date skeleton table used for time-series alignment.
        output_path: Output location for the processed base price dataset.
        correlation_id: Unique identifier for tracking the DAG or pipeline run.

    Returns:
        None -> The function writes the processed base price dataset to the specified output path.
    """
    config = BaselineProcessedData.base_price_data_config

    fact_sales_df, store_hierarchy_df, sku_cluster_df, weekly_dates_df = _load_s3_data(
        spark=spark,
        fact_sales_path=fact_sales_path,
        store_hierarchy_path=store_hierarchy_path,
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        weekly_dates_path=weekly_dates_path,
    )

    transaction_daily = _filter_to_supermarket_sales(fact_sales_df, store_hierarchy_df, config)
    transaction_weekly = _aggregate_weekly_item_base_prices(transaction_daily)

    transaction_clustered = _enrich_with_sku_clusters(transaction_weekly, sku_cluster_df)
    weekly_cluster_avg = _aggregate_weekly_cluster_base_prices(transaction_clustered)
    full_weekly_series = _build_cluster_metric_grid(weekly_cluster_avg, weekly_dates_df, config["metric"])
    imputed_weekly_series = _fill_missing_base_price_weeks(full_weekly_series)
    final_base_price_df = _format_base_price_output(imputed_weekly_series, config, correlation_id)

    # Write the final output to s3
    spark_s3_overwrite(output_path, final_base_price_df)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Base Price Data for baseline pipeline.")
    parser.add_argument(
        "--fact-sales-path",
        type=str,
        required=True,
        help="Path to base sales fact data."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="Path to SKU cluster mapping."
    )
    parser.add_argument(
        "--store-hierarchy-path",
        type=str,
        required=True,
        help="Path to store hierarchy data."
    )
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="Path to weekly date skeleton table."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="Output location for processed base price dataset."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG or pipeline run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_base_price_data(
        spark=spark,
        fact_sales_path=known_args.fact_sales_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        store_hierarchy_path=known_args.store_hierarchy_path,
        weekly_dates_path=known_args.weekly_dates_path,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("BasePriceData").getOrCreate())
