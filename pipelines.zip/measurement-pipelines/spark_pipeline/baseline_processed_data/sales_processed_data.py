from typing import List, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.baseline_processed_data.processed_data_utils import load_shared_processed_data_sources
from spark_pipeline.utils.pipeline_utils import get_model_dates
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_sales_processed_data(
    spark: SparkSession,
    weekly_dates_path: str,
    sku_cluster_mapping_path: str,
    sales_data_transaction: str,
    output_path: str,
    correlation_id: str,
) -> None:
    """
    Generates weekly aggregated sales data at the SKU cluster level,
    producing the TOTAL_SALES metric.

    :param spark: The SparkSession object.
    :param weekly_dates_path: Path to the weekly date skeleton table.
    :param sku_cluster_mapping_path: Path to the SKU cluster mapping.
    :param sales_data_transaction: Path to the pre-aggregated weekly sales transaction data.
    :param output_path: Output location for processed sales dataset.
    :param correlation_id: Unique identifier for tracking the DAG or pipeline run.
    :return: None
    """
    config = BaselineProcessedData.sales_data_config

    sku_cluster_mapping_df, weekly_dates_df = load_shared_processed_data_sources(
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        weekly_dates_path=weekly_dates_path,
        spark=spark,
    )

    sales_data_transaction_df = (
        spark
        .read
        .parquet(sales_data_transaction)
        .select(
            'week_start_dt',
            'item_cd',
            'total_sales_amt',
        )
    )

    # Inner join to filter the sales to the to brand SKUs and bring in cluster attributes
    sales_cluster_df = (
        sales_data_transaction_df
        .join(
            sku_cluster_mapping_df,
            on="item_cd",
            how="inner",
        )
        .select(
            'week_start_dt',
            'super_category_name',
            'unique_brand_name',
            'item_cd',
            'total_sales_amt',
            'cluster_num',
        )
    )

    sales_processed_data_intermediate = (
        sales_cluster_df
        .groupBy("week_start_dt", "super_category_name", "unique_brand_name", "cluster_num")
        .agg(F.sum("total_sales_amt").alias("metric_value"))
    )

    # Derive model date bounds from the weekly dates skeleton
    temp_date_dataset = weekly_dates_df.select(F.col("week_start_dt").alias("week_start_date"))
    min_date, max_date = get_model_dates(temp_date_dataset)

    final_sales_data = (
        sales_processed_data_intermediate
        .filter(
            (F.col("week_start_dt") >= min_date) &
            (F.col("week_start_dt") <= max_date)
        )
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            F.lit(config['marketing_type_name']).alias("marketing_type_name"),
            F.lit(config['marketing_channel_name']).alias("marketing_channel_name"),
            F.lit(config['marketing_sub_channel_name']).alias("marketing_sub_channel_name"),
            F.lit(config['metric_name']).alias("metric_name"),
            "metric_value",
            F.lit(correlation_id).alias("job_run_id"),
            F.current_timestamp().alias("load_ts"),
        )
    )

    # Write the final output to s3
    spark_s3_overwrite(output_path, final_sales_data)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Sales Processed Data.")

    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="S3 path for weekly calendar reference data."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="S3 path for SKU to cluster mapping."
    )
    parser.add_argument(
        "--sales-data-transaction",
        type=str,
        required=True,
        help="S3 path for pre-aggregated weekly sales transaction data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for output of sales processed data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for traceability."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_sales_processed_data(
        spark=spark,
        weekly_dates_path=known_args.weekly_dates_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        sales_data_transaction=known_args.sales_data_transaction,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("SalesProcessedData").getOrCreate())
