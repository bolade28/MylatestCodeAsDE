from typing import List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset


def load_shared_processed_data_sources(
        sku_cluster_mapping_path: str,
        weekly_dates_path: str,
        spark: SparkSession,
        extra_sku_cols: Optional[List[str]] = None,
) -> Tuple[DataFrame, DataFrame]:
    """
    Load the two shared sources common to all baseline processed data pipelines:
    the SKU cluster mapping (filtered to brand SKUs) and the weekly date skeleton.

    Standard sku cluster mapping columns are: "item_cd", "super_category_name", "sub_category_name", "unique_brand_name", "cluster_num"
    """
    sku_cluster_mapping_df = load_parquet_dataset(
        spark, sku_cluster_mapping_path, 'sku_cluster_mapping',
        slack_notifier=None, columns=BaselineProcessedData.sku_cluster_mapping_cols + (extra_sku_cols or [])
    )

    weekly_dates_df = spark.read.parquet(weekly_dates_path).select("week_start_dt")

    return sku_cluster_mapping_df, weekly_dates_df


def build_cluster_date_skeleton(
        weekly_dates_df: DataFrame,
        cluster_attrs_df: DataFrame,
) -> DataFrame:
    """
    Cross-join distinct (super_category_name, unique_brand_name, cluster_num) combinations
    with the full weekly date range to produce a complete time-series skeleton.

    :param weekly_dates_df: DataFrame with a week_start_dt column.
    :param cluster_attrs_df: DataFrame containing at minimum super_category_name,
                             unique_brand_name, and cluster_num columns.
    :return: Skeleton DataFrame with week_start_date, super_category_name,
             unique_brand_name, cluster_num.
    """
    distinct_clusters = (
        cluster_attrs_df
        .select("super_category_name", "unique_brand_name", "cluster_num")
        .distinct()
    )
    return (
        weekly_dates_df
        .select(F.col("week_start_dt").alias("week_start_date"))
        .crossJoin(distinct_clusters)
    )


def normalise_pollen_dtp_join_columns(
    df: DataFrame,
    normalised_columns: List[str],
) -> DataFrame:
    """Normalise columns to uppercase for consistent dataset comparison."""
    shared_dimension_columns = [
        "super_category_name",
        "unique_brand_name",
        "cluster_num",
        "marketing_type_name",
        "marketing_channel_name",
        "marketing_sub_channel_name",
        "metric_name",
    ]
    return df.select(
        "week_start_dt",
        "metric_value",
        *[
            (F.upper(F.col(column_name)).alias(column_name)
             if column_name in normalised_columns
             else F.col(column_name))
            for column_name in shared_dimension_columns
        ],
    )
