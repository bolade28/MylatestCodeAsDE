from typing import Any, Dict, List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from spark_pipeline.baseline_processed_data.processed_data_utils import (
    build_cluster_date_skeleton,
    load_shared_processed_data_sources,
)
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def _load_s3_data(
    spark: SparkSession,
    weekly_dates_path: str,
    item_brand_hist_path: str,
    processed_sales_transaction_item_path: str,
    sku_cluster_mapping_path: str,
) -> Tuple[DataFrame, DataFrame, DataFrame, DataFrame]:
    """
    Load all s3 datasets required for promotional discount processing.

    Args:
        spark: Active Spark session.
        weekly_dates_path: Path to the weekly date skeleton table.
        item_brand_hist_path: Path to the ITEM_BRAND_HIST dataset.
        processed_sales_transaction_item_path: Path to item-level sales transaction data.
        sku_cluster_mapping_path: Path to the SKU cluster mapping.

    Returns:
        A tuple containing the transaction item, item brand hist, SKU cluster mapping,
        and weekly dates DataFrames.
    """
    sku_cluster_mapping_df, weekly_dates_df = load_shared_processed_data_sources(
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        weekly_dates_path=weekly_dates_path,
        spark=spark,
    )

    # Item-level transaction data we look for any promotions in
    # This table is pre-filtered to the model start and end date
    transaction_sale_return_df = (
        spark.read.parquet(processed_sales_transaction_item_path)
        .select(
            "transaction_id",
            "transaction_dt",
            "net_retail_sales_amt",
            "pre_promotional_sale_amt",
            "item_cd",
            "item_type_sale_or_return",
            "uom_cd",
            "item_qty",
        )
    )

    # We use this to label all skus from our transactional data, so they have the correct hierarchy
    item_brand_hist_df = (
        spark.read.parquet(item_brand_hist_path)
        .withColumnRenamed('sub_cat_name', 'sub_category_name')
        .withColumnRenamed('super_cat_name', 'super_category_name')
        .select(
            "item_cd",
            "super_category_name",
            "sub_category_name",
            "unique_brand_name",
        )
    )

    return transaction_sale_return_df, item_brand_hist_df, sku_cluster_mapping_df, weekly_dates_df


def _prepare_transactional_item_data(
    transaction_sale_return_df: DataFrame,
    item_brand_hist_df: DataFrame,
    sku_cluster_mapping_df: DataFrame,
    config: Dict[str, Any]
) -> DataFrame:
    """
    Prepare transactional item data for promotional discount calculations.
    Filtering to the wider sub-categories for the current baseline run and labelling cluster vs non-cluster items for the metrics

    Args:
        transaction_sale_return_df: Item-level transactional sales and returns data.
        item_brand_hist_df: Item brand and hierarchy data from ITEM_BRAND_HIST.
        sku_cluster_mapping_df: SKU-to-cluster mapping for in-scope brand SKUs.
        config: Configuration dictionary containing filtering columns for F.col(item_type_sale_or_return)

    Returns:
        Transactional item data enriched with hierarchy, cluster, quantity, and week fields.
    """

    # This will be used to get all transactional data with the relevant subcategories for the current run
    relevant_subcategories_df = (
        sku_cluster_mapping_df
        .select("super_category_name", "sub_category_name")
        .distinct()
    )

    brand_skus_df = sku_cluster_mapping_df.select("item_cd", "cluster_num")

    # Inner join with relevant_subcategories to filter to get the broader sub-categories
    # Then left join with the targeted brand skus so we can compare the two outputs to form cluster + non-cluster metrics
    return (
        transaction_sale_return_df
        .join(item_brand_hist_df, on="item_cd", how="inner")  # Drops SKUs with no product hierarchy
        .join(
            F.broadcast(relevant_subcategories_df),
            on=["super_category_name", "sub_category_name"],
            how="inner",
        )
        .join(F.broadcast(brand_skus_df), on="item_cd", how="left")
        .withColumn("cluster_num", F.coalesce(F.col("cluster_num"), F.lit("non_cluster")))  # This is not needed, I've just added it to make it clear that there is a non-cluster group
        .withColumn(
            "item_sale_qty",
            F.when(
                F.col("item_type_sale_or_return") == config['item_type_sale_value'],
                F.when(F.col("uom_cd") != "EA", 1).otherwise(F.col("item_qty")),  # Treat non-'EA' (Each) units as 1 (non-countable like weight/volume), otherwise use actual item_qty for countable items
            )
            .otherwise(0)
            .cast("int"),
        )
        .withColumn(
            "item_return_qty",
            F.when(
                F.col("item_type_sale_or_return") == config['item_type_return_value'],
                F.when(F.col("uom_cd") != "EA", 1).otherwise(F.col("item_qty")),
            )
            .otherwise(0)
            .cast("int"),
        )
        .withColumn("week_start_date", F.date_trunc("week", F.col("transaction_dt")))
        .select(
            "transaction_id",
            "transaction_dt",
            "net_retail_sales_amt",
            "pre_promotional_sale_amt",
            "item_cd",
            "item_type_sale_or_return",
            "uom_cd",
            "item_qty",
            "super_category_name",
            "sub_category_name",
            "unique_brand_name",
            "cluster_num",
            "item_sale_qty",
            "item_return_qty",
            "week_start_date",
        )
    )


def _aggregate_sales_per_cluster(transactional_item_data_df: DataFrame) -> DataFrame:
    """
    Aggregate net and pre-promotional sales per cluster per week.
    We only have one cluster with all brand skus, so this will be over this cluster and left over skus within a subcategory which are labelled as non_cluster

    Args:
        transactional_item_data_df: Enriched transactional item data.

    Returns:
        Cluster-level weekly net sales, pre-promotional sales, and brand counts.
    """

    return (
        transactional_item_data_df
        .groupBy("super_category_name", "cluster_num", "week_start_date")
        .agg(
            F.sum("net_retail_sales_amt").alias("net_sales_in_cluster"),
            F.sum("pre_promotional_sale_amt").alias("pre_promo_sales_in_cluster"),
            F.count_distinct("unique_brand_name").alias("cluster_num_brands"),
        )
    )


def _aggregate_sales_per_supercategory(sales_per_cluster_df: DataFrame) -> DataFrame:
    """
    Aggregate totals across all clusters in each super-category and week.

    Args:
        sales_per_cluster_df: Cluster-level weekly sales aggregates.

    Returns:
        Supercategory-level weekly net sales, pre-promotional sales, and brand counts.
    """

    return (
        sales_per_cluster_df
        .groupBy("super_category_name", "week_start_date")
        .agg(
            F.sum("net_sales_in_cluster").alias("total_net_sales_subcat"),
            F.sum("pre_promo_sales_in_cluster").alias("total_pre_promo_sales_subcat"),
            F.sum("cluster_num_brands").alias("total_num_brands_subcat"),
        )
    )


def _calculate_promotional_discount_per_cluster(
    sales_per_cluster_df: DataFrame,
    sales_per_subcategory_df: DataFrame,
    config: Dict[str, Any],
) -> DataFrame:
    """
    Calculate weekly promotional discount features for each cluster by comparing
    cluster-level sales against the remainder of the super-category.

    It derives the sales for the non-cluster portion of the supercategory
    by subtracting the cluster totals from the supercategory totals.

    Two discount percentages are calculated using the formula:
        (1 - net_sales / pre_promotional_sales) * 100

    where:
        - discount_perc represents the promotional discount percentage for the cluster
        - non_cluster_discount_perc represents the promotional discount percentage for all other items in the same supercategory outside the cluster

    If either the net sales or pre-promotional sales value is not positive, the
    corresponding discount metric is set to 0.

    The function also calculates 'non_cluster_num_brands', which is the number of
    distinct brands in the super-category excluding brands belonging to the cluster.

    Args:
        sales_per_cluster_df: Cluster-level weekly sales aggregates.
        sales_per_subcategory_df: Supercategory-level weekly sales aggregates.
        config: Promotional discount configuration values.

    Returns:
        Cluster-level weekly discount metrics.

    Note:
        This was previous on the sub-category level but since we process all sub-categories within a brand together (one row in the output), we have moved it to the super-category level.
        The cluster is still at the same level, it only contains the brand skus.
    """
    discount_perc = config["discount_perc_metric"]
    non_cluster_discount_perc = config["non_cluster_discount_perc_metric"]

    return (
        sales_per_cluster_df
        .join(
            sales_per_subcategory_df,
            on=["super_category_name", "week_start_date"],
            how="left",
        )
        .withColumn(
            "total_net_sales_non_cluster",
            F.col("total_net_sales_subcat") - F.col("net_sales_in_cluster"),
        )
        .withColumn(
            "total_pre_promo_sales_non_cluster",
            F.col("total_pre_promo_sales_subcat") - F.col("pre_promo_sales_in_cluster"),
        )
        .withColumn(
            discount_perc,
            F.when(
                F.expr("net_sales_in_cluster > 0 AND pre_promo_sales_in_cluster > 0"),
                F.round(
                    (1 - (F.col("net_sales_in_cluster") / F.col("pre_promo_sales_in_cluster"))) * 100,
                    5,
                ),
            ).otherwise(0),
        )
        .withColumn(
            non_cluster_discount_perc,
            F.when(
                F.expr(
                    "total_net_sales_non_cluster > 0 AND total_pre_promo_sales_non_cluster > 0"
                ),
                F.round(
                    (
                        1
                        - (
                            F.col("total_net_sales_non_cluster")
                            / F.col("total_pre_promo_sales_non_cluster")
                        )
                    ) * 100,
                    5,
                ),
            ).otherwise(0),
        )
        .withColumn(
            "non_cluster_num_brands",
            F.col("total_num_brands_subcat") - F.col("cluster_num_brands"),
        )
        .select(
            "cluster_num",
            "week_start_date",
            "non_cluster_num_brands",
            discount_perc,
            non_cluster_discount_perc,
        )
    )


def _join_with_data_skeleton(
    weekly_dates_df: DataFrame,
    sku_cluster_mapping_df: DataFrame,
    promotional_discount_per_cluster_df: DataFrame,
    config: Dict[str, Any],
) -> DataFrame:
    """
    Join the promotional discount metrics onto the full cluster-by-week skeleton.

    Args:
        weekly_dates_df: Weekly date skeleton covering the modelling period.
        sku_cluster_mapping_df: SKU-to-cluster mapping used to derive cluster attributes.
        promotional_discount_per_cluster_df: Computed cluster discount metrics.
        config: Promotional discount configuration values.

    Returns:
        Full cluster-by-week promotional discount dataset with null metrics imputed to zero.
    """
    discount_perc = config["discount_perc_metric"]
    non_cluster_discount_perc = config["non_cluster_discount_perc_metric"]
    num_brands = config["num_brands_metric"]

    # This joins the clusters were going to run with the modelling period, creating our time series data
    promotional_discount_skeleton_final_df = build_cluster_date_skeleton(
        weekly_dates_df=weekly_dates_df,
        cluster_attrs_df=sku_cluster_mapping_df,
    )

    # Left join skeleton with computed discount values, imputing nulls with 0
    return (
        promotional_discount_skeleton_final_df
        .join(
            promotional_discount_per_cluster_df,
            on=["week_start_date", "cluster_num"],
            how="left",
        )
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            F.lit(config["marketing_type_name"]).alias("marketing_type"),
            F.lit(config["marketing_sub_channel_name"]).alias("marketing_sub_channel"),
            "cluster_num",
            F.coalesce(F.col(discount_perc), F.lit(0)).alias(discount_perc),
            F.coalesce(F.col(non_cluster_discount_perc), F.lit(0)).alias(non_cluster_discount_perc),
            F.coalesce(F.col("non_cluster_num_brands"), F.lit(0)).alias(num_brands),
        )
    )


def _unpivot_promotional_discount_metrics(
    promotional_discount_unique_brand_cluster_hierarchy_df: DataFrame,
    config: Dict[str, Any],
) -> DataFrame:
    """
    Unpivot promotional discount metric columns into metric rows.

    Args:
        promotional_discount_unique_brand_cluster_hierarchy_df: Cluster-level promotional discount dataset.
        config: Promotional discount configuration values.

    Returns:
        Unpivoted promotional discount metrics with marketing channel labels.
    """
    discount_perc = config["discount_perc_metric"]
    non_cluster_discount_perc = config["non_cluster_discount_perc_metric"]
    num_brands = config["num_brands_metric"]

    discount_metric_name = config["discount_metric_cluster_label"]
    discount_non_cluster_metric_name = config["discount_metric_non_cluster_label"]

    # Unpivot the three metric columns into rows
    return (
        promotional_discount_unique_brand_cluster_hierarchy_df
        .unpivot(
            [
                "week_start_date",
                "super_category_name",
                "unique_brand_name",
                "cluster_num",
                "marketing_type",
            ],
            config["discount_metrics"],
            "metric",
            "value",
        )
        .withColumn(
            "marketing_channel",
            F.when(F.col("metric") == discount_perc, discount_metric_name)
            .otherwise(
                F.when(
                    (F.col("metric") == non_cluster_discount_perc) | (F.col("metric") == num_brands),
                    discount_non_cluster_metric_name,
                )
            ),
        )
    )


def _format_promotional_discount_output(
    promotional_discount_processed_data_df: DataFrame,
    config: Dict[str, Any],
    correlation_id: str,
) -> DataFrame:
    """
    Apply the final formatting required for baseline processed data scripts.
    Creating the final output for the discount_perc, non_cluster_discount_perc, num_brands metrics.

    Args:
        promotional_discount_processed_data_df: Unpivoted promotional discount metrics.
        config: Promotional discount configuration values.
        correlation_id: Unique identifier for the pipeline run.

    Returns:
        Final promotional discount processed dataset ready to be written.
    """
    return promotional_discount_processed_data_df.select(
        F.col("week_start_date").alias("week_start_dt"),
        "super_category_name",
        "unique_brand_name",
        "cluster_num",
        F.col("marketing_type").alias("marketing_type_name"),
        F.col("marketing_channel").alias("marketing_channel_name"),
        F.lit(config["marketing_sub_channel_name"]).alias("marketing_sub_channel_name"),
        F.col("metric").alias("metric_name"),
        F.col("value").alias("metric_value"),
        F.lit(correlation_id).alias("job_run_id"),
        F.current_timestamp().alias("load_ts"),
    )


def prepare_promotional_discount_processed_data(
    spark: SparkSession,
    weekly_dates_path: str,
    item_brand_hist_path: str,
    processed_sales_transaction_item_path: str,
    sku_cluster_mapping_path: str,
    output_path: str,
    correlation_id: str,
) -> None:
    """
    Creates time series data for promotional discount at the cluster level,
    producing the discount_percentage, non_cluster_discount_percentage and num_brands feature metrics.

    Business Context:
    - Promotional Discounts data helps the Baseline Modelling script estimate Baseline Sales.
    - Variations in price generally impact overall sales volumes.
    - Discounted items are expected to lead to an increase in sales that the model captures.

    Confluence:
        https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/832177401/Promotional+discount+processed+data

    Args:
        spark: Active Spark session.
        weekly_dates_path: Path to the weekly date skeleton table.
        item_brand_hist_path: Path to the ITEM_BRAND_HIST dataset.
        processed_sales_transaction_item_path: Path to item-level sales transaction data.
        sku_cluster_mapping_path: Path to the SKU cluster mapping.
        output_path: Output location for processed promotional discount dataset.
        correlation_id: Unique identifier for tracking the DAG or pipeline run.

    Returns:
        None -> The function writes the processed promotional discount dataset to the specified output path.
    """
    config = BaselineProcessedData.promotional_discount_config

    (
        transaction_sale_return_df,
        item_brand_hist_df,
        sku_cluster_mapping_df,
        weekly_dates_df,
    ) = _load_s3_data(
        spark=spark,
        weekly_dates_path=weekly_dates_path,
        item_brand_hist_path=item_brand_hist_path,
        processed_sales_transaction_item_path=processed_sales_transaction_item_path,
        sku_cluster_mapping_path=sku_cluster_mapping_path,
    )

    transactional_item_data_df = _prepare_transactional_item_data(
        transaction_sale_return_df,
        item_brand_hist_df,
        sku_cluster_mapping_df,
        config
    )

    sales_per_cluster_df = _aggregate_sales_per_cluster(transactional_item_data_df)
    sales_per_supercategory_df = _aggregate_sales_per_supercategory(sales_per_cluster_df)

    promotional_discount_per_cluster_df = _calculate_promotional_discount_per_cluster(
        sales_per_cluster_df,
        sales_per_supercategory_df,
        config,
    )
    promotional_discount_unique_brand_cluster_hierarchy_df = _join_with_data_skeleton(
        weekly_dates_df,
        sku_cluster_mapping_df,
        promotional_discount_per_cluster_df,
        config,
    )
    promotional_discount_processed_data_df = _unpivot_promotional_discount_metrics(
        promotional_discount_unique_brand_cluster_hierarchy_df,
        config,
    )
    final_promotional_discount_data_df = _format_promotional_discount_output(
        promotional_discount_processed_data_df,
        config,
        correlation_id,
    )

    spark_s3_overwrite(output_path, final_promotional_discount_data_df)


def entrypoint(
    spark: SparkSession, command_line_args: Optional[List[str]] = None
) -> None:

    parser = ThrowingArgumentParser(
        description="Prepare Promotional Discount Processed Data."
    )

    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="S3 path for weekly calendar reference data.",
    )
    parser.add_argument(
        "--item-brand-hist-path",
        type=str,
        required=True,
        help="S3 path for ITEM_BRAND_HIST dataset.",
    )
    parser.add_argument(
        "--processed-fact-sales-transaction-item",
        type=str,
        required=True,
        help="S3 path for processed item-level sales transactions.",
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="S3 path for SKU to cluster mapping.",
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for output of promotional discount processed data.",
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for traceability.",
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_promotional_discount_processed_data(
        spark=spark,
        weekly_dates_path=known_args.weekly_dates_path,
        item_brand_hist_path=known_args.item_brand_hist_path,
        processed_sales_transaction_item_path=known_args.processed_fact_sales_transaction_item,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id,
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder.appName("PromotionalDiscountProcessedData").getOrCreate()
    )
