from typing import List, Optional
from pyspark.sql import SparkSession
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data_helper import (
    read_s3_data,
    build_meta_required_campaigns,
    build_meta_required_campaigns_columns,
    build_meta_reqd_metrics,
    build_meta_reqd_metrics_jb,
    build_meta_metrics_jb_sku_pre,
    build_meta_num_skus,
    build_meta_camp_skus_split,
    build_meta_camp_cluster,
    build_meta_unique_brand_cluster,
    build_meta_unique_brand_cluster_unpivot,
    build_skeleton_meta_unique_brand,
    build_skeleton_with_dates,
    build_meta_processed_data,
    format_meta_processed_data
)
from spark_pipeline.utils.stdout_logger import StdOutLogger
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


logger = StdOutLogger()


def prepare_meta_processed_data(
    spark: SparkSession,
    fb_campaign_normalize_path: str,
    fb_insight_normalize_path: str,
    sku_cluster_mapping_path: str,
    weekly_dates_path: str,
    output_path: str,
) -> None:
    """

    * Objective:
    - This script is used to create time series data for Meta campaigns at cluster level and create feature metrics using pyspark -
      clicks, impressions, external_spends, internal_spends etc..

    * Business Context:
    - Meta data is processed to calculate key performance metrics like internal_media_spend, external_media_spend,
      impressions, clicks, sales_online, sales_instore, total_sales.
    - This activity is then tested in the UCM model, which helps the model isolate the impact of marketing to
      calculate Baseline Sales.

    * Lineage:
        Upstream:
            - Campaign Selection
            - Facebook Insight normalize
            - Facebook Campaign normalize
            - Unified Product
            - Sku cluster mapping
            - Dates
    Downstream:
        - 08_ads_creation (channel_processed_data.sql)

    * Confluence:
    https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/832341568/Meta+processed+data

    :param spark: The SparkSession object.
    :param campaign_selection_path: The S3 path for campaing selection python table.
    :param fb_campaign_normalize_path: The S3 path for the facebook campaign normalize table .
    :param fb_insight_normalize_path: The S3 path for the fb_insight_normalize_path table.
    :param weekly_dates_path: The S3 path for the weekly dates table.
    :param sku_cluster_mapping_path: The S3 path for the sku clustering table.
    :param output_path: The S3 path for the output of Meta processed table.
    :return: None
    """

    # Read all S3 data
    (meta_camp_skus,
     meta_metrics,
     sku_cluster_df,
     temp_date_dataset,
     _) = read_s3_data(
        spark,
        fb_campaign_normalize_path,
        fb_insight_normalize_path,
        sku_cluster_mapping_path,
        'DTP',
        weekly_dates_path=weekly_dates_path
    )

    # Process data through transformation pipeline
    meta_required_campaigns = build_meta_required_campaigns(meta_camp_skus, sku_cluster_df)
    meta_required_campaigns_columns = build_meta_required_campaigns_columns(meta_required_campaigns)
    meta_reqd_metrics = build_meta_reqd_metrics(meta_metrics, meta_required_campaigns_columns)
    meta_reqd_metrics_jb = build_meta_reqd_metrics_jb(meta_reqd_metrics)
    meta_metrics_jb_sku = build_meta_metrics_jb_sku_pre(meta_reqd_metrics_jb, meta_required_campaigns)
    meta_num_skus = build_meta_num_skus(meta_metrics_jb_sku)
    meta_camp_skus_split = build_meta_camp_skus_split(meta_metrics_jb_sku, meta_num_skus)
    meta_camp_cluster = build_meta_camp_cluster(meta_camp_skus_split, sku_cluster_df)
    meta_unique_brand_cluster = build_meta_unique_brand_cluster(meta_camp_cluster)
    meta_unique_brand_cluster_unpivot = build_meta_unique_brand_cluster_unpivot(meta_unique_brand_cluster)

    # Build skeleton and join with actual data
    skele_meta_unique_brand = build_skeleton_meta_unique_brand(meta_unique_brand_cluster_unpivot)
    skele_meta_unique_brand_final = build_skeleton_with_dates(temp_date_dataset, skele_meta_unique_brand)

    meta_processed_data = build_meta_processed_data(
        skele_meta_unique_brand_final,
        meta_unique_brand_cluster_unpivot
    )

    meta_processed_data_print = format_meta_processed_data(meta_processed_data)
    logger.info(f"DTP final_meta_processed_data: {meta_processed_data_print.count()}")

    spark_s3_overwrite(output_path, meta_processed_data_print)


def entrypoint(spark: SparkSession,
               command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(
        description="Prepare Meta processed data for baseline pipeline.")
    parser.add_argument(
        "--fb-campaign-normalize-path",
        type=str,
        required=True,
        help="The S3 path for the facebook campaign normalize table."
    )
    parser.add_argument(
        "--fb-insight-normalize-path",
        type=str,
        required=True,
        help="The S3 path for the facebook insight normalize table."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="The S3 path for the sku cluster mapping table."
    )
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="The S3 path for the weekly dates mapping table."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The S3 path for the output of campaign_product_type."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_meta_processed_data(
        spark=spark,
        fb_campaign_normalize_path=known_args.fb_campaign_normalize_path,
        fb_insight_normalize_path=known_args.fb_insight_normalize_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        weekly_dates_path=known_args.weekly_dates_path,
        output_path=known_args.output_path,
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder.appName("MetaProcessedData").getOrCreate())
