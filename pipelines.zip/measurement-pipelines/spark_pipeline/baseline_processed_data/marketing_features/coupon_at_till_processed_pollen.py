from typing import List, Optional

from pyspark.sql import functions as F, types as T, SparkSession, DataFrame
from datetime import date
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData, CouponAtTillConfig
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.stdout_logger import StdOutLogger
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite

logger = StdOutLogger()


def prepare_coupon_at_till_processed(
    spark: SparkSession,
    campaign_booking_media_channel_path: str,
    sku_cluster_mapping_path: str,
    coupon_path: str,
    coupon_cell_path: str,
    cell_path: str,
    campaign_path: str,
    historic_cat_processed_data: str,
    start_date: str,
    end_date: str,
    output_path: str,
    run_date: str,
    correlation_id: str,
) -> None:
    """
    Processes and aggregates coupon-at-till campaign data at the cluster level to generate time series feature metrics
    (base_value, coupon_value, spend) for use in downstream modeling.

    This function reads multiple input datasets, filters and joins them to identify relevant campaigns and SKUs,
    calculates daily and weekly metrics, merges with historic data, and writes the final processed output.

    * Business Context:
        - Coupon at Till data is processed to calculate key performance metrics like coupon value, base value and  spend.
        - This activity is then tested in the UCM model, which helps the model isolate the impact of marketing to
        calculate Baseline Sales.

    Args:
        spark (SparkSession): Active Spark session.
        campaign_booking_media_channel_path (str): Path to campaign booking media channel data (parquet).
        sku_cluster_mapping_path (str): Path to SKU-cluster mapping data (parquet).
        coupon_path (str): Path to coupon data (parquet).
        coupon_cell_path (str): Path to coupon-cell mapping data (parquet).
        cell_path (str): Path to cell data (parquet).
        campaign_path (str): Path to campaign data (parquet).
        historic_cat_processed_data (str): Path to historic coupon-at-till processed data (parquet).
        start_date (str): Start date for filtering campaigns (YYYY-MM-DD).
        end_date (str): End date for filtering campaigns (YYYY-MM-DD).
        output_path (str): Output path for the processed data (parquet).
        run_date (str): Pipeline run date (YYYY-MM-DD).
        correlation_id (str): Unique identifier for the pipeline run.

    Returns:
        None: Writes the processed DataFrame to the specified output path.
    """

    # Ensure start_date and end_date are strings
    if isinstance(start_date, date):
        start_date = start_date.strftime("%Y-%m-%d")
    if isinstance(end_date, date):
        end_date = end_date.strftime("%Y-%m-%d")

    sku_cluster_df = load_parquet_dataset(
        spark,
        sku_cluster_mapping_path,
        'sku_cluster_mapping',
        slack_notifier=None,
        columns=BaselineProcessedData.sku_cluster_mapping_cols,
    )

    coupon_df = (
        spark
        .read
        .parquet(coupon_path)
        .select(
            "coupon_key",
            "start_date",
            "expiry_date",
            "coupon_value"
        )
    )

    coupon_cell_df = (
        spark
        .read
        .parquet(coupon_cell_path)
        .select(
            "cell_key",
            "coupon_key"
        )
    )

    cell_df = (
        spark
        .read
        .parquet(cell_path)
        .select(
            "campaign_id",
            "cell_key"
        )
    )

    campaign_df = (
        spark
        .read
        .parquet(campaign_path)
        .select(
            "campaign_id",
            "pre_period",
            "post_period"
        )
    )

    job_run_id = correlation_id

    campaign_booking_media_channel_br = (
        spark
        .read
        .parquet(campaign_booking_media_channel_path)
        .select(
            'booking_id',
            'campaign_id',
            'channel_type',
            'booking_status',
            'media_provider',
            'media_business_group',
            'media_spend_amt',
            'booking_media_live_start_dt',
            'booking_media_live_end_dt',
            'item_cd_list'
        )
    )

    # Filter the campaign bookings for coupon-at-till campaigns
    campaign_bookings = (
        campaign_booking_media_channel_br
        .withColumn("item_cd_list", F.from_json(F.col("item_cd_list"), ProcessedData.item_schema))  # Parse JSON string to array
        .filter(
            (F.lower(F.col("channel_type")) == CouponAtTillConfig.CHANNEL_TYPE) &
            (F.lower(F.col("media_provider")) == CouponAtTillConfig.MEDIA_PROVIDER) &
            (F.lower(F.col("booking_status")).isin(CouponAtTillConfig.BOOKING_STATUS)) &
            (F.lower(F.col("media_business_group")).like(CouponAtTillConfig.MEDIA_BUSINESS_GROUP_FILTER)) &
            (F.size(F.col("item_cd_list")) > 0) &
            (~F.col("campaign_id").isin("~~", "-1")) &
            (F.col("booking_media_live_start_dt").between(start_date, end_date)) &
            (F.col("booking_media_live_end_dt").between(start_date, end_date))
        )
        .withColumnRenamed("campaign_id", "master_campaign_id")
        .withColumnRenamed("booking_media_live_start_dt", "campaign_start_date")
        .withColumnRenamed("booking_media_live_end_dt", "campaign_end_date")
        .select(
            "booking_id",
            "master_campaign_id",
            "media_spend_amt",
            "campaign_start_date",
            "campaign_end_date",
            "item_cd_list"
        )
        .distinct()
    )

    # TODO: Refactor this logic to reuse applicable helper functions from the instore processed data script to reduce duplication (see instore_processed_data_pollen_helper.py).
    # Explode item_cd_list to get individual SKUs
    known_sku_flattened = (
        campaign_bookings
        .withColumn("item", F.explode("item_cd_list"))
        .withColumn("item_cd", F.col("item.skuId").cast("string"))
        .select(
            "booking_id",
            "master_campaign_id",
            "item_cd"
        )
    )

    # Inner join with sku_cluster_df on item_cd to filter to our brand SKUs and brings in product details
    campaign_items = (
        known_sku_flattened
        .join(
            F.broadcast(sku_cluster_df),
            "item_cd",
            "inner"
        )
        .select(
            "booking_id",
            "master_campaign_id",
            "item_cd",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
        )
        .distinct()
    )

    instore_campaigns = (
        campaign_bookings
        .join(
            campaign_items,
            on=["booking_id", "master_campaign_id"],
            how="left"
        )
        .select(
            "master_campaign_id",
            "media_spend_amt",
            "campaign_start_date",
            "campaign_end_date",
            "item_cd_list",
            "item_cd",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
        )
        .filter(F.col("unique_brand_name").isNotNull())
    )

    coupon_base_data = (
        instore_campaigns
        .filter(F.col("media_spend_amt") > 0)
        .withColumn("job_bag_number", F.lit('NA'))
        .withColumnRenamed("campaign_start_date", "base_start_date")
        .withColumnRenamed("campaign_end_date", "base_end_date")
        .withColumnRenamed("media_spend_amt", "value_")
        .withColumnRenamed("master_campaign_id", "cid")
        .select(
            "job_bag_number",
            "base_start_date",
            "base_end_date",
            "value_",
            "cid",
        )
    )

    # Map coupon_key to campaign_id
    coupon_key_cid = (
        campaign_df
        .join(
            cell_df,
            "campaign_id",
            "left"
        )
        .join(
            coupon_cell_df,
            "cell_key",
            "left"
        )
        .select(
            "campaign_id",
            "coupon_key",
            "pre_period",
            "post_period",
        )
        .distinct()
    )

    # Join coupon mappings with product details, including cluster_num
    coupon_product_details = (
        coupon_key_cid
        .join(instore_campaigns, coupon_key_cid["campaign_id"] == instore_campaigns["master_campaign_id"], "left")
        .select(
            coupon_key_cid["campaign_id"],
            coupon_key_cid["coupon_key"],
            coupon_key_cid["pre_period"],
            coupon_key_cid["post_period"],
            instore_campaigns["super_category_name"],
            instore_campaigns["unique_brand_name"],
            instore_campaigns["item_cd"],
            instore_campaigns["cluster_num"],
        )
    )

    campaign_filter = (
        coupon_base_data
        .withColumnRenamed("cid", "campaign_id")
        .select('campaign_id')
        .distinct()
    )
    # Coupon value data filtered and aggregated
    coupon_value_data = (
        coupon_key_cid
        .join(
            coupon_df,
            on=["coupon_key"],
            how="left"
        )
        .join(
            campaign_filter,
            on=['campaign_id'],
            how="left_semi",
        )
        .filter(F.col("start_date").between(start_date, end_date))
        .groupBy("campaign_id")
        .agg(
            F.min("start_date").alias("start_date"),
            F.max("expiry_date").alias("expiry_date"),
            F.sum("coupon_value").alias("coupon_value"),
        )
    )

    # Explode to daily and item code level
    coupon_campaign_sku_data = (
        coupon_base_data
        .withColumnRenamed("cid", "campaign_id")
        .withColumnRenamed("value_", "base_value")
        .join(
            coupon_product_details,
            "campaign_id",
            "left",
        )
        .join(
            coupon_value_data,
            "campaign_id",
            "left",
        )
        .withColumn(
            "number_of_days",
            F.datediff(F.col("base_end_date"), F.col("base_start_date")) + F.lit(1)
        )
        .select(
            "job_bag_number",
            "campaign_id",
            "base_start_date",
            "base_end_date",
            "start_date",
            "expiry_date",
            "base_value",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "coupon_value",
            "number_of_days",
        )
        .distinct()
    )

    # Get the number of SKUs per campaign
    campaign_sku_count = (
        coupon_campaign_sku_data
        .groupBy("campaign_id")
        .agg(F.countDistinct("item_cd").alias("skus_per_camp"))
        .filter(F.col("skus_per_camp") != 0)
    )

    # Scale metrics at SKU level
    coupon_overall = (
        coupon_campaign_sku_data
        .join(
            campaign_sku_count,
            "campaign_id",
            "inner"
        )
        .withColumn("coupon_value_split", F.coalesce(F.col("coupon_value") / F.col("skus_per_camp"), F.lit(0)))
        .withColumn("base_value_split", F.coalesce(F.col("base_value") / F.col("skus_per_camp"), F.lit(0)))
        .select(
            "job_bag_number",
            "campaign_id",
            "base_start_date",
            "base_end_date",
            "start_date",
            "expiry_date",
            "base_value",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "coupon_value",
            "number_of_days",
            "skus_per_camp",
            "coupon_value_split",
            "base_value_split"
        )
    )

    # Splitting Coupon value equally for all days in the Campaign period
    coupon_overall_daily = (
        coupon_overall
        .withColumn("base_start_date", F.to_date(F.col("base_start_date")))
        .withColumn(
            "date",
            F.explode(
                F.sequence(
                    F.col("base_start_date"),
                    F.date_add(F.col("base_start_date"), F.col("number_of_days") - 1).cast(T.DateType())
                )
            )
        )
        .withColumn("coupon_value_split", F.col("coupon_value_split") / F.col("number_of_days"))
        .withColumn("base_value_split", F.col("base_value_split") / F.col("number_of_days"))
        .withColumn("date", F.col("date").cast("date"))
        .select(
            "job_bag_number",
            "campaign_id",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "date",
            "coupon_value_split",
            "base_value_split"
        )
    )

    # Aggregating Coupon value at weekly level
    coupon_overall_weekly = (
        coupon_overall_daily
        .withColumn("week_start_date", F.date_trunc("week", F.col("date")))
        .groupBy(
            "item_cd",
            "super_category_name",
            "unique_brand_name",
            "job_bag_number",
            "cluster_num",
            "week_start_date",
        )
        .agg(
            F.round(F.sum("coupon_value_split"), 2).alias("coupon_value"),
            F.round(F.sum("base_value_split"), 2).alias("base_value"),
        )
        .withColumn("week_start_date", F.date_format("week_start_date", "yyyy-MM-dd"))
    )

    # Melt (unpivot) base_value and coupon_value to get the data in long format
    coupon_unpivot = (
        coupon_overall_weekly
        .withColumn("marketing_type", F.lit(CouponAtTillConfig.MARKETING_TYPE))
        .withColumn("marketing_channel", F.lit(CouponAtTillConfig.MARKETING_CHANNEL))
        .withColumn("marketing_sub_channel", F.lit(CouponAtTillConfig.MARKETING_SUB_CHANNEL))
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "item_cd",
            "cluster_num",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            F.expr("stack(2, 'base_value', cast(base_value as decimal(35,2)), 'coupon_value', cast(coupon_value as decimal(35,2))) as (metric, value_)")
        )
    )

    # Aggregate after unpivoting
    coupon_at_till_unique_brand = (
        coupon_unpivot
        .groupBy(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "metric",
            "cluster_num"
        )
        .agg(F.sum("value_").alias("value_"))
    )

    # Prepare the final output
    coupon_at_till_processed_data = (
        coupon_at_till_unique_brand
        .filter(F.col('cluster_num').isNotNull())
        .select(
            F.to_date(F.col("week_start_date")).alias("week_start_dt"),
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            F.upper(F.col("marketing_type")).alias("marketing_type_name"),
            F.upper(F.col("marketing_channel")).alias("marketing_channel_name"),
            F.upper(F.col("marketing_sub_channel")).alias("marketing_sub_channel_name"),
            F.upper(F.col("metric")).alias("metric_name"),
            F.col("value_").alias("metric_value"),
            F.lit(job_run_id).alias("job_run_id"),
            F.lit(run_date).alias("load_ts")
        )
    )

    # Read the historic coupon at till processed data from dtp to merge with pollen data
    cat_processed_data_dtp = (
        spark
        .read
        .parquet(historic_cat_processed_data)
    )

    # Merge pollen and historic dtp data to create final coupon at till processed data
    final_cat_processed_data = merge_pollen_and_dtp_data(coupon_at_till_processed_data, cat_processed_data_dtp)

    final_cat_processed_data = final_cat_processed_data.cache()
    logger.info(f"CAT_PROCESSED_POLLEN_DATA Count: {coupon_at_till_processed_data.count()}")
    logger.info(f"CAT_PROCESSED_DATA Count: {final_cat_processed_data.count()}")

    spark_s3_overwrite(output_path, final_cat_processed_data)


def merge_pollen_and_dtp_data(
        cat_processed_data_pollen: DataFrame,
        cat_processed_data_dtp: DataFrame
) -> DataFrame:
    """
    Merge pollen and dtp coupon at till processed data, with pollen data taking precedence.

    Args:
        cat_processed_data_pollen: Pollen processed data (takes precedence)
        cat_processed_data_dtp: DTP processed data (used only when no pollen match exists)

    Returns:
        DataFrame: Combined data with pollen taking precedence over dtp
    """
    # Normalize pollen data
    cat_data_pollen_normalized = (
        cat_processed_data_pollen
        .select(
            'week_start_dt',
            'metric_value',
            F.col('super_category_name'),
            F.col('unique_brand_name'),
            F.upper(F.col('cluster_num')).alias('cluster_num'),
            F.upper(F.col('marketing_type_name')).alias('marketing_type_name'),
            F.upper(F.col('marketing_channel_name')).alias('marketing_channel_name'),
            F.upper(F.col('marketing_sub_channel_name')).alias('marketing_sub_channel_name'),
            F.upper(F.col('metric_name')).alias('metric_name')
        )
    )

    # Normalize dtp data
    cat_data_dtp_normalized = (
        cat_processed_data_dtp
        .select(
            'week_start_dt',
            'metric_value',
            F.col('super_category_name'),
            F.col('unique_brand_name'),
            F.upper(F.col('cluster_num')).alias('cluster_num'),
            F.upper(F.col('marketing_type_name')).alias('marketing_type_name'),
            F.upper(F.col('marketing_channel_name')).alias('marketing_channel_name'),
            F.upper(F.col('marketing_sub_channel_name')).alias('marketing_sub_channel_name'),
            F.upper(F.col('metric_name')).alias('metric_name')
        )
    )

    # Get dtp records that don't exist in pollen data
    join_conditions = [
        'week_start_dt',
        'super_category_name',
        'unique_brand_name',
        'cluster_num',
        'marketing_type_name',
        'marketing_channel_name',
        'marketing_sub_channel_name',
        'metric_name'
    ]

    dtp_only_records = (
        cat_data_dtp_normalized
        .join(
            cat_data_pollen_normalized,
            join_conditions,
            'left_anti'
        )
    )

    # Combine pollen data (takes precedence) with non-overlapping dtp data
    cat_combined = (
        cat_data_pollen_normalized
        .unionByName(dtp_only_records)
        .select(
            'week_start_dt',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name',
            F.col('metric_value').cast(T.DecimalType(18, 5)),
            F.lit('NA').alias('job_run_id'),
            F.current_timestamp().alias('load_ts')
        )
    )

    return cat_combined


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare  processed data for Coupon at till in baseline pipeline.")
    parser.add_argument(
        "--campaign-booking-media-channel-path",
        type=str,
        required=True,
        help="The S3 path for the campaign data."
    )
    parser.add_argument(
        "--cell-path",
        type=str,
        required=True,
        help="The S3 path for the cell data."
    )
    parser.add_argument(
        "--coupon-cell-path",
        type=str,
        required=True,
        help="The S3 path for the coupon cell data."
    )
    parser.add_argument(
        "--coupon-path",
        type=str,
        required=True,
        help="The S3 path for the coupon data."
    )
    parser.add_argument(
        "--campaign-path",
        type=str,
        required=True,
        help="The S3 path for the coupon data."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="The S3 path for the sku_cluster_mapping data."
    )
    parser.add_argument(
        "--historic-cat-processed-data",
        type=str,
        required=True,
        help="The S3 path for the historic coupon at till processed data."
    )
    # TODO: test and receive start and end dates from weekly_dates
    parser.add_argument(
        "--start-date",
        type=str,
        required=True,
        help="This is model start date"
    )
    parser.add_argument(
        "--end-date",
        type=str,
        required=True,
        help="This is model end date"
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The S3 path for the output data."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_coupon_at_till_processed(
        spark=spark,
        campaign_booking_media_channel_path=known_args.campaign_booking_media_channel_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        coupon_path=known_args.coupon_path,
        coupon_cell_path=known_args.coupon_cell_path,
        cell_path=known_args.cell_path,
        campaign_path=known_args.campaign_path,
        historic_cat_processed_data=known_args.historic_cat_processed_data,
        start_date=known_args.start_date,
        end_date=known_args.end_date,
        output_path=known_args.output_path,
        run_date=known_args.run_date,
        correlation_id=known_args.correlation_id,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("CouponAtTillProcessedData").getOrCreate())
