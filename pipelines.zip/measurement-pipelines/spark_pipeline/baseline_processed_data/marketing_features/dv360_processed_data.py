from typing import List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data_helper import (
    aggregate_to_cluster_level,
    calculate_sku_counts,
    format_final_output,
    join_cluster_info,
    scale_metrics_to_sku_level,
    unpivot_metrics,
)
from spark_pipeline.baseline_processed_data.processed_data_utils import load_shared_processed_data_sources
from spark_pipeline.common.variables import DV360Config
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


# --- Helper Functions ---
def read_s3_data(
    spark: SparkSession,
    dv360_normalised_path: str,
    sku_cluster_mapping_path: str,
    weekly_dates_path: str,
    dv360_media_report_path: str
) -> Tuple[DataFrame, DataFrame, DataFrame, DataFrame]:
    """
    Reads all necessary input DataFrames from S3 paths.

    :param spark: The SparkSession object.
    :param dv360_normalised_path: S3 path for dv360 normalised.
    :param sku_cluster_mapping_path: S3 path for SKU_CLUSTER_MAPPING.
    :param weekly_dates_path: S3 path for weekly_dates.
    :param dv360_media_report_path: S3 path for dv360_media_report_path.
    :return: A tuple containing all loaded DataFrames.
    """
    dv360_normalised_df = (
        spark.read.parquet(dv360_normalised_path).select(
            "start_dt",
            "end_dt",
            "item_cd",
            "jobbagid",
            "channel"
        )
    )
    sku_cluster_mapping_df, weekly_dates_df = load_shared_processed_data_sources(sku_cluster_mapping_path, weekly_dates_path, spark)

    dv360_media_report_df = (
        spark.read.parquet(dv360_media_report_path)
        .withColumnRenamed("jobbag_id", "jobbagid")
        .select(
            "jobbagid",
            "campaign_date",
            DV360Config.MEASURABLE_IMPRESSIONS_METRIC,
            DV360Config.VIEWABLE_IMPRESSIONS_METRIC,
            DV360Config.CLICKS_METRIC,
            DV360Config.IMPRESSIONS_METRIC,
            "revenue"
        )
    )

    return (
        dv360_normalised_df,
        sku_cluster_mapping_df,
        weekly_dates_df,
        dv360_media_report_df
    )


def get_dv360_campaigns(
    dv360_normalised_df: DataFrame,
    sku_cluster_df: DataFrame,
) -> DataFrame:
    """Get DV360 campaigns filtered by brand and super categories"""

    # Join and filter
    dv360_campaigns = (
        dv360_normalised_df
        .join(
            sku_cluster_df,
            on='item_cd',
            how="inner"
        )
        .select(
            "start_dt",
            "end_dt",
            "item_cd",
            "jobbagid",
            "channel",
            "super_category_name",
            "unique_brand_name"
        ).distinct()
    )
    return dv360_campaigns


def explode_campaigns_to_daily(dv360_campaigns):
    """Explode campaign date ranges to daily records"""
    return (
        dv360_campaigns
        .withColumn(
            "date_range",
            F.sequence(F.col("start_dt"), F.col("end_dt"))
        )
        .withColumnRenamed("item_cd", "sku_no")
        .withColumn(
            "date_",
            F.explode(F.col("date_range"))
        )
        .select(
            "super_category_name",
            "unique_brand_name",
            "sku_no",
            "jobbagid",
            "date_"
        )
    )


def get_weekly_campaigns(daily_exploded):
    """Aggregate daily records to weekly level"""
    return daily_exploded.withColumn(
        "week_start_date",
        F.date_trunc("week", F.col("date_"))
    ).select(
        "jobbagid",
        "super_category_name",
        "unique_brand_name",
        "sku_no",
        "week_start_date"
    ).distinct()


def get_unique_brand_campaigns(weekly_campaigns):
    """Get distinct campaign, brand, super category and SKU combinations"""
    return weekly_campaigns.select(
        "jobbagid",
        "super_category_name",
        "unique_brand_name",
        "sku_no"
    ).distinct()


def get_dv360_media_data(dv360_media_report, weekly_campaigns):
    """Filter DV360 media report for relevant campaigns using a join (efficient for large data)."""
    # Select only distinct master_campaign_id for join
    campaign_ids_df = (
        weekly_campaigns
        .select("jobbagid")
        .distinct()
    )
    filtered_dv360_raw = (
        dv360_media_report
        .join(
            campaign_ids_df,
            "jobbagid",
            how="inner"
        )
    )
    return filtered_dv360_raw


def aggregate_dv360_metrics(dv360_raw):
    """Aggregate DV360 metrics at campaign and date level"""

    raw_df = (
        dv360_raw
        .groupBy("campaign_date", "jobbagid")
        .agg(
            F.sum(DV360Config.IMPRESSIONS_METRIC).alias(DV360Config.IMPRESSIONS_METRIC),
            F.sum(DV360Config.CLICKS_METRIC).alias(DV360Config.CLICKS_METRIC),
            F.sum("revenue").alias(DV360Config.CAMPAIGN_SPEND_METRIC),
            F.sum(DV360Config.MEASURABLE_IMPRESSIONS_METRIC).alias(DV360Config.MEASURABLE_IMPRESSIONS_METRIC),
            F.sum(DV360Config.VIEWABLE_IMPRESSIONS_METRIC).alias(DV360Config.VIEWABLE_IMPRESSIONS_METRIC)
        )
    )
    return raw_df


def join_sku_info(metrics_df, unique_brand_campaigns):
    """Join metrics with SKU information"""
    return metrics_df.join(
        unique_brand_campaigns,
        "jobbagid",
        "left"
    )


def aggregate_to_weekly_sku_level(scaled_metrics):
    """Aggregate scaled metrics to weekly and SKU level"""

    scaled_metrics = (
        scaled_metrics
        .withColumn("week_start_date", F.date_trunc("week", F.col("campaign_date")))
        .withColumnRenamed("jobbagid", "master_campaign_id")
    )

    return scaled_metrics.groupBy(
        "master_campaign_id",
        "sku_no",
        "unique_brand_name",
        "super_category_name",
        "week_start_date"
    ).agg(
        F.sum(DV360Config.IMPRESSIONS_METRIC).alias(DV360Config.IMPRESSIONS_METRIC),
        F.sum(DV360Config.CLICKS_METRIC).alias(DV360Config.CLICKS_METRIC),
        F.sum(DV360Config.CAMPAIGN_SPEND_METRIC).alias(DV360Config.CAMPAIGN_SPEND_METRIC),
        F.sum(DV360Config.MEASURABLE_IMPRESSIONS_METRIC).alias(DV360Config.MEASURABLE_IMPRESSIONS_METRIC),
        F.sum(DV360Config.VIEWABLE_IMPRESSIONS_METRIC).alias(DV360Config.VIEWABLE_IMPRESSIONS_METRIC)
    )


def get_sku_cluster_mapping(sku_cluster_mapping_table):
    """Get latest SKU to cluster mapping"""
    max_load_ts = sku_cluster_mapping_table.agg(F.max("load_ts")).collect()[0][0]
    return sku_cluster_mapping_table.where(F.col("load_ts") == F.lit(max_load_ts))


def create_skeleton(cluster_unpivot, weekly_dates_ref):
    """Create complete skeleton with all combinations"""
    # Get distinct combinations from unpivoted data
    skele_combinations = cluster_unpivot.select(
        "super_category_name",
        "unique_brand_name",
        "marketing_type",
        "marketing_channel",
        "marketing_sub_channel",
        "cluster_num",
        "metric"
    ).distinct()

    # Cross join with all weeks
    return weekly_dates_ref.crossJoin(skele_combinations)


def create_final_output(skeleton, cluster_unpivot, correlation_id):
    """Create final output by joining skeleton with data and filling missing values"""
    join_columns = [
        "week_start_dt",
        "super_category_name",
        "unique_brand_name",
        "marketing_type",
        "marketing_channel",
        "marketing_sub_channel",
        "cluster_num",
        "metric"
    ]

    skeleton_with_metrics = (
        skeleton
        .join(
            cluster_unpivot
            .withColumnRenamed("week_start_date", "week_start_dt"),
            join_columns,
            "left"
        )
    )

    return format_final_output(
        skeleton_with_metrics,
        correlation_id,
        week_column="week_start_dt"
    )


# --- Main Orchestration Function ---

def prepare_dv360_processed_data(
    spark: SparkSession,
    dv360_normalised_path: str,
    sku_cluster_mapping_path: str,
    weekly_dates_path: str,
    dv360_media_report_path: str,
    output_path: str,
    correlation_id: str,  # Added as per previous discussion and usage
) -> DataFrame:
    """
    Orchestrates the preparation of value index processed data by calling
    smaller, manageable functions. This function effectively replaces
    the original large method, enhancing readability and maintainability.
    The overall purpose of this script is for migrating the legacy system
    originally developed in DBT SQL into PySpark.

    :param spark: The SparkSession object.
    :param dv360_normalised_path: The S3 path for the dv360 normalised.
    :param sku_cluster_mapping_path: The S3 path for the SKU cluster mapping.
    :param weekly_dates_path: The S3 path for the weekly dates.
    :param dv360_media_report_path: The S3 path for the dv360 media report.
    :param output_path: The S3 path for the output processed data.
    :param correlation_id: A unique identifier for the current job run.
    :return: The final processed DataFrame.
    """

    # 1. Read all input data
    (dv360_normalised_df, sku_cluster_mapping_df,
     weekly_dates_df, dv360_media_report_df) = (
        read_s3_data(spark, dv360_normalised_path, sku_cluster_mapping_path,
                     weekly_dates_path, dv360_media_report_path))

    # Step 2: Get DV360 campaigns filtered by brand and super category
    dv360_campaigns = get_dv360_campaigns(dv360_normalised_df, sku_cluster_mapping_df)

    # Step 3: Explode campaigns to daily level
    daily_exploded = explode_campaigns_to_daily(dv360_campaigns)

    # Step 4: Aggregate to weekly level
    weekly_campaigns = get_weekly_campaigns(daily_exploded)

    # Step 5: Get unique brand campaigns
    unique_brand_campaigns = get_unique_brand_campaigns(weekly_campaigns)

    # Step 6: Get DV360 media data for relevant campaigns
    dv360_raw = get_dv360_media_data(dv360_media_report_df, weekly_campaigns)

    # Step 7: Aggregate DV360 metrics
    dv360_metrics = aggregate_dv360_metrics(dv360_raw)

    # Step 8: Join with SKU information
    metrics_with_sku = join_sku_info(dv360_metrics, unique_brand_campaigns)

    # Step 9: Calculate SKU counts per campaign
    sku_counts = calculate_sku_counts(metrics_with_sku, "jobbagid", "sku_no")

    # Step 10: Scale metrics to SKU level
    scaled_metrics = scale_metrics_to_sku_level(
        metrics_with_sku,
        sku_counts,
        campaign_id_col="jobbagid",
        metric_columns=DV360Config.METRIC_COLUMNS,
        select_columns=[
            "campaign_date",
            "jobbagid",
            "sku_no",
            "unique_brand_name",
            "super_category_name",
            DV360Config.IMPRESSIONS_METRIC,
            DV360Config.CLICKS_METRIC,
            DV360Config.CAMPAIGN_SPEND_METRIC,
            DV360Config.MEASURABLE_IMPRESSIONS_METRIC,
            DV360Config.VIEWABLE_IMPRESSIONS_METRIC,
        ]
    )

    # Step 11: Aggregate to weekly and SKU level
    weekly_metrics = aggregate_to_weekly_sku_level(scaled_metrics)

    # Step 12: Join with cluster info
    cluster_pre = join_cluster_info(
        weekly_metrics,
        sku_cluster_mapping_df,
        sku_col="sku_no",
        metric_columns=DV360Config.METRIC_COLUMNS,
    )

    # Step 14: Aggregate to cluster level
    cluster_metrics = aggregate_to_cluster_level(cluster_pre, DV360Config.METRIC_COLUMNS)

    # Step 15: Unpivot metrics
    cluster_unpivot = unpivot_metrics(
        cluster_metrics,
        DV360Config.METRIC_COLUMNS
    )

    # Step 16: Create skeleton
    skeleton = create_skeleton(cluster_unpivot, weekly_dates_df)

    # Step 17: Create final output
    final_result_df = create_final_output(skeleton, cluster_unpivot, correlation_id)

    # Write the final output to s3
    spark_s3_overwrite(output_path, final_result_df)

    return final_result_df


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare DV360 processed data for baseline pipeline.")
    parser.add_argument(
        "--dv360-normalised-path",
        type=str,
        required=True,
        help="The output S3 path for the dv360 normalised."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="S3 path for skull cluster mapping path."
    )
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="S3 path for weekly calendar reference data."
    )
    parser.add_argument(
        "--dv360-media-report-path",
        type=str,
        required=True,
        help="The output S3 path for the dv360 normalised."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The path in S3 to output the fb campaigns data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    _ = prepare_dv360_processed_data(
        spark=spark,
        dv360_normalised_path=known_args.dv360_normalised_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        weekly_dates_path=known_args.weekly_dates_path,
        dv360_media_report_path=known_args.dv360_media_report_path,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id)


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("Dv360ProcessedData").getOrCreate())
