from typing import List, Optional, Tuple
from pyspark.sql import functions as F, SparkSession, DataFrame

from spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data_helper import (
    aggregate_to_cluster_level,
    calculate_sku_counts,
    format_final_output,
    join_cluster_info,
    merge_pollen_and_dtp_data,
    scale_metrics_to_sku_level,
    unpivot_metrics,
)
from spark_pipeline.common.variables import BaselineProcessedData, DV360Config
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite
from spark_pipeline.utils.stdout_logger import StdOutLogger


logger = StdOutLogger()


# --- Helper Functions ---
def read_s3_data(
    spark: SparkSession,
    dv360_normalised_path: str,
    sku_cluster_mapping_path: str,
    dv360_media_report_path: str,
    historic_dv360_processed_data: str
) -> Tuple[DataFrame, DataFrame, DataFrame, DataFrame]:
    """
    Reads all necessary input DataFrames from S3 paths.

    :param spark: The SparkSession object.
    :param dv360_normalised_path: S3 path for dv360 normalised.
    :param sku_cluster_mapping_path: S3 path for SKU_CLUSTER_MAPPING.
    :param dv360_media_report_path: S3 path for dv360_media_report_path.
    :param historic_dv360_processed_data: The historic DV360 processed data path, in case we don't have enough data in pollen.
    :return: A tuple containing all loaded DataFrames.
    """
    dv360_normalised_df = (
        spark.read.parquet(dv360_normalised_path).select(
            "start_dt",
            "end_dt",
            "item_cd",
            "booking_id",
            "campaign_id"
        )
    )

    sku_cluster_mapping_df = load_parquet_dataset(
        spark,
        sku_cluster_mapping_path,
        'sku_cluster_mapping',
        slack_notifier=None,
        columns=BaselineProcessedData.sku_cluster_mapping_cols,
    )

    dv360_media_report_df = (
        spark.read.parquet(dv360_media_report_path)
        .withColumn("campaign_id", F.col("insertion_order_id"))  # Note the media report already has a campaign_id, so we overwrite this column as insertion_order_id is the third party ID which will join to the pollen data
        .select(
            "campaign_id",
            "campaign_date",
            DV360Config.MEASURABLE_IMPRESSIONS_METRIC,
            DV360Config.VIEWABLE_IMPRESSIONS_METRIC,
            DV360Config.CLICKS_METRIC,
            DV360Config.IMPRESSIONS_METRIC,
            "revenue"
        )
    )

    dv360_processed_data_dtp = (
        spark
        .read
        .parquet(historic_dv360_processed_data)
    )

    return (
        dv360_normalised_df,
        sku_cluster_mapping_df,
        dv360_media_report_df,
        dv360_processed_data_dtp
    )


def get_dv360_campaigns(
    dv360_normalised_df: DataFrame,
    sku_cluster_df: DataFrame
) -> DataFrame:
    """Get DV360 campaigns filtered to brand SKUs via inner join on sku cluster mapping"""
    dv360_campaigns = (
        dv360_normalised_df
        .join(
            sku_cluster_df,
            on="item_cd",
            how="inner"
        )
        .select(
            "start_dt",
            "end_dt",
            "item_cd",
            "booking_id",
            "campaign_id",
            "super_category_name",
            "unique_brand_name"
        ).distinct()
    )
    return dv360_campaigns


def get_dv360_media_data(
    dv360_media_report: DataFrame,
    dv360_required_campaigns: DataFrame
):
    """
    Filter DV360 media report data to the campaigns required by the baseline pipeline
    and aggregate campaign performance metrics to weekly grain.


    Args:
        dv360_media_report: Raw DV360 media report dataframe. Expected to contain all metrics
        dv360_required_campaigns: Dataframe of DV360 campaigns that are in scope
            for processing. Only the distinct campaign_id values are used here
            to filter the media report.

    Returns:
        DataFrame: A dataframe at campaign-week grain containing all the chosen metrics
    """

    dv360_metrics = (
        dv360_media_report
        # filter only campaigns in required list
        .join(
            dv360_required_campaigns.select("campaign_id").distinct(),
            on="campaign_id",
            how="inner"
        )
        # add truncated week column
        .withColumn("week_start_date", F.date_trunc("week", F.col("campaign_date")))
        .groupBy("campaign_id", "week_start_date")
        .agg(
            F.sum(DV360Config.IMPRESSIONS_METRIC).alias(DV360Config.IMPRESSIONS_METRIC),
            F.sum(DV360Config.CLICKS_METRIC).alias(DV360Config.CLICKS_METRIC),
            F.sum("revenue").alias(DV360Config.CAMPAIGN_SPEND_METRIC),
            F.sum(DV360Config.MEASURABLE_IMPRESSIONS_METRIC).alias(DV360Config.MEASURABLE_IMPRESSIONS_METRIC),
            F.sum(DV360Config.VIEWABLE_IMPRESSIONS_METRIC).alias(DV360Config.VIEWABLE_IMPRESSIONS_METRIC)
        )
        # final projection for clarity
        .select(
            "campaign_id",
            "week_start_date",
            DV360Config.IMPRESSIONS_METRIC,
            DV360Config.CLICKS_METRIC,
            DV360Config.CAMPAIGN_SPEND_METRIC,
            DV360Config.MEASURABLE_IMPRESSIONS_METRIC,
            DV360Config.VIEWABLE_IMPRESSIONS_METRIC
        )
    )
    return dv360_metrics


def build_dv360_metrics_jb_sku(
    dv360_metrics: DataFrame,
    dv360_required_campaigns: DataFrame,
) -> DataFrame:
    """
    Join DV360 metrics with required campaigns and SKU information, aggregating at the weekly level.
    super_category_name and unique_brand_name are sourced from dv360_required_campaigns
    """

    # Get the distinct campaigns
    dv360_required_campaigns_columns = (
        dv360_required_campaigns
        .select("booking_id", "campaign_id")
        .distinct()
    )

    # Join metrics with the required campaigns
    dv360_reqd_metrics = (
        dv360_metrics
        .join(
            dv360_required_campaigns_columns,
            on="campaign_id",
            how="inner"
        )
        .select(
            "booking_id",
            "campaign_id",
            "week_start_date",
            DV360Config.IMPRESSIONS_METRIC,
            DV360Config.CLICKS_METRIC,
            DV360Config.CAMPAIGN_SPEND_METRIC,
            DV360Config.MEASURABLE_IMPRESSIONS_METRIC,
            DV360Config.VIEWABLE_IMPRESSIONS_METRIC,
        )
    )

    # Aggregate at the weekly level
    dv360_reqd_metrics_jb = (
        dv360_reqd_metrics
        .groupBy("week_start_date", "booking_id")
        .agg(
            F.sum(DV360Config.IMPRESSIONS_METRIC).alias(DV360Config.IMPRESSIONS_METRIC),
            F.sum(DV360Config.CLICKS_METRIC).alias(DV360Config.CLICKS_METRIC),
            F.sum(DV360Config.CAMPAIGN_SPEND_METRIC).alias(DV360Config.CAMPAIGN_SPEND_METRIC),
            F.sum(DV360Config.MEASURABLE_IMPRESSIONS_METRIC).alias(DV360Config.MEASURABLE_IMPRESSIONS_METRIC),
            F.sum(DV360Config.VIEWABLE_IMPRESSIONS_METRIC).alias(DV360Config.VIEWABLE_IMPRESSIONS_METRIC)
        )
    )

    # Add SKU information
    dv360_metrics_jb_sku_pre = (
        dv360_reqd_metrics_jb
        .join(
            dv360_required_campaigns.select("booking_id", "item_cd"),
            on="booking_id",
            how="left"
        )
        .select(
            "week_start_date",
            "booking_id",
            DV360Config.IMPRESSIONS_METRIC,
            DV360Config.CLICKS_METRIC,
            DV360Config.CAMPAIGN_SPEND_METRIC,
            DV360Config.MEASURABLE_IMPRESSIONS_METRIC,
            DV360Config.VIEWABLE_IMPRESSIONS_METRIC,
            "item_cd"
        )
    )

    # Add brand and category information
    dv360_metrics_jb_sku = (
        dv360_metrics_jb_sku_pre
        .join(
            dv360_required_campaigns
            .select("item_cd", "super_category_name", "unique_brand_name")
            .distinct(),
            on="item_cd",
            how="left"
        )
        .select(
            "week_start_date",
            "booking_id",
            DV360Config.IMPRESSIONS_METRIC,
            DV360Config.CLICKS_METRIC,
            DV360Config.CAMPAIGN_SPEND_METRIC,
            DV360Config.MEASURABLE_IMPRESSIONS_METRIC,
            DV360Config.VIEWABLE_IMPRESSIONS_METRIC,
            "item_cd",
            "super_category_name",
            "unique_brand_name"
        )
    )

    return dv360_metrics_jb_sku


# --- Main Orchestration Function ---

def prepare_dv360_processed_data(
    spark: SparkSession,
    dv360_normalised_path: str,
    sku_cluster_mapping_path: str,
    dv360_media_report_path: str,
    historic_dv360_processed_data: str,
    output_path: str,
    correlation_id: str,
) -> None:
    """
    Orchestrates the preparation of value index processed data by calling
    smaller, manageable functions. This function effectively replaces
    the original large method, enhancing readability and maintainability.
    The overall purpose of this script is for migrating the legacy system
    originally developed in DBT SQL into PySpark.

    :param spark: The SparkSession object.
    :param dv360_normalised_path: The S3 path for the dv360 normalised.
    :param sku_cluster_mapping_path: The S3 path for the SKU cluster mapping.
    :param dv360_media_report_path: The S3 path for the dv360 media report.
    :param historic_dv360_processed_data: The historic DV360 processed data path, in case we don't have enough data in pollen.
    :param output_path: The S3 path for the output processed data.
    :param correlation_id: A unique identifier for the current job run.
    :return: None, the output is written to s3
    """

    # Read all input data
    (dv360_normalised_df, sku_cluster_mapping_df,
     dv360_media_report_df, dv360_processed_data_dtp) = (
        read_s3_data(spark, dv360_normalised_path,
                     sku_cluster_mapping_path, dv360_media_report_path,
                     historic_dv360_processed_data))

    # Get DV360 campaigns filtered to brand SKUs via sku_cluster_mapping
    dv360_required_campaigns = get_dv360_campaigns(dv360_normalised_df, sku_cluster_mapping_df)

    # Get DV360 media data for relevant campaigns and aggregate them
    dv360_metrics = get_dv360_media_data(dv360_media_report_df, dv360_required_campaigns)

    # Join with SKU information
    metrics_with_sku = build_dv360_metrics_jb_sku(dv360_metrics, dv360_required_campaigns)

    # Calculate SKU counts per campaign
    sku_counts = calculate_sku_counts(metrics_with_sku, "booking_id", "item_cd")

    # Scale metrics to SKU level
    scaled_metrics = scale_metrics_to_sku_level(
        metrics_with_sku,
        sku_counts,
        campaign_id_col="booking_id",
        metric_columns=DV360Config.METRIC_COLUMNS,
        select_columns=[
            "week_start_date",
            "booking_id",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "number_of_skus",
            DV360Config.IMPRESSIONS_METRIC,
            DV360Config.CLICKS_METRIC,
            DV360Config.CAMPAIGN_SPEND_METRIC,
            DV360Config.MEASURABLE_IMPRESSIONS_METRIC,
            DV360Config.VIEWABLE_IMPRESSIONS_METRIC,
        ],
    )

    # Join with cluster info
    dv360_campaign_cluster = join_cluster_info(
        scaled_metrics,
        sku_cluster_mapping_df,
        sku_col="item_cd",
        metric_columns=DV360Config.METRIC_COLUMNS,
    )

    # Aggregate to cluster level
    cluster_metrics = aggregate_to_cluster_level(dv360_campaign_cluster, DV360Config.METRIC_COLUMNS)

    # Unpivot metrics to create data in long format for final output
    cluster_unpivot = unpivot_metrics(
        cluster_metrics,
        DV360Config.METRIC_COLUMNS
    )

    # Creates final output
    final_result_df = format_final_output(
        cluster_unpivot,
        correlation_id,
        week_column="week_start_date"
    )

    # Merge pollen and historic dtp data to create final dv360 processed data
    final_dv360_processed_data = merge_pollen_and_dtp_data(final_result_df, dv360_processed_data_dtp)

    final_dv360_processed_data = final_dv360_processed_data.cache()
    logger.info(f"DV360_PROCESSED_POLLEN_DATA Count: {final_dv360_processed_data.count()}")
    logger.info(f"DV360_PROCESSED_DTP_DATA Count: {final_result_df.count()}")

    # Write output to S3
    spark_s3_overwrite(output_path, final_dv360_processed_data)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare DV360 Pollen processed data for baseline pipeline.")
    parser.add_argument(
        "--dv360-normalised-path",
        type=str,
        required=True,
        help="The output S3 path for the dv360 normalised."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="S3 path for SKU cluster mapping path."
    )
    parser.add_argument(
        "--dv360-media-report-path",
        type=str,
        required=True,
        help="The output S3 path for the dv360 media report."
    )
    parser.add_argument(
        "--historic-dv360-processed-data",
        type=str,
        required=True,
        help="The path in S3 for the historic dv360 processed data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The path in S3 to output the dv360 processed data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_dv360_processed_data(
        spark=spark,
        dv360_normalised_path=known_args.dv360_normalised_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        dv360_media_report_path=known_args.dv360_media_report_path,
        historic_dv360_processed_data=known_args.historic_dv360_processed_data,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id)


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("Dv360ProcessedData").getOrCreate())
