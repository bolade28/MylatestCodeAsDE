from typing import List, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData, InstoreConfig
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_instore_processed_data(
    spark: SparkSession,
    ie_product_path: str,
    ie_location_path: str,
    ie_campaign_filt_path: str,
    cust_by_location_path: str,
    media_instore_init_path: str,
    temp_unified_product_path: str,
    is_active_filter_path: str,
    sku_cluster_mapping_path: str,
    weekly_dates_path: str,
    start_date: str,
    end_date: str,
    output_path: str,
) -> None:
    """
    * Objective:
    - This script is used to create time series data for instore campaigns at cluster level and create feature
      metrics - instore_spends and exposed_customers.

    * Business Context:
    - Instore Ad data is processed to calculate key performance metrics.
    - SKU filtering is performed via an inner join with the SKU cluster mapping on item_cd,
      replacing the previous campaign_selection and unified_product filtering approach.
    """

    sku_cluster_df = load_parquet_dataset(
        spark,
        sku_cluster_mapping_path,
        'sku_cluster_mapping',
        slack_notifier=None,
        columns=BaselineProcessedData.sku_cluster_mapping_cols,
    )

    sku_cluster_brand_lookup = F.broadcast(
        sku_cluster_df.select('item_cd', 'super_category_name', 'unique_brand_name')
    )
    sku_cluster_cluster_lookup = F.broadcast(
        sku_cluster_df
        .select(
            'item_cd',
            'super_category_name',
            'unique_brand_name',
            'cluster_num'
        )
    )

    ie_campaign_filt = (
        spark
        .read
        .parquet(ie_campaign_filt_path)
        .filter(F.col('start_date').between(start_date, end_date))
        .filter(F.col('end_date') >= F.col('start_date'))  # guard against incorrectly setup campaigns
    )

    ie_product = (
        spark
        .read
        .parquet(ie_product_path)
        .select('master_campaign_id', 'product_key')
    )

    temp_unified_product = (
        spark
        .read
        .parquet(temp_unified_product_path)
        .select('product_key', 'item_cd')
    )

    campaign_products = (
        ie_campaign_filt
        .join(ie_product, on='master_campaign_id', how='left')
        .select(
            'master_campaign_id',
            'start_date',
            'end_date',
            'media_cost',
            'npd',
            'product_key'
        )
    )

    campaign_items = (
        campaign_products
        .join(temp_unified_product, on='product_key', how='left')
        .select(
            'master_campaign_id',
            'start_date',
            'end_date',
            'media_cost',
            'npd',
            'product_key',
            'item_cd'
        )
    )

    # Filter to brand skus
    instore_brand_skus = (
        campaign_items
        .join(sku_cluster_brand_lookup, on='item_cd', how='inner')
        .select(
            'master_campaign_id',
            'start_date',
            'end_date',
            'media_cost',
            'npd',
            'product_key',
            'item_cd',
            'super_category_name',
            'unique_brand_name'
        )
    )

    is_active_filter = (
        spark
        .read
        .parquet(is_active_filter_path)
        .withColumnRenamed('media_no', 'active_media_no')
        .select('active_media_no')
        .distinct()
    )

    media_instore_init = (
        spark
        .read
        .parquet(media_instore_init_path)
        .select('master_campaign_id', 'targeted_id', 'media_no')
    )

    media_instore = (
        media_instore_init
        .join(is_active_filter, F.expr('media_no % 100 = active_media_no'), 'inner')
        .select(
            'master_campaign_id',
            'targeted_id',
            'media_no'
        )
        .distinct()
    )

    instore_campaign_media = (
        instore_brand_skus
        .join(media_instore, on='master_campaign_id', how='inner')
        .select(
            'start_date',
            'end_date',
            'media_cost',
            'npd',
            'unique_brand_name',
            'product_key',
            'item_cd',
            'super_category_name',
            'master_campaign_id',
            'targeted_id',
            'media_no'
        )
        .distinct()
    )

    ie_location = (
        spark
        .read
        .parquet(ie_location_path)
        .select('master_campaign_id', 'media_no', 'location_key')
    )

    instore_campaign_locations = (
        instore_campaign_media
        .join(ie_location, on=['master_campaign_id', 'media_no'], how='inner')
        .select(
            'start_date',
            'end_date',
            'media_cost',
            'npd',
            'unique_brand_name',
            'product_key',
            'item_cd',
            'super_category_name',
            'master_campaign_id',
            'targeted_id',
            'media_no',
            'location_key'
        )
    )

    instore_campaigns_with_clusters = (
        instore_campaign_locations
        .join(
            sku_cluster_cluster_lookup,
            on=['item_cd', 'unique_brand_name', 'super_category_name'],
            how='left'
        )
        .filter(F.col('media_cost') != 0)
        .select(
            'master_campaign_id',
            'start_date',
            'end_date',
            'media_cost',
            'npd',
            'unique_brand_name',
            'product_key',
            'item_cd',
            'super_category_name',
            'targeted_id',
            'media_no',
            'location_key',
            'cluster_num'
        )
        .distinct()
    )

    instore_sku_campaigns = (
        instore_campaigns_with_clusters
        .select(
            'master_campaign_id',
            'start_date',
            'end_date',
            'media_cost',
            'product_key',
            'item_cd',
            'super_category_name',
            'unique_brand_name',
            'cluster_num'
        ).distinct()
    )

    instore_campaign_durations = (
        instore_sku_campaigns
        .withColumn('campaign_days', F.datediff(F.col('end_date'), F.col('start_date')) + F.lit(1))
        .select(
            'master_campaign_id',
            'start_date',
            'end_date',
            'media_cost',
            'super_category_name',
            'unique_brand_name',
            'item_cd',
            'cluster_num',
            'campaign_days'
        ).distinct()
    )

    campaign_sku_counts = (
        instore_campaign_durations.groupBy('master_campaign_id').agg(F.count_distinct('item_cd').alias('number_skus'))
    )

    instore_split_media_costs = (
        instore_campaign_durations
        .join(campaign_sku_counts, on='master_campaign_id', how='left')
        .withColumn('split_media_cost', F.col('media_cost') / F.col('number_skus'))
        .select(
            'master_campaign_id',
            'start_date',
            'end_date',
            'media_cost',
            'super_category_name',
            'unique_brand_name',
            'item_cd',
            'cluster_num',
            'campaign_days',
            'number_skus',
            'split_media_cost'
        )
    )

    media_costs_daily = (
        instore_split_media_costs
        .withColumn('media_cost_per_day', F.col('split_media_cost') / F.col('campaign_days'))
        .select(
            'master_campaign_id',
            'start_date',
            'end_date',
            'media_cost',
            'super_category_name',
            'unique_brand_name',
            'item_cd',
            'campaign_days',
            'number_skus',
            'split_media_cost',
            'cluster_num',
            'media_cost_per_day'
        )
    )

    media_costs_daily_exploded_init = (
        media_costs_daily
        .select(
            'master_campaign_id',
            'super_category_name',
            'unique_brand_name',
            'item_cd',
            'cluster_num',
            'media_cost_per_day',
            F.explode(
                F.sequence(
                    F.to_date('start_date'),
                    F.to_date('end_date'),
                    F.expr("INTERVAL 1 DAY")
                )
            ).alias('date_')
        )
    )

    media_costs_daily_exploded = (
        media_costs_daily_exploded_init
        .filter((F.to_date('date_') >= F.to_date(F.lit(start_date))) & (F.to_date('date_') <= F.to_date(F.lit(end_date))))
    )

    cust_by_location = (
        spark
        .read
        .parquet(cust_by_location_path)
    )
    weekly_media_costs = (
        media_costs_daily_exploded
        .withColumn('week_start_date', F.date_trunc('week', F.col('date_')))
        .groupBy(
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'master_campaign_id',
            'week_start_date'
        ).agg(F.sum('media_cost_per_day').alias('total_media_cost'))
    )

    temp_date_dataset = (
        spark
        .read
        .parquet(weekly_dates_path)
        .withColumnRenamed('week_start_dt', 'week_start_date')
        .select('week_start_date')
    )

    unique_skele = (
        weekly_media_costs
        .select(
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'master_campaign_id'
        ).distinct()
    )

    skele_weekly = (
        temp_date_dataset
        .filter(F.col('week_start_date').between(start_date, end_date))
        .select('week_start_date')
        .distinct()
    )

    final_skele = skele_weekly.crossJoin(unique_skele)

    media_cost_final = (
        final_skele
        .join(
            weekly_media_costs,
            on=['week_start_date', 'super_category_name', 'unique_brand_name', 'cluster_num', 'master_campaign_id'],
            how='left'
        )
        .withColumn('total_media_cost', F.coalesce(F.col('total_media_cost'), F.lit(0)))
        .select(
            'week_start_date',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'master_campaign_id',
            'total_media_cost'
        )
    )

    media_cost_final_unique_brand = (
        media_cost_final
        .groupBy(
            'week_start_date',
            'super_category_name',
            'unique_brand_name',
            'cluster_num'
        )
        .agg(F.sum('total_media_cost').alias('total_media_cost'))
    )

    campaign_location_unique_brand_strategic = (
        instore_campaigns_with_clusters.select(
            'master_campaign_id',
            'start_date',
            'end_date',
            'location_key',
            'super_category_name',
            'unique_brand_name',
            'cluster_num'
        ).distinct()
    )

    location_exploded_unique_brand_strategic_init = (
        campaign_location_unique_brand_strategic
        .select(
            'location_key',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            F.explode(
                F.sequence(
                    F.to_date('start_date'),
                    F.to_date('end_date'),
                    F.expr("INTERVAL 1 DAY")
                )
            ).alias('date_')
        )
    )

    location_exploded_unique_brand_strategic = (
        location_exploded_unique_brand_strategic_init
        .filter((F.to_date('date_') >= F.to_date(F.lit(start_date))) & (F.to_date('date_') <= F.to_date(F.lit(end_date))))
        .distinct()
    )

    location_exploded_unique_brand_strategic_weekly = (
        location_exploded_unique_brand_strategic
        .withColumn('week_start_date', F.to_date(F.date_trunc('week', 'date_')))
        .select(
            'location_key',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'week_start_date'
        ).distinct()
    )

    cust_by_location_weekly = (
        cust_by_location
        .withColumn('week_start_date', F.to_date(F.col('date_')))
        .withColumnRenamed('store_cd', 'location_key')
        .select(
            'week_start_date',
            'location_key',
            'distinct_customers'
        )

    )

    weekly_exposed_custs = (
        location_exploded_unique_brand_strategic_weekly
        .join(
            cust_by_location_weekly,
            on=['week_start_date', 'location_key'],
            how='inner'
        )
        .groupBy(
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'week_start_date'
        )
        .agg(F.sum('distinct_customers').alias('exposed_customers'))
    )

    weekly_brand_metrics = (
        media_cost_final_unique_brand
        .join(
            weekly_exposed_custs,
            on=['week_start_date', 'super_category_name', 'unique_brand_name', 'cluster_num'],
            how='left'
        )
        .withColumn('exposed_customers', F.coalesce(F.col('exposed_customers'), F.lit(0)))
        .select(
            'week_start_date',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'total_media_cost',
            'exposed_customers'
        )
    )

    instore_hierarchy_metrics = (
        weekly_brand_metrics
        .select(
            'week_start_date',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'total_media_cost',
            'exposed_customers'
        )
    )

    concatenated_field = F.concat('week_start_date', 'super_category_name', 'unique_brand_name', 'cluster_num')

    instore_process_data_conc = (
        instore_hierarchy_metrics
        .filter(F.col('cluster_num').isNotNull())
        .withColumn('ip_concatenated_fields', concatenated_field)
        .withColumn('total_media_cost', F.col('total_media_cost').cast(T.DecimalType(10)))
        .withColumn('exposed_customers', F.col('exposed_customers').cast(T.DecimalType(10)))
        .select(
            'ip_concatenated_fields',
            'total_media_cost',
            'exposed_customers'
        )
    )

    instore_processed_data_unpivot_init = (
        instore_process_data_conc
        .select(
            'ip_concatenated_fields',
            InstoreConfig.TOTAL_MEDIA_COST_METRIC,
            InstoreConfig.EXPOSED_CUSTOMERS_METRIC
        )
        .unpivot(
            F.col('ip_concatenated_fields'),
            InstoreConfig.METRIC_COLUMNS,
            'metric',
            'value'
        )
    )

    instore_processed_data = (
        instore_hierarchy_metrics
        .withColumn('ip_concatenated_fields', concatenated_field)
        .join(instore_processed_data_unpivot_init, on='ip_concatenated_fields', how='inner')
        .select(
            F.to_date('week_start_date').alias('week_start_dt'),
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            F.lit(InstoreConfig.MARKETING_TYPE).alias('marketing_type_name'),
            F.lit(InstoreConfig.MARKETING_CHANNEL).alias('marketing_channel_name'),
            F.lit(InstoreConfig.MARKETING_SUB_CHANNEL).alias('marketing_sub_channel_name'),
            F.upper(F.col('metric')).alias('metric_name'),
            F.col('value').alias('metric_value')
        )
    )

    # Write the final output to s3
    spark_s3_overwrite(output_path, instore_processed_data)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(
        description="Prepare Meta processed data for baseline pipeline.")
    parser.add_argument("--ie-product-path", type=str, required=True, help="The S3 path for the facebook campaign normalize table.")
    parser.add_argument("--ie-location-path", type=str, required=True, help="The S3 path for the facebook campaign normalize table.")
    parser.add_argument("--ie-campaign-filt-path", type=str, required=True, help="The S3 path for the facebook campaign normalize table.")
    parser.add_argument("--cust-by-location-path", type=str, required=True, help="The S3 path for the facebook campaign normalize table.")
    parser.add_argument("--media-instore-init-path", type=str, required=True, help="The S3 path for the facebook campaign normalize table.")
    parser.add_argument("--temp-unified-product-path", type=str, required=True, help="The S3 path for the facebook campaign normalize table.")
    parser.add_argument("--is-active-filter-path", type=str, required=True, help="The S3 path for the facebook campaign normalize table.")
    parser.add_argument("--sku-cluster-mapping-path", type=str, required=True, help="The S3 path for the sku cluster mapping table.")
    parser.add_argument("--weekly-dates-path", type=str, required=True, help="The S3 path for the weekly dates mapping table.")
    parser.add_argument("--start-date", type=str, required=True, help="This is model start date")
    parser.add_argument("--end-date", type=str, required=True, help="This is model end date")
    parser.add_argument("--output-path", type=str, required=True, help="The S3 path for the output of campaign_product_type.")

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_instore_processed_data(
        spark=spark,
        ie_product_path=known_args.ie_product_path,
        ie_location_path=known_args.ie_location_path,
        ie_campaign_filt_path=known_args.ie_campaign_filt_path,
        cust_by_location_path=known_args.cust_by_location_path,
        media_instore_init_path=known_args.media_instore_init_path,
        temp_unified_product_path=known_args.temp_unified_product_path,
        is_active_filter_path=known_args.is_active_filter_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        weekly_dates_path=known_args.weekly_dates_path,
        start_date=known_args.start_date,
        end_date=known_args.end_date,
        output_path=known_args.output_path,
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder.appName("InstoreProcessedData").getOrCreate())
