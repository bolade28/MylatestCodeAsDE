from typing import Any, Dict, List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

from spark_pipeline.baseline_processed_data.processed_data_utils import (
    build_cluster_date_skeleton,
    load_shared_processed_data_sources,
)
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def _load_s3_data(
    spark: SparkSession,
    advertise_request_realised_path: str,
    sku_cluster_mapping_path: str,
    weekly_dates_path: str,
    config: Dict[str, Any],
) -> Tuple[DataFrame, DataFrame, DataFrame]:
    """
    Load all s3 datasets required for Citrus processing.

    Args:
        spark: Active Spark session.
        advertise_request_realised_path: Path to the realised Citrus advertising request dataset.
        sku_cluster_mapping_path: Path to the SKU cluster mapping.
        weekly_dates_path: Path to the weekly date skeleton table.
        config: Citrus configuration values.

    Returns:
        A tuple containing the realised Citrus request data, SKU cluster mapping,
        and weekly dates DataFrames.
    """

    # Reads key metrics we want to use for baseline
    ad_request_realised_df = (
        spark.read.parquet(advertise_request_realised_path)
        .withColumn(
            "item_cd",
            F.lower(
                # normalise item code by stripping leading zero padding
                F.regexp_replace(F.col(config["item_id_column"]).cast("string"), r"^[0]*", "")  # ToDo: see NUP-22857
            )
        )
        .select(
            "ingressed_at_dt",
            *config["metric_column_mappings"].keys(),
            "item_cd"
        )
    )

    sku_cluster_mapping_df, weekly_dates_df = load_shared_processed_data_sources(
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        weekly_dates_path=weekly_dates_path,
        spark=spark,
    )

    return ad_request_realised_df, sku_cluster_mapping_df, weekly_dates_df


def _build_citrus_item_cluster_data(
    ad_request_realised_df: DataFrame,
    sku_cluster_mapping_df: DataFrame,
    config: Dict[str, Any],
) -> DataFrame:
    """
    Filter realised Citrus request data to the brand skus and bring in product attributes

    Args:
        ad_request_realised_df: Realised Citrus request data with metric data
        sku_cluster_mapping_df: SKU-to-cluster mapping for in-scope brand SKU, with product attributes
        config: Citrus configuration values.

    Returns:
        Realised Citrus request data enriched with cluster attributes.
    """
    return (
        ad_request_realised_df
        .join(F.broadcast(sku_cluster_mapping_df), on="item_cd", how="inner")
        .select(
            "item_cd",
            "unique_brand_name",
            "cluster_num",
            "super_category_name",
            "ingressed_at_dt",
            *config["metric_column_mappings"].keys(),
        )
    )


def _aggregate_weekly_citrus_metrics(
    citrus_item_cluster_df: DataFrame,
    config: Dict[str, Any],
) -> DataFrame:
    """
    Aggregate realised Citrus metrics to weekly brand-cluster level, mapping the real columns to the metric names we define in the config

    Args:
        citrus_item_cluster_df: Realised Citrus request data enriched with cluster attributes.
        config: Citrus configuration values.

    Returns:
        Weekly Citrus metrics at super-category, brand, and cluster granularity.
    """
    return (
        citrus_item_cluster_df
        .groupBy(
            "unique_brand_name",
            "cluster_num",
            "super_category_name",
            F.to_date(F.date_trunc("week", "ingressed_at_dt")).alias("week_start_date"),
        )
        .agg(
            *[
                F.sum(source_col).alias(target_col)
                for source_col, target_col in config["metric_column_mappings"].items()
            ]
        )
    )


def _build_citrus_metric_grid(
    weekly_citrus_metrics_df: DataFrame,
    weekly_dates_df: DataFrame,
    config: Dict[str, Any],
) -> DataFrame:
    """
    Create the full Citrus cluster-by-week grid and zero-fill missing metric values.

    Args:
        weekly_citrus_metrics_df: Weekly Citrus metrics at cluster level.
        weekly_dates_df: Weekly date skeleton covering the modelling period.
        config: Citrus configuration values.


    Returns:
        Full cluster-by-week Citrus dataset with zero-filled metric columns.
    """
    citrus_skeleton_df = build_cluster_date_skeleton(
        weekly_dates_df=weekly_dates_df,
        cluster_attrs_df=weekly_citrus_metrics_df,
    )

    return (
        citrus_skeleton_df
        .join(
            weekly_citrus_metrics_df,
            on=["week_start_date", "super_category_name", "unique_brand_name", "cluster_num"],
            how="left",
        )
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            *[
                F.coalesce(F.col(metric_col), F.lit(0)).alias(metric_col)
                for metric_col in config["metric_columns"]
            ],
        )
        .withColumn("marketing_type_name", F.lit(config["marketing_type_name"]))
        .withColumn("marketing_channel_name", F.lit(config["marketing_channel_name"]))
        .withColumn("marketing_sub_channel_name", F.lit(config["marketing_sub_channel_name"]))
    )


def _unpivot_citrus_metrics(
    citrus_metric_grid_df: DataFrame,
    config: Dict[str, Any],
) -> DataFrame:
    """
    Unpivot Citrus metric columns into metric rows.

    Args:
        citrus_metric_grid_df: Full cluster-by-week Citrus dataset.
        config: Citrus configuration values.

    Returns:
        Unpivoted Citrus metric rows.
    """
    return (
        citrus_metric_grid_df
        .filter(F.col("cluster_num").isNotNull())
        .unpivot(
            [
                "week_start_date",
                "super_category_name",
                "unique_brand_name",
                "cluster_num",
                "marketing_type_name",
                "marketing_channel_name",
                "marketing_sub_channel_name",
            ],
            config["metric_columns"],
            "metric",
            "value",
        )
    )


def _format_citrus_output(citrus_unpivoted_df: DataFrame) -> DataFrame:
    """
    Apply the final formatting required for baseline processed data scripts.
    Creating the final output for the citrus metric.

    Args:
        citrus_unpivoted_df: Unpivoted Citrus metric rows.

    Returns:
        Final Citrus processed dataset ready to be written.
    """
    return citrus_unpivoted_df.select(
        F.col("week_start_date").alias("week_start_dt"),
        "super_category_name",
        "unique_brand_name",
        "cluster_num",
        "marketing_type_name",
        "marketing_channel_name",
        "marketing_sub_channel_name",
        F.upper(F.col("metric")).alias("metric_name"),
        F.col("value").cast(T.DecimalType(38, 0)).alias("metric_value"),
    )


def prepare_citrus_processed_data(
    spark: SparkSession,
    advertise_request_realised_path: str,
    sku_cluster_mapping_path: str,
    weekly_dates_path: str,
    output_path: str,
) -> None:
    """
    Generate time series data for Citrus onsite metrics at the SKU cluster level.

    Business Context:
    - Citrus data captures onsite retail media performance such as revenue, spend, impressions, clicks,
      conversions, and unit sales.
    - These metrics are used as baseline marketing features to help explain changes in sales performance.

    Args:
        spark: Active Spark session.
        advertise_request_realised_path: Path to the realised Citrus advertising request dataset.
        sku_cluster_mapping_path: Path to the SKU cluster mapping.
        weekly_dates_path: Path to the weekly date skeleton table.
        output_path: Output location for the processed Citrus dataset.

    Returns:
        None -> The function writes the processed Citrus dataset to the specified output path.
    """
    config = BaselineProcessedData.citrus_processed_data_config

    ad_request_realised_df, sku_cluster_mapping_df, weekly_dates_df = _load_s3_data(
        spark=spark,
        advertise_request_realised_path=advertise_request_realised_path,
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        weekly_dates_path=weekly_dates_path,
        config=config,
    )

    citrus_item_cluster_df = _build_citrus_item_cluster_data(
        ad_request_realised_df,
        sku_cluster_mapping_df,
        config,
    )
    weekly_citrus_metrics_df = _aggregate_weekly_citrus_metrics(citrus_item_cluster_df, config)
    citrus_metric_grid_df = _build_citrus_metric_grid(
        weekly_citrus_metrics_df,
        weekly_dates_df,
        config,
    )
    citrus_unpivoted_df = _unpivot_citrus_metrics(citrus_metric_grid_df, config)
    citrus_processed_data_df = _format_citrus_output(citrus_unpivoted_df)

    spark_s3_overwrite(output_path, citrus_processed_data_df)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Citrus processed data for baseline pipeline.")

    parser.add_argument(
        "--advertise-request-realised-path",
        type=str,
        required=True,
        help="The S3 path for the realised Citrus advertising request table."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="The S3 path for the sku cluster mapping table."
    )
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="The S3 path for the weekly dates mapping table."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The S3 path for the output of Citrus processed data."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_citrus_processed_data(
        spark=spark,
        advertise_request_realised_path=known_args.advertise_request_realised_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        weekly_dates_path=known_args.weekly_dates_path,
        output_path=known_args.output_path,
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder.appName("CitrusProcessedData").getOrCreate())
