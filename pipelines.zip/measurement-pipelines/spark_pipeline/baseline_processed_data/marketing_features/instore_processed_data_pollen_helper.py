from typing import Dict
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F, types as T

from spark_pipeline.common.variables import BaselineProcessedData, InstoreConfig
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset


def read_instore_pollen_s3_inputs(
    spark: SparkSession,
    campaign_booking_media_channel_path: str,
    cust_by_location_path: str,
    sku_cluster_mapping_path: str
) -> Dict[str, DataFrame]:
    """
    Read and minimally prepare source inputs used by the instore pollen processed data pipeline.

    Args:
        spark (SparkSession): Spark session.
        campaign_booking_media_channel_path (str): Path to campaign booking media channel parquet.
        cust_by_location_path (str): Path to customer by location parquet.
        sku_cluster_mapping_path (str): Path to SKU cluster mapping parquet.

    Returns:
        Dict[str, DataFrame]: Dictionary of loaded DataFrames.
    """
    campaign_booking_media_channel_br = (
        spark.read.parquet(campaign_booking_media_channel_path)
        .select(
            "booking_id",
            "campaign_id",
            "channel_type",
            "booking_status",
            "media_provider",
            "media_business_group",
            "media_spend_amt",
            "booking_media_live_start_dt",
            "booking_media_live_end_dt",
            "item_cd_list",
            "store_cd_list"
        )
    )

    cust_by_location = spark.read.parquet(cust_by_location_path)

    sku_cluster_mapping = load_parquet_dataset(
        spark,
        sku_cluster_mapping_path,
        'sku_cluster_mapping',
        slack_notifier=None,
        columns=BaselineProcessedData.sku_cluster_mapping_cols,
    )

    return {
        "campaign_booking_media_channel_br": campaign_booking_media_channel_br,
        "cust_by_location": cust_by_location,
        "sku_cluster_mapping": sku_cluster_mapping
    }


def build_instore_campaign_bookings(
    campaign_booking_media_channel_br: DataFrame,
    start_date: str,
    end_date: str,
) -> DataFrame:
    """
    Filter pollen campaign bookings to only include valid in-store campaigns,
    parse item_cd (sku) and store_cd information relating to the campaign from a string to array representation,
    to prepare for later processing.

    Args:
        campaign_booking_media_channel_br (DataFrame): Campaign bookings data, containing all pollen booking data including targeted sku's (item_cd) we want to process and store_cd information
        start_date (str): Start date (YYYY-MM-DD), this is the start of the modelling period we want to measure
        end_date (str): End date (YYYY-MM-DD), this is the end of the modelling period we want to measure, we pass this value into the pipeline

    Returns:
        DataFrame: Filtered and processed campaign bookings DataFrame.
    """
    # ToDo :: Use media hierarchy filters to get only instore campaigns instead of the current config values
    return (
        campaign_booking_media_channel_br
        # Parse the item_cd_list and store_cd_list from JSON to array data so we process them later
        .withColumn("item_cd_list", F.from_json(F.col("item_cd_list"), ProcessedData.item_schema))
        .withColumn("store_cd_list", F.from_json(F.col("store_cd_list"), T.ArrayType(T.StringType())))
        .filter(
            (F.lower(F.col("channel_type")) == InstoreConfig.CHANNEL_TYPE)
            & (F.lower(F.col("media_provider")) != InstoreConfig.MEDIA_PROVIDER)
            & (F.lower(F.col("booking_status")).isin(InstoreConfig.BOOKING_STATUS))
            & (F.lower(F.col("media_business_group")).like(InstoreConfig.MEDIA_BUSINESS_GROUP_FILTER))
            & (F.size(F.col("item_cd_list")) > 0)
            & (~F.col("campaign_id").isin("~~", "-1"))
            & (F.col("booking_media_live_start_dt").between(start_date, end_date))
            & (F.col("booking_media_live_end_dt").between(start_date, end_date))
        )
        .withColumnRenamed("campaign_id", "master_campaign_id")
        .withColumn("campaign_start_date", F.to_date("booking_media_live_start_dt"))
        .withColumn("campaign_end_date", F.to_date("booking_media_live_end_dt"))
        .withColumn(
            "invalid_date_range",
            (F.col("campaign_start_date").isNull())
            | (F.col("campaign_end_date").isNull())
            | (F.col("campaign_start_date") > F.col("campaign_end_date")),
        )
        .select(
            "booking_id",
            "master_campaign_id",
            "media_spend_amt",
            "campaign_start_date",
            "campaign_end_date",
            "invalid_date_range",
            "store_cd_list",
            "item_cd_list",
        )
        .distinct()
    )


def explode_campaign_stores(
    campaign_bookings: DataFrame,
) -> DataFrame:
    """
    Explode store lists into one row per (booking, campaign, store).

    Args:
        campaign_bookings (DataFrame): DataFrame containing booking_id, master_campaign_id, store_cd_list.

    Returns:
        DataFrame: DataFrame with columns booking_id, master_campaign_id, location_key.
    """
    return (
        campaign_bookings
        .withColumn("location_key", F.explode("store_cd_list"))
        .select("booking_id", "master_campaign_id", "location_key")
    )


def explode_campaign_items(
    campaign_bookings: DataFrame,
) -> DataFrame:
    """
    Explode item list into one row per (booking, campaign, item_cd).

    Args:
        campaign_bookings (DataFrame): DataFrame containing booking_id, master_campaign_id, item_cd_list.

    Returns:
        DataFrame: DataFrame with columns booking_id, master_campaign_id, item_cd.
    """
    return (
        campaign_bookings
        .withColumn("item", F.explode("item_cd_list"))
        .withColumn("item_cd", F.col("item.skuId").cast("string"))
        .select("booking_id", "master_campaign_id", "item_cd")
    )


def build_instore_campaigns(
    campaign_bookings: DataFrame,
    campaign_items: DataFrame,
    store_cd_flattened: DataFrame,
) -> DataFrame:
    """
    Bring bookings down to sku (item) X store level.
    Brand filtering is handled upstream via the inner join with sku_cluster_mapping on item_cd.

    Args:
        campaign_bookings (DataFrame): Bookings DataFrame.
        campaign_items (DataFrame): Campaign items DataFrame with brand/cat/cluster from sku_cluster_df.
        store_cd_flattened (DataFrame): Flattened DataFrame containing store cds per campaign.

    Returns:
        DataFrame: instore campaign data at the sku x store granularity.
    """

    instore_campaigns = (
        campaign_bookings
        .join(
            campaign_items,
            on=["booking_id", "master_campaign_id"],
            how="inner"
        )
        .join(
            store_cd_flattened,
            on=["booking_id", "master_campaign_id"],
            how="inner"
        )
        .select(
            "master_campaign_id",
            "media_spend_amt",
            "campaign_start_date",
            "campaign_end_date",
            "invalid_date_range",
            "item_cd",
            "super_category_name",
            "unique_brand_name",
            "location_key"
        )
        .filter(F.col("unique_brand_name").isNotNull())
    )

    return instore_campaigns


def build_campaign_durations_sku_level(
    instore_campaigns_enriched: DataFrame,
) -> DataFrame:
    """
    Compute campaign duration (days) for the campaign period, which will then be used to get metrics at the daily level downstream.

    Args:
        instore_campaigns_enriched (DataFrame): DataFrame containing all instore campaigns at the store X item level.

    Returns:
        DataFrame: Instore campaign data with additional campaign days column.
    """
    return (
        instore_campaigns_enriched
        .withColumn(
            "campaign_days",
            F.datediff(F.col("campaign_end_date"), F.col("campaign_start_date")) + F.lit(1),
        )
        .select(
            "master_campaign_id",
            "campaign_start_date",
            "campaign_end_date",
            "media_cost",
            "super_category_name",
            "unique_brand_name",
            "item_cd",
            "campaign_days",
        )
        .distinct()
    )


def split_media_cost_across_skus(
    campaign_durations_sku_level: DataFrame,
) -> DataFrame:
    """
    Aggregate number of SKUs per campaign, and then use that to split campaign media cost evenly across skus per campaign.

    Args:
        campaign_durations_sku_level (DataFrame): Instore campaign data with campaign durations at the sku X store level.

    Returns:
        DataFrame: DataFrame with split media cost per sku.
    """
    instore_num_skus = (
        campaign_durations_sku_level
        .groupBy("master_campaign_id")
        .agg(F.count_distinct("item_cd").alias("number_skus"))
    )

    return (
        campaign_durations_sku_level
        .join(instore_num_skus, "master_campaign_id", "left")
        .withColumn("split_media_cost", F.col("media_cost") / F.col("number_skus"))
        .select(
            "master_campaign_id",
            "campaign_start_date",
            "campaign_end_date",
            "media_cost",
            "split_media_cost",
            "super_category_name",
            "unique_brand_name",
            "item_cd",
            "number_skus",
            "campaign_days",
        )
    )


def compute_daily_media_costs(
    instore_split: DataFrame,
    sku_cluster_mapping: DataFrame,
    start_date: str,
    end_date: str,
) -> DataFrame:
    """
    Add cluster number to support the current pipeline as it expects cluster num downstream.
    Compute per-day media cost to use in the metric total_media_cost, explode to daily time series and filter to date window.

    Args:
        instore_split (DataFrame): DataFrame with split media cost per SKU.
        sku_cluster_mapping (DataFrame): SKU cluster mapping DataFrame.
        start_date (str): Inclusive start date (YYYY-MM-DD).
        end_date (str): Inclusive end date (YYYY-MM-DD).

    Returns:
        DataFrame: Daily media cost DataFrame.
    """

    media_costs_daily = (
        instore_split
        .join(
            F.broadcast(sku_cluster_mapping),
            on=['item_cd', 'unique_brand_name', 'super_category_name'],
            how="left"
        )
        .withColumn('media_cost_per_day', F.coalesce(F.col('split_media_cost') / F.col('campaign_days'), F.lit(0)))
        .select(
            'master_campaign_id',
            'super_category_name',
            'unique_brand_name',
            'item_cd',
            'cluster_num',
            'media_cost_per_day',
            F.explode(
                F.sequence(
                    F.to_date('campaign_start_date'),
                    F.to_date('campaign_end_date'),
                    F.expr("INTERVAL 1 DAY")
                )
            ).alias('date_')
        )
    )

    return (
        media_costs_daily
        .filter(
            (F.to_date("date_") >= F.to_date(F.lit(start_date)))
            & (F.to_date("date_") <= F.to_date(F.lit(end_date)))
        )
    )


def aggregate_daily_costs_to_weekly(
    media_costs_daily_exploded: DataFrame,
) -> DataFrame:
    """
    Aggregate daily costs to weekly total media cost.

    Args:
        media_costs_daily_exploded (DataFrame): Daily exploded media costs DataFrame.

    Returns:
        DataFrame: Weekly aggregated media cost DataFrame.
    """
    weekly_media_costs = (
        media_costs_daily_exploded
        .withColumn("week_start_date", F.date_trunc("week", F.col("date_")))
        .groupBy(
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "master_campaign_id",
            "week_start_date",
        )
        .agg(F.sum("media_cost_per_day").alias("total_media_cost"))
    )

    return (
        weekly_media_costs
        .groupBy("week_start_date", "super_category_name", "unique_brand_name", "cluster_num")
        .agg(F.sum("total_media_cost").alias("total_media_cost"))
    )


def build_weekly_exposed_customers(
    instore_campaigns_enriched: DataFrame,
    cust_by_location: DataFrame,
    start_date: str,
    end_date: str,
) -> DataFrame:
    """
    Brings store cd data to a weekly level,
    then joins to the cutomer by location data to compute the number of customers exposed to an instore campaign each week,
    by brand/super category/cluster.

    Args:
        instore_campaigns_enriched (DataFrame): Instore campaigns.
        cust_by_location (DataFrame): Pre-aggregated dataset containing distinct customer counts by store.
        start_date (str): Inclusive start date (YYYY-MM-DD).
        end_date (str): Inclusive end date (YYYY-MM-DD).

    Returns:
        DataFrame: Weekly exposed customers DataFrame.
    """
    location_daily = (
        instore_campaigns_enriched
        .select(
            "master_campaign_id",
            "campaign_start_date",
            "campaign_end_date",
            "invalid_date_range",
            "location_key",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
        )
        .distinct()
        .withColumn(
            "date_range",
            F.when(
                ~F.col("invalid_date_range"),
                F.sequence(
                    F.col("campaign_start_date"),
                    F.col("campaign_end_date"),
                    F.expr("interval 1 day"),
                ),
            ).otherwise(F.array()),
        )
        .withColumn("date_", F.explode("date_range"))
        .drop("date_range")
        .filter((F.col("date_") >= F.lit(start_date)) & (F.col("date_") <= F.lit(end_date)))
    )

    location_weekly = (
        location_daily
        .withColumnRenamed("location_key", "store_cd")
        .withColumn("week_start_date", F.date_trunc("week", "date_"))
        .select(
            "store_cd",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "week_start_date",
        )
        .distinct()
    )

    cust_by_location = cust_by_location.withColumnRenamed("date_", "week_start_date")
    return (
        location_weekly
        .join(
            cust_by_location,
            on=["week_start_date", "store_cd"],
            how="inner",
        )
        .groupBy(
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "week_start_date",
        )
        .agg(F.sum("distinct_customers").alias("exposed_customers"))
    )


def build_weekly_brand_metrics(
    weekly_media_costs: DataFrame,
    weekly_exposed_custs: DataFrame,
) -> DataFrame:
    """
    Combine weekly media cost and weekly exposed customers into one dataset so we can unpivot later to get the metrics
    in the correct format to be processed by the UCM model downstream.

    Args:
        weekly_media_costs (DataFrame): Weekly media costs DataFrame.
        weekly_exposed_custs (DataFrame): Weekly exposed customers DataFrame.

    Returns:
        DataFrame: Combined weekly brand metrics DataFrame.
    """
    return (
        weekly_media_costs
        .join(
            weekly_exposed_custs,
            on=["week_start_date", "super_category_name", "unique_brand_name", "cluster_num"],
            how="left",
        )
        .withColumn("exposed_customers", F.coalesce(F.col("exposed_customers"), F.lit(0)))
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "total_media_cost",
            "exposed_customers",
        )
    )


def format_metrics_to_hierarchy(
    weekly_instore_metrics: DataFrame,
) -> DataFrame:
    """
    Add marketing hierarchy constants in the format the UCM expects and cast numeric fields for the final long format step.

    Args:
        weekly_instore_metrics (DataFrame): Processed weekly instore metrics for a unique brand and super category combination.

    Returns:
        DataFrame: DataFrame with hierarchy columns and casted metrics.
    """
    return (
        weekly_instore_metrics
        .withColumn("marketing_type", F.lit(InstoreConfig.MARKETING_TYPE))
        .withColumn("marketing_channel", F.lit(InstoreConfig.MARKETING_CHANNEL))
        .withColumn("marketing_sub_channel", F.lit(InstoreConfig.MARKETING_SUB_CHANNEL))
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "cluster_num",
            F.col("total_media_cost").cast(T.DecimalType()),
            F.col("exposed_customers").cast(T.DecimalType()),
        )
    )


def unpivot_metrics_long_format(
    instore_unique_brand_processed_hierarchy: DataFrame,
    correlation_id: str,
) -> DataFrame:
    """
    Unpivot wide metrics into (metric, value) rows and attach job_run_id.
    This is how the downstream sources expect the data to be formatted.

    Args:
        instore_unique_brand_processed_hierarchy (DataFrame): Hierarchy processed DataFrame.
        correlation_id (str): Identifier for the run.

    Returns:
        DataFrame: Unpivoted metrics DataFrame.
    """
    return (
        instore_unique_brand_processed_hierarchy
        .selectExpr(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            """stack(2,
                'total_media_cost', total_media_cost,
                'exposed_customers', exposed_customers
            ) as (metric, value)""",
        )
        .withColumn("job_run_id", F.lit(correlation_id))
        .filter(F.col("cluster_num").isNotNull())
    )


def merge_pollen_and_dtp_data(
        instore_processed_data_pollen: DataFrame,
        instore_processed_data_dtp: DataFrame
) -> DataFrame:
    """
    Merge pollen and dtp instore processed data, with pollen data taking precedence.

    Args:
        instore_processed_data_pollen (DataFrame): Pollen processed data (takes precedence).
        instore_processed_data_dtp (DataFrame): DTP processed data (used only when no pollen match exists).

    Returns:
        DataFrame: Combined data with pollen taking precedence over dtp.
    """
    # Normalize pollen data
    instore_data_pollen_normalized = (
        instore_processed_data_pollen
        .withColumn('cluster_num', F.upper(F.col('cluster_num')))
        .withColumn('marketing_type_name', F.upper(F.col('marketing_type_name')))
        .withColumn('marketing_channel_name', F.upper(F.col('marketing_channel_name')))
        .withColumn('marketing_sub_channel_name', F.upper(F.col('marketing_sub_channel_name')))
        .withColumn('metric_name', F.upper(F.col('metric_name')))
        .select(
            'week_start_dt',
            'metric_value',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name'
        )
    )

    # Normalize dtp data
    instore_data_dtp_normalized = (
        instore_processed_data_dtp
        .withColumn('cluster_num', F.upper(F.col('cluster_num')))
        .withColumn('marketing_type_name', F.upper(F.col('marketing_type_name')))
        .withColumn('marketing_channel_name', F.upper(F.col('marketing_channel_name')))
        .withColumn('marketing_sub_channel_name', F.upper(F.col('marketing_sub_channel_name')))
        .withColumn('metric_name', F.upper(F.col('metric_name')))
        .select(
            'week_start_dt',
            'metric_value',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name'
        )
    )

    # Get dtp records that don't exist in pollen data
    join_conditions = [
        'week_start_dt',
        'super_category_name',
        'unique_brand_name',
        'cluster_num',
        'marketing_type_name',
        'marketing_channel_name',
        'marketing_sub_channel_name',
        'metric_name'
    ]

    dtp_only_records = (
        instore_data_dtp_normalized
        .join(
            instore_data_pollen_normalized,
            join_conditions,
            'left_anti'
        )
    )

    # Combine pollen data (takes precedence) with non-overlapping dtp data
    instore_combined = (
        instore_data_pollen_normalized
        .unionByName(dtp_only_records)
        .withColumn('metric_value', F.col('metric_value').cast(T.DecimalType(18, 5)))
        .withColumn('job_run_id', F.lit('NA'))
        .withColumn('load_ts', F.current_timestamp())
        .select(
            'week_start_dt',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name',
            'metric_value',
            'job_run_id',
            'load_ts'
        )
    )

    return instore_combined
