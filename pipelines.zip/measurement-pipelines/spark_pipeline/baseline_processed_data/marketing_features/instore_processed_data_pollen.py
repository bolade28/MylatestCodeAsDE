from typing import List, Optional
from pyspark.sql import functions as F, SparkSession
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser

from spark_pipeline.baseline_processed_data.marketing_features.instore_processed_data_pollen_helper import (
    aggregate_daily_costs_to_weekly,
    build_campaign_durations_sku_level,
    build_instore_campaign_bookings,
    build_instore_campaigns,
    build_weekly_brand_metrics,
    build_weekly_exposed_customers,
    compute_daily_media_costs,
    explode_campaign_items,
    explode_campaign_stores,
    format_metrics_to_hierarchy,
    merge_pollen_and_dtp_data,
    read_instore_pollen_s3_inputs,
    split_media_cost_across_skus,
    unpivot_metrics_long_format,
)

from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_instore_processed_data(
    spark: SparkSession,
    campaign_booking_media_channel_path: str,
    cust_by_location_path: str,
    sku_cluster_mapping_path: str,
    historic_instore_processed_data: str,
    start_date: str,
    end_date: str,
    correlation_id: str,
    output_path: str,
) -> None:
    """
    This script is used to create time series data for pollen instore campaigns at the cluster level and create the feature
    metrics - instore_spends and exposed_customers.

    We take the transactional data to get total exposed customers for a particular store. Then we join it with the campaign booking data to get the total exposed customers for each campaign per week.
    We also split the media cost of the campaign across the number of SKUs in the campaign and then aggregate it to get the media cost per week.

    Finally, we merge the media cost and exposed customers data to get the final metrics at the cluster level per week.

    * Business Context:
    - Instore Ad data is processed to calculate key performance metrics like total media cost and exposed customers.
    - This activity is then tested in the UCM model, which helps the model isolate the impact of marketing to
      calculate Baseline Sales.
    """

    inputs = read_instore_pollen_s3_inputs(
        spark=spark,
        campaign_booking_media_channel_path=campaign_booking_media_channel_path,
        cust_by_location_path=cust_by_location_path,
        sku_cluster_mapping_path=sku_cluster_mapping_path
    )

    campaign_booking_media_channel_br = inputs["campaign_booking_media_channel_br"]
    cust_by_location = inputs["cust_by_location"]
    sku_cluster_mapping = inputs["sku_cluster_mapping"]

    # Filter the campaign bookings for in-store campaigns and convert item and store columns to arrays
    campaign_bookings = build_instore_campaign_bookings(
        campaign_booking_media_channel_br,
        start_date,
        end_date,
    ).cache()

    # Explode store_cd_list to get individual store locations for each campaign
    store_cd_flattened = explode_campaign_stores(campaign_bookings)

    # Explode item_cd_list to get individual SKUs for each campaign
    known_skus_flattened = explode_campaign_items(campaign_bookings)

    # Filter the campaigns to brand skus only
    campaign_items = (
        known_skus_flattened
        .join(
            F.broadcast(sku_cluster_mapping),
            "item_cd",
            "inner"
        )
        .select(
            "booking_id",
            "master_campaign_id",
            "item_cd",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
        )
        .distinct()
    )

    # Bring down the bookings to the item X store level
    instore_campaigns = build_instore_campaigns(campaign_bookings, campaign_items, store_cd_flattened)

    # Add cluster num to support downstream logic
    instore_campaigns_with_cluster_details = (
        instore_campaigns
        .join(
            F.broadcast(sku_cluster_mapping),
            on=['item_cd', 'unique_brand_name', 'super_category_name'],
            how="left"
        )
        .filter(F.col("media_spend_amt") != 0)
        .withColumnRenamed("media_spend_amt", "media_cost")
        .select(
            "master_campaign_id",
            "media_cost",
            "campaign_start_date",
            "campaign_end_date",
            "invalid_date_range",
            "item_cd",
            "super_category_name",
            "unique_brand_name",
            "location_key",
            "cluster_num"
        )
        .distinct()
    )

    # Calculate the campaign durations at the SKU level, which will be used to calculate media cost per day for each SKU in the campaign
    campaign_durations_sku_level = build_campaign_durations_sku_level(instore_campaigns_with_cluster_details)

    # Split media cost by number of SKUs
    instore_split = split_media_cost_across_skus(campaign_durations_sku_level)

    # Aggregate the daily media costs to the weekly level
    media_costs_daily_exploded = compute_daily_media_costs(instore_split, sku_cluster_mapping, start_date, end_date)
    weekly_media_costs = aggregate_daily_costs_to_weekly(media_costs_daily_exploded)

    # Aggregate the exposed customers per store to the weekly level
    weekly_exposed_customers = build_weekly_exposed_customers(instore_campaigns_with_cluster_details, cust_by_location, start_date, end_date)

    # Combine both metric sources to get the final metrics at the cluster level per week for each unique_brand_name, super_category_name combination
    weekly_instore_metrics = build_weekly_brand_metrics(weekly_media_costs, weekly_exposed_customers)

    # Format to required hierarchy
    instore_metrics = format_metrics_to_hierarchy(weekly_instore_metrics)

    # Unpivot to get the metrics in long format
    instore_processed_data = unpivot_metrics_long_format(instore_metrics, correlation_id)

    instore_processed_data_pollen = (
        instore_processed_data
        .withColumn("week_start_dt", F.to_date("week_start_date"))
        .withColumn("marketing_type_name", F.upper(F.col("marketing_type")))
        .withColumn("marketing_channel_name", F.upper(F.col("marketing_channel")))
        .withColumn("marketing_sub_channel_name", F.upper(F.col("marketing_sub_channel")))
        .withColumn("metric_name", F.upper(F.col("metric")))
        .withColumn("metric_value", F.coalesce(F.col("value"), F.lit(0)))
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value"
        )
    )

    # Read the historic instore processed data from dtp to merge with pollen data
    instore_processed_data_dtp = (
        spark
        .read
        .parquet(historic_instore_processed_data)
    )

    # Merge pollen and historic dtp data to create final instore processed data backfilled with historic data from dtp and new data from pollen
    final_instore_processed_data = merge_pollen_and_dtp_data(instore_processed_data_pollen, instore_processed_data_dtp)

    spark_s3_overwrite(output_path, final_instore_processed_data)
    campaign_bookings.unpersist()


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Instore processed data for baseline pipeline.")
    parser.add_argument("--campaign-booking-media-channel-path", type=str, required=True, help="Path to CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR parquet.")
    parser.add_argument("--cust-by-location-path", type=str, required=True, help="Path to precomputed cust_by_location parquet.")
    parser.add_argument("--sku-cluster-mapping-path", type=str, required=True, help="Path to SKU_CLUSTER_MAPPING parquet.")
    parser.add_argument("--start-date", type=str, required=True, help="Model start date (YYYY-MM-DD).")
    parser.add_argument("--historic-instore-processed-data", type=str, required=True, help="Path to historic instore_processed_data.")
    parser.add_argument("--end-date", type=str, required=True, help="Model end date (YYYY-MM-DD).")
    parser.add_argument("--correlation-id", type=str, required=True, help="Unique identifier for the DAG run.")
    parser.add_argument("--output-path", type=str, required=True, help="Output path for instore_processed_data_up.")

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_instore_processed_data(
        spark=spark,
        campaign_booking_media_channel_path=known_args.campaign_booking_media_channel_path,
        cust_by_location_path=known_args.cust_by_location_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        historic_instore_processed_data=known_args.historic_instore_processed_data,
        start_date=known_args.start_date,
        end_date=known_args.end_date,
        correlation_id=known_args.correlation_id,
        output_path=known_args.output_path,
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder.appName("InstoreProcessedData").getOrCreate())
