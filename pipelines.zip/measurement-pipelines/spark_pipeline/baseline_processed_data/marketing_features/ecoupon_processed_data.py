from datetime import date
from pyspark.sql import DataFrame, SparkSession, functions as F
from pyspark.sql.types import DateType

from typing import List, Optional
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


# 1. Prepare Brand and Campaign Base Data
def extract_base_brand_campaign_data(
    base_finance_assets_data_df: DataFrame,
    oc_campaign_df: DataFrame,
    start_date: date,
    end_date: date
) -> DataFrame:
    """
    Extracts and joins base campaign, brand, and coupon asset data.

    This function performs several steps to prepare the foundational datasets:
    1. Finds the latest 'timeid' from the finance assets data.
    2. Filters the finance data to get relevant coupon base data for completed
       campaigns within the specified date range.
    3. Aggregates and joins the coupon campaign data with the finance data
       to link base assets with campaign details.

    Args:
        base_finance_assets_data_df (DataFrame): A DataFrame with finance asset
            details, including dates, job bag numbers, and asset values.
        oc_campaign_df (DataFrame): A DataFrame with campaign details, including
            base asset IDs and campaign dates.
        start_date (date): The start date for filtering campaigns.
        end_date (date): The end date for filtering campaigns.

    Returns:
        DataFrame: ecoupon_base_value_df — campaign and finance data linked for eCoupons.
    """
    max_timeid = (
        base_finance_assets_data_df
        .agg(F.max("timeid").alias("max_timeid"))
        .collect()[0]["max_timeid"]
    )

    coupon_base_data_df = (
        base_finance_assets_data_df
        .filter(
            (F.col("asset_actual_start_date").between(start_date, end_date)) &
            (F.col("asset_actual_end_date").between(start_date, end_date)) &
            (F.upper(F.col("media_host_name")).like("SAINSBUR%")) &
            (F.col("job_bag_number").isNotNull()) &
            (F.col("timeid") == max_timeid) &
            (F.lower(F.col("campaign_status")) == "campaign completed") &
            (F.col("asset_value_unweighted") > 0)
        )
        .withColumnRenamed("asset_actual_start_date", "base_start_date")
        .withColumnRenamed("asset_actual_end_date", "base_end_date")
        .withColumnRenamed("asset_value_unweighted", "value_")
        .withColumn("cid", F.expr("right(asset_unique_id, 6)"))
        .select(
            "job_bag_number",
            "base_start_date",
            "base_end_date",
            "value_",
            "cid"
        )
    )

    ecoupon_base_asset_df = (
        oc_campaign_df
        .filter(F.col("base_asset_id").isNotNull())
        .withColumn("cid", F.col('base_asset_id'))
        .groupBy("campaign_id", "cid", "base_asset_id")  # ToDo: this is redundant logic, effectively cid and base_asset_id are the same
        .agg(
            F.min("start_date").alias("start_date"),
            F.max("expiry_date").alias("expiry_date")
        )
        .select(
            "campaign_id",
            "cid",
            "base_asset_id",
            "start_date",
            "expiry_date",
        )
    )

    coupon_base_lookup_df = (
        coupon_base_data_df
        .select(
            "job_bag_number",
            "base_start_date",
            "base_end_date",
            "value_",
            "cid"
        )
        .distinct()
    )

    ecoupon_base_value_df = (
        ecoupon_base_asset_df
        .join(coupon_base_lookup_df, on="cid", how="inner")
        .select(
            "job_bag_number",
            "base_start_date",
            "base_end_date",
            "value_",
            "cid",
            "campaign_id",
            "base_asset_id",
            "start_date",
            "expiry_date"
        )
    )

    return ecoupon_base_value_df


# 2. Prepare Product and Brand Details
def enrich_with_product_and_brand_info(
    oc_products_df: DataFrame,
    temp_unified_product_df: DataFrame,
    sku_cluster_df: DataFrame,
    ecoupon_base_value_df: DataFrame,
):
    """
    Enriches the eCoupon base data with product and brand information via an inner join
    on item_cd with the SKU cluster mapping

    Args:
        oc_products_df (DataFrame): Contains mapping from product keys to base asset IDs.
        temp_unified_product_df (DataFrame): Maps product keys to item codes.
        sku_cluster_df (DataFrame): SKU cluster mapping — inner join on item_cd filters
            to brand SKUs and provides brand/category/cluster attributes.
        ecoupon_base_value_df (DataFrame): The base eCoupon data from the previous step.

    Returns:
        DataFrame: ecoupon_base_value_bs with item_cd, unique_brand_name,
            super_category_name, and cluster_num.
    """
    ecoupon_base_asset_ids = ecoupon_base_value_df.select("base_asset_id").distinct()

    # Join with distinct base_asset_ids to get item_cd
    product_key_item = (
        oc_products_df
        .join(
            ecoupon_base_asset_ids,
            on="base_asset_id",
            how="inner"
        )
        .join(
            temp_unified_product_df.select("product_key", "item_cd"),
            on="product_key",
            how="inner"
        )
        .select(
            "item_cd",
            "base_asset_id"
        )
        .distinct()
    )

    ecoupon_base_value_item = (
        ecoupon_base_value_df
        .join(
            product_key_item,
            on="base_asset_id",
            how="inner"
        )
        .select(
            "base_asset_id",
            "job_bag_number",
            "base_start_date",
            "base_end_date",
            "value_",
            "cid",
            "campaign_id",
            "start_date",
            "expiry_date",
            "item_cd"
        )
    )

    sku_cluster_lookup = (
        F.broadcast(sku_cluster_df)
        .select(
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "cluster_num"
        )
        .distinct()
    )

    ecoupon_base_value_bs = (
        ecoupon_base_value_item
        .join(
            sku_cluster_lookup,
            on="item_cd",
            how="inner"
        )
        .withColumnRenamed("value_", "base_value")
        .select(
            "job_bag_number",
            "base_start_date",
            "base_end_date",
            "base_value",
            "cid",
            "campaign_id",
            "base_asset_id",
            "start_date",
            "expiry_date",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
        )
    )

    return ecoupon_base_value_bs


# 3. Calculate Coupon Values and Performance Metrics
def calculate_aggregate_coupon_values(
        oc_customer_selection_df: DataFrame,
        ecoupon_base_value_bs: DataFrame):
    """
    Calculates the aggregate value of coupons based on their type and status.

    This function processes the `coupon_id` to determine the actual coupon
    value, aggregates these values by campaign and base asset, and then
    joins the result with the enriched base data. The `when().otherwise()`
    logic handles different coupon ID formats to extract the value.

    Args:
        oc_customer_selection_df (DataFrame): Contains customer-specific coupon
            information, including campaign ID and `coupon_id` strings.
        ecoupon_base_value_bs (DataFrame): The enriched DataFrame from the
            previous step.

    Returns:
        DataFrame: A DataFrame with the original base data enriched with
            an aggregated `coupon_value` column.
    """

    ecoupon_value = (
        oc_customer_selection_df.select(
            "campaign_id",
            "base_asset_id",
            "status",
            F.when(
                F.col("coupon_id").rlike("^99"), F.expr("cast(substring(coupon_id, -4, 3) as double)")
            )
            .when(
                F.col("coupon_id").rlike("^28"), F.expr("cast(substring(substring(coupon_id, 1, 7), -3, 3) as double) * 0.5")
            )
            .otherwise(None)
            .alias("coupon_value")
        )
    )

    ecoupon_value_agg = (
        ecoupon_value.groupBy("campaign_id", "base_asset_id")
        .agg(F.sum("coupon_value").alias("coupon_value"))
    )

    ecoupon_performance = (
        ecoupon_base_value_bs
        .join(
            ecoupon_value_agg.select("campaign_id", "base_asset_id", "coupon_value"),
            on=["campaign_id", "base_asset_id"],
            how="left"
        )
        .select(
            "campaign_id",
            "base_asset_id",
            "job_bag_number",
            "base_start_date",
            "base_end_date",
            "base_value",
            "cid",
            "start_date",
            "expiry_date",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "coupon_value"
        )
    )

    return ecoupon_performance

# 4. Aggregate and Final Output Preparation (includes exploding daily, weekly aggregation, cluster join, unpivot, final join)


def build_final_aggregated_output(
        weekly_dates_df: DataFrame,
        ecoupon_performance: DataFrame,
        correlation_id: str):
    """
    Aggregates and transforms the eCoupon performance data into a final output format.

    This function performs a series of transformations, including:
    1. Exploding the data to a daily level.
    2. Aggregating the data weekly.
    4. Unpivoting 'base_value' and 'coupon_value' into a single 'metric' column.
    5. Performing a final cross-join with a weekly dates table to ensure
       a complete data skeleton.
    6. Selecting and renaming final columns for output.

    Args:
        weekly_dates_df (DataFrame): A DataFrame containing a list of all relevant
            week start dates.
        ecoupon_performance (DataFrame): The DataFrame from the previous step,
            containing base/coupon values and cluster_num.
        correlation_id (str): A unique ID for the pipeline run.

    Returns:
        DataFrame: The final processed DataFrame ready to be written to a target location.
    """
    coupon_overall_1 = (
        ecoupon_performance
        .drop('campaign_id')
        .withColumn("number_of_days", F.datediff(F.col("base_end_date"), F.col("base_start_date")) + F.lit(1))
        .withColumnRenamed("cid", "campaign_id")
        .distinct()
    )

    coupon_overall_daily = (
        coupon_overall_1.withColumn(
            "date",
            F.explode(F.sequence(F.col("base_start_date"), F.col("base_end_date")))
        )
        .withColumn("daily_coupon_value", F.col("coupon_value") / F.col("number_of_days"))
        .withColumn("daily_base_value", F.col("base_value") / F.col("number_of_days"))
        .select(
            "job_bag_number",
            "campaign_id",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "date",
            "daily_coupon_value",
            "daily_base_value",
        )
    )

    # Weekly aggregation — cluster_num carried from the inner join in enrich_with_product_and_brand_info
    coupon_overall_weekly = (
        coupon_overall_daily
        .withColumn("week_start_date", F.date_trunc("week", F.col("date")))
        .groupBy(
            "item_cd",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "job_bag_number",
            "week_start_date"
        )
        .agg(
            F.round(F.sum("daily_coupon_value"), 2).alias("coupon_value"),
            F.round(F.sum("daily_base_value"), 2).alias("base_value")
        )
        .withColumnRenamed("job_bag_number", "campaign_name")
    )

    # Unpivot base_value and coupon_value into metric, value_
    coupon_unpivot = (
        coupon_overall_weekly.selectExpr(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "item_cd",
            "campaign_name",
            "cluster_num",
            "stack(2, 'base_value', cast(base_value as double), 'coupon_value', cast(coupon_value as double)) as (metric, value_)"
        )
        .withColumn("marketing_type", F.lit("ONSITE"))
        .withColumn("marketing_channel", F.lit("eCoupon"))
        .withColumn("marketing_sub_channel", F.lit("TOTAL"))
    )

    # Aggregate melted data
    ecoupon_unique_brand = (
        coupon_unpivot
        .groupBy(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "metric",
            "cluster_num",
        )
        .agg(F.sum("value_").alias("value_"))
    )

    weekly_dates_df = weekly_dates_df.select(F.col("week_start_dt").alias("week_start_date")).distinct()

    ecoupon_unique_brand_cluster_skele = (
        ecoupon_unique_brand.select(
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "cluster_num",
            "metric"
        ).distinct()
    )

    ecoupon_unique_brand_cluster_skele_final = weekly_dates_df.crossJoin(ecoupon_unique_brand_cluster_skele)

    join_columns = [
        "week_start_date",
        "super_category_name",
        "unique_brand_name",
        "cluster_num",
        "marketing_type",
        "marketing_channel",
        "marketing_sub_channel",
        "metric"
    ]

    ecoupon_processed_data = (
        ecoupon_unique_brand_cluster_skele_final
        .join(
            ecoupon_unique_brand.select(*join_columns, "value_"),
            on=join_columns,
            how="left"
        )
        .filter(F.col("cluster_num").isNotNull())
        .select(
            F.col("week_start_date").alias("week_start_dt"),
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            F.col("marketing_type").alias("marketing_type_name"),
            F.col("marketing_channel").alias("marketing_channel_name"),
            F.col("marketing_sub_channel").alias("marketing_sub_channel_name"),
            F.col("metric").alias("metric_name"),
            F.coalesce(F.col("value_"), F.lit(0)).alias("metric_value"),
            F.lit(correlation_id).alias("job_run_id"),
            F.current_timestamp().cast("timestamp").alias("load_ts")
        )
    )

    return ecoupon_processed_data


def run_ecoupon_transformation_pipeline(
    base_finance_assets_data_df: DataFrame,
    oc_campaign_df: DataFrame,
    start_date: date | str,
    end_date: date | str,
    oc_products_df: DataFrame,
    temp_unified_product_df: DataFrame,
    sku_cluster_df: DataFrame,
    oc_customer_selection_df: DataFrame,
    weekly_dates_df: DataFrame,
    correlation_id: str
) -> DataFrame:
    """
    Executes the full eCoupon data transformation pipeline.

    This is the orchestrator function that calls the individual data
    preparation, enrichment, and aggregation functions in the correct order.
    It takes all necessary input DataFrames and parameters and returns
    the final processed DataFrame.

    Args:
        base_finance_assets_data_df (DataFrame): Base finance assets data.
        oc_campaign_df (DataFrame): Online coupon campaign data.
        start_date (date): The start date for filtering data.
        end_date (date): The end date for filtering data.
        oc_products_df (DataFrame): Online coupon products data.
        temp_unified_product_df (DataFrame): Temporary unified product data (product_key→item_cd).
        sku_cluster_df (DataFrame): SKU cluster mapping — inner join on item_cd filters to brand SKUs.
        oc_customer_selection_df (DataFrame): Online coupon customer selection data.
        weekly_dates_df (DataFrame): Weekly dates data.
        correlation_id (str): A unique ID for the pipeline run.

    Returns:
        DataFrame: The final processed DataFrame.
    """

    ecoupon_base_value_df = (
        extract_base_brand_campaign_data(base_finance_assets_data_df,
                                         oc_campaign_df,
                                         start_date,
                                         end_date))

    ecoupon_base_value_bs = (
        enrich_with_product_and_brand_info(oc_products_df,
                                           temp_unified_product_df,
                                           sku_cluster_df,
                                           ecoupon_base_value_df))

    ecoupon_performance = (
        calculate_aggregate_coupon_values(oc_customer_selection_df,
                                          ecoupon_base_value_bs))

    ecoupon_processed_data_df = (
        build_final_aggregated_output(weekly_dates_df, ecoupon_performance, correlation_id))

    return ecoupon_processed_data_df


def run_and_save_ecoupon_data_to_parquet(
    spark: SparkSession,
    base_finance_assets_path: str,
    oc_campaign_path: str,
    start_date: str,
    end_date: str,
    oc_products_path: str,
    temp_unified_product_path: str,
    oc_customer_selection_path: str,
    sku_cluster_mapping_path: str,
    weekly_dates_path: str,
    output_path: str,
    correlation_id: str

) -> None:
    """
    Main entry point for the eCoupon data processing pipeline.

    SKU filtering is performed via an inner join on item_cd with the SKU cluster
    mapping, replacing the previous campaign_selection and unified_product approach.

    Args:
        spark (SparkSession): The SparkSession object.
        base_finance_assets_path (str): S3 path for base finance assets data.
        oc_campaign_path (str): S3 path for online coupon campaign data.
        start_date (str): The start date for filtering.
        end_date (str): The end date for filtering.
        oc_products_path (str): S3 path for online coupon products data.
        temp_unified_product_path (str): S3 path for temporary unified product data (product_key→item_cd).
        oc_customer_selection_path (str): S3 path for online coupon customer selection data.
        sku_cluster_mapping_path (str): S3 path for SKU cluster mapping data.
        weekly_dates_path (str): S3 path for weekly dates data.
        output_path (str): S3 path where the final output will be saved.
        correlation_id (str): A unique identifier for the DAG run.
    """
    # Fix for Spark 3.x date/timestamp rebase issue
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")

    # Ensure start_date and end_date are strings
    if isinstance(start_date, date):
        start_date = start_date.strftime("%Y-%m-%d")
    if isinstance(end_date, date):
        end_date = end_date.strftime("%Y-%m-%d")

    weekly_dates_df = (
        spark
        .read
        .parquet(weekly_dates_path)
        .withColumn(
            "WEEK_START_DT",
            F.col("WEEK_START_DT").cast(DateType())
        )
    )

    sku_cluster_df = load_parquet_dataset(
        spark,
        sku_cluster_mapping_path,
        'sku_cluster_mapping',
        slack_notifier=None,
        columns=BaselineProcessedData.sku_cluster_mapping_cols,
    )

    temp_unified_product_df = (
        spark
        .read
        .parquet(temp_unified_product_path)
        .select(
            "product_key",
            "item_cd"
        )
    )

    base_finance_assets_df = (
        spark
        .read
        .parquet(base_finance_assets_path)
        .select(
            "asset_actual_start_date",
            "asset_actual_end_date",
            "media_host_name",
            "job_bag_number",
            "timeid",
            "campaign_status",
            "asset_value_unweighted",
            "asset_unique_id"
        )
    )

    oc_campaign_df = (
        spark
        .read
        .parquet(oc_campaign_path)
        .select(
            "campaign_id",
            "base_asset_id",
            "start_date",
            "expiry_date"
        )
    )

    oc_products_df = (
        spark
        .read
        .parquet(oc_products_path)
        .select(
            "product_key",
            "base_asset_id"
        )
    )

    oc_customer_selection_df = (
        spark
        .read
        .parquet(oc_customer_selection_path)
        .select(
            "campaign_id",
            "base_asset_id",
            "status",
            "coupon_id",
        )
    )

    result_df = (
        run_ecoupon_transformation_pipeline(
            base_finance_assets_df,
            oc_campaign_df,
            start_date,
            end_date,
            oc_products_df,
            temp_unified_product_df,
            sku_cluster_df,
            oc_customer_selection_df,
            weekly_dates_df,
            correlation_id
        )
    )

    result_df = (
        result_df
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "job_run_id",
            "load_ts"
        )
    )
    spark_s3_overwrite(output_path, result_df)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    """
    This function sets up an argument parser to read all necessary S3 paths
    and parameters from the command line, then calls the
    `run_and_save_ecoupon_data_to_parquet` function to start the data
    processing workflow.

    Args:
        spark (SparkSession): The active SparkSession object.
        command_line_args (Optional[List[str]]): A list of command-line
            arguments. If None, `sys.argv` is used.
    """
    parser = ThrowingArgumentParser(description="Prepare  processed data for Coupon at till in baseline pipeline.")
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="The S3 path for the weekly dates."
    )
    parser.add_argument(
        "--base-finance-assets-path",
        type=str,
        required=True,
        help="The S3 path for the base finance assets data."
    )
    parser.add_argument(
        "--oc-campaign-path",
        type=str,
        required=True,
        help="The S3 path for the oc campaign data."
    )
    parser.add_argument(
        "--oc-products-path",
        type=str,
        required=True,
        help="The S3 path for the oc products data."
    )
    parser.add_argument(
        "--oc-customer-selection-path",
        type=str,
        required=True,
        help="The S3 path for the oc customer selection data."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="The S3 path for the sku_cluster_mapping data."
    )
    parser.add_argument(
        "--temp-unified-product-path",
        type=str,
        required=True,
        help="The S3 path for the temporary unified product data."
    )
    # TODO: test and receive start and end dates from weekly_dates
    parser.add_argument(
        "--start-date",
        type=str,
        required=True,
        help="This is model start date"
    )
    parser.add_argument(
        "--end-date",
        type=str,
        required=True,
        help="This is model end date"
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The S3 path for the output data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    run_and_save_ecoupon_data_to_parquet(
        spark=spark,
        base_finance_assets_path=known_args.base_finance_assets_path,
        oc_campaign_path=known_args.oc_campaign_path,
        start_date=known_args.start_date,
        end_date=known_args.end_date,
        oc_products_path=known_args.oc_products_path,
        temp_unified_product_path=known_args.temp_unified_product_path,
        oc_customer_selection_path=known_args.oc_customer_selection_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        weekly_dates_path=known_args.weekly_dates_path,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("ECouponProcessedData").getOrCreate())
