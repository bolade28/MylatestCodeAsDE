from datetime import date
from typing import List, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import DateType

from spark_pipeline.common.variables import BaselineProcessedData, YoutubeConfig
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.stdout_logger import StdOutLogger
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite

logger = StdOutLogger()


def prepare_youtube_processed_data(
    spark: SparkSession,
    youtube_normalize_path: str,
    sku_cluster_mapping_path: str,
    media_report_path: str,
    weekly_dates_path: str,
    start_date: str,
    end_date: str,
    output_path: str,
    correlation_id: str,
) -> None:
    """
    * Objective:
    - This script is used to create time series data for YouTube campaigns at cluster level and create feature
      metrics - clicks, impressions, spends etc..

    * Business Context:
        - Youtube data is processed to calculate key performance metrics like campaign spend, impressions, clicks,
          measurable_impressions and viewable_impressions.
        - This activity is then tested in the UCM model, which helps the model isolate the impact of marketing to
          calculate Baseline Sales.

    * Lineage:
        Upstream:
            - offsite_format (youtube_normalize.py)
            - 14_stored_procedure_call (sku_cluster_mapping_call.sql)
        Downstream:
            - 08_ads_creation (channel_processed_data.sql)
    """

    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")

    # start_date and end_date are strings
    if isinstance(start_date, date):
        start_date = start_date.strftime("%Y-%m-%d")
    if isinstance(end_date, date):
        end_date = end_date.strftime("%Y-%m-%d")

    logger.info(f"START DATE: {start_date}, END_DATE: {end_date}")

    # Read
    youtube_normalize_df = (
        spark.read.parquet(youtube_normalize_path)
        .withColumnRenamed("jobbagid", "master_campaign_id")
        .select(
            "item_cd",
            "master_campaign_id",
            "start_dt",
            "end_dt"
        )
    )

    media_report_df = (
        spark.read.parquet(media_report_path)
        .withColumnRenamed("jobbag_id", "master_campaign_id")
        .select(
            "master_campaign_id",
            "campaign_date",
            "impressions",
            "clicks",
            "revenue",
            "measurable_impressions",
            "viewable_impressions"
        )
    )

    sku_cluster_df = load_parquet_dataset(
        spark,
        sku_cluster_mapping_path,
        'sku_cluster_mapping',
        slack_notifier=None,
        columns=BaselineProcessedData.sku_cluster_mapping_cols,
    )

    weekly_dates_df = (
        spark.read.parquet(weekly_dates_path)
        .withColumn(
            "week_start_dt",
            F.col("week_start_dt").cast(DateType())
        )
    )

    # Setting parameter
    job_run_id = correlation_id

    # Inner join youtube normalised with sku_cluster_df to filter to the brand skus
    youtube_campaigns = (
        youtube_normalize_df
        .join(F.broadcast(sku_cluster_df), "item_cd", "inner")
        .select(
            "item_cd",
            "master_campaign_id",
            "start_dt",
            "end_dt",
            "super_category_name",
            "unique_brand_name"
        )
        .distinct()
    )

    # Exploding campaign level information to daily level information
    yt_campaigns_daily_exploded = (
        youtube_campaigns
        .withColumn("date_diff", F.datediff(F.col("end_dt"), F.col("start_dt")) + F.lit(1))
        .withColumn("date_range", F.expr("sequence(0, date_diff - 1)"))
        .withColumn("date_offset", F.explode(F.col("date_range")))
        .withColumn("date_", F.date_add(F.col("start_dt"), F.col("date_offset")))
        .withColumnRenamed("item_cd", "sku_no")
        .select(
            "super_category_name",
            "unique_brand_name",
            "sku_no",
            "master_campaign_id",
            "date_"
        )
    )

    # Taking Distinct Weekly,Campaign and SKU level values
    yt_campaigns_weekly = (
        yt_campaigns_daily_exploded
        .withColumn("week_start_date", F.date_trunc("week", F.col("date_")))
        .select(
            "master_campaign_id",
            "super_category_name",
            "unique_brand_name",
            "sku_no",
            "week_start_date"
        )
        .distinct()
    )

    # Taking Distinct Campaign and SKU level values
    yt_camps_unique_brand = (
        yt_campaigns_weekly
        .select(
            "master_campaign_id",
            "super_category_name",
            "unique_brand_name",
            "sku_no"
        )
        .distinct()
    )

    # Retrieving Youtube Media_Report for Metric Information
    campaign_ids = yt_campaigns_weekly.select("master_campaign_id").distinct()

    youtube_raw_metrics = (
        media_report_df
        .join(
            F.broadcast(campaign_ids),
            on="master_campaign_id",
            how="inner"
        )
    )

    # Aggregating metrics at a Campaign level
    yt_metrics = (
        youtube_raw_metrics
        .groupBy("campaign_date", "master_campaign_id")
        .agg(
            F.sum("impressions").alias("impressions"),
            F.sum("clicks").alias("clicks"),
            F.sum("revenue").alias("campaign_spend"),
            F.sum("measurable_impressions").alias("measurable_impressions"),
            F.sum("viewable_impressions").alias("viewable_impressions")
        )
    )

    # Taking Distinct Campaign and SKU level values
    yt_camps_unique_brand_reqd_cols = (
        yt_camps_unique_brand
        .select("master_campaign_id", "sku_no", "super_category_name", "unique_brand_name")
        .distinct()
    )

    # Merging to bring in SKU, Super Category and Brand Information
    yt_metrics_with_product_details = (
        yt_metrics
        .join(
            yt_camps_unique_brand_reqd_cols,
            on="master_campaign_id",
            how="left"
        )
        .select(
            "campaign_date",
            "master_campaign_id",
            "impressions",
            "clicks",
            "campaign_spend",
            "measurable_impressions",
            "viewable_impressions",
            "sku_no",
            "unique_brand_name",
            "super_category_name"
        )
    )

    # Counting number of SKUs in each campaign to scale campaign level metrics appropriately for SKU level
    yt_metrics_campaign_sku_count = (
        yt_metrics_with_product_details
        .groupBy("master_campaign_id")
        .agg(F.countDistinct("sku_no").alias("number_of_skus"))
    )

    # Merging with SKU count
    yt_metrics_with_product_details = (
        yt_metrics_with_product_details
        .join(
            yt_metrics_campaign_sku_count,
            on="master_campaign_id",
            how="left"
        )
        .select(
            "master_campaign_id",
            "campaign_date",
            "sku_no",
            "unique_brand_name",
            "super_category_name",
            "impressions",
            "clicks",
            "campaign_spend",
            "measurable_impressions",
            "viewable_impressions",
            "number_of_skus"
        )
    )

    # Scale campaign level metrics appropriately for SKU level
    yt_metrics_normalised = (
        yt_metrics_with_product_details
        .select(
            "campaign_date",
            "master_campaign_id",
            "sku_no",
            "unique_brand_name",
            "super_category_name",
            (F.col("impressions") / F.col("number_of_skus")).alias("impressions"),
            (F.col("clicks") / F.col("number_of_skus")).alias("clicks"),
            (F.col("campaign_spend") / F.col("number_of_skus")).alias("campaign_spend"),
            (F.col("measurable_impressions") / F.col("number_of_skus")).alias("measurable_impressions"),
            (F.col("viewable_impressions") / F.col("number_of_skus")).alias("viewable_impressions")
        )
    )

    # Aggregating metrics at weekly level and SKU level
    yt_metrics_normalised_weekly = (
        yt_metrics_normalised
        .withColumn("week_start_date", F.date_trunc("week", F.col("campaign_date")))
        .groupBy(
            "master_campaign_id",
            "sku_no",
            "unique_brand_name",
            "super_category_name",
            "week_start_date"
        )
        .agg(
            F.sum("impressions").alias("impressions"),
            F.sum("clicks").alias("clicks"),
            F.sum("campaign_spend").alias("campaign_spend"),
            F.sum("measurable_impressions").alias("measurable_impressions"),
            F.sum("viewable_impressions").alias("viewable_impressions")
        )
    )

    # Merging to bring in Cluster information
    sku_cluster_lookup = (
        sku_cluster_df
        .withColumnRenamed("item_cd", "sku_no")
        .select(
            "sku_no",
            "cluster_num"
        )
        .distinct()
    )

    yt_cluster_pre = (
        yt_metrics_normalised_weekly
        .join(
            sku_cluster_lookup,
            on="sku_no",
            how="inner"
        )
        .select(
            "master_campaign_id",
            "sku_no",
            "unique_brand_name",
            "super_category_name",
            "week_start_date",
            "impressions",
            "clicks",
            "campaign_spend",
            "measurable_impressions",
            "viewable_impressions",
            "cluster_num"
        )
    )

    # Aggregating at Cluster Level ToDo: confirm if we still need this, as we don't do clustering anymore, but might need this for multi-booking?
    yt_clustered_data = (
        yt_cluster_pre
        .groupBy(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num"
        )
        .agg(
            F.sum("impressions").alias("impressions"),
            F.sum("clicks").alias("clicks"),
            F.sum("campaign_spend").alias("campaign_spend"),
            F.sum("measurable_impressions").alias("measurable_impressions"),
            F.sum("viewable_impressions").alias("viewable_impressions")
        )
    )

    # Retrieving Date Skeleton
    temp_date_dataset = weekly_dates_df.select(F.col("week_start_dt").alias("week_start_date"))

    # Melting to bring in all metrics
    youtube_pivoted_metrics = (
        yt_clustered_data
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            F.expr(
                "stack(5, "
                "'impressions', cast(impressions as decimal(38,2)), "
                "'clicks', cast(clicks as decimal(38,2)), "
                "'measurable_impressions', cast(measurable_impressions as decimal(38,2)), "
                "'viewable_impressions', cast(viewable_impressions as decimal(38,2)), "
                "'campaign_spend', cast(campaign_spend as decimal(38,2))"
                ") as (metric, value)"
            ),
            F.lit(YoutubeConfig.MARKETING_TYPE).alias("marketing_type"),
            F.lit(YoutubeConfig.MARKETING_CHANNEL).alias("marketing_channel"),
            F.lit(YoutubeConfig.MARKETING_SUB_CHANNEL).alias("marketing_sub_channel")
        )
    )

    # Creating Skeleton
    skele_youtube_unique_brand = (
        youtube_pivoted_metrics
        .select(
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "cluster_num",
            "metric"
        )
        .distinct()
    )

    # Merging to create complete skeleton for dataset
    skele_youtube_unique_brand_final = (
        temp_date_dataset
        .crossJoin(skele_youtube_unique_brand)
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "cluster_num",
            "metric"
        )
    )

    join_columns = [
        "week_start_date",
        "super_category_name",
        "unique_brand_name",
        "marketing_type",
        "marketing_channel",
        "marketing_sub_channel",
        "cluster_num",
        "metric"
    ]

    # Merging with main data to create complete skeleton for dataset. Imputing missing values.
    youtube_processed_data = (
        skele_youtube_unique_brand_final
        .join(
            youtube_pivoted_metrics.select(*join_columns, "value"),
            on=join_columns,
            how="left"
        )
        .filter(F.col("cluster_num").isNotNull())
        .withColumn("value_", F.coalesce(F.col("value"), F.lit(0)))
        .withColumn("job_run_id", F.lit(job_run_id))
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "cluster_num",
            "metric",
            F.col("value_"),
            F.col("job_run_id")
        )
        .distinct()
    )

    # Filtering for required columns
    youtube_processed_data_final = (
        youtube_processed_data
        .select(
            F.col("week_start_date").alias("week_start_dt"),
            F.col("super_category_name"),
            F.col("unique_brand_name"),
            F.col("cluster_num"),
            F.col("marketing_type").alias("marketing_type_name"),
            F.col("marketing_channel").alias("marketing_channel_name"),
            F.col("marketing_sub_channel").alias("marketing_sub_channel_name"),
            F.col("metric").alias("metric_name"),
            F.col("value_").alias("metric_value"),
            F.col("job_run_id"),
            F.current_timestamp().alias("load_ts"),
            F.expr("named_struct('effective_ts', current_timestamp())").alias("technical_metadata")
        )
    )

    # Write output to S3
    spark_s3_overwrite(output_path, youtube_processed_data_final)
    logger.info(f"YOUTUBE_PROCESSED_DATA Count: {youtube_processed_data_final.count()}")


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare YouTube processed data for baseline pipeline.")
    parser.add_argument(
        "--youtube-normalize-path",
        type=str,
        required=True,
        help="The S3 path for the YouTube normalize data."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="S3 path for SKU cluster mapping path."
    )
    parser.add_argument(
        "--media-report-path",
        type=str,
        required=True,
        help="S3 path for media report data."
    )
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="S3 path for weekly calendar reference data."
    )
    parser.add_argument(
        "--start-date",
        type=str,
        required=True,
        help="Pipeline start date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--end-date",
        type=str,
        required=True,
        help="Pipeline end date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The path in S3 to output the YouTube processed data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_youtube_processed_data(
        spark=spark,
        youtube_normalize_path=known_args.youtube_normalize_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        media_report_path=known_args.media_report_path,
        weekly_dates_path=known_args.weekly_dates_path,
        start_date=known_args.start_date,
        end_date=known_args.end_date,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.getOrCreate())  # type: ignore[attr-defined]
