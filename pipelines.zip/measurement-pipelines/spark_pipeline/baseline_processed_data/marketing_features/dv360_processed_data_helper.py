from typing import List

from pyspark.sql import DataFrame
from pyspark.sql import functions as F, types as T

from spark_pipeline.baseline_processed_data.processed_data_utils import normalise_pollen_dtp_join_columns
from spark_pipeline.common.variables import DV360Config


def calculate_sku_counts(
    metrics_with_sku: DataFrame,
    campaign_id_col: str,
    sku_col: str,
) -> DataFrame:
    """Calculate the number of distinct SKUs attached to each campaign."""
    return metrics_with_sku.groupBy(campaign_id_col).agg(
        F.countDistinct(sku_col).alias("number_of_skus")
    )


def scale_metrics_to_sku_level(
    metrics_with_sku: DataFrame,
    sku_counts: DataFrame,
    campaign_id_col: str,
    metric_columns: List[str],
    select_columns: List[str]
) -> DataFrame:
    """
    Scale campaign-level metrics down to the SKU grain.

    Joins campaign-level metrics to a precomputed SKU count per campaign and divides
    each metric in metric_columns by number_of_skus so that the values are
    allocated evenly across the attached SKUs.

    Args:
        metrics_with_sku: Input dataframe at campaign-and-SKU grain containing the
            campaign identifier and the metric columns to scale.
        sku_counts: Dataframe containing one row per campaign with a number_of_skus column
        campaign_id_col: Name of the campaign identifier column used to join metrics_with_sku to sku_counts.
        metric_columns: Names of the numeric metric columns to divide by the SKU count.
        select_columns: Columns to keep in the returned dataframe after scaling.

    Returns:
        DataFrame: A dataframe at SKU grain with the requested select_columns
        and metric values scaled from campaign level to SKU level.
    """
    scaled_df = metrics_with_sku.join(F.broadcast(sku_counts), campaign_id_col, "left")
    number_of_skus = F.col("number_of_skus")

    for metric_column in metric_columns:
        scaled_value = F.coalesce(F.when(number_of_skus > F.lit(0), F.col(metric_column) / number_of_skus), F.lit(0))
        scaled_df = scaled_df.withColumn(metric_column, scaled_value)

    return scaled_df.select(*select_columns)


def join_cluster_info(
    metrics_df: DataFrame,
    sku_cluster_mapping: DataFrame,
    sku_col: str,
    metric_columns: List[str],
) -> DataFrame:
    """Attach cluster assignments at SKU level."""
    cluster_mapping_lookup = (
        sku_cluster_mapping
        .withColumnRenamed("item_cd", sku_col)  # Support both DTP and Pollen
        .select(
            sku_col,
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
        )
    )

    return (
        metrics_df
        .join(
            cluster_mapping_lookup,
            on=["super_category_name", "unique_brand_name", sku_col],
            how="left",
        )
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            *metric_columns,
        )
    )


def aggregate_to_cluster_level(
    cluster_pre: DataFrame,
    metric_columns: List[str],
) -> DataFrame:
    """Aggregate SKU-level metrics to cluster level."""
    return cluster_pre.groupBy(
        "week_start_date",
        "super_category_name",
        "unique_brand_name",
        "cluster_num",
    ).agg(*[F.sum(metric_column).alias(metric_column) for metric_column in metric_columns])


def unpivot_metrics(
    cluster_metrics: DataFrame,
    metric_columns: List[str]
) -> DataFrame:
    """Convert wide cluster metrics into the processed long-format output."""

    # ToDo: Add a schema for this
    metric_array = F.array(
        *[
            F.struct(
                F.lit(metric_column).alias("metric"),
                F.col(metric_column).alias("value"),
            )
            for metric_column in metric_columns
        ]
    )

    return (
        cluster_metrics
        .withColumn("metric_array", metric_array)
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            F.explode("metric_array").alias("metric_data"),
        )
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            F.col("metric_data.metric").alias("metric"),
            F.col("metric_data.value").alias("metric_value"),
            F.lit(DV360Config.MARKETING_TYPE).alias("marketing_type"),
            F.lit(DV360Config.MARKETING_CHANNEL).alias("marketing_channel"),
            F.lit(DV360Config.MARKETING_SUB_CHANNEL).alias("marketing_sub_channel"),
        )
    )


def format_final_output(
    processed_metrics: DataFrame,
    correlation_id: str,
    week_column: str = "week_start_date",
) -> DataFrame:
    """Apply the final formatting required for baseline processed data scripts."""

    # ToDo: Clean this up so the renames happen upstream rather than a big list here
    return (
        processed_metrics
        .withColumn("metric_value", F.coalesce(F.col("metric_value"), F.lit(0)))
        .withColumn("job_run_id", F.lit(correlation_id))
        .withColumnRenamed(week_column, "week_start_dt")
        .withColumnRenamed("marketing_type", "marketing_type_name")
        .withColumnRenamed("marketing_channel", "marketing_channel_name")
        .withColumnRenamed("marketing_sub_channel", "marketing_sub_channel_name")
        .withColumnRenamed("metric", "metric_name")
        .where(F.col("cluster_num").isNotNull())
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "job_run_id",
        )
    )


def merge_pollen_and_dtp_data(
    dv360_processed_data_pollen: DataFrame,
    dv360_processed_data_dtp: DataFrame,
) -> DataFrame:
    """Merge pollen and DTP DV360 processed data, keeping pollen rows when both exist."""
    normalised_columns = [
        "cluster_num",
        "marketing_type_name",
        "marketing_channel_name",
        "marketing_sub_channel_name",
        "metric_name",
    ]
    join_columns = [
        "week_start_dt",
        "super_category_name",
        "unique_brand_name",
        *normalised_columns,
    ]

    pollen_normalized = normalise_pollen_dtp_join_columns(dv360_processed_data_pollen, normalised_columns)
    dtp_normalized = normalise_pollen_dtp_join_columns(dv360_processed_data_dtp, normalised_columns)

    dtp_only_records = dtp_normalized.join(
        pollen_normalized,
        join_columns,
        "left_anti",
    )

    return (
        pollen_normalized
        .unionByName(dtp_only_records)
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            F.col("metric_value").cast(T.DecimalType(18, 5)).alias("metric_value"),
            F.lit("NA").alias("job_run_id"),
            F.current_timestamp().alias("load_ts"),
        )
    )
