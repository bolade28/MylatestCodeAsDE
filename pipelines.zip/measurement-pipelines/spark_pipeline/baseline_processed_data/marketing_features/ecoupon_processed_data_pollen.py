from pyspark.sql import functions as F, types as T, SparkSession
from pyspark.sql import DataFrame
from typing import Optional, List
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData, EcouponConfig
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.stdout_logger import StdOutLogger
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite

logger = StdOutLogger()


# --------------------------------------------------------------------
# 1. Load campaign bookings, filter, and join with sku_cluster_df on item_cd
# --------------------------------------------------------------------
def load_campaign_data(
    campaign_booking_media_channel_df: DataFrame,
    sku_cluster_df: DataFrame,
    start_date: str,
    end_date: str,
) -> DataFrame:
    """
    Loads and filters campaign data, joining campaign bookings with product information.

    Args:
        campaign_booking_media_channel_df: DataFrame with campaign booking details.
        sku_cluster_df: SKU cluster mapping, inner join on item_cd filters to brand SKUs.
        start_date: The start date for filtering campaigns.
        end_date: The end date for filtering campaigns.

    Returns:
        A DataFrame containing filtered onsite campaigns with item, brand, and category details.
    """

    # Filtered campaign bookings with early filtering and column pruning
    cb = (
        campaign_booking_media_channel_df
        .withColumn("item_cd_list", F.from_json(F.col("item_cd_list"), ProcessedData.item_schema))  # Parse JSON string to array
        .filter(
            (F.lower(F.col("channel_type")) == EcouponConfig.CHANNEL_TYPE) &
            (F.lower(F.col("media_provider")) == EcouponConfig.MEDIA_PROVIDER) &
            (F.lower(F.col("booking_status")) == EcouponConfig.BOOKING_STATUS) &
            (F.lower(F.col("media_business_group")).like(EcouponConfig.MEDIA_BUSINESS_GROUP_FILTER)) &
            (F.size(F.col("item_cd_list")) > 0) &
            (~F.col("campaign_id").isin("~~", "-1")) &
            (F.col("booking_media_live_start_dt").between(start_date, end_date)) &
            (F.col("booking_media_live_end_dt").between(start_date, end_date))
        )
        .select(
            "booking_id",
            F.col("campaign_id").alias("master_campaign_id"),
            F.col("booking_media_live_start_dt").alias("campaign_start_date"),
            F.col("booking_media_live_end_dt").alias("campaign_end_date"),
            "media_spend_amt",
            "item_cd_list"
        )
        .dropDuplicates()
        .cache()  # Cache since used in multiple operations
    )

    # Flatten SKUs with optimized column selection
    known_skus = (
        cb
        .withColumn("item", F.explode("item_cd_list"))
        .withColumn("sku_id", F.col("item.skuId").cast("string"))
        .select(
            "booking_id",
            "master_campaign_id",
            "sku_id"
        )
    )

    # Inner join with sku_cluster_df on item_cd to filter to brand skus and get product information
    campaign_items = (
        known_skus
        .join(
            F.broadcast(sku_cluster_df),
            known_skus.sku_id == F.col("item_cd"),
            "inner",
        )
        .select(
            "booking_id",
            "master_campaign_id",
            "item_cd",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
        )
    )

    # Join bookings with campaign_items
    onsite_campaigns = (
        cb.join(
            campaign_items,
            ["booking_id", "master_campaign_id"],
            "left",
        )
        .filter(F.col("unique_brand_name").isNotNull())
        .select(
            "master_campaign_id",
            "campaign_start_date",
            "campaign_end_date",
            "media_spend_amt",
            "item_cd",
            "unique_brand_name",
            F.col("super_category_name"),
            "cluster_num",
        ).distinct()
    )

    return onsite_campaigns


# --------------------------------------------------------------------
# 2. Prepare ecoupon base values, coupon values, and merge
# --------------------------------------------------------------------
def prepare_ecoupon_base(
    onsite_campaigns: DataFrame,
    oc_customer_selection_df: DataFrame,
) -> DataFrame:
    """
    Prepares a base DataFrame for eCoupon performance metrics by calculating
    and aggregating coupon values.

    Args:
        onsite_campaigns: A DataFrame containing filtered onsite campaign data.
        oc_customer_selection_df: DataFrame with eCoupon customer selection details,
                                  used to determine coupon values.

    Returns:
        A DataFrame with aggregated coupon values joined to the base campaign data.
    """
    # Base spend > 0
    base_df = (
        onsite_campaigns.filter(F.col("media_spend_amt") > 0)
        .select(
            F.lit("NA").alias("job_bag_number"),
            F.col("campaign_start_date").alias("base_start_date"),
            F.col("campaign_end_date").alias("base_end_date"),
            F.col("media_spend_amt").alias("base_value"),
            F.col("master_campaign_id").alias("cid"),
            "item_cd",
            "unique_brand_name",
            "super_category_name",
        )
    )

    # Coupon values
    ev = oc_customer_selection_df.select("campaign_id", "coupon_id")
    ev = ev.withColumn(
        "coupon_value",
        F.when(F.col("coupon_id").like(EcouponConfig.COUPON_99_PATTERN), F.substring("coupon_id", -4, 3).cast("double"))
        .when(F.col("coupon_id").like(EcouponConfig.COUPON_28_PATTERN), F.substring(F.col("coupon_id"), 5, 3).cast("double") * 0.5)
        .otherwise(None),
    )

    ev_agg = ev.groupBy("campaign_id").agg(F.sum("coupon_value").alias("coupon_value"))

    # Merge base + value
    perf = (
        base_df.alias("b")
        .join(ev_agg.alias("e"), F.col("b.cid") == F.col("e.campaign_id"), "left")
        .select("b.job_bag_number",
                "b.base_start_date",
                "b.base_end_date",
                "b.base_value",
                "b.cid",
                "b.item_cd",
                "b.unique_brand_name",
                "b.super_category_name",
                "e.coupon_value")
    )
    return perf


# --------------------------------------------------------------------
# 3. Transform into daily → weekly → cluster → unpivot
# --------------------------------------------------------------------
def transform_ecoupon_metrics(
    ecoupon_performance: DataFrame,
    sku_cluster_df: DataFrame,
) -> DataFrame:
    """
    Transforms eCoupon performance data into a detailed, unpivoted format with weekly
    aggregations and cluster information.

    Args:
        ecoupon_performance: DataFrame with eCoupon performance and base values.
        sku_cluster_mapping_df: DataFrame mapping SKUs to their respective clusters.

    Returns:
        A DataFrame with unpivoted metrics, including marketing and cluster details.
    """
    # Expand to daily
    daily = (
        ecoupon_performance.withColumn("number_of_days", F.datediff("base_end_date", "base_start_date") + 1)
        .withColumn("date", F.explode(F.sequence("base_start_date", "base_end_date")))
        .withColumn("daily_coupon_value", F.col("coupon_value") / F.col("number_of_days"))
        .withColumn("daily_base_value", F.col("base_value") / F.col("number_of_days"))
        .select(
            "cid",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "date",
            "daily_coupon_value",
            "daily_base_value",
        )
    )

    # Weekly agg
    weekly = (
        daily.withColumn("week_start_date", F.to_date(F.trunc("date", "week")))
        .groupBy("cid", "item_cd", "super_category_name", "unique_brand_name", "week_start_date")
        .agg(
            F.round(F.sum("daily_coupon_value"), 2).alias("coupon_value"),
            F.round(F.sum("daily_base_value"), 2).alias("base_value"),
        )
    )

    weekly_cluster = (
        weekly.alias("w")
        .join(
            F.broadcast(sku_cluster_df.alias("scm")),
            [
                F.col("w.super_category_name") == F.col("scm.super_category_name"),
                F.col("w.unique_brand_name") == F.col("scm.unique_brand_name"),
                F.upper("w.item_cd") == F.upper("scm.item_cd"),
            ],
            "left",
        )
        .select("w.*", "scm.cluster_num")
    )

    # Unpivot
    unpivot = (
        weekly_cluster.select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "item_cd",
            "cluster_num",
            F.expr("""
                stack(2,
                    'base_value', cast(base_value as double),
                    'coupon_value', cast(coupon_value as double)
                ) as (metric, value_)
            """)
        )
        .withColumn("marketing_type", F.lit(EcouponConfig.MARKETING_TYPE))
        .withColumn("marketing_channel", F.lit(EcouponConfig.MARKETING_CHANNEL))
        .withColumn("marketing_sub_channel", F.lit(EcouponConfig.MARKETING_SUB_CHANNEL))
    )
    return unpivot


# --------------------------------------------------------------------
# Orchestrator
# --------------------------------------------------------------------
def build_ecoupon_processed_data(
    campaign_booking_media_channel_df: DataFrame,
    oc_customer_selection_df: DataFrame,
    sku_cluster_mapping_df: DataFrame,
    start_date: str,
    end_date: str,
    correlation_id: str,
) -> DataFrame:
    """
    Orchestrates the full eCoupon data processing pipeline.

    Args:
        campaign_booking_media_channel_df: DataFrame with campaign booking details.
        oc_customer_selection_df: DataFrame with customer selection data for coupons.
        sku_cluster_mapping_df: DataFrame mapping SKUs to clusters.
        start_date: The start date for the data processing window.
        end_date: The end date for the data processing window.
        correlation_id: A unique identifier for the job run.

    Returns:
        A final DataFrame with aggregated and processed eCoupon metrics.
    """
    onsite_campaigns = (load_campaign_data(
        campaign_booking_media_channel_df,
        sku_cluster_mapping_df,
        start_date,
        end_date
    ))

    ecoupon_perf = (
        prepare_ecoupon_base(onsite_campaigns,
                             oc_customer_selection_df)
    )

    ecoupon_unpivot = (
        transform_ecoupon_metrics(ecoupon_perf,
                                  sku_cluster_mapping_df)
    )

    final_df = (
        ecoupon_unpivot.filter(F.col("cluster_num").isNotNull())
        .groupBy(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "metric",
            "cluster_num",
        )
        .agg(F.sum("value_").alias("metric_value"))
        .withColumn("job_run_id", F.lit(correlation_id))
        .withColumn("load_ts", F.current_timestamp())
        .select(
            F.col("week_start_date").cast(T.DateType()),
            F.col("super_category_name").cast(T.StringType()),
            F.col("unique_brand_name").cast(T.StringType()),
            F.col("cluster_num").cast(T.StringType()),
            F.col("marketing_type"),
            F.col("marketing_channel"),
            F.col("marketing_sub_channel"),
            F.col("metric"),
            F.col("metric_value").cast(T.DecimalType(38, 10)),
            F.col("job_run_id"),
            F.col("load_ts"),
        )
    )

    final_df = (final_df.withColumnRenamed("week_start_date", "week_start_dt")
                .withColumnRenamed("marketing_type", "marketing_type_name")
                .withColumnRenamed("marketing_channel", "marketing_channel_name")
                .withColumnRenamed("marketing_sub_channel", "marketing_sub_channel_name")
                .withColumnRenamed("metric", "metric_name"))

    return final_df


def merge_pollen_and_dtp_data(
        ecoupon_processed_data_pollen: DataFrame,
        ecoupon_processed_data_dtp: DataFrame
) -> DataFrame:
    """
    Merge pollen and dtp ecoupon processed data, with pollen data taking precedence.

    Args:
        ecoupon_processed_data_pollen: Pollen processed data (takes precedence)
        ecoupon_processed_data_dtp: DTP processed data (used only when no pollen match exists)

    Returns:
        DataFrame: Combined data with pollen taking precedence over dtp
    """
    # Normalize pollen data
    ecoupon_data_pollen_normalized = (
        ecoupon_processed_data_pollen
        .select(
            'week_start_dt',
            'metric_value',
            F.col('super_category_name'),
            F.col('unique_brand_name'),
            F.upper(F.col('cluster_num')).alias('cluster_num'),
            F.upper(F.col('marketing_type_name')).alias('marketing_type_name'),
            F.upper(F.col('marketing_channel_name')).alias('marketing_channel_name'),
            F.upper(F.col('marketing_sub_channel_name')).alias('marketing_sub_channel_name'),
            F.upper(F.col('metric_name')).alias('metric_name')
        )
    )

    # Normalize dtp data
    ecoupon_data_dtp_normalized = (
        ecoupon_processed_data_dtp
        .select(
            'week_start_dt',
            'metric_value',
            F.col('super_category_name'),
            F.col('unique_brand_name'),
            F.upper(F.col('cluster_num')).alias('cluster_num'),
            F.upper(F.col('marketing_type_name')).alias('marketing_type_name'),
            F.upper(F.col('marketing_channel_name')).alias('marketing_channel_name'),
            F.upper(F.col('marketing_sub_channel_name')).alias('marketing_sub_channel_name'),
            F.upper(F.col('metric_name')).alias('metric_name')
        )
    )

    # Get dtp records that don't exist in pollen data
    join_conditions = [
        'week_start_dt',
        'super_category_name',
        'unique_brand_name',
        'cluster_num',
        'marketing_type_name',
        'marketing_channel_name',
        'marketing_sub_channel_name',
        'metric_name'
    ]

    dtp_only_records = (
        ecoupon_data_dtp_normalized
        .join(
            ecoupon_data_pollen_normalized,
            join_conditions,
            'left_anti'
        )
    )

    # Combine pollen data (takes precedence) with non-overlapping dtp data
    ecoupon_combined = (
        ecoupon_data_pollen_normalized
        .unionByName(dtp_only_records)
        .select(
            'week_start_dt',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name',
            F.col('metric_value').cast(T.DecimalType(18, 5)),
            F.lit('NA').alias('job_run_id'),
            F.current_timestamp().alias('load_ts')
        )
    )

    return ecoupon_combined


def prepare_ecoupon_processed_data_pollen(
    spark: SparkSession,
    campaign_booking_media_channel_path: str,
    historic_ecoupon_processed_data: str,
    oc_customer_selection_path: str,
    sku_cluster_mapping_path: str,
    output_path: str,
    start_date: str,
    end_date: str,
    correlation_id: str
) -> DataFrame:
    """
    Prepares and processes eCoupon data from various Parquet files,
    writes the result to a specified output path.

    Args:
        spark: The SparkSession object.
        campaign_booking_media_channel_path: S3 path for campaign booking data.
        historic_ecoupon_processed_data: S3 path for historic ecoupon processed data.
        oc_customer_selection_path: S3 path for customer selection data.
        sku_cluster_mapping_path: S3 path for SKU cluster mapping data.
        output_path: The S3 path where the processed data will be written.
        start_date: The start date for the data processing window.
        end_date: The end date for the data processing window.
        correlation_id: A unique identifier for the DAG run.

    Returns:
        The final processed DataFrame.
    """

    campaign_booking_media_channel_df = (
        spark
        .read
        .parquet(campaign_booking_media_channel_path)
        .select(
            'booking_id',
            'campaign_id',
            'channel_type',
            'booking_status',
            'media_provider',
            'media_business_group',
            'media_spend_amt',
            'booking_media_live_start_dt',
            'booking_media_live_end_dt',
            'item_cd_list'
        )
    )

    oc_customer_selection_df = (
        spark.read.parquet(oc_customer_selection_path)
        .select(
            "campaign_id",
            "status",
            "coupon_id"
        )
    )

    sku_cluster_df = load_parquet_dataset(
        spark,
        sku_cluster_mapping_path,
        'sku_cluster_mapping',
        slack_notifier=None,
        columns=BaselineProcessedData.sku_cluster_mapping_cols,
    )

    ecoupon_processed_data_pollen_df = (build_ecoupon_processed_data(
        campaign_booking_media_channel_df,
        oc_customer_selection_df,
        sku_cluster_df,
        start_date,
        end_date,
        correlation_id)
    )

    logger.info(f"ECoupon Processed Data Pollen Count: {ecoupon_processed_data_pollen_df.count()}")

    # Load historic DTP data for merging into pollen if any data is missing
    ecoupon_processed_data_dtp = (
        spark
        .read
        .parquet(historic_ecoupon_processed_data)
    )

    ecoupon_processed_data_final = merge_pollen_and_dtp_data(ecoupon_processed_data_pollen_df, ecoupon_processed_data_dtp)

    ecoupon_processed_data_final = (
        ecoupon_processed_data_final
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "job_run_id",
            "load_ts"
        )
    )

    spark_s3_overwrite(output_path, ecoupon_processed_data_final)

    return ecoupon_processed_data_pollen_df


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    """
    Main entry point for the New Launch Estimation baseline pipeline.

    Args:
        spark: The SparkSession object.
        command_line_args: Optional list of command-line arguments.
    """
    parser = ThrowingArgumentParser(description="New Launch Estimation for baseline pipeline.")
    parser.add_argument(
        "--campaign-booking-media-channel-path",
        type=str,
        required=True,
        help="The S3 path for the campaign booking media channel data."
    )
    parser.add_argument(
        "--historic-ecoupon-processed-data",
        type=str,
        required=True,
        help="The S3 path for historic DTP data for ecoupon."
    )
    parser.add_argument(
        "--oc-customer-selection-path",
        type=str,
        required=True,
        help="The S3 path for the oc customer selection data."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="The S3 path for the sku_cluster_mapping data."
    )
    # TODO: test and receive start and end dates from weekly_dates
    parser.add_argument(
        "--start-date",
        type=str,
        required=True,
        help="This is model start date"
    )
    parser.add_argument(
        "--end-date",
        type=str,
        required=True,
        help="This is model end date"
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The S3 path for the output data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_ecoupon_processed_data_pollen(
        spark=spark,
        campaign_booking_media_channel_path=known_args.campaign_booking_media_channel_path,
        historic_ecoupon_processed_data=known_args.historic_ecoupon_processed_data,
        oc_customer_selection_path=known_args.oc_customer_selection_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        output_path=known_args.output_path,
        start_date=known_args.start_date,
        end_date=known_args.end_date,
        correlation_id=known_args.correlation_id,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("ECouponProcessedDataPollen").getOrCreate())
