from datetime import date
from typing import List, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import DateType

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData, CouponAtTillConfig
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_coupon_at_till_processed(
    spark: SparkSession,
    weekly_dates_path: str,
    sku_cluster_mapping_path: str,
    temp_unified_product_path: str,
    base_finance_assets_path: str,
    coupon_path: str,
    coupon_cell_path: str,
    cell_path: str,
    campaign_path: str,
    coupon_to_product_path: str,
    start_date: str,
    end_date: str,
    output_path: str,
    correlation_id: str,
) -> None:
    """
    * Objective:
    - This script is used to create time series data for coupon at till at cluster level and create feature metrics -
      base_value and coupon_value

    * Business Context:
        - Coupon at Till data is processed to calculate key performance metrics like coupon value and base value.
        - This activity is then tested in the UCM model, which helps the model isolate the impact of marketing to
        calculate Baseline Sales.

    * Lineage:
        Upstream:
            - 14_stored_procedure_call (sku_cluster_mapping_call.sql)
        Downstream:
            - 08_ads_creation (channel_processed_data.sql)
    """

    # Fix for Spark 3.x date/timestamp rebase issue
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")

    # Ensure start_date and end_date are strings
    if isinstance(start_date, date):
        start_date = start_date.strftime("%Y-%m-%d")
    if isinstance(end_date, date):
        end_date = end_date.strftime("%Y-%m-%d")

    weekly_dates_df = (
        spark
        .read
        .parquet(weekly_dates_path)
        .withColumn("week_start_dt", F.col("week_start_dt").cast(DateType()))
    )

    # Load SKU cluster mapping, inner join on item_cd filters to brand SKUs later
    sku_cluster_df = load_parquet_dataset(
        spark,
        sku_cluster_mapping_path,
        'sku_cluster_mapping',
        slack_notifier=None,
        columns=BaselineProcessedData.sku_cluster_mapping_cols,
    )

    temp_unified_product_df = (
        spark
        .read
        .parquet(temp_unified_product_path)
        .select(
            "product_key",
            "item_cd"
        )
    )

    # Legacy campaign source of truth
    base_finance_assets_df = (
        spark
        .read
        .parquet(base_finance_assets_path)
        .select(
            "asset_actual_start_date",
            "asset_actual_end_date",
            "service_type",
            "media_host_name",
            "job_bag_number",
            "timeid",
            "campaign_status",
            "asset_value_unweighted",
            "asset_unique_id"
        )
    )

    coupon_df = (
        spark
        .read
        .parquet(coupon_path)
        .select(
            "coupon_key",
            "start_date",
            "expiry_date",
            "coupon_value"
        )
    )

    coupon_cell_keys_df = (
        spark
        .read
        .parquet(coupon_cell_path)
        .select(
            "cell_key",
            "coupon_key"
        )
    )

    cell_campaign_df = (
        spark
        .read
        .parquet(cell_path)
        .select(
            "campaign_id",
            "cell_key"
        )
    )

    campaign_details_df = (
        spark
        .read
        .parquet(campaign_path)
        .select(
            "campaign_id",
            "pre_period",
            "post_period"
        )
    )

    coupon_to_product_df = (
        spark
        .read
        .parquet(coupon_to_product_path)
        .select(
            "coupon_key",
            "product_key",
            "correct_brand",
            "correct_offer"
        )
    )

    job_run_id = correlation_id
    latest_timeid = base_finance_assets_df.agg(F.max("timeid").alias("timeid"))

    # Retrieving coupon Spend data
    # Filtering for Sainsburys and Coupon at Till channel.
    # Filtering for completed campaigns where spend is greater than 0 which are the required campaigns.
    coupon_base_data = (
        base_finance_assets_df
        .join(F.broadcast(latest_timeid), "timeid", "inner")
        .filter(
            (F.col("asset_actual_start_date").between(start_date, end_date)) &
            (F.col("asset_actual_end_date").between(start_date, end_date)) &
            (F.upper(F.col("service_type")) == CouponAtTillConfig.DTP_SERVICE_TYPE) &
            (F.upper(F.col("media_host_name")).like(CouponAtTillConfig.DTP_MEDIA_HOST_NAME)) &
            (F.col("job_bag_number").isNotNull()) &
            (F.col("campaign_status") == CouponAtTillConfig.DTP_CAMPAIGN_STATUS) &
            (F.col("asset_value_unweighted") > 0)
        )
        .withColumnRenamed("asset_actual_start_date", "base_start_date")
        .withColumnRenamed("asset_actual_end_date", "base_end_date")
        .withColumnRenamed("asset_value_unweighted", "base_value")
        .withColumn("campaign_id", F.expr("right(asset_unique_id, 6)"))
        .select(
            "job_bag_number",
            "base_start_date",
            "base_end_date",
            "base_value",
            "campaign_id"
        )
        .distinct()
    )

    eligible_campaigns = coupon_base_data.select("campaign_id").distinct()

    coupon_key_cid = (
        campaign_details_df
        .join(cell_campaign_df, "campaign_id", "left")
        .join(coupon_cell_keys_df, "cell_key", "left")
        .select(
            "campaign_id",
            "coupon_key",
            "pre_period",
            "post_period"
        )
        .distinct()
    )

    coupon_product_filter = (
        coupon_to_product_df
        .select("coupon_key", "product_key")
        .distinct()
    )

    # We use our temp unified mapping to get the skus from the product key.
    # Then we filter the historic campaigns, for skus that are within our targeted brand skus
    coupon_product_details = (
        coupon_key_cid
        .join(eligible_campaigns, "campaign_id", "left_semi")
        .join(coupon_product_filter, "coupon_key", "left")
        .join(temp_unified_product_df, "product_key", "left")
        .join(
            F.broadcast(
                sku_cluster_df.select(
                    "item_cd",
                    "super_category_name",
                    "unique_brand_name",
                    "cluster_num"
                )
            ),
            "item_cd",
            "inner"
        )
        .filter(
            F.col("product_key").isNotNull()
        )
        .select(
            "campaign_id",
            "coupon_key",
            "pre_period",
            "post_period",
            "super_category_name",
            "unique_brand_name",
            "item_cd",
            "cluster_num",
        )
    )

    coupon_value_data = (
        coupon_key_cid
        .join(eligible_campaigns, "campaign_id", "left_semi")
        .join(coupon_df, "coupon_key", "left")
        .filter(
            F.col("start_date").between(start_date, end_date)
        )
        .groupBy("campaign_id")
        .agg(
            F.min("start_date").alias("start_date"),
            F.max("expiry_date").alias("expiry_date"),
            F.sum("coupon_value").alias("coupon_value")
        )
        .select(
            "campaign_id",
            "start_date",
            "expiry_date",
            "coupon_value",
        )
    )

    coupon_campaign_sku_data = (
        coupon_base_data
        .join(
            coupon_product_details
            .select(
                "campaign_id",
                "item_cd",
                "unique_brand_name",
                "super_category_name",
                "cluster_num"
            ),
            "campaign_id",
            "left"
        )
        .join(
            coupon_value_data,
            "campaign_id",
            "left"
        )
        .select(
            "job_bag_number",
            "campaign_id",
            "base_start_date",
            "base_end_date",
            "start_date",
            "expiry_date",
            "base_value",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "coupon_value",
        )
        .withColumn(
            "number_of_days",
            F.datediff(F.col("base_end_date"), F.col("base_start_date")) + F.lit(1)
        )
        .distinct()
    )

    campaign_sku_count = (
        coupon_campaign_sku_data
        .groupBy("campaign_id")
        .agg(F.countDistinct("item_cd").alias("skus_per_camp"))
        .filter(F.col("skus_per_camp") != 0)
        .select("campaign_id", "skus_per_camp")
    )

    coupon_overall = (
        coupon_campaign_sku_data
        .join(
            campaign_sku_count,
            "campaign_id",
            "inner"
        )
        .select(
            "job_bag_number",
            "campaign_id",
            "base_start_date",
            "base_end_date",
            "start_date",
            "expiry_date",
            "base_value",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "coupon_value",
            "number_of_days",
            "skus_per_camp",
        )
        .withColumn("coupon_value_split", F.col("coupon_value") / F.col("skus_per_camp"))
        .withColumn("base_value_split", F.col("base_value") / F.col("skus_per_camp"))
    )

    coupon_overall_daily = (
        coupon_overall
        .withColumn(
            "date",
            F.explode(
                F.sequence(
                    F.col("base_start_date"),
                    F.expr("date_add(base_start_date, number_of_days - 1)")
                )
            )
        )
        .withColumn("date", F.date_format("date", "yyyy-MM-dd"))
        .withColumn("daily_coupon_value", F.col("coupon_value_split") / F.col("number_of_days"))
        .withColumn("daily_base_value", F.col("base_value_split") / F.col("number_of_days"))
    )

    coupon_overall_weekly = (
        coupon_overall_daily
        .withColumn("week_start_date", F.date_trunc("week", F.col("date")))
        .groupBy(
            "item_cd", "super_category_name", "unique_brand_name", "job_bag_number", "cluster_num", "week_start_date"
        )
        .agg(
            F.round(F.sum("daily_coupon_value"), 2).alias("coupon_value"),
            F.round(F.sum("daily_base_value"), 2).alias("base_value")
        )
        .withColumnRenamed("job_bag_number", "campaign_name")
        .select(
            "item_cd",
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "campaign_name",
            "cluster_num",
            "coupon_value",
            "base_value"
        )
    )

    coupon_overall_weekly_marketing = (
        coupon_overall_weekly
        .withColumn("marketing_type", F.lit(CouponAtTillConfig.MARKETING_TYPE))
        .withColumn("marketing_channel", F.lit(CouponAtTillConfig.MARKETING_CHANNEL))
        .withColumn("marketing_sub_channel", F.lit(CouponAtTillConfig.MARKETING_SUB_CHANNEL))
    )

    # Instead of using a stack function, we create two separate dataframes for base_value and coupon_value and then union them together to unpivot the data.
    coupon_base_value_rows = (
        coupon_overall_weekly_marketing
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "item_cd",
            "campaign_name",
            "cluster_num",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "base_value"
        )
        .withColumn("metric", F.lit("base_value"))
        .withColumn("value_", F.col("base_value").cast("decimal(35,2)"))
        .drop("base_value")
    )

    coupon_coupon_value_rows = (
        coupon_overall_weekly_marketing
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "item_cd",
            "campaign_name",
            "cluster_num",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "coupon_value"
        )
        .withColumn("metric", F.lit("coupon_value"))
        .withColumn("value_", F.col("coupon_value").cast("decimal(35,2)"))
        .drop("coupon_value")
    )

    # Melt (unpivot) base_value and coupon_value
    coupon_unpivot = coupon_base_value_rows.unionByName(coupon_coupon_value_rows)

    # Aggregate after melting
    coupon_at_till_unique_brand = (
        coupon_unpivot
        .groupBy(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "metric",
            "cluster_num"
        )
        .agg(F.sum("value_").alias("value_"))
    )

    # Retrieve Date Skeleton
    temp_date_dataset = (
        weekly_dates_df
        .withColumnRenamed("week_start_dt", "week_start_date")
        .select("week_start_date")
    )

    # Create Skeleton
    coupon_at_till_unique_brand_cluster_skele = (
        coupon_at_till_unique_brand
        .select(
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "cluster_num",
            "metric"
        ).distinct()
    )

    # Cross join to create complete skeleton
    coupon_at_till_unique_brand_cluster_skele_final = (
        temp_date_dataset.crossJoin(coupon_at_till_unique_brand_cluster_skele)
    )

    coupon_join_columns = [
        "week_start_date",
        "super_category_name",
        "unique_brand_name",
        "marketing_type",
        "marketing_channel",
        "marketing_sub_channel",
        "metric",
        "cluster_num",
    ]

    # Merge with main data to create complete skeleton and impute missing values
    coupon_at_till_processed_data = (
        coupon_at_till_unique_brand_cluster_skele_final
        .join(coupon_at_till_unique_brand, coupon_join_columns, "left")
        .filter(F.col("cluster_num").isNotNull())
        .withColumn("value_", F.coalesce(F.col("value_"), F.lit(0)))
        .withColumn("job_run_id", F.lit(job_run_id))
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "cluster_num",
            "metric",
            "value_",
            "job_run_id"
        )
    )

    coupon_at_till_processed_data = (
        coupon_at_till_processed_data
        .withColumnRenamed("week_start_date", "week_start_dt")
        .withColumnRenamed("marketing_type", "marketing_type_name")
        .withColumnRenamed("marketing_channel", "marketing_channel_name")
        .withColumnRenamed("marketing_sub_channel", "marketing_sub_channel_name")
        .withColumnRenamed("metric", "metric_name")
        .withColumnRenamed("value_", "metric_value")
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "job_run_id"
        )
    )

    # Write the final output to s3
    spark_s3_overwrite(output_path, coupon_at_till_processed_data)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare  processed data for Coupon at till in baseline pipeline.")
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="The S3 path for the weekly dates."
    )
    parser.add_argument(
        "--base-finance-assets-path",
        type=str,
        required=True,
        help="The S3 path for the base finance assets data."
    )
    parser.add_argument(
        "--campaign-path",
        type=str,
        required=True,
        help="The S3 path for the campaign data."
    )
    parser.add_argument(
        "--cell-path",
        type=str,
        required=True,
        help="The S3 path for the cell data."
    )
    parser.add_argument(
        "--coupon-cell-path",
        type=str,
        required=True,
        help="The S3 path for the coupon cell data."
    )
    parser.add_argument(
        "--coupon-to-product-path",
        type=str,
        required=True,
        help="The S3 path for the coupon to product mapping data."
    )
    parser.add_argument(
        "--coupon-path",
        type=str,
        required=True,
        help="The S3 path for the coupon data."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="The S3 path for the sku_cluster_mapping data."
    )
    parser.add_argument(
        "--temp-unified-product-path",
        type=str,
        required=True,
        help="The S3 path for the temporary unified product data."
    )
    # TODO: test and receive start and end dates from weekly_dates
    parser.add_argument(
        "--start-date",
        type=str,
        required=True,
        help="This is model start date"
    )
    parser.add_argument(
        "--end-date",
        type=str,
        required=True,
        help="This is model end date"
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The S3 path for the output data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_coupon_at_till_processed(
        spark=spark,
        weekly_dates_path=known_args.weekly_dates_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        temp_unified_product_path=known_args.temp_unified_product_path,
        base_finance_assets_path=known_args.base_finance_assets_path,
        coupon_path=known_args.coupon_path,
        coupon_cell_path=known_args.coupon_cell_path,
        cell_path=known_args.cell_path,
        campaign_path=known_args.campaign_path,
        coupon_to_product_path=known_args.coupon_to_product_path,
        start_date=known_args.start_date,
        end_date=known_args.end_date,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("CouponAtTillProcessedData").getOrCreate())
