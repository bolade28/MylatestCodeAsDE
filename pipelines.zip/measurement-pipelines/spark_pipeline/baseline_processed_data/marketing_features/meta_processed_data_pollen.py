from typing import List, Optional
from pyspark.sql import SparkSession, functions as F
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data_helper import (
    read_s3_data,
    build_meta_required_campaigns,
    build_meta_required_campaigns_columns,
    build_meta_reqd_metrics,
    build_meta_reqd_metrics_jb,
    build_meta_metrics_jb_sku_pre,
    build_meta_num_skus,
    build_meta_camp_skus_split,
    build_meta_camp_cluster,
    build_meta_unique_brand_cluster,
    build_meta_unique_brand_cluster_unpivot,
    format_meta_processed_data,
    merge_pollen_and_dtp_data
)
from spark_pipeline.utils.stdout_logger import StdOutLogger
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


logger = StdOutLogger()


def prepare_meta_processed_data(
    spark: SparkSession,
    fb_campaign_normalize_pollen_path: str,
    fb_insight_normalize_path: str,
    sku_cluster_mapping_path: str,
    historic_meta_processed_data: str,
    output_path: str
) -> None:
    """
    * Objective:
    - This script is used to create time series data for Pollen Meta campaigns at cluster level and create feature metrics using pyspark -
      clicks, impressions, external_spends, internal_spends etc..

    * Business Context:
    - Meta-data is processed to calculate key performance metrics like internal_media_spend, external_media_spend,
      impressions, clicks, sales_online, sales_instore, total_sales.
    - This activity is then tested in the UCM model, which helps the model isolate the impact of marketing to
      calculate Baseline Sales.

    :param spark: The SparkSession object.
    :param fb_campaign_normalize_pollen_path: The S3 path for the facebook campaign normalize pollen table .
    :param fb_insight_normalize_path: The S3 path for the fb_insight_normalize_path table.
    :param sku_cluster_mapping_path: The S3 path for the sku clustering table.
    :param historic_meta_processed_data: The historic Meta processed data path, in case we don't have enough data in pollen.
    :param output_path: The S3 path for the output of Meta processed table.
    :return: None
    """

    # Read all S3 data with unified function for POLLEN branch (includes historic DTP data)
    (meta_camp_skus,
     meta_metrics,
     sku_cluster_df,
     _,
     meta_processed_data_dtp) = read_s3_data(
        spark,
        fb_campaign_normalize_pollen_path,
        fb_insight_normalize_path,
        sku_cluster_mapping_path,
        'POLLEN',
        historic_meta_processed_data_path=historic_meta_processed_data
    )

    # Process POLLEN data through transformation pipeline
    meta_required_campaigns = build_meta_required_campaigns(meta_camp_skus, sku_cluster_df)
    meta_required_campaigns_columns = build_meta_required_campaigns_columns(meta_required_campaigns)
    meta_reqd_metrics = build_meta_reqd_metrics(meta_metrics, meta_required_campaigns_columns)
    meta_reqd_metrics_jb = build_meta_reqd_metrics_jb(meta_reqd_metrics)
    meta_metrics_jb_sku = build_meta_metrics_jb_sku_pre(meta_reqd_metrics_jb, meta_required_campaigns)
    meta_num_skus = build_meta_num_skus(meta_metrics_jb_sku)
    meta_camp_skus_split = build_meta_camp_skus_split(meta_metrics_jb_sku, meta_num_skus)
    meta_camp_cluster = build_meta_camp_cluster(meta_camp_skus_split, sku_cluster_df)
    meta_unique_brand_cluster = build_meta_unique_brand_cluster(meta_camp_cluster)
    meta_unique_brand_cluster_unpivot = build_meta_unique_brand_cluster_unpivot(meta_unique_brand_cluster)

    # Format POLLEN processed data
    meta_processed_data_pollen = format_meta_processed_data(meta_unique_brand_cluster_unpivot)

    # Check unique week count for each brand in pollen data
    agg_pollen = (
        meta_processed_data_pollen
        .groupBy("super_category_name", "unique_brand_name", "metric_name")
        .agg(
            F.countDistinct("week_start_dt").alias("unique_week_count"),
            F.sum("metric_value").alias("total_metric_value")
        )
    )

    agg_pollen.show(100, truncate=False)

    # Merge pollen and historic dtp data
    final_meta_processed_data = merge_pollen_and_dtp_data(meta_processed_data_pollen, meta_processed_data_dtp)

    final_meta_processed_data = final_meta_processed_data.cache()
    logger.info(f"meta_processed_data_pollen Count: {meta_processed_data_pollen.count()}")
    logger.info(f"meta_processed_data_dtp Count: {meta_processed_data_dtp.count()}")
    logger.info(f"final_meta_processed_data after joining with DTP Count: {final_meta_processed_data.count()}")

    spark_s3_overwrite(output_path, final_meta_processed_data)


def entrypoint(spark: SparkSession,
               command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Meta processed data for baseline pipeline.")

    parser.add_argument("--fb-campaign-normalize-pollen-path",
                        type=str,
                        required=True,
                        help="The S3 path for the facebook campaign normalize pollen table.")
    parser.add_argument("--fb-insight-normalize-path",
                        type=str,
                        required=True,
                        help="The S3 path for the facebook insight normalize table.")

    parser.add_argument("--sku-cluster-mapping-path",
                        type=str,
                        required=True,
                        help="The S3 path for the sku cluster mapping table.")

    parser.add_argument("--historic-meta-processed-data",
                        type=str,
                        required=True,
                        help="The S3 path for the historic meta processed data.")

    parser.add_argument("--output-path",
                        type=str,
                        required=True,
                        help="The S3 path for the output of meta processed data.")

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_meta_processed_data(
        spark=spark,
        fb_campaign_normalize_pollen_path=known_args.fb_campaign_normalize_pollen_path,
        fb_insight_normalize_path=known_args.fb_insight_normalize_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        historic_meta_processed_data=known_args.historic_meta_processed_data,
        output_path=known_args.output_path,
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder.appName("MetaProcessedData").getOrCreate())
