from typing import List, Optional, Tuple
from pyspark.sql import functions as F, types as T, SparkSession, DataFrame

from spark_pipeline.common.variables import BaselineProcessedData, YoutubeConfig
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.stdout_logger import StdOutLogger
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite

logger = StdOutLogger()


# --- Helper Functions ---
def read_s3_data(
    spark: SparkSession,
    youtube_normalised_path: str,
    sku_cluster_mapping_path: str,
    dv360_media_report_path: str,
    historic_youtube_processed_data: str
) -> Tuple[DataFrame, DataFrame, DataFrame, DataFrame]:
    """
    Reads all necessary input DataFrames from S3 paths for YouTube processing.
    """
    youtube_normalised_df = (
        spark.read.parquet(youtube_normalised_path).select(
            "start_dt",
            "end_dt",
            "item_cd",
            "booking_id",
            "campaign_id"
        )
    )
    sku_cluster_df = load_parquet_dataset(
        spark,
        sku_cluster_mapping_path,
        'sku_cluster_mapping',
        slack_notifier=None,
        columns=BaselineProcessedData.sku_cluster_mapping_cols,
    )

    # DV360 media report used for YouTube metrics later
    dv360_media_report_df = (
        spark.read.parquet(dv360_media_report_path).select(
            "campaign_id",
            "insertion_order_id",
            "campaign_date",
            "measurable_impressions",
            "viewable_impressions",
            "clicks",
            "impressions",
            "revenue"
        )
    )

    youtube_processed_data_dtp = (
        spark
        .read
        .parquet(historic_youtube_processed_data)
    )

    return (
        youtube_normalised_df,
        sku_cluster_df,
        dv360_media_report_df,
        youtube_processed_data_dtp
    )


def get_yt_required_campaigns(
    youtube_normalised_df: DataFrame,
    sku_cluster_df: DataFrame
) -> DataFrame:
    """
    Inner join YouTube normalized with sku_cluster_df on item_cd to filter for brand SKUs
    and enrich with product information.
    """
    return (
        youtube_normalised_df
        .join(sku_cluster_df, "item_cd", "inner")
        .select(
            "start_dt",
            "end_dt",
            "item_cd",
            "booking_id",
            "campaign_id",
            "super_category_name",
            "unique_brand_name"
        )
        .distinct()
    )


def get_youtube_media_data(media_report_df: DataFrame, yt_required_campaigns: DataFrame) -> DataFrame:
    """
    Filter DV360 media report for relevant YouTube campaigns and aggregate weekly.
    """

    media_report_intermediate_df = (
        media_report_df
        .join(
            yt_required_campaigns.select("campaign_id").distinct(),
            on="campaign_id",
            how="inner"  # only keep rows with matching campaign_id
        )
    )

    # ToDo not sure which is the proper column to join on, uses campaign_id falls back to insertion_order_id if needed
    if media_report_intermediate_df.isEmpty():
        media_report_df = (
            media_report_df
            .drop("campaign_id")
            .withColumnRenamed('insertion_order_id', 'campaign_id')
        )

        media_report_intermediate_df = (
            media_report_df
            .join(
                yt_required_campaigns.select("campaign_id").distinct(),
                on="campaign_id",
                how="inner"  # only keep rows with matching campaign_id
            )
        )

    return (
        media_report_intermediate_df
        .withColumn("week_start_date", F.date_trunc("week", F.col("campaign_date")))
        .groupBy("campaign_id", "week_start_date")
        .agg(
            F.sum("impressions").alias("impressions"),
            F.sum("clicks").alias("clicks"),
            F.sum("revenue").alias("campaign_spend"),
            F.sum("measurable_impressions").alias("measurable_impressions"),
            F.sum("viewable_impressions").alias("viewable_impressions")
        )
        .select(
            "campaign_id",
            "week_start_date",
            "impressions",
            "clicks",
            "campaign_spend",
            "measurable_impressions",
            "viewable_impressions"
        )
    )


def build_youtube_metrics_jb_sku(
    yt_metrics: DataFrame,
    yt_required_campaigns: DataFrame,
    sku_cluster_df: DataFrame
) -> DataFrame:
    """
    Build weekly booking_id + SKU metrics with brand and super category.
    """

    # Get the distinct campaigns
    yt_required_campaigns_columns = (
        yt_required_campaigns
        .select("booking_id", "campaign_id")
        .distinct()
    )

    # Join metrics with the required campaigns
    yt_reqd_metrics = (
        yt_metrics
        .join(
            yt_required_campaigns_columns,
            on="campaign_id",
            how="inner"
        )
        .select(
            "campaign_id",
            "week_start_date",
            "impressions",
            "clicks",
            "campaign_spend",
            "measurable_impressions",
            "viewable_impressions",
            "booking_id"
        )
    )

    # Aggregate at the weekly level
    yt_reqd_metrics_jb = (
        yt_reqd_metrics
        .groupBy("week_start_date", "booking_id")
        .agg(
            F.sum("impressions").alias("impressions"),
            F.sum("clicks").alias("clicks"),
            F.sum("campaign_spend").alias("campaign_spend"),
            F.sum("measurable_impressions").alias("measurable_impressions"),
            F.sum("viewable_impressions").alias("viewable_impressions")
        )
    )

    # Add SKU information
    yt_metrics_jb_sku_pre = (
        yt_reqd_metrics_jb
        .join(
            yt_required_campaigns.select("booking_id", "item_cd"),
            on="booking_id",
            how="left"
        )
        .select(
            "week_start_date",
            "booking_id",
            "impressions",
            "clicks",
            "campaign_spend",
            "measurable_impressions",
            "viewable_impressions",
            "item_cd"
        )
    )

    # Add product information from sku_cluster_df
    yt_metrics_jb_sku = (
        yt_metrics_jb_sku_pre
        .join(
            sku_cluster_df.select("item_cd", "super_category_name", "unique_brand_name"),
            on="item_cd",
            how="left"
        )
        .select(
            "week_start_date",
            "booking_id",
            "impressions",
            "clicks",
            "campaign_spend",
            "measurable_impressions",
            "viewable_impressions",
            "item_cd",
            "super_category_name",
            "unique_brand_name"
        )
    )

    return yt_metrics_jb_sku


def calculate_sku_counts(metrics_with_sku: DataFrame) -> DataFrame:
    """Calculate number of SKUs per campaign for scaling"""
    return metrics_with_sku.groupBy("booking_id").agg(F.countDistinct("item_cd").alias("number_of_skus"))


def scale_metrics_to_sku_level(metrics_with_sku: DataFrame, sku_counts: DataFrame) -> DataFrame:
    """Scale campaign metrics to SKU level"""
    return (
        metrics_with_sku
        .join(sku_counts, "booking_id", "left")
        .withColumn("impressions", F.coalesce(F.col("impressions") / F.col("number_of_skus"), F.lit(0)))
        .withColumn("clicks", F.coalesce(F.col("clicks") / F.col("number_of_skus"), F.lit(0)))
        .withColumn("campaign_spend", F.coalesce(F.col("campaign_spend") / F.col("number_of_skus"), F.lit(0)))
        .withColumn("measurable_impressions", F.coalesce(F.col("measurable_impressions") / F.col("number_of_skus"), F.lit(0)))
        .withColumn("viewable_impressions", F.coalesce(F.col("viewable_impressions") / F.col("number_of_skus"), F.lit(0)))
        .select(
            "week_start_date",
            "booking_id",
            "item_cd",
            "unique_brand_name",
            "super_category_name",
            "number_of_skus",
            "impressions",
            "clicks",
            "campaign_spend",
            "measurable_impressions",
            "viewable_impressions"
        )
    )


def join_cluster_info(camp_skus_split: DataFrame, sku_cluster_df: DataFrame) -> DataFrame:
    """Join weekly metrics with cluster information"""
    return (
        camp_skus_split
        .join(
            sku_cluster_df,
            on=['super_category_name', 'unique_brand_name', 'item_cd'],
            how='left'
        )
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "impressions",
            "clicks",
            "campaign_spend",
            "measurable_impressions",
            "viewable_impressions"
        )
    )


def aggregate_to_cluster_level(cluster_pre: DataFrame) -> DataFrame:
    """Aggregate metrics to cluster level"""
    return (
        cluster_pre
        .groupBy("week_start_date", "super_category_name", "unique_brand_name", "cluster_num")
        .agg(
            F.sum("impressions").alias("impressions"),
            F.sum("clicks").alias("clicks"),
            F.sum("campaign_spend").alias("campaign_spend"),
            F.sum("measurable_impressions").alias("measurable_impressions"),
            F.sum("viewable_impressions").alias("viewable_impressions")
        )
    )


def unpivot_metrics(cluster_metrics: DataFrame) -> DataFrame:
    """Unpivot metrics for final long output format"""
    metrics = ["impressions", "clicks", "measurable_impressions", "viewable_impressions", "campaign_spend"]
    metric_arrays = [F.struct(F.lit(metric).alias("metric"), F.col(metric).alias("value")) for metric in metrics]

    return (
        cluster_metrics
        .withColumn("metric_array", F.array(*metric_arrays))
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            F.explode("metric_array").alias("metric_data")
        )
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "metric_data.metric",
            "metric_data.value",
            F.lit(YoutubeConfig.MARKETING_TYPE).alias("marketing_type"),
            F.lit(YoutubeConfig.MARKETING_CHANNEL).alias("marketing_channel"),
            F.lit(YoutubeConfig.MARKETING_SUB_CHANNEL).alias("marketing_sub_channel")
        )
    )


def create_final_output(cluster_unpivot: DataFrame, correlation_id: str) -> DataFrame:
    """Create final output by filling in any missing values and adding meta data"""
    return (
        cluster_unpivot
        .withColumn("value_", F.coalesce(F.col("value"), F.lit(0)))
        .withColumn("job_run_id", F.lit(correlation_id))
        .where(F.col("cluster_num").isNotNull())
        .withColumnRenamed('week_start_date', 'week_start_dt')
        .withColumnRenamed('marketing_type', 'marketing_type_name')
        .withColumnRenamed('marketing_channel', 'marketing_channel_name')
        .withColumnRenamed('marketing_sub_channel', 'marketing_sub_channel_name')
        .withColumnRenamed('metric', 'metric_name')
        .withColumnRenamed('value_', 'metric_value')
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "job_run_id"
        )
    )


def merge_pollen_and_dtp_data(
        youtube_processed_data_pollen: DataFrame,
        youtube_processed_data_dtp: DataFrame
) -> DataFrame:
    """
    Merge pollen and dtp youtube processed data, with pollen data taking precedence.

    Args:
        youtube_processed_data_pollen: Pollen processed data (takes precedence)
        youtube_processed_data_dtp: DTP processed data (used only when no pollen match exists)

    Returns:
        DataFrame: Combined data with pollen taking precedence over dtp
    """
    # Normalize pollen data
    youtube_data_pollen_normalized = (
        youtube_processed_data_pollen
        .select(
            'week_start_dt',
            'metric_value',
            F.col('super_category_name'),
            F.col('unique_brand_name'),
            F.upper(F.col('cluster_num')).alias('cluster_num'),
            F.upper(F.col('marketing_type_name')).alias('marketing_type_name'),
            F.upper(F.col('marketing_channel_name')).alias('marketing_channel_name'),
            F.upper(F.col('marketing_sub_channel_name')).alias('marketing_sub_channel_name'),
            F.upper(F.col('metric_name')).alias('metric_name')
        )
    )

    # Normalize dtp data
    youtube_data_dtp_normalized = (
        youtube_processed_data_dtp
        .select(
            'week_start_dt',
            'metric_value',
            F.col('super_category_name'),
            F.col('unique_brand_name'),
            F.upper(F.col('cluster_num')).alias('cluster_num'),
            F.upper(F.col('marketing_type_name')).alias('marketing_type_name'),
            F.upper(F.col('marketing_channel_name')).alias('marketing_channel_name'),
            F.upper(F.col('marketing_sub_channel_name')).alias('marketing_sub_channel_name'),
            F.upper(F.col('metric_name')).alias('metric_name')
        )
    )

    # Get dtp records that don't exist in pollen data
    join_conditions = [
        'week_start_dt',
        'super_category_name',
        'unique_brand_name',
        'cluster_num',
        'marketing_type_name',
        'marketing_channel_name',
        'marketing_sub_channel_name',
        'metric_name'
    ]

    dtp_only_records = (
        youtube_data_dtp_normalized
        .join(
            youtube_data_pollen_normalized,
            join_conditions,
            'left_anti'
        )
    )

    # Combine pollen data (takes precedence) with non-overlapping dtp data
    youtube_combined = (
        youtube_data_pollen_normalized
        .unionByName(dtp_only_records)
        .select(
            'week_start_dt',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name',
            F.col('metric_value').cast(T.DecimalType(18, 5)),
            F.lit('NA').alias('job_run_id'),
            F.current_timestamp().alias('load_ts')
        )
    )

    return youtube_combined


# --- Main Orchestration Function ---
def prepare_youtube_processed_data(
    spark: SparkSession,
    youtube_normalised_path: str,
    sku_cluster_mapping_path: str,
    dv360_media_report_path: str,
    historic_youtube_processed_data: str,
    output_path: str,
    correlation_id: str,
) -> DataFrame:
    """
    End-to-end preparation of YouTube processed data
    It creates the channel specific metrics that will be used as features into downstream
    baseline models.

    It takes campaign data and merges it with channel specific metric data
    scaling on the sku level and aggregating on the brand x super category x cluster level x weekly level
    """

    # Read all input data
    (
        youtube_normalised_df,
        sku_cluster_df,
        dv360_media_report_df,
        youtube_processed_data_dtp
    ) = read_s3_data(
        spark,
        youtube_normalised_path=youtube_normalised_path,
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        dv360_media_report_path=dv360_media_report_path,
        historic_youtube_processed_data=historic_youtube_processed_data
    )

    # Gets Youtube campaigns filtered by brand SKUs via inner join on item_cd
    yt_required_campaigns = get_yt_required_campaigns(youtube_normalised_df, sku_cluster_df)

    # Gets Youtube media data for relevant campaigns and aggregate them
    yt_metrics = get_youtube_media_data(dv360_media_report_df, yt_required_campaigns)

    # Join with SKU information
    metrics_with_sku = build_youtube_metrics_jb_sku(yt_metrics, yt_required_campaigns, sku_cluster_df)

    # Calculate SKU counts per campaign
    sku_counts = calculate_sku_counts(metrics_with_sku)

    # Scale metrics to SKU level
    scaled_metrics = scale_metrics_to_sku_level(metrics_with_sku, sku_counts)

    # Join with cluster info (sku_cluster_df already loaded, no load_ts filtering needed)
    yt_campaign_cluster = join_cluster_info(scaled_metrics, sku_cluster_df)

    # Aggregate to cluster level
    cluster_metrics = aggregate_to_cluster_level(yt_campaign_cluster)

    # Unpivot metrics to create data in long format for final output
    cluster_unpivot = unpivot_metrics(cluster_metrics)

    # Creates final output
    final_result_df = create_final_output(cluster_unpivot, correlation_id)

    final_result_df.printSchema()

    # Testing - To check unique week count for each brand in pollen data
    agg_pollen = (
        final_result_df
        .groupBy("super_category_name", "unique_brand_name", "metric_name")
        .agg(
            F.countDistinct("week_start_dt").alias("unique_week_count"),
            F.sum("metric_value").alias("total_metric_value")
        )
    )

    agg_pollen.show(100, truncate=False)

    # Merge pollen and historic dtp data to create final youtube processed data
    final_youtube_processed_data = merge_pollen_and_dtp_data(final_result_df, youtube_processed_data_dtp)

    final_youtube_processed_data = final_youtube_processed_data.cache()
    logger.info(f"YOUTUBE_PROCESSED_POLLEN_DATA Count: {final_result_df.count()}")

    logger.info(f"YOUTUBE_PROCESSED_DATA Count: {final_youtube_processed_data.count()}")

    spark_s3_overwrite(output_path, final_youtube_processed_data)
    return final_result_df


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare YouTube processed data for baseline pipeline.")
    parser.add_argument(
        "--youtube-normalize-path",
        type=str,
        required=True,
        help="S3 path for youtube normalised (YOUTUBE_NORMALIZE_UP) data."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="S3 path for SKU cluster mapping."
    )
    parser.add_argument(
        "--dv360-media-report-path",
        type=str,
        required=True,
        help="S3 path for DV360 media report (used for YouTube metrics)."
    )
    parser.add_argument(
        "--historic-youtube-processed-data",
        type=str,
        required=True,
        help="S3 path for historic YouTube processed data (DTP)."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path to output the YouTube processed data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    _ = prepare_youtube_processed_data(
        spark=spark,
        youtube_normalised_path=known_args.youtube_normalize_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        dv360_media_report_path=known_args.dv360_media_report_path,
        historic_youtube_processed_data=known_args.historic_youtube_processed_data,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("YouTubeProcessedData").getOrCreate())
