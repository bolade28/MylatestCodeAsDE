from typing import Tuple, Optional
from pyspark.sql import SparkSession, DataFrame, functions as F, types as T
from pyspark.sql.functions import lit
from spark_pipeline.common.variables import BaselineProcessedData, MetaConfig
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset


def read_s3_data(
    spark: SparkSession,
    fb_campaign_normalize_path: str,
    fb_insight_normalize_path: str,
    sku_cluster_mapping_path: str,
    branch_type: str,
    weekly_dates_path: Optional[str] = None,
    historic_meta_processed_data_path: Optional[str] = None
) -> Tuple[DataFrame, DataFrame, DataFrame, Optional[DataFrame], Optional[DataFrame]]:
    """
    Reads all necessary input DataFrames from S3 paths.

    :param fb_campaign_normalize_path: S3 path for facebook normalised.
    :param fb_insight_normalize_path: S3 path for facebook insight normalised.
    :param sku_cluster_mapping_path: S3 path for SKU_CLUSTER_MAPPING.
    :param branch_type: Branch type indicator. Accepts 'DTP' or 'POLLEN'.
    :param weekly_dates_path: S3 path for weekly dates (required for DTP branch).
    :param historic_meta_processed_data_path: S3 path for historic meta processed data (required for POLLEN branch).
    :return: A tuple containing (meta_camp_skus, meta_metrics, sku_cluster_df, weekly_dates, historic_meta_processed_data).
    """

    # Determine join column based on branch type
    join_column = 'jobbagid' if branch_type.upper() == 'DTP' else 'booking_id'

    # Get the targeted SKUs from pollen or dtp campaign details
    meta_camp_skus = (
        spark
        .read
        .parquet(fb_campaign_normalize_path)
        .withColumn('item_cd_upper', F.upper(F.col('item_cd')))
        .select(
            F.col(join_column).alias('job_id'),
            'campaign_id',
            'start_dt',
            'end_dt',
            'item_cd',
            'item_cd_upper'
        )
        .distinct()
    )

    # Retrieve and aggregate meta metrics
    meta_metrics = (
        spark
        .read
        .parquet(fb_insight_normalize_path)
        .withColumn('week_start_date', F.date_trunc('week', 'start_dt'))
        .groupBy('campaign_id', 'week_start_date')
        .agg(
            F.sum('clicks').alias('clicks'),
            F.sum('impressions').alias('impressions'),
            F.sum('internals_media_spend').alias('internals_media_spend'),
            F.sum('externals_media_spend').alias('externals_media_spend')
        )
        .select(
            'campaign_id',
            'week_start_date',
            'clicks',
            'impressions',
            'internals_media_spend',
            'externals_media_spend'
        )
    )

    # Load SKU cluster mapping brings in unique_brand_name, super_category_name, cluster_num
    sku_cluster_df = load_parquet_dataset(
        spark,
        sku_cluster_mapping_path,
        'sku_cluster_mapping',
        slack_notifier=None,
        columns=BaselineProcessedData.sku_cluster_mapping_cols,
    )

    # Branch-specific reads
    if branch_type.upper() == 'DTP':
        if weekly_dates_path is None:
            raise ValueError('weekly_dates_path is required for DTP branch')
        weekly_dates = (
            spark.read.parquet(weekly_dates_path)
            .withColumn('week_start_dt', F.to_date('week_start_dt'))
            .select('week_start_dt')
        )
        historic_meta_processed_data = None
    else:  # This branch will always be pollen
        if historic_meta_processed_data_path is None:
            raise ValueError('historic_meta_processed_data_path is required for POLLEN branch')
        weekly_dates = None
        historic_meta_processed_data = spark.read.parquet(historic_meta_processed_data_path)

    return (
        meta_camp_skus,
        meta_metrics,
        sku_cluster_df,
        weekly_dates,
        historic_meta_processed_data
    )


def build_meta_required_campaigns(
    meta_camp_skus: DataFrame,
    sku_cluster_df: DataFrame
) -> DataFrame:
    """
    Inner join campaign SKUs with sku_cluster_df on item_cd, filters to brand SKUs
    and brings in super_category_name and unique_brand_name.
    """
    sku_cluster_lookup = (
        sku_cluster_df
        .select(
            'item_cd',
            'super_category_name',
            'unique_brand_name'
        )
        .distinct()
    )
    return (
        meta_camp_skus
        .join(
            sku_cluster_lookup,
            on='item_cd',
            how='inner'
        )
        .select(
            'job_id',
            'campaign_id',
            'start_dt',
            'end_dt',
            'item_cd',
            'item_cd_upper',
            'super_category_name',
            'unique_brand_name',
        )
    )


def build_meta_required_campaigns_columns(meta_required_campaigns: DataFrame) -> DataFrame:
    """
    Get distinct job_id and campaign_id for required campaigns.
    """
    return meta_required_campaigns.select('job_id', 'campaign_id').distinct()


def build_meta_reqd_metrics(
    meta_metrics: DataFrame,
    meta_required_campaigns_columns: DataFrame
) -> DataFrame:
    """
    Filter meta metrics to only required campaigns.
    """
    required_campaign_jobs = (
        meta_required_campaigns_columns
        .select('campaign_id', 'job_id')
        .distinct()
    )
    return (
        meta_metrics
        .join(
            required_campaign_jobs,
            on='campaign_id',
            how='inner'
        )
        .select(
            'campaign_id',
            'week_start_date',
            'clicks',
            'impressions',
            'internals_media_spend',
            'externals_media_spend',
            'job_id'
        )
    )


def build_meta_reqd_metrics_jb(meta_reqd_metrics: DataFrame) -> DataFrame:
    """
    Aggregate required meta metrics by week and job_id.
    """
    meta_reqd_metrics_jb = (
        meta_reqd_metrics.groupBy(
            F.col('week_start_date'),
            F.col('job_id')
        ).agg(
            F.sum('clicks').alias('clicks'),
            F.sum('impressions').alias('impressions'),
            F.sum('internals_media_spend').alias('internals_media_spend'),
            F.sum('externals_media_spend').alias('externals_media_spend')
        )
    )
    return (
        meta_reqd_metrics_jb.select(
            'job_id',
            'week_start_date',
            'clicks',
            'impressions',
            'internals_media_spend',
            'externals_media_spend'
        )
    )


def build_meta_metrics_jb_sku_pre(
    meta_reqd_metrics_jb: DataFrame,
    meta_required_campaigns: DataFrame
) -> DataFrame:
    """
    Join required metrics with campaigns to get SKU list per job_id
    """
    campaign_sku_details = (
        meta_required_campaigns
        .select(
            'job_id',
            'item_cd',
            'super_category_name',
            'unique_brand_name'
        )
        .distinct()
    )
    return (
        meta_reqd_metrics_jb
        .join(
            campaign_sku_details,
            on='job_id',
            how='left'
        )
        .select(
            'job_id',
            'week_start_date',
            'clicks',
            'impressions',
            'internals_media_spend',
            'externals_media_spend',
            'item_cd',
            'super_category_name',
            'unique_brand_name',
        )
    )


def build_meta_num_skus(meta_metrics_jb_sku: DataFrame) -> DataFrame:
    """
    Count distinct SKUs per job_id.
    """
    meta_num_skus = meta_metrics_jb_sku.groupBy('job_id').agg(
        F.countDistinct('item_cd').alias('number_of_skus')
    )
    return meta_num_skus.withColumn(
        'number_of_skus',
        F.coalesce(F.col('number_of_skus'), F.lit(0)).cast(T.LongType())
    ).select(
        'job_id',
        'number_of_skus'
    )


def build_meta_camp_skus_split(
    meta_metrics_jb_sku: DataFrame,
    meta_num_skus: DataFrame
) -> DataFrame:
    """
    Split campaign metrics across SKUs.
    """
    return (
        meta_metrics_jb_sku
        .join(
            meta_num_skus.select('job_id', 'number_of_skus'),
            on='job_id',
            how='left'
        )
        .select(
            'job_id',
            'week_start_date',
            'super_category_name',
            'unique_brand_name',
            'item_cd',
            'number_of_skus',
            F.coalesce(
                F.col('clicks') / F.col('number_of_skus'),
                lit(0)
            ).alias('clicks'),
            F.coalesce(
                F.col('impressions') / F.col('number_of_skus'),
                lit(0)
            ).alias('impressions'),
            F.coalesce(
                F.col('externals_media_spend') /
                F.col('number_of_skus'),
                lit(0)
            ).alias('externals_media_spend'),
            F.coalesce(
                F.col('internals_media_spend') /
                F.col('number_of_skus'),
                lit(0)
            ).alias('internals_media_spend')
        )
    )


def build_meta_camp_cluster(
    meta_camp_skus_split: DataFrame,
    sku_cluster_df: DataFrame
) -> DataFrame:
    """
    Join campaign SKU data with sku_cluster_df to get cluster assignments.
    """
    cluster_lookup = (
        sku_cluster_df
        .select(
            'item_cd',
            'super_category_name',
            'unique_brand_name',
            'cluster_num'
        )
        .distinct()
    )
    return (
        meta_camp_skus_split
        .join(
            cluster_lookup,
            on=['item_cd', 'super_category_name', 'unique_brand_name'],
            how='left'
        )
        .select(
            'job_id',
            'week_start_date',
            'super_category_name',
            'unique_brand_name',
            'item_cd',
            'number_of_skus',
            'clicks',
            'impressions',
            'externals_media_spend',
            'internals_media_spend',
            'cluster_num'
        )
    )


def build_meta_unique_brand_cluster(meta_camp_cluster: DataFrame) -> DataFrame:
    """
    Aggregate metrics at unique brand x cluster x week level.
    """
    meta_unique_brand_cluster = (
        meta_camp_cluster.groupBy(
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'week_start_date'
        ).agg(
            F.sum('clicks').alias('clicks'),
            F.sum('impressions').alias('impressions'),
            F.sum('internals_media_spend').alias('internals_media_spend'),
            F.sum('externals_media_spend').alias('externals_media_spend')
        )
    )
    return (
        meta_unique_brand_cluster.select(
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'week_start_date',
            'clicks',
            'impressions',
            'internals_media_spend',
            'externals_media_spend'
        ).sort('week_start_date')
    )


def build_meta_unique_brand_cluster_unpivot(meta_unique_brand_cluster: DataFrame) -> DataFrame:
    """
    Unpivot metrics and attach marketing attributes.
    """
    meta_unique_brand_cluster_unpivot = (
        meta_unique_brand_cluster
        .unpivot(
            ['super_category_name', 'unique_brand_name', 'cluster_num', 'week_start_date'],
            [
                'impressions',
                'clicks',
                'internals_media_spend',
                'externals_media_spend'
            ],
            'metric',
            'value'
        )
        .select(
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            F.to_date(F.col('week_start_date')).alias('week_start_dt'),
            'metric',
            'value'
        )
    )
    return (
        meta_unique_brand_cluster_unpivot
        .withColumn('marketing_type', lit(MetaConfig.MARKETING_TYPE))
        .withColumn('marketing_channel', lit(MetaConfig.MARKETING_CHANNEL))
        .withColumn('marketing_sub_channel', lit(MetaConfig.MARKETING_SUB_CHANNEL))
    )


def build_skeleton_meta_unique_brand(
    meta_unique_brand_cluster_unpivot: DataFrame
) -> DataFrame:
    """
    Build skeleton for meta unique brand data.
    """
    return (
        meta_unique_brand_cluster_unpivot.select(
            'super_category_name',
            'unique_brand_name',
            'marketing_type',
            'marketing_channel',
            'marketing_sub_channel',
            'cluster_num',
            'metric'
        ).distinct()
    )


def build_skeleton_with_dates(
    temp_date_dataset: DataFrame,
    skele_meta_unique_brand: DataFrame
) -> DataFrame:
    """
    Join dates with skeleton to create final skeleton dataset.
    """
    return (
        temp_date_dataset
        .select('week_start_dt')
        .crossJoin(
            skele_meta_unique_brand.select(
                'super_category_name',
                'unique_brand_name',
                'marketing_type',
                'marketing_channel',
                'marketing_sub_channel',
                'cluster_num',
                'metric'
            )
        )
        .select(
            'week_start_dt',
            'super_category_name',
            'unique_brand_name',
            'marketing_type',
            'marketing_channel',
            'marketing_sub_channel',
            'cluster_num',
            'metric'
        )
    )


def build_meta_processed_data(
    skele_meta_unique_brand_final: DataFrame,
    meta_unique_brand_cluster_unpivot: DataFrame
) -> DataFrame:
    """
    Join skeleton with actual metrics and fill missing values.
    """
    join_columns = [
        'week_start_dt',
        'super_category_name',
        'unique_brand_name',
        'marketing_type',
        'marketing_channel',
        'marketing_sub_channel',
        'cluster_num',
        'metric'
    ]
    return (
        skele_meta_unique_brand_final
        .join(
            meta_unique_brand_cluster_unpivot.select(*join_columns, 'value'),
            on=join_columns,
            how='left'
        )
        .withColumn('value', F.coalesce(F.col('value'), lit(0)))
        .select(
            'week_start_dt',
            'super_category_name',
            'unique_brand_name',
            'marketing_type',
            'marketing_channel',
            'marketing_sub_channel',
            'cluster_num',
            'metric',
            'value'
        )
        .filter(F.col('cluster_num').isNotNull())
    )


def format_meta_processed_data(meta_processed_data: DataFrame) -> DataFrame:
    """
    Format meta processed data for output.
    """
    return (
        meta_processed_data
        .withColumn('metric_name', F.upper(F.col('metric')))
        .withColumn('metric_value', F.col('value').cast(T.DecimalType(18, 5)))
        .select(
            'week_start_dt',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            F.col('marketing_type').alias('marketing_type_name'),
            F.col('marketing_channel').alias('marketing_channel_name'),
            F.col('marketing_sub_channel').alias('marketing_sub_channel_name'),
            'metric_name',
            'metric_value'
        )
    )


def merge_pollen_and_dtp_data(
        meta_processed_data_pollen: DataFrame,
        meta_processed_data_dtp: DataFrame
) -> DataFrame:
    """
    Merge pollen and dtp meta processed data, with pollen data taking precedence.

    Args:
        meta_processed_data_pollen: Pollen processed data (takes precedence)
        meta_processed_data_dtp: DTP processed data (used only when no pollen match exists)

    Returns:
        DataFrame: Combined data with pollen taking precedence over dtp
    """
    # Normalize pollen data
    meta_data_pollen_normalized = (
        meta_processed_data_pollen
        .withColumn('cluster_num', F.upper(F.col('cluster_num')))
        .withColumn('marketing_type_name', F.upper(F.col('marketing_type_name')))
        .withColumn('marketing_channel_name', F.upper(F.col('marketing_channel_name')))
        .withColumn('marketing_sub_channel_name', F.upper(F.col('marketing_sub_channel_name')))
        .withColumn('metric_name', F.upper(F.col('metric_name')))
        .select(
            'week_start_dt',
            'metric_value',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name'
        )
    )

    # Normalize dtp data
    meta_data_dtp_normalized = (
        meta_processed_data_dtp
        .withColumn('cluster_num', F.upper(F.col('cluster_num')))
        .withColumn('marketing_type_name', F.upper(F.col('marketing_type_name')))
        .withColumn('marketing_channel_name', F.upper(F.col('marketing_channel_name')))
        .withColumn('marketing_sub_channel_name', F.upper(F.col('marketing_sub_channel_name')))
        .withColumn('metric_name', F.upper(F.col('metric_name')))
        .select(
            'week_start_dt',
            'metric_value',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name'
        )
    )

    # Get dtp records that don't exist in pollen data
    join_conditions = [
        'week_start_dt',
        'super_category_name',
        'unique_brand_name',
        'cluster_num',
        'marketing_type_name',
        'marketing_channel_name',
        'marketing_sub_channel_name',
        'metric_name'
    ]

    dtp_only_records = (
        meta_data_dtp_normalized
        .join(
            meta_data_pollen_normalized,
            join_conditions,
            'left_anti'
        )
    )

    # Combine pollen data (takes precedence) with non-overlapping dtp data
    meta_combined = (
        meta_data_pollen_normalized
        .unionByName(dtp_only_records)
        .withColumn('metric_value', F.col('metric_value').cast(T.DecimalType(18, 5)))
        .withColumn('job_run_id', F.lit('NA'))
        .withColumn('load_ts', F.current_timestamp())
        .select(
            'week_start_dt',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name',
            'metric_value',
            'job_run_id',
            'load_ts'
        )
    )

    return meta_combined
