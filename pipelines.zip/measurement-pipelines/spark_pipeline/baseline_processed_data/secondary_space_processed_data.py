from typing import Any, Dict, List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession, functions as F

from spark_pipeline.baseline_processed_data.processed_data_utils import load_shared_processed_data_sources
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.schemas.baseline_processed_data.secondary_space import SecondarySpace
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_during_data(
    spark: SparkSession,
    during_correlation_id: str,
    during_baseline_modelling_path: str,
    config: Dict[str, Any],
) -> DataFrame:
    """
    Load the baseline modelling dataset produced during the During period for Post-specific logic.

    Args:
        spark: Active Spark session.
        during_correlation_id: Unique identifier for the During DAG or pipeline run that produced the baseline modelling dataset.
        during_baseline_modelling_path: Path to the During baseline modelling dataset.
        config: Secondary space configuration values.
    Returns:
        Baseline modelling dataset from the During period.
    """
    ss_marketing_type_name: str = config["marketing_type_name"]
    ss_marketing_sub_channel_name: str = config["marketing_sub_channel_name"]

    # Filter to the specific marketing type and sub-channel for secondary space from the During baseline modelling dataset
    during_run_data = (
        spark
        .read
        .parquet(during_baseline_modelling_path)
        .filter(
            (F.col("job_run_id") == during_correlation_id)  # Jon Run ID here is correlation ID
            & (F.col("marketing_type_name") == ss_marketing_type_name)
            & (F.col("marketing_sub_channel_name") == ss_marketing_sub_channel_name)
        )
        .select(
            'week_start_dt',
            'cluster_num',  # retain cluster_num in case we're running for multiple brands
            'metric_name',
            'metric_value'
        )
    )

    return during_run_data


def _load_s3_data(
    spark: SparkSession,
    weekly_dates_path: str,
    sku_cluster_mapping_path: str,
    plngrm_campaign_item_postn_daily_path: str,
    dim_section_path: str,
) -> Tuple[DataFrame, DataFrame, DataFrame, DataFrame]:
    """
    Load all s3 datasets required for secondary space processing.

    Args:
        spark: Active Spark session.
        weekly_dates_path: Path to the weekly date skeleton table used for time series alignment.
        sku_cluster_mapping_path: Path to the SKU cluster mapping used for aggregating SKUs into clusters.
        plngrm_campaign_item_postn_daily_path: Path to the planogram data capturing secondary placement information.
        dim_section_path: Path to the section dimension table used for filtering and categorizing planogram data.

    Returns:
        A tuple containing the planogram, section dimension, SKU cluster mapping,
        and weekly dates DataFrames.
    """
    sku_cluster_mapping_df, weekly_dates_df = load_shared_processed_data_sources(
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        weekly_dates_path=weekly_dates_path,
        spark=spark,
    )

    # Load planogram data
    planogram_df = (
        spark.read.parquet(plngrm_campaign_item_postn_daily_path)
        .select(
            "date_dt",
            "week_start_dt",
            "store_cd",
            "section_id",
            "item_cd",
        )
    )

    # Load section dimension data
    dim_section_df = (
        spark.read.parquet(dim_section_path)
        .select(
            "section_id",
            "section_type_desc",
            "section_created_ts",
            "section_expired_ts",
        )
    )

    return planogram_df, dim_section_df, sku_cluster_mapping_df, weekly_dates_df


def _get_weekly_date_bounds(
    weekly_dates_df: DataFrame,
    start_date: str,
    end_date: str,
) -> Tuple[DataFrame, Any, Any]:
    """
    Restrict weekly dates to the requested range and derive the min/max week bounds.

    Args:
        weekly_dates_df: Weekly date skeleton.
        start_date: Start of the date range to process (inclusive), in YYYY-MM-DD format.
        end_date: End of the date range to process (inclusive), in YYYY-MM-DD format.

    Returns:
        The filtered weekly dates DataFrame together with the minimum and maximum week start dates.
    """
    # Derive the min/max week bounds from the requested date range
    weekly_dates_range_df = weekly_dates_df.filter(
        (F.col("week_start_dt") >= F.to_date(F.lit(start_date)))
        & (F.col("week_start_dt") <= F.to_date(F.lit(end_date)))
    )

    date_range_vals = (
        weekly_dates_range_df
        .select(
            F.min("week_start_dt").alias("min_week_start_dt"),
            F.max("week_start_dt").alias("max_week_start_dt"),
        )
        .first()
    )

    return (
        weekly_dates_range_df,
        date_range_vals["min_week_start_dt"],
        date_range_vals["max_week_start_dt"],
    )


def _filter_planogram_campaign_data(
    planogram_df: DataFrame,
    sku_cluster_mapping_df: DataFrame,
    min_week_start_dt: Any,
    max_week_start_dt: Any,
) -> DataFrame:
    """
    Filter planogram data to in-scope brand SKUs and the requested week bounds.

    Args:
        planogram_df: Raw planogram data.
        sku_cluster_mapping_df: SKU-to-cluster mapping for in-scope brand SKUs.
        min_week_start_dt: Minimum in-scope week start date.
        max_week_start_dt: Maximum in-scope week start date.

    Returns:
        Planogram records enriched with cluster attributes and filtered to the modelling period.
    """
    min_week_start_lit = F.lit(min_week_start_dt)
    max_week_start_lit = F.lit(max_week_start_dt)

    # Inner join planogram with SKU cluster mapping to filter to brand SKUs
    return (
        planogram_df
        .join(F.broadcast(sku_cluster_mapping_df), on="item_cd", how="inner")
        .where(
            (F.to_date("week_start_dt") >= min_week_start_lit)
            & (F.to_date("week_start_dt") <= max_week_start_lit)
        )
        .select(
            "date_dt",
            "week_start_dt",
            "store_cd",
            "section_id",
            "item_cd",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
        )
    )


def _calculate_ranged_items_metrics(
    planogram_campaign_data_df: DataFrame,
    dim_section_df: DataFrame,
) -> DataFrame:
    """
    Calculate ranged item metrics for each cluster, week, and section type.

    Args:
        planogram_campaign_data_df: In-scope planogram data enriched with cluster attributes.
        dim_section_df: Section dimension data used to determine section type and validity period.

    Returns:
        Weekly cluster-level ranged item metrics by section type.
    """
    # Total unique store count across the filtered planogram data
    store_count_val = (
        planogram_campaign_data_df
        .select(F.countDistinct("store_cd").alias("store_count"))
        .first()["store_count"]
    )

    # Number of unique items per cluster
    items_df = (
        planogram_campaign_data_df
        .groupBy("cluster_num")
        .agg(F.countDistinct("item_cd").alias("item_count"))
    )

    # Calculate ranged items and their metrics per section type
    return (
        planogram_campaign_data_df
        .join(items_df, on="cluster_num", how="inner")
        .join(dim_section_df, on="section_id", how="inner")
        .filter(
            F.col("date_dt").between(
                F.to_date("section_created_ts"),
                F.coalesce(F.to_date("section_expired_ts"), F.to_date(F.lit("3199-12-31"))),
            )
        )
        .groupBy(
            "week_start_dt",
            "section_type_desc",
            "cluster_num",
            "item_count",
            "unique_brand_name",
            "super_category_name",
        )
        .agg(F.countDistinct("item_cd", "store_cd", "date_dt").alias("item_dt_count"))
        .withColumn("marketing_channel_name", F.upper(F.col("section_type_desc")))
        .withColumn("store_count", F.lit(store_count_val))
        .withColumn("max_total", F.col("item_count") * F.lit(7) * F.col("store_count"))
        .withColumn(
            "metric_value",
            F.when(F.col("max_total") > 0, F.col("item_dt_count") / F.col("max_total")).otherwise(
                F.lit(0.0)
            ),
        )
        .select(
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "week_start_dt",
            "marketing_channel_name",
            "metric_value",
        )
    )


def _build_baseline_specific_attributes_df(
    spark: SparkSession,
    config: Dict[str, Any],
) -> DataFrame:
    """
    Build the static marketing attribute combinations required for secondary space output.

    Args:
        spark: Active Spark session.
        config: Secondary space configuration values.

    Returns:
        Static marketing attribute combinations for secondary space metrics.
    """

    bsa_data = [
        (
            config["marketing_type_name"],
            config["marketing_channel_name_promo"],
            config["marketing_sub_channel_name"],
            config["metric_name_promo"],
        ),
        (
            config["marketing_type_name"],
            config["marketing_channel_name_core"],
            config["marketing_sub_channel_name"],
            config["metric_name_core"],
        ),
    ]
    return spark.createDataFrame(
        data=bsa_data,
        schema=SecondarySpace.baseline_specific_attributes_schema,
    )


def _build_secondary_space_metric_grid(
    weekly_dates_range_df: DataFrame,
    sku_cluster_mapping_df: DataFrame,
    baseline_specific_attributes_df: DataFrame,
) -> DataFrame:
    """
    Create the full week-by-cluster-by-metric grid for the modelling period.

    Args:
        weekly_dates_range_df: Weekly dates within the requested modelling period.
        sku_cluster_mapping_df: SKU-to-cluster mapping used to derive distinct cluster combinations.
        baseline_specific_attributes_df: Static marketing attribute combinations.

    Returns:
        Full secondary space metric grid before observed values are joined in.
    """
    # Distinct cluster combos from sku_cluster_mapping
    unique_attributes_df = (
        sku_cluster_mapping_df
        .select("super_category_name", "unique_brand_name", "cluster_num")
        .distinct()
    )

    # Cross join weekly dates × cluster attributes × marketing type/metric combinations,
    # then left join with the observed ranged items
    return (
        weekly_dates_range_df
        .crossJoin(unique_attributes_df)
        .crossJoin(baseline_specific_attributes_df)
    )


def _format_secondary_space_output(
    secondary_space_metric_grid_df: DataFrame,
    ranged_items_df: DataFrame,
    run_date: str,
    correlation_id: str,
) -> DataFrame:
    """
    Apply the final baseline processed data contract for secondary space output.

    Args:
        secondary_space_metric_grid_df: Full week-by-cluster-by-metric grid.
        ranged_items_df: Observed ranged item metric values.
        run_date: The pipeline run date in YYYY-MM-DD format.
        correlation_id: Unique identifier for the pipeline run.

    Returns:
        Final secondary space processed dataset ready to be written.
    """
    return (
        secondary_space_metric_grid_df
        .join(
            ranged_items_df,
            on=[
                "week_start_dt",
                "super_category_name",
                "unique_brand_name",
                "cluster_num",
                "marketing_channel_name",
            ],
            how="left",
        )
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            F.coalesce(F.col("metric_value"), F.lit(0.0)).alias("metric_value"),
            F.lit(correlation_id).alias("job_run_id"),
            F.current_timestamp().alias("load_ts"),
            F.lit(run_date).alias("run_date"),
        )
    )


def reconcile_during_data(
    final_df: DataFrame,
    during_secondary_space_df: DataFrame,
) -> DataFrame:
    """
    Replace overlapping post-period secondary-space values with the corresponding During values.

    The output keeps the full set of rows produced for the current run. For join-key overlaps
    (`week_start_dt`, `cluster_num`, `metric_name`), the During `metric_value` replaces the
    post-period value while the current-run metadata is preserved. Rows that only exist in the
    During dataset are not appended.

    Args:
        final_df: Final secondary space processed dataset for post period calculation
        during_secondary_space_df: During secondary space processed dataset
    Returns:
        Final secondary space processed dataset after reconciling with during data.
    """

    join_columns = ["week_start_dt", "cluster_num", "metric_name"]

    # Rows in final_df that have a matching during row:
    overlapping_replaced_df = (
        final_df.drop('metric_value')  # Will be filled in via the During data
        .join(
            during_secondary_space_df,
            on=join_columns,
            how="inner",
        )
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "job_run_id",
            "load_ts",
            "run_date",
        )
    )

    # Rows in final_df with no matching during row:
    non_overlapping_final_df = (
        final_df
        .join(
            during_secondary_space_df,
            on=join_columns,
            how="left_anti",
        )
    )

    return non_overlapping_final_df.unionByName(overlapping_replaced_df)


def prepare_secondary_space_data(
    spark: SparkSession,
    weekly_dates_path: str,
    sku_cluster_mapping_path: str,
    plngrm_campaign_item_postn_daily_path: str,
    dim_section_path: str,
    output_path: str,
    run_date: str,
    start_date: str,
    end_date: str,
    correlation_id: str,
    during_baseline_modelling_path: Optional[str] = None,
    during_correlation_id: Optional[str] = None,
) -> None:
    """
    Creates a dataset capturing secondary placement (end-of-aisle) data for SKUs, aggregated at the brand cluster level.
    Products placed at the end-of-aisle sometimes have N360 ads, which can impact sales performance.

    Business Context:
    - Secondary placement can influence consumer purchasing behavior, potentially boosting sales.
    - From a model perspective, including secondary placement data may enhance the accuracy of sales predictions.
    - Secondary placement can also significantly affect incrementality.

    Confluence: https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/

    Args:
        spark: Active Spark session.
        weekly_dates_path: Path to the weekly date skeleton table used for time series alignment.
        sku_cluster_mapping_path: Path to the SKU cluster mapping used for aggregating SKUs into clusters.
        plngrm_campaign_item_postn_daily_path: Path to the planogram data capturing secondary placement information.
        dim_section_path: Path to the section dimension table used for filtering and categorizing planogram data.
        output_path: Output location for the processed core secondary space dataset.
        run_date: The pipeline run date in YYYY-MM-DD format.
        start_date: Start of the date range to process (inclusive), in YYYY-MM-DD format.
        end_date: End of the date range to process (inclusive), in YYYY-MM-DD format.
        correlation_id: Unique identifier for tracking the DAG or pipeline run.
        during_baseline_modelling_path: Optional S3 path for the baseline modelling dataset produced during the During period (For Post specific logic).
        during_correlation_id: Optional unique identifier for the During DAG or pipeline run that produced the baseline modelling dataset (For Post specific logic).
    Returns:
        None -> The function writes the processed secondary space dataset to the specified output path.
    """
    config = BaselineProcessedData.secondary_space_config

    if during_correlation_id:
        if during_baseline_modelling_path is None:
            raise ValueError("during_baseline_modelling_path is required when during_correlation_id is provided.")

        during_secondary_space_df = prepare_during_data(
            spark,
            during_correlation_id,
            during_baseline_modelling_path,
            config,
        )
    else:
        during_secondary_space_df = None

    planogram_df, dim_section_df, sku_cluster_mapping_df, weekly_dates_df = _load_s3_data(
        spark=spark,
        weekly_dates_path=weekly_dates_path,
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        plngrm_campaign_item_postn_daily_path=plngrm_campaign_item_postn_daily_path,
        dim_section_path=dim_section_path,
    )
    weekly_dates_range_df, min_week_start_dt, max_week_start_dt = _get_weekly_date_bounds(
        weekly_dates_df,
        start_date,
        end_date,
    )
    planogram_campaign_data_df = _filter_planogram_campaign_data(
        planogram_df,
        sku_cluster_mapping_df,
        min_week_start_dt,
        max_week_start_dt,
    )
    ranged_items_df = _calculate_ranged_items_metrics(planogram_campaign_data_df, dim_section_df)
    baseline_specific_attributes_df = _build_baseline_specific_attributes_df(spark, config)

    secondary_space_metric_grid_df = _build_secondary_space_metric_grid(
        weekly_dates_range_df,
        sku_cluster_mapping_df,
        baseline_specific_attributes_df,
    )
    final_df = _format_secondary_space_output(
        secondary_space_metric_grid_df,
        ranged_items_df,
        run_date,
        correlation_id,
    )

    if during_secondary_space_df is not None:
        final_df = reconcile_during_data(final_df, during_secondary_space_df)

    spark_s3_overwrite(output_path, final_df)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Core Secondary Space Processed Data for baseline pipeline.")
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="Path to weekly date skeleton table."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="Path to SKU cluster mapping."
    )
    parser.add_argument(
        "--plngrm-campaign-item-postn-daily-path",
        type=str,
        required=True,
        help="Path to planogram campaign data."
    )
    parser.add_argument(
        "--dim-section-path",
        type=str,
        required=True,
        help="Path to store section dimension data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="Output location for processed core secondary space dataset."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--start-date",
        type=str,
        required=True,
        help="Start of the date range (inclusive), YYYY-MM-DD."
    )
    parser.add_argument(
        "--end-date",
        type=str,
        required=True,
        help="End of the date range (inclusive), YYYY-MM-DD."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG or pipeline run."
    )
    parser.add_argument(
        "--baseline-modelling-dataset-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for previous baseline modelling dataset (During period)"
    )
    parser.add_argument(
        "--during-correlation-id",
        type=str,
        required=False,
        default=None,
        help="Unique identifier for the DAG or pipeline run that was produced in the During period for this booking."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_secondary_space_data(
        spark=spark,
        weekly_dates_path=known_args.weekly_dates_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        plngrm_campaign_item_postn_daily_path=known_args.plngrm_campaign_item_postn_daily_path,
        dim_section_path=known_args.dim_section_path,
        output_path=known_args.output_path,
        run_date=known_args.run_date,
        start_date=known_args.start_date,
        end_date=known_args.end_date,
        correlation_id=known_args.correlation_id,
        during_baseline_modelling_path=known_args.baseline_modelling_dataset_path,
        during_correlation_id=known_args.during_correlation_id,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("SecondarySpaceProcessedData").getOrCreate())
