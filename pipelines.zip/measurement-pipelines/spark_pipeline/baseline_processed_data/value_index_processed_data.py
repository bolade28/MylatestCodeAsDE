from typing import List, Optional, Dict, Any

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import DateType, DecimalType

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.baseline_processed_data.processed_data_utils import (
    load_shared_processed_data_sources,
    build_cluster_date_skeleton,
)
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite
from spark_pipeline.utils.stdout_logger import StdOutLogger


logger = StdOutLogger()


# --- Helper Functions ---
def get_value_index_item_cd_cluster(
    agg_value_index_dashboard_w_df: DataFrame,
    sku_cluster_mapping_df: DataFrame,
    start_date: str,
    end_date: str,
) -> DataFrame:
    """
    Joins value index data with the SKU cluster mapping (filtering to brand SKUs only)
    and includes Wednesday loads for every week overlapping the requested date range.

    :param agg_value_index_dashboard_w_df: AGG_VALUE_INDEX_DASHBOARD_W DataFrame.
    :param sku_cluster_mapping_df: SKU cluster mapping DataFrame.
    :param start_date: First campaign date, truncated to its week (YYYY-MM-DD).
    :param end_date: Last campaign date, truncated to its week (YYYY-MM-DD).
    :return: Value index item code cluster DataFrame.
    """
    start_load_date = F.date_add(F.date_trunc("week", F.lit(start_date).cast(DateType())).cast(DateType()), 2)
    end_load_date = F.date_add(F.date_trunc("week", F.lit(end_date).cast(DateType())).cast(DateType()), 2)

    value_index_item_cd_cluster = (
        agg_value_index_dashboard_w_df
        .join(
            sku_cluster_mapping_df,
            "item_cd",
            "inner",
        )
        .filter(F.col("process_dt").between(start_load_date, end_load_date))
        .select(
            "primary_annual_sales_amt",
            "secondary_annual_sales_amt",
            "secondary_retailer_cd",
            "process_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
        )
    )
    return value_index_item_cd_cluster


def calculate_value_indices(
    value_index_item_cd_cluster_df: DataFrame,
    config: Dict[str, Any]
) -> DataFrame:
    """
    Calculates value indices for all retailers and key retailers, then combines them.

    :param value_index_item_cd_cluster_df: Input value index item code cluster DataFrame.
    :param config: Configuration dictionary containing key retailer patterns and metric names.
    :return: Combined DataFrame with all and key retailer value indices.
    """
    zero_value_index = F.lit(0).cast(DecimalType(38, 2))

    value_index_with_week_start_df = (
        value_index_item_cd_cluster_df
        .withColumn(
            "week_start_date",
            F.date_sub(F.col("process_dt"), 2)
        )
    )

    # All-retailer value index: ratio of primary to total secondary annual sales
    value_index_all_retailers = (
        value_index_with_week_start_df
        .groupBy(
            "unique_brand_name",
            "cluster_num",
            "super_category_name",
            "week_start_date",
        )
        .agg(
            (F.sum("primary_annual_sales_amt") /
             F.when(F.sum("secondary_annual_sales_amt") == 0, 1)  # ToDo: This is inconsistent with key_retailer_value_index, DS to look into this
             .otherwise(F.sum("secondary_annual_sales_amt")) * 100
             ).cast(DecimalType(38, 2)).alias("all_retailer_value_index")
        )
    )

    # Filter to key retailers only (ALDI and TESCO)
    key_retailer_filter = (
        value_index_with_week_start_df
        .filter(
            F.col("secondary_retailer_cd").like(config['key_retailer_patterns'][0]) |
            F.col("secondary_retailer_cd").like(config['key_retailer_patterns'][1])
        )
    )

    # Key-retailer value index
    value_index_key_retailers = (
        key_retailer_filter
        .groupBy(
            "unique_brand_name",
            "cluster_num",
            "super_category_name",
            "week_start_date",
        )
        .agg(
            (F.sum("primary_annual_sales_amt") /
             F.when(F.sum("secondary_annual_sales_amt") == 0, None)
             .otherwise(F.sum("secondary_annual_sales_amt")) * 100
             ).cast(DecimalType(38, 2)).alias("key_retailer_value_index")
        )
    )

    join_keys = ["week_start_date", "super_category_name", "unique_brand_name", "cluster_num"]

    # Full outer join to combine both indices, coalescing nulls to 0
    value_index_all_metrics = (
        value_index_all_retailers
        .join(
            value_index_key_retailers,
            on=join_keys,
            how="full",
        )
        .withColumn("all_retailer_value_index", F.coalesce(F.col("all_retailer_value_index"), zero_value_index))
        .withColumn("key_retailer_value_index", F.coalesce(F.col("key_retailer_value_index"), zero_value_index))
        .select(*join_keys, "all_retailer_value_index", "key_retailer_value_index")
    )
    return value_index_all_metrics


def join_with_skeleton(
    value_index_skeleton_final_df: DataFrame,
    value_index_all_metrics_df: DataFrame,
    config: Dict[str, Any]
) -> DataFrame:
    """
    Left-joins the full date/cluster skeleton with the computed value index metrics,
    imputing missing values with 0.

    :param value_index_skeleton_final_df: The complete date × cluster skeleton DataFrame.
    :param value_index_all_metrics_df: Combined value indices DataFrame.
    :param config: Configuration dictionary containing metric hierarchy

    :return: Value index unique brand cluster hierarchy DataFrame.
    """

    join_keys = ["week_start_date", "super_category_name", "unique_brand_name", "cluster_num"]
    zero_value_index = F.lit(0).cast(DecimalType(38, 2))

    value_index_skeleton_final_df = (
        value_index_skeleton_final_df
        .join(
            value_index_all_metrics_df,
            on=join_keys,
            how="left",
        )
        .withColumn("marketing_type", F.lit(config['marketing_type_name']))
        .withColumn("marketing_channel", F.lit(config['marketing_channel_name']))
        .withColumn("marketing_sub_channel", F.lit(config['marketing_sub_channel_name']))
        .withColumn("all_retailer_value_index", F.coalesce(F.col("all_retailer_value_index"), zero_value_index))
        .withColumn("key_retailer_value_index", F.coalesce(F.col("key_retailer_value_index"), zero_value_index))
        .select(
            *join_keys,
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "all_retailer_value_index",
            "key_retailer_value_index",
        )
    )

    return value_index_skeleton_final_df


def unpivot_data(
    value_index_unique_brand_cluster_hierarchy_df: DataFrame,
    correlation_id: str,
    config: Dict[str, Any]
) -> DataFrame:
    """
    Unpivots all_retailer_value_index and key_retailer_value_index into metric rows.

    :param value_index_unique_brand_cluster_hierarchy_df: Input DataFrame.
    :param correlation_id: Unique identifier for the pipeline run.
    :param config: Configuration dictionary containing metric hierarchy

    :return: Processed DataFrame with metrics unpivoted.
    """
    all_retailer_value_index: str = config['value_index_metrics'][0]
    key_retailer_value_index: str = config['value_index_metrics'][1]

    # ToDo: separate out this stack expression
    value_index_processed_data = (
        value_index_unique_brand_cluster_hierarchy_df
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "cluster_num",
            F.expr(
                f"stack(2, "
                f"'{all_retailer_value_index}', {all_retailer_value_index}, "
                f"'{key_retailer_value_index}', {key_retailer_value_index}"
                f") as (metric, value)"
            ),
        )
        .withColumn("job_run_id", F.lit(correlation_id))
    )

    return value_index_processed_data


def get_final_result(value_index_processed_data_df: DataFrame) -> DataFrame:
    """
    Renames columns for the final output schema.

    :param value_index_processed_data_df: The unpivoted and processed DataFrame.
    :return: Final DataFrame ready for output.
    """

    final_result = (
        value_index_processed_data_df
        .withColumnRenamed("week_start_date", "week_start_dt")
        .withColumnRenamed("marketing_type", "marketing_type_name")
        .withColumnRenamed("marketing_channel", "marketing_channel_name")
        .withColumnRenamed("marketing_sub_channel", "marketing_sub_channel_name")
        .withColumnRenamed("metric", "metric_name")
        .withColumnRenamed("value", "metric_value")
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "job_run_id"
        )
    )

    return final_result


# --- Main Orchestration Function ---

def prepare_value_index_processed_data(
    spark: SparkSession,
    agg_value_index_dashboard_w_path: str,
    sku_cluster_mapping_path: str,
    weekly_dates_path: str,
    output_path: str,
    start_date: str,
    end_date: str,
    correlation_id: str,
) -> DataFrame:
    """
    Orchestrates the preparation of value index processed data.
    Creating the all_retailer_value_index and key_retailer_value_index metrics

    :param spark: The SparkSession object.
    :param agg_value_index_dashboard_w_path: S3 path for the aggregated value index dashboard.
    :param sku_cluster_mapping_path: S3 path for the SKU cluster mapping.
    :param weekly_dates_path: S3 path for the weekly dates skeleton.
    :param output_path: S3 path for the output processed data.
    :param start_date: Start date for data processing (YYYY-MM-DD).
    :param end_date: End date for data processing (YYYY-MM-DD).
    :param correlation_id: Unique identifier for the current job run.
    :return: The final processed DataFrame.
    """
    logger.info(f"START DATE: {start_date}, END DATE: {end_date}")

    sku_cluster_mapping_df, weekly_dates_df = load_shared_processed_data_sources(
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        weekly_dates_path=weekly_dates_path,
        spark=spark,
    )

    agg_value_index_dashboard_w_df = (
        spark
        .read
        .parquet(agg_value_index_dashboard_w_path)
        .withColumnRenamed('primary_item_cd', 'item_cd')  # Renamed so we can match with sku cluster mapping later
        .select(
            "item_cd",
            "primary_annual_sales_amt",
            "secondary_annual_sales_amt",
            "secondary_retailer_cd",
            "process_dt",
        )
    )

    config = BaselineProcessedData.value_index_config

    # Inner join value index data with SKU cluster mapping and filter by date range
    value_index_item_cd_cluster_df = get_value_index_item_cd_cluster(
        agg_value_index_dashboard_w_df,
        sku_cluster_mapping_df,
        start_date,
        end_date,
    )

    # Calculate all-retailer and key-retailer value indices
    value_index_all_metrics_df = calculate_value_indices(value_index_item_cd_cluster_df, config)

    # Build the full date × cluster skeleton
    value_index_skeleton_final_df = build_cluster_date_skeleton(
        weekly_dates_df=weekly_dates_df,
        cluster_attrs_df=value_index_all_metrics_df,
    )

    # Left join skeleton with metrics, imputing missing values
    value_index_unique_brand_cluster_hierarchy_df = join_with_skeleton(
        value_index_skeleton_final_df,
        value_index_all_metrics_df,
        config
    )

    # Unpivot metrics into rows
    value_index_processed_data_df = unpivot_data(
        value_index_unique_brand_cluster_hierarchy_df,
        correlation_id,
        config
    )

    # Final column selection and rename
    final_result_df = get_final_result(value_index_processed_data_df)

    # Write the final output to s3
    spark_s3_overwrite(output_path, final_result_df)

    return final_result_df


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Value Index Processed Data for baseline pipeline.")
    parser.add_argument(
        "--agg-value-index-dashboard-w-path",
        type=str,
        required=True,
        help="S3 path for the aggregated value index dashboard.",
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="S3 path for SKU cluster mapping.",
    )
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="S3 path for the weekly dates skeleton.",
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for output of value index processed data.",
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run.",
    )
    parser.add_argument(
        "--start-date",
        type=str,
        required=True,
        help="Start date for data processing in YYYY-MM-DD format.",
    )
    parser.add_argument(
        "--end-date",
        type=str,
        required=True,
        help="End date for data processing in YYYY-MM-DD format.",
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    _ = prepare_value_index_processed_data(
        spark=spark,
        agg_value_index_dashboard_w_path=known_args.agg_value_index_dashboard_w_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        weekly_dates_path=known_args.weekly_dates_path,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id,
        start_date=known_args.start_date,
        end_date=known_args.end_date,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("ValueIndexProcessedData").getOrCreate())
