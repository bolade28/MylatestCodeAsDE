"""
Baseline Sales Forecasting Module

This module provides forecasting capabilities for baseline sales estimation using multiple
machine learning models including Linear Regression, Random Forest, XGBoost, and
Unobserved Components Model (UCM). It's designed to forecast baseline sales for new
products when existing baseline data is available for the same Brand x Super Category
combination within the last 3 months.

The module selects the best performing model based on weighted metrics including WSMAPE,
incremental difference, and trend alignment flags.
"""

from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    DateType,
    IntegerType,
    DoubleType,
    DecimalType,
)
from pyspark.sql.window import Window
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from statsmodels.tsa.statespace.structural import UnobservedComponents
from xgboost import XGBRFRegressor
from datetime import datetime
from typing import Tuple, Dict, Any
from pyspark.sql import SparkSession, DataFrame


def parallel_runner_spark(
    spark,
    ads_df,
    baseline_df,
    baseline_summary_df,
    sku_cluster_map_forecast_df,
    params,
    external_df,
    sales_df,
    iteration_num=1,
):
    """
    Execute forecasting process in parallel for multiple brand-category-cluster combinations.

    This function orchestrates the entire forecasting pipeline by processing each unique
    combination of Brand x Super Category x Cluster in parallel, applying multiple ML models
    and selecting the best performer for each combination.

    Args:
        spark (SparkSession): Active Spark session
        ads_df (DataFrame): Baseline modelling dataset containing advertising/marketing data
        baseline_df (DataFrame): Historical baseline output data from previous UCM runs
        baseline_summary_df (DataFrame): Baseline intermediate output with significant variables
        sku_cluster_map_forecast_df (DataFrame): SKU to cluster mapping for aggregation
        params (dict): Configuration parameters including train/test splits and weights
        external_df (DataFrame): External variables dataset (weather, events, etc.)
        sales_df (DataFrame): Sales data for the forecasting period
        iteration_num (int, optional): Iteration number for tracking. Defaults to 1.

    Returns:
        tuple: Contains three DataFrames:
            - forecast_results: All model predictions with metadata
            - result_forecast: Model evaluation metrics and best model selection
            - future_: Future predictions from the best performing model
    """
    # Convert decimal columns to double for consistent processing
    decimal_columns = ["METRIC_VALUE", "TOTAL_SALES_AMT"]

    baseline_df = convert_decimal_columns_spark(baseline_df, decimal_columns)
    baseline_summary_df = convert_decimal_columns_spark(
        baseline_summary_df, decimal_columns
    )
    ads_df = convert_decimal_columns_spark(ads_df, decimal_columns)
    external_df = convert_decimal_columns_spark(external_df, decimal_columns)
    sales_df = convert_decimal_columns_spark(sales_df, decimal_columns)

    # Get unique combinations to process
    unique_combinations = sku_cluster_map_forecast_df.select(
        "UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "CLUSTER_NUM"
    ).distinct()

    # Initialize result DataFrames with predefined schemas
    forecast_results_schema = get_forecast_results_schema()
    result_forecast_schema = get_result_forecast_schema()
    future_schema = get_future_schema()

    forecast_results = spark.createDataFrame([], schema=forecast_results_schema)
    result_forecast = spark.createDataFrame([], schema=result_forecast_schema)
    future_ = spark.createDataFrame([], schema=future_schema)

    combinations = unique_combinations.collect()
    print(f"Processing {len(combinations)} brand-category-cluster combinations...")

    # Process each combination individually
    for i, row in enumerate(combinations):
        unique_brand = row.UNIQUE_BRAND_NAME
        super_cat = row.SUPER_CATEGORY_NAME
        cluster = row.CLUSTER_NUM

        print(
            f"Processing combination {i+1}/{len(combinations)}: {unique_brand} - {super_cat} - {cluster}"
        )

        # Execute forecasting for individual cluster
        cluster_forecast_result, cluster_result_forecast, cluster_future = (
            forecast_iterator_spark(
                spark,
                unique_brand,
                super_cat,
                cluster,
                ads_df,
                baseline_df,
                baseline_summary_df,
                params,
                external_df,
                sales_df,
                sku_cluster_map_forecast_df,
                iteration_num,
            )
        )

        # Ensure schema compatibility and union results
        if cluster_forecast_result.count() > 0:
            cluster_forecast_result = align_dataframe_schema(
                cluster_forecast_result, forecast_results_schema
            )
            forecast_results = forecast_results.union(cluster_forecast_result)
            print(f"Added {cluster_forecast_result.count()} forecast results")

        if cluster_result_forecast.count() > 0:
            cluster_result_forecast = align_dataframe_schema(
                cluster_result_forecast, result_forecast_schema
            )
            result_forecast = result_forecast.union(cluster_result_forecast)
            print(f"Added {cluster_result_forecast.count()} result forecast records")

        if cluster_future.count() > 0:
            cluster_future = align_dataframe_schema(cluster_future, future_schema)
            future_ = future_.union(cluster_future)
            print(f"Added {cluster_future.count()} future records")

    print(
        f"Final results - forecast_results: {forecast_results.count()}, "
        f"result_forecast: {result_forecast.count()}, future_: {future_.count()}"
    )

    return forecast_results, result_forecast, future_


def align_dataframe_schema(df, target_schema):
    """
    Align DataFrame schema to match target schema exactly with proper type casting.

    Args:
        df (DataFrame): Source DataFrame to align
        target_schema (StructType): Target schema to match

    Returns:
        DataFrame: DataFrame with aligned schema and proper column types
    """
    target_columns = [field.name for field in target_schema.fields]
    target_types = {field.name: field.dataType for field in target_schema.fields}

    select_exprs = []

    for col_name in target_columns:
        if col_name in df.columns:
            # Cast existing columns to target type
            target_type = target_types[col_name]
            if isinstance(target_type, StringType):
                select_exprs.append(F.col(col_name).cast("string").alias(col_name))
            elif isinstance(target_type, DoubleType):
                select_exprs.append(F.col(col_name).cast("double").alias(col_name))
            elif isinstance(target_type, DateType):
                select_exprs.append(F.col(col_name).cast("date").alias(col_name))
            elif isinstance(target_type, IntegerType):
                select_exprs.append(F.col(col_name).cast("integer").alias(col_name))
            else:
                select_exprs.append(F.col(col_name).alias(col_name))
        else:
            # Add missing columns with null values
            target_type = target_types[col_name]
            if isinstance(target_type, StringType):
                select_exprs.append(F.lit(None).cast("string").alias(col_name))
            elif isinstance(target_type, DoubleType):
                select_exprs.append(F.lit(None).cast("double").alias(col_name))
            elif isinstance(target_type, DateType):
                select_exprs.append(F.lit(None).cast("date").alias(col_name))
            elif isinstance(target_type, IntegerType):
                select_exprs.append(F.lit(None).cast("integer").alias(col_name))
            else:
                select_exprs.append(F.lit(None).alias(col_name))

    return df.select(*select_exprs)


def linear_reg_pandas(data, train_start, train_end, test_start, test_end, future_steps):
    """
    Apply Linear Regression model for baseline forecasting.

    Uses exponential weighted moving average as a feature along with total sales
    and external variables to predict baseline sales.

    Args:
        data (pd.DataFrame): Input dataset with sales and baseline data
        train_start (str): Training period start date
        train_end (str): Training period end date
        test_start (str): Test period start date
        test_end (str): Test period end date
        future_steps (int): Number of future periods to forecast

    Returns:
        tuple: (updated_data_with_forecasts, future_predictions_list)
    """
    data["WEEK_START_DT"] = pd.to_datetime(data["WEEK_START_DT"])
    data = data.sort_values(by="WEEK_START_DT")

    # Create exponential weighted moving average feature
    data["rolling_avg_13"] = (
        data["TOTAL_BASELINE_AMT"].ewm(span=13, adjust=False).mean()
    )
    data_lm = data.dropna()

    train_start_dt = pd.to_datetime(train_start)
    train_end_dt = pd.to_datetime(train_end)
    test_start_dt = pd.to_datetime(test_start)
    test_end_dt = pd.to_datetime(test_end)

    data_lm_train = data_lm[
        (data_lm["WEEK_START_DT"] >= train_start_dt) &
        (data_lm["WEEK_START_DT"] <= train_end_dt)
    ]
    data_lm_test = data_lm[
        (data_lm["WEEK_START_DT"] >= test_start_dt) &
        (data_lm["WEEK_START_DT"] <= test_end_dt)
    ]

    # Identify external variables and prepare feature set
    ext_vars = [col for col in data.columns if "EXT" in col]
    reqd_cols = ["rolling_avg_13", "TOTAL_SALES_AMT"] + ext_vars

    # Train model and generate predictions for train/test periods
    lr = LinearRegression()
    lr.fit(data_lm_train[reqd_cols], data_lm_train["TOTAL_BASELINE_AMT"])
    predictions_train = lr.predict(data_lm_train[reqd_cols])
    predictions = lr.predict(data_lm_test[reqd_cols])

    # Combine predictions and pad with NaN for future periods
    final_yhat = np.append(predictions_train, predictions)
    diff_length = len(data) - len(final_yhat)
    additional_arr = np.full(diff_length, np.nan)
    final_yhat = np.append(final_yhat, additional_arr)
    data["FORECAST_BASE"] = final_yhat

    # Retrain on complete historical data for future predictions
    future_train = data_lm[
        (data_lm["WEEK_START_DT"] >= train_start_dt) &
        (data_lm["WEEK_START_DT"] <= test_end_dt)
    ]
    lr.fit(future_train[reqd_cols], future_train["TOTAL_BASELINE_AMT"])
    values_new_fut = list(future_train["TOTAL_BASELINE_AMT"].values)
    new_predictions = []

    # Generate future predictions iteratively
    for i in range(future_steps):
        rolling_avg_13 = (
            pd.Series(values_new_fut).ewm(span=13, adjust=False).mean().iloc[-1]
        )
        input_row = pd.DataFrame(
            {
                "rolling_avg_13": [rolling_avg_13],
                "TOTAL_SALES_AMT": [
                    data["TOTAL_SALES_AMT"].iloc[future_train.shape[0] + i]
                ],
            }
        )
        for ext_var in ext_vars:
            input_row[ext_var] = [data[ext_var].iloc[future_train.shape[0] + i]]

        prediction = lr.predict(input_row)[0]
        new_predictions.append(prediction)
        values_new_fut.append(prediction)

    return data, new_predictions


def forecast_iterator_spark(
    spark: SparkSession,
    unique_brand: str,
    super_cat: str,
    cluster: str,
    ads: DataFrame,
    baseline_output: DataFrame,
    baseline_intermediate_output: DataFrame,
    params: Dict[str, Any],
    external_df: DataFrame,
    sales_df: DataFrame,
    sku_cluster_map_forecast_df: DataFrame,
    iteration_num: int = 1,
) -> Tuple[DataFrame, DataFrame, DataFrame]:
    """
    Execute complete forecasting pipeline for a single brand-category-cluster combination.

    This function applies multiple ML models (Linear Regression, Random Forest, XGBoost, UCM)
    to forecast baseline sales and selects the best performing model based on evaluation metrics.

    Args:
        spark (SparkSession): Active Spark session
        unique_brand (str): Brand name to process
        super_cat (str): Super category name to process
        cluster (str): Cluster number to process
        ads (DataFrame): Advertising/marketing dataset
        baseline_output (DataFrame): Historical baseline results
        baseline_intermediate_output (DataFrame): Baseline model metadata
        params (Dict[str, Any]): Configuration parameters
        external_df (DataFrame): External variables data
        sales_df (DataFrame): Sales data for forecast period
        sku_cluster_map_forecast_df (DataFrame): SKU cluster mappings
        iteration_num (int, optional): Iteration tracking number. Defaults to 1.

    Returns:
        Tuple[DataFrame, DataFrame, DataFrame]: A tuple containing:
            - forecast_results_df: Forecast results for all models
            - result_forecast_df: Best model selection results
            - future_predictions_df: Future period predictions
    """
    # [Rest of the function implementation remains the same]
    # Initialize empty return values for error cases
    empty_forecast_results = spark.createDataFrame(
        [], schema=get_forecast_results_schema()
    )
    empty_result_forecast = spark.createDataFrame(
        [], schema=get_result_forecast_schema()
    )
    empty_future = spark.createDataFrame([], schema=get_future_schema())

    print(f"Starting forecast for {unique_brand} - {super_cat} - {cluster}")

    # Filter data for specific cluster combination
    cluster_baseline = baseline_output.filter(
        (F.col("UNIQUE_BRAND_NAME") == unique_brand) &
        (F.col("SUPER_CATEGORY_NAME") == super_cat) &
        (F.col("CLUSTER_NUM") == cluster)
    )

    cluster_baseline_summary = baseline_intermediate_output.filter(
        (F.col("UNIQUE_BRAND_NAME") == unique_brand) &
        (F.col("SUPER_CATEGORY_NAME") == super_cat) &
        (F.col("CLUSTER_NUM") == cluster)
    )

    # Validate data availability
    if cluster_baseline.count() == 0:
        print(f"No baseline data found for {unique_brand} - {super_cat} - {cluster}")
        return empty_forecast_results, empty_result_forecast, empty_future

    if cluster_baseline_summary.count() == 0:
        print(
            f"No baseline summary data found for {unique_brand} - {super_cat} - {cluster}"
        )
        return empty_forecast_results, empty_result_forecast, empty_future

    # Convert to pandas for model processing
    cluster_baseline_pd = cluster_baseline.toPandas()
    cluster_baseline_summary_pd = cluster_baseline_summary.toPandas()

    # Ensure numeric data types for calculations
    numeric_columns = ["METRIC_VALUE", "TOTAL_SALES_AMT", "TOTAL_BASELINE_AMT"]
    for col_name in numeric_columns:
        if col_name in cluster_baseline_pd.columns:
            cluster_baseline_pd[col_name] = pd.to_numeric(
                cluster_baseline_pd[col_name], errors="coerce"
            )
        if col_name in cluster_baseline_summary_pd.columns:
            cluster_baseline_summary_pd[col_name] = pd.to_numeric(
                cluster_baseline_summary_pd[col_name], errors="coerce"
            )
    # Process baseline data into modeling format
    ucm_output = ucm_read_2_pandas(
        cluster_baseline_pd, unique_brand, super_cat, cluster
    )

    if ucm_output.empty:
        print(f"Empty UCM output for {unique_brand} - {super_cat} - {cluster}")
        return empty_forecast_results, empty_result_forecast, empty_future

    # Create train/test date splits
    train_start, train_end, test_start, test_end = train_test_date_creator_pandas(
        ucm_output, params
    )

    # Identify significant external variables from previous baseline run
    ext_vars = cluster_baseline_summary_pd[
        cluster_baseline_summary_pd["MARKETING_TYPE_NAME"] == "EXTERNAL"
    ]["VARIABLE_CD"].unique()

    # Prepare datasets for modeling
    ads_pd = ads.toPandas()
    external_pd = external_df.toPandas()

    # Convert decimal columns to numeric
    if "METRIC_VALUE" in ads_pd.columns:
        ads_pd["METRIC_VALUE"] = pd.to_numeric(ads_pd["METRIC_VALUE"], errors="coerce")
    if "METRIC_VALUE" in external_pd.columns:
        external_pd["METRIC_VALUE"] = pd.to_numeric(
            external_pd["METRIC_VALUE"], errors="coerce"
        )

    ext_ads = read_ads_pandas(ads_pd, ext_vars, external_pd, train_start)

    # Create future sales data
    sales_pd = sales_df.toPandas()
    sku_cluster_pd = sku_cluster_map_forecast_df.toPandas()

    if "TOTAL_SALES_AMT" in sales_pd.columns:
        sales_pd["TOTAL_SALES_AMT"] = pd.to_numeric(
            sales_pd["TOTAL_SALES_AMT"], errors="coerce"
        )

    sales_new = sales_new_creator_pandas(
        sales_pd, sku_cluster_pd, unique_brand, super_cat, cluster, test_end
    )

    # Combine historical and future data
    sales_total = pd.concat(
        [ucm_output.reset_index(drop=True), sales_new.reset_index(drop=True)],
        ignore_index=True,
    )
    sales_total["WEEK_START_DT"] = pd.to_datetime(sales_total["WEEK_START_DT"])

    # Align external data with sales timeline
    if not ext_ads.empty:
        ext_ads = ext_ads.head(sales_total.shape[0])

    # Create final modeling dataset
    if len(ext_vars) != 0 and not ext_ads.empty:
        input_with_ext = pd.concat(
            [sales_total.reset_index(drop=True), ext_ads.reset_index(drop=True)], axis=1
        )
    else:
        input_with_ext = sales_total.reset_index(drop=True)

    # Calculate forecast horizon
    num_steps = num_forecast_steps_pandas(sales_total, ucm_output)

    if num_steps <= 0:
        print(
            f"Invalid forecast steps ({num_steps}) for {unique_brand} - {super_cat} - {cluster}"
        )
        num_steps = 1

    # Apply all forecasting models
    lr_test, new_pred_lr = linear_reg_pandas(
        input_with_ext.copy(), train_start, train_end, test_start, test_end, num_steps
    )
    rf_test, new_pred_rf = random_forest_pandas(
        input_with_ext.copy(), train_start, train_end, test_start, test_end, num_steps
    )
    xg_test, new_pred_xg = xgb_pandas(
        input_with_ext.copy(), train_start, train_end, test_start, test_end, num_steps
    )
    a_ucm, b_ucm = ucm_forecast_pandas(
        input_with_ext.copy(),
        train_start,
        train_end,
        test_start,
        test_end,
        ext_ads,
        num_steps,
    )

    # Organize model results
    models_data = [
        ("linear_regression", lr_test, new_pred_lr),
        ("random_forest", rf_test, new_pred_rf),
        ("xgboost", xg_test, new_pred_xg),
        ("ucm", a_ucm, b_ucm),
    ]

    # Select best performing model
    result_forecast_pd, best_future_pred = select_model_pandas(
        [m[0] for m in models_data],
        [m[1] for m in models_data],
        [m[2] for m in models_data],
        test_start,
        test_end,
        params,
    )

    # Create forecast results DataFrame
    forecast_results_data = []
    for model_name, model_data, future_pred in models_data:
        result_df = input_with_ext[
            ["WEEK_START_DT", "TOTAL_SALES_AMT", "TOTAL_BASELINE_AMT"]
        ].copy()

        # Ensure predictions are properly formatted
        if not isinstance(future_pred, list):
            future_pred = (
                [future_pred] if np.isscalar(future_pred) else list(future_pred)
            )

        # Create forecast series with proper length alignment
        forecast_base = model_data.get(
            "FORECAST_BASE", pd.Series([0.0] * len(result_df))
        ).fillna(0)
        if len(forecast_base) < len(result_df):
            padding = [0.0] * (len(result_df) - len(forecast_base))
            forecast_base = list(forecast_base) + padding
        elif len(forecast_base) > len(result_df):
            forecast_base = forecast_base[: len(result_df)]

        result_df["FORECAST_SERIES"] = forecast_base
        result_df["BASELINE_PERC"] = np.nan  # Set to null as per requirements

        # Add metadata columns
        result_df["model"] = model_name
        result_df["UNIQUE_BRAND_NAME"] = unique_brand
        result_df["SUPER_CATEGORY_NAME"] = super_cat
        result_df["CLUSTER_NUM"] = cluster

        # Ensure proper data types for Spark compatibility
        result_df["WEEK_START_DT"] = pd.to_datetime(result_df["WEEK_START_DT"]).dt.date
        result_df["TOTAL_SALES_AMT"] = pd.to_numeric(
            result_df["TOTAL_SALES_AMT"], errors="coerce"
        ).fillna(0.0)
        result_df["TOTAL_BASELINE_AMT"] = pd.to_numeric(
            result_df["TOTAL_BASELINE_AMT"], errors="coerce"
        ).fillna(0.0)
        result_df["FORECAST_SERIES"] = pd.to_numeric(
            result_df["FORECAST_SERIES"], errors="coerce"
        ).fillna(0.0)
        result_df["BASELINE_PERC"] = pd.to_numeric(
            result_df["BASELINE_PERC"], errors="coerce"
        ).fillna(0.0)

        forecast_results_data.append(result_df)

    # Convert results to Spark DataFrames
    if forecast_results_data:
        forecast_results_combined = pd.concat(forecast_results_data, ignore_index=True)
        forecast_results = spark.createDataFrame(forecast_results_combined)
    else:
        forecast_results = empty_forecast_results

    # Create result forecast DataFrame
    result_forecast_pd["UNIQUE_BRAND_NAME"] = unique_brand
    result_forecast_pd["SUPER_CATEGORY_NAME"] = super_cat
    result_forecast_pd["CLUSTER_NUM"] = cluster
    result_forecast = spark.createDataFrame(result_forecast_pd)

    # Create future predictions DataFrame
    future_sales = 0.0
    future_date = datetime.now().date()

    # Extract future period information
    if not input_with_ext.empty and "TOTAL_BASELINE_AMT" in input_with_ext.columns:
        nan_mask = input_with_ext["TOTAL_BASELINE_AMT"].isna()
        if nan_mask.any():
            first_nan_idx = nan_mask.idxmax()
            future_date_raw = input_with_ext.loc[first_nan_idx, "WEEK_START_DT"]
            if hasattr(future_date_raw, "date"):
                future_date = future_date_raw.date()
            elif isinstance(future_date_raw, str):
                future_date = datetime.strptime(future_date_raw, "%Y-%m-%d").date()

            if "TOTAL_SALES_AMT" in input_with_ext.columns:
                future_sales = float(
                    input_with_ext.loc[first_nan_idx, "TOTAL_SALES_AMT"]
                )

    best_future_value = (
        float(best_future_pred["best_future"].iloc[0])
        if not best_future_pred.empty and len(best_future_pred) > 0
        else 0.0
    )

    future_data = {
        "UNIQUE_BRAND_NAME": unique_brand,
        "SUPER_CATEGORY_NAME": super_cat,
        "CLUSTER_NUM": cluster,
        "best_future": best_future_value,
        "WEEK_START_DT": future_date,
        "TOTAL_SALES_AMT": future_sales,
    }
    future_ = spark.createDataFrame([future_data], schema=get_future_schema())

    print(
        f"Successfully completed forecast for {unique_brand} - {super_cat} - {cluster}"
    )
    return forecast_results, result_forecast, future_


def convert_decimal_columns_spark(df, decimal_columns):
    """
    Convert decimal type columns to double type for consistent numerical operations.

    Args:
        df (DataFrame): Input Spark DataFrame
        decimal_columns (list): List of column names that may contain decimal types

    Returns:
        DataFrame: DataFrame with decimal columns converted to double type
    """
    for col_name in decimal_columns:
        if col_name in df.columns:
            col_type = dict(df.dtypes)[col_name]
            if "decimal" in col_type.lower() or isinstance(
                df.schema[col_name].dataType, DecimalType
            ):
                df = df.withColumn(col_name, F.col(col_name).cast("double"))

    return df


def get_forecast_results_schema():
    """Define schema for forecast results output."""
    return StructType(
        [
            StructField("UNIQUE_BRAND_NAME", StringType(), True),
            StructField("SUPER_CATEGORY_NAME", StringType(), True),
            StructField("CLUSTER_NUM", StringType(), True),
            StructField("WEEK_START_DT", DateType(), True),
            StructField("TOTAL_SALES_AMT", DoubleType(), True),
            StructField("TOTAL_BASELINE_AMT", DoubleType(), True),
            StructField("FORECAST_SERIES", DoubleType(), True),
            StructField("BASELINE_PERC", DoubleType(), True),
            StructField("model", StringType(), True),
        ]
    )


def get_result_forecast_schema():
    """Define schema for model evaluation results."""
    return StructType(
        [
            StructField("UNIQUE_BRAND_NAME", StringType(), True),
            StructField("SUPER_CATEGORY_NAME", StringType(), True),
            StructField("CLUSTER_NUM", StringType(), True),
            StructField("method", StringType(), True),
            StructField("mape_percent_test", DoubleType(), True),
            StructField("incremental_diff", DoubleType(), True),
            StructField("base_dep_flag_test", IntegerType(), True),
            StructField("r2_percent_test", DoubleType(), True),
            StructField("Final_Score", DoubleType(), True),
        ]
    )


def get_future_schema():
    """Define schema for future predictions output."""
    return StructType(
        [
            StructField("UNIQUE_BRAND_NAME", StringType(), True),
            StructField("SUPER_CATEGORY_NAME", StringType(), True),
            StructField("CLUSTER_NUM", StringType(), True),
            StructField("best_future", DoubleType(), True),
            StructField("WEEK_START_DT", DateType(), True),
            StructField("TOTAL_SALES_AMT", DoubleType(), True),
        ]
    )


def get_params(config):
    """
    Extract forecasting parameters from configuration.

    Args:
        config (ForecastingConfig): Configuration dataclass instance  # Fixed docstring

    Returns:
        dict: Dictionary with extracted forecasting parameters
    """
    params = {}
    params["forecast_train_share"] = config.forecasting_train_share  # Use dot notation
    params["forecast_test_share"] = config.forecasting_test_share
    params["forecast_wsmape_wt"] = config.forecasting_wsmape_wt
    params["forecast_inc_diff_wt"] = config.forecasting_inc_diff_wt
    params["forecast_trend_flag_wt"] = config.forecasting_trend_flag_wt
    return params


def ucm_read_2_pandas(baseline_output, unique_brand, super_category, cluster):
    """
    Extract and pivot baseline output data for specific brand-category-cluster combination.

    Transforms long-format baseline data into wide format suitable for modeling,
    combining baseline amounts and sales amounts by week.

    Args:
        baseline_output (pd.DataFrame): Baseline output data in long format
        unique_brand (str): Brand name filter
        super_category (str): Super category filter
        cluster (str): Cluster number filter

    Returns:
        pd.DataFrame: Wide-format data with weekly baseline and sales amounts
    """
    baseline_output = baseline_output[
        (baseline_output["UNIQUE_BRAND_NAME"] == unique_brand) &
        (baseline_output["SUPER_CATEGORY_NAME"] == super_category) &
        (baseline_output["CLUSTER_NUM"] == cluster)
    ]
    baseline_output = baseline_output[["WEEK_START_DT", "METRIC_NAME", "METRIC_VALUE"]]

    # Separate baseline and sales metrics
    baseline_output_m1 = baseline_output[
        baseline_output["METRIC_NAME"] == "TOTAL_BASELINE_AMT"
    ]
    baseline_output_m1 = baseline_output_m1.rename(
        columns={"METRIC_VALUE": "TOTAL_BASELINE_AMT"}
    )
    baseline_output_m1 = baseline_output_m1.drop(columns=["METRIC_NAME"])

    baseline_output_m2 = baseline_output[
        baseline_output["METRIC_NAME"] == "TOTAL_SALES_AMT"
    ]
    baseline_output_m2 = baseline_output_m2.rename(
        columns={"METRIC_VALUE": "TOTAL_SALES_AMT"}
    )
    baseline_output_m2 = baseline_output_m2.drop(columns=["METRIC_NAME"])

    # Merge baseline and sales data
    baseline_output = pd.merge(
        baseline_output_m1, baseline_output_m2, how="left", on="WEEK_START_DT"
    )
    ucm = (
        baseline_output[["WEEK_START_DT", "TOTAL_BASELINE_AMT", "TOTAL_SALES_AMT"]]
        .sort_values(by="WEEK_START_DT")
        .reset_index(drop=True)
    )

    # Remove last week as it will be forecasted
    ucm = ucm.drop(ucm.index[-1])
    return ucm


def train_test_date_creator_pandas(data, params):
    """
    Create training and testing date ranges based on configured split ratios.

    Args:
        data (pd.DataFrame): Dataset containing WEEK_START_DT column
        params (dict): Parameters containing train/test split ratios

    Returns:
        tuple: (train_start, train_end, test_start, test_end) as strings
    """
    train_share = params["forecast_train_share"]
    data = data.sort_values(by="WEEK_START_DT").reset_index(drop=True)
    unique_dates = data["WEEK_START_DT"].unique().astype(str)

    cnt = len(unique_dates)
    train_len = np.floor(cnt * train_share)
    train_dates = unique_dates[: int(train_len)]
    test_dates = unique_dates[int(train_len):]

    tr_start = str(train_dates[0])
    tr_end = str(train_dates[-1])
    te_start = str(test_dates[0])
    te_end = str(test_dates[-1])

    return tr_start, tr_end, te_start, te_end


def read_ads_pandas(ads_df, ext_vars, ext_df, train_start):
    """
    Process external variables data for modeling input.

    Filters and pivots external variables data to create wide-format features
    for use in forecasting models.

    Args:
        ads_df (pd.DataFrame): Advertising dataset containing variable mappings
        ext_vars (list): List of significant external variable codes
        ext_df (pd.DataFrame): External variables dataset
        train_start (str): Training start date for filtering

    Returns:
        pd.DataFrame: Pivoted external variables data indexed by week
    """
    if len(ext_vars) == 0:
        return pd.DataFrame()

    ext_vars = [i.upper() for i in ext_vars]
    ads_df["WEEK_START_DT"] = pd.to_datetime(ads_df["WEEK_START_DT"])

    # Create mapping from variable codes to marketing dimensions
    ext_var_map = ads_df[ads_df["VARIABLE_CD"].isin(ext_vars)][
        [
            "MARKETING_TYPE_NAME",
            "MARKETING_CHANNEL_NAME",
            "MARKETING_SUB_CHANNEL_NAME",
            "METRIC_NAME",
            "VARIABLE_CD",
        ]
    ].drop_duplicates()

    if ext_var_map.empty:
        return pd.DataFrame()

    # Join external data with variable mappings
    ext_var_ads = pd.merge(
        ext_df[
            [
                "WEEK_START_DT",
                "MARKETING_TYPE_NAME",
                "MARKETING_CHANNEL_NAME",
                "MARKETING_SUB_CHANNEL_NAME",
                "METRIC_NAME",
                "METRIC_VALUE",
            ]
        ],
        ext_var_map,
        how="inner",
        on=[
            "MARKETING_TYPE_NAME",
            "MARKETING_CHANNEL_NAME",
            "MARKETING_SUB_CHANNEL_NAME",
            "METRIC_NAME",
        ],
    )

    if ext_var_ads.empty:
        return pd.DataFrame()

    # Pivot to wide format and filter by date
    ext_var_ads = ext_var_ads[["WEEK_START_DT", "VARIABLE_CD", "METRIC_VALUE"]]
    ext_var_ads = ext_var_ads.pivot_table(
        index="WEEK_START_DT", columns="VARIABLE_CD", values="METRIC_VALUE"
    ).reset_index()
    ext_var_ads["WEEK_START_DT"] = pd.to_datetime(ext_var_ads["WEEK_START_DT"])
    ext_var_ads = ext_var_ads[
        ext_var_ads["WEEK_START_DT"] >= pd.to_datetime(train_start)
    ]
    ext_var_ads = ext_var_ads.sort_values(by="WEEK_START_DT").set_index("WEEK_START_DT")
    return ext_var_ads


def sales_new_creator_pandas(
    sales_req, sku_cluster_map_forecast_df, unique_brand, super_cat, cluster, test_end
):
    """
    Generate aggregated sales data for the forecast period.

    Filters sales data for the specific cluster and time period beyond the test end date,
    then aggregates sales amounts by week for forecasting.

    Args:
        sales_req (pd.DataFrame): Raw sales data
        sku_cluster_map_forecast_df (pd.DataFrame): SKU to cluster mapping
        unique_brand (str): Brand filter
        super_cat (str): Super category filter
        cluster (str): Cluster filter
        test_end (str): End date of test period

    Returns:
        pd.DataFrame: Aggregated sales data for forecast period
    """
    sales_req["WEEK_START_DT"] = pd.to_datetime(sales_req["WEEK_START_DT"])
    sales_req = sales_req[sales_req["WEEK_START_DT"] > pd.to_datetime(test_end)]

    # Filter cluster mapping for specific combination
    sku_filter = (
        (sku_cluster_map_forecast_df["UNIQUE_BRAND_NAME"] == unique_brand) &
        (sku_cluster_map_forecast_df["SUPER_CATEGORY_NAME"] == super_cat) &
        (sku_cluster_map_forecast_df["CLUSTER_NUM"] == cluster)
    )

    # Add modelling type filter if column exists
    if "MODELLING_TYPE" in sku_cluster_map_forecast_df.columns:
        sku_filter = sku_filter & (
            sku_cluster_map_forecast_df["MODELLING_TYPE"] == "CLUSTERING"
        )

    sku_cluster_map_forecast_df_req = sku_cluster_map_forecast_df[sku_filter][
        ["UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "ITEM_CD", "CLUSTER_NUM"]
    ]

    if sku_cluster_map_forecast_df_req.empty:
        return pd.DataFrame(
            {
                "WEEK_START_DT": pd.to_datetime([]),
                "TOTAL_SALES_AMT": [],
                "TOTAL_BASELINE_AMT": [],
            }
        )

    # Filter and aggregate sales data
    sales_req = sales_req[
        sales_req["ITEM_CD"].isin(sku_cluster_map_forecast_df_req["ITEM_CD"].unique())
    ]

    if sales_req.empty:
        return pd.DataFrame(
            {
                "WEEK_START_DT": pd.to_datetime([]),
                "TOTAL_SALES_AMT": [],
                "TOTAL_BASELINE_AMT": [],
            }
        )

    sales_req = sales_req[["WEEK_START_DT", "ITEM_CD", "TOTAL_SALES_AMT"]]
    sales_req = pd.merge(
        sales_req, sku_cluster_map_forecast_df_req, how="left", on=["ITEM_CD"]
    )
    sales_req = sales_req[
        [
            "UNIQUE_BRAND_NAME",
            "SUPER_CATEGORY_NAME",
            "CLUSTER_NUM",
            "WEEK_START_DT",
            "TOTAL_SALES_AMT",
        ]
    ]
    sales_req = (
        sales_req.groupby(
            ["UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "CLUSTER_NUM", "WEEK_START_DT"]
        )["TOTAL_SALES_AMT"]
        .sum()
        .reset_index()
    )
    sales_req = sales_req[["WEEK_START_DT", "TOTAL_SALES_AMT"]]
    sales_req["TOTAL_BASELINE_AMT"] = np.nan
    sales_req["WEEK_START_DT"] = pd.to_datetime(sales_req["WEEK_START_DT"])
    sales_req = sales_req.sort_values(by="WEEK_START_DT").reset_index(drop=True)

    return sales_req


def num_forecast_steps_pandas(sales_df, ucm_df):
    """
    Calculate number of forecast steps needed based on data availability.

    Args:
        sales_df (pd.DataFrame): Sales data with future periods
        ucm_df (pd.DataFrame): Historical baseline data

    Returns:
        int: Number of weekly forecast steps required
    """
    last_date_ucm = pd.to_datetime(ucm_df["WEEK_START_DT"]).max()
    sales_max_date = pd.to_datetime(sales_df["WEEK_START_DT"]).max()

    # Calculate weekly difference and round up
    future_steps = (sales_max_date - last_date_ucm) / 7
    s = int(np.ceil(future_steps.days))
    return s


def random_forest_pandas(
    data, train_start, train_end, test_start, test_end, future_steps
):
    """
    Apply Random Forest model for baseline forecasting.

    Uses ensemble of decision trees with exponential weighted moving average
    and external variables as features.

    Args:
        data (pd.DataFrame): Input dataset with sales and baseline data
        train_start (str): Training period start date
        train_end (str): Training period end date
        test_start (str): Test period start date
        test_end (str): Test period end date
        future_steps (int): Number of future periods to forecast

    Returns:
        tuple: (updated_data_with_forecasts, future_predictions_list)
    """
    data["WEEK_START_DT"] = pd.to_datetime(data["WEEK_START_DT"])
    data = data.sort_values(by="WEEK_START_DT")
    data["rolling_avg_13"] = (
        data["TOTAL_BASELINE_AMT"].ewm(span=13, adjust=False).mean()
    )

    data_lm = data.dropna()

    train_start_dt = pd.to_datetime(train_start)
    train_end_dt = pd.to_datetime(train_end)
    test_start_dt = pd.to_datetime(test_start)
    test_end_dt = pd.to_datetime(test_end)

    data_lm_train = data_lm[
        (data_lm["WEEK_START_DT"] >= train_start_dt) &
        (data_lm["WEEK_START_DT"] <= train_end_dt)
    ]
    data_lm_test = data_lm[
        (data_lm["WEEK_START_DT"] >= test_start_dt) &
        (data_lm["WEEK_START_DT"] <= test_end_dt)
    ]

    ext_vars = [col for col in data.columns if "EXT" in col]
    reqd_cols = ["rolling_avg_13", "TOTAL_SALES_AMT"] + ext_vars

    # Configure and train Random Forest with production parameters
    rf = RandomForestRegressor(
        n_jobs=1, n_estimators=80, max_depth=5, min_samples_split=2, random_state=42
    )
    rf.fit(data_lm_train[reqd_cols], data_lm_train["TOTAL_BASELINE_AMT"])
    predictions_train = rf.predict(data_lm_train[reqd_cols])
    predictions = rf.predict(data_lm_test[reqd_cols])

    final_yhat = np.append(predictions_train, predictions)
    diff_length = len(data) - len(final_yhat)
    additional_arr = np.full(diff_length, np.nan)
    final_yhat = np.append(final_yhat, additional_arr)
    data["FORECAST_BASE"] = final_yhat

    # Retrain for future predictions
    future_train = data_lm[
        (data_lm["WEEK_START_DT"] >= train_start_dt) &
        (data_lm["WEEK_START_DT"] <= test_end_dt)
    ]
    rf.fit(future_train[reqd_cols], future_train["TOTAL_BASELINE_AMT"])
    values_new_fut = list(future_train["TOTAL_BASELINE_AMT"].values)
    new_predictions = []

    for i in range(future_steps):
        rolling_avg_13 = (
            pd.Series(values_new_fut).ewm(span=13, adjust=False).mean().iloc[-1]
        )
        input_row = pd.DataFrame(
            {
                "rolling_avg_13": [rolling_avg_13],
                "TOTAL_SALES_AMT": [
                    data["TOTAL_SALES_AMT"].iloc[future_train.shape[0] + i]
                ],
            }
        )
        for ext_var in ext_vars:
            input_row[ext_var] = [data[ext_var].iloc[future_train.shape[0] + i]]

        prediction = rf.predict(input_row)[0]
        new_predictions.append(prediction)
        values_new_fut.append(prediction)

    return data, new_predictions


def xgb_pandas(data, train_start, train_end, test_start, test_end, future_steps):
    """
    Apply XGBoost model for baseline forecasting.

    Uses gradient boosting with optimized hyperparameters for time series forecasting.

    Args:
        data (pd.DataFrame): Input dataset with sales and baseline data
        train_start (str): Training period start date
        train_end (str): Training period end date
        test_start (str): Test period start date
        test_end (str): Test period end date
        future_steps (int): Number of future periods to forecast

    Returns:
        tuple: (updated_data_with_forecasts, future_predictions_list)
    """
    data["WEEK_START_DT"] = pd.to_datetime(data["WEEK_START_DT"])
    data = data.sort_values(by="WEEK_START_DT")
    data["rolling_avg_13"] = (
        data["TOTAL_BASELINE_AMT"].ewm(span=13, adjust=False).mean()
    )

    data_lm = data.dropna()

    train_start_dt = pd.to_datetime(train_start)
    train_end_dt = pd.to_datetime(train_end)
    test_start_dt = pd.to_datetime(test_start)
    test_end_dt = pd.to_datetime(test_end)

    data_lm_train = data_lm[
        (data_lm["WEEK_START_DT"] >= train_start_dt) &
        (data_lm["WEEK_START_DT"] <= train_end_dt)
    ]
    data_lm_test = data_lm[
        (data_lm["WEEK_START_DT"] >= test_start_dt) &
        (data_lm["WEEK_START_DT"] <= test_end_dt)
    ]

    ext_vars = [col for col in data.columns if "EXT" in col]
    reqd_cols = ["rolling_avg_13", "TOTAL_SALES_AMT"] + ext_vars

    # Configure XGBoost with production parameters
    xgb_model = XGBRFRegressor(
        n_estimators=80,
        max_depth=5,
        eta=0.1,
        subsample=0.7,
        colsample_bytree=0.8,
        random_state=42,
    )
    xgb_model.fit(data_lm_train[reqd_cols], data_lm_train["TOTAL_BASELINE_AMT"])
    predictions_train = xgb_model.predict(data_lm_train[reqd_cols])
    predictions = xgb_model.predict(data_lm_test[reqd_cols])

    final_yhat = np.append(predictions_train, predictions)
    diff_length = len(data) - len(final_yhat)
    additional_arr = np.full(diff_length, np.nan)
    final_yhat = np.append(final_yhat, additional_arr)
    data["FORECAST_BASE"] = final_yhat

    # Retrain for future predictions
    future_train = data_lm[
        (data_lm["WEEK_START_DT"] >= train_start_dt) &
        (data_lm["WEEK_START_DT"] <= test_end_dt)
    ]
    xgb_model.fit(future_train[reqd_cols], future_train["TOTAL_BASELINE_AMT"])
    values_new_fut = list(future_train["TOTAL_BASELINE_AMT"].values)
    new_predictions = []

    for i in range(future_steps):
        rolling_avg_13 = (
            pd.Series(values_new_fut).ewm(span=13, adjust=False).mean().iloc[-1]
        )
        input_row = pd.DataFrame(
            {
                "rolling_avg_13": [rolling_avg_13],
                "TOTAL_SALES_AMT": [
                    data["TOTAL_SALES_AMT"].iloc[future_train.shape[0] + i]
                ],
            }
        )
        for ext_var in ext_vars:
            input_row[ext_var] = [data[ext_var].iloc[future_train.shape[0] + i]]

        prediction = xgb_model.predict(input_row)[0]
        new_predictions.append(prediction)
        values_new_fut.append(prediction)

    return data, new_predictions


def ucm_forecast_pandas(
    data, train_start, train_end, test_start, test_end, external_data, future_steps
):
    """
    Apply Unobserved Components Model (UCM) for baseline forecasting.

    Uses state space modeling to capture trend, cycle, and irregular components
    along with external variables as exogenous factors.

    Args:
        data (pd.DataFrame): Input dataset with sales and baseline data
        train_start (str): Training period start date
        train_end (str): Training period end date
        test_start (str): Test period start date
        test_end (str): Test period end date
        external_data (pd.DataFrame): External variables data
        future_steps (int): Number of future periods to forecast

    Returns:
        tuple: (updated_data_with_forecasts, future_predictions_list)
    """
    try:
        data["WEEK_START_DT"] = pd.to_datetime(data["WEEK_START_DT"])
        data = data.sort_values(by="WEEK_START_DT")

        base = data[["TOTAL_BASELINE_AMT"]]
        base.index = data["WEEK_START_DT"]
        sales = data["TOTAL_SALES_AMT"]

        train_start_dt = pd.to_datetime(train_start)
        train_end_dt = pd.to_datetime(train_end)
        test_start_dt = pd.to_datetime(test_start)
        test_end_dt = pd.to_datetime(test_end)

        train_data = data[
            (data["WEEK_START_DT"] >= train_start_dt) &
            (data["WEEK_START_DT"] <= train_end_dt)
        ]
        test_data = data[
            (data["WEEK_START_DT"] >= test_start_dt) &
            (data["WEEK_START_DT"] <= test_end_dt)
        ]

        n_in = train_data.shape[0]

        # Prepare exogenous variables
        if external_data.empty:
            sales_train = sales.iloc[:n_in].reset_index(drop=True)
            sales_test = (
                sales.iloc[n_in:-future_steps].reset_index(drop=True)
                if future_steps > 0
                else sales.iloc[n_in:].reset_index(drop=True)
            )
            exog_train = sales_train.to_frame()
            exog_test = sales_test.to_frame()
        else:
            sales_train = sales.iloc[:n_in].reset_index(drop=True)
            sales_test = (
                sales.iloc[n_in:-future_steps].reset_index(drop=True)
                if future_steps > 0
                else sales.iloc[n_in:].reset_index(drop=True)
            )
            external_train = external_data.iloc[:n_in].reset_index(drop=True)
            external_test = (
                external_data.iloc[n_in:-future_steps].reset_index(drop=True)
                if future_steps > 0
                else external_data.iloc[n_in:].reset_index(drop=True)
            )
            exog_train = pd.concat([external_train, sales_train], axis=1)
            exog_test = pd.concat([external_test, sales_test], axis=1)

        # Configure and fit UCM model with consistent random state
        model = UnobservedComponents(
            train_data["TOTAL_BASELINE_AMT"].reset_index(drop=True),
            seasonal=None,
            stochastic_level=True,
            stochastic_trend=True,
            cycle=True,
            irregular=True,
            level=True,
            trend=True,
            exog=exog_train.reset_index(drop=True),
            random_state=1234,
        )

        model_fit = model.fit(disp=False, maxiter=500, method="lbfgs")

        # Generate forecasts for test period
        if len(test_data) > 0:
            forecast = model_fit.get_forecast(steps=len(test_data), exog=exog_test)
            forecast_mean = forecast.predicted_mean
        else:
            forecast_mean = np.array([])

        forecast_train = model_fit.get_forecast(steps=len(train_data), exog=exog_train)
        forecast_mean_train = forecast_train.predicted_mean

        final_pred_col = np.append(
            np.array(forecast_mean_train), np.array(forecast_mean)
        )
        forecast_rough = data.copy()
        diff_length = len(data) - len(final_pred_col)
        additional_arr = np.full(diff_length, np.nan)
        final_yhat = np.append(final_pred_col, additional_arr)
        forecast_rough["FORECAST_BASE"] = final_yhat

        # Train final model for future predictions
        if future_steps > 0:
            if external_data.empty:
                exog_full = sales.reset_index(drop=True).to_frame()
            else:
                exog_full = pd.concat(
                    [
                        external_data.reset_index(drop=True),
                        sales.reset_index(drop=True),
                    ],
                    axis=1,
                )

            final_model = UnobservedComponents(
                data["TOTAL_BASELINE_AMT"].dropna().reset_index(drop=True),
                seasonal=None,
                stochastic_level=True,
                stochastic_trend=True,
                irregular=True,
                level=True,
                trend=True,
                cycle=True,
                exog=exog_full.iloc[:-future_steps].reset_index(drop=True),
                random_state=1234,
            )

            final_model_fit = final_model.fit(disp=False, maxiter=500, method="lbfgs")
            future_exog = exog_full.iloc[-future_steps:].reset_index(drop=True)
            future_forecast = final_model_fit.get_forecast(
                steps=future_steps, exog=future_exog
            )
            future_forecast_mean = future_forecast.predicted_mean.tolist()
        else:
            future_forecast_mean = []

        return forecast_rough, future_forecast_mean

    except Exception as e:
        print(
            f"UCM model failed with error: {str(e)}, falling back to linear regression"
        )
        # Fallback to linear regression if UCM fails
        return linear_reg_pandas(
            data, train_start, train_end, test_start, test_end, future_steps
        )


def select_model_pandas(
    model_names, model_outputs, future_predictions, test_start, test_end, config
):
    """
    Select the best forecasting model based on evaluation metrics.

    Args:
        model_names (list): List of model names
        model_outputs (list): List of DataFrames with model forecasts
        future_predictions (list): List of future prediction values
        test_start (str): Test period start date
        test_end (str): Test period end date
        config (dict): Configuration with scoring weights

    Returns:
        tuple: (results_df, best_future_df)
    """
    results = []
    successful_indices = []  # Track which models succeeded

    for i, name in enumerate(model_names):
        try:
            data = model_outputs[i]

            test_data = data[
                (pd.to_datetime(data["WEEK_START_DT"]) >= pd.to_datetime(test_start)) &
                (pd.to_datetime(data["WEEK_START_DT"]) <= pd.to_datetime(test_end))
            ]

            if len(test_data) > 0:
                y_true = test_data["TOTAL_SALES_AMT"]
                y_pred = test_data["FORECAST_BASE"]

                # Calculate metrics
                mape = weighted_smape_pandas(y_true, y_pred) * 100
                inc_diff = get_inc_pandas(y_true, y_pred) * 100
                base_flag = selection_criteria_pandas(test_data)
                r2 = r_square_pandas(y_true, y_pred) * 100

                results.append(
                    {
                        "method": name,
                        "mape_percent_test": mape,
                        "incremental_diff": inc_diff,
                        "base_dep_flag_test": base_flag,
                        "r2_percent_test": r2,
                    }
                )
                successful_indices.append(i)  # Track successful model index

        except Exception:
            # Skip failed model entirely (no logging)
            continue

    # Convert to DataFrame and calculate final scores
    results_df = pd.DataFrame(results)

    if len(results_df) > 0:
        # Calculate weighted final score
        results_df["Final_Score"] = (
            results_df["mape_percent_test"] * config["forecast_wsmape_wt"] +
            results_df["incremental_diff"] * config["forecast_inc_diff_wt"] +
            results_df["base_dep_flag_test"] * config["forecast_trend_flag_wt"]
        )

        # Select best model (lowest score)
        best_idx = results_df["Final_Score"].idxmin()
        best_model_name = results_df.iloc[best_idx]["method"]

        # Find the original index of the best model
        best_model_original_idx = None
        for i, name in enumerate(model_names):
            if name == best_model_name and i in successful_indices:
                best_model_original_idx = i
                break

        best_future = pd.DataFrame(
            {"best_future": future_predictions[best_model_original_idx]}
        )
    else:
        # If no models succeeded, return empty DataFrames
        best_future = pd.DataFrame({"best_future": []})

    return results_df, best_future


def weighted_smape_pandas(y_true, y_pred):
    """
    Calculate Weighted Symmetric Mean Absolute Percentage Error.

    Args:
        y_true (pd.Series): Actual values
        y_pred (pd.Series): Predicted values

    Returns:
        float: WSMAPE value
    """
    total_sales = np.sum(y_true)
    actual_scaled = np.where(total_sales != 0, y_true / total_sales, y_true)

    mask = (y_true == 0) & (y_pred == 0)
    numerator = np.abs(y_true - y_pred)
    denominator = (np.abs(y_true) + np.abs(y_pred)) / 2.0
    smape_values = np.where(mask, 0, numerator / denominator)

    scaled_smape = actual_scaled * smape_values
    if np.sum(actual_scaled) != 0:
        result = np.sum(scaled_smape) / np.sum(actual_scaled)
    else:
        result = 3
    return result


def r_square_pandas(actual, pred):
    """
    Calculate R-squared coefficient of determination.

    Args:
        actual (pd.Series): Actual values
        pred (pd.Series): Predicted values

    Returns:
        float: R-squared value
    """
    actual, pred = np.array(actual), np.array(pred)
    SST = np.sum((actual - np.mean(actual)) ** 2)
    SSE = np.sum((actual - pred) ** 2)
    if np.all(actual == 0):
        if np.all(pred == 0):
            rsq = 1.0
        else:
            rsq = 0.0
    else:
        rsq = 1 - (SSE / SST)
    return rsq


def selection_criteria_pandas(data):
    """
    Calculate trend alignment flag between forecasted baseline and actual sales.

    Measures how well the direction of baseline changes aligns with sales changes,
    which is used as a model selection criterion.

    Args:
        data (pd.DataFrame): Data containing FORECAST_BASE and TOTAL_SALES_AMT

    Returns:
        int: Count of periods where trend directions don't align
    """
    base_dep_flag = np.where(
        (
            (data["FORECAST_BASE"] - data["FORECAST_BASE"].shift(1) > 0) &
            (data["TOTAL_SALES_AMT"] - data["TOTAL_SALES_AMT"].shift(1) > 0)
        ) |
        (
            (data["FORECAST_BASE"] - data["FORECAST_BASE"].shift(1) < 0) &
            (data["TOTAL_SALES_AMT"] - data["TOTAL_SALES_AMT"].shift(1) < 0)
        ),
        0,
        1,
    )
    base_dep_flag_val = np.sum(base_dep_flag)
    return base_dep_flag_val


def get_inc_pandas(y_true, y_pred):
    """
    Calculate average incremental contribution percentage.

    Args:
        y_true (pd.Series): Actual sales values
        y_pred (pd.Series): Predicted baseline values

    Returns:
        float: Average incremental contribution as percentage
    """
    actual, pred = np.array(y_true), np.array(y_pred)
    contri = np.where(actual == 0, 0, (actual - pred) / actual)
    return np.mean(contri)


def compile_and_save_forecast_output(spark, forecast_results, result_forecast, future_, job_run_id):
    """
    Compile forecast results into final output format and prepare for saving.

    Transforms forecast results into the standard baseline modeling output format
    with proper metrics structure and metadata.

    Args:
        spark (SparkSession): Active Spark session
        forecast_results (DataFrame): All model forecast results
        result_forecast (DataFrame): Model evaluation results
        future_ (DataFrame): Best model future predictions
        params (dict): Configuration parameters
        cluster_features_df (DataFrame, optional): Cluster feature mappings

    Returns:
        DataFrame: Final formatted output ready for saving to baseline table
    """
    print("Starting output compilation and saving...")

    if future_.count() == 0:
        print("No future predictions to process")
        return "NO_DATA_TO_SAVE"

    # Cap negative baseline values at zero
    future_processed = future_.withColumn(
        "best_future",
        F.when(F.col("best_future") < 0, 0.0).otherwise(F.col("best_future")),
    )

    # Create metrics structure for melting
    future_with_metrics = future_processed.select(
        F.col("WEEK_START_DT"),
        F.col("UNIQUE_BRAND_NAME"),
        F.col("SUPER_CATEGORY_NAME"),
        F.col("CLUSTER_NUM"),
        F.col("best_future").alias("TOTAL_BASELINE_AMT"),
        F.col("TOTAL_SALES_AMT"),
        (F.col("TOTAL_SALES_AMT") - F.col("best_future")).alias(
            "TOTAL_INCREMENTAL_AMT"
        ),
        F.lit(0.0).alias("TOTAL_SEASONALITY_AMT"),
    )

    # Transform to long format with separate metric DataFrames
    baseline_df = future_with_metrics.select(
        F.col("WEEK_START_DT"),
        F.col("UNIQUE_BRAND_NAME"),
        F.col("SUPER_CATEGORY_NAME"),
        F.col("CLUSTER_NUM"),
        F.lit("TOTAL_BASELINE_AMT").alias("METRIC_NAME"),
        F.col("TOTAL_BASELINE_AMT").alias("METRIC_VALUE"),
    )

    sales_df = future_with_metrics.select(
        F.col("WEEK_START_DT"),
        F.col("UNIQUE_BRAND_NAME"),
        F.col("SUPER_CATEGORY_NAME"),
        F.col("CLUSTER_NUM"),
        F.lit("TOTAL_SALES_AMT").alias("METRIC_NAME"),
        F.col("TOTAL_SALES_AMT").alias("METRIC_VALUE"),
    )

    incremental_df = future_with_metrics.select(
        F.col("WEEK_START_DT"),
        F.col("UNIQUE_BRAND_NAME"),
        F.col("SUPER_CATEGORY_NAME"),
        F.col("CLUSTER_NUM"),
        F.lit("TOTAL_INCREMENTAL_AMT").alias("METRIC_NAME"),
        F.col("TOTAL_INCREMENTAL_AMT").alias("METRIC_VALUE"),
    )

    seasonality_df = future_with_metrics.select(
        F.col("WEEK_START_DT"),
        F.col("UNIQUE_BRAND_NAME"),
        F.col("SUPER_CATEGORY_NAME"),
        F.col("CLUSTER_NUM"),
        F.lit("TOTAL_SEASONALITY_AMT").alias("METRIC_NAME"),
        F.col("TOTAL_SEASONALITY_AMT").alias("METRIC_VALUE"),
    )

    # Union all metric DataFrames
    melted_df = baseline_df.union(sales_df).union(incremental_df).union(seasonality_df)

    # # Add cluster features if available
    # if cluster_features_df is not None and cluster_features_df.count() > 0:
    #     melted_df = melted_df.join(
    #         cluster_features_df.select(
    #             "UNIQUE_BRAND_NAME",
    #             "SUPER_CATEGORY_NAME",
    #             "CLUSTER_NUM",
    #             "CLUSTER_TYPE",
    #         ),
    #         on=["UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "CLUSTER_NUM"],
    #         how="left",
    #     )
    # else:
    melted_df = melted_df.withColumn("CLUSTER_TYPE", F.lit(None).cast(StringType()))

    # Add standard metadata columns
    current_timestamp_val = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    melted_df = (
        melted_df.withColumn("ITERATION", F.lit("NA"))
        .withColumn("MODELLING_TYPE", F.lit("FORECAST_MODELLING"))
        .withColumn("JOB_RUN_ID", F.lit(job_run_id))
        .withColumn("BEST_ITERATION", F.lit("Y"))
        .withColumn("LOAD_TS", F.lit(current_timestamp_val).cast("timestamp"))
    )

    # Add model performance metrics from best model
    if result_forecast.count() > 0:
        # Identify best model for each cluster
        window_spec = Window.partitionBy(
            "UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "CLUSTER_NUM"
        ).orderBy("Final_Score")
        best_models = (
            result_forecast.withColumn("rank", F.row_number().over(window_spec))
            .filter(F.col("rank") == 1)
            .select(
                "UNIQUE_BRAND_NAME",
                "SUPER_CATEGORY_NAME",
                "CLUSTER_NUM",
                F.col("mape_percent_test").alias("WSMAPE"),
                F.col("r2_percent_test").alias("RSQ"),
            )
        )

        melted_df = melted_df.join(
            best_models,
            on=["UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "CLUSTER_NUM"],
            how="left",
        )
    else:
        melted_df = melted_df.withColumn(
            "WSMAPE", F.lit(None).cast(DoubleType())
        ).withColumn("RSQ", F.lit(None).cast(DoubleType()))

    # Set baseline percentage to null as per requirements
    melted_df = melted_df.withColumn("BASELINE_PERC", F.lit(None).cast(DoubleType()))

    # Final column selection and type casting
    final_df = melted_df.select(
        F.col("WEEK_START_DT").cast(DateType()).alias("WEEK_START_DT"),
        F.col("SUPER_CATEGORY_NAME").cast("string").alias("SUPER_CATEGORY_NAME"),
        F.col("UNIQUE_BRAND_NAME").cast("string").alias("UNIQUE_BRAND_NAME"),
        F.col("CLUSTER_NUM").cast("string").alias("CLUSTER_NUM"),
        F.col("ITERATION").cast("string").alias("ITERATION"),
        F.col("MODELLING_TYPE").cast("string").alias("MODELLING_TYPE"),
        F.col("JOB_RUN_ID").cast("string").alias("JOB_RUN_ID"),
        F.col("METRIC_NAME").cast("string").alias("METRIC_NAME"),
        F.col("LOAD_TS").alias("LOAD_TS"),
        F.col("CLUSTER_TYPE").cast("string").alias("CLUSTER_TYPE"),
        F.col("BEST_ITERATION").cast("string").alias("BEST_ITERATION"),
        F.col("METRIC_VALUE").cast("double").alias("METRIC_VALUE"),
        F.col("RSQ").cast("double").alias("RSQ"),
        F.col("WSMAPE").cast("double").alias("WSMAPE"),
        F.col("BASELINE_PERC").cast("double").alias("BASELINE_PERC"),
    )

    return final_df
