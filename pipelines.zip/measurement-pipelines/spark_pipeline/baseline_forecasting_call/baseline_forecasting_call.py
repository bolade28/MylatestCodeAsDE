from typing import List, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from spark_pipeline.baseline_forecasting_call.baseline_forecasting_functions import (
    compile_and_save_forecast_output,
    get_params,
    parallel_runner_spark,
)
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import ForecastingConfig

config = ForecastingConfig()
params = get_params(config)


def run_forecasting_pipeline(
        spark: SparkSession,
        baseline_modelling_dataset_path: str,
        baseline_forecast_path: str,
        baseline_summary_path: str,
        sku_cluster_mapping_path: str,
        external_variables_path: str,
        sales_data_path: str,
        # cluster_features_path: Optional[str],
        campaign_selection_path: str,
        output_path: str,
        run_date: str,
        job_run_id: str
) -> None:
    """
    Execute complete forecasting pipeline for baseline sales prediction.

    Objective:
        - Runs PySpark-based forecasting process for complete forecasting
          workflow
        - Performed for new items of existing Brand x Super Category when
          baseline was run less than 3 months ago.
        - Baseline Sales is forecasted from the last baseline available for
          that Cluster till current d    ate.

    Business Context:
        - Baseline sales is usually estimated by the UCM model. However in
          cases where a new product is targeted by a campaign where the
          baseline for that Brand x Super category already exists in a recent
          (less than three months baseline run) then we use forecasting script
          to estimate the baseline sales.

    Args:
        spark (SparkSession): Active Spark session
        baseline_modelling_dataset_path (str): Path to baseline modelling
            dataset (ADS data)
        baseline_forecast_path (str): Path to baseline forecast output data
        baseline_summary_path (str): Path to baseline summary/intermediate
            output data
        sku_cluster_mapping_path (str): Path to SKU cluster mapping data
        external_variables_path (str): Path to external variables dataset
        sales_data_path (str): Path to sales data
        cluster_features_path (str, optional): Path to cluster features data
        campaign_selection_path (str): Path to campaign selection data
        output_path (str): Output path for forecast results
        run_date (str): Pipeline execution date
        job_run_id (str): Unique job run identifier
        config_params (dict): Configuration parameters for forecasting

    Lineage:
        Upstream:
            - sku_refactoring_call.sql
        Downstream:
            - new_launch_estimation.py
    """

    print(f"Starting forecasting pipeline for job run: {job_run_id}")
    print(f"Run date: {run_date}")

    # Load baseline modelling dataset (ADS data)
    print("Loading baseline modelling dataset...")
    ads_df = (
        spark
        .read
        .parquet(baseline_modelling_dataset_path)
        .select(
            F.col("UNIQUE_BRAND_NAME"),
            F.col("SUPER_CATEGORY_NAME"),
            F.col("LOAD_TS"),
            F.col("VARIABLE_CD"),
            F.col("MARKETING_TYPE_NAME"),
            F.col("MARKETING_CHANNEL_NAME"),
            F.col("MARKETING_SUB_CHANNEL_NAME"),
            F.col("METRIC_NAME"),
            F.col("WEEK_START_DT"),
        )
    )

    # Load baseline forecast output data
    print("Loading baseline forecast data...")
    baseline_df = (
        spark
        .read
        .parquet(baseline_forecast_path)
        .select(
            F.col("UNIQUE_BRAND_NAME"),
            F.col("SUPER_CATEGORY_NAME"),
            F.col("CLUSTER_NUM"),
            F.col("WEEK_START_DT"),
            F.col("METRIC_NAME"),
            F.col("METRIC_VALUE"),
            F.col("LOAD_TS"),
            F.col("BEST_ITERATION"),
            F.col("MODELLING_TYPE"),
        )
        .filter(F.col("BEST_ITERATION") == "Y")
        .filter(F.col("MODELLING_TYPE") == "BASELINE_MODELLING")
    )

    # Load baseline summary/intermediate output data
    print("Loading baseline summary data...")
    baseline_summary_df = (
        spark
        .read
        .parquet(baseline_summary_path)
        .select(
            F.col("UNIQUE_BRAND_NAME"),
            F.col("SUPER_CATEGORY_NAME"),
            F.col("CLUSTER_NUM"),
            F.col("MARKETING_TYPE_NAME"),
            F.col("VARIABLE_CD"),
            F.col("LOAD_TS"),
            F.col("BEST_ITERATION")
        )
        .filter(F.col("BEST_ITERATION") == "Y")
    )

    # Load SKU cluster mapping data
    print("Loading SKU cluster mapping data...")
    sku_cluster_map_forecast_df = (
        spark
        .read
        .parquet(sku_cluster_mapping_path)
        .select(
            F.col("ITEM_CD"),
            F.col("UNIQUE_BRAND_NAME"),
            F.col("SUPER_CATEGORY_NAME"),
            F.col("CLUSTER_NUM"),
            F.coalesce(F.col("MODELLING_TYPE"), F.lit("CLUSTERING")).alias(
                "MODELLING_TYPE"
            ),
            F.col("EXCLUDED_FROM_UCM_FLAG"),
            F.col("LOAD_TS")
        )
        .filter(F.col("EXCLUDED_FROM_UCM_FLAG") == 0)
    )

    # Load external variables dataset
    print("Loading external variables data...")
    external_df = (
        spark
        .read
        .parquet(external_variables_path)
        .select(
            F.col("WEEK_START_DT"),
            F.col("MARKETING_TYPE_NAME"),
            F.col("MARKETING_CHANNEL_NAME"),
            F.col("MARKETING_SUB_CHANNEL_NAME"),
            F.col("METRIC_NAME"),
            F.col("METRIC_VALUE")
        )
    )

    # Load sales data
    print("Loading sales data...")
    sales_df = (
        spark
        .read
        .parquet(sales_data_path)
        .select(
            F.col("UNIQUE_BRAND_NAME"),
            F.col("SUPER_CATEGORY_NAME"),
            F.col("ITEM_CD"),
            F.col("WEEK_START_DT"),
            F.col("TOTAL_SALES_AMT")
        )
    )

    # Load cluster features if available
    # cluster_features_df = None
    # if cluster_features_path:
    #     print("Loading cluster features data...")
    #     cluster_features_df = (
    #         spark
    #         .read
    #         .parquet(cluster_features_path)
    #         .select(
    #             F.col("UNIQUE_BRAND_NAME"),
    #             F.col("SUPER_CATEGORY_NAME"),
    #             F.col("CLUSTER_NUM"),
    #             F.col("CLUSTER_TYPE"),
    #             F.col("LOAD_TS")
    #         )
    #     )

    # Load campaign selection data to filter for required brands and categories
    print("Loading campaign selection data...")
    campaign_selection_df = (
        spark
        .read
        .parquet(campaign_selection_path)
        .select(
            F.upper(F.col("final_status")).alias("FINAL_STATUS"),
            F.upper(F.col("unique_brand_name")).alias("UNIQUE_BRAND_NAME"),
            F.upper(F.col("super_category_name")).alias("SUPER_CATEGORY_NAME")
        )
        .filter(F.col("FINAL_STATUS").isin(["FORECASTING", "REFACTORING"]))
    )

    print(f"Campaign selection data loaded with "
          f"{campaign_selection_df.count()} forecasting campaigns")

    # Check if any data needs forecasting
    if campaign_selection_df.count() == 0:
        print("No campaigns requiring forecasting found. "
              "Pipeline completed with no processing.")
        return

    # Filter for latest data using maximum load timestamp
    print("Filtering for latest data versions...")

    # Get latest ADS data
    ads_max_cat = ads_df.groupBy("SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME").agg(
        F.max("LOAD_TS").alias("LOAD_TS")
    )
    ads_df = ads_df.join(
        ads_max_cat,
        ["SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "LOAD_TS"],
        "inner"
    )

    # Get latest baseline data
    baseline_max_cat = baseline_df.groupBy(
        "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME"
    ).agg(
        F.max("LOAD_TS").alias("LOAD_TS")
    )
    baseline_df = baseline_df.join(
        baseline_max_cat,
        ["SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "LOAD_TS"],
        "inner"
    )

    # Get latest baseline summary data
    baseline_summary_max_cat = baseline_summary_df.groupBy(
        "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME"
    ).agg(
        F.max("LOAD_TS").alias("LOAD_TS")
    )
    baseline_summary_df = baseline_summary_df.join(
        baseline_summary_max_cat,
        ["SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "LOAD_TS"],
        "inner"
    )

    # Get latest SKU cluster mapping
    sku_cluster_max_cat = sku_cluster_map_forecast_df.groupBy("ITEM_CD").agg(
        F.max("LOAD_TS").alias("LOAD_TS")
    )
    sku_cluster_map_forecast_df = sku_cluster_map_forecast_df.join(
        sku_cluster_max_cat, ["ITEM_CD", "LOAD_TS"], "inner"
    )

    # # Get latest cluster features if available
    # if cluster_features_df:
    #     cluster_features_max_cat = cluster_features_df.groupBy(
    #         "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME"
    #     ).agg(
    #         F.max("LOAD_TS").alias("LOAD_TS")
    #     )
    #     cluster_features_df = cluster_features_df.join(
    #         cluster_features_max_cat,
    #         ["SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "LOAD_TS"],
    #         "inner"
    #     ).select(
    #         "UNIQUE_BRAND_NAME",
    #         "SUPER_CATEGORY_NAME",
    #         "CLUSTER_NUM",
    #         "CLUSTER_TYPE"
    #     ).distinct()

    # Create filter keys from campaign selection
    selection_keys = [
        row.UNIQUE_BRAND_NAME + row.SUPER_CATEGORY_NAME
        for row in campaign_selection_df.select(
            "UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME"
        ).distinct().collect()
    ]

    print(f"Filtering data for {len(selection_keys)} "
          f"brand-category combinations...")

    # Apply campaign filters to all datasets
    ads_df = ads_df.withColumn(
        "KEY", F.concat(F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME"))
    ).filter(
        F.col("KEY").isin(selection_keys)
    )

    baseline_df = baseline_df.withColumn(
        "KEY", F.concat(F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME"))
    ).filter(
        F.col("KEY").isin(selection_keys)
    )

    baseline_summary_df = baseline_summary_df.withColumn(
        "KEY", F.concat(F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME"))
    ).filter(
        F.col("KEY").isin(selection_keys)
    )

    # Filter SKU mapping based on available baseline clusters
    baseline_cluster_keys = [
        row.CLUSTER_KEY for row in baseline_df.withColumn(
            "CLUSTER_KEY",
            F.concat(
                F.col("UNIQUE_BRAND_NAME"),
                F.col("SUPER_CATEGORY_NAME"),
                F.col("CLUSTER_NUM")
            )
        ).select("CLUSTER_KEY").distinct().collect()
    ]

    sku_cluster_map_forecast_df = (
        sku_cluster_map_forecast_df
        .withColumn(
            "KEY",
            F.concat(F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME"))
        )
        .withColumn(
            "CLUSTER_KEY",
            F.concat(
                F.col("UNIQUE_BRAND_NAME"),
                F.col("SUPER_CATEGORY_NAME"),
                F.col("CLUSTER_NUM")
            )
        )
        .filter(F.col("KEY").isin(selection_keys))
        .filter(F.col("CLUSTER_KEY").isin(baseline_cluster_keys))
    )

    # Filter sales data
    sales_df = sales_df.withColumn(
        "CONCAT",
        F.concat(F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME"))
    ).filter(
        F.col("CONCAT").isin(selection_keys)
    ).drop("CONCAT")

    # Filter cluster features if available
    # if cluster_features_df:
    #     cluster_features_df = cluster_features_df.withColumn(
    #         "KEY",
    #         F.concat(F.col("UNIQUE_BRAND_NAME"), F.col("SUPER_CATEGORY_NAME"))
    #     ).filter(
    #         F.col("KEY").isin(selection_keys)
    #     )

    print("Starting parallel forecasting execution...")

    # Run the forecasting process
    forecast_results, result_forecast, future_ = parallel_runner_spark(
        spark=spark,
        ads_df=ads_df,
        baseline_df=baseline_df,
        baseline_summary_df=baseline_summary_df,
        sku_cluster_map_forecast_df=sku_cluster_map_forecast_df,
        params=params,
        external_df=external_df,
        sales_df=sales_df,
        iteration_num=1
    )

    print("Forecasting execution completed. Compiling final output...")

    # Compile and format final output
    final_output = compile_and_save_forecast_output(
        spark=spark,
        forecast_results=forecast_results,
        result_forecast=result_forecast,
        future_=future_,
        job_run_id=job_run_id,
        # cluster_features_df=cluster_features_df
    )

    # Save results
    if final_output != "NO_DATA_TO_SAVE":
        print(f"Saving forecast results to: {output_path}")
        (
            final_output
            .write
            .mode("append")
            .parquet(output_path)
        )

        record_count = final_output.count()
        print("Forecasting pipeline completed successfully!")
        print(f"Output saved to: {output_path}")
        print(f"Total records processed: {record_count}")
    else:
        print("No data to save - forecasting pipeline completed with no output.")


def prepare_baseline_forecasting_data(
        spark: SparkSession,
        baseline_modelling_dataset_path: str,
        baseline_forecast_path: str,
        baseline_summary_path: str,
        sku_cluster_mapping_path: str,
        external_variables_path: str,
        sales_data_path: str,
        # cluster_features_path: Optional[str],
        campaign_selection_path: str,
        output_path: str,
        run_date: str,
        job_run_id: str
) -> None:
    """
    * Objective:
    - This script orchestrates the complete baseline sales forecasting pipeline
    - Forecasts baseline sales for new products when existing baseline data is
      available for the same Brand x Super Category combination within the last
      3 months
    - Uses multiple ML models (Linear Regression, Random Forest, XGBoost, UCM)
      and selects the best performing model based on weighted evaluation metrics

    * Business Context:
        - Baseline sales forecasting is used for new product launches when
          similar products already have recent baseline modeling results
        - Instead of running full UCM baseline modeling, this leverages existing
          patterns from similar Brand x Super Category clusters
        - Provides faster time-to-market for campaign planning and baseline
          estimation
        - Critical for promotional planning and incremental lift calculations

    * Lineage:
        Upstream:
            - sku_refactoring_call.sql (campaign selection logic)
            - baseline modeling pipeline outputs
        Downstream:
            - new_launch_estimation.py (campaign impact assessment)
            - promotional planning systems

    * Confluence:
        https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/
        baseline-forecasting-pipeline
    """

    # Execute the forecasting pipeline
    run_forecasting_pipeline(
        spark=spark,
        baseline_modelling_dataset_path=baseline_modelling_dataset_path,
        baseline_forecast_path=baseline_forecast_path,
        baseline_summary_path=baseline_summary_path,
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        external_variables_path=external_variables_path,
        sales_data_path=sales_data_path,
        # cluster_features_path=cluster_features_path,
        campaign_selection_path=campaign_selection_path,
        output_path=output_path,
        run_date=run_date,
        job_run_id=job_run_id
    )


def entrypoint(spark: SparkSession,
               command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(
        description="Execute Baseline Sales Forecasting Pipeline."
    )

    parser.add_argument(
        "--baseline-modelling-dataset-path",
        type=str,
        required=True,
        help="S3 path for baseline modelling dataset "
             "(ADS data with advertising/marketing variables)."
    )
    parser.add_argument(
        "--baseline-forecast-path",
        type=str,
        required=True,
        help="S3 path for historical baseline forecast output data "
             "from previous UCM runs."
    )
    parser.add_argument(
        "--baseline-summary-path",
        type=str,
        required=True,
        help="S3 path for baseline summary/intermediate output "
             "with significant variables."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="S3 path for SKU to cluster mapping data for aggregation."
    )
    parser.add_argument(
        "--external-variables-path",
        type=str,
        required=True,
        help="S3 path for external variables dataset (weather, events, etc.)."
    )
    parser.add_argument(
        "--sales-data-path",
        type=str,
        required=True,
        help="S3 path for sales data covering the forecasting period."
    )
    # parser.add_argument(
    #     "--cluster-features-path",
    #     type=str,
    #     required=False,
    #     default=None,
    #     help="S3 path for cluster features data (optional)."
    # )
    parser.add_argument(
        "--campaign-selection-path",
        type=str,
        required=True,
        help="S3 path for campaign selection data to filter required "
             "Brand x Super Category combinations."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for output of baseline forecasting results."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline execution date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--job-run-id",
        type=str,
        required=True,
        help="Unique job run identifier for tracking and traceability."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    # Execute the main processing function
    prepare_baseline_forecasting_data(
        spark=spark,
        baseline_modelling_dataset_path=known_args.baseline_modelling_dataset_path,
        baseline_forecast_path=known_args.baseline_forecast_path,
        baseline_summary_path=known_args.baseline_summary_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        external_variables_path=known_args.external_variables_path,
        sales_data_path=known_args.sales_data_path,
        # cluster_features_path=known_args.cluster_features_path,
        campaign_selection_path=known_args.campaign_selection_path,
        output_path=known_args.output_path,
        run_date=known_args.run_date,
        job_run_id=known_args.job_run_id
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder.appName("BaselineForecastingCall")
        .getOrCreate()
    )
