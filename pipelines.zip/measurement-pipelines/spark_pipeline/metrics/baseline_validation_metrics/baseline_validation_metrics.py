import json
from typing import List

from pyspark.sql import functions as F, DataFrame
from pyspark.sql.window import Window

from spark_pipeline.common.variables import BaselineProcessedData, Severity
from spark_pipeline.utils.baseline_events import BaselineValidationMetrics
from spark_pipeline.utils.publish_metrics import MetricsPublisher

validation_cfg = BaselineProcessedData.channel_validation_config
NON_MARKETING_FEATURE_TYPES = validation_cfg['non_marketing_feature_types']
WEATHER_METRICS = validation_cfg['weather_metrics']
ECONOMIC_METRICS = validation_cfg['economic_metrics']
DISCOUNT_METRICS = validation_cfg['discount_metrics']
EXPECTED_WEEKS = validation_cfg['expected_weeks']
ADS_EXCLUDED_MARKETING_TYPES = validation_cfg['ads_check_excluded_marketing_types']
ADS_EXCLUDED_MARKETING_CHANNELS = validation_cfg['ads_check_excluded_marketing_channels']
ZERO_WEEKS_THRESHOLD = validation_cfg['zero_weeks_threshold']
SPIKE_RATIO = validation_cfg['spike_ratio']

# Columns within non-marketing features that should never be null pre-imputation
COLUMNS_TO_CHECK: List[str] = [
    'metric_value',
    'super_category_name',
    'unique_brand_name',
    'cluster_num',
    'metric_name',
]


def check_pre_imputation_nulls_in_non_marketing_features(
        df: DataFrame,
        correlation_id: str,
        metrics_topic_arn: str,
) -> None:
    """
    Before imputation: checks that external/internal non-marketing features
    (SALES, PROMOTIONAL DISCOUNT, VALUE INDEX, PLANOGRAM, EXTERNAL) have no
    unexpected nulls in key columns.

    If nulls are found, publishes a single HIGH severity warning event via SNS,
    with metadata identifying the exact (marketing_type_name, marketing_channel_name)
    patterns and per-column null counts.
    """
    non_marketing_df = df.filter(
        F.upper(F.col("marketing_type_name")).isin(NON_MARKETING_FEATURE_TYPES)
    )

    null_agg_exprs = [
        F.sum(F.col(c).isNull().cast("int")).alias(c)
        for c in COLUMNS_TO_CHECK
    ]
    grouped_nulls = (
        non_marketing_df
        .groupBy("marketing_type_name", "marketing_channel_name")
        .agg(*null_agg_exprs)
        .collect()
    )

    affected_patterns = [
        {
            "marketing_type_name": row["marketing_type_name"],
            "marketing_channel_name": row["marketing_channel_name"],
            "null_counts": {
                c: row[c] for c in COLUMNS_TO_CHECK if row[c] > 0
            },
        }
        for row in grouped_nulls
        if any(row[c] > 0 for c in COLUMNS_TO_CHECK)
    ]

    if affected_patterns:
        total_nulls = sum(
            count
            for pattern in affected_patterns
            for count in pattern["null_counts"].values()
        )
        affected_label = ", ".join(
            f"{p['marketing_type_name']}/{p['marketing_channel_name']}"
            for p in affected_patterns
        )
        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)
        event = BaselineValidationMetrics(
            correlation_id=correlation_id,
            name="pre_imputation_null_check_non_marketing_features",
            type="null_check",
            severity=Severity.HIGH,
            comment=f"Non-marketing features with nulls before imputation: {affected_label}",
            value=str(total_nulls),
            metadata=json.dumps({"affected_patterns": affected_patterns}),
            channel_name=None,
        )
        publisher.publish_event(
            message_subject="Baseline Validation Metrics Event",
            event=event,
        )


def check_no_nulls_after_imputation(
        df: DataFrame,
        correlation_id: str,
        metrics_topic_arn: str,
) -> None:
    """
    Checks that there are no null/NA values in any column of the DataFrame after imputation.
    If nulls are found, publishes a single HIGH severity warning event via SNS.

    :param df: The DataFrame to check (post-imputation complete skeleton).
    :param correlation_id: Unique identifier for the current job run.
    :param metrics_topic_arn: The ARN for the SNS topic to publish validation metrics.
    """
    null_counts = df.agg(
        *[F.coalesce(F.sum(F.col(c).isNull().cast("int")), F.lit(0)).alias(c) for c in df.columns]
    ).first()

    null_columns = {c: null_counts[c] for c in df.columns if null_counts[c] > 0}

    if null_columns:
        total_nulls = sum(null_columns.values())
        affected = ", ".join(null_columns.keys())
        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)
        event = BaselineValidationMetrics(
            correlation_id=correlation_id,
            name="post_imputation_null_check",
            type="null_check",
            severity=Severity.HIGH,
            comment=f"Columns with nulls after imputation: {affected}",
            value=str(total_nulls),
            metadata=json.dumps({"null_columns": null_columns}),
            channel_name=None,
        )
        publisher.publish_event(
            message_subject="Baseline Validation Metrics Event",
            event=event,
        )


def check_feature_sense_checks(
        df: DataFrame,
        correlation_id: str,
        metrics_topic_arn: str,
) -> None:
    """
    Sense-checks key external features before imputation:
    - Weather and economic metrics: must have data for all EXPECTED_WEEKS distinct weeks.
    - Discount metrics: metric_value must be within [0.0, 100.0].

    Publishes one HIGH severity event per failing metric_name.
    """
    all_metrics = [*WEATHER_METRICS, *ECONOMIC_METRICS, *DISCOUNT_METRICS]

    results = (
        df.filter(F.col("metric_name").isin(all_metrics))
        .groupBy("metric_name")
        .agg(
            F.countDistinct("week_start_dt").alias("weeks_present"),
            F.sum(
                F.when(F.col("metric_value").isNull(), F.lit(0))
                .otherwise((~F.col("metric_value").between(0, 100)).cast("int"))
            ).alias("out_of_range"),
        )
        .collect()
    )

    failing = []
    for row in results:
        metric = row["metric_name"]
        if metric in WEATHER_METRICS or metric in ECONOMIC_METRICS:
            if row["weeks_present"] < EXPECTED_WEEKS:
                failing.append((metric, "week_coverage", row["weeks_present"]))
        elif metric in DISCOUNT_METRICS:
            if row["out_of_range"] > 0:
                failing.append((metric, "range_check", row["out_of_range"]))

    if failing:
        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)
        for metric, check_type, value in failing:
            if check_type == "week_coverage":
                comment = f"{metric} has only {value} weeks of data; expected {EXPECTED_WEEKS}"
                metadata = json.dumps({
                    "metric_name": metric,
                    "threshold_min": EXPECTED_WEEKS,
                    "threshold_max": None,
                })
            else:
                comment = f"{metric} has {value} values outside [0.0, 100.0]"
                metadata = json.dumps({
                    "metric_name": metric,
                    "threshold_min": 0.0,
                    "threshold_max": 100.0,
                })
            event = BaselineValidationMetrics(
                correlation_id=correlation_id,
                name="feature_sense_check",
                type=check_type,
                severity=Severity.HIGH,
                comment=comment,
                value=str(value),
                metadata=metadata,
                channel_name=None,
            )
            publisher.publish_event(
                message_subject="Baseline Validation Metrics Event",
                event=event,
            )


def check_non_zero_during_campaign_period(
        baseline_modelling_df: DataFrame,
        campaign_selection_df: DataFrame,
        correlation_id: str,
        metrics_topic_arn: str,
) -> None:
    """
    Check 4: For all features in baseline_modelling_dataset, verifies they are non-zero
    during campaign period weeks. Raises a warning for any feature where the total value
    across all campaign weeks is zero.

    Excludes: discount variables (PROMOTIONAL DISCOUNT), planogram variables (PLANOGRAM),
    and holiday/weather/festival marketing channels (HOLIDAYS, FESTIVALS, WEATHER,
    SCHOOL HOLIDAY), as these legitimately take zero values.
    """
    campaign_dates = campaign_selection_df.select(
        "unique_brand_name", "super_category_name", "min_campaign_start_dt", "max_campaign_end_dt"
    )

    zero_vars = (
        baseline_modelling_df
        .filter(
            ~F.upper(F.col("marketing_type_name")).isin(ADS_EXCLUDED_MARKETING_TYPES) &
            ~F.upper(F.col("marketing_channel_name")).isin(ADS_EXCLUDED_MARKETING_CHANNELS)
        )
        .join(F.broadcast(campaign_dates), on=["unique_brand_name", "super_category_name"], how="inner")
        .filter(
            (F.col("week_start_dt") >= F.col("min_campaign_start_dt")) &
            (F.col("week_start_dt") <= F.col("max_campaign_end_dt"))
        )
        .groupBy("unique_brand_name", "super_category_name", "cluster_num", "marketing_channel_name", "variable_cd")
        .agg(
            F.sum(F.coalesce(F.col("metric_value").cast("double"), F.lit(0.0))).alias("total_value"),
            F.count("*").alias("campaign_weeks"),
        )
        .filter((F.col("total_value") == 0) & (F.col("campaign_weeks") > 0))
        .collect()
    )

    if zero_vars:
        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)
        for row in zero_vars:
            event = BaselineValidationMetrics(
                correlation_id=correlation_id,
                name=f"ads_non_zero_campaign_period_check|{row['marketing_channel_name']}|{row['variable_cd']}",
                type="zero_check",
                severity=Severity.HIGH,
                comment=f"{row['variable_cd']} is all-zero during the campaign period ({row['campaign_weeks']} weeks)",
                value=str(row["campaign_weeks"]),
                metadata=json.dumps({
                    "unique_brand_name": row["unique_brand_name"],
                    "super_category_name": row["super_category_name"],
                    "cluster_num": row["cluster_num"],
                    "variable_cd": row["variable_cd"],
                    "campaign_weeks_checked": row["campaign_weeks"],
                }),
                channel_name=row["marketing_channel_name"],
            )
            publisher.publish_event(
                message_subject="Baseline Validation Metrics Event",
                event=event,
            )


def check_zero_null_week_count(
        baseline_modelling_df: DataFrame,
        correlation_id: str,
        metrics_topic_arn: str,
) -> None:
    """
    Check 5: For each feature in baseline_modelling_dataset, counts the number of weeks
    within the 104-week window that have a zero or null metric_value.
    Raises a warning for any feature where this count exceeds ZERO_WEEKS_THRESHOLD (50).
    """
    high_zero_vars = (
        baseline_modelling_df
        .filter(
            ~F.upper(F.col("marketing_channel_name")).isin(ADS_EXCLUDED_MARKETING_CHANNELS)
        )
        .groupBy("unique_brand_name", "super_category_name", "cluster_num", "marketing_channel_name", "variable_cd")
        .agg(
            F.sum(
                F.when(
                    F.col("metric_value").isNull() | (F.col("metric_value").cast("double") == 0.0),
                    F.lit(1)
                ).otherwise(F.lit(0))
            ).alias("zero_null_weeks")
        )
        .filter(F.col("zero_null_weeks") > ZERO_WEEKS_THRESHOLD)
        .collect()
    )

    if high_zero_vars:
        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)
        for row in high_zero_vars:
            event = BaselineValidationMetrics(
                correlation_id=correlation_id,
                name=f"ads_zero_null_week_count_check|{row['marketing_channel_name']}|{row['variable_cd']}",
                type="zero_null_check",
                severity=Severity.HIGH,
                comment=f"{row['variable_cd']} has {row['zero_null_weeks']}/{ZERO_WEEKS_THRESHOLD} zero/null weeks in the 104-week window",
                value=str(row["zero_null_weeks"]),
                metadata=json.dumps({
                    "unique_brand_name": row["unique_brand_name"],
                    "super_category_name": row["super_category_name"],
                    "cluster_num": row["cluster_num"],
                    "variable_cd": row["variable_cd"],
                    "zero_null_weeks": row["zero_null_weeks"],
                    "threshold": ZERO_WEEKS_THRESHOLD,
                }),
                channel_name=row["marketing_channel_name"],
            )
            publisher.publish_event(
                message_subject="Baseline Validation Metrics Event",
                event=event,
            )


def check_spike_outliers(
        baseline_modelling_df: DataFrame,
        correlation_id: str,
        metrics_topic_arn: str,
) -> None:
    """
    Check 6: For each feature in baseline_modelling_dataset, raises a warning if any
    single week has a value >= SPIKE_RATIO * median or <= median / SPIKE_RATIO (default 3x).
    Only non-zero, non-null weeks are considered for median calculation.
    """
    group_cols = ["unique_brand_name", "super_category_name", "cluster_num", "marketing_channel_name", "variable_cd"]
    w = Window.partitionBy(*group_cols)

    spike_vars = (
        baseline_modelling_df
        .filter(F.col("metric_value").isNotNull() & (F.col("metric_value").cast("double") != 0.0))
        .withColumn("value_d", F.col("metric_value").cast("double"))
        .withColumn("median_value", F.percentile_approx("value_d", 0.5).over(w))
        .filter(F.col("median_value") > 0)
        .filter(
            (F.col("value_d") >= SPIKE_RATIO * F.col("median_value")) |
            (F.col("value_d") <= F.col("median_value") / SPIKE_RATIO)
        )
        .groupBy(*group_cols)
        .agg(
            F.count("*").alias("spike_weeks"),
            F.collect_list(F.col("week_start_dt").cast("string")).alias("spike_week_dates"),
        )
        .collect()
    )

    if spike_vars:
        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)
        for row in spike_vars:
            event = BaselineValidationMetrics(
                correlation_id=correlation_id,
                name=f"ads_spike_outlier_check|{row['marketing_channel_name']}|{row['variable_cd']}",
                type="spike_check",
                severity=Severity.HIGH,
                comment=f"{row['variable_cd']} has {row['spike_weeks']} spike/outlier week(s) ({SPIKE_RATIO}x above or below median)",
                value=str(row["spike_weeks"]),
                metadata=json.dumps({
                    "unique_brand_name": row["unique_brand_name"],
                    "super_category_name": row["super_category_name"],
                    "cluster_num": row["cluster_num"],
                    "variable_cd": row["variable_cd"],
                    "spike_weeks": row["spike_weeks"],
                    "spike_week_dates": row["spike_week_dates"],
                    "spike_ratio": SPIKE_RATIO,
                }),
                channel_name=row["marketing_channel_name"],
            )
            publisher.publish_event(
                message_subject="Baseline Validation Metrics Event",
                event=event,
            )
