import json
from typing import List, Optional

from pyspark.sql import DataFrame, SparkSession, functions as F

from spark_pipeline.common.variables import BaselineModellingOutputConfig, Severity
from spark_pipeline.schemas.validation_metrics_schema import ValidationMetrics
from spark_pipeline.utils.baseline_events import BaselineValidationMetrics
from spark_pipeline.utils.metrics_schema import BaselineValidationMetricsSchema
from spark_pipeline.utils.publish_metrics import MetricsPublisher
from spark_pipeline.utils.stdout_logger import get_stdout_logger


def extract_metrics_by_flag(
    config: BaselineModellingOutputConfig,
    flag_name: str,
    exclude_types: Optional[set] = None,
) -> List[tuple]:
    """
    Return (marketing_type_name, marketing_channel_name, metric_name) rows from primary_metrics.

    The BaselineModellingOutputConfig.primary_metrics list uses this tuple layout:
      (marketing_type_name, marketing_channel_name, subchannel_name,
       metric_name, is_imp, is_inv)

    Args:
        config: Baseline modelling config containing primary_metrics entries.
        flag_name: Which flag to filter by; supported values are "is_imp" and "is_inv".
        exclude_types: Optional set of marketing types to skip.
    """
    flag_index_by_name = {"is_imp": 4, "is_inv": 5}
    if flag_name not in flag_index_by_name:
        raise ValueError(f"Unsupported flag_name: {flag_name}")

    excluded = exclude_types or set()
    flag_index = flag_index_by_name[flag_name]

    return [
        (metric[0], metric[1], metric[3])
        for metric in config.primary_metrics
        if metric[flag_index] == "Y" and metric[0] not in excluded
    ]


def build_signal_metrics_df(spark: SparkSession, config: BaselineModellingOutputConfig) -> DataFrame:
    """
    Build a DataFrame of signal metrics (impressions and spend) from the baseline modelling configuration.
    Args:
        spark: SparkSession instance.
        config: BaselineModellingOutputConfig containing primary_metrics to filter.
    Returns:
        DataFrame with columns: marketing_type_name, marketing_channel_name, signal_type, metric_name.
    """
    exclude_types = set(config.validation_excluded_marketing_types)
    rows = [
        (mtype, mchannel, "impressions", metric)
        for mtype, mchannel, metric in extract_metrics_by_flag(
            config=config,
            flag_name="is_imp",
            exclude_types=exclude_types,
        )
    ] + [
        (mtype, mchannel, "spend", metric)
        for mtype, mchannel, metric in extract_metrics_by_flag(
            config=config,
            flag_name="is_inv",
            exclude_types=exclude_types,
        )
    ]
    return spark.createDataFrame(
        rows,
        schema=ValidationMetrics.SIGNAL_METRICS_SCHEMA,
    )


def build_impression_metrics_df(spark: SparkSession, config: BaselineModellingOutputConfig) -> DataFrame:
    """
    Build a DataFrame of impression-like metrics to use for the range check.

    Selects metrics flagged as is_imp='Y' in primary_metrics, excluding non-marketing
    types (EXTERNAL, SALES, VALUE INDEX, PROMOTIONAL DISCOUNT, PLANOGRAM).

    For channels that do not record standard impressions, the closest proxy is used:
      - INSTORE / IN-STORE        → EXPOSED_CUSTOMERS
      - COUPON AT TILL / ECOUPON  → COUPON_VALUE
      - META, YOUTUBE, DV360, ONSITE-GOL → IMPRESSIONS

    Args:
        config: BaselineModellingOutputConfig containing primary_metrics definitions.

    Returns:
        DataFrame with columns: marketing_type_name, marketing_channel_name, metric_name.
    """
    exclude_types = set(config.validation_excluded_marketing_types)
    rows = extract_metrics_by_flag(
        config=config,
        flag_name="is_imp",
        exclude_types=exclude_types,
    )
    rows.append(("OFFSITE", "DV360_YOUTUBE", "IMPRESSIONS"))
    return spark.createDataFrame(
        rows,
        schema=ValidationMetrics.METRICS_SCHEMA,
    )


def build_spend_metrics_df(spark: SparkSession, config: BaselineModellingOutputConfig) -> DataFrame:
    """
    Build a DataFrame of spend metrics to use for the budget range check.

    Selects metrics flagged as is_inv='Y' in primary_metrics across all marketing types.
    These are the cost/spend columns for each channel:
      - INSTORE / IN-STORE             → TOTAL_MEDIA_COST
      - TARGETED MEDIA / ECOUPON       → BASE_VALUE
      - OFFSITE (META, DV360, YOUTUBE) → INTERNALS_MEDIA_SPEND / CAMPAIGN_SPEND
      - ONSITE-GOL                     → AD_SPEND

    EXTERNAL, SALES, VALUE INDEX, PROMOTIONAL DISCOUNT, and PLANOGRAM types have no
    spend metrics (all is_inv='N') so they are naturally excluded.

    Args:
        config: BaselineModellingOutputConfig containing primary_metrics definitions.

    Returns:
        DataFrame with columns: marketing_type_name, marketing_channel_name, metric_name.
    """
    rows = extract_metrics_by_flag(
        config=config,
        flag_name="is_inv",
    )
    return spark.createDataFrame(
        rows,
        schema=ValidationMetrics.METRICS_SCHEMA,
    )


# TODO:: there is a risk with harcoding values, but baseline doent not follow marketing hierarchy - maybe revisit this after usm rebuild finished.
def resolve_modelling_channels(campaign_selection_df: DataFrame) -> DataFrame:
    """
    Resolve marketing channels from campaign selection data, handling type mappings.

    Normalizes marketing types (INSTORE, IN-STORE, ONSITE, OFFSITE, COUPON-AT-TILL) into
    standardized channel pairs and extracts subchannel names for offsite channels (META, YOUTUBE, DV360).

    Args:
        campaign_selection_df: DataFrame containing marketing_types and subchannel_name.

    Returns:
        DataFrame with columns: unique_brand_name, super_category_name, min_campaign_start_dt,
        max_campaign_end_dt, marketing_type_name, marketing_channel_name.
    """
    base_cols = ["unique_brand_name", "super_category_name", "min_campaign_start_dt", "max_campaign_end_dt"]

    by_type = campaign_selection_df.select(
        *base_cols,
        F.explode("marketing_types").alias("raw_marketing_type"),
        "subchannel_name",
    )
    raw_type = F.upper(F.trim(F.col("raw_marketing_type")))

    non_offsite = (
        by_type
        .filter(raw_type != "OFFSITE")
        .withColumn(
            "channel_pairs",
            F.when(raw_type == "INSTORE",
                   F.array(
                       F.struct(F.lit("INSTORE").alias("t"), F.lit("INSTORE").alias("c")),
                       F.struct(F.lit("IN-STORE").alias("t"), F.lit("IN-STORE").alias("c")),
                   ))
             .when(raw_type == "IN-STORE",
                   F.array(
                       F.struct(F.lit("IN-STORE").alias("t"), F.lit("IN-STORE").alias("c")),
                       F.struct(F.lit("INSTORE").alias("t"), F.lit("INSTORE").alias("c")),
                   ))
             .when(raw_type.isin("COUPON-AT-TILL", "COUPON AT TILL"),
                   F.array(F.struct(F.lit("TARGETED MEDIA").alias("t"), F.lit("COUPON AT TILL").alias("c"))))
             .when(raw_type == "ONSITE",
                   F.array(
                       F.struct(F.lit("ONSITE").alias("t"), F.lit("ONSITE-GOL").alias("c")),
                       F.struct(F.lit("ONSITE").alias("t"), F.lit("ECOUPON").alias("c")),
                   ))
        )
        .filter(F.col("channel_pairs").isNotNull())
        .select(*base_cols, F.explode("channel_pairs").alias("pair"))
        .select(*base_cols, F.col("pair.t").alias("marketing_type_name"), F.col("pair.c").alias("marketing_channel_name"))
    )

    offsite = (
        by_type
        .filter(raw_type == "OFFSITE")
        .select(*base_cols, F.explode("subchannel_name").alias("raw_subchannel"))
        .withColumn(
            "marketing_channel_name",
            F.when(F.lower(F.col("raw_subchannel")).contains("meta"), "META")
             .when(F.lower(F.col("raw_subchannel")).contains("youtube"), "YOUTUBE")
             .when(F.lower(F.col("raw_subchannel")).contains("dv360"), "DV360")
             .when(F.lower(F.col("raw_subchannel")).rlike("ttd|pubmatic|experian"), "DV360_YOUTUBE")
        )
        .filter(F.col("marketing_channel_name").isNotNull())
        .withColumn("marketing_type_name", F.lit("OFFSITE"))
        .select(*base_cols, "marketing_type_name", "marketing_channel_name")
    )

    return non_offsite.unionByName(offsite).distinct()


def check_marketing_impressions_budget_signal(
    spark: SparkSession,
    campaign_selection_df: DataFrame,
    baseline_modelling_dataset_df: DataFrame,
    config: BaselineModellingOutputConfig = None,
) -> DataFrame:
    """
    Check for missing impressions and budget signal in baseline modelling dataset.

    Validates that marketing channels have non-zero impressions and spend signal during campaign weeks.
    Returns warnings for any channel/type combinations that have zero signal in one or more campaign weeks.

    Args:
        spark: SparkSession instance.
        campaign_selection_df: DataFrame with campaign selections and marketing types.
        baseline_modelling_dataset_df: DataFrame with baseline metrics (impressions, spend).
        config: BaselineModellingOutputConfig (optional) for signal metric definitions.

    Returns:
        DataFrame with warning records containing: unique_brand_name, super_category_name,
        marketing_type_name, marketing_channel_name, signal_type, zero_signal_weeks,
        total_campaign_weeks, severity, message.
    """
    if config is None:
        config = BaselineModellingOutputConfig()

    signal_metrics_df = build_signal_metrics_df(spark, config)
    campaign_channels_df = resolve_modelling_channels(campaign_selection_df)

    baseline_with_channels = (
        baseline_modelling_dataset_df
        .join(
            campaign_channels_df,
            on=["unique_brand_name", "super_category_name", "marketing_type_name", "marketing_channel_name"],
            how="inner",
        )
        .filter(
            (baseline_modelling_dataset_df["week_start_dt"] >= campaign_channels_df["min_campaign_start_dt"])
            & (baseline_modelling_dataset_df["week_start_dt"] <= campaign_channels_df["max_campaign_end_dt"])
        )
        .select(
            campaign_channels_df["unique_brand_name"].alias("unique_brand_name"),
            campaign_channels_df["super_category_name"].alias("super_category_name"),
            campaign_channels_df["min_campaign_start_dt"].alias("min_campaign_start_dt"),
            campaign_channels_df["max_campaign_end_dt"].alias("max_campaign_end_dt"),
            baseline_modelling_dataset_df["marketing_type_name"].alias("marketing_type_name"),
            baseline_modelling_dataset_df["marketing_channel_name"].alias("marketing_channel_name"),
            baseline_modelling_dataset_df["week_start_dt"].alias("week_start_dt"),
            baseline_modelling_dataset_df["metric_name"].alias("metric_name"),
            baseline_modelling_dataset_df["metric_value"].alias("metric_value"),
        )
        .join(signal_metrics_df, on=["marketing_type_name", "marketing_channel_name", "metric_name"], how="inner")
    )

    weekly_signal = (
        baseline_with_channels
        .groupBy(
            "unique_brand_name", "super_category_name", "min_campaign_start_dt", "max_campaign_end_dt",
            "marketing_type_name", "marketing_channel_name", "signal_type", "week_start_dt",
        )
        .agg(F.sum(F.coalesce(F.col("metric_value"), F.lit(0))).alias("total_signal"))
    )

    marketing_signals_df = (
        weekly_signal
        .groupBy(
            "unique_brand_name", "super_category_name", "min_campaign_start_dt", "max_campaign_end_dt",
            "marketing_type_name", "marketing_channel_name", "signal_type",
        )
        .agg(
            F.count("week_start_dt").alias("total_campaign_weeks"),
            F.sum(F.when(F.col("total_signal") == 0, 1).otherwise(0)).alias("zero_signal_weeks"),
        )
        .filter(F.col("zero_signal_weeks") > 0)
        .withColumn("severity", F.lit(Severity.HIGH))
        .withColumn(
            "message",
            F.format_string(
                "%s/%s has zero %s signal in %d/%d campaign weeks",
                F.col("marketing_type_name"),
                F.col("marketing_channel_name"),
                F.col("signal_type"),
                F.col("zero_signal_weeks"),
                F.col("total_campaign_weeks"),
            )
        )
        .select(
            "unique_brand_name", "super_category_name",
            "marketing_type_name", "marketing_channel_name",
            "signal_type", "zero_signal_weeks", "total_campaign_weeks",
            "severity", "message",
        )
    )
    return marketing_signals_df


def check_value_range(
    baseline_modelling_dataset_df: DataFrame,
    metrics_lookup_df: DataFrame,
    min_threshold: float,
    max_threshold: float,
) -> DataFrame:
    """
    Flag (type, channel, metric) combinations with at least one week where metric_value
    is outside [min_threshold, max_threshold].

    Null values are skipped — they indicate missing data, not a range violation.
    """
    verify_value_range_df = (
        baseline_modelling_dataset_df
        .join(metrics_lookup_df, on=["marketing_type_name", "marketing_channel_name", "metric_name"], how="inner")
        .filter(
            F.col("metric_value").isNotNull() &
            (
                (F.col("metric_value") < min_threshold) |
                (F.col("metric_value") > max_threshold)
            )
        )
        .groupBy(
            "unique_brand_name", "super_category_name",
            "marketing_type_name", "marketing_channel_name", "metric_name",
        )
        .agg(
            F.count("week_start_dt").alias("out_of_range_weeks"),
            F.sort_array(
                F.collect_list(
                    F.struct(
                        F.col("week_start_dt").cast("string").alias("week"),
                        F.col("metric_value").cast("double").alias("value"),
                    )
                )
            ).alias("out_of_range_week_dates"),
            # Cast to double: metric_value are Decimal,
            # and F.format_string's %.2f specifier requires double/float.
            F.min(F.col("metric_value").cast("double")).alias("min_value"),
            F.max(F.col("metric_value").cast("double")).alias("max_value"),
        )
        .withColumn("severity", F.lit(Severity.HIGH))
        .withColumn(
            "message",
            F.format_string(
                f"%s/%s %s has %d week(s) with values outside [{min_threshold:.1f}, {max_threshold:.1f}] (min=%.2f, max=%.2f)",
                F.col("marketing_type_name"),
                F.col("marketing_channel_name"),
                F.col("metric_name"),
                F.col("out_of_range_weeks"),
                F.col("min_value"),
                F.col("max_value"),
            )
        )
        .select(
            "unique_brand_name", "super_category_name",
            "marketing_type_name", "marketing_channel_name",
            "metric_name", "out_of_range_weeks", "out_of_range_week_dates",
            "min_value", "max_value",
            "severity", "message",
        )
    )
    return verify_value_range_df


def check_marketing_impressions_range(
    spark: SparkSession,
    baseline_modelling_dataset_df: DataFrame,
    config: BaselineModellingOutputConfig = None,
) -> DataFrame:
    """
    Check that impression-like weekly values across all weeks are within expected bounds.

    Validates that impression-like metric values (e.g. IMPRESSIONS, EXPOSED_CUSTOMERS,
    COUPON_VALUE) are >= min_impressions_threshold and <= max_impressions_threshold for every
    week in the baseline modelling dataset — not just campaign weeks.

    This catches:
      - Negative values caused by upstream data corrections or pipeline errors
      - Implausibly large spikes from unit mismatches or duplicated rows

    The check covers all (brand, category, channel) combinations present in the dataset,
    regardless of whether they appear in campaign_selection.

    Args:
        baseline_modelling_dataset_df: DataFrame with weekly marketing metrics.
        config: BaselineModellingOutputConfig (optional). Uses default config if None.

    Returns:
        DataFrame with one row per (brand, category, channel, metric) combination
        with at least one out-of-range week. Columns: unique_brand_name,
        super_category_name, marketing_type_name, marketing_channel_name,
        metric_name, out_of_range_weeks, min_value, max_value, severity, message.
    """
    if config is None:
        config = BaselineModellingOutputConfig()

    return check_value_range(
        baseline_modelling_dataset_df,
        build_impression_metrics_df(spark, config),
        config.min_impressions_threshold,
        config.max_impressions_threshold,
    )


def check_marketing_budget_range(
    spark: SparkSession,
    baseline_modelling_dataset_df: DataFrame,
    config: BaselineModellingOutputConfig = None,
) -> DataFrame:
    """
    Check that marketing spend weekly values across all weeks are within expected bounds.

    Validates that spend metrics (e.g. TOTAL_MEDIA_COST, CAMPAIGN_SPEND, AD_SPEND, BASE_VALUE)
    are >= min_spend_threshold and <= max_spend_threshold for every week in the baseline
    modelling dataset — not just campaign weeks.

    This catches:
      - Negative values caused by upstream data corrections or pipeline errors
      - Implausibly large values from unit mismatches or duplicated rows

    The check covers all (brand, category, channel) combinations present in the dataset,
    regardless of whether they appear in campaign_selection.

    Args:
        baseline_modelling_dataset_df: DataFrame with weekly marketing metrics.
            Expected columns: unique_brand_name, super_category_name,
            marketing_type_name, marketing_channel_name, week_start_dt,
            metric_name, metric_value.
        config: BaselineModellingOutputConfig (optional). Uses default config if None.

    Returns:
        DataFrame with one row per (brand, category, channel, metric) combination
        that has at least one out-of-range week. Columns: unique_brand_name,
        super_category_name, marketing_type_name, marketing_channel_name,
        metric_name, out_of_range_weeks, min_value, max_value, severity, message.
    """
    if config is None:
        config = BaselineModellingOutputConfig()
    return check_value_range(
        baseline_modelling_dataset_df,
        build_spend_metrics_df(spark, config),
        config.min_spend_threshold,
        config.max_spend_threshold,
    )


def run_all_marketing_checks(
    spark: SparkSession,
    campaign_selection_df: DataFrame,
    baseline_modelling_dataset_df: DataFrame,
    config: BaselineModellingOutputConfig,
) -> DataFrame:
    """
    Run all marketing input validation checks and return a unified warnings DataFrame.

    Each check result is normalised to a common schema before combining:
      - unique_brand_name, super_category_name, marketing_type_name, marketing_channel_name
      - severity, message, check_name, metadata (JSON string of check-specific fields)

    Checks:
      1. marketing_signal_check  — zero impressions/spend for booked channels during campaign weeks
      2. impressions_range_check — impression-like values outside [0, 2,000,000] across all weeks
      3. budget_range_check      — spend values outside [0, 50,000] across all weeks
    """
    # Check 1: marketing_signal_check — zero impressions/spend for booked channels during campaign weeks
    signal_warnings_df = check_marketing_impressions_budget_signal(
        spark=spark,
        campaign_selection_df=campaign_selection_df,
        baseline_modelling_dataset_df=baseline_modelling_dataset_df,
        config=config,
    ).select(
        "unique_brand_name", "super_category_name", "marketing_type_name", "marketing_channel_name",
        "severity", "message",
        F.lit("marketing_signal_check").alias("check_name"),
        F.to_json(
            F.struct(
                "signal_type",
                "zero_signal_weeks",
                "total_campaign_weeks",
                F.array(F.lit(0), F.lit(0)).alias("threshold_range"),
            )
        ).alias("metadata"),
    )

    # Check 2: impressions_range_check — impression-like values outside [0, 2,000,000] across all weeks
    impressions_warnings_df = check_marketing_impressions_range(
        spark=spark,
        baseline_modelling_dataset_df=baseline_modelling_dataset_df,
        config=config,
    ).select(
        "unique_brand_name", "super_category_name", "marketing_type_name", "marketing_channel_name",
        "severity", "message",
        F.lit("impressions_range_check").alias("check_name"),
        F.to_json(
            F.struct(
                "metric_name",
                "out_of_range_weeks",
                "out_of_range_week_dates",
                "min_value",
                "max_value",
                F.array(
                    F.lit(config.min_impressions_threshold),
                    F.lit(config.max_impressions_threshold),
                ).alias("threshold_range"),
            )
        ).alias("metadata"),
    )

    # Check 3: budget_range_check — spend values outside [0, 50,000] across all weeks
    spend_warnings_df = check_marketing_budget_range(
        spark=spark,
        baseline_modelling_dataset_df=baseline_modelling_dataset_df,
        config=config,
    ).select(
        "unique_brand_name", "super_category_name", "marketing_type_name", "marketing_channel_name",
        "severity", "message",
        F.lit("budget_range_check").alias("check_name"),
        F.to_json(
            F.struct(
                "metric_name",
                "out_of_range_weeks",
                "out_of_range_week_dates",
                "min_value",
                "max_value",
                F.array(
                    F.lit(config.min_spend_threshold),
                    F.lit(config.max_spend_threshold),
                ).alias("threshold_range"),
            )
        ).alias("metadata"),
    )

    all_warnings = (
        signal_warnings_df
        .unionByName(impressions_warnings_df)
        .unionByName(spend_warnings_df)
    )
    return all_warnings


def publish_marketing_validation_metrics(
    spark: SparkSession,
    campaign_selection_df: DataFrame,
    baseline_modelling_dataset_df: DataFrame,
    metrics_topic_arn: str,
    correlation_id: str,
    config: BaselineModellingOutputConfig = None,
) -> None:
    """
    Run all marketing input validation checks and publish any warnings to SNS.

    Args:
        spark: SparkSession instance.
        campaign_selection_df: DataFrame with campaign selections and marketing types.
        baseline_modelling_dataset_df: DataFrame with weekly baseline metrics.
        metrics_topic_arn: ARN of the SNS topic to publish metrics events to.
        correlation_id: Correlation ID for the current pipeline run.
        config: BaselineModellingOutputConfig (optional). Uses default config if None.
    """
    if config is None:
        config = BaselineModellingOutputConfig()

    logger = get_stdout_logger()
    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

    all_warnings = run_all_marketing_checks(
        spark=spark,
        campaign_selection_df=campaign_selection_df,
        baseline_modelling_dataset_df=baseline_modelling_dataset_df,
        config=config,
    ).collect()
    logger.info(f"Found {len(all_warnings)} total validation warning(s).", log_type="marketing_validation")

    _db_schema = BaselineValidationMetricsSchema()
    logger.info(
        f"Publishing to table: {_db_schema.schema}.{_db_schema.table_name} (write_operation={_db_schema.write_operation})",
        log_type="marketing_validation",
    )

    for row in all_warnings:
        metadata = json.loads(row["metadata"])
        metadata["correlation_id"] = correlation_id
        metadata["channel_name"] = row["marketing_channel_name"]
        out_of_range_week_dates = metadata.get("out_of_range_week_dates")
        if out_of_range_week_dates is not None:
            logger.info(
                f"Range check summary: check={row['check_name']} channel={row['marketing_channel_name']} "
                f"metric={metadata.get('metric_name', 'unknown')} out_of_range_week_dates={out_of_range_week_dates}",
                log_type="marketing_validation",
            )
        metadata.pop("out_of_range_week_dates", None)
        # metric_key distinguishes the check variant (e.g. EXPOSED_CUSTOMERS, impressions, spend).
        # unique_name keeps the UPSERT key (name + correlation_id) distinct per brand/channel/metric
        # so multiple warnings of the same check_name do not overwrite each other.
        metric_key = metadata.get("metric_name") or metadata.get("signal_type", "unknown")
        unique_name = f"{row['check_name']}|{row['marketing_channel_name']}|{metric_key}"

        event = BaselineValidationMetrics(
            correlation_id=correlation_id,
            name=unique_name,
            type=metric_key,
            severity=row["severity"],
            comment=row["message"],
            value=0,
            metadata=json.dumps(metadata),
            channel_name=row["marketing_channel_name"],
        )
        try:
            publisher.publish_event(
                message_subject="Baseline Validation Metrics Event",
                event=event,
            )
            logger.info(f"Published warning: {row['message']}", log_type="marketing_validation")
        except Exception as e:
            logger.error(
                f"Failed to publish warning for {row['unique_brand_name']}/{row['marketing_channel_name']}: {e}"
            )
