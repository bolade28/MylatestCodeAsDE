import json
from datetime import timedelta
from typing import Optional

from pyspark.sql import DataFrame, Window, functions as F

from spark_pipeline.common.variables import (
    BaselineModellingOutputConfig,
    BaselineProcessedData,
    CampaignDurations,
)
from spark_pipeline.schemas.validation_metrics_schema import ValidationMetrics
from spark_pipeline.utils.baseline_events import BaselineValidationMetrics
from spark_pipeline.utils.metrics_schema import BaselineValidationMetricsSchema
from spark_pipeline.utils.publish_metrics import MetricsPublisher
from spark_pipeline.utils.stdout_logger import get_stdout_logger


SALES_SERIES_GROUP_COLS = [
    "unique_brand_name",
    "super_category_name",
    "cluster_num",
    "marketing_type_name",
    "marketing_channel_name",
    "metric_name",
]


def _empty_df(source_df: DataFrame, schema) -> DataFrame:
    return source_df.sparkSession.createDataFrame([], schema=schema)


def _normalise_duration_label(duration_label: Optional[str]) -> Optional[str]:
    return duration_label.strip().lower() if duration_label else None


def _resolve_validation_metric_value(check_name: str, metadata: dict) -> str:
    """
    Resolve the primary numeric value to publish for a metric.

    Each check stores richer detail inside `metadata`, but the metrics event also exposes a top-
    level numeric `value`. This helper maps each check to the most useful summary figure so
    downstream consumers can sort or aggregate warnings without parsing the metadata JSON.

    Args:
        check_name: Name of the validation check being published.
        metadata: Parsed metadata dictionary for the warning.

    Returns:
        String representation of the primary numeric value for the check. Returns "0" when the
        check has no recognised numeric summary.
    """
    if check_name == "sales_zero_streak_check":
        return str(metadata.get("longest_zero_sales_streak", 0))

    if check_name in {
        "near_zero_sales_check",
        "during_period_near_zero_check",
        "post_period_near_zero_check",
    }:
        return str(metadata.get("near_zero_weeks", 0))

    if check_name == "sales_distribution_outlier_check":
        total_flagged_weeks = (
            metadata.get("median_outlier_weeks", 0)
            + metadata.get("isolated_extreme_weeks", 0)
        )
        return str(total_flagged_weeks)

    return "0"


def filter_sales_baseline_dataset(
    baseline_modelling_dataset_df: DataFrame,
) -> DataFrame:
    """
    Filter the baseline modelling dataset down to the TOTAL_SALES series used by sales checks.

    The sales metric definitions come from BaselineProcessedData.sales_data_config so the
    validation logic stays aligned with the baseline processed-data pipeline.
    """
    sales_config = BaselineProcessedData.sales_data_config
    group_cols = [
        "unique_brand_name",
        "super_category_name",
        "cluster_num",
        "marketing_type_name",
        "marketing_channel_name",
        "week_start_dt",
        "metric_name",
    ]

    return (
        baseline_modelling_dataset_df
        .select(*group_cols, F.col("metric_value").cast("double").alias("metric_value"))
        .withColumn("week_start_dt", F.to_date("week_start_dt"))
        .filter(
            (F.upper(F.col("marketing_type_name")) == F.lit(sales_config["marketing_type_name"]))
            & (F.upper(F.col("marketing_channel_name")) == F.lit(sales_config["marketing_channel_name"]))
            & (F.upper(F.col("metric_name")) == F.lit(sales_config["metric_name"]))
        )
    )


def select_recent_sales_window(
    sales_baseline_df: DataFrame,
    config: Optional[BaselineModellingOutputConfig] = None,
) -> DataFrame:
    """
    Keep only the most recent configured lookback window (104 weeks) ending at the run's latest sales week.

    Check 2 explicitly needs the last 104 weeks counted backwards from the end of the run.
    The same recent window is re-used for checks 3–6 so all sales validations inspect the
    same modelling period.

    The runs only contain 2 years worth of data anyway, so this mostly serves to future-proof against any unexpected increase in the modelling window length
    or if we want to examine a different period in the future.
    """
    if config is None:
        config = BaselineModellingOutputConfig()

    latest_week = sales_baseline_df.agg(F.max("week_start_dt").alias("latest_week")).first()["latest_week"]
    if latest_week is None:
        return _empty_df(sales_baseline_df, ValidationMetrics.SALES_BASELINE_SCHEMA)

    lookback_start_dt = latest_week - timedelta(weeks=config.sales_validation_lookback_weeks - 1)
    return sales_baseline_df.filter(
        (F.col("week_start_dt") >= F.lit(lookback_start_dt))
        & (F.col("week_start_dt") <= F.lit(latest_week))
    )


def resolve_sales_campaign_periods(campaign_selection_df: DataFrame) -> DataFrame:
    """
    Resolve the campaign timing window used by the sales checks.

    Sales validations only need the brand/category timing columns from campaign_selection:
      - min_campaign_start_dt
      - max_campaign_end_dt
      - max_post_campaign_dt (when available for post-period validation)
    """
    max_post_expr = (
        F.max(F.to_date("max_post_campaign_dt")).alias("max_post_campaign_dt")
        if "max_post_campaign_dt" in campaign_selection_df.columns
        else F.max(F.to_date("max_campaign_end_dt")).alias("max_post_campaign_dt")
    )

    return (
        campaign_selection_df
        .select(
            "unique_brand_name",
            "super_category_name",
            F.to_date("min_campaign_start_dt").alias("min_campaign_start_dt"),
            F.to_date("max_campaign_end_dt").alias("max_campaign_end_dt"),
            *([F.to_date("max_post_campaign_dt").alias("max_post_campaign_dt")] if "max_post_campaign_dt" in campaign_selection_df.columns else []),
        )
        .groupBy("unique_brand_name", "super_category_name")
        .agg(
            F.min("min_campaign_start_dt").alias("min_campaign_start_dt"),
            F.max("max_campaign_end_dt").alias("max_campaign_end_dt"),
            max_post_expr,
        )
    )


def check_sales_zero_streaks(
    sales_baseline_df: DataFrame,
    config: Optional[BaselineModellingOutputConfig] = None,
) -> DataFrame:
    """
    Check 2: warn when the last 104 weeks contain any zero-sales streak of 4+ consecutive weeks.

    For each brand/category/cluster series, the function finds
    consecutive runs where `metric_value == 0.0` and raises a warning when any run reaches the
    configured minimum streak length (currently 4)

    Args:
        sales_baseline_df: Sales baseline rows for the period being validated. Each row represents
            one weekly TOTAL_SALES value for a brand/category/cluster series.
        config: Optional validation config. When omitted, the default
            `BaselineModellingOutputConfig` is used.

    Returns:
        DataFrame matching `ValidationMetrics.SALES_ZERO_STREAK_SCHEMA` with one warning row per
        affected sales series.
    """
    if config is None:
        config = BaselineModellingOutputConfig()

    order_window = (
        Window.partitionBy(*SALES_SERIES_GROUP_COLS)
        .orderBy("week_start_dt")
        .rowsBetween(Window.unboundedPreceding, 0)
    )

    # Assign each run of consecutive zero-sales weeks to its own streak id.
    zero_sales_with_groups_df = (
        sales_baseline_df
        .withColumn("is_zero_sales", F.when(F.col("metric_value") == 0.0, 1).otherwise(0))
        .withColumn("zero_streak_reset_flag", F.when(F.col("metric_value") == 0.0, 0).otherwise(1))  # flag to identify when we hit a non-zero value that should reset the zero-sales streak id
        .withColumn("zero_streak_group", F.sum("zero_streak_reset_flag").over(order_window))  # every time we hit a non-zero value (zero_streak_reset_flag), increment the group number (zero_streak_group)
    )

    zero_streak_lengths_df = (
        zero_sales_with_groups_df
        .filter(F.col("is_zero_sales") == 1)  # Filter out only the non-zero sales weeks so we don't count them
        .groupBy(*SALES_SERIES_GROUP_COLS, "zero_streak_group")
        .agg(
            F.count("week_start_dt").alias("zero_sales_weeks"),
            F.sort_array(
                F.collect_list(
                    F.struct(
                        F.col("week_start_dt").cast("string").alias("week"),
                        F.col("metric_value").alias("value"),
                    )
                )
            ).alias("zero_sales_week_dates"),
        )
    )

    warning_streaks_df = zero_streak_lengths_df.filter(
        F.col("zero_sales_weeks") >= F.lit(config.sales_zero_streak_warning_weeks)
    )

    # Keep the longest warning streak per series so each series publishes a single warning row.
    zero_streaks_df = (
        warning_streaks_df
        .withColumn(
            "streak_details",
            F.struct(
                F.col("zero_sales_weeks").alias("longest_zero_sales_streak"),
                F.col("zero_sales_week_dates").alias("zero_sales_week_dates"),
            ),
        )
        .groupBy(*SALES_SERIES_GROUP_COLS)
        .agg(F.max("streak_details").alias("streak_details"))
        .select(
            *SALES_SERIES_GROUP_COLS,
            F.col("streak_details.longest_zero_sales_streak").alias("longest_zero_sales_streak"),
            F.col("streak_details.zero_sales_week_dates").alias("zero_sales_week_dates"),
        )
        .withColumn("severity", F.lit("MEDIUM"))
        .withColumn(
            "message",
            F.format_string(
                "%s/%s cluster %s has a %d-week zero-sales streak in the last %d weeks",
                F.col("unique_brand_name"),
                F.col("super_category_name"),
                F.col("cluster_num"),
                F.col("longest_zero_sales_streak"),
                F.lit(config.sales_validation_lookback_weeks),
            ),
        )
        .select(*ValidationMetrics.SALES_ZERO_STREAK_SCHEMA.fieldNames())
    )

    # Format into final output for warning metrics
    zero_streak_warnings_df = (
        zero_streaks_df
        .select(
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "severity",
            "message",
            F.lit("sales_zero_streak_check").alias("check_name"),
            F.to_json(
                F.struct(
                    "metric_name",
                    "longest_zero_sales_streak",
                    "zero_sales_week_dates",
                    F.array(
                        F.lit(0),
                        F.lit(config.sales_zero_streak_warning_weeks - 1),
                    ).alias("threshold_range"),
                    F.lit(config.sales_validation_lookback_weeks).alias("lookback_weeks"),
                )
            ).alias("metadata"),
        )
    )
    return zero_streak_warnings_df


def check_sales_near_zero_weeks(
    sales_baseline_df: DataFrame,
    config: Optional[BaselineModellingOutputConfig] = None,
) -> DataFrame:
    """
    Check 3: warn when any single week has TOTAL_SALES very close to 0.0.

    A warning is raised whenever the absolute weekly sales value is below
    or equal to the configured near-zero threshold.

    Args:
        sales_baseline_df: Sales baseline rows for the period being validated.
        config: Optional validation config. When omitted, the default
            `BaselineModellingOutputConfig` is used.

    Returns:
        DataFrame matching `ValidationMetrics.SALES_NEAR_ZERO_SCHEMA` with one warning row per
        affected sales series.
    """
    if config is None:
        config = BaselineModellingOutputConfig()

    # Surface the exact week(s) that are close to zero.
    near_zero_weeks_df = sales_baseline_df.filter(
        F.abs(F.col("metric_value")) <= F.lit(config.sales_near_zero_threshold)
    )

    near_zero_df = (
        near_zero_weeks_df
        .groupBy(*SALES_SERIES_GROUP_COLS)
        .agg(
            F.count("week_start_dt").alias("near_zero_weeks"),
            F.sort_array(
                F.collect_list(
                    F.struct(
                        F.col("week_start_dt").cast("string").alias("week"),
                        F.col("metric_value").alias("value"),
                    )
                )
            ).alias("near_zero_week_dates"),
        )
        .withColumn("severity", F.lit("MEDIUM"))
        .withColumn(
            "message",
            F.format_string(
                "%s/%s cluster %s has %d week(s) with TOTAL_SALES within ±%.2f of zero",
                F.col("unique_brand_name"),
                F.col("super_category_name"),
                F.col("cluster_num"),
                F.col("near_zero_weeks"),
                F.lit(config.sales_near_zero_threshold),
            ),
        )
        .select(*ValidationMetrics.SALES_NEAR_ZERO_SCHEMA.fieldNames())
    )

    # Format into final output for warning metrics
    near_zero_warnings_df = (
        near_zero_df
        .select(
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "severity",
            "message",
            F.lit("near_zero_sales_check").alias("check_name"),
            F.to_json(
                F.struct(
                    "metric_name",
                    "near_zero_weeks",
                    "near_zero_week_dates",
                    F.array(F.lit(0.0), F.lit(config.sales_near_zero_threshold)).alias("threshold_range"),
                )
            ).alias("metadata"),
        )
    )
    return near_zero_warnings_df


def _get_sales_distribution_ranking_windows():
    """Return the ascending and descending rank windows used for isolated-extreme checks."""
    descending_window = Window.partitionBy(*SALES_SERIES_GROUP_COLS).orderBy(
        F.col("metric_value").desc(),
        F.col("week_start_dt").asc(),
    )

    ascending_window = Window.partitionBy(*SALES_SERIES_GROUP_COLS).orderBy(
        F.col("metric_value").asc(),
        F.col("week_start_dt").asc(),
    )

    return descending_window, ascending_window


def _calculate_sales_medians(sales_baseline_df: DataFrame) -> DataFrame:
    """Calculate the approximate median sales value for each sales series."""
    return (
        sales_baseline_df
        .groupBy(*SALES_SERIES_GROUP_COLS)
        .agg(
            F.percentile_approx("metric_value", 0.5, 10_000).alias("median_sales")
        )
    )


def _find_sales_median_band_outliers(
    sales_baseline_df: DataFrame,
    median_sales_df: DataFrame,
    config: BaselineModellingOutputConfig,
) -> DataFrame:
    """Find weeks that fall outside the configured median band for each sales series."""
    return (
        sales_baseline_df
        .join(median_sales_df, on=SALES_SERIES_GROUP_COLS, how="inner")
        .filter(
            (F.col("median_sales") > F.lit(config.sales_near_zero_threshold))
            & (
                (F.col("metric_value") > F.col("median_sales") * F.lit(config.sales_outlier_multiplier))  # 3 * median_sales
                | (F.col("metric_value") < F.col("median_sales") / F.lit(config.sales_outlier_multiplier))  # median_sales / 3
            )
        )
        .groupBy(*SALES_SERIES_GROUP_COLS, "median_sales")
        .agg(
            F.count("week_start_dt").alias("median_outlier_weeks"),
            F.sort_array(
                F.collect_list(
                    F.struct(
                        F.col("week_start_dt").cast("string").alias("week"),
                        F.col("metric_value").alias("value"),
                    )
                )
            ).alias("median_outlier_week_dates"),
        )
    )


def _rank_sales_for_distribution_checks(sales_baseline_df: DataFrame) -> DataFrame:
    """Attach ascending and descending row-number ranks to each weekly sales row."""
    descending_window, ascending_window = _get_sales_distribution_ranking_windows()
    return (
        sales_baseline_df
        .withColumn("desc_rank", F.row_number().over(descending_window))
        .withColumn("asc_rank", F.row_number().over(ascending_window))
    )


def _find_high_sales_isolated_extremes(
    ranked_sales_df: DataFrame,
    config: BaselineModellingOutputConfig,
) -> DataFrame:
    """Identify series whose single highest week is much larger than the next-highest week."""
    highest_df = (
        ranked_sales_df
        .filter(F.col("desc_rank") == 1)
        .select(
            *SALES_SERIES_GROUP_COLS,
            F.col("metric_value").alias("highest_sales"),
            F.col("week_start_dt").cast("string").alias("highest_week"),
        )
    )

    second_highest_df = (
        ranked_sales_df
        .filter(F.col("desc_rank") == 2)
        .select(
            *SALES_SERIES_GROUP_COLS,
            F.col("metric_value").alias("second_highest_sales"),
        )
    )

    return (
        highest_df
        .join(second_highest_df, on=SALES_SERIES_GROUP_COLS, how="left")
        .filter(
            # Ignore one-row series because they do not have a comparison week.
            F.col("second_highest_sales").isNotNull()
            & (F.col("highest_sales") > F.col("second_highest_sales") * F.lit(config.sales_outlier_multiplier))
        )
        .select(
            *SALES_SERIES_GROUP_COLS,
            F.lit(1).alias("isolated_extreme_weeks"),
            F.array(
                F.struct(
                    F.col("highest_week").alias("week"),
                    F.col("highest_sales").alias("value"),
                )
            ).alias("isolated_extreme_week_dates"),
        )
    )


def _find_low_sales_isolated_extremes(
    ranked_sales_df: DataFrame,
    config: BaselineModellingOutputConfig,
) -> DataFrame:
    """Identify series whose single lowest week is much smaller than the next-lowest week."""

    lowest_df = (
        ranked_sales_df.filter(F.col("asc_rank") == 1)
        .select(
            *SALES_SERIES_GROUP_COLS,
            F.col("metric_value").alias("lowest_sales"),
            F.col("week_start_dt").cast("string").alias("lowest_week"),
        )
    )

    second_lowest_df = (
        ranked_sales_df
        .filter(F.col("asc_rank") == 2)
        .select(
            *SALES_SERIES_GROUP_COLS,
            F.col("metric_value").alias("second_lowest_sales"),
        )
    )

    return (
        lowest_df
        .join(second_lowest_df, on=SALES_SERIES_GROUP_COLS, how="left")
        .filter(
            # Ignore one-row series because they do not have a comparison week.
            F.col("second_lowest_sales").isNotNull()
            & (F.col("lowest_sales") * F.lit(config.sales_outlier_multiplier) < F.col("second_lowest_sales"))
        )
        .select(
            *SALES_SERIES_GROUP_COLS,
            F.lit(1).alias("isolated_extreme_weeks"),
            F.array(
                F.struct(
                    F.col("lowest_week").alias("week"),
                    F.col("lowest_sales").alias("value"),
                )
            ).alias("isolated_extreme_week_dates"),
        )
    )


def _combine_sales_isolated_extremes(
    high_isolated_df: DataFrame,
    low_isolated_df: DataFrame,
) -> DataFrame:
    """Merge high-side and low-side isolated extremes into one row per sales series."""
    return (
        high_isolated_df
        .unionByName(low_isolated_df)
        .groupBy(*SALES_SERIES_GROUP_COLS)
        .agg(
            F.sum("isolated_extreme_weeks").alias("isolated_extreme_weeks"),
            F.flatten(F.collect_list("isolated_extreme_week_dates")).alias("isolated_extreme_week_dates"),
        )
    )


def _build_sales_distribution_details(
    median_sales_df: DataFrame,
    median_outliers_df: DataFrame,
    isolated_extremes_df: DataFrame,
) -> DataFrame:
    """Join all outlier signals together and build the human-readable warning message."""
    return (
        median_sales_df
        .join(median_outliers_df, on=SALES_SERIES_GROUP_COLS + ["median_sales"], how="left")
        .join(isolated_extremes_df, on=SALES_SERIES_GROUP_COLS, how="left")
        .fillna({"median_outlier_weeks": 0, "isolated_extreme_weeks": 0})
        .filter(
            (F.col("median_outlier_weeks") > F.lit(0))
            | (F.col("isolated_extreme_weeks") > F.lit(0))
        )
        .withColumn("severity", F.lit("MEDIUM"))
        .withColumn(
            "message",
            F.concat_ws(
                ": ",
                F.format_string(
                    "%s/%s cluster %s TOTAL_SALES distribution warning",
                    F.col("unique_brand_name"),
                    F.col("super_category_name"),
                    F.col("cluster_num"),
                ),
                F.concat_ws(
                    "; ",
                    F.when(
                        F.col("median_outlier_weeks") > F.lit(0),
                        F.format_string(
                            "%d week(s) outside the 3x median band (median=%.2f)",
                            F.col("median_outlier_weeks"),
                            F.col("median_sales"),
                        ),
                    ),
                    F.when(
                        F.col("isolated_extreme_weeks") > F.lit(0),
                        F.format_string(
                            "%d isolated extreme week(s) compared with all other weeks",
                            F.col("isolated_extreme_weeks"),
                        ),
                    ),
                ),
            ),
        )
        .select(*ValidationMetrics.SALES_OUTLIER_SCHEMA.fieldNames())
    )


def _format_sales_distribution_outlier_warnings(
    distribution_details_df: DataFrame,
    config: BaselineModellingOutputConfig,
) -> DataFrame:
    """Convert detailed outlier results into the shared warning-event schema."""
    return (
        distribution_details_df
        .select(
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "severity",
            "message",
            F.lit("sales_distribution_outlier_check").alias("check_name"),
            F.to_json(
                F.struct(
                    "metric_name",
                    "median_sales",
                    "median_outlier_weeks",
                    "median_outlier_week_dates",
                    "isolated_extreme_weeks",
                    "isolated_extreme_week_dates",
                    F.array(
                        F.lit(1 / config.sales_outlier_multiplier),
                        F.lit(config.sales_outlier_multiplier),
                    ).alias("threshold_range"),
                )
            ).alias("metadata"),
        )
    )


def check_sales_distribution_outliers(
    sales_baseline_df: DataFrame,
    config: Optional[BaselineModellingOutputConfig] = None,
) -> DataFrame:
    """
    Check 4: warn on weeks that are unusually large or unusually small for the sales series.

    Two rules are evaluated on the sales dataset:
      1. Median-band rule: flag weeks above `3 * median_sales` or below `median_sales / 3`.
      2. Isolated-extreme rule: flag the single highest or lowest week when it is at least 3x away
         from the next closest week in that direction.

    Args:
        sales_baseline_df: Sales baseline rows for the period being validated.
        config: Optional validation config. When omitted, the default
            `BaselineModellingOutputConfig` is used.

    Returns:
        DataFrame of formatted warning rows ready to be unioned into the shared validation-metrics
        output.
    """
    if config is None:
        config = BaselineModellingOutputConfig()

    median_sales_df = _calculate_sales_medians(sales_baseline_df)

    # Compare each week with the typical level of its own series.
    median_outliers_df = _find_sales_median_band_outliers(
        sales_baseline_df,
        median_sales_df,
        config,
    )

    ranked_sales_df = _rank_sales_for_distribution_checks(sales_baseline_df)

    # Check whether the single highest or lowest week is unusually far from the next closest week.
    high_isolated_df = _find_high_sales_isolated_extremes(ranked_sales_df, config)
    low_isolated_df = _find_low_sales_isolated_extremes(ranked_sales_df, config)
    isolated_extremes_df = _combine_sales_isolated_extremes(high_isolated_df, low_isolated_df)

    distribution_details_df = _build_sales_distribution_details(
        median_sales_df,
        median_outliers_df,
        isolated_extremes_df,
    )
    return _format_sales_distribution_outlier_warnings(distribution_details_df, config)


def _check_sales_near_zero_in_period(
    sales_baseline_df: DataFrame,
    periods_df: DataFrame,
    config: Optional[BaselineModellingOutputConfig] = None,
    severity: str = "HIGH",
) -> DataFrame:
    """
    Check a supplied campaign period for weeks whose sales are at or near zero.

    This helper is shared by the During and Post checks. A DataFrame of
    sales rows and a second DataFrame that defines one validation window per brand/category.

    Only sales weeks that fall inside each supplied period are considered, and any weeks whose
    absolute sales value is less than or equal to the configured near-zero threshold are grouped
    into a warning row.

    Args:
        sales_baseline_df: Sales baseline rows for the period being validated.
        periods_df: Period definitions keyed by brand/category with `period_start_dt`,
            `period_end_dt`, and `period_type` columns.
        config: Optional validation config. When omitted, the default
            `BaselineModellingOutputConfig` is used.
        severity: Severity label to apply to any warnings returned by the helper.

    Returns:
        DataFrame matching `ValidationMetrics.SALES_PERIOD_CHECK_SCHEMA` with one warning row per
        affected sales series and period.
    """
    if config is None:
        config = BaselineModellingOutputConfig()

    # Keep only the weekly sales rows that fall inside the caller-supplied validation window.
    period_sales_df = (
        sales_baseline_df.alias("sales")
        .join(periods_df.alias("periods"), on=["unique_brand_name", "super_category_name"], how="inner")
        .filter(
            (F.col("sales.week_start_dt") >= F.col("periods.period_start_dt"))
            & (F.col("sales.week_start_dt") <= F.col("periods.period_end_dt"))
        )
        .select(
            F.col("sales.unique_brand_name").alias("unique_brand_name"),
            F.col("sales.super_category_name").alias("super_category_name"),
            F.col("sales.cluster_num").alias("cluster_num"),
            F.col("sales.marketing_type_name").alias("marketing_type_name"),
            F.col("sales.marketing_channel_name").alias("marketing_channel_name"),
            F.col("sales.metric_name").alias("metric_name"),
            F.col("sales.week_start_dt").alias("week_start_dt"),
            F.col("sales.metric_value").alias("metric_value"),
            F.col("periods.period_type").alias("period_type"),
            F.col("periods.period_start_dt").cast("string").alias("period_start_dt"),
            F.col("periods.period_end_dt").cast("string").alias("period_end_dt"),
        )
    )

    # Aggregate the exact near-zero week(s) so downstream warnings can log precise dates/values.
    return (
        period_sales_df
        .filter(F.abs(F.col("metric_value")) <= F.lit(config.sales_near_zero_threshold))
        .groupBy(
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "metric_name",
            "period_type",
            "period_start_dt",
            "period_end_dt",
        )
        .agg(
            F.count("week_start_dt").alias("near_zero_weeks"),
            F.sort_array(
                F.collect_list(
                    F.struct(
                        F.col("week_start_dt").cast("string").alias("week"),
                        F.col("metric_value").alias("value"),
                    )
                )
            ).alias("near_zero_week_dates"),
        )
        .withColumn("severity", F.lit(severity))
        .withColumn(
            "message",
            F.format_string(
                "%s/%s cluster %s has %d near-zero TOTAL_SALES week(s) in the %s period",
                F.col("unique_brand_name"),
                F.col("super_category_name"),
                F.col("cluster_num"),
                F.col("near_zero_weeks"),
                F.col("period_type"),
            ),
        )
        .select(*ValidationMetrics.SALES_PERIOD_CHECK_SCHEMA.fieldNames())
    )


def check_during_run_near_zero_sales(
    sales_baseline_df: DataFrame,
    campaign_selection_df: DataFrame,
    config: Optional[BaselineModellingOutputConfig] = None,
) -> DataFrame:
    """
    Check 5: warn on near-zero sales during the campaign window for During runs.

    The input sales dataset is expected to be the already de-duplicated sales-only baseline data
    for the recent modelling window. The campaign window is defined from
    `min_campaign_start_dt` to `max_campaign_end_dt` for each brand/category.

    Args:
        sales_baseline_df: Sales baseline rows for the period being validated.
        campaign_selection_df: Campaign timing rows used to resolve the during-campaign window.
        config: Optional validation config. When omitted, the default
            `BaselineModellingOutputConfig` is used.

    Returns:
        DataFrame matching `ValidationMetrics.SALES_PERIOD_CHECK_SCHEMA` with high-severity
        warnings for affected sales series.
    """

    if config is None:
        config = BaselineModellingOutputConfig()

    campaign_periods_df = resolve_sales_campaign_periods(campaign_selection_df)

    campaign_periods_df = (
        campaign_periods_df
        .select(
            "unique_brand_name",
            "super_category_name",
            F.col("min_campaign_start_dt").alias("period_start_dt"),
            F.col("max_campaign_end_dt").alias("period_end_dt"),
            F.lit("during_campaign").alias("period_type"),
        )
    )

    during_period_warnings_df = _check_sales_near_zero_in_period(sales_baseline_df, campaign_periods_df, config=config, severity="HIGH")

    final_during_warnings_df = (
        during_period_warnings_df
        .select(
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "severity",
            "message",
            F.lit("during_period_near_zero_check").alias("check_name"),
            F.to_json(
                F.struct(
                    "metric_name",
                    "period_type",
                    "period_start_dt",
                    "period_end_dt",
                    "near_zero_weeks",
                    "near_zero_week_dates",
                    F.array(F.lit(0.0), F.lit(config.sales_near_zero_threshold)).alias("threshold_range"),
                )
            ).alias("metadata"),
        )
    )
    return final_during_warnings_df


def check_post_run_near_zero_sales(
    sales_baseline_df: DataFrame,
    campaign_selection_df: DataFrame,
    config: Optional[BaselineModellingOutputConfig] = None,
) -> DataFrame:
    """
    Check 6: warn on near-zero sales across the combined During + Post window for Post runs.

    The input sales dataset is expected to be the already de-duplicated sales-only baseline data
    for the recent modelling window. The combined period starts at `min_campaign_start_dt` from
    campaign selection and ends at `max_post_campaign_dt` when that column is available or
    `max_campaign_end_dt` otherwise.

    Args:
        sales_baseline_df: Sales baseline rows for the period being validated.
        campaign_selection_df: Campaign timing rows used to resolve the combined during/post
            validation window.
        config: Optional validation config. When omitted, the default
            `BaselineModellingOutputConfig` is used.

    Returns:
        DataFrame matching `ValidationMetrics.SALES_PERIOD_CHECK_SCHEMA` with high-severity
        warnings for affected sales series.
    """

    if config is None:
        config = BaselineModellingOutputConfig()

    campaign_periods_df = resolve_sales_campaign_periods(campaign_selection_df)
    post_periods_df = (
        campaign_periods_df
        .select(
            "unique_brand_name",
            "super_category_name",
            F.col("min_campaign_start_dt").alias("period_start_dt"),
            F.coalesce(F.col("max_post_campaign_dt"), F.col("max_campaign_end_dt")).alias("period_end_dt"),
            F.lit("during_and_post_campaign").alias("period_type"),
        )
    )

    post_period_warnings_df = _check_sales_near_zero_in_period(sales_baseline_df, post_periods_df, config=config, severity="HIGH")

    final_post_warnings_df = (
        post_period_warnings_df
        .select(
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "severity",
            "message",
            F.lit("post_period_near_zero_check").alias("check_name"),
            F.to_json(
                F.struct(
                    "metric_name",
                    "period_type",
                    "period_start_dt",
                    "period_end_dt",
                    "near_zero_weeks",
                    "near_zero_week_dates",
                    F.array(F.lit(0.0), F.lit(config.sales_near_zero_threshold)).alias("threshold_range"),
                )
            ).alias("metadata"),
        )
    )
    return final_post_warnings_df


def run_all_sales_checks(
    campaign_selection_df: DataFrame,
    baseline_modelling_dataset_df: DataFrame,
    campaign_duration: Optional[str],
    config: BaselineModellingOutputConfig,
) -> DataFrame:
    """
    Run all sales validation checks and return a unified warnings DataFrame.

    Each check result is normalised to a common schema before combining:
      - unique_brand_name, super_category_name, cluster_num, marketing_type_name, marketing_channel_name
      - severity, message, check_name, metadata (JSON string of check-specific fields)

    Checks:
      1. total_sales_per_brand            - total sales is < 52 weeks (validation check, within the pipeline, so it is not present here)
      2. sales_zero_streak_check          — zero-sales periods in the last 104 weeks must stay < 4 weeks
      3. near_zero_sales_check            — any recent week with sales very close to 10.0 (config.sales_near_zero_threshold)
      4. sales_distribution_outlier_check — weeks outside the 3x median band or isolated 3x extremes
      5. during_period_near_zero_check    — During-run campaign weeks with near-zero sales
      6. post_period_near_zero_check      — Post-run during+post weeks with near-zero sales

    The baseline modelling dataset is assumed to have been de-duplicated upstream already.
    """
    sales_baseline_df = filter_sales_baseline_dataset(baseline_modelling_dataset_df)
    # This is not strictly needed but allows us to control the modelling period we want to look at
    recent_sales_df = select_recent_sales_window(sales_baseline_df, config=config)

    # Check 2: sales_zero_streak_check — zero-sales periods in the last 104 weeks must stay < 4 weeks
    zero_streak_warnings_df = check_sales_zero_streaks(recent_sales_df, config=config)

    # Check 3: near_zero_sales_check — any recent week with sales very close to 10.0
    near_zero_warnings_df = check_sales_near_zero_weeks(recent_sales_df, config=config)

    # Check 4: sales_distribution_outlier_check — weeks outside the 3x median band or isolated 3x extremes
    outlier_warnings_df = check_sales_distribution_outliers(recent_sales_df, config=config)

    all_warnings = (
        zero_streak_warnings_df
        .unionByName(near_zero_warnings_df)
        .unionByName(outlier_warnings_df)
    )

    normalized_campaign_duration = _normalise_duration_label(campaign_duration)

    if normalized_campaign_duration == _normalise_duration_label(CampaignDurations.CAMPAIGN_DURATION_DURING):

        # Check 5: during_period_near_zero_check — During-run campaign weeks with near-zero sales
        during_period_warnings_df = check_during_run_near_zero_sales(
            recent_sales_df,
            campaign_selection_df,
            config=config,
        )
        all_warnings = all_warnings.unionByName(during_period_warnings_df)

    elif normalized_campaign_duration == _normalise_duration_label(CampaignDurations.CAMPAIGN_DURATION_POST):
        # Check 6: post_period_near_zero_check — Post-run during+post weeks with near-zero sales
        post_period_warnings_df = check_post_run_near_zero_sales(
            recent_sales_df,
            campaign_selection_df,
            config=config,
        )

        all_warnings = all_warnings.unionByName(post_period_warnings_df)

    return all_warnings


def publish_sales_validation_metrics(
    metrics_topic_arn: str,
    correlation_id: str,
    campaign_selection_df: DataFrame,
    baseline_modelling_dataset_df: DataFrame,
    campaign_duration: Optional[str] = None,
) -> None:
    """
    Run all sales validation checks and publish any warnings to SNS.

    Args:
        metrics_topic_arn: ARN of the SNS topic to publish metrics events to.
        correlation_id: Correlation ID for the current pipeline run.
        campaign_selection_df: DataFrame with campaign selections and marketing types.
        baseline_modelling_dataset_df: DataFrame with weekly baseline metrics.
        campaign_duration: Current run duration label (for example During or Post).
    """

    config = BaselineModellingOutputConfig()

    logger = get_stdout_logger()
    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

    all_warnings = run_all_sales_checks(
        campaign_selection_df=campaign_selection_df,
        baseline_modelling_dataset_df=baseline_modelling_dataset_df,
        campaign_duration=campaign_duration,
        config=config,
    ).collect()

    logger.info(f"Found {len(all_warnings)} total sales validation warning(s).", log_type="sales_validation")

    _db_schema = BaselineValidationMetricsSchema()

    logger.info(
        f"Publishing to table: {_db_schema.schema}.{_db_schema.table_name} (write_operation={_db_schema.write_operation})",
        log_type="sales_validation",
    )

    detailed_week_fields = [
        "zero_sales_week_dates",
        "near_zero_week_dates",
        "median_outlier_week_dates",
        "isolated_extreme_week_dates",
    ]

    for row in all_warnings:
        metadata = json.loads(row["metadata"])
        metadata["correlation_id"] = correlation_id
        metadata["channel_name"] = row["marketing_channel_name"]
        metadata["cluster_num"] = row["cluster_num"]

        # Extract specific metadata for each check to log in a structured way, while keeping cleaning up the metadata JSON for the event payload.
        for detailed_week_field in detailed_week_fields:
            detailed_weeks = metadata.get(detailed_week_field)
            if detailed_weeks is not None:
                logger.info(
                    f"Sales validation detail: check={row['check_name']} cluster={row['cluster_num']} "
                    f"metric={metadata.get('metric_name', 'unknown')} {detailed_week_field}={detailed_weeks}",
                    log_type="sales_validation",
                )
                metadata.pop(detailed_week_field, None)

        # metric_key distinguishes the check variant (metric_name or period_type).
        # unique_name keeps the UPSERT key (name + correlation_id) distinct per brand/category/cluster
        # so multiple warnings from the same run do not overwrite one another.
        metric_key = metadata.get("period_type") or metadata.get("metric_name", "TOTAL_SALES")
        unique_name = (
            f"{row['check_name']}|{row['unique_brand_name']}|{row['super_category_name']}|"
            f"{row['cluster_num']}|{metric_key}"
        )

        event = BaselineValidationMetrics(
            correlation_id=correlation_id,
            name=unique_name,
            type=metric_key,
            severity=row["severity"],
            comment=row["message"],
            value=_resolve_validation_metric_value(row["check_name"], metadata),
            metadata=json.dumps(metadata),
            channel_name=row["marketing_channel_name"],
        )
        try:
            publisher.publish_event(
                message_subject="Baseline Validation Metrics Event",
                event=event,
            )
            logger.info(f"Published warning: {row['message']}", log_type="sales_validation")
        except Exception as e:
            logger.error(
                f"Failed to publish warning for {row['unique_brand_name']}/{row['cluster_num']}: {e}"
            )
