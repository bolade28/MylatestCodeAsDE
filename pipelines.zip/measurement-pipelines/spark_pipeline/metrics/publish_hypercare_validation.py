from typing import List, Optional

from pyspark.sql import SparkSession

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import ValidationStatus
from spark_pipeline.metrics.qa_validation_metrics.hypercare_validation_metrics.hypercare_validation_metrics import (
    resolve_booking_subchannels,
    run_hypercare_validation_checks,
)
from spark_pipeline.utils.mta_events import QAChecksMetric
from spark_pipeline.utils.publish_metrics import MetricsPublisher
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.utils.stdout_logger import get_stdout_logger


def publish_hypercare_validation(
    spark: SparkSession,
    measurement_campaign_reporting_path: str,
    reach_engagement_path: str,
    campaign_period: str,
    booking_id: str,
    correlation_id: str,
    metrics_topic_arn: str,
    slack_topic_arn: str,
    output_path: str,
    campaign_booking_media_channel_path: Optional[str] = None,
    measurement_marketing_channel_hierarchy_path: Optional[str] = None,
) -> None:
    """
    Run hypercare checks, persist and publish QA rows, then notify Slack.

    Booking IDs are inspected as a set so filtering would hide duplicates.
    """
    if campaign_booking_media_channel_path is not None and measurement_marketing_channel_hierarchy_path is None:
        raise ValueError("The marketing hierarchy path is required to resolve booking subchannels for check 20.")
    logger = get_stdout_logger()
    logger.info(
        f"Reading measurement campaign reporting from: {measurement_campaign_reporting_path}",
        log_type="hypercare_validation",
    )
    reporting_columns = [
        "booking_id", "correlation_id", "journey_type", "campaign_duration",
        "channel_name", "attributed_recalibrated_sales_amt", "conversions_recalibrated",
        "conversion_rate", "marketing_type", "incremental_sales_amt_exposed", "iroas_exposed",
    ]
    if campaign_booking_media_channel_path is not None:
        reporting_columns.extend([
            "campaign_id", "subchannel_name", "media_spend_amt", "roas_exposed",
            "recalibration_factor", "attributed_sales_amt",
        ])
    measurement_campaign_reporting_df = (
        spark.read.parquet(measurement_campaign_reporting_path).select(*reporting_columns)
    )
    reach_engagement_df = None
    campaign_booking_media_channel_df = None
    if campaign_booking_media_channel_path is not None:
        reach_engagement_df = (
            spark.read.parquet(reach_engagement_path)
            .select("booking_id", "campaign_id", "subchannel_name")
        )
        booking_media_df = (
            spark.read.parquet(campaign_booking_media_channel_path)
            .select("booking_id", "campaign_id", "marketing_hierarchy_cd")
        )
        hierarchy_df = (
            spark.read.parquet(measurement_marketing_channel_hierarchy_path)
            .select("marketing_hierarchy_cd", "marketing_subchannel")
        )
        campaign_booking_media_channel_df = resolve_booking_subchannels(
            booking_media_df, hierarchy_df,
        )

    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)
    validation_results = run_hypercare_validation_checks(
        measurement_campaign_reporting_df,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        reach_engagement_df=reach_engagement_df,
        campaign_booking_media_channel_df=campaign_booking_media_channel_df,
    )
    status_counts = {status.value: 0 for status in ValidationStatus}
    try:
        validation_results.write.mode("overwrite").parquet(output_path)
        rows = validation_results.collect()
        for row in rows:
            event = QAChecksMetric(
                correlation_id=str(row["correlation_id"]),
                type=str(row["type"]),
                name=str(row["name"]),
                expected_value=str(row["expected_value"]),
                outcome=str(row["outcome"]),
                details=str(row["details"]),
                additional_metadata=str(row["additional_metadata"]),
                load_timestamp=str(row["load_timestamp"]),
            )
            publisher.publish_event(
                message_subject="Hypercare Validation Metric Event",
                event=event,
            )
            status_counts[row["outcome"]] += 1

    finally:
        validation_results.unpersist()

    logger.info(
        f"Published hypercare validation checks for correlation_id={correlation_id}",
        log_type="hypercare_validation",
    )
    checks_run = sum(status_counts.values())
    status_summary = ", ".join(
        f"{status.value}: {status_counts[status.value]}"
        for status in ValidationStatus
    )
    SlackMessenger(
        topic_arn=slack_topic_arn,
        correlation_id=correlation_id,
    ).send_message(
        event_type="Hypercare Validation Metrics Status",
        text=(
            f"Hypercare validation published for campaign_period={campaign_period}: "
            f"{checks_run} checks run ({status_summary})."
        ),
        data={
            "status": "Hypercare validation metrics published successfully",
            "campaign_period": campaign_period,
            "checks_run": checks_run,
            "status_counts": status_counts,
        },
    )


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Publish hypercare validation metrics.")
    parser.add_argument(
        "--measurement-campaign-reporting-path",
        type=str,
        required=True,
        help="S3 path for the measurement campaign reporting output.",
    )
    parser.add_argument(
        "--reach-engagement-path",
        type=str,
        required=True,
        help="S3 path for the reach engagement reporting output.",
    )
    parser.add_argument(
        "--campaign-booking-media-channel-path",
        type=str,
        required=True,
        help="S3 path for the campaign booking media channel source.",
    )
    parser.add_argument(
        "--measurement-marketing-channel-hierarchy-path",
        type=str,
        required=True,
        help="Existing in-scope marketing hierarchy parquet used to resolve booking subchannels.",
    )
    parser.add_argument(
        "--campaign-period",
        type=str,
        required=True,
        choices=("During", "Post"),
        help="Campaign period for the current run.",
    )
    parser.add_argument(
        "--booking-id",
        required=True,
        help="Booking IDs for the campaigns to validate.",
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for the pipeline run.",
    )
    parser.add_argument(
        "--metrics-topic-arn",
        type=str,
        required=True,
        help="ARN of the SNS topic to publish metrics.",
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="ARN of the SNS topic to publish Slack notifications.",
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for the hypercare validation checks output.",
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    publish_hypercare_validation(
        spark=spark,
        measurement_campaign_reporting_path=known_args.measurement_campaign_reporting_path,
        reach_engagement_path=known_args.reach_engagement_path,
        campaign_booking_media_channel_path=known_args.campaign_booking_media_channel_path,
        measurement_marketing_channel_hierarchy_path=known_args.measurement_marketing_channel_hierarchy_path,
        campaign_period=known_args.campaign_period,
        booking_id=known_args.booking_id,
        correlation_id=known_args.correlation_id,
        metrics_topic_arn=known_args.metrics_topic_arn,
        slack_topic_arn=known_args.slack_topic_arn,
        output_path=known_args.output_path,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("PublishHypercareValidation").getOrCreate())
