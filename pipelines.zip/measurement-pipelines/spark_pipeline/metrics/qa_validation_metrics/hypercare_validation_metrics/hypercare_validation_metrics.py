
from functools import reduce
from typing import Optional

from pyspark.sql import Column, DataFrame, functions as F

from spark_pipeline.common.variables import (
    CampaignDurations,
    DV360Config,
    HypercareValidationConfig as Config,
    LowMediaSpendConfig,
    MetaConfig,
    ProductType,
    RecalibrationFactorsConfig,
    ValidationStatus,
    YoutubeConfig,
)
from spark_pipeline.schemas.qa_checks import QAChecks
from spark_pipeline.metrics.utils.shared_helper import (
    ThresholdBounds,
    evaluate_brand_offer_sales,
    evaluate_conversion_rate_thresholds,
    evaluate_expected_value,
    evaluate_incremental_sales,
    evaluate_iroas_thresholds,
    get_threshold_violations,
    summarize_ratio_spread,
    filter_reporting_by_correlation_id,
    filter_reporting_by_campaign_period_and_journey_type,
    format_check_name
)


def format_result(
    stats: DataFrame,
    correlation_id: str,
    campaign_period: str,
    check_name: str,
    expected_value: str,
    outcome: Column,
    metadata: Column,
) -> DataFrame:
    """
    Format one QA row with empty details and diagnostic values in metadata.
    """
    result = stats.select(
        F.lit(correlation_id).alias("correlation_id"),
        F.lit(Config.CHECK_TYPE).alias("type"),
        F.lit(format_check_name(check_name, campaign_period)).alias("name"),
        F.lit(expected_value).alias("expected_value"),
        F.coalesce(outcome, F.lit(ValidationStatus.FAIL.value)).alias("outcome"),
        F.lit("").alias("details"),
        # Metadata holds structured values and the human-readable check comment; details stays empty.
        F.coalesce(F.to_json(metadata), F.lit("{}")).alias("additional_metadata"),
        F.current_timestamp().alias("load_timestamp"),
    )
    return result.select(*[
        F.col(field.name)
        for field in QAChecks.detail_schema.fields
    ])


def check_booking_id(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
) -> DataFrame:
    """
    Validate the number of distinct non-null booking IDs.
    """
    stats = filter_reporting_by_correlation_id(reporting_df, correlation_id).agg(
        F.countDistinct("booking_id").alias("distinct_count"),
        F.sort_array(F.collect_set(F.col("booking_id").cast("string"))).alias("distinct_booking_ids"),
        F.count(F.when(F.col("booking_id").isNull(), 1)).alias("null_count"),
    )
    has_no_booking_ids = F.col("distinct_count") == 0
    has_one_booking_id = F.col("distinct_count") == 1
    outcome = (
        F.when(has_no_booking_ids, ValidationStatus.FAIL.value)
        .when(has_one_booking_id, ValidationStatus.PASS.value)
        .otherwise(ValidationStatus.WARNING.value)
    )
    return format_result(
        stats=stats,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        check_name=Config.BOOKING_ID_CHECK,
        expected_value="1",
        outcome=outcome,
        metadata=F.struct(
            "distinct_count", "distinct_booking_ids", "null_count",
            F.when(has_no_booking_ids, F.lit("No booking ID found in output."))
            .otherwise(F.concat(
                F.lit("Distinct booking IDs: "), F.concat_ws(" | ", "distinct_booking_ids"),
            )).alias("comment"),
        ),
    )


def check_correlation_id(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
) -> DataFrame:
    """
    Require exactly one correlation ID matching the expected run.

    Requires correlation_id. Empty input, null IDs, or unexpected IDs fails.
    Do not prefilter the input by the expected ID: that would hide mismatches.
    Returns one QA row with observed IDs and null count in its JSON metadata.
    """
    stats = reporting_df.agg(
        F.countDistinct("correlation_id").alias("distinct_count"),
        F.max("correlation_id").alias("observed_id"),
        F.sort_array(F.collect_set("correlation_id")).alias("correlation_ids"),
        F.count(F.when(F.col("correlation_id").isNull(), 1)).alias("null_count"),
    )
    has_one_correlation_id = F.col("distinct_count") == 1
    matches_expected_id = F.col("observed_id") == correlation_id
    has_no_null_ids = F.col("null_count") == 0
    matches = (
        has_one_correlation_id
        & matches_expected_id
        & has_no_null_ids
    )
    outcome = F.when(matches, ValidationStatus.PASS.value).otherwise(ValidationStatus.FAIL.value)
    metadata = F.struct(
        "distinct_count", "correlation_ids", "null_count",
        F.lit(correlation_id).alias("expected_correlation_id"),
        F.when(matches, F.lit("Correlation ID matches the expected run."))
        .otherwise(F.concat(
            F.lit(f"Expected correlation ID: {correlation_id}; observed IDs: "),
            F.concat_ws(" | ", "correlation_ids"),
        )).alias("comment"),
    )
    return format_result(
        stats=stats,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        check_name=Config.CORRELATION_ID_CHECK,
        expected_value=correlation_id,
        outcome=outcome,
        metadata=metadata,
    )


def check_channel_coverage(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    journey_type: str = ProductType.BRAND.value,
) -> DataFrame:
    """
    Require a channel at the requested journey type and period.
    Checks whether at least one non-null channel_name exists for the requested
    journey type and campaign period

    Requires journey_type, campaign_duration, and channel_name. Returns one
    QA row; empty or null-only channels fails. Sorted channels are metadata.
    """
    stats = filter_reporting_by_campaign_period_and_journey_type(
        reporting_df, campaign_period, journey_type, correlation_id,
    ).agg(
        F.countDistinct("channel_name").alias("channel_count"),
        F.sort_array(F.collect_set("channel_name")).alias("channels"),
    )
    has_channels = F.col("channel_count") > 0
    outcome = F.when(has_channels, ValidationStatus.PASS.value).otherwise(ValidationStatus.FAIL.value)
    metadata = F.struct(
        "channel_count",
        "channels",
        F.lit(campaign_period).alias("campaign_period"),
        F.when(has_channels, F.concat(
            F.lit("Channels present: "), F.concat_ws(" | ", "channels"),
        ))
        .otherwise(F.lit("No channels found for the requested journey type and period."))
        .alias("comment"),
    )
    return format_result(
        stats=stats,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        check_name=Config.CHANNEL_COVERAGE_CHECK,
        expected_value=">=1",
        outcome=outcome,
        metadata=metadata,
    )


def check_near_zero_sales(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    threshold: float = Config.NEAR_ZERO_SALES_THRESHOLD,
    journey_type: str = ProductType.BRAND.value,
) -> DataFrame:
    """
    Warn on sales below threshold at the requested journey type.

    Requires journey_type, campaign_duration, channel_name, and
    attributed_recalibrated_sales_amt. Equality passes; negative sales warns.
    No non-null sales skips rather than passes. Returns one QA row containing
    affected channel/value pairs, threshold, and missing-value counts.
    """
    sales = F.col("attributed_recalibrated_sales_amt")
    sales_below_threshold = sales < threshold
    stats = filter_reporting_by_campaign_period_and_journey_type(
        reporting_df, campaign_period, journey_type, correlation_id,
    ).agg(
        F.count(sales).alias("value_count"),
        F.count(F.when(sales.isNull(), 1)).alias("null_count"),
        F.count(F.when(sales_below_threshold, 1)).alias("breach_count"),
        F.sort_array(F.collect_list(F.when(sales_below_threshold, F.struct(
            F.col("channel_name").alias("channel"), sales.alias("sales"),
        )))).alias("affected_channels"),
    )
    has_no_sales_values = F.col("value_count") == 0
    has_sales_breaches = F.col("breach_count") > 0
    outcome = (
        F.when(has_no_sales_values, ValidationStatus.SKIPPED.value)
        .when(has_sales_breaches, ValidationStatus.WARNING.value)
        .otherwise(ValidationStatus.PASS.value)
    )
    metadata = F.struct(
        "value_count",
        "null_count",
        "breach_count",
        "affected_channels",
        F.lit(threshold).alias("threshold"),
        F.when(has_no_sales_values, F.lit("no_usable_sales")).alias("reason"),
        F.when(has_no_sales_values, F.lit("No non-null sales available for the requested journey type and period."))
        .when(has_sales_breaches, F.concat(
            F.col("breach_count").cast("string"), F.lit(f" sales rows below {threshold}."),
        ))
        .otherwise(F.lit("No near-zero attributed sales detected.")).alias("comment"),
    )
    return format_result(
        stats=stats,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        check_name=Config.NEAR_ZERO_SALES_CHECK,
        expected_value=f">={threshold}",
        outcome=outcome,
        metadata=metadata,
    )


def check_channel_dominance(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    threshold: float = Config.CHANNEL_DOMINANCE_THRESHOLD,
    journey_type: str = ProductType.BRAND.value,
) -> DataFrame:
    """
    Warn when a channel exceeds the sales-share threshold at the requested journey type.

    Requires journey_type, campaign_duration, channel_name, and
    attributed_recalibrated_sales_amt. Sum sales by channel for the requested journey type in
    the exact period. Single-channel campaigns pass; equality passes. Empty,
    null-only, negative channel totals, or nonpositive total sales skips, since
    shares are not interpretable. Tied leaders sort by channel name. Returns
    one QA row with channel totals, leading share, and threshold as metadata.
    """
    channels = filter_reporting_by_campaign_period_and_journey_type(
        reporting_df, campaign_period, journey_type, correlation_id,
    ).groupBy("channel_name").agg(
        F.sum("attributed_recalibrated_sales_amt").alias("channel_sales"),
    )
    stats = channels.agg(
        F.count("channel_name").alias("channel_count"),
        F.count(F.when(F.col("channel_name").isNull(), 1)).alias("null_channel_count"),
        F.count(F.when(F.col("channel_sales").isNull(), 1)).alias("null_sales_count"),
        F.count(F.when(F.col("channel_sales") < 0, 1)).alias("negative_channel_count"),
        F.sum("channel_sales").alias("total_sales"),
        F.sort_array(F.collect_list(F.struct(
            (-F.col("channel_sales")).alias("sort_sales"),
            F.col("channel_name").alias("channel"), F.col("channel_sales").alias("sales"),
        ))).alias("channel_totals"),
    ).withColumn("leading_channel", F.element_at("channel_totals", 1))
    stats = stats.withColumn(
        "leading_share",
        F.when(F.col("total_sales") > 0, F.col("leading_channel.sales") / F.col("total_sales")),
    )
    unusable = (
        (F.col("channel_count") == 0) | (F.col("null_channel_count") > 0)
        | (F.col("null_sales_count") > 0) | (F.col("negative_channel_count") > 0)
        | F.col("total_sales").isNull() | (F.col("total_sales") <= 0)
    )
    has_single_channel = F.col("channel_count") == 1
    exceeds_dominance_threshold = F.col("leading_share") > threshold
    outcome = (
        F.when(unusable, ValidationStatus.SKIPPED.value)
        .when(has_single_channel, ValidationStatus.PASS.value)
        .when(exceeds_dominance_threshold, ValidationStatus.WARNING.value)
        .otherwise(ValidationStatus.PASS.value)
    )
    metadata = F.struct(
        "channel_count",
        "null_channel_count",
        "null_sales_count",
        "negative_channel_count",
        "total_sales",
        "leading_share",
        F.col("leading_channel.channel").alias("leading_channel"),
        F.transform("channel_totals", lambda channel_total: F.struct(
            channel_total["channel"].alias("channel"), channel_total["sales"].alias("sales"),
        )).alias("channel_totals"),
        F.lit(threshold).alias("threshold"),
        F.when(unusable, F.lit("unusable_channel_sales"))
        .when(has_single_channel, F.lit("single_channel")).alias("reason"),
        F.when(unusable, F.lit("Channel sales totals are missing or unsuitable for a share calculation."))
        .when(has_single_channel, F.lit("Single-channel campaign; dominance warning does not apply."))
        .otherwise(F.concat(
            F.lit("Highest channel share: "),
            F.round(F.col("leading_share") * 100, 2).cast("string"),
            F.lit("% ("), F.col("leading_channel.channel"), F.lit(")."),
        )).alias("comment"),
    )
    return format_result(
        stats=stats,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        check_name=Config.CHANNEL_DOMINANCE_CHECK,
        expected_value=f"<={threshold}",
        outcome=outcome,
        metadata=metadata,
    )


def check_units_per_conversion(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    journey_type: str = ProductType.BRAND.value,
    threshold: float = Config.UNITS_PER_CONV_SPREAD_WARNING,
) -> DataFrame:
    """
    Check row-level sales/conversion ratios in the run/journey/period.

    Requires attributed_recalibrated_sales_amt and conversions_recalibrated.
    Negative minimum ratios fail; spread above the configured limit warns.
    Undefined ratios pass. Metadata retains min/max/spread.
    """
    stats = summarize_ratio_spread(
        filter_reporting_by_campaign_period_and_journey_type(
            reporting_df, campaign_period, journey_type, correlation_id,
        ),
        F.col("attributed_recalibrated_sales_amt"), F.col("conversions_recalibrated"),
    )
    negative_ratio = F.col("minimum_ratio") < 0
    excessive_spread = get_threshold_violations(F.col("spread"), ThresholdBounds(maximum=threshold)).isNotNull()
    outcome = (
        F.when(negative_ratio, ValidationStatus.FAIL.value)
        .when(excessive_spread, ValidationStatus.WARNING.value)
        .otherwise(ValidationStatus.PASS.value)
    )
    metadata = F.struct(
        "minimum_ratio",
        "maximum_ratio",
        "spread",
        F.lit(threshold).alias("threshold"),
        F.when(F.col("spread").isNull(), F.lit("undefined_ratio_spread")).alias("reason"),
        F.coalesce(F.concat(
            F.lit("Min: "), F.round(F.col("minimum_ratio"), 3).cast("string"),
            F.lit(" | Max: "), F.round(F.col("maximum_ratio"), 3).cast("string"),
            F.lit(" | Spread (max/min): "), F.round(F.col("spread"), 2).cast("string"), F.lit("x"),
        ), F.lit("No usable values available.")).alias("comment"),
    )
    return format_result(
        stats=stats,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        check_name=Config.UNITS_PER_CONVERSION_CHECK,
        expected_value=f"<={threshold}x",
        outcome=outcome,
        metadata=metadata,
    )


def check_brand_vs_offer_sales(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    group_by_columns: tuple[str, ...] = ("channel_name",),
    decimal_places: int = 2,
) -> DataFrame:
    """
    Check channel sales in the requested run across all periods.

    Requires channel_name, journey_type and attributed_recalibrated_sales_amt.
    Journey matching ignores case but not whitespace. Channel sums are rounded
    to two decimals before comparison. Empty or incomplete pairs pass.

    You can include subchannel_name in group_by_columns for subchannel-level checks
    """
    journey_type = F.upper(F.col("journey_type"))
    sales = F.col("attributed_recalibrated_sales_amt")
    campaign_rows = filter_reporting_by_correlation_id(reporting_df, correlation_id)
    channel_sales = campaign_rows.groupBy(*group_by_columns).agg(
        F.sum(F.when(journey_type == ProductType.BRAND.value.upper(), sales)).alias("brand_sales"),
        F.sum(F.when(journey_type == ProductType.OFFER.value.upper(), sales)).alias("offer_sales"),
    )
    compared_sales = evaluate_brand_offer_sales(channel_sales, decimal_places=decimal_places)
    dimension_names = {"channel_name": "channel", "subchannel_name": "subchannel"}
    dimensions = [dimension_names.get(name, name) for name in group_by_columns]
    affected_sales = F.struct(
        *[F.col(name).alias(label) for name, label in zip(group_by_columns, dimensions)],
        "brand_sales",
        "offer_sales",
    )
    breach = F.col("offer_exceeds_brand")
    channel_level = group_by_columns == ("channel_name",)
    stats = compared_sales.agg(
        F.count(F.lit(1)).alias("channel_count" if channel_level else "group_count"),
        F.count(F.when(breach, 1)).alias("breach_count"),
        F.sort_array(F.collect_list(F.when(breach, affected_sales))).alias("breaches"),
    )
    has_breaches = F.col("breach_count") > 0
    outcome = F.when(has_breaches, ValidationStatus.FAIL.value).otherwise(ValidationStatus.PASS.value)
    breach_messages = F.transform(F.col("breaches"), lambda sales_pair: F.concat(
        F.concat_ws(" | ", *[
            F.coalesce(sales_pair.getField(name).cast("string"), F.lit(f"Unknown {name}"))
            for name in dimensions
        ]),
        F.lit(" [Brand="), sales_pair.getField("brand_sales").cast("string"),
        F.lit(", Offer="), sales_pair.getField("offer_sales").cast("string"), F.lit("]"),
    ))
    metadata = F.struct(
        "channel_count" if channel_level else "group_count", "breach_count", "breaches",
        F.when(has_breaches, F.concat(F.lit("Offer > Brand for: "), F.concat_ws(" | ", breach_messages)))
        .otherwise(F.lit("OK  Brand >= Offer for all channels." if channel_level
                         else "OK  Brand >= Offer for all channel/subchannels.")).alias("comment"),
    )
    return format_result(
        stats=stats,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        check_name=Config.BRAND_VS_OFFER_SALES_CHECK,
        expected_value="Brand >= Offer",
        outcome=outcome,
        metadata=metadata,
    )


def check_conversion_rates(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    journey_type: str = ProductType.BRAND.value,
) -> DataFrame:
    """
    Check marketing-type conversion rates in the run/journey/period.

    Requires conversion_rate, marketing_type and channel_name. Unknown types,
    missing rates and empty input pass; marketing types are not whitespace-trimmed.
    Configured endpoint equality passes. Metadata retains counts, bounds and affected-rate objects.
    """
    rate = F.col("conversion_rate")
    breach = F.col("is_breach")
    rows = evaluate_conversion_rate_thresholds(
        filter_reporting_by_campaign_period_and_journey_type(
            reporting_df, campaign_period, journey_type, correlation_id,
        ),
        thresholds={
            "offsite": ThresholdBounds(maximum=Config.OFFSITE_CONVERSION_RATE_WARNING),
            "onsite": ThresholdBounds(
                minimum=Config.ONSITE_CONVERSION_RATE_MIN, maximum=Config.ONSITE_CONVERSION_RATE_MAX,
            ),
            "instore": ThresholdBounds(minimum=Config.INSTORE_CONVERSION_RATE_MIN),
        },
        trim_marketing_type=False,
    )
    marketing_type = F.col("marketing_type_lower")
    affected_rate = F.struct(
        F.col("channel_name").alias("channel"),
        marketing_type.alias("marketing_type"),
        rate.alias("conversion_rate"),
        F.col("threshold_value").alias("threshold"),
    )
    stats = rows.agg(
        F.count(rate).alias("value_count"),
        F.count(F.when(breach, 1)).alias("breach_count"),
        F.sort_array(F.collect_list(F.when(breach, affected_rate))).alias("affected_rates"),
    )
    has_breaches = F.col("breach_count") > 0
    outcome = F.when(has_breaches, ValidationStatus.WARNING.value).otherwise(ValidationStatus.PASS.value)
    rate_messages = F.transform(F.col("affected_rates"), lambda affected: F.concat(
        F.coalesce(affected.getField("channel"), F.lit("Unknown channel")), F.lit(" ["),
        F.when(affected.getField("marketing_type") == "offsite", F.lit("OFFSITE"))
        .when(
            (affected.getField("marketing_type") == "onsite")
            & (affected.getField("conversion_rate") < Config.ONSITE_CONVERSION_RATE_MIN),
            F.lit("ONSITE LOW"),
        )
        .when(affected.getField("marketing_type") == "onsite", F.lit("ONSITE HIGH"))
        .when(affected.getField("marketing_type") == "instore", F.lit("INSTORE LOW")),
        F.lit("] "), affected.getField("conversion_rate").cast("string"), F.lit("%"),
    ))
    metadata = F.struct(
        "value_count", "breach_count", "affected_rates",
        F.struct(
            F.lit(Config.OFFSITE_CONVERSION_RATE_WARNING).alias("offsite_maximum"),
            F.lit(Config.ONSITE_CONVERSION_RATE_MIN).alias("onsite_minimum"),
            F.lit(Config.ONSITE_CONVERSION_RATE_MAX).alias("onsite_maximum"),
            F.lit(Config.INSTORE_CONVERSION_RATE_MIN).alias("instore_minimum"),
        ).alias("thresholds"),
        F.when(has_breaches, F.concat(
            F.lit("Potentially unusual conversion rates: "), F.concat_ws(" | ", rate_messages),
        ))
        .otherwise(F.lit("OK Conversion rates within expected ranges.")).alias("comment"),
    )
    return format_result(
        stats=stats,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        check_name=Config.CONVERSION_RATE_CHECK,
        expected_value="marketing-type thresholds",
        outcome=outcome,
        metadata=metadata,
    )


def check_incremental_sales(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    journey_type: str = ProductType.BRAND.value,
    warning_threshold: float = Config.INCREMENTAL_PCT_WARNING,
) -> DataFrame:
    """
    Check row-level incremental sales in the requested run/journey/period.

    Requires channel_name, incremental_sales_amt_exposed and attributed_recalibrated_sales_amt.
    Incremental > attributed fails before inclusive percentage warnings are considered.
    Missing pairs pass; zero attributed sales disable only the ratio warning.
    """
    incremental = F.col("incremental_sales_amt_exposed")
    attributed = F.col("attributed_recalibrated_sales_amt")
    rows = evaluate_incremental_sales(
        filter_reporting_by_campaign_period_and_journey_type(
            reporting_df, campaign_period, journey_type, correlation_id,
        ),
        incremental, attributed, warning_threshold=warning_threshold,
    )
    ratio = F.col("incremental_ratio")
    breach = F.col("incremental_breach")
    warning = F.col("incremental_warning")
    has_sales_pair = incremental.isNotNull() & attributed.isNotNull()
    affected_sales = F.struct(
        F.col("channel_name").alias("channel"),
        incremental.alias("incremental_sales"),
        attributed.alias("attributed_sales"),
        ratio.alias("incremental_ratio"),
    )
    stats = rows.agg(
        F.count(F.when(has_sales_pair, 1)).alias("value_count"),
        F.count(F.when(breach, 1)).alias("fail_count"),
        F.count(F.when(warning, 1)).alias("warning_count"),
        F.sort_array(F.collect_list(F.when(
            breach, affected_sales,
        ))).alias("failures"),
        F.sort_array(F.collect_list(F.when(warning, affected_sales))).alias("warnings"),
    )
    has_failures = F.col("fail_count") > 0
    has_warnings = F.col("warning_count") > 0
    outcome = (
        F.when(has_failures, ValidationStatus.FAIL.value)
        .when(has_warnings, ValidationStatus.WARNING.value)
        .otherwise(ValidationStatus.PASS.value)
    )
    failure_channels = F.transform(F.col("failures"), lambda sales_pair: F.coalesce(
        sales_pair.getField("channel"), F.lit("Unknown channel"),
    ))
    warning_messages = F.transform(F.col("warnings"), lambda sales_pair: F.concat(
        F.coalesce(sales_pair.getField("channel"), F.lit("Unknown channel")), F.lit(" ("),
        F.round(sales_pair.getField("incremental_ratio") * 100, 1).cast("string"), F.lit("%)"),
    ))
    metadata = F.struct(
        "value_count",
        "fail_count",
        "warning_count",
        "failures",
        "warnings",
        F.lit(warning_threshold).alias("warning_threshold"),
        F.when(has_failures, F.concat(
            F.lit("FAIL  Incremental exceeds Attributed for: "), F.concat_ws(" | ", failure_channels),
        ))
        .when(has_warnings, F.concat(
            F.lit(f"Incremental >= {warning_threshold:.0%} of Attributed for: "),
            F.concat_ws(" | ", warning_messages),
        ))
        .otherwise(F.lit("OK Incremental sales within expected range for all channels.")).alias("comment"),
    )
    return format_result(
        stats=stats,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        check_name=Config.INCREMENTAL_SALES_CHECK,
        expected_value=f"<=100%; warn >= {warning_threshold:.0%}",
        outcome=outcome,
        metadata=metadata,
    )


def check_iroas(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    journey_type: str = ProductType.BRAND.value,
    threshold: float = Config.IROAS_WARNING_THRESHOLD,
) -> DataFrame:
    """
    Check maximum reported iROAS in the run/journey/period.

    Requires iroas_exposed. Compare its unrounded maximum: > threshold warns,
    <= 0 fails, and missing values pass. Metadata retains the unrounded maximum.
    This check does not recalculate iROAS from spend.
    """
    iroas = F.col("iroas_exposed")
    level_rows = filter_reporting_by_campaign_period_and_journey_type(
        reporting_df, campaign_period, journey_type, correlation_id,
    )
    maximum_stats = level_rows.agg(
        F.count(iroas).alias("value_count"),
        F.max(iroas).alias("maximum_iroas"),
    )
    stats = evaluate_iroas_thresholds(
        maximum_stats, F.col("maximum_iroas"),
        ThresholdBounds(minimum=0.0, maximum=threshold, minimum_inclusive=False),
    )
    above_threshold = F.col("iroas_above_maximum")
    is_nonpositive = F.col("iroas_below_minimum")
    outcome = (
        F.when(above_threshold, ValidationStatus.WARNING.value)
        .when(is_nonpositive, ValidationStatus.FAIL.value)
        .otherwise(ValidationStatus.PASS.value)
    )
    rounded_maximum_iroas = F.round(F.col("maximum_iroas"), 2).cast("string")
    metadata = F.struct(
        "value_count",
        "maximum_iroas",
        F.lit(threshold).alias("threshold"),
        F.when(F.col("value_count") == 0, F.lit("no_usable_iroas")).alias("reason"),
        F.coalesce(
            F.when(above_threshold, F.concat(
                F.lit("iROAS = "), rounded_maximum_iroas,
                F.lit(f" above threshold of {threshold}. Investigate if explainable."),
            ))
            .when(is_nonpositive, F.concat(F.lit("iROAS is zero or negative: "), rounded_maximum_iroas))
            .otherwise(F.concat(F.lit("OK iROAS = "), rounded_maximum_iroas)),
            F.lit("No usable values available."),
        ).alias("comment"),
    )
    return format_result(
        stats=stats,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
        check_name=Config.IROAS_CHECK,
        expected_value=f">0 and <={threshold}",
        outcome=outcome,
        metadata=metadata,
    )


def check_roas(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    journey_type: str = ProductType.BRAND.value,
    threshold: float = Config.ROAS_WARNING_THRESHOLD,
) -> DataFrame:
    """Validate maximum exposed ROAS against the warning threshold and zero."""
    roas = F.col("roas_exposed").cast("double")
    stats = filter_reporting_by_campaign_period_and_journey_type(
        reporting_df, campaign_period, journey_type, correlation_id,
    ).agg(
        F.count(roas).alias("value_count"),
        F.max(roas).alias("maximum_roas"),
    )
    too_high = get_threshold_violations(
        F.col("maximum_roas"), ThresholdBounds(maximum=threshold),
    ).isNotNull()
    nonpositive_maximum = (
        (F.col("value_count") > 0)
        & (F.col("maximum_roas") <= 0)
    )
    outcome = (
        F.when(too_high, ValidationStatus.WARNING.value)
        .when(nonpositive_maximum, ValidationStatus.FAIL.value)
        .otherwise(ValidationStatus.PASS.value)
    )
    metadata = F.struct(
        "value_count", "maximum_roas", F.lit(threshold).alias("threshold"),
        F.when(too_high, F.lit("Maximum ROAS exceeds the warning threshold."))
        .when(
            nonpositive_maximum,
            F.concat(F.lit("ROAS is zero or negative: "), F.round(F.col("maximum_roas"), 2)),
        )
        .otherwise(F.lit("ROAS is within the expected range.")).alias("comment"),
    )
    return format_result(
        stats, correlation_id, campaign_period, Config.ROAS_CHECK,
        f">0 and <={threshold}", outcome, metadata,
    )


def check_media_spend(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    journey_type: str = ProductType.BRAND.value,
    threshold: Optional[float] = None,
) -> DataFrame:
    """Warn for individual campaign-reporting rows below minimum spend."""
    if threshold is None:
        threshold = LowMediaSpendConfig().low_spend_threshold
    scoped_rows = filter_reporting_by_campaign_period_and_journey_type(
        reporting_df, campaign_period, journey_type, correlation_id,
    )
    spend = F.col("media_spend_amt").cast("double")
    below_threshold = get_threshold_violations(
        spend, ThresholdBounds(minimum=threshold),
    ).isNotNull()
    stats = scoped_rows.agg(
        F.count(spend).alias("value_count"),
        F.count(F.when(below_threshold, 1)).alias("breach_count"),
        F.sort_array(F.collect_list(F.when(below_threshold, F.struct(
            F.col("channel_name").alias("channel"), spend.alias("media_spend"),
        )))).alias("affected_rows"),
    )
    has_breaches = F.col("breach_count") > 0
    outcome = F.when(has_breaches, ValidationStatus.WARNING.value).otherwise(ValidationStatus.PASS.value)
    metadata = F.struct(
        "value_count", "breach_count", "affected_rows",
        F.lit(threshold).alias("threshold"),
        F.when(has_breaches, F.lit("Campaign rows have media spend below the minimum."))
        .otherwise(F.lit("All campaign rows meet the minimum media spend.")).alias("comment"),
    )
    return format_result(
        stats, correlation_id, campaign_period, Config.MEDIA_SPEND_CHECK,
        f">={threshold}", outcome, metadata,
    )


def recalibration_expected_value(factors: RecalibrationFactorsConfig) -> str:
    """Describe the expected recalibration factors for subchannels,
    including required Meta bounds, channel exemptions and non-offsite equality."""
    return (
        f"Meta: >{factors.offsite_recalibration_min_threshold:g} "
        f"and <={factors.offsite_recalibration_max_threshold:g}, required; "
        "DV360/YouTube exempt; "
        f"otherwise={factors.non_offsite_recalibration_factor:g}"
    )


def check_recalibration_factor(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    journey_type: str = ProductType.BRAND.value,
) -> DataFrame:
    """Validate recalibration factors by subchannel."""
    scoped_rows = filter_reporting_by_campaign_period_and_journey_type(
        reporting_df, campaign_period, journey_type, correlation_id,
    )
    subchannel = F.upper(F.col("subchannel_name"))
    is_meta = subchannel.contains(MetaConfig.MARKETING_CHANNEL)
    is_exempt = (
        subchannel.contains(DV360Config.MARKETING_CHANNEL)
        | subchannel.contains(YoutubeConfig.MARKETING_CHANNEL)
    )
    eligible = subchannel.isNotNull() & (is_meta | ~is_exempt)
    factors = RecalibrationFactorsConfig()
    factor_rows = (
        scoped_rows
        .withColumn(
            "expected_factor",
            F.when(~is_meta, F.lit(factors.non_offsite_recalibration_factor)),
        )
    )
    factor_rows = evaluate_expected_value(
        factor_rows,
        F.col("recalibration_factor").cast("double"),
        F.col("expected_factor"),
    )
    meta_outside_bounds = get_threshold_violations(
        F.col("recalibration_factor").cast("double"),
        ThresholdBounds(
            minimum=factors.offsite_recalibration_min_threshold,
            maximum=factors.offsite_recalibration_max_threshold,
            minimum_inclusive=False,
            maximum_inclusive=True,
        ),
    ).isNotNull()
    missing_factor = F.col("recalibration_factor").isNull()
    mismatch = eligible & (
        missing_factor
        | (is_meta & meta_outside_bounds)
        | (~is_meta & (F.col("matches_expected_value") == F.lit(False)))
    )
    stats = factor_rows.agg(
        F.count(F.when(eligible, 1)).alias("value_count"),
        F.count(F.when(mismatch, 1)).alias("breach_count"),
        F.sort_array(F.collect_list(F.when(mismatch, F.struct(
            F.col("subchannel_name").alias("subchannel"),
            F.col("recalibration_factor").cast("double").alias("actual_factor"),
            "expected_factor",
            F.when(
                is_meta, F.lit(factors.offsite_recalibration_min_threshold),
            ).alias("minimum_factor"),
            F.when(
                is_meta, F.lit(factors.offsite_recalibration_max_threshold),
            ).alias("maximum_factor"),
        )))).alias("breaches"),
    )
    has_breaches = F.col("breach_count") > 0
    outcome = F.when(has_breaches, ValidationStatus.WARNING.value).otherwise(ValidationStatus.PASS.value)
    metadata = F.struct(
        "value_count", "breach_count", "breaches",
        F.when(has_breaches, F.lit("Recalibration factors are missing or differ from the subchannel rules."))
        .otherwise(F.lit("Recalibration factors match the subchannel rules.")).alias("comment"),
    )
    return format_result(
        stats, correlation_id, campaign_period, Config.RECALIBRATION_FACTOR_CHECK,
        recalibration_expected_value(factors), outcome, metadata,
    )


def check_attributed_vs_recalibrated_sales(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    journey_type: str = ProductType.BRAND.value,
    tolerance: float = Config.RECALIBRATED_SALES_TOLERANCE,
) -> DataFrame:
    """Fail when non-offsite attributed sales differ by more than the tolerance."""
    scoped_rows = filter_reporting_by_campaign_period_and_journey_type(
        reporting_df, campaign_period, journey_type, correlation_id,
    )
    marketing_type = F.upper(F.col("marketing_type"))
    raw_sales = F.col("attributed_sales_amt").cast(Config.DECIMAL_CAST_TYPE)
    recalibrated_sales = F.col("attributed_recalibrated_sales_amt").cast(Config.DECIMAL_CAST_TYPE)
    non_offsite = marketing_type != "OFFSITE"
    difference = F.abs(raw_sales - recalibrated_sales)
    breached = (difference > F.lit(tolerance).cast(Config.DECIMAL_CAST_TYPE)) & non_offsite
    stats = scoped_rows.agg(
        F.count(F.when(non_offsite, 1)).alias("value_count"),
        F.count(F.when(breached, 1)).alias("breach_count"),
        F.sort_array(F.collect_list(F.when(breached, F.struct(
            F.col("channel_name").alias("channel"),
            raw_sales.alias("attributed_sales"),
            recalibrated_sales.alias("recalibrated_sales"),
        )))).alias("breaches"),
    )
    has_breaches = F.col("breach_count") > 0
    outcome = F.when(has_breaches, ValidationStatus.FAIL.value).otherwise(ValidationStatus.PASS.value)
    metadata = F.struct(
        "value_count", "breach_count", "breaches", F.lit(tolerance).alias("tolerance"),
        F.when(has_breaches, F.lit("Non-offsite attributed and recalibrated sales differ."))
        .otherwise(F.lit("Non-offsite attributed sales match recalibrated sales.")).alias("comment"),
    )
    return format_result(
        stats, correlation_id, campaign_period, Config.ATTRIBUTED_SALES_CHECK,
        f"difference <= {tolerance}", outcome, metadata,
    )


def check_post_period_metric(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str,
    check_name: str,
    metric_column: str,
    warning_multiplier: float,
    expected_value: str,
    skip_without_period_rows: bool,
    skip_without_pairs: bool,
) -> DataFrame:
    """Compare POST-only values with DURING+POST totals by channel."""
    campaign_rows = filter_reporting_by_correlation_id(reporting_df, correlation_id)
    period_rows = campaign_rows.filter(
        (F.upper(F.trim(F.col("journey_type"))) == ProductType.BRAND.value.upper())
        & F.upper(F.trim(F.col("campaign_duration"))).isin("POST", "DURING+POST")
    )
    duration = F.upper(F.trim(F.col("campaign_duration")))
    metric = F.col(metric_column).cast("double")
    channel_pairs = period_rows.groupBy(
        F.upper(F.trim(F.col("channel_name"))).alias("channel_name"),
    ).agg(
        F.sum(F.when(duration == "POST", metric)).alias("post_only_value"),
        F.sum(F.when(duration == "DURING+POST", metric)).alias("combined_value"),
    ).filter(
        F.col("post_only_value").isNotNull() & F.col("combined_value").isNotNull()
    )
    lower = F.col("combined_value") < F.col("post_only_value")
    higher = F.col("combined_value") > F.col("post_only_value") * warning_multiplier
    pair_stats = channel_pairs.agg(
        F.count(F.lit(1)).alias("pair_count"),
        F.count(F.when(lower, 1)).alias("fail_count"),
        F.count(F.when(higher, 1)).alias("warning_count"),
        F.sort_array(F.collect_set(F.when(lower, F.col("channel_name")))).alias("failure_channels"),
        F.sort_array(F.collect_set(F.when(higher, F.col("channel_name")))).alias("warning_channels"),
    )
    period_presence = period_rows.agg(F.count(F.lit(1)).alias("period_row_count"))
    stats = pair_stats.crossJoin(period_presence)
    has_failures = F.col("fail_count") > 0
    has_warnings = F.col("warning_count") > 0
    no_pairs = F.col("pair_count") == 0
    outcome = (
        F.when((F.col("period_row_count") == 0) & F.lit(skip_without_period_rows), ValidationStatus.SKIPPED.value)
        .when(no_pairs & F.lit(skip_without_pairs), ValidationStatus.SKIPPED.value)
        .when(no_pairs, ValidationStatus.PASS.value)
        .when(has_failures, ValidationStatus.FAIL.value)
        .when(has_warnings, ValidationStatus.WARNING.value)
        .otherwise(ValidationStatus.PASS.value)
    )
    metadata = F.struct(
        "period_row_count", "pair_count", "fail_count", "warning_count",
        "failure_channels", "warning_channels",
        F.lit(warning_multiplier).alias("warning_multiplier"),
        F.when(F.col("period_row_count") == 0, F.lit("No POST or DURING+POST data found."))
        .when(no_pairs, F.lit("No channel has both POST and DURING+POST values."))
        .when(has_failures, F.concat(F.lit("Combined value is below POST for: "), F.concat_ws(" | ", "failure_channels")))
        .when(has_warnings, F.concat(F.lit("Combined value exceeds the warning multiplier for: "), F.concat_ws(" | ", "warning_channels")))
        .otherwise(F.lit("Combined values are within the expected range.")).alias("comment"),
    )
    return format_result(
        stats, correlation_id, campaign_period, check_name, expected_value, outcome, metadata,
    )


def check_post_period_sales(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
) -> DataFrame:
    return check_post_period_metric(
        reporting_df, correlation_id, campaign_period, Config.POST_SALES_CHECK,
        "attributed_recalibrated_sales_amt", Config.POST_SALES_WARNING_MULTIPLIER,
        Config.POST_SALES_EXPECTED_VALUE,
        skip_without_period_rows=True, skip_without_pairs=False,
    )


def check_post_period_conversions(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
) -> DataFrame:
    return check_post_period_metric(
        reporting_df, correlation_id, campaign_period, Config.POST_CONVERSIONS_CHECK,
        "conversions_recalibrated", Config.POST_CONVERSIONS_WARNING_MULTIPLIER,
        Config.POST_CONVERSIONS_EXPECTED_VALUE,
        skip_without_period_rows=False, skip_without_pairs=True,
    )


def check_post_period_incremental_sales(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
) -> DataFrame:
    return check_post_period_metric(
        reporting_df, correlation_id, campaign_period, Config.POST_INCREMENTAL_SALES_CHECK,
        "incremental_sales_amt_exposed", Config.POST_INCREMENTAL_SALES_WARNING_MULTIPLIER,
        Config.POST_INCREMENTAL_SALES_EXPECTED_VALUE,
        skip_without_period_rows=False, skip_without_pairs=True,
    )


def check_subchannel_consistency(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str,
    reach_engagement_df: Optional[DataFrame] = None,
) -> DataFrame:
    """Compare distinct MCR and reach-engagement subchannels by booking/campaign."""
    if reach_engagement_df is None:
        return format_result(
            reporting_df.sparkSession.range(1), correlation_id, campaign_period,
            Config.SUBCHANNEL_CONSISTENCY_CHECK, Config.SUBCHANNEL_CONSISTENCY_EXPECTED_VALUE,
            F.lit(ValidationStatus.SKIPPED.value),
            F.struct(F.lit("reach_engagement_input_missing").alias("reason"),
                     F.lit("Reach-engagement input was not provided.").alias("comment")),
        )
    mcr_rows = filter_reporting_by_correlation_id(reporting_df, correlation_id).select(
        "campaign_duration",
        F.upper(F.trim(F.col("booking_id"))).alias("booking_id"),
        F.upper(F.trim(F.col("campaign_id"))).alias("campaign_id"),
        F.upper(F.trim(F.col("subchannel_name"))).alias("mcr_subchannel_name"),
    ).distinct().alias("mcr")
    reach_rows = reach_engagement_df.select(
        F.upper(F.trim(F.col("booking_id"))).alias("booking_id"),
        F.upper(F.trim(F.col("campaign_id"))).alias("campaign_id"),
        F.upper(F.trim(F.col("subchannel_name"))).alias("re_subchannel_name"),
    ).distinct().alias("reach")
    joined = mcr_rows.join(
        reach_rows,
        (F.col("mcr.booking_id") == F.col("reach.booking_id"))
        & (F.col("mcr.campaign_id") == F.col("reach.campaign_id"))
        & (F.col("mcr.mcr_subchannel_name") == F.col("reach.re_subchannel_name")),
        how="full_outer",
    ).select(
        F.coalesce(F.col("mcr.booking_id"), F.col("reach.booking_id")).alias("booking_id"),
        F.coalesce(F.col("mcr.campaign_id"), F.col("reach.campaign_id")).alias("campaign_id"),
        F.col("mcr.mcr_subchannel_name"), F.col("mcr.campaign_duration"),
        F.col("reach.re_subchannel_name"),
    )
    reach_count = reach_rows.agg(F.count(F.lit(1)).alias("re_row_count"))
    comparisons = joined.crossJoin(reach_count).withColumn(
        "validation_status",
        F.when(F.col("mcr_subchannel_name").isNull(), F.lit("FAIL: missing in MCR"))
        .when((F.col("re_row_count") == 0) & (F.upper(F.col("campaign_duration")) == "DURING"), F.lit("FAIL: RE is empty for During"))
        .when(F.col("re_row_count") == 0, F.lit("SKIPPED: RE is empty"))
        .when(F.col("re_subchannel_name").isNull(), F.lit("FAIL: missing in RE"))
        .when(F.col("mcr_subchannel_name") == F.col("re_subchannel_name"), F.lit("PASS"))
        .otherwise(F.lit("FAIL: value mismatch")),
    )
    stats = comparisons.agg(
        F.count(F.when(F.col("validation_status").startswith("FAIL"), 1)).alias("failure_count"),
        F.count(F.when(F.col("validation_status").startswith("SKIPPED"), 1)).alias("skipped_count"),
        F.sort_array(F.collect_set(F.when(
            F.col("validation_status").startswith("FAIL"),
            F.concat_ws("/", "booking_id", "campaign_id", "mcr_subchannel_name", "re_subchannel_name"),
        ))).alias("failures"),
    )
    has_failures = F.col("failure_count") > 0
    has_skips = F.col("skipped_count") > 0
    outcome = (
        F.when(has_failures, ValidationStatus.FAIL.value)
        .when(has_skips, ValidationStatus.SKIPPED.value)
        .otherwise(ValidationStatus.PASS.value)
    )
    metadata = F.struct(
        "failure_count", "skipped_count", "failures",
        F.when(has_failures, F.lit("Reach-engagement and MCR subchannels differ."))
        .when(has_skips, F.lit("Reach-engagement comparison is not applicable for this period."))
        .otherwise(F.lit("MCR and reach-engagement subchannels match.")).alias("comment"),
    )
    return format_result(
        stats, correlation_id, campaign_period, Config.SUBCHANNEL_CONSISTENCY_CHECK,
        Config.SUBCHANNEL_CONSISTENCY_EXPECTED_VALUE, outcome, metadata,
    )


def check_rounded_media_spend(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
) -> DataFrame:
    """Warn when campaign-wide media spend is a multiple of ten."""
    spend = F.col("media_spend_amt").cast("double")
    integer_spend = spend == F.floor(spend)
    trailing_zero_count = (
        F.when(~integer_spend, F.lit(-1))
        .when(F.pmod(F.abs(spend), F.lit(1_000_000)) == 0, F.lit(6))
        .when(F.pmod(F.abs(spend), F.lit(100_000)) == 0, F.lit(5))
        .when(F.pmod(F.abs(spend), F.lit(10_000)) == 0, F.lit(4))
        .when(F.pmod(F.abs(spend), F.lit(1_000)) == 0, F.lit(3))
        .when(F.pmod(F.abs(spend), F.lit(100)) == 0, F.lit(2))
        .when(F.pmod(F.abs(spend), F.lit(10)) == 0, F.lit(1))
        .otherwise(F.lit(0))
    )
    scoped_rows = filter_reporting_by_correlation_id(reporting_df, correlation_id)
    classified = scoped_rows.withColumn("trailing_zero_count", trailing_zero_count)
    rounded = F.col("trailing_zero_count") >= 1
    details = F.when(
        F.col("trailing_zero_count") >= 2,
        F.concat_ws(" ", "subchannel_name", spend.cast("string"),
                    F.concat(F.lit("[WARNING - multiple of "),
                             F.pow(F.lit(10), F.col("trailing_zero_count")).cast("long"), F.lit(")]"))),
    ).when(
        F.col("trailing_zero_count") == 1,
        F.concat(spend.cast("string"), F.lit(" [WARNING - multiple of 10]")),
    )
    stats = classified.agg(
        F.count(spend).alias("value_count"),
        F.count(F.when(rounded, 1)).alias("breach_count"),
        F.sort_array(F.collect_list(F.when(rounded, details))).alias("rounded_values"),
    )
    has_breaches = F.col("breach_count") > 0
    outcome = F.when(has_breaches, ValidationStatus.WARNING.value).otherwise(ValidationStatus.PASS.value)
    metadata = F.struct(
        "value_count", "breach_count", "rounded_values",
        F.when(has_breaches, F.lit("Suspiciously rounded media spend values found."))
        .otherwise(F.lit("No suspiciously rounded media spend values found.")).alias("comment"),
    )
    return format_result(
        stats, correlation_id, "campaign_wide", Config.ROUNDED_MEDIA_SPEND_CHECK,
        "media spend is not a multiple of 10", outcome, metadata,
    )


def resolve_booking_subchannels(
    booking_media_df: DataFrame,
    hierarchy_df: DataFrame,
) -> DataFrame:
    """Resolve booking subchannels using the in-scope, measurement-ready hierarchy."""
    bookings = booking_media_df.select(
        "booking_id", "campaign_id", "marketing_hierarchy_cd",
    ).alias("bookings")
    hierarchy = hierarchy_df.select(
        "marketing_hierarchy_cd", "marketing_subchannel",
    ).alias("hierarchy")
    return bookings.join(
        hierarchy,
        on="marketing_hierarchy_cd",
        how="inner",
    ).select(
        F.col("bookings.booking_id").alias("booking_id"),
        F.col("bookings.campaign_id").alias("campaign_id"),
        F.col("hierarchy.marketing_subchannel").alias("marketing_subchannel"),
    )


def check_missing_inscope_subchannel(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str,
    campaign_booking_media_channel_df: Optional[DataFrame] = None,
) -> DataFrame:
    """Fail when an in-scope booking subchannel is absent from MCR."""
    if campaign_booking_media_channel_df is None:
        return format_result(
            reporting_df.sparkSession.range(1), correlation_id, campaign_period,
            Config.MISSING_INSCOPE_SUBCHANNEL_CHECK, Config.MISSING_INSCOPE_SUBCHANNEL_EXPECTED_VALUE,
            F.lit(ValidationStatus.SKIPPED.value),
            F.struct(F.lit("campaign_booking_media_input_missing").alias("reason"),
                     F.lit("Campaign-booking-media input was not provided.").alias("comment")),
        )
    campaign_rows = filter_reporting_by_correlation_id(reporting_df, correlation_id).select(
        F.upper(F.trim(F.col("booking_id"))).alias("booking_id"),
        F.upper(F.trim(F.col("campaign_id"))).alias("campaign_id"),
        "subchannel_name",
    )
    booking_rows = campaign_booking_media_channel_df.select(
        F.upper(F.trim(F.col("booking_id"))).alias("booking_id"),
        F.upper(F.trim(F.col("campaign_id"))).alias("campaign_id"),
        "marketing_subchannel",
    )
    bookings = campaign_rows.select("booking_id").distinct()
    in_scope = booking_rows.join(bookings, on="booking_id", how="inner")
    reporting_keys = campaign_rows.select(
        "campaign_id",
        F.upper(F.trim(F.col("subchannel_name"))).alias("normalized_subchannel"),
    ).distinct()
    missing = in_scope.alias("scope").join(
        reporting_keys.alias("reporting"),
        (F.col("scope.campaign_id") == F.col("reporting.campaign_id"))
        & (F.upper(F.trim(F.col("scope.marketing_subchannel"))) == F.col("reporting.normalized_subchannel")),
        how="left_anti",
    )
    stats = missing.agg(
        F.count(F.lit(1)).alias("missing_count"),
        F.count(F.when(
            F.col("marketing_subchannel").isNull()
            | (F.trim(F.col("marketing_subchannel")) == ""),
            1,
        )).alias("unmapped_subchannel_count"),
        F.sort_array(F.collect_set(F.concat_ws(
            ": ", F.col("campaign_id"), F.col("marketing_subchannel"),
        ))).alias("missing_subchannels"),
    ).crossJoin(
        campaign_rows.agg(F.count(F.lit(1)).alias("reporting_row_count"))
    )
    has_no_reporting_rows = F.col("reporting_row_count") == 0
    has_missing = (F.col("missing_count") > 0) | has_no_reporting_rows
    outcome = F.when(has_missing, ValidationStatus.FAIL.value).otherwise(ValidationStatus.PASS.value)
    metadata = F.struct(
        "missing_count", "missing_subchannels", "unmapped_subchannel_count", "reporting_row_count",
        F.when(
            has_no_reporting_rows,
            F.lit("No reporting rows found for the correlation ID; in-scope coverage cannot be validated."),
        )
        .when(
            F.col("unmapped_subchannel_count") > 0,
            F.lit("Booking subchannels could not be resolved from the in-scope hierarchy; coverage is incomplete."),
        )
        .when(has_missing, F.lit("In-scope subchannels are missing from measurement reporting."))
        .otherwise(F.lit("No missing in-scope subchannels detected.")).alias("comment"),
    )
    return format_result(
        stats, correlation_id, campaign_period, Config.MISSING_INSCOPE_SUBCHANNEL_CHECK,
        Config.MISSING_INSCOPE_SUBCHANNEL_EXPECTED_VALUE, outcome, metadata,
    )


def run_hypercare_validation_checks(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    journey_type: str = ProductType.BRAND.value,
    reach_engagement_df: Optional[DataFrame] = None,
    campaign_booking_media_channel_df: Optional[DataFrame] = None,
) -> DataFrame:
    """
    Union all hypercare checks into a QA alert table for Grafana monitoring .
    """
    checks = (
        (Config.BOOKING_ID_CHECK, check_booking_id, "1", {}),
        (Config.CORRELATION_ID_CHECK, check_correlation_id, correlation_id, {}),
        (Config.CHANNEL_COVERAGE_CHECK, check_channel_coverage, ">=1", {"journey_type": journey_type}),
        (Config.NEAR_ZERO_SALES_CHECK, check_near_zero_sales, f">={Config.NEAR_ZERO_SALES_THRESHOLD}", {"journey_type": journey_type}),
        (Config.CHANNEL_DOMINANCE_CHECK, check_channel_dominance, f"<={Config.CHANNEL_DOMINANCE_THRESHOLD}", {"journey_type": journey_type}),
        (Config.UNITS_PER_CONVERSION_CHECK, check_units_per_conversion, f"<={Config.UNITS_PER_CONV_SPREAD_WARNING}x", {"journey_type": journey_type}),
        (Config.BRAND_VS_OFFER_SALES_CHECK, check_brand_vs_offer_sales, "Brand >= Offer", {}),
        (Config.CONVERSION_RATE_CHECK, check_conversion_rates, "marketing-type thresholds", {"journey_type": journey_type}),
        (Config.INCREMENTAL_SALES_CHECK, check_incremental_sales,
         f"<=100%; warn >= {Config.INCREMENTAL_PCT_WARNING:.0%}", {"journey_type": journey_type}),
        (Config.IROAS_CHECK, check_iroas, f">0 and <={Config.IROAS_WARNING_THRESHOLD}", {"journey_type": journey_type}),
    )
    if campaign_booking_media_channel_df is not None:
        checks += (
            (Config.ROAS_CHECK, check_roas, f">0 and <={Config.ROAS_WARNING_THRESHOLD}", {"journey_type": journey_type}),
            (Config.MEDIA_SPEND_CHECK, check_media_spend, f">={LowMediaSpendConfig().low_spend_threshold}", {"journey_type": journey_type}),
            (Config.RECALIBRATION_FACTOR_CHECK, check_recalibration_factor,
             recalibration_expected_value(RecalibrationFactorsConfig()), {"journey_type": journey_type}),
            (Config.ATTRIBUTED_SALES_CHECK, check_attributed_vs_recalibrated_sales,
             f"difference <= {Config.RECALIBRATED_SALES_TOLERANCE}", {"journey_type": journey_type}),
            (Config.POST_SALES_CHECK, check_post_period_sales,
             Config.POST_SALES_EXPECTED_VALUE, {}),
            (Config.POST_CONVERSIONS_CHECK, check_post_period_conversions,
             Config.POST_CONVERSIONS_EXPECTED_VALUE, {}),
            (Config.POST_INCREMENTAL_SALES_CHECK, check_post_period_incremental_sales,
             Config.POST_INCREMENTAL_SALES_EXPECTED_VALUE, {}),
            (Config.SUBCHANNEL_CONSISTENCY_CHECK, check_subchannel_consistency,
             Config.SUBCHANNEL_CONSISTENCY_EXPECTED_VALUE, {"reach_engagement_df": reach_engagement_df}),
            (Config.ROUNDED_MEDIA_SPEND_CHECK, check_rounded_media_spend,
             "media spend is not a multiple of 10", {}),
            (Config.MISSING_INSCOPE_SUBCHANNEL_CHECK, check_missing_inscope_subchannel,
             Config.MISSING_INSCOPE_SUBCHANNEL_EXPECTED_VALUE,
             {"campaign_booking_media_channel_df": campaign_booking_media_channel_df}),
        )
    results = []
    # unifiy all checks
    for check_name, check_function, expected_value, check_kwargs in checks:
        try:
            result = check_function(
                reporting_df, correlation_id, campaign_period, **check_kwargs,
            )
            result_schema = result.schema
            # Enforce names, order and types without comparing Spark-inferred nullability.
            actual_fields = [(field.name, field.dataType) for field in result_schema]
            expected_fields = [(field.name, field.dataType) for field in QAChecks.detail_schema]
            if actual_fields != expected_fields:
                raise ValueError(
                    f"QA schema mismatch: expected {QAChecks.detail_schema.simpleString()}, "
                    f"got {result_schema.simpleString()}."
                )
        except Exception as error:
            result = format_result(
                reporting_df.sparkSession.range(1), correlation_id, campaign_period,
                check_name, expected_value, F.lit(ValidationStatus.FAIL.value),
                F.struct(
                    F.lit(type(error).__name__).alias("error_type"),
                    F.lit(str(error)).alias("error_message"),
                    F.lit(f"Check could not be evaluated: {error}").alias("comment"),
                ),
            )
        results.append(result)
    return reduce(DataFrame.unionByName, results)
