from functools import reduce
from typing import Optional

from pyspark.sql import Column, DataFrame, functions as F

from spark_pipeline.common.variables import (
    AnalyticsValidationConfig as Config,
    CampaignDurations,
    ValidationStatus,
    MarketingTypes
)
from spark_pipeline.metrics.qa_validation_metrics.hypercare_validation_metrics import (
    check_brand_vs_offer_sales as check_hypercare_brand_vs_offer_sales,
)
from spark_pipeline.metrics.utils.shared_helper import (
    filter_reporting_by_correlation_id,
    format_check_name,
    format_qa_result,
    safe_ratio,
)


BOOKING_JOURNEY_COLUMNS = ("booking_id", "campaign_duration", "journey_type")
CAMPAIGN_COLUMNS = ("booking_id", "campaign_id", "campaign_duration")


def is_instore(marketing_type: Column) -> Column:
    """Identify in-store marketing types, ignoring case and whitespace."""
    return F.lower(F.trim(marketing_type)).isin(*Config.INSTORE_MARKETING_TYPES)


def count_failed_rows(rows: DataFrame, value: Column, fail_condition: Column, failed_row: Column) -> DataFrame:
    """
    Aggregate validation results into a single-row DataFrame.

    Returns the count of non-null checked values, the count of failed rows,
    and a sorted array of failed row details.

    The failed row details are a struct of the columns in ``failed_row``.
    """
    return rows.agg(
        F.count(value).alias("checked_count"),
        F.count(F.when(fail_condition, 1)).alias("failed_count"),
        F.sort_array(F.collect_list(F.when(fail_condition, failed_row))).alias("failed_rows"),
    )


def count_rows_above_threshold(
    reporting_df: DataFrame,
    metric_column: str,
    threshold: Column,
) -> DataFrame:
    """
    Compare each reporting row's metric with its threshold.
    Equality passes and null values are ignored.
    """
    rows_to_process = (
        reporting_df
        .withColumn("threshold", threshold)
        .withColumn("value", F.col(metric_column).cast("double"))
    )
    return count_failed_rows(
        rows_to_process,
        value=F.col("value"),
        fail_condition=F.col("value") > F.col("threshold"),
        failed_row=F.struct(
            "booking_id", "campaign_id", "journey_type", "channel_name", "subchannel_name",
            "value", "threshold",
        ),
    )


def count_aggregated_ratios_above_threshold(
    reporting_df: DataFrame,
    numerator: Column,
    denominator: Column,
    group_columns: tuple[str, ...],
    threshold: Column,
) -> DataFrame:
    """
    Count aggregated groupings where SUM(numerator) / SUM(denominator) exceeds the threshold.

    We recalculate the roas, iroas and exposed_sales_uplift for these checks.

    Default grain: booking_id, campaign_duration, journey_type, combining
    all campaigns and channels. Uplift additionally groups by marketing_type.

    Equality passes. Null ratios and zero denominators are unchecked.
    Failure metadata retains group identifiers, totals, ratio and threshold.
    """
    rows = (
        reporting_df
        .groupBy(*group_columns)
        .agg(
            F.sum(numerator).alias("numerator"),
            F.sum(denominator).alias("denominator"),
        )
        .withColumn("value", safe_ratio(F.col("numerator"), F.col("denominator")))
        .withColumn("threshold", threshold)
    )

    return count_failed_rows(
        rows,
        value=F.col("value"),
        fail_condition=F.col("value") > F.col("threshold"),
        failed_row=F.struct(
            *group_columns, "numerator", "denominator", "value", "threshold",
        ),
    )


def format_value(value: Column) -> Column:
    """Format to two decimal places if rounding preserves the original value."""
    return F.when(value == F.round(value, 2), F.format_number(value, 2)).otherwise(value.cast("string"))


def format_details_for_failed_checks(
    row: Column,
    detail_columns: tuple[str, ...] = ("channel_name", "subchannel_name"),
) -> Column:
    """
    Format a failed reporting row for the detail column.

    Example: "In-store - trolleys (12.50)"
    """
    return F.concat(
        F.concat_ws(" - ", *[row[name] for name in detail_columns]),
        F.lit(" ("),
        format_value(row["value"]),
        F.lit(")"),
    )


def format_fail_result(
    stats: DataFrame,
    correlation_id: str,
    campaign_period: str,
    check_name: str,
    expected_value: Optional[str] = None,
    detail_columns: tuple[str, ...] = ("channel_name", "subchannel_name"),
    **thresholds: float,
) -> DataFrame:
    """
    Turn 'count_failed_rows' stats into a QA row for Grafana.

    No usable values means skipped; any failed row/group fails, otherwise pass.
    Failed identifiers/values go in details; thresholds stay in metadata.
    """
    outcome = (
        F.when(F.col("checked_count") == 0, ValidationStatus.SKIPPED.value)
        .when(F.col("failed_count") > 0, ValidationStatus.FAIL.value)
        .otherwise(ValidationStatus.PASS.value)
    )

    details = (
        F.when(F.col("checked_count") == 0, F.lit("No values to check."))
        .when(F.col("failed_count") > 0, F.concat_ws("; ", F.transform(
            F.col("failed_rows"), lambda row: format_details_for_failed_checks(row, detail_columns),
        )))
        .otherwise(F.lit("All rows passed."))
    )
    metadata = F.struct(
        "checked_count",
        "failed_count",
        "failed_rows",
        *[F.lit(value).alias(name) for name, value in thresholds.items()],
    )
    return format_qa_result(
        stats, correlation_id, Config.CHECK_TYPE, format_check_name(check_name, campaign_period),
        expected_value, outcome, metadata, details=details,
    )


def check_brand_vs_offer_sales(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
) -> DataFrame:
    """
    Compare campaign Brand/Offer maximum per booking, campaign and period.

    Match the SQL's MAX of four-decimal sales rather than channel-level sums.
    """
    campaign_sales = (
        reporting_df
        .groupBy(
            "correlation_id", *CAMPAIGN_COLUMNS, "journey_type",
        )
        .agg(
            F.max(F.round("attributed_recalibrated_sales_amt", 4)).alias("attributed_recalibrated_sales_amt"),
        )
    )

    return (
        check_hypercare_brand_vs_offer_sales(
            campaign_sales, correlation_id, campaign_period,
            group_by_columns=CAMPAIGN_COLUMNS, decimal_places=4,
        )
        .withColumn("type", F.lit(Config.CHECK_TYPE))
        .withColumn("name", F.lit(format_check_name(Config.OFFER_VS_BRAND_SALES_CHECK, campaign_period)))
        .withColumn("details", F.get_json_object("additional_metadata", "$.comment"))
    )


def check_conversion_rate(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    instore_threshold: float = Config.INSTORE_CONVERSION_RATE_MAX,
    default_channel_threshold: float = Config.DEFAULT_CHANNEL_CONVERSION_RATE_MAX,
) -> DataFrame:
    """
    Check conversion rate <= 10% for in-store channels or <= 20% for other channels.

    Reporting conversion rates are percentage points, so compare with 10/20.
    """
    threshold = F.when(is_instore(F.col("marketing_type")), instore_threshold).otherwise(default_channel_threshold)
    stats = count_rows_above_threshold(reporting_df, "conversion_rate", threshold)

    return format_fail_result(
        stats, correlation_id, campaign_period, Config.CONVERSION_RATE_CHECK,
        instore_threshold=instore_threshold, default_channel_threshold=default_channel_threshold,
    )


def check_roas(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    threshold: float = Config.ROAS_MAX,
) -> DataFrame:
    """Check summed attributed sales / spend <= 20 per booking, period and journey."""
    stats = count_aggregated_ratios_above_threshold(
        reporting_df, F.round("attributed_recalibrated_sales_amt", 4), F.col("media_spend_amt"),
        BOOKING_JOURNEY_COLUMNS, F.lit(threshold),
    )
    return format_fail_result(
        stats, correlation_id, campaign_period, Config.ROAS_CHECK,
        expected_value=f"{threshold:g}", detail_columns=BOOKING_JOURNEY_COLUMNS, threshold=threshold,
    )


def check_iroas(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    threshold: float = Config.IROAS_MAX,
) -> DataFrame:
    """
    Check summed incremental sales / spend <= 2 per booking, period and journey.

    Null-only incremental sales (normally Offer) are unchecked.
    """
    stats = count_aggregated_ratios_above_threshold(
        reporting_df, F.col("incremental_sales_amt_exposed"), F.col("media_spend_amt"),
        BOOKING_JOURNEY_COLUMNS, F.lit(threshold),
    )
    return format_fail_result(
        stats, correlation_id, campaign_period, Config.IROAS_CHECK,
        expected_value=f"{threshold:g}", detail_columns=BOOKING_JOURNEY_COLUMNS, threshold=threshold,
    )


def check_exposed_sales_uplift(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    instore_threshold: float = Config.INSTORE_EXPOSED_SALES_UPLIFT_MAX,
    default_channel_threshold: float = Config.DEFAULT_CHANNEL_EXPOSED_SALES_UPLIFT_MAX,
) -> DataFrame:
    """
    Check exposed sales uplift <= 20% in-store or <= 80% elsewhere.

    Divide summed incremental sales by summed base sales per booking, period,
    journey and marketing type
    """
    group_columns = (*BOOKING_JOURNEY_COLUMNS, "marketing_type")
    threshold = F.when(is_instore(F.col("marketing_type")), instore_threshold).otherwise(default_channel_threshold)
    stats = count_aggregated_ratios_above_threshold(
        reporting_df, F.col("incremental_sales_amt_exposed"), F.col("base_sales_amt_exposed"),
        group_columns, threshold,
    )
    return format_fail_result(
        stats, correlation_id, campaign_period, Config.EXPOSED_SALES_UPLIFT_CHECK,
        detail_columns=group_columns, instore_threshold=instore_threshold,
        default_channel_threshold=default_channel_threshold,
    )


def check_offsite_media_spend(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
    multiple: float = Config.OFFSITE_MEDIA_SPEND_MULTIPLE,
) -> DataFrame:
    """
    Check each offsite row's spend is positive and not a multiple of 1,000.

    No spend aggregation or deduplication is applied. Null spend is ignored;
    zero and negative spend fail.
    """
    if multiple <= 0:
        raise ValueError("The offsite media spend multiple must be positive.")

    offsite_spend = (
        reporting_df
        .filter(F.lower(F.trim(F.col("marketing_type"))) == MarketingTypes.OFFSITE)
        .withColumn("value", F.col("media_spend_amt").cast("double"))
        .withColumn("threshold", F.lit(multiple))
    )
    stats = count_failed_rows(
        offsite_spend,
        value=F.col("value"),
        fail_condition=(F.col("value") <= 0) | (F.pmod(F.col("value"), F.col("threshold")) == 0),
        failed_row=F.struct(
            "booking_id", "campaign_id", "journey_type", "channel_name", "subchannel_name",
            "value", "threshold",
        ),
    )
    return format_fail_result(
        stats, correlation_id, campaign_period, Config.OFFSITE_MEDIA_SPEND_CHECK,
        expected_value=f"{multiple:g}", multiple=multiple,
    )


def run_analytics_validation_checks(
    reporting_df: DataFrame,
    correlation_id: str,
    campaign_period: str = CampaignDurations.CAMPAIGN_DURATION_DURING,
) -> DataFrame:
    """
    Returns one result for each analytics check.
    Filter by correlation ID, then carry out each check.
    """
    filtered_reporting_df = filter_reporting_by_correlation_id(
        reporting_df, correlation_id,
    )

    checks = (
        check_brand_vs_offer_sales,
        check_conversion_rate,
        check_roas,
        check_iroas,
        check_exposed_sales_uplift,
        check_offsite_media_spend,
    )
    return reduce(DataFrame.unionByName, [
        check(filtered_reporting_df, correlation_id, campaign_period) for check in checks
    ])
