import uuid

from pyspark.sql import DataFrame

from spark_pipeline.utils.pipeline_utils import (
    safe_decimal_conversion,
    safe_float_conversion,
)
from spark_pipeline.utils.mta_events import CampaignReporting
from spark_pipeline.utils.publish_metrics import MetricsPublisher


def publish_campaign_reporting_metrics(
    measurement_campaign_reporting_df: DataFrame,
    metrics_topic_arn: str,
) -> int:
    batch_id = str(uuid.uuid4())
    rows = measurement_campaign_reporting_df.collect()
    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

    for row in rows:
        event = CampaignReporting(
            correlation_id=row["correlation_id"],
            name="Measurement Campaign Reporting",
            batch_id=batch_id,
            campaign_id=row["campaign_id"],
            booking_id=row["booking_id"],
            campaign_duration=row["campaign_duration"],
            journey_type=row["journey_type"],
            marketing_type=row["marketing_type"],
            channel_name=row["channel_name"],
            subchannel_name=row["subchannel_name"],
            sub_category_name=row["sub_category_name"],
            attributed_conversions=safe_float_conversion(row["attributed_conversions"]),
            incremental_sales_amt_exposed=safe_float_conversion(row["incremental_sales_amt_exposed"]),
            super_category_name=row["super_category_name"],
            campaign_name=row["campaign_name"],
            attributed_recalibrated_sales_amt=safe_decimal_conversion(row["attributed_recalibrated_sales_amt"]),
            attributed_recalibrated_units_qty=safe_decimal_conversion(row["attributed_recalibrated_units_qty"]),
            incremental_units_qty_exposed=safe_float_conversion(row["incremental_units_qty_exposed"]),
            attributed_units_qty=safe_float_conversion(row["attributed_units_qty"]),
            attributed_sales_amt=safe_float_conversion(row["attributed_sales_amt"]),
            conversions_recalibrated=safe_float_conversion(row["conversions_recalibrated"]),
            recalibration_factor=safe_float_conversion(row["recalibration_factor"]),
            job_bag_number=row["job_bag_number"],
            nectar_sales_amt=safe_float_conversion(row["nectar_sales_amt"]),
            non_nectar_sales_amt=safe_float_conversion(row["non_nectar_sales_amt"]),
            media_spend_amt=safe_float_conversion(row["media_spend_amt"]),
            campaign_type=row["campaign_type"],
            roas_exposed=safe_float_conversion(row["roas_exposed"]),
            iroas_exposed=safe_float_conversion(row["iroas_exposed"]),
            base_sales_amt_exposed=safe_float_conversion(row["base_sales_amt_exposed"]),
            uplift_exposed_sales_amt=safe_float_conversion(row["uplift_exposed_sales_amt"]),
            uplift_exposed_units_qty=safe_float_conversion(row["uplift_exposed_units_qty"]),
            num_user_journeys=safe_float_conversion(row["num_user_journeys"]),
            num_conversions=safe_float_conversion(row["num_conversions"]),
            attributed_recalibrated_sales_amt_per_uj=safe_decimal_conversion(row["attributed_recalibrated_sales_amt_per_uj"]),
            attributed_recalibrated_sales_amt_per_conversion=safe_decimal_conversion(row["attributed_recalibrated_sales_amt_per_conversion"]),
            conversion_per_uj=safe_decimal_conversion(row["conversion_per_uj"]),
            conversion_rate=safe_float_conversion(row["conversion_rate"]),
            load_ts=str(row["load_ts"]),
        )

        publisher.publish_event(
            message_subject="Campaign Metrics Event",
            event=event,
        )

    return len(rows)
