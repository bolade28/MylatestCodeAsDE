from pyspark.sql import DataFrame, functions as F

from spark_pipeline.common.variables import (
    BaselineProcessedData,
    CouponAtTillConfig,
    EcouponConfig,
    HISTORICAL_LOOKBACK_WEEKS,
    InstoreConfig,
    MarketingMetricNames,
    MetaConfig,
    PipelineSummaryMetricsConfig,
    Severity,
)
from spark_pipeline.schemas.pipeline_summary import PipelineSummaryMetricsSchema
from spark_pipeline.utils.stdout_logger import get_stdout_logger


def has_empty_campaign_details_inputs(
    campaign_details_metrics_df: DataFrame,
    product_details_df: DataFrame,
    marketing_details_df: DataFrame,
) -> bool:
    """Return True if any critical input DataFrame is empty."""
    return (
        campaign_details_metrics_df.isEmpty()
        or product_details_df.isEmpty()
        or marketing_details_df.isEmpty()
    )


def _normalize_columns_to_lowercase(dataframe: DataFrame, columns: list[str]) -> DataFrame:
    """Normalize specified columns to lowercase, trimming whitespace where applicable."""
    result_df = dataframe
    for col_name in columns:
        if col_name in result_df.columns:
            result_df = result_df.withColumn(col_name, F.lower(F.trim(F.col(col_name))))
    return result_df


def _filter_by_booking_id_if_present(dataframe: DataFrame, booking_id: str) -> DataFrame:
    """Filter to booking_id only when the DataFrame includes a booking_id column."""
    if "booking_id" not in dataframe.columns:
        return dataframe

    booking_id_lower = booking_id.lower()
    return dataframe.filter(
        F.lower(F.col("booking_id").cast("string")) == F.lit(booking_id_lower)
    )


def _sum_sku_group_fingerprint_for_grouping(
    product_details_df: DataFrame,
    groupby_cols: list[str],
) -> DataFrame:
    """
    Generate fingerprint by summing distinct item_cd values and hashing the result.

    This enables quick comparison of SKU inventory across runs without detailed review.
    For DS analysis: one fingerprint per brand, one per offer (product_type).

    Args:
        product_details_df: DataFrame with item_cd and grouping columns.
        groupby_cols: Columns to group by (e.g., ["unique_brand_name"] for brand fingerprint,
                      or ["unique_brand_name", "product_type"] for offer fingerprint).

    Returns:
        DataFrame with groupby_cols and "sum_sku_group_fingerprint" hash column.
    """
    summed_col = F.sum(F.col("item_cd").cast("long")).cast("string")
    return (
        product_details_df
        .groupBy(*groupby_cols)
        .agg(
            F.xxhash64(summed_col).alias("sum_sku_group_fingerprint")
        )
    )


def sum_sku_group_fingerprint(product_details_df: DataFrame) -> tuple[DataFrame, DataFrame]:
    """
    Generate two fingerprints for SKU inventory validation across data runs.

    Computes a fingerprint per brand and per offer (product_type) by:
    1. Casting item_cd to long (numeric) to sum values
    2. Hashing the sum for quick comparison across runs
    3. Enables DS to detect if inventory changed between model runs

    Args:
        product_details_df: DataFrame containing item_cd, unique_brand_name, and product_type.

    Returns:
        Tuple of (brand_fingerprints_df, offer_fingerprints_df)
        - brand_fingerprints_df: unique_brand_name -> sum_sku_group_fingerprint
        - offer_fingerprints_df: (unique_brand_name, product_type) -> sum_sku_group_fingerprint
    """
    brand_fingerprints = _sum_sku_group_fingerprint_for_grouping(
        product_details_df,
        ["unique_brand_name"]
    )

    offer_fingerprints = _sum_sku_group_fingerprint_for_grouping(
        product_details_df,
        ["unique_brand_name", "product_type"]
    )

    return brand_fingerprints, offer_fingerprints


def build_campaign_details_metrics_df(
    unified_campaign_df: DataFrame,
    booking_id: str,
    correlation_id: str,
) -> DataFrame:
    """Build campaign details DataFrame used by pipeline summary."""
    select_cols = []
    for col_name in PipelineSummaryMetricsConfig.CAMPAIGN_DETAILS_INPUT_COLS:
        alias = PipelineSummaryMetricsConfig.CAMPAIGN_DETAILS_ALIASES.get(col_name)
        if alias:
            select_cols.append(F.col(col_name).alias(alias))
        else:
            select_cols.append(col_name)

    booking_id_lower = booking_id.lower()
    campaign_details_metrics_df = (
        unified_campaign_df
        .filter(F.lower(F.col("booking_id").cast("string")) == F.lit(booking_id_lower))
        .select(*select_cols)
        .withColumn("correlation_id", F.lit(correlation_id))
    )
    return campaign_details_metrics_df


def build_product_details_df(
    product_details_raw_df: DataFrame,
    booking_id: str,
    correlation_id: str,
) -> DataFrame:
    """Build product details DataFrame used by pipeline summary."""
    sales_amount_column = next(
        (column_name for column_name in PipelineSummaryMetricsConfig.SALES_AMOUNT_CANDIDATES if column_name in product_details_raw_df.columns),
        None,
    )

    product_select_cols = list(PipelineSummaryMetricsConfig.PRODUCT_DETAILS_BASE_COLS)
    if sales_amount_column:
        product_select_cols.append(sales_amount_column)

    product_details_df = (
        _filter_by_booking_id_if_present(product_details_raw_df, booking_id)
        .select(*product_select_cols)
        .withColumn(
            "sales_amt",
            F.col(sales_amount_column).cast("double") if sales_amount_column else F.lit(None).cast("double"),
        )
        .withColumn("correlation_id", F.lit(correlation_id))
    )

    return product_details_df


def build_marketing_details_df(
    baseline_modelling_dataset_df: DataFrame,
    booking_id: str,
    campaign_details_metrics_df: DataFrame,
) -> DataFrame:
    """Build marketing details DataFrame used by pipeline summary."""
    marketing_key_cols = PipelineSummaryMetricsConfig.MARKETING_KEY_COLS
    cols_to_normalize = marketing_key_cols + ["metric_name", "marketing_type_name"]

    baseline_marketing_df = _filter_by_booking_id_if_present(
        baseline_modelling_dataset_df,
        booking_id,
    )
    baseline_marketing_df = _normalize_columns_to_lowercase(baseline_marketing_df, cols_to_normalize)

    campaign_marketing_keys_df = campaign_details_metrics_df.select(
        *PipelineSummaryMetricsConfig.CAMPAIGN_MARKETING_KEYS_COLS
    )
    campaign_marketing_keys_df = _normalize_columns_to_lowercase(campaign_marketing_keys_df, marketing_key_cols)

    baseline_filtered_df = baseline_marketing_df.filter(
        F.col("metric_name").isin(
            [
                MarketingMetricNames.IMPRESSIONS.lower(),
                CouponAtTillConfig.METRIC_NAME.lower(),
                EcouponConfig.METRIC_NAME.lower(),
                InstoreConfig.METRIC_NAME.lower(),
                BaselineProcessedData.citrus_onsite_impressions_metric.lower(),
                BaselineProcessedData.sales_data_config["metric_name"].lower(),
            ]
        )
    )

    # Baseline inputs may already carry correlation_id; keep only the campaign-side value.
    if "correlation_id" in baseline_filtered_df.columns:
        baseline_filtered_df = baseline_filtered_df.drop("correlation_id")

    marketing_details_df = (
        baseline_filtered_df
        .join(
            campaign_marketing_keys_df.distinct(),
            on=["super_category_name", "unique_brand_name"],
            how="inner",
        )
        .filter(
            (
                F.to_date(F.col("week_start_dt"))
                >= F.date_sub(F.to_date(F.col("campaign_start_date")), HISTORICAL_LOOKBACK_WEEKS * 7)
            )
            & (F.to_date(F.col("week_start_dt")) <= F.to_date(F.col("campaign_start_date")))
        )
    )

    return marketing_details_df


def build_campaign_booking_media_channel_df(
    campaign_booking_media_channel_raw_df: DataFrame,
    campaign_details_metrics_df: DataFrame,
) -> DataFrame:
    """Build booking media channel DataFrame used by pipeline summary."""

    campaign_booking_media_channel_df = (
        campaign_booking_media_channel_raw_df
        .join(
            campaign_details_metrics_df.select("campaign_id", "booking_id").distinct(),
            on=["campaign_id", "booking_id"],
            how="inner",
        )
    )

    return campaign_booking_media_channel_df


def _explode_metric_columns(overview_df: DataFrame, metric_columns: list[str]) -> DataFrame:
    """Convert one section overview DataFrame into long metric rows."""
    metric_structs = [
        F.struct(
            F.lit(metric_column).alias("name"),
            F.col(metric_column).cast("double").alias("value"),
        )
        for metric_column in metric_columns
    ]

    return (
        overview_df
        .select("correlation_id", F.explode(F.array(*metric_structs)).alias("metric"))
        .select(
            F.col("correlation_id"),
            F.col("metric.name").alias("name"),
            F.col("metric.value").alias("value"),
        )
    )


def campaign_definition_summary(
    campaign_details_metrics_df: DataFrame,
    campaign_booking_media_channel_df: DataFrame,
    severity: str,
) -> DataFrame:
    """Build Campaign Definition summary rows."""
    campaign_overview_df = (
        campaign_details_metrics_df
        .groupBy("correlation_id", "campaign_id", "booking_id")
        .agg(
            F.countDistinct("subchannel_name").alias("distinct_subchannels"),
            F.sum("media_spend_amt").alias("total_media_spend"),
            F.countDistinct("unique_brand_name").alias("unique_brand_names"),
            F.countDistinct("super_category_name").alias("unique_super_categories"),
        )
    )

    deduped_booking_media_df = (
        campaign_booking_media_channel_df
        .groupBy(*PipelineSummaryMetricsConfig.JOIN_KEY_COLS)
        .agg(F.min("store_cd_list").alias("store_cd_list"))
    )

    campaign_overview_df = (
        campaign_overview_df
        .join(deduped_booking_media_df, on=PipelineSummaryMetricsConfig.JOIN_KEY_COLS, how="left")
        .withColumn(
            "unique_store_count",
            F.when(
                F.col("store_cd_list").isNotNull(),
                F.size(F.split(F.col("store_cd_list"), ",")),
            ).otherwise(F.lit(None)),
        )
    )

    metrics_df = _explode_metric_columns(
        overview_df=campaign_overview_df,
        metric_columns=[
            "distinct_subchannels",
            "total_media_spend",
            "unique_brand_names",
            "unique_super_categories",
            "unique_store_count",
        ],
    )

    campaign_definition_summary_df = (
        metrics_df
        .select(
            F.col("correlation_id"),
            F.col("name"),
            F.col("value"),
            F.lit(PipelineSummaryMetricsConfig.DATA_GROUP_CAMPAIGN).alias("data_group"),
            F.lit(PipelineSummaryMetricsConfig.DATA_SOURCE_UNIFIED_CAMPAIGN).alias("data_sources"),
            F.lit(severity).alias("severity"),
            PipelineSummaryMetricsSchema.campaign_definition_metadata_struct().alias("metadata"),
        )
    )
    return campaign_definition_summary_df


def product_details_summary(
    product_details_df: DataFrame,
    campaign_details_metrics_df: DataFrame,
    severity: str,
) -> DataFrame:
    """Build Product Details summary rows."""
    sales_amt_expr = F.sum("sales_amt").alias("total_sales_amt_104w")

    product_overview_df = (
        product_details_df
        .join(
            campaign_details_metrics_df
            .select("correlation_id", "campaign_id", "booking_id", "campaign_start_date")
            .distinct(),
            on=["correlation_id", "campaign_id", "booking_id"],
            how="inner",
        )
        .filter(
            (
                F.to_date(F.col("load_ts"))
                >= F.date_sub(F.to_date(F.col("campaign_start_date")), HISTORICAL_LOOKBACK_WEEKS * 7)
            )
            & (F.to_date(F.col("load_ts")) <= F.to_date(F.col("campaign_start_date")))
        )
        .groupBy("correlation_id", "campaign_id", "booking_id", "product_type", "brand_name")
        .agg(
            F.countDistinct("sku_name").alias("sku_count_by_brand"),
            F.xxhash64(F.concat_ws(",", F.sort_array(F.collect_set("item_cd")))).alias(
                "sku_group_fingerprint"
            ),
            sales_amt_expr,
        )
    )

    metrics_df = _explode_metric_columns(
        overview_df=product_overview_df,
        metric_columns=[
            "sku_count_by_brand",
            "sku_group_fingerprint",
            "total_sales_amt_104w",
        ],
    )

    product_details_summary_df = (
        metrics_df
        .select(
            F.col("correlation_id"),
            F.col("name"),
            F.col("value"),
            F.lit(PipelineSummaryMetricsConfig.DATA_GROUP_PRODUCT).alias("data_group"),
            F.lit(PipelineSummaryMetricsConfig.DATA_SOURCE_CAMPAIGN_PRODUCT).alias("data_sources"),
            F.lit(severity).alias("severity"),
            PipelineSummaryMetricsSchema.product_details_metadata_struct().alias("metadata"),
        )
    )
    return product_details_summary_df


def marketing_details_summary(
    marketing_details_df: DataFrame,
    campaign_details_metrics_df: DataFrame,
    campaign_booking_media_channel_df: DataFrame,
    severity: str,
) -> DataFrame:
    """Build Marketing Details summary rows."""
    # Normalize marketing_type_name and metric_name for comparison
    marketing_details_df = _normalize_columns_to_lowercase(
        marketing_details_df,
        ["marketing_type_name", "metric_name"]
    )

    instore_impressions_condition = (
        F.col("marketing_type_name") == InstoreConfig.MARKETING_CHANNEL.lower()
    )
    onsite_impressions_condition = (
        (F.col("marketing_type_name") == BaselineProcessedData.citrus_processed_data_config["marketing_type_name"].lower())
        & (F.col("metric_name") == BaselineProcessedData.citrus_onsite_impressions_metric.lower())
    )
    offsite_impressions_condition = (
        (F.col("marketing_type_name") == MetaConfig.MARKETING_TYPE.lower())
        & (F.col("metric_name") == MarketingMetricNames.IMPRESSIONS.lower())
    )
    coupon_at_till_base_value_condition = (
        (F.col("marketing_type_name") == CouponAtTillConfig.MARKETING_TYPE.lower())
        & (F.col("metric_name") == CouponAtTillConfig.METRIC_NAME.lower())
    )
    ecoupon_base_value_condition = (
        (F.col("marketing_type_name") == EcouponConfig.MARKETING_TYPE.lower())
        & (F.col("metric_name") == EcouponConfig.METRIC_NAME.lower())
    )

    marketing_overview_df = (
        marketing_details_df
        .groupBy("correlation_id", "campaign_id", "booking_id")
        .agg(
            F.sum(
                F.when(instore_impressions_condition, F.col("metric_value")).otherwise(0)
            ).alias("instore_impressions"),
            F.sum(
                F.when(onsite_impressions_condition, F.col("metric_value")).otherwise(0)
            ).alias("onsite_impressions"),
            F.sum(
                F.when(offsite_impressions_condition, F.col("metric_value")).otherwise(0)
            ).alias("offsite_impressions"),
            F.sum(
                F.when(coupon_at_till_base_value_condition, F.col("metric_value")).otherwise(0)
            ).alias("coupon_at_till_base_value"),
            F.sum(
                F.when(ecoupon_base_value_condition, F.col("metric_value")).otherwise(0)
            ).alias("ecoupon_base_value"),
            F.countDistinct(
                F.when(offsite_impressions_condition, F.col("campaign_id"))
            ).alias("distinct_offsite_campaigns"),
            F.countDistinct(
                F.when(onsite_impressions_condition, F.col("campaign_id"))
            ).alias("distinct_onsite_campaigns"),
            F.countDistinct(
                F.when(instore_impressions_condition, F.col("campaign_id"))
            ).alias("distinct_instore_campaigns"),
        )
    )

    targeted_stores_df = (
        campaign_details_metrics_df
        .select("correlation_id", "campaign_id", "booking_id")
        .distinct()
        .join(
            campaign_booking_media_channel_df
            .groupBy("campaign_id", "booking_id")
            .agg(F.min("store_cd_list").alias("store_cd_list")),
            on=["campaign_id", "booking_id"],
            how="left",
        )
        .withColumn(
            "targeted_stores",
            F.when(
                F.col("store_cd_list").isNotNull(),
                F.size(F.split(F.col("store_cd_list"), ",")),
            ).otherwise(F.lit(None)),
        )
        .select("correlation_id", "campaign_id", "booking_id", "targeted_stores")
    )

    marketing_overview_df = marketing_overview_df.join(
        targeted_stores_df,
        on=["correlation_id", "campaign_id", "booking_id"],
        how="left",
    )

    metrics_df = _explode_metric_columns(
        overview_df=marketing_overview_df,
        metric_columns=[
            "targeted_stores",
            "instore_impressions",
            "onsite_impressions",
            "offsite_impressions",
            "coupon_at_till_base_value",
            "ecoupon_base_value",
            "distinct_offsite_campaigns",
            "distinct_onsite_campaigns",
            "distinct_instore_campaigns",
        ],
    )

    marketing_details_summary_df = (
        metrics_df
        .select(
            F.col("correlation_id"),
            F.col("name"),
            F.col("value"),
            F.lit(PipelineSummaryMetricsConfig.DATA_GROUP_MARKETING).alias("data_group"),
            F.lit(PipelineSummaryMetricsConfig.DATA_SOURCE_BASELINE_DATASET).alias("data_sources"),
            F.lit(severity).alias("severity"),
            PipelineSummaryMetricsSchema.marketing_details_metadata_struct().alias("metadata"),
        )
    )

    return marketing_details_summary_df


def input_layer_summary(
    unified_campaign_df: DataFrame,
    product_details_raw_df: DataFrame,
    baseline_modelling_dataset_df: DataFrame,
    campaign_booking_media_channel_raw_df: DataFrame,
    booking_id: str,
    correlation_id: str,
    severity: Severity = Severity.HIGH,
) -> DataFrame | None:
    """Build one canonical pipeline summary row per correlation_id."""
    logger = get_stdout_logger()
    campaign_details_metrics_df = build_campaign_details_metrics_df(
        unified_campaign_df=unified_campaign_df,
        booking_id=booking_id,
        correlation_id=correlation_id,
    ).cache()

    product_details_df = build_product_details_df(
        product_details_raw_df=product_details_raw_df,
        booking_id=booking_id,
        correlation_id=correlation_id,
    )

    marketing_details_df = build_marketing_details_df(
        baseline_modelling_dataset_df=baseline_modelling_dataset_df,
        booking_id=booking_id,
        campaign_details_metrics_df=campaign_details_metrics_df,
    )

    campaign_booking_media_channel_df = build_campaign_booking_media_channel_df(
        campaign_booking_media_channel_raw_df=campaign_booking_media_channel_raw_df,
        campaign_details_metrics_df=campaign_details_metrics_df,
    )

    if has_empty_campaign_details_inputs(
        campaign_details_metrics_df=campaign_details_metrics_df,
        product_details_df=product_details_df,
        marketing_details_df=marketing_details_df,
    ):
        logger.warning(
            "One or more pipeline summary input DataFrames are empty. "
            f"Skipping publish for correlation_id={correlation_id}",
            log_type="publish_pipeline_summary",
        )
        campaign_details_metrics_df.unpersist()
        return None

    campaign_df = campaign_definition_summary(
        campaign_details_metrics_df=campaign_details_metrics_df,
        campaign_booking_media_channel_df=campaign_booking_media_channel_df,
        severity=severity.value,
    )
    logger.info(
        f"Built campaign summary for correlation_id={correlation_id}",
        log_type="publish_pipeline_summary",
    )

    product_df = product_details_summary(
        product_details_df=product_details_df,
        campaign_details_metrics_df=campaign_details_metrics_df,
        severity=severity.value,
    )
    logger.info(
        f"Built product summary for correlation_id={correlation_id}",
        log_type="publish_pipeline_summary",
    )

    marketing_df = marketing_details_summary(
        marketing_details_df=marketing_details_df,
        campaign_details_metrics_df=campaign_details_metrics_df,
        campaign_booking_media_channel_df=campaign_booking_media_channel_df,
        severity=severity.value,
    )
    logger.info(
        f"Built marketing summary for correlation_id={correlation_id}",
        log_type="publish_pipeline_summary",
    )

    unioned_df = campaign_df.unionByName(product_df).unionByName(marketing_df)

    campaign_context_df = (
        campaign_details_metrics_df
        .groupBy("correlation_id")
        .agg(
            F.date_format(F.min(F.to_date(F.col("campaign_start_date"))), "yyyy-MM-dd").alias(
                "min_campaign_start_date"
            ),
            F.date_format(F.max(F.to_date(F.col("campaign_end_date"))), "yyyy-MM-dd").alias(
                "max_campaign_end_date"
            ),
            F.date_format(F.max(F.to_date(F.col("post_campaign_date"))), "yyyy-MM-dd").alias(
                "max_post_end_date"
            ),
            F.concat_ws(", ", F.sort_array(F.collect_set(F.col("unique_brand_name")))).alias(
                "unique_brand_names_text"
            ),
            F.concat_ws(", ", F.sort_array(F.collect_set(F.col("super_category_name")))).alias(
                "super_category_names_text"
            ),
        )
    )

    # Calculate SKU group fingerprints for brand and offer levels
    brand_fingerprints, offer_fingerprints = sum_sku_group_fingerprint(product_details_df)

    # Aggregate fingerprints at campaign level by taking max (since fingerprint should be same for all rows)
    brand_fingerprints_agg = (
        brand_fingerprints
        .groupBy()
        .agg(F.max("sum_sku_group_fingerprint").alias("brand_sku_group_fingerprint"))
    )

    offer_fingerprints_agg = (
        offer_fingerprints
        .groupBy()
        .agg(F.max("sum_sku_group_fingerprint").alias("offer_sku_group_fingerprint"))
    )

    product_context_df = (
        product_details_df
        .select("*")  # Ensure we have all columns
        .withColumn("product_type", F.lower(F.trim(F.col("product_type"))))
        .withColumn("unique_brand_name", F.lower(F.trim(F.col("unique_brand_name"))))
        .groupBy("correlation_id")
        .agg(
            F.countDistinct(
                F.when(
                    F.col("product_type").contains(PipelineSummaryMetricsConfig.PRODUCT_TYPE_OFFER),
                    F.col("sku_name"),
                )
            ).alias("offer_sku_count"),
            F.countDistinct(
                F.when(
                    F.col("product_type").contains(PipelineSummaryMetricsConfig.PRODUCT_TYPE_BRAND),
                    F.col("sku_name"),
                )
            ).alias("brand_sku_count"),
        )
        .crossJoin(brand_fingerprints_agg)
        .crossJoin(offer_fingerprints_agg)
    )

    baseline_with_sales_df = (
        marketing_details_df
        .filter(
            (F.col("marketing_type_name") == BaselineProcessedData.sales_data_config["marketing_type_name"].lower())
            & (F.col("metric_name") == BaselineProcessedData.sales_data_config["metric_name"].lower())
        )
    )

    sales_104w_by_brand_df = (
        baseline_with_sales_df
        .groupBy("correlation_id", "unique_brand_name")
        .agg(
            F.sum(
                F.when(
                    F.to_date(F.col("week_start_dt")) >= F.date_sub(
                        F.to_date(F.col("campaign_start_date")), HISTORICAL_LOOKBACK_WEEKS * 7
                    ),
                    F.col("metric_value"),
                ).otherwise(F.lit(0))
            ).alias("sum_sales_104wks")
        )
    )

    product_brand_type_df = (
        product_details_df
        .withColumn("product_type", F.lower(F.trim(F.col("product_type"))))
        .withColumn("unique_brand_name", F.lower(F.trim(F.col("unique_brand_name"))))
        .groupBy("correlation_id", "unique_brand_name")
        .agg(
            F.max(
                F.when(F.col("product_type").contains(PipelineSummaryMetricsConfig.PRODUCT_TYPE_OFFER), F.lit(1)).otherwise(F.lit(0))
            ).alias("has_offer"),
            F.max(
                F.when(F.col("product_type").contains(PipelineSummaryMetricsConfig.PRODUCT_TYPE_BRAND), F.lit(1)).otherwise(F.lit(0))
            ).alias("has_brand"),
        )
    )

    product_sales_context_df = (
        product_brand_type_df
        .join(
            sales_104w_by_brand_df,
            on=["correlation_id", "unique_brand_name"],
            how="left",
        )
        .groupBy("correlation_id")
        .agg(
            F.sum(F.when(F.col("has_offer") == F.lit(1), F.col("sum_sales_104wks")).otherwise(F.lit(0))).alias(
                "offer_sales_amt_104w"
            ),
            F.sum(F.when(F.col("has_brand") == F.lit(1), F.col("sum_sales_104wks")).otherwise(F.lit(0))).alias(
                "brand_sales_amt_104w"
            ),
        )
    )

    metric_values_df = (
        unioned_df
        .groupBy("correlation_id", "name")
        .agg(F.max(F.col("value")).alias("metric_value"))
        .groupBy("correlation_id")
        .agg(
            F.map_from_entries(
                F.collect_list(F.struct(F.col("name"), F.col("metric_value")))
            ).alias("metric_values")
        )
    )

    canonical_summary_df = (
        unioned_df
        .groupBy("correlation_id")
        .agg(
            F.concat_ws(",", F.sort_array(F.collect_set(F.col("data_sources")))).alias(
                "data_sources"
            ),
            F.first(F.col("severity"), ignorenulls=True).alias("severity"),
        )
        .join(metric_values_df, on=["correlation_id"], how="left")
        .join(campaign_context_df, on=["correlation_id"], how="left")
        .join(product_context_df, on=["correlation_id"], how="left")
        .join(product_sales_context_df, on=["correlation_id"], how="left")
        .select(
            F.col("correlation_id"),
            F.lit("campaign_details").alias("name"),
            F.lit("campaign_details").alias("data_group"),
            F.col("data_sources"),
            F.col("severity"),
            PipelineSummaryMetricsSchema.canonical_metadata_struct_with_values(
                metric_values=F.col("metric_values"),
                campaign_dates_value=F.struct(
                    F.col("min_campaign_start_date").alias("min_campaign_start_date"),
                    F.col("max_campaign_end_date").alias("max_campaign_end_date"),
                    F.col("max_post_end_date").alias("max_post_end_date"),
                ),
                unique_brand_names_value=F.col("unique_brand_names_text"),
                super_category_names_value=F.col("super_category_names_text"),
                offer_sku_count=F.col("offer_sku_count"),
                brand_sku_count=F.col("brand_sku_count"),
                offer_sales_amt_104w=F.col("offer_sales_amt_104w"),
                brand_sales_amt_104w=F.col("brand_sales_amt_104w"),
                brand_sku_group_fingerprint=F.col("brand_sku_group_fingerprint"),
                offer_sku_group_fingerprint=F.col("offer_sku_group_fingerprint"),
            ).alias("metadata"),
        )
    )

    logger.info(
        f"Built canonical campaign details summary for correlation_id={correlation_id}",
        log_type="publish_pipeline_summary",
    )

    campaign_details_metrics_df.unpersist()
    return canonical_summary_df
