from typing import Tuple

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from spark_pipeline.common.variables import Severity


def get_user_journey_metrics(user_journey_df: DataFrame, col_alias: str) -> Tuple[float, DataFrame]:
    """Compute journey metrics in a single aggregation pass.

    Args:
        user_journey_df: User journey DataFrame. Expected to contain ``booking_id``,
            ``userjourney_id``, ``channel_name``, ``subchannel_name``, ``loyalty_id``,
            ``transaction_key``, and ``net_sales_amt``.
        col_alias: Alias for the output journey collection column.

    Returns:
        Tuple of (total_sales: float, journey_agg: DataFrame).
            - total_sales: Sum of deduplicated transaction-level net sales
            - journey_agg: Single-row DataFrame with structured journey metrics
    """
    # net_sales_amt is stamped at transaction level; dedup at (journey, transaction) to count each once.
    deduplicated_transaction_sales = (
        user_journey_df
        .groupBy("userjourney_id", "transaction_key")
        .agg(F.first("net_sales_amt").alias("transaction_total_sales"))
    )

    sum_net_sales_by_journey_df = (
        deduplicated_transaction_sales
        .agg(F.sum("transaction_total_sales").alias("total"))
        .collect()[0]["total"] or 0.0
    )

    # Each subchannel the journey touched gets the full deduplicated journey total.
    journey_sales = (
        deduplicated_transaction_sales
        .groupBy("userjourney_id")
        .agg(F.sum("transaction_total_sales").alias("journey_total_sales"))
    )
    journey_channels = (
        user_journey_df
        .filter(F.col("subchannel_name").isNotNull() & (F.col("subchannel_name") != ""))
        .select("userjourney_id", "channel_name", "subchannel_name", "loyalty_id")
        .distinct()
    )
    joined = journey_channels.join(journey_sales, on="userjourney_id", how="left")

    # Deduplicate per (channel, subchannel, journey) so each journey total is counted once, not once per user.
    channel_totals = (
        joined
        .select("channel_name", "subchannel_name", "userjourney_id", "journey_total_sales")
        .distinct()
        .groupBy("channel_name", "subchannel_name")
        .agg(F.sum("journey_total_sales").alias("sum_exposed_sales"))
    )
    channel_loyalty = (
        joined
        .groupBy("channel_name", "subchannel_name")
        .agg(F.countDistinct("loyalty_id").alias("count_distinct_loyalty_ids"))
    )
    aggregate_user_journey_df = (
        channel_loyalty
        .join(channel_totals, on=["channel_name", "subchannel_name"], how="left")
        .agg(
            F.collect_list(
                F.struct(
                    F.col("channel_name"),
                    F.col("subchannel_name"),
                    F.col("count_distinct_loyalty_ids"),
                    F.col("sum_exposed_sales"),
                )
            ).alias(col_alias)
        )
    )
    return sum_net_sales_by_journey_df, aggregate_user_journey_df


def get_lift_details(df: DataFrame, journey_type: str, col_alias: str) -> DataFrame:
    aggregate_lift_details_df = (
        df
        .filter(F.lower(F.col("journey_type")) == F.lit(journey_type.lower()))
        .groupBy("channel_name", "subchannel_name")
        .agg(F.sum("normalized_weights").alias("sum_channel_weights"))
        .agg(
            F.collect_list(
                F.struct(
                    F.col("channel_name"),
                    F.col("subchannel_name"),
                    F.col("sum_channel_weights"),
                )
            ).alias(col_alias)
        )
    )
    return aggregate_lift_details_df


def mta_layer_summary(
    offer_adg_df: DataFrame,
    brand_adg_df: DataFrame,
    mta_result_df: DataFrame,
    sku_level_attributed_sales_offer_df: DataFrame,
    sku_level_attributed_sales_brand_df: DataFrame,
    correlation_id: str,
    severity: Severity = Severity.HIGH,
) -> DataFrame:
    """Produce a unified pipeline-summary for the MTA layer.

    Aggregates four metric sections into a single summary row:
    user journey (offer), user journey (brand), lift details (offer), and
    lift details (brand). Also includes total sales metadata for offer/brand
    user journeys and SKU-level attributed sales.

    Args:
        offer_adg_df: User journey DataFrame filtered to offer-level data.
            Expected to contain ``loyalty_id``, ``channel_name``, and
            ``net_sales_amt``.
        brand_adg_df: User journey DataFrame filtered to brand-level data.
            Expected to contain ``loyalty_id``, ``channel_name``, and
            ``net_sales_amt``.
        mta_result_df: Attribution Model Result DataFrame containing both offer
            and brand records.  Expected to contain ``journey_type``,
            ``channel_name``, ``subchannel_name``, and ``normalized_weights``.
            Filtered internally by ``journey_type``.
        sku_level_attributed_sales_offer_df: SKU-level attributed sales DataFrame
            for offer data. Expected to contain ``attributed_sales_amt``.
        sku_level_attributed_sales_brand_df: SKU-level attributed sales DataFrame
            for brand data. Expected to contain ``attributed_sales_amt``.
        correlation_id: Pipeline run correlation ID.
        severity: Alert severity level applied to all summaries
            (default ``Severity.HIGH``).

    Returns:
        Single-row DataFrame conforming to
        ``PipelineSummaryMetricsSchema.pipeline_summary_metric_schema``.
    """
    data_group = "mta_layer_summary"
    data_sources = "user_journey_offer,user_journey_brand,attribution_model_results,sku_level_attributed_sales_offer,sku_level_attributed_sales_brand"

    sum_attributed_sales_amt_sku_level_offer = (
        sku_level_attributed_sales_offer_df.agg(F.sum("attributed_sales_amt").alias("total")).collect()[0]["total"] or 0.0
    )
    sum_attributed_sales_amt_sku_level_brand = (
        sku_level_attributed_sales_brand_df.agg(F.sum("attributed_sales_amt").alias("total")).collect()[0]["total"] or 0.0
    )

    sum_net_sales_amt_user_journey_offer, offer_journey_agg = get_user_journey_metrics(offer_adg_df, "user_journey_offer")
    sum_net_sales_amt_user_journey_brand, brand_journey_agg = get_user_journey_metrics(brand_adg_df, "user_journey_brand")
    offer_lift_agg = get_lift_details(mta_result_df, "offer", "lift_details_offer")
    brand_lift_agg = get_lift_details(mta_result_df, "brand", "lift_details_brand")

    combined_df = (
        offer_journey_agg
        .crossJoin(brand_journey_agg)
        .crossJoin(offer_lift_agg)
        .crossJoin(brand_lift_agg)
    )

    return combined_df.select(
        F.lit(correlation_id).cast("string").alias("correlation_id"),
        F.lit(data_group).cast("string").alias("name"),
        F.lit(data_group).cast("string").alias("data_group"),
        F.lit(data_sources).cast("string").alias("data_sources"),
        F.lit(severity.value).cast("string").alias("severity"),
        F.to_json(F.struct(
            F.col("user_journey_offer"),
            F.col("user_journey_brand"),
            F.col("lift_details_offer"),
            F.col("lift_details_brand"),
            F.lit(sum_net_sales_amt_user_journey_offer).cast("double").alias("sum_net_sales_amt_user_journey_offer"),
            F.lit(sum_net_sales_amt_user_journey_brand).cast("double").alias("sum_net_sales_amt_user_journey_brand"),
            F.lit(sum_attributed_sales_amt_sku_level_offer).cast("double").alias("sum_attributed_sales_amt_sku_level_offer"),
            F.lit(sum_attributed_sales_amt_sku_level_brand).cast("double").alias("sum_attributed_sales_amt_sku_level_brand"),
        )).alias("metadata"),
        F.current_timestamp().cast("string").alias("load_timestamp"),
    )
