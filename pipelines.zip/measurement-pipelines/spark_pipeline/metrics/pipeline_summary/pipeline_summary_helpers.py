from functools import reduce

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql import types as T

from spark_pipeline.common.variables import Severity


def _union_all(*dfs: DataFrame) -> DataFrame:
    return reduce(DataFrame.unionByName, dfs)


def _finalize_summary_row(
    agg_df: DataFrame,
    metadata_col,
    correlation_id: str,
    data_group: str,
    source_name: str,
    severity: Severity,
) -> DataFrame:
    return agg_df.select(
        F.lit(correlation_id).cast(T.StringType()).alias("correlation_id"),
        F.concat_ws("_", F.lit(data_group), F.lit(source_name)).alias("name"),
        F.lit(data_group).cast(T.StringType()).alias("data_group"),
        F.lit(source_name).cast(T.StringType()).alias("data_sources"),
        F.lit(severity.value).cast(T.StringType()).alias("severity"),
        metadata_col.alias("metadata"),
        F.current_timestamp().cast(T.StringType()).alias("load_timestamp"),
    )
