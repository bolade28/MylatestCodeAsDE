from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from spark_pipeline.common.variables import PipelineSummaryMetricsConfig, Severity
from spark_pipeline.metrics.pipeline_summary.pipeline_summary_helpers import (
    _finalize_summary_row,
    _union_all,
)
from spark_pipeline.schemas.pipeline_summary import PipelineSummaryMetricsSchema


def get_features_overview(
    df: DataFrame,
    correlation_id: str,
    source_name: str,
    severity: Severity = Severity.HIGH,
    value_col: str = "metric_value",
) -> DataFrame:
    """Overview of all input variables to UCM.

    Produces a single summary row per source dataset, where ``metadata`` contains
    an array of per-variable aggregates (row_count and sum of ``value_col``)
    grouped by ``variable_cd`` and its marketing dimensions, with external
    variables filtered out for brevity.
    The ``name`` column is the upsert key and is constructed as
    ``{data_group}_{source_name}``.

    Expected source for this function is either the baseline modelling dataset
    or the feature-prioritisation output.

    Args:
        df: Input DataFrame containing at minimum the columns in
            ``_VARIABLE_GROUP_COLS`` plus ``value_col``.
        correlation_id: Pipeline run correlation ID written to
            ``correlation_id`` in the output.
        source_name: Human-readable label identifying which upstream
            dataset this summary represents, e.g.
            ``"baseline_modelling_dataset"`` or ``"feature_prioritisation"``.
        severity: Alert severity level (default ``Severity.HIGH``).
        value_col: Column to aggregate with ``SUM``; defaults to
            ``"metric_value"``.  Pass ``"variable_importance_rank"`` for
            the feature-prioritisation dataset.

    Returns:
        DataFrame conforming to
        ``PipelineSummaryMetricsSchema.pipeline_summary_metric_schema``.
    """
    agg_df = (
        df
        .filter(
            F.coalesce(F.upper(F.col("marketing_type_name")), F.lit(""))
            != F.lit(PipelineSummaryMetricsConfig.EXTERNAL_MARKETING_TYPE)
        )
        .groupBy(*PipelineSummaryMetricsConfig.VARIABLE_GROUP_COLS)
        .agg(
            F.count("*").alias("row_count"),
            F.sum(F.col(value_col)).alias("sum_metric_value"),
        )
        .agg(
            F.collect_list(
                F.struct(
                    *[F.col(c) for c in PipelineSummaryMetricsConfig.VARIABLE_GROUP_COLS],
                    F.col("row_count"),
                    F.col("sum_metric_value"),
                )
            ).alias("features_overview")
        )
    )

    data_group = "features_overview"
    metadata_struct = PipelineSummaryMetricsSchema.feature_overview_metadata_struct()
    return _finalize_summary_row(agg_df, metadata_struct, correlation_id, data_group, source_name, severity)


def get_incrementality_output_results(
    df: DataFrame,
    correlation_id: str,
    source_name: str,
    severity: Severity = Severity.HIGH,
) -> DataFrame:
    """Overview of UCM and Calibration outputs.

    Produces one summary row per ``unique_brand_name`` capturing key incrementality
    metrics from the calibration output as a JSON metadata payload:

    - total_ucm_booking_period_incrementality (ucm_incrementality)
    - total_calibrated_incrementality (calibrated_incrementality)
    - total_bypass_incrementality (bypass_incrementality)
    - total_during_incrementality (during_incrementality)
    - total_adjusted_calibrated_incrementality (adjusted_calibrated_incrementality)

    Expected source for this function is the calibration output DataFrame (incremental_shrinkage)


    Args:
        df: Calibration output DataFrame containing at minimum
            ``unique_brand_name``, ``metric_name``, and ``metric_value``.
        correlation_id: Pipeline run correlation ID.
        source_name: Human-readable label identifying the upstream dataset,
            e.g. ``"incremental_shrinkage"``.
        severity: Alert severity level (default ``Severity.HIGH``).

    Returns:
        DataFrame conforming to
        ``PipelineSummaryMetricsSchema.pipeline_summary_metric_schema``.
    """
    data_group = "incrementality_output_results"

    agg_df = (
        df
        .groupBy("unique_brand_name")
        .pivot("metric_name", PipelineSummaryMetricsConfig.INCREMENTALITY_METRIC_NAMES)
        .agg(F.sum("metric_value"))
    )

    metadata_struct = PipelineSummaryMetricsSchema.incrementality_output_metadata_struct()
    return _finalize_summary_row(agg_df, metadata_struct, correlation_id, data_group, source_name, severity)


def get_ucm_details(
    ucm_output_data_df: DataFrame,
    ucm_base_data_df: DataFrame,
    correlation_id: str,
    source_name: str,
    severity: Severity = Severity.HIGH,
) -> DataFrame:
    """Overview of UCM model quality metrics and hyperparameters.

    Produces a single summary row per run capturing model performance
    metrics (rsq, wsmape), hyperparameters (level, cycle, level_base),
    and the distinct set of features used, sourced from
    ``ucm_output_data_df`` (filtered to ``best_iteration == 'Y'``) and
    ``ucm_base_data_df``.

    Args:
        ucm_output_data_df: UCM output DataFrame containing ``best_iteration``,
            ``iteration``, ``rsq``, and ``wsmape`` columns.
        ucm_base_data_df: UCM base data DataFrame containing ``iteration``,
            ``variable``, and ``value`` columns.
        correlation_id: Pipeline run correlation ID.
        source_name: Human-readable label identifying the upstream dataset,
            e.g. ``"ucm_output"``.
        severity: Alert severity level (default ``Severity.HIGH``).

    Returns:
        DataFrame conforming to
        ``PipelineSummaryMetricsSchema.pipeline_summary_metric_schema``.
    """
    data_group = "ucm_details"

    filtered_output_df = ucm_output_data_df.filter(F.col("best_iteration") == F.lit("Y"))

    joined_df = (
        filtered_output_df.select("iteration")
        .distinct()
        .join(ucm_base_data_df, on="iteration", how="inner")
    )

    hyper_df = (
        joined_df
        .filter(F.col("variable").isin(PipelineSummaryMetricsConfig.UCM_HYPERPARAMETER_VARIABLES))
        .groupBy()
        .pivot("variable", PipelineSummaryMetricsConfig.UCM_HYPERPARAMETER_VARIABLES)
        # F.first() is safe: all rows share the same value per hyperparameter variable.
        .agg(F.first("value"))
    )

    features_df = (
        joined_df
        .filter(~F.col("variable").isin(PipelineSummaryMetricsConfig.UCM_HYPERPARAMETER_VARIABLES))
        .groupBy("variable")
        # F.first() is safe: all rows share the same value per feature variable.
        .agg(F.first("value").alias("value"))
        .agg(
            F.collect_list(F.struct(F.col("variable"), F.col("value"))).alias("distinct_features")
        )
    )

    metrics_df = filtered_output_df.agg(
        F.first("rsq").alias("rsq"),
        F.first("wsmape").alias("wsmape"),
        F.first("iteration").alias("iteration"),
    )

    combined_df = metrics_df.crossJoin(hyper_df).crossJoin(features_df)

    metadata_struct = PipelineSummaryMetricsSchema.ucm_details_metadata_struct()
    return _finalize_summary_row(combined_df, metadata_struct, correlation_id, data_group, source_name, severity)


def get_calibration_audit_details(
    df: DataFrame,
    correlation_id: str,
    source_name: str,
    severity: Severity = Severity.HIGH,
) -> DataFrame:
    """Overview of calibration audit parameters per marketing type.

    Produces a single summary row per run capturing all calibration audit
    parameters as a JSON metadata payload.  The full set of per-marketing-type
    records is collected into a list of structs under the ``calibration_details``
    key.

    Expected source for this function is the calibration audit DataFrame from
    ``baseline_modelling_shrinkage/incremental_shrinkage_helper.py``.

    Args:
        df: Calibration audit DataFrame containing at minimum
            ``marketing_type``, ``mean_log_uplift``, ``var_log_uplift``,
            ``count_campaigns``, ``distribution_type``, ``shift_parameter``,
            ``rev_similarity_percentile``, ``scaling_factor``,
            ``sample_median``, ``sample_mode``, ``z_score``, and
            ``channel_prior_failures``.
        correlation_id: Pipeline run correlation ID.
        source_name: Human-readable label identifying the upstream dataset,
            e.g. ``"calibration_audit"``.
        severity: Alert severity level (default ``Severity.HIGH``).

    Returns:
        DataFrame conforming to
        ``PipelineSummaryMetricsSchema.pipeline_summary_metric_schema``.
    """
    data_group = "calibration_details"

    agg_df = (
        df
        .select(*PipelineSummaryMetricsConfig.CALIBRATION_AUDIT_COLS)
        .agg(
            F.collect_list(
                F.struct(*[F.col(c) for c in PipelineSummaryMetricsConfig.CALIBRATION_AUDIT_COLS])
            ).alias("calibration_details")
        )
    )

    metadata_struct = PipelineSummaryMetricsSchema.calibration_details_metadata_struct()
    return _finalize_summary_row(agg_df, metadata_struct, correlation_id, data_group, source_name, severity)


def incrementality_layer_summary(
    modelling_df: DataFrame,
    fp_df: DataFrame,
    calibration_df: DataFrame,
    calibration_audit_df: DataFrame,
    ucm_output_data_df: DataFrame,
    ucm_base_data_df: DataFrame,
    correlation_id: str,
    severity: Severity = Severity.HIGH,
) -> DataFrame:
    """Produce a unified pipeline-summary for the incrementality layer.

    Calls :func:`get_features_overview` twice — once for the baseline
    modelling dataset and once for the feature-prioritisation output —
    then unions the results into a single DataFrame ready to be written
    to the ``pipeline_summary_metrics`` table.

    Args:
        modelling_df: Baseline modelling dataset DataFrame.  Expected to
            contain ``metric_value`` and all columns in
            ``_VARIABLE_GROUP_COLS``.
        fp_df: Feature-prioritisation output DataFrame.  Expected to
            contain ``variable_importance_rank`` and all columns in
            ``_VARIABLE_GROUP_COLS``.
        calibration_df: Calibration output DataFrame from incremental
            shrinkage. Expected to contain ``unique_brand_name``,
            ``metric_name``, and ``metric_value``.
        calibration_audit_df: Calibration audit DataFrame from
            ``incremental_shrinkage_helper``. Expected to contain
            ``marketing_type``, ``mean_log_uplift``, ``var_log_uplift``,
            ``count_campaigns``, ``distribution_type``, ``shift_parameter``,
            ``rev_similarity_percentile``, ``scaling_factor``,
            ``sample_median``, ``sample_mode``, ``z_score``, and
            ``channel_prior_failures``.
        ucm_output_data_df: UCM output DataFrame containing ``best_iteration``,
            ``iteration``, ``rsq``, and ``wsmape`` columns.
        ucm_base_data_df: UCM base data DataFrame containing ``iteration``,
            ``variable``, and ``value`` columns.
        correlation_id: Pipeline run correlation ID.
        severity: Alert severity level applied to both summaries
            (default ``Severity.HIGH``).

    Returns:
        Union of all summaries conforming to
        ``PipelineSummaryMetricsSchema.pipeline_summary_metric_schema``.
    """
    modelling_summary = get_features_overview(
        df=modelling_df,
        correlation_id=correlation_id,
        source_name="baseline_modelling_dataset",
        severity=severity,
        value_col="metric_value",
    )

    fp_summary = get_features_overview(
        df=fp_df,
        correlation_id=correlation_id,
        source_name="feature_prioritisation",
        severity=severity,
        value_col="variable_importance_rank",
    )

    incrementality_output_summary = get_incrementality_output_results(
        df=calibration_df,
        correlation_id=correlation_id,
        source_name="incremental_shrinkage",
        severity=severity,
    )

    ucm_details_summary = get_ucm_details(
        ucm_output_data_df=ucm_output_data_df,
        ucm_base_data_df=ucm_base_data_df,
        correlation_id=correlation_id,
        source_name="ucm_output",
        severity=severity,
    )

    calibration_details_summary = get_calibration_audit_details(
        df=calibration_audit_df,
        correlation_id=correlation_id,
        source_name="calibration_audit",
        severity=severity,
    )

    incrementality_summary_df = _union_all(
        modelling_summary,
        fp_summary,
        incrementality_output_summary,
        ucm_details_summary,
        calibration_details_summary,
    )
    return incrementality_summary_df
