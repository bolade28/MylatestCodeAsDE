"""
Helper utilities for MTA validation checks.
"""

from typing import Callable, List


def run_validation_check(
    logger,
    findings: List[str],
    check_name: str,
    check_func: Callable,
    **check_kwargs,
) -> int:
    """
    Helper to run a validation check with error handling.

    Catches exceptions, logs errors, and appends to findings list for
    downstream Slack notification.

    Args:
        logger: Logger instance for recording check execution.
        findings: List to accumulate error messages from failed checks.
        check_name: Human-readable name of the check (e.g., "Check 3: Channel Sales Ratio").
        check_func: The validation check function to execute.
        **check_kwargs: Keyword arguments to pass to check_func.

    Returns:
        Number of breaches detected by the check (0 if none or error occurred).
    """
    try:
        logger.info(
            f"Running {check_name}",
            log_type="mta_validation_metrics",
        )
        breach_count = check_func(**check_kwargs)
        logger.info(
            f"{check_name} complete: breach_count={breach_count}",
            log_type="mta_validation_metrics",
        )
        return breach_count
    except Exception as exc:
        msg = f"{check_name} raised an unexpected error: {exc}"
        logger.error(msg, log_type="mta_validation_metrics")
        findings.append(msg)
        return 0
