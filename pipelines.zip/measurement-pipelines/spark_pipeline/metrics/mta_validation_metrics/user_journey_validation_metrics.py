import json
from typing import Optional
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from spark_pipeline.common.variables import MtaValidationConfig, EventName, Severity
from spark_pipeline.metrics.utils.shared_helper import evaluate_brand_offer_sales
from spark_pipeline.schemas.mta_validation_metrics import MTAValidationMetrics
from spark_pipeline.schemas.user_journey import UserJourney
from spark_pipeline.utils.mta_events import MTAValidationMetricSchema
from spark_pipeline.utils.publish_metrics import MetricsPublisher


user_journey_validation_schema = MTAValidationMetrics.user_journey_validation_schema


def get_booking_id(user_journey_df: DataFrame) -> str:
    """
    Extract the booking_id from a user journey DataFrame.
    """
    return user_journey_df.select("booking_id").distinct().first()["booking_id"]


def threshold_msg(label: str, col_name: str, threshold: float, above: bool = False) -> F.Column:
    """
    Build a readable threshold-breach message as a Spark Column expression.
    """
    direction = "above maximum" if above else "below minimum"
    return F.concat_ws(
        "",
        F.lit(f"{label} ("),
        F.col(col_name).cast("string"),
        F.lit(f") is {direction} threshold of {threshold}"),
    )


def validate_conversion_ratios(
    min_converted: int,
    min_non_converted: int,
    min_ratio: float,
    max_ratio: float,
) -> F.Column:
    """
    Build the comment Column expression for channel conversion ratio warnings.

    Returns a chained ``F.when`` expression that produces a human-readable
    threshold-breach message for the first condition that fires:
    converted count, non-converted count, ratio below minimum, or ratio above maximum.

    Args:
        min_converted: Minimum acceptable number of distinct converted journeys per channel.
        min_non_converted: Minimum acceptable number of distinct non-converted journeys per channel.
        min_ratio: Minimum acceptable conversion ratio (converted / non_converted).
        max_ratio: Maximum acceptable conversion ratio.

    Returns:
        A Spark Column expression that evaluates to a warning message string, or ``NULL``
        if no threshold is breached.
    """
    conversion_ratios_df = (
        F.when(F.col('converted') < min_converted,
               threshold_msg('Converted journey count', 'converted', min_converted))
        .when(F.col('non_converted') < min_non_converted,
              threshold_msg('Non-converted journey count', 'non_converted', min_non_converted))
        .when(F.col('ratio') < min_ratio,
              threshold_msg('Conversion ratio', 'ratio', min_ratio))
        .when(F.col('ratio') > max_ratio,
              threshold_msg('Conversion ratio', 'ratio', max_ratio, above=True))
    )

    return conversion_ratios_df


def ratio_metadata_col(
    min_converted: int,
    min_non_converted: int,
    min_ratio: float,
    max_ratio: float,
) -> F.Column:
    """
    Build the metadata JSON Column expression for channel conversion ratio warnings.

    Returns a ``F.to_json`` Column containing ``min_threshold`` and ``max_threshold``
    keys. Values are populated based on which threshold was breached first:
    converted count, non-converted count, or ratio.

    Args:
        min_converted: Minimum acceptable number of distinct converted journeys per channel.
        min_non_converted: Minimum acceptable number of distinct non-converted journeys per channel.
        min_ratio: Minimum acceptable conversion ratio.
        max_ratio: Maximum acceptable conversion ratio.

    Returns:
        A Spark Column expression that evaluates to a JSON string with keys
        ``min_threshold`` and ``max_threshold``.
    """
    ratio_breach = (F.col('ratio') < min_ratio) | (F.col('ratio') > max_ratio)
    return F.to_json(F.create_map(
        F.lit('min_threshold'),
        F.when(F.col('converted') < min_converted, F.lit(str(float(min_converted))))
         .when(F.col('non_converted') < min_non_converted, F.lit(str(float(min_non_converted))))
         .when(ratio_breach, F.lit(str(min_ratio))),
        F.lit('max_threshold'),
        F.when(F.col('converted') < min_converted, F.lit(None).cast('string'))
         .when(F.col('non_converted') < min_non_converted, F.lit(None).cast('string'))
         .when(ratio_breach, F.lit(str(max_ratio))),
    ))


def ratio_value_col(min_converted: int, min_non_converted: int) -> F.Column:
    """
    Build the value Column expression for channel conversion ratio warnings.

    Returns the numeric value associated with the first breached threshold:
    the converted count, the non-converted count, or the ratio itself as a fallback.

    Args:
        min_converted: Minimum acceptable number of distinct converted journeys per channel.
        min_non_converted: Minimum acceptable number of distinct non-converted journeys per channel.

    Returns:
        A Spark Column expression that evaluates to a ``double`` breach value.
    """
    return (
        F.when(F.col('converted') < min_converted, F.col('converted').cast('double'))
         .when(F.col('non_converted') < min_non_converted, F.col('non_converted').cast('double'))
         .otherwise(F.col('ratio'))
    )


def warning_df(
    spark: SparkSession,
    booking_id: str,
    check_name: str,
    comment: str,
    metadata: str,
    value: float,
    channel_name: Optional[str] = None,
    severity: str = Severity.HIGH.value,
) -> DataFrame:
    """
    Create a single-row warning DataFrame conforming to ``user_journey_validation_schema``.

    Convenience wrapper used by checks that produce a scalar result (e.g. a campaign-level
    count) rather than a per-row distributed result.

    Args:
        spark: Active SparkSession used to construct the DataFrame.
        booking_id: Booking ID for the campaign being validated.
        check_name: Identifier of the validation check that raised the warning.
        comment: Human-readable description of the breach.
        metadata: JSON string containing supplementary threshold/value context.
        value: Numeric value that triggered the warning (e.g. the count or ratio).
        channel_name: Channel associated with the warning, or ``None`` for campaign-level checks.
        severity: Severity level string. Defaults to ``Severity.HIGH``.

    Returns:
        A one-row DataFrame conforming to ``user_journey_validation_schema``.
    """
    return spark.createDataFrame(
        [(booking_id, channel_name, severity, comment, metadata, check_name, value)],
        schema=user_journey_validation_schema,
    )


def select_warning_cols(
    df: DataFrame,
    check_name: str,
    comment_col: F.Column,
    metadata_col: F.Column,
    value_col: F.Column,
    booking_id_col: F.Column,
    severity: str = Severity.HIGH.value,
    channel_name_col: F.Column = None,
) -> DataFrame:
    """
    Attach standard warning columns to a DataFrame and return the validated output schema.

    Used by checks that produce a distributed per-row result (e.g. per-channel warnings).
    Adds ``booking_id``, ``channel_name``, ``severity``, ``comment``, ``metadata``,
    ``check_name``, and ``value`` via ``withColumns``, then selects and deduplicates.

    Args:
        df: Source DataFrame containing the breach rows to annotate.
        check_name: Identifier of the validation check that raised the warnings.
        comment_col: Spark Column expression producing the human-readable breach message.
        metadata_col: Spark Column expression producing a JSON metadata string.
        value_col: Spark Column expression producing the numeric breach value.
        booking_id_col: Spark Column expression for ``booking_id``
            (typically ``F.lit(booking_id)`` or ``F.col('booking_id')``).
        channel_name_col: Spark Column expression for ``channel_name``, or ``None``
            to emit ``NULL`` for campaign-level checks.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema`` with duplicate rows removed.
    """
    return (
        df
        .withColumns({
            'booking_id': booking_id_col,
            'channel_name': channel_name_col if channel_name_col is not None else F.lit(None).cast('string'),
            'severity': F.lit(severity),
            'comment': comment_col,
            'metadata': metadata_col,
            'check_name': F.lit(check_name),
            'value': value_col,
        })
        .select('booking_id', 'channel_name', 'severity', 'comment', 'metadata', 'check_name', 'value')
        .distinct()
    )


def check_num_converted_journeys(
    spark: SparkSession,
    booking_id: str,
    user_journey_df: DataFrame,
    min_threshold: int,
    severity: str = Severity.HIGH.value,
) -> DataFrame:
    """
    Check whether the number of converted journeys at MTA input meets a minimum threshold.

    Counts distinct ``loyalty_id`` values where ``isConversion == 1`` and compares the
    result against ``min_threshold``. A warning row is emitted when the count is at or
    below the threshold; otherwise an empty DataFrame is returned.

    Args:
        spark: Active SparkSession used to construct the output DataFrame.
        booking_id: Booking ID associated with the user journey data.
        user_journey_df: Input user journey DataFrame containing at least
            ``loyalty_id``, ``isConversion``, and ``booking_id`` columns.
        min_threshold: Minimum acceptable number of distinct converted journeys.
        severity: Severity level for this check. Defaults to ``Severity.HIGH``.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema``. Contains one
        warning row (with ``metadata.min_threshold``) if the count is at or below
        ``min_threshold``, otherwise an empty DataFrame.
    """
    num_converted_journeys = (
        user_journey_df
        .filter(F.col("isconversion") == 1)
        .select("loyalty_id")
        .distinct()
        .count()
    )
    if num_converted_journeys <= min_threshold:
        comment = (
            f"Number of converted journeys ({num_converted_journeys}) is at or below min_threshold."
        )
        return warning_df(
            spark, booking_id, "check_num_converted_journeys", comment,
            json.dumps({"min_threshold": str(min_threshold)}, separators=(',', ':')),
            float(num_converted_journeys),
            severity=severity,
        )

    return spark.createDataFrame([], schema=user_journey_validation_schema)


def check_channel_conversion_ratio(
    user_journey_df: DataFrame,
    booking_id: str,
    min_ratio: float = 0.001,
    max_ratio: float = 0.3,
    min_converted: int = 100,
    min_non_converted: int = 100,
    severity: str = Severity.HIGH.value,
) -> DataFrame:
    """
    Check per-channel conversion ratios and journey counts against configured thresholds.

    For each channel, counts distinct converted and non-converted journeys where that
    channel appears as a touchpoint, then computes ``converted / non_converted`` as the
    ratio. A warning row is emitted for any channel that breaches a count or ratio
    threshold.

    Args:
        user_journey_df: Input user journey DataFrame containing at least
            ``channel_name``, ``isconversion``, ``loyalty_id``, and ``booking_id``.
        booking_id: Booking ID associated with the user journey data.
        min_ratio: Minimum acceptable conversion ratio (converted / non_converted).
            Defaults to 0.001.
        max_ratio: Maximum acceptable conversion ratio. Defaults to 0.3.
        min_converted: Minimum acceptable number of distinct converted journeys per
            channel. Defaults to 100.
        min_non_converted: Minimum acceptable number of distinct non-converted journeys
            per channel. Defaults to 100.
        severity: Severity level for this check. Defaults to ``Severity.HIGH``.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema``. Contains one row
        per channel that breaches any threshold, with ``metadata`` keys
        ``min_threshold`` and ``max_threshold``. Returns an empty DataFrame if all
        channels are within bounds.
    """

    count_journey_conversion = (
        user_journey_df
        .filter(F.col("channel_name") != '')
        .groupBy("channel_name", "isconversion")
        .agg(F.countDistinct("loyalty_id").alias("count"))
        .groupBy("channel_name")
        .pivot("isconversion", [0, 1])
        .agg(F.first("count"))
        .withColumnRenamed('0', 'non_converted')
        .withColumnRenamed('1', 'converted')
        .fillna(0, subset=['converted', 'non_converted'])
        .withColumn(
            'ratio',
            F.when(F.col('non_converted') == 0, F.lit(None))
             .otherwise(F.col('converted') / F.col('non_converted')),
        )
    )

    breach_condition = (
        (F.col('converted') < min_converted)
        | (F.col('non_converted') < min_non_converted)
        | (F.col('ratio') < min_ratio)
        | (F.col('ratio') > max_ratio)
    )

    return select_warning_cols(
        count_journey_conversion.filter(breach_condition),
        'check_channel_conversion_ratio',
        validate_conversion_ratios(min_converted, min_non_converted, min_ratio, max_ratio),
        ratio_metadata_col(min_converted, min_non_converted, min_ratio, max_ratio),
        ratio_value_col(min_converted, min_non_converted),
        booking_id_col=F.lit(booking_id),
        severity=severity,
        channel_name_col=F.col('channel_name'),
    )


def check_multi_touchpoint_journeys(
    spark: SparkSession,
    user_journey_df: DataFrame,
    booking_id: str,
    min_multi_touchpoint_journeys: int,
    severity: str = Severity.MEDIUM.value,
) -> DataFrame:
    """
    Check that a sufficient number of journeys span multiple channels.

    This check is skipped when the campaign has only one active channel. Otherwise,
    it counts journeys that contain two or more distinct ``channel_name`` values and
    emits a warning if that count falls below ``min_multi_touchpoint_journeys``.

    Args:
    spark: Active SparkSession used to construct the output DataFrame.
        user_journey_df: Input user journey DataFrame containing at least
            ``channel_name`` and ``loyalty_id`` columns.
        booking_id: Booking ID associated with the user journey data.
        min_multi_touchpoint_journeys: Minimum number of journeys that must contain
            more than one channel. Defaults to 10.
        severity: Severity level for this check. Defaults to ``Severity.MEDIUM``.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema``. Contains one
        warning row with ``metadata`` keys ``min_threshold``, ``num_multi_touchpoint``,
        and ``num_active_channels`` if the threshold is not met. Returns an empty
        DataFrame if the campaign has one or fewer channels, or if the threshold is met.
    """
    num_active_channels = user_journey_df.select("channel_name").distinct().count()

    if num_active_channels <= 1:
        return spark.createDataFrame([], schema=user_journey_validation_schema)

    num_multi_touchpoint = (
        user_journey_df
        .groupBy("loyalty_id")
        .agg(F.countDistinct("channel_name").alias("num_channels"))
        .filter(F.col("num_channels") >= 2)
        .count()
    )

    if num_multi_touchpoint < min_multi_touchpoint_journeys:
        comment = (
            f"Only {num_multi_touchpoint} journeys contain more than one channel as a touchpoint, "
            f"which is below the minimum threshold of {min_multi_touchpoint_journeys}. "
            f"The campaign has {num_active_channels} active channels."
        )
        return warning_df(
            spark, booking_id, "check_multi_touchpoint_journeys", comment,
            json.dumps({
                "min_threshold": str(min_multi_touchpoint_journeys),
                "num_multi_touchpoint": str(num_multi_touchpoint),
                "num_active_channels": str(num_active_channels),
            }, separators=(',', ':')),
            float(num_multi_touchpoint),
            severity=severity,
        )

    return spark.createDataFrame([], schema=user_journey_validation_schema)


def check_duplicate_journeys(
    spark: SparkSession,
    user_journey_df: DataFrame,
    booking_id: str,
    severity: str = Severity.HIGH.value,
) -> DataFrame:
    """
    Check for exact duplicate rows in the user journey data.

    Groups all journey columns and flags any combination that appears more than once.
    Duplicates are defined as rows that are identical across all touchpoint and
    transaction fields (including ``loyalty_id``, ``transaction_key``, ``event_ts``,
    channel/subchannel/event names, and sales fields).

    Args:
        spark: Active SparkSession used to construct the empty output DataFrame.
        user_journey_df: Input user journey DataFrame. Must contain all columns
            listed in ``journey_cols`` inside the function.
        booking_id: Booking ID associated with the user journey data.
        severity: Severity level for this check. Defaults to ``Severity.HIGH``.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema``. Contains a single
        campaign-level summary warning row with ``metadata.duplicate_count`` when any
        exact duplicate rows are found. Returns an empty DataFrame if no duplicates are found.
    """
    _EXCLUDE_FROM_DEDUP = {'sub_path', 'rank', 'position', 'load_ts'}
    journey_cols = [
        field.name
        for field in UserJourney.UserJourneySchema.fields
        if field.name not in _EXCLUDE_FROM_DEDUP
    ]

    selected_df = user_journey_df.select(*journey_cols)

    duplicate_rows = (
        selected_df
        .groupBy(*journey_cols)
        .count()
        .filter(F.col('count') > 1)
    )

    if duplicate_rows.isEmpty():
        return spark.createDataFrame([], schema=user_journey_validation_schema)

    duplicate_count = float(
        duplicate_rows
        .agg(F.sum(F.col('count') - 1).alias('excess_rows'))
        .first()['excess_rows']
    )

    comment = f"Duplicate user journeys detected: {int(duplicate_count)} duplicate rows found."

    return warning_df(
        spark, booking_id, 'check_duplicate_journeys', comment,
        json.dumps({'duplicate_count': str(int(duplicate_count))}, separators=(',', ':')),
        duplicate_count,
        severity=severity,
    )


def check_channel_cooccurrence(
    spark: SparkSession,
    user_journey_df: DataFrame,
    booking_id: str,
    threshold: float = 0.9,
    severity: str = Severity.MEDIUM.value,
) -> DataFrame:
    """
    Detect channel combinations that appear together in an unusually high proportion of journeys.

    Computes the distinct set of channels present in each journey (its "channel combo"),
    then flags any combo that appears in more than ``threshold`` of all journeys. A high
    co-occurrence rate can legitimately arise in full-store instore campaigns but may
    otherwise indicate a data quality issue.

    Args:
        spark: Active SparkSession used to construct empty output DataFrames.
        user_journey_df: Input user journey DataFrame containing at least
            ``userjourney_id`` and ``channel_name`` columns.
        booking_id: Booking ID associated with the user journey data.
        threshold: Proportion of journeys (0–1) above which a channel combination
            triggers a warning. Defaults to 0.9.
        severity: Severity level for this check. Defaults to ``Severity.MEDIUM``.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema``. Contains one
        row per offending channel combination with ``metadata`` keys ``channel_combo``,
        ``journey_count``, and ``journey_pct``. Returns an empty DataFrame if no
        combination exceeds the threshold, or if there are no journeys.
    """
    total_journeys = user_journey_df.select('userjourney_id').distinct().count()

    if total_journeys == 0:
        return spark.createDataFrame([], schema=user_journey_validation_schema)

    # Collect all distinct channels per journey, then sort and stringify to get a
    # canonical representation of each channel combination.
    channel_combos = (
        user_journey_df
        .groupBy('userjourney_id')
        .agg(F.sort_array(F.collect_set('channel_name')).alias('channel_combo'))
    )

    combo_counts = (
        channel_combos
        .groupBy('channel_combo')
        .agg(
            F.count('*').alias('journey_count'),
            (F.count('*') / total_journeys).alias('journey_pct'),
        )
        .filter(F.col('journey_pct') > threshold)
        .cache()
    )

    if combo_counts.isEmpty():
        combo_counts.unpersist()
        return spark.createDataFrame([], schema=user_journey_validation_schema)

    comment = (
        f"Channel combination appears in more than {int(threshold * 100)}% of journeys. "
        f"Verify this is expected (e.g. full-store instore campaign)."
    )

    result = select_warning_cols(
        combo_counts,
        'check_channel_cooccurrence',
        F.lit(comment),
        F.to_json(F.create_map(
            F.lit('channel_combo'), F.col('channel_combo').cast('string'),
            F.lit('journey_count'), F.col('journey_count').cast('string'),
            F.lit('journey_pct'), F.col('journey_pct').cast('string'),
        )),
        F.col('journey_pct').cast('double'),
        booking_id_col=F.lit(booking_id),
        severity=severity,
    )
    combo_counts.unpersist()
    return result


def check_invalid_touchpoint_names(
    spark: SparkSession,
    user_journey_df: DataFrame,
    booking_id: str,
    severity: str = Severity.HIGH.value,
) -> DataFrame:
    """
    Detect touchpoints with null, empty, or placeholder names in key dimension columns.

    Based on the event_name, checks ``channel_name``, ``subchannel_name`` for values that
    are ``NULL``, blank after trimming, or equal to ``'NA'`` (case-insensitive). Any
    such value indicates incomplete or unparsed taxonomy data.

    Args:
        spark: Active SparkSession used to construct empty output DataFrames.
        user_journey_df: Input user journey DataFrame containing at least
            ``userjourney_id``, ``channel_name``, ``subchannel_name``, and
            ``event_name`` columns.
        booking_id: Booking ID associated with the user journey data.
        severity: Severity level for this check. Defaults to ``Severity.HIGH``.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema``. Contains a single
        campaign-level summary warning row with ``metadata.invalid_count`` when any invalid
        touchpoint names or ``isconversion`` values are detected; otherwise returns an empty DataFrame.
    """
    def _is_invalid(col_name: str) -> F.Column:
        return (
            F.col(col_name).isNull()
            | (F.trim(F.col(col_name)) == '')
            | (F.upper(F.col(col_name)) == 'NA')
        )

    invalid_name_condition = (
        (F.lower(F.col('event_name')) == EventName.TOUCHPOINT.value)
        & (_is_invalid('channel_name') | _is_invalid('subchannel_name'))
    )
    invalid_isconversion_condition = ~F.col('isconversion').isin(0, 1)

    invalid_df = user_journey_df.filter(invalid_name_condition | invalid_isconversion_condition)

    if invalid_df.isEmpty():
        return spark.createDataFrame([], schema=user_journey_validation_schema)

    invalid_count = float(invalid_df.count())
    comment = f"Invalid touchpoint data detected: {int(invalid_count)} rows with invalid channel_name, subchannel_name, or isconversion."

    return warning_df(
        spark, booking_id, 'check_invalid_touchpoint_names', comment,
        json.dumps({'invalid_count': str(int(invalid_count))}, separators=(',', ':')),
        invalid_count,
        severity=severity,
    )


def check_channel_sales(
    spark: SparkSession,
    user_journey_df: DataFrame,
    booking_id: str,
    low_sales_threshold: float = 100.0,
    severity: str = Severity.HIGH.value,
) -> DataFrame:
    """
    Check that each channel is associated with a meaningful volume of converted sales.

    For every channel, sums ``net_sales_amt`` across all converted journeys
    (``isconversion == True``) in which that channel appears. Channels at or below
    ``low_sales_threshold`` are flagged as a high-severity data quality issue, since
    zero or near-zero sales can indicate missing conversion linkage.

    Args:
        spark: Active SparkSession used to construct empty output DataFrames.
        user_journey_df: Input user journey DataFrame containing at least
            ``userjourney_id``, ``channel_name``, ``isconversion``, and
            ``net_sales_amt`` columns.
        booking_id: Booking ID associated with the user journey data.
        low_sales_threshold: Maximum total sales (inclusive) below which a channel
            is flagged. Defaults to 100.0.
        severity: Severity level for this check. Defaults to ``Severity.HIGH``.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema``. Contains one
        row per flagged channel with ``metadata`` keys ``total_sales`` and
        ``low_sales_threshold``. Returns an empty DataFrame if all channels are above
        the threshold.
    """
    converted_journey_ids = (
        user_journey_df
        .filter(F.col('isconversion') == 1)
        .select('userjourney_id')
        .distinct()
    )

    # One row per journey: sum net_sales_amt for converted journeys only
    journey_sales = (
        user_journey_df
        .join(converted_journey_ids, on='userjourney_id', how='inner')
        .filter(F.col('isconversion') == 1)
        .select('userjourney_id', 'channel_name', 'net_sales_amt')
        .distinct()
    )

    channel_sales = (
        journey_sales
        .groupBy('channel_name')
        .agg(F.sum('net_sales_amt').alias('total_sales'))
        .filter(F.col('total_sales') <= low_sales_threshold)
    )

    if channel_sales.isEmpty():
        return spark.createDataFrame([], schema=user_journey_validation_schema)

    comment = (
        f"Channel has zero or very low total sales (<= {low_sales_threshold}) "
        f"across all converted user journeys. High severity data quality issue."
    )

    return select_warning_cols(
        channel_sales,
        'check_channel_sales',
        F.lit(comment),
        F.to_json(F.create_map(
            F.lit('total_sales'), F.col('total_sales').cast('string'),
            F.lit('low_sales_threshold'), F.lit(str(low_sales_threshold)),
        )),
        F.col('total_sales').cast('double'),
        booking_id_col=F.lit(booking_id),
        channel_name_col=F.col('channel_name'),
        severity=severity,
    )


def check_subchannel_consistency_across_sources(
    spark: SparkSession,
    user_journey_df: DataFrame,
    unified_campaign_df: DataFrame,
    reporting_df: DataFrame,
    booking_id: str,
    severity: str = Severity.HIGH.value,
) -> DataFrame:
    """
    Check that subchannels are consistent across the unified campaign, user journeys, and reporting.

    Args:
        spark: Active SparkSession used to construct empty output DataFrames.
        user_journey_df: Input user journey DataFrame containing at least
            ``channel_name``, ``subchannel_name``, ``event_name``, and ``isconversion``
            columns.
        unified_campaign_df: Unified campaign DataFrame (Pollen booking metadata)
            containing at least ``job_bag_number``, ``channel_name``, and
            ``subchannel_name`` columns.
        reporting_df: Measurement campaign reporting DataFrame containing at least
            ``booking_id``, ``channel_name``, and ``subchannel_name`` columns.
        booking_id: Booking ID associated with the user journey data.
        severity: Severity level for this check. Defaults to ``Severity.HIGH``.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema``. Contains one row
        per channel whose subchannel sets differ across sources, with ``metadata`` keys
        ``booking_subchannels``, ``journey_subchannels``, and ``reporting_subchannels``
        each holding the sorted list of subchannels from that source. Returns an empty
        DataFrame if all three sources agree on every channel.
    """
    booked_subchannels = (
        unified_campaign_df
        .filter(F.col('job_bag_number') == booking_id)
        .select(
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.lit(True).alias('in_booking'),
        )
        .distinct()
    )

    journey_subchannels = (
        user_journey_df
        .filter(
            (F.lower(F.col('event_name')) == EventName.TOUCHPOINT.value)
            & (F.col('isconversion') == 1)
        )
        .select(
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.lit(True).alias('in_journeys'),
        )
        .distinct()
    )

    reporting_subchannels = (
        reporting_df
        .filter(F.col('booking_id') == booking_id)
        .select(
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.lit(True).alias('in_reporting'),
        )
        .distinct()
    )

    all_subchannels = (
        booked_subchannels
        .join(journey_subchannels, on=['channel_name', 'subchannel_name'], how='full')
        .join(reporting_subchannels, on=['channel_name', 'subchannel_name'], how='full')
        .select(
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.coalesce(F.col('in_booking'), F.lit(False)).alias('in_booking'),
            F.coalesce(F.col('in_journeys'), F.lit(False)).alias('in_journeys'),
            F.coalesce(F.col('in_reporting'), F.lit(False)).alias('in_reporting'),
        )
    )

    # Aggregate per channel: collect the subchannel set present in each source,
    # then flag channels where the three sets differ.
    channel_summary = (
        all_subchannels
        .groupBy('channel_name')
        .agg(
            F.sort_array(
                F.collect_set(F.when(F.col('in_booking'), F.col('subchannel_name')))
            ).alias('booking_subchannel_name'),
            F.sort_array(
                F.collect_set(F.when(F.col('in_journeys'), F.col('subchannel_name')))
            ).alias('journey_subchannel_name'),
            F.sort_array(
                F.collect_set(F.when(F.col('in_reporting'), F.col('subchannel_name')))
            ).alias('reporting_subchannel_name'),
        )
        .filter(
            (F.col('booking_subchannel_name') != F.col('journey_subchannel_name'))
            | (F.col('booking_subchannel_name') != F.col('reporting_subchannel_name'))
        )
    )

    if channel_summary.isEmpty():
        return spark.createDataFrame([], schema=user_journey_validation_schema)

    return select_warning_cols(
        channel_summary,
        'check_subchannel_consistency_across_sources',
        F.concat_ws(
            '',
            F.lit('Subchannel mismatch detected for channel ('),
            F.col('channel_name'),
            F.lit('): subchannels do not match across booking, journeys, and reporting.'),
        ),
        F.to_json(F.create_map(
            F.lit('booking_subchannels'), F.col('booking_subchannel_name'),
            F.lit('journey_subchannels'), F.col('journey_subchannel_name'),
            F.lit('reporting_subchannels'), F.col('reporting_subchannel_name'),
        )),
        F.lit(0.0).cast('double'),
        booking_id_col=F.lit(booking_id),
        channel_name_col=F.col('channel_name'),
        severity=severity,
    )


def check_input_output_sales_match(
    spark: SparkSession,
    user_journey_df: DataFrame,
    reporting_df: DataFrame,
    booking_id: str,
    journey_type: str,
    severity: str = Severity.HIGH.value,
) -> DataFrame:
    """
    Check that total converted sales in MTA input (user journeys) match MTA output (reporting).
    Args:
        spark: Active SparkSession used to construct the output DataFrame.
        user_journey_df: MTA input user journey DataFrame containing at least
            ``isconversion`` and ``net_sales_amt`` columns.
        reporting_df: Measurement campaign reporting DataFrame containing
            at least ``booking_id``, ``journey_type``, and ``attributed_sales_amt`` columns.
        booking_id: Booking ID associated with the user journey data.
        journey_type: Journey type to filter the reporting DataFrame (``'brand'`` or
            ``'offer'``).
        severity: Severity level for this check. Defaults to ``Severity.HIGH``.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema``. Contains one
        warning row with ``metadata`` keys ``journey_type``, ``input_sales`` and
        ``output_sales`` when the totals differ. Returns an empty DataFrame if they match.
    """
    input_sales = float(
        user_journey_df
        .filter(F.col('isconversion') == 1)
        .agg(F.sum('net_sales_amt'))
        .first()[0] or 0
    )
    output_sales = float(
        reporting_df
        .filter(
            (F.col('booking_id') == booking_id)
            & (F.lower(F.col('journey_type')) == journey_type.lower())
        )
        .agg(F.sum('attributed_sales_amt'))
        .first()[0] or 0
    )

    if input_sales == 0:
        return warning_df(
            spark, booking_id, 'check_input_output_sales_match',
            f"MTA input total converted sales (net_sales_amt) is zero for {journey_type} journeys.",
            json.dumps({'journey_type': journey_type, 'input_sales': '0.0', 'output_sales': str(output_sales)}, separators=(',', ':')),
            0.0,
            severity=severity,
        )

    if output_sales == 0:
        return warning_df(
            spark, booking_id, 'check_input_output_sales_match',
            f"MTA output total sales (attributed_sales_amt) is zero for {journey_type} journeys.",
            json.dumps({'journey_type': journey_type, 'input_sales': str(input_sales), 'output_sales': '0.0'}, separators=(',', ':')),
            0.0,
            severity=severity,
        )

    if input_sales == output_sales:
        return spark.createDataFrame([], schema=user_journey_validation_schema)

    comment = (
        f"Total converted sales mismatch for {journey_type} journeys: "
        f"MTA input (net_sales_amt) = {input_sales}, "
        f"MTA output (attributed_sales_amt) = {output_sales}."
    )
    return warning_df(
        spark, booking_id, 'check_input_output_sales_match', comment,
        json.dumps({
            'journey_type': journey_type,
            'input_sales': str(input_sales),
            'output_sales': str(output_sales),
        }, separators=(',', ':')),
        abs(input_sales - output_sales),
        severity=severity,
    )


def get_journey_sales_comparison(
    brand_journey_df: DataFrame,
    offer_journey_df: DataFrame,
) -> DataFrame:
    """
    Return one unrounded brand/offer total comparison for campaign journeys.

    Each input requires net_sales_amt and must already have its journey scope.
    Empty/null-only sales sum to zero. Output has brand_sales, offer_sales,
    offer_exceeds_brand and sales_equal; this function performs no actions.
    """
    brand_totals = brand_journey_df.agg(
        F.coalesce(F.sum(F.col("net_sales_amt")).cast("double"), F.lit(0.0)).alias("brand_sales"),
    )
    offer_totals = offer_journey_df.agg(
        F.coalesce(F.sum(F.col("net_sales_amt")).cast("double"), F.lit(0.0)).alias("offer_sales"),
    )
    return evaluate_brand_offer_sales(brand_totals.crossJoin(F.broadcast(offer_totals)))


def get_journey_skus(
    journey_df: DataFrame,
    unified_campaign_df: DataFrame,
    booking_id: str,
) -> DataFrame:
    """
    Return distinct nonempty SKUs for a booking's journey channels.

    Journey input requires channel_name; campaign input requires job_bag_number,
    channel_name and comma-separated item_cd_list. Unicode whitespace is removed
    around SKU values; null lists and empty tokens contribute no SKUs.
    """
    channels = journey_df.select(F.col("channel_name")).distinct()
    booking_items = unified_campaign_df.filter(F.col("job_bag_number") == booking_id)
    matching_items = booking_items.join(channels, on="channel_name", how="left_semi")
    campaign_items = (
        matching_items
        .select(F.col("item_cd_list"))
    )
    sku_rows = campaign_items.select(F.explode(F.split(F.col("item_cd_list"), ",")).alias("sku"))
    normalized_skus = sku_rows.withColumn("sku", F.regexp_replace(F.col("sku"), r"(?U)^\s+|\s+$", ""))
    return (
        normalized_skus
        .filter(F.col("sku").isNotNull() & (F.col("sku") != ""))
        .distinct()
    )


def get_brand_offer_sku_differences(
    brand_journey_df: DataFrame,
    offer_journey_df: DataFrame,
    unified_campaign_df: DataFrame,
    booking_id: str,
) -> DataFrame:
    """
    Return sku/journey_type rows present in only one journey's booking SKU set.

    Inputs follow get_journey_skus. Set difference uses distributed anti joins;
    an empty result means equal sets. No channel or SKU lists are collected.
    """
    brand_skus = get_journey_skus(brand_journey_df, unified_campaign_df, booking_id)
    offer_skus = get_journey_skus(offer_journey_df, unified_campaign_df, booking_id)
    brand_difference = brand_skus.join(offer_skus, on="sku", how="left_anti")
    offer_difference = offer_skus.join(brand_skus, on="sku", how="left_anti")
    brand_only = brand_difference.withColumn("journey_type", F.lit("brand"))
    offer_only = offer_difference.withColumn("journey_type", F.lit("offer"))
    return brand_only.unionByName(offer_only)


def check_brand_vs_offer_sales(
    spark: SparkSession,
    brand_journey_df: DataFrame,
    offer_journey_df: DataFrame,
    unified_campaign_df: DataFrame,
    booking_id: str,
    severity: str = Severity.HIGH.value,
) -> DataFrame:
    """
    Check that offer sales do not exceed brand sales, and that equal sales share the same SKUs.

    Sums ``net_sales_amt`` across all rows in each journey DataFrame. Two scenarios
    trigger a warning:

    * **Offer > Brand**: offer sales exceed brand sales, which is unexpected since
      brand sales should always be greater than or equal to offer sales.
    * **Brand == Offer with differing SKUs**: equal totals are only acceptable when
      both journey types share the same set of SKUs. SKUs are resolved from
      ``unified_campaign_df`` by matching each journey type's channel names against
      the ``item_cd_list`` (comma-separated) in the unified campaign.

    Args:
        spark: Active SparkSession used to construct the output DataFrame.
        brand_journey_df: DataFrame containing brand journeys only. Must include
            ``net_sales_amt`` and ``channel_name`` columns.
        offer_journey_df: DataFrame containing offer journeys only. Must include
            ``net_sales_amt`` and ``channel_name`` columns.
        unified_campaign_df: Unified campaign DataFrame containing ``job_bag_number``,
            ``channel_name``, and ``item_cd_list`` (comma-separated SKU string) columns.
        booking_id: Booking ID associated with the user journey data.
        severity: Severity level for this check. Defaults to ``Severity.HIGH``.

    Returns:
        A DataFrame conforming to ``user_journey_validation_schema``. Contains one
        summary warning row with ``metadata`` keys ``brand_sales`` and ``offer_sales``
        when offer exceeds brand, or when sales are equal but SKU sets differ.
        Returns an empty DataFrame otherwise.
    """
    comparison = get_journey_sales_comparison(brand_journey_df, offer_journey_df).first()
    brand_sales = comparison["brand_sales"]
    offer_sales = comparison["offer_sales"]

    if comparison["offer_exceeds_brand"]:
        comment = (
            f"Offer sales ({offer_sales}) are higher than brand sales ({brand_sales}). "
            f"Brand sales should always be greater than or equal to offer sales; "
            f"this may indicate a data quality issue."
        )
        return warning_df(
            spark, booking_id, "check_brand_vs_offer_sales", comment,
            json.dumps({'brand_sales': str(brand_sales), 'offer_sales': str(offer_sales)}, separators=(',', ':')),
            offer_sales,
            severity=severity,
        )

    if comparison["sales_equal"]:
        differences = get_brand_offer_sku_differences(
            brand_journey_df, offer_journey_df, unified_campaign_df, booking_id,
        )
        sample_size = 10
        brand_only = [row["sku"] for row in (
            differences
            .filter(F.col("journey_type") == "brand")
            .orderBy(F.col("sku").asc_nulls_last())
            .limit(sample_size)
            .collect()
        )]
        offer_only = [row["sku"] for row in (
            differences
            .filter(F.col("journey_type") == "offer")
            .orderBy(F.col("sku").asc_nulls_last())
            .limit(sample_size)
            .collect()
        )]
        if not brand_only and not offer_only:
            return spark.createDataFrame([], schema=user_journey_validation_schema)
        comment = (
            f"Brand sales equal offer sales ({brand_sales}) but the SKU sets differ. "
            f"Brand-only SKUs (sample): {brand_only}. "
            f"Offer-only SKUs (sample): {offer_only}."
        )
        return warning_df(
            spark, booking_id, "check_brand_vs_offer_sales", comment,
            json.dumps({'brand_sales': str(brand_sales), 'offer_sales': str(offer_sales)}, separators=(',', ':')),
            offer_sales,
            severity=severity,
        )

    return spark.createDataFrame([], schema=user_journey_validation_schema)


def user_journey_validation_metric(
    brand_journey_df: DataFrame,
    offer_journey_df: DataFrame,
    unified_campaign_df: DataFrame,
    spark: SparkSession,
    reporting_df: DataFrame,
) -> DataFrame:
    """
    Run all user journey validation checks and return a single combined warnings DataFrame.

    Args:
        brand_journey_df: Brand-only journey DataFrame (``journey_type == 'brand'``).
        offer_journey_df: Offer-only journey DataFrame (``journey_type == 'offer'``).
        unified_campaign_df: Unified campaign DataFrame used for channel/subchannel
            validation and SKU lookup. Must include ``job_bag_number``, ``channel_name``,
            ``subchannel_name``, and ``item_cd_list`` columns.
        spark: Active SparkSession passed to every check function.
        reporting_df: Measurement campaign reporting DataFrame containing both
            brand and offer rows. When provided, subchannel consistency is checked
            across unified campaign, user journeys, and reporting for each journey type.
            Must include ``booking_id``, ``journey_type``, ``channel_name``, and
            ``subchannel_name`` columns.

    Returns:
        A single DataFrame conforming to ``user_journey_validation_schema`` containing
        the union of all warning rows produced by every check. Returns an empty
        DataFrame if no checks raise warnings.
    """
    # offer and brand have the same booking_id
    booking_id = get_booking_id(offer_journey_df)

    def _checks_for(journey_df: DataFrame, journey_type: str) -> DataFrame:
        checks = (
            check_num_converted_journeys(
                spark, booking_id, journey_df,
                MtaValidationConfig.MIN_THRESHOLD_FOR_CONVERTED_JOURNEYS,
                severity=Severity.HIGH.value,
            )
            .unionByName(check_channel_conversion_ratio(
                journey_df, booking_id,
                min_ratio=MtaValidationConfig.MIN_RATIO_FOR_JOURNEY_CONVERSION,
                max_ratio=MtaValidationConfig.MAX_RATIO_FOR_JOURNEY_CONVERSION,
                min_converted=MtaValidationConfig.MIN_CONVERTED_JOURNEYS,
                min_non_converted=MtaValidationConfig.MIN_NON_CONVERTED_JOURNEYS,
                severity=Severity.HIGH.value,
            ))
            .unionByName(check_multi_touchpoint_journeys(
                spark, journey_df, booking_id,
                min_multi_touchpoint_journeys=MtaValidationConfig.MIN_MULTI_TOUCHPOINT_JOURNEYS,
                severity=Severity.MEDIUM.value,
            ))
            .unionByName(check_duplicate_journeys(
                spark, journey_df, booking_id,
                severity=Severity.HIGH.value,
            ))
            .unionByName(check_channel_cooccurrence(
                spark, journey_df, booking_id,
                threshold=MtaValidationConfig.CHANNEL_COMBINATION_FREQUENCY_THRESHOLD,
                severity=Severity.MEDIUM.value,
            ))
            .unionByName(check_invalid_touchpoint_names(
                spark, journey_df, booking_id,
                severity=Severity.HIGH.value,
            ))
            .unionByName(check_channel_sales(
                spark, journey_df, booking_id,
                low_sales_threshold=MtaValidationConfig.LOW_SALES_THRESHOLD,
                severity=Severity.HIGH.value,
            ))
            .unionByName(check_subchannel_consistency_across_sources(
                spark, journey_df, unified_campaign_df,
                reporting_df.filter(F.lower(F.col('journey_type')) == journey_type.lower()),
                booking_id,
                severity=Severity.HIGH.value,
            ))
            .unionByName(check_input_output_sales_match(
                spark, journey_df, reporting_df, booking_id, journey_type,
                severity=Severity.HIGH.value,
            ))
        )
        return checks

    return (
        _checks_for(brand_journey_df, 'brand')
        .unionByName(_checks_for(offer_journey_df, 'offer'))
        .unionByName(check_brand_vs_offer_sales(
            spark, brand_journey_df, offer_journey_df, unified_campaign_df, booking_id,
            severity=Severity.HIGH.value,
        ))
    )


def publish_user_journey_validation_metric(
    brand_journey_df: DataFrame,
    offer_journey_df: DataFrame,
    unified_campaign_df: DataFrame,
    correlation_id: str,
    metrics_topic_arn: str,
    spark: SparkSession,
    reporting_df: DataFrame,
) -> int:
    """
    Run all user journey validation checks and publish each warning to SNS for Grafana.

    Executes every individual check against both brand and offer journey DataFrames
    separately, unions the results, then publishes one ``MTAValidationMetricSchema``
    event per warning row via ``MetricsPublisher``. ``check_brand_vs_offer_sales`` is
    the only check that receives both DataFrames simultaneously. When ``reporting_df``
    is provided, ``check_subchannel_consistency_across_sources`` is also run for each
    journey type, filtering by ``journey_type``.

    Args:
        brand_journey_df: Brand-only journey DataFrame (``journey_type == 'brand'``).
        offer_journey_df: Offer-only journey DataFrame (``journey_type == 'offer'``).
        unified_campaign_df: Unified campaign DataFrame used for channel/subchannel
            validation and SKU lookup. Must include ``job_bag_number``, ``channel_name``,
            ``subchannel_name``, and ``item_cd_list`` columns.
        correlation_id: Correlation ID for tracing the pipeline run.
        metrics_topic_arn: ARN of the SNS topic to publish metrics to.
        spark: Active SparkSession.
        reporting_df: Measurement campaign reporting DataFrame containing both
            brand and offer rows. When provided, subchannel consistency is checked across
            unified campaign, user journeys, and reporting for each journey type. Must
            include ``booking_id``, ``journey_type``, ``channel_name``, and
            ``subchannel_name`` columns.

    Returns:
        Number of warning events published to SNS.
    """
    brand_journey_df.cache()
    offer_journey_df.cache()
    try:
        warnings_df = user_journey_validation_metric(
            brand_journey_df, offer_journey_df, unified_campaign_df, spark,
            reporting_df=reporting_df,
        )
        warning_rows = warnings_df.collect()
        breach_count = len(warning_rows)

        if warning_rows:
            publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

            for row in warning_rows:
                metadata_str = row['metadata'] if row['metadata'] else '{}'
                unique_name = (
                    f"{row['check_name']}"
                    f"|{row['booking_id']}"
                    f"|{row['channel_name'] or 'all'}"
                )
                event = MTAValidationMetricSchema(
                    correlation_id=correlation_id,
                    name=unique_name,
                    type="user_journey_validation",
                    severity=row['severity'],
                    comment=row['comment'],
                    value=str(row['value']),
                    metadata=metadata_str,
                    channel_name=row['channel_name'],
                )
                publisher.publish_event(
                    message_subject=MtaValidationConfig.MESSAGE_SUBJECT + " User Journey Validation Warning Detected.",
                    event=event,
                )
    finally:
        brand_journey_df.unpersist()
        offer_journey_df.unpersist()
    return breach_count
