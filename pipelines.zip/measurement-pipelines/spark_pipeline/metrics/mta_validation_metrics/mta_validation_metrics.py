import json

from typing import List
from pyspark.sql import DataFrame, functions as F
from pyspark.sql.window import Window
from spark_pipeline.common.variables import (
    ConversionRateThresholdsConfig,
    ChannelSalesRatioConfig,
    LowMediaSpendConfig,
    MtaValidationConfig,
    RecalibrationFactorsConfig,
    Severity,
    IncrementalSalesIROASConfig,
)
from spark_pipeline.metrics.utils.shared_helper import (
    ThresholdBounds,
    calculate_iroas,
    evaluate_conversion_rate_thresholds,
    evaluate_expected_value,
    evaluate_incremental_sales,
    evaluate_iroas_thresholds,
    get_threshold_violations,
    safe_ratio,
)
from spark_pipeline.utils.mta_events import MTAValidationMetricSchema
from spark_pipeline.utils.publish_metrics import MetricsPublisher


def publish_mta_validation_metrics(
    measurement_campaign_reporting_df: DataFrame,
    correlation_id: str,
    metrics_topic_arn: str,
) -> int:
    """
    Publishes MTA validation metrics after validating conversion rate thresholds.

    Validates conversion rates after data is loaded but before the metrics are published,
    to catch any breaches early in the pipeline.

    Args:
        measurement_campaign_reporting_df: DataFrame containing campaign reporting data with conversion rates.
        correlation_id: The correlation ID for the run.
        metrics_topic_arn: The ARN for the SNS topic to publish metrics.

    Returns:
        Number of breach groups detected (0 if no breaches).
    """
    conversion_rate_config = ConversionRateThresholdsConfig()
    conversion_breach_count = validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=measurement_campaign_reporting_df,
        thresholds_config=conversion_rate_config,
        instore_variants=conversion_rate_config.instore_variants,
        correlation_id=correlation_id,
        metrics_topic_arn=metrics_topic_arn,
    )

    recalibration_config = RecalibrationFactorsConfig()
    recalibration_breach_count = validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=measurement_campaign_reporting_df,
        recalibration_config=recalibration_config,
        correlation_id=correlation_id,
        metrics_topic_arn=metrics_topic_arn,
    )

    return conversion_breach_count + recalibration_breach_count


def agg_validate_conversion_rate_thresholds(
        conversion_rate_threshold_df: DataFrame,
        thresholds_config: ConversionRateThresholdsConfig,
        instore_variants: List[str],
) -> DataFrame:
    """
    Summarize positive-rate breaches by marketing type, channel and subchannel.

    Requires campaign/booking IDs, marketing type, conversion rate, channel,
    subchannel and load timestamp. Configured maxima are inclusive; instore
    aliases come from ``instore_variants``. Each group retains counts, min/max,
    a threshold and up to ten examples, ranked by rate then campaign/booking ID.
    Returns an empty summary when no rates breach; no publishing is performed.
    """
    conversion_rates = evaluate_conversion_rate_thresholds(
        conversion_rate_threshold_df,
        thresholds={
            "offsite": ThresholdBounds(maximum=thresholds_config.offsite_max_threshold),
            "onsite": ThresholdBounds(maximum=thresholds_config.onsite_max_threshold),
            **{
                variant: ThresholdBounds(maximum=thresholds_config.instore_max_threshold)
                for variant in instore_variants
            },
        },
        positive_only=True,
    )
    all_breaches_df = (
        conversion_rates
        .filter(F.col("is_breach"))
        .select(
            "campaign_id", "booking_id", "marketing_type", "marketing_type_lower",
            "conversion_rate", "channel_name", "subchannel_name", "load_ts", "threshold_value",
        )
    )

    window_spec = Window.partitionBy(
        "marketing_type_lower", "channel_name", "subchannel_name", "threshold_value"
    ).orderBy(
        F.col("conversion_rate").desc_nulls_last(),
        F.col("campaign_id").asc_nulls_last(),
        F.col("booking_id").asc_nulls_last(),
    ).rowsBetween(Window.unboundedPreceding, Window.currentRow)

    all_breaches_ranked = all_breaches_df.withColumn("row_num", F.row_number().over(window_spec))  # NOSONAR pythonenterprise:S7181
    example_limit = 10
    top_examples = F.collect_list(F.when(
        F.col("row_num") <= example_limit,
        F.struct(F.col("conversion_rate"), F.col("campaign_id"), F.col("booking_id")),
    ))
    breach_summary_df = (
        all_breaches_ranked
        .groupBy("marketing_type_lower", "channel_name", "subchannel_name", "threshold_value")
        .agg(
            F.count("*").alias("breach_count"),
            F.max(F.col("conversion_rate")).alias("max_conversion_rate"),
            F.min(F.col("conversion_rate")).alias("min_conversion_rate"),
            F.min(F.col("marketing_type")).alias("marketing_type"),
            F.coalesce(top_examples, F.array()).alias("top_examples"),
            F.min(F.col("load_ts")).alias("load_ts"),
        )
    )

    return breach_summary_df


def validate_conversion_rate_thresholds(
        conversion_rate_threshold_df: DataFrame,
        thresholds_config: ConversionRateThresholdsConfig,
        instore_variants: List[str],
        correlation_id: str,
        metrics_topic_arn: str,
) -> int:
    """
    Validates conversion rate thresholds and publishes aggregated breach summaries.

    Uses agg_validate_conversion_rate_thresholds to get aggregated breach summaries,
    then publishes a bounded number of events (one per marketing_type/channel/subchannel group)
    to prevent SNS flooding.

    Results are sorted by marketing_type, channel, and subchannel to guarantee consistent
    ordering. Breach summaries are published to Grafana for monitoring and alerting.

    Args:
        conversion_rate_threshold_df: DataFrame containing conversion rates to be validated.
        thresholds_config: Configuration containing the threshold values for validation.
        instore_variants: List of marketing type variants considered as instore.
        correlation_id: The correlation ID for the run.
        metrics_topic_arn: The ARN for the SNS topic to publish metrics.

    Returns:
        Number of breach groups detected (0 if no breaches).
    """

    breach_summary_df = agg_validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=conversion_rate_threshold_df,
        thresholds_config=thresholds_config,
        instore_variants=instore_variants,
    )

    ordered_summary = breach_summary_df.orderBy("marketing_type_lower", "channel_name", "subchannel_name")
    breach_summary = ordered_summary.collect()

    if breach_summary:
        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

        for summary in breach_summary:
            # Creates a unique name for the aggregated breach summary
            unique_name = f"conversion_rate_validation_summary|{summary['marketing_type']}|{summary['subchannel_name']}"

            # Format top examples for metadata
            top_examples = [
                {
                    "campaign_id": example["campaign_id"],
                    "booking_id": example["booking_id"],
                    "conversion_rate": float(example["conversion_rate"]),
                }
                for example in summary["top_examples"]
            ]

            # Store aggregated data in metadata as JSON
            metadata = json.dumps({
                "marketing_type": summary["marketing_type"],
                "channel_name": summary["channel_name"],
                "subchannel_name": summary["subchannel_name"],
                "threshold_value": float(summary["threshold_value"]),
                "breach_count": summary["breach_count"],
                "max_conversion_rate": float(summary["max_conversion_rate"]),
                "min_conversion_rate": float(summary["min_conversion_rate"]),
                "top_examples": top_examples,
                "load_ts": str(summary["load_ts"]),
            })

            event = MTAValidationMetricSchema(
                correlation_id=correlation_id,
                name=unique_name,
                type="conversion_rate_validation",
                severity=Severity.HIGH,
                comment=f"{summary['breach_count']} campaigns exceeded threshold: {summary['marketing_type']}/{summary['subchannel_name']} - Max: {summary['max_conversion_rate']:.2f}%, Min: {summary['min_conversion_rate']:.2f}%, Threshold: {summary['threshold_value']:.2f}%",
                value=str(summary["breach_count"]),
                metadata=metadata,
                channel_name=summary["channel_name"],
            )
            publisher.publish_event(
                message_subject="Conversion Rate Threshold Violations Detected",
                event=event,
            )

    return len(breach_summary)


def threshold_to_machine_key(threshold_breached: str) -> str:
    """
    Convert human-readable threshold_breached string to machine-friendly event key.

    Maps threshold descriptions to short, stable identifiers suitable for metric event names.
    These keys are used in unique_name for reliable querying and aggregation.

    Args:
        threshold_breached: Human-readable threshold violation description.
            Examples: "<= 0.00", "> 1.00", "!= 1.00"

    Returns:
        Machine-friendly key (lowercase alphanumeric + underscore).
        Examples: "offsite_le_0", "offsite_gt_1", "non_offsite_ne_1"
    """
    threshold_breached_lower = threshold_breached.lower()

    # Offsite channel thresholds
    if "<= 0" in threshold_breached_lower:
        return "offsite_le_0"
    elif "> 1" in threshold_breached_lower:
        return "offsite_gt_1"
    # Non-offsite channel threshold
    elif "!= 1" in threshold_breached_lower:
        return "non_offsite_ne_1"
    else:
        # Fallback: keep only lowercase alphanumerics and underscores
        return "".join(ch if ch.isalnum() else "_" for ch in threshold_breached_lower).strip("_")


def agg_validate_recalibration_factor_thresholds(
    measurement_campaign_reporting_df: DataFrame,
    recalibration_config: RecalibrationFactorsConfig,
) -> DataFrame:
    """
    Aggregate recalibration factor threshold breaches by channel.

    All offsite channels, including Meta, use the configured exclusive lower
    and inclusive upper bounds (defaults: > 0 and <= 1). Non-offsite factors
    must equal the configured non-offsite value (default: 1).
    Null factors are excluded. Breaches are grouped by channel and threshold,
    with at most 10 examples per group. No fixed Meta factor is enforced.

    Args:
        measurement_campaign_reporting_df: DataFrame containing campaign reporting data with recalibration factors.
        recalibration_config: Configuration containing the recalibration factor thresholds.
    Returns:
        DataFrame containing aggregated breach summaries.
    """

    offsite_rows = (
        measurement_campaign_reporting_df
        .filter(F.col("recalibration_factor").isNotNull())
        .withColumn("recalibration_factor", F.col("recalibration_factor").cast("double"))
        .filter(F.lower(F.trim(F.col("marketing_type"))) == "offsite")
        .withColumn(
            "threshold_breached",
            get_threshold_violations(
                F.col("recalibration_factor"),
                ThresholdBounds(
                    minimum=recalibration_config.offsite_recalibration_min_threshold,
                    maximum=recalibration_config.offsite_recalibration_max_threshold,
                    minimum_inclusive=False,
                ),
            ),
        )
    )
    offsite_breaches_df = (
        offsite_rows
        .filter(F.col("threshold_breached").isNotNull())
        .select("campaign_id", "booking_id", "channel_name", "recalibration_factor", "load_ts")
        .withColumn(
            "threshold_breached",
            F.when(
                F.col("recalibration_factor")
                <= recalibration_config.offsite_recalibration_min_threshold,
                f"<= {recalibration_config.offsite_recalibration_min_threshold}",
            )
            .when(
                F.col("recalibration_factor")
                > recalibration_config.offsite_recalibration_max_threshold,
                f"> {recalibration_config.offsite_recalibration_max_threshold}",
            ),
        )
    )

    non_offsite_rows = (
        measurement_campaign_reporting_df
        .filter(F.col("recalibration_factor").isNotNull())
        .withColumn("recalibration_factor", F.col("recalibration_factor").cast("double"))
        .filter(F.lower(F.trim(F.col("marketing_type"))) != "offsite")
    )
    non_offsite_rows = evaluate_expected_value(
        non_offsite_rows,
        F.col("recalibration_factor"),
        F.lit(recalibration_config.non_offsite_recalibration_factor),
        "matches_non_offsite_factor",
    )
    non_offsite_breaches_df = (
        non_offsite_rows
        .filter(~F.col("matches_non_offsite_factor"))
        .select("campaign_id", "booking_id", "channel_name", "recalibration_factor", "load_ts")
        .withColumn("threshold_breached", F.lit(f"!= {recalibration_config.non_offsite_recalibration_factor}"))
    )

    all_breaches_df = offsite_breaches_df.union(non_offsite_breaches_df)
    # Only the top 10 per channel will be collected, preventing large datasets and memory issues
    window_spec = Window.partitionBy("channel_name", "threshold_breached").orderBy(F.desc("recalibration_factor"))  # NOSONAR pythonenterprise:S7181

    # Rank breaches within each channel group
    all_breaches_ranked = all_breaches_df.withColumn("row_num", F.row_number().over(window_spec))  # NOSONAR pythonenterprise:S7181

    # Aggregates multiple campaign breaches into one summary per channel, with min/max to show the range of breach values
    recalibration_breach_summary_df = (
        all_breaches_ranked
        .groupBy("channel_name", "threshold_breached")
        .agg(
            F.count("*").alias("breach_count"),
            F.max("recalibration_factor").alias("max_recalibration_factor"),
            F.min("recalibration_factor").alias("min_recalibration_factor"),
            F.coalesce(
                F.expr(
                    "filter(collect_list(case when row_num <= 10 then "
                    "struct(recalibration_factor, campaign_id, booking_id) end), x -> x is not null)"
                ),
                F.array()
            ).alias("top_examples"),
            F.min("load_ts").alias("load_ts"),
        )
    )

    return recalibration_breach_summary_df


def validate_recalibration_factor_thresholds(
    measurement_campaign_reporting_df: DataFrame,
    recalibration_config: RecalibrationFactorsConfig,
    correlation_id: str,
    metrics_topic_arn: str,
) -> int:
    """
    Validates recalibration factors.

    All offsite channels, including Meta, use the configured bounds (defaults:
    recalibration_factor > 0 and <= 1). Non-offsite factors must equal the
    configured non-offsite value (default: 1). Null factors are excluded;
    no fixed Meta factor is enforced.
    If validation fails, publishes a HIGH severity warning.

    Args:
        measurement_campaign_reporting_df: DataFrame containing the measurement campaign reporting data
        recalibration_config: Configuration object containing recalibration factors
        correlation_id: Correlation ID for tracking
        metrics_topic_arn: ARN of the metrics topic

    Returns:
        Number of breach groups detected.
    """

    # Reads validation factor values from DataFrame
    recalibration_breach_summary_df = agg_validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=measurement_campaign_reporting_df,
        recalibration_config=recalibration_config,
    )

    recalibration_breach_summary_df = recalibration_breach_summary_df.orderBy("channel_name", "threshold_breached")
    recalibration_breach_summary = recalibration_breach_summary_df.collect()

    if recalibration_breach_summary:
        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

        for summary in recalibration_breach_summary:
            threshold_key = threshold_to_machine_key(summary['threshold_breached'])
            unique_name = f"recalibration_factor_validation_summary|{summary['channel_name']}|{threshold_key}"

            # Metadata with breach details and examples
            top_examples = [
                {
                    "campaign_id": ex["campaign_id"],
                    "booking_id": ex["booking_id"],
                    "recalibration_factor": float(ex["recalibration_factor"]),
                }
                for ex in summary["top_examples"]
            ]

            metadata = json.dumps({
                "channel_name": summary["channel_name"],
                "threshold_breached": summary["threshold_breached"],
                "breach_count": summary["breach_count"],
                "max_recalibration_factor": float(summary["max_recalibration_factor"]),
                "min_recalibration_factor": float(summary["min_recalibration_factor"]),
                "meta_recalibration_factor": recalibration_config.meta_recalibration_factor,
                "top_examples": top_examples,
                "load_ts": str(summary["load_ts"]),
            })

            event = MTAValidationMetricSchema(
                correlation_id=correlation_id,
                name=unique_name,
                type="recalibration_factor_validation",
                severity=Severity.HIGH,
                comment=f"{summary['breach_count']} campaigns breached recalibration factor threshold: {summary['channel_name']} - Max: {summary['max_recalibration_factor']:.2f}, Min: {summary['min_recalibration_factor']:.2f}, Breach Type: {summary['threshold_breached']}",
                value=str(summary["breach_count"]),
                metadata=metadata,
                channel_name=summary["channel_name"],
            )
            publisher.publish_event(
                message_subject="Recalibration Factor Threshold Violations Detected",
                event=event,
            )

    return len(recalibration_breach_summary)


def check_normalized_weight_distribution(
    attribution_df: DataFrame,
    correlation_id: str,
    metrics_topic_arn: str,
) -> int:
    """
    Validates that normalized_weights sum to 1.0 for each converted user journey.

    MTA attribution assigns fractional credit across touchpoints per journey, so the
    weights must sum to exactly 1.0. Any deviation beyond the tolerance indicates a
    data integrity issue in the attribution model output, which would cause incorrect
    sales attribution downstream.

    Returns:
        Number of breach events published (0 if no breaches, 1 if breaches detected).
    """
    conversion_df = attribution_df

    weight_sums = conversion_df.groupBy("userjourney_id").agg(
        F.sum("normalized_weights").alias("weight_sum")
    )

    failing_df = weight_sums.filter(
        F.abs(F.col("weight_sum") - 1.0) >= MtaValidationConfig.WEIGHT_SUM_TOLERANCE
    )

    stats = failing_df.agg(
        F.count("*").alias("failing_count"),
        F.min("weight_sum").alias("min_weight_sum"),
        F.max("weight_sum").alias("max_weight_sum"),
    ).first()

    failing_count = int(stats["failing_count"])

    if failing_count > 0:
        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)
        publisher.publish_event(
            message_subject=MtaValidationConfig.MESSAGE_SUBJECT,
            event=MTAValidationMetricSchema(
                correlation_id=correlation_id,
                name=MtaValidationConfig.WEIGHT_CHECK_NAME,
                type=MtaValidationConfig.WEIGHT_CHECK_TYPE,
                severity=Severity.HIGH,
                comment=(
                    f"{failing_count} converted user journey(s) have normalized_weights "
                    f"not summing to 1.0 (tolerance {MtaValidationConfig.WEIGHT_SUM_TOLERANCE})."
                ),
                value=str(failing_count),
                metadata=json.dumps({
                    "failing_journey_count": failing_count,
                    "min_weight_sum": stats["min_weight_sum"],
                    "max_weight_sum": stats["max_weight_sum"],
                    "tolerance": MtaValidationConfig.WEIGHT_SUM_TOLERANCE,
                }),
            ),
        )
        return 1

    return 0


def get_channel_unit_ratios(reporting_df: DataFrame) -> DataFrame:
    """
    Return channel totals and summed-units / summed-conversions ratios.

    Requires channel_name, attributed_recalibrated_units_qty and conversions_recalibrated.
    Null channels and nonpositive conversion totals are excluded. Null unit totals
    remain null ratios; empty input returns no channel rows.
    """
    channel_rows = (
        reporting_df
        .select(F.col("channel_name"), F.col("attributed_recalibrated_units_qty"), F.col("conversions_recalibrated"))
        .filter(F.col("channel_name").isNotNull())
    )
    channel_totals = channel_rows.groupBy("channel_name").agg(
        F.sum(F.col("attributed_recalibrated_units_qty")).alias("total_recalibrated_units"),
        F.sum(F.col("conversions_recalibrated")).alias("total_conversions"),
    )
    eligible_channels = channel_totals.filter(F.col("total_conversions") > 0)
    return eligible_channels.withColumn(
        "channel_sales_ratio", safe_ratio(F.col("total_recalibrated_units"), F.col("total_conversions")),
    )


def evaluate_channel_ratio_thresholds(
    channel_ratios: DataFrame,
    ratio_config: ChannelSalesRatioConfig,
) -> DataFrame:
    """
    Add absolute/median breach flags and median-relative diagnostic values.

    Requires channel_sales_ratio. Absolute and median bounds permit equality.
    The approximate median excludes null ratios; missing/nonpositive medians
    disable median breaches. Empty input remains empty; no publishing occurs.
    """
    absolute_bounds = ThresholdBounds(maximum=ratio_config.higher_unit_ratio_warning)
    deviation_bounds = ThresholdBounds(minimum=0.0, maximum=ratio_config.median_ratio_deviation_threshold)
    median_stats = channel_ratios.agg(
        F.percentile_approx(F.col("channel_sales_ratio"), 0.5).alias("median_ratio"),
    )
    ratios_with_median = channel_ratios.crossJoin(F.broadcast(median_stats))
    deviation = deviation_bounds.maximum
    ratios_with_bounds = (
        ratios_with_median
        .withColumn("lower_bound", F.col("median_ratio") * (1 - deviation))
        .withColumn("upper_bound", F.col("median_ratio") * (1 + deviation))
        .withColumn("deviation_percentage", safe_ratio(
            F.col("channel_sales_ratio") - F.col("median_ratio"), F.col("median_ratio"),
        ) * 100)
    )
    ratio = F.col("channel_sales_ratio")
    outside_median_bounds = (ratio < F.col("lower_bound")) | (ratio > F.col("upper_bound"))
    usable_median = F.col("median_ratio") > 0
    median_breach = usable_median & outside_median_bounds
    return (
        ratios_with_bounds
        .withColumn("absolute_breach", get_threshold_violations(ratio, absolute_bounds).isNotNull())
        .withColumn("median_breach", F.coalesce(median_breach, F.lit(False)))
    )


def check_channel_sales_ratio(
    measurement_campaign_reporting_df: DataFrame,
    correlation_id: str,
    metrics_topic_arn: str,
) -> int:
    """
    Publish channel units-per-conversion warnings and return the event count.

    Uses summed units/conversions, not hypercare's row-level sales ratios.
    ChannelSalesRatioConfig controls absolute and median-relative limits.
    A channel may emit two events; no breaches avoids publisher initialization.
    Input scope is supplied by the caller; correlation_id labels events only.
    """

    ratio_config = ChannelSalesRatioConfig()
    channel_ratios = get_channel_unit_ratios(measurement_campaign_reporting_df)
    evaluated_ratios = evaluate_channel_ratio_thresholds(channel_ratios, ratio_config).cache()
    try:
        high_ratio_rows = evaluated_ratios.filter(F.col("absolute_breach")).collect()
        breach_rows = evaluated_ratios.filter(F.col("median_breach")).collect()
    finally:
        evaluated_ratios.unpersist()
    breach_count = len(high_ratio_rows) + len(breach_rows)

    # Early return if no breaches (avoids unnecessary SNS client initialization)
    if breach_count == 0:
        return 0

    # Create publisher only when breaches are confirmed
    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

    # Publish Check 1 breaches
    for row in high_ratio_rows:
        channel_name = row["channel_name"]
        channel_sales_ratio = row["channel_sales_ratio"]

        publisher.publish_event(
            message_subject="Warning: Higher Attributed Units per Conversion Ratio Detected",
            event=MTAValidationMetricSchema(
                correlation_id=correlation_id,
                name=f"channel_sales_ratio_absolute_check|{channel_name}",
                type="channel_sales_ratio_validation",
                severity=Severity.MEDIUM,
                comment=(
                    f"Channel '{channel_name}' has an attributed units per conversion ratio of "
                    f"{channel_sales_ratio:.2f}, which exceeds the expected units-per-conversion threshold of {ratio_config.higher_unit_ratio_warning}."
                ),
                value=str(channel_sales_ratio),
                metadata=json.dumps({
                    "channel_name": channel_name,
                    "channel_sales_ratio": float(channel_sales_ratio),
                    "threshold": ratio_config.higher_unit_ratio_warning,
                }),
                channel_name=channel_name,
            ),
        )

    # Publish Check 2 breaches
    for row in breach_rows:
        channel_name = row['channel_name']
        median_ratio = row["median_ratio"]
        lower_bound = row["lower_bound"]
        upper_bound = row["upper_bound"]
        publisher.publish_event(
            message_subject="Channel Units Ratio Deviation Warning",
            event=MTAValidationMetricSchema(
                correlation_id=correlation_id,
                name=f"channel_sales_ratio_median_check|{channel_name}",
                type="channel_sales_ratio_validation",
                severity=Severity.MEDIUM,
                comment=(
                    f"Channel '{channel_name}' ratio ({row['channel_sales_ratio']:.2f}) "
                    f"deviates {abs(row['deviation_percentage']):.1f}% from median ({median_ratio:.2f}). "
                    f"Acceptable range: {lower_bound:.2f} - {upper_bound:.2f}"
                ),
                value=str(row['channel_sales_ratio']),
                metadata=json.dumps({
                    "channel_name": channel_name,
                    "channel_sales_ratio": float(row["channel_sales_ratio"]),
                    "median_ratio": float(median_ratio),
                    "deviation_percentage": float(row["deviation_percentage"]),
                    "lower_bound": float(lower_bound),
                    "upper_bound": float(upper_bound),
                }),
                channel_name=channel_name,
            ),
        )

    return breach_count


def media_spend_check(
    measurement_campaign_reporting_df: DataFrame,
    correlation_id: str,
    metrics_topic_arn: str,
) -> int:
    """
    Check if the media spend per channel falls below the configured threshold and publishes warnings.

    Detects channels with low media spend relative to the configured threshold, which may indicate
    insufficient budget allocation or data quality issues.

    Returns:
        Number of channels with media spend below threshold (0 if all channels above threshold).

    Args:
        measurement_campaign_reporting_df (DataFrame): DataFrame containing measurement campaign reporting data.
        correlation_id (str): Correlation ID for tracing the pipeline run.
        metrics_topic_arn (str): ARN of the SNS topic to publish metrics to.
    """

    low_spend_config = LowMediaSpendConfig()

    # Group by channel and sum spend
    media_spend_df = (
        measurement_campaign_reporting_df
        .select(F.col("channel_name"), F.col("media_spend_amt"))
        .filter(F.col("channel_name").isNotNull())
        .groupBy("channel_name")
        .agg(F.sum("media_spend_amt").alias("total_media_spend_amt"))
    )

    # Get channels where media spend is below the configured threshold
    below_threshold_spend = media_spend_df.filter(  # NOSONAR pythonenterprise:S7189
        get_threshold_violations(
            F.col("total_media_spend_amt"),
            ThresholdBounds(minimum=low_spend_config.low_spend_threshold),
        ).isNotNull()
    )

    # Collect rows and track breach count
    below_threshold_rows = below_threshold_spend.collect()
    breach_count = len(below_threshold_rows)

    # Early return if no breaches (avoids unnecessary SNS client initialization)
    if breach_count == 0:
        return 0

    # Publish warnings for breaches
    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)
    for row in below_threshold_rows:
        publisher.publish_event(
            message_subject="Low Media Spend Warning",
            event=MTAValidationMetricSchema(
                correlation_id=correlation_id,
                name=f"media_spend_below_threshold|{row['channel_name']}",
                type="media_spend_validation",
                severity=Severity.LOW,
                comment=(
                    f"Channel '{row['channel_name']}' media spend £{row['total_media_spend_amt']:,.2f} "
                    f"is below the configured threshold of £{low_spend_config.low_spend_threshold:,.2f}"
                ),
                value=str(row["total_media_spend_amt"]),
                metadata=json.dumps({
                    "channel_name": row["channel_name"],
                    "channel_media_spend": float(row["total_media_spend_amt"]),
                    "low_spend_threshold": float(low_spend_config.low_spend_threshold),
                }),
                channel_name=row["channel_name"],
            ),
        )

    return breach_count


def check_channel_contribution_distribution(
    attribution_df: DataFrame,
    campaign_reporting_df: DataFrame,
    correlation_id: str,
    metrics_topic_arn: str,
) -> int:
    """
    Validates channel contribution distribution against sales attribution.

    Computes Spearman rank correlation between channel contribution weights and
    attributed sales rank, as well as recalibrated units rank. Returns early if
    fewer than 2 channels exist (correlation requires 2+ points).

    Returns:
        Number of checks that detected HIGH severity issues (0 if none).
    """
    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

    contribution_df = (
        attribution_df
        .groupBy("channel_name")
        .agg(
            F.avg("normalized_weights").alias("avg_weight"),
            F.countDistinct("userjourney_id").alias("journey_count"),
        )
        .withColumn("channel_contribution", F.col("avg_weight") * F.col("journey_count"))
        .withColumn(
            "contribution_rank",
            F.rank().over(Window.orderBy(F.desc("channel_contribution"))),
        )
    )

    channel_count = contribution_df.count()

    if channel_count < 2:
        return 0

    breach_count = 0

    sales_df = (
        campaign_reporting_df
        .groupBy("channel_name")
        .agg(
            F.sum("attributed_sales_amt").alias("sales_amt"),
            F.sum("attributed_recalibrated_units_qty").alias("total_recalibrated_units"),
        )
        .withColumn(
            "sales_rank",
            F.rank().over(Window.orderBy(F.desc("sales_amt"))),
        )
        .withColumn(
            "recalibrated_units_rank",
            F.rank().over(Window.orderBy(F.desc("total_recalibrated_units"))),  # NOSONAR pythonenterprise:S7181
        )
    )

    joined = contribution_df.join(sales_df, on="channel_name", how="inner")

    channel_ranks = [
        {
            "channel_name": row["channel_name"],
            "contribution_rank": row["contribution_rank"],
            "sales_rank": row["sales_rank"],
            "recalibrated_units_rank": row["recalibrated_units_rank"],
        }
        for row in joined.select(
            "channel_name", "contribution_rank", "sales_rank", "recalibrated_units_rank"
        ).collect()
    ]

    rho_sales_row = joined.select(
        F.corr("contribution_rank", "sales_rank").alias("rho")
    ).first()
    rho_recal_row = joined.select(
        F.corr("contribution_rank", "recalibrated_units_rank").alias("rho")
    ).first()

    rho_sales = float(rho_sales_row["rho"]) if rho_sales_row["rho"] is not None else 0.0
    rho_recal = float(rho_recal_row["rho"]) if rho_recal_row["rho"] is not None else 0.0

    metadata_base = json.dumps({"channel_ranks": channel_ranks})

    breach_count += publish_rank_event(
        publisher=publisher,
        correlation_id=correlation_id,
        check_name=MtaValidationConfig.CONTRIBUTION_VS_SALES_CHECK_NAME,
        sales_column="attributed_sales_amt",
        rho=rho_sales,
        metadata=metadata_base,
    )

    breach_count += publish_rank_event(
        publisher=publisher,
        correlation_id=correlation_id,
        check_name=MtaValidationConfig.CONTRIBUTION_VS_RECALIBRATED_UNITS_CHECK_NAME,
        sales_column="recalibrated units",
        rho=rho_recal,
        metadata=metadata_base,
    )

    return breach_count


def check_roas_thresholds(
    campaign_reporting_df: DataFrame,
    correlation_id: str,
    metrics_topic_arn: str,
) -> int:
    """
    Validates ROAS (Return on Ad Spend) values and publishes breach summaries to Grafana.

    Extremely high ROAS may indicate incorrect sales attribution, duplicated rows,
    missing journeys, or misalignment in marketing spend. Any row where roas_exposed
    exceeds MtaValidationConfig.ROAS_MAX_THRESHOLD (50.0) is flagged as a breach.

    Args:
        campaign_reporting_df: DataFrame containing roas_exposed, campaign_id, booking_id,
            channel_name, subchannel_name, and media_spend_amt columns.
        correlation_id: Correlation ID for tracing the pipeline run.
        metrics_topic_arn: ARN of the SNS topic to publish metrics to.

    Returns:
        Number of breach groups detected (0 if no breaches).
    """
    breach_summary_df = agg_roas_breaches(campaign_reporting_df)
    breach_summary_df = breach_summary_df.orderBy("channel_name", "subchannel_name")
    breach_summary = breach_summary_df.collect()

    if breach_summary:
        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

        for summary in breach_summary:
            unique_name = (
                f"{MtaValidationConfig.ROAS_CHECK_NAME}"
                f"|{summary['channel_name']}"
                f"|{summary['subchannel_name']}"
            )

            breach_examples = [
                {
                    "campaign_id": ex["campaign_id"],
                    "booking_id": ex["booking_id"],
                    "roas_exposed": float(ex["roas_exposed"]),
                }
                for ex in summary["breach_examples"]
            ]

            metadata = json.dumps({
                "channel_name": summary["channel_name"],
                "subchannel_name": summary["subchannel_name"],
                "threshold_value": MtaValidationConfig.ROAS_MAX_THRESHOLD,
                "breach_count": summary["breach_count"],
                "max_roas": float(summary["max_roas"]),
                "min_roas": float(summary["min_roas"]),
                "breach_examples": breach_examples,
                "load_ts": str(summary["load_ts"]),
            })

            event = MTAValidationMetricSchema(
                correlation_id=correlation_id,
                name=unique_name,
                type=MtaValidationConfig.ROAS_CHECK_TYPE,
                severity=Severity.HIGH,
                comment=(
                    f"{summary['breach_count']} campaign(s) exceeded ROAS threshold "
                    f"{MtaValidationConfig.ROAS_MAX_THRESHOLD} for "
                    f"{summary['channel_name']}/{summary['subchannel_name']} - "
                    f"Max: {float(summary['max_roas']):.2f}, "
                    f"Min: {float(summary['min_roas']):.2f}, "
                    f"Threshold: {MtaValidationConfig.ROAS_MAX_THRESHOLD}"
                ),
                value=str(summary["breach_count"]),
                metadata=metadata,
                channel_name=summary["channel_name"],
            )
            publisher.publish_event(
                message_subject=MtaValidationConfig.MESSAGE_SUBJECT,
                event=event,
            )

    return len(breach_summary)


def agg_roas_breaches(
    campaign_reporting_df: DataFrame,
    threshold: float = MtaValidationConfig.ROAS_MAX_THRESHOLD,
) -> DataFrame:
    """
    Aggregates ROAS breach summaries by channel_name/subchannel_name.

    Filters rows where roas_exposed exceeds the configured maximum threshold,
    ranks them within each channel/subchannel group, and returns one aggregated
    summary row per group containing breach_count, max/min ROAS, and top 3.

    Args:
        campaign_reporting_df: DataFrame containing roas_exposed, campaign_id,
            booking_id, channel_name, subchannel_name, and load_ts columns.

    Returns:
        DataFrame of aggregated breach summaries, one row per channel/subchannel group.
    """
    breaches_df = (
        campaign_reporting_df
        .filter(F.col("roas_exposed").isNotNull())
        .withColumn("roas_exposed", F.col("roas_exposed").cast("double"))
        .filter(
            get_threshold_violations(
                F.col("roas_exposed"), ThresholdBounds(maximum=threshold),
            ).isNotNull()
        )
        .select(
            "campaign_id",
            "booking_id",
            "channel_name",
            "subchannel_name",
            "roas_exposed",
            "load_ts",
        )
    )

    window_spec = Window.partitionBy("channel_name", "subchannel_name").orderBy(
        F.desc("roas_exposed")
    )

    breaches_ranked = breaches_df.withColumn(
        "row_num", F.row_number().over(window_spec)
    )

    breach_summary_df = (
        breaches_ranked
        .groupBy("channel_name", "subchannel_name")
        .agg(
            F.count("*").alias("breach_count"),
            F.max("roas_exposed").alias("max_roas"),
            F.min("roas_exposed").alias("min_roas"),
            F.coalesce(
                F.expr(
                    "filter(collect_list(case when row_num <= 3 then "
                    "struct(roas_exposed, campaign_id, booking_id) end), x -> x is not null)"
                ),
                F.array()
            ).alias("breach_examples"),
            F.min("load_ts").alias("load_ts"),
        )
    )

    return breach_summary_df


def get_brand_channel_incremental_totals(reporting_df: DataFrame) -> DataFrame:
    """
    Return brand/channel sales and spend totals plus recalculated iROAS.

    Requires unique_brand_name, channel_name, incremental_sales_amt_exposed,
    attributed_recalibrated_sales_amt and media_spend_amt. Null channels are
    excluded; numeric inputs are cast to double. Nonpositive/missing spend
    produces iROAS zero, preserving the MTA policy.
    """
    sales_rows = (
        reporting_df
        .select(
            F.col("unique_brand_name"), F.col("channel_name"),
            F.col("incremental_sales_amt_exposed").cast("double").alias("incremental_sales_amt_exposed"),
            F.col("attributed_recalibrated_sales_amt").cast("double").alias("attributed_recalibrated_sales_amt"),
            F.col("media_spend_amt").cast("double").alias("media_spend_amt"),
        )
        .filter(F.col("channel_name").isNotNull())
    )
    brand_channel_totals = sales_rows.groupBy("unique_brand_name", "channel_name").agg(
        F.sum(F.col("incremental_sales_amt_exposed")).alias("total_incremental_sales"),
        F.sum(F.col("attributed_recalibrated_sales_amt")).alias("total_attributed_sales"),
        F.sum(F.col("media_spend_amt")).alias("total_media_spend"),
    )
    return brand_channel_totals.withColumn(
        "total_iroas",
        calculate_iroas(F.col("total_incremental_sales"), F.col("total_media_spend"), nonpositive_spend_value=0.0),
    )


def get_channel_incremental_iroas(brand_channel_totals: DataFrame) -> DataFrame:
    """
    Sum brand/channel totals by channel and recalculate iROAS from summed spend.

    Requires channel_name, total_incremental_sales and total_media_spend.
    Ratios are never summed or averaged; missing/nonpositive spend yields zero.
    """
    channel_totals = brand_channel_totals.groupBy("channel_name").agg(
        F.sum(F.col("total_incremental_sales")).alias("total_incremental_sales"),
        F.sum(F.col("total_media_spend")).alias("total_media_spend"),
    )
    return channel_totals.withColumn(
        "total_iroas",
        calculate_iroas(F.col("total_incremental_sales"), F.col("total_media_spend"), nonpositive_spend_value=0.0),
    )


def check_incremental_sales_iroas(
    campaign_reporting_df: DataFrame,
    correlation_id: str,
    metrics_topic_arn: str,
) -> int:
    """
    Publish MTA sales/iROAS warnings and return the total breach count.

    Input follows get_brand_channel_incremental_totals and is caller-scoped.
    Brand/channel incremental >= attributed sales breaches; channel negative
    sales/iROAS breaches independently. High iROAS breaches require sufficient
    spend. At most 100 events per category are published; the return value counts
    all breaches, not only published samples. Correlation ID labels events.
    """

    incremental_sales_iroas_config = IncrementalSalesIROASConfig()
    low_media_spend_config = LowMediaSpendConfig()

    brand_channel_totals = get_brand_channel_incremental_totals(campaign_reporting_df)
    evaluated_sales = evaluate_incremental_sales(
        brand_channel_totals,
        F.col("total_incremental_sales"), F.col("total_attributed_sales"), fail_on_equal=True,
    ).cache()

    failing_incremental_sales_df = evaluated_sales.filter(F.col("incremental_breach"))
    channel_totals = get_channel_incremental_iroas(evaluated_sales)
    evaluated_iroas = evaluate_iroas_thresholds(
        channel_totals, F.col("total_iroas"),
        ThresholdBounds(
            minimum=incremental_sales_iroas_config.low_iroas_threshold,
            maximum=incremental_sales_iroas_config.high_iroas_threshold,
        ),
    )

    sufficient_spend = F.col("total_media_spend") > low_media_spend_config.low_spend_threshold
    high_iroas_breach = sufficient_spend & F.col("iroas_above_maximum")
    negative_sales = F.col("total_incremental_sales") < incremental_sales_iroas_config.low_incremental_sales_threshold
    non_negative_breach = negative_sales | F.col("iroas_below_minimum")
    failing_iroas_df = evaluated_iroas.filter(high_iroas_breach)
    failing_non_negative_df = evaluated_iroas.filter(non_negative_breach)
    breach_rows = (
        failing_incremental_sales_df.select(F.lit(1).alias("breach"))
        .unionByName(failing_iroas_df.select(F.lit(1).alias("breach")))
        .unionByName(failing_non_negative_df.select(F.lit(1).alias("breach")))
    )
    breach_count = breach_rows.agg(F.count(F.col("breach")).alias("breach_count")).first()["breach_count"]

    # Early return if there are no breaches (avoids unnecessary SNS)
    if breach_count == 0:
        evaluated_sales.unpersist()
        return 0

    max_events = 100

    # Collect a bounded set of examples for publishing
    incremental_sales_rows = failing_incremental_sales_df.limit(max_events).collect()
    iroas_rows = failing_iroas_df.limit(max_events).collect()
    non_negative_rows = failing_non_negative_df.limit(max_events).collect()

    evaluated_sales.unpersist()
    # Publishing events for failing channels
    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

    for row in incremental_sales_rows:
        publisher.publish_event(
            message_subject="Incremental vs Attributed Sales Validation Warning",
            event=MTAValidationMetricSchema(
                correlation_id=correlation_id,
                name=f"incremental_vs_attributed|{row['unique_brand_name']}|{row['channel_name']}",
                type="incremental_vs_attributed",
                severity=Severity.HIGH,
                comment=(
                    f"Brand '{row['unique_brand_name']}' Channel '{row['channel_name']}' has incremental sales "
                    f"£{row['total_incremental_sales']:,.2f} which is not less than "
                    f"attributed sales £{row['total_attributed_sales']:,.2f}."
                ),
                value=str(row["total_incremental_sales"]),
                metadata=json.dumps({
                    "unique_brand_name": row["unique_brand_name"],
                    "channel_name": row["channel_name"],
                    "total_incremental_sales": float(row["total_incremental_sales"]),
                    "total_attributed_sales": float(row["total_attributed_sales"]),
                }),
                channel_name=row["channel_name"],
            ),
        )

    for row in iroas_rows:
        publisher.publish_event(
            message_subject="iROAS Validation Warning",
            event=MTAValidationMetricSchema(
                correlation_id=correlation_id,
                name=f"iroas_validation|{row['channel_name']}",
                type="iroas_validation",
                severity=Severity.HIGH,
                comment=(
                    f"Channel '{row['channel_name']}' has iROAS "
                    f"{row['total_iroas']:,.2f} which exceeds the high threshold of "
                    f"{incremental_sales_iroas_config.high_iroas_threshold}."
                ),
                value=str(row["total_iroas"]),
                metadata=json.dumps({
                    "channel_name": row["channel_name"],
                    "total_incremental_sales": float(row["total_incremental_sales"]),
                    "total_iroas": float(row["total_iroas"]),
                    "high_iroas_threshold": incremental_sales_iroas_config.high_iroas_threshold,
                    "total_media_spend": float(row["total_media_spend"]),
                }),
                channel_name=row["channel_name"],
            ),
        )

    for row in non_negative_rows:
        publisher.publish_event(
            message_subject="Non-Negative Validation Warning",
            event=MTAValidationMetricSchema(
                correlation_id=correlation_id,
                name=f"non_negative_validation|{row['channel_name']}",
                type="non_negative_validation",
                severity=Severity.HIGH,
                comment=(
                    f"Channel '{row['channel_name']}' has non-negative validation issues: "
                    f"Incremental Sales {row['total_incremental_sales']:,.2f}, "
                    f"iROAS {row['total_iroas']:,.2f}."
                ),
                value=str(row["total_incremental_sales"]),
                metadata=json.dumps({
                    "channel_name": row["channel_name"],
                    "total_incremental_sales": float(row["total_incremental_sales"]),
                    "total_iroas": float(row["total_iroas"]),
                }),
                channel_name=row["channel_name"],
            ),
        )

    return breach_count


def severity_for_rho(rho: float) -> str:
    if rho < MtaValidationConfig.SPEARMAN_HIGH_THRESHOLD:
        return Severity.HIGH
    return Severity.LOW


def publish_rank_event(
    publisher: MetricsPublisher,
    correlation_id: str,
    check_name: str,
    sales_column: str,
    rho: float,
    metadata: str,
) -> int:
    """
    Publish rank divergence event if severity is HIGH.

    Returns:
        1 if a HIGH severity event was published, 0 otherwise.
    """
    severity = severity_for_rho(rho)

    if severity != Severity.HIGH:
        return 0

    rho_rounded = round(rho, 4)
    comment = (
        f"Channel contribution ranks diverge from {sales_column} ranks "
        f"(Spearman ρ = {rho_rounded}). "
        f"Expected ρ ≥ {MtaValidationConfig.SPEARMAN_HIGH_THRESHOLD} for OK."
    )

    event = MTAValidationMetricSchema(
        correlation_id=correlation_id,
        name=check_name,
        type=MtaValidationConfig.CONTRIBUTION_CHECK_TYPE,
        severity=severity,
        comment=comment,
        value=str(rho_rounded),
        metadata=metadata,
    )
    publisher.publish_event(
        message_subject=MtaValidationConfig.MESSAGE_SUBJECT, event=event
    )
    return 1
