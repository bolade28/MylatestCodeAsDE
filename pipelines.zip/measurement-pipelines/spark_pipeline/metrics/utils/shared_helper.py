from dataclasses import dataclass
from typing import Mapping, Optional

from pyspark.sql import Column, DataFrame, functions as F

from spark_pipeline.common.variables import ProductType, ValidationStatus


def filter_reporting_by_correlation_id(reporting_df: DataFrame, correlation_id: str) -> DataFrame:
    """Keep reporting rows for the requested correlation ID."""
    return reporting_df.filter(F.col("correlation_id") == correlation_id)


def filter_reporting_by_campaign_period(
    reporting_df: DataFrame,
    campaign_period: str,
    correlation_id: Optional[str] = None,
) -> DataFrame:
    """Keep rows for one campaign period (case and whitespace insensitive), optionally for one run."""
    if correlation_id is not None:
        reporting_df = filter_reporting_by_correlation_id(reporting_df, correlation_id)

    return reporting_df.filter(
        F.upper(F.trim(F.col("campaign_duration"))) == campaign_period.strip().upper()
    )


def filter_reporting_by_campaign_period_and_journey_type(
    reporting_df: DataFrame,
    campaign_period: str,
    journey_type: str = ProductType.BRAND.value,
    correlation_id: Optional[str] = None,
) -> DataFrame:
    """Filter by campaign period and journey type, optionally also by correlation ID."""
    return filter_reporting_by_campaign_period(reporting_df, campaign_period, correlation_id).filter(
        F.upper(F.trim(F.col("journey_type"))) == journey_type.strip().upper()
    )


def format_check_name(check_name: str, campaign_period: str) -> str:
    """Suffix a check name with its period, e.g. ``iroas`` + ``During+Post`` -> ``iroas_during_post``."""
    return f"{check_name}_{campaign_period.strip().lower().replace('+', '_')}"


def format_qa_result(
    stats: DataFrame,
    correlation_id: str,
    check_type: str,
    name: str,
    expected_value: Optional[str],
    outcome: Column,
    metadata: Column,
    details: Optional[Column] = None,
) -> DataFrame:
    """
    Shape check statistics into ``QAChecks.detail_schema``.

    A null outcome becomes ``fail``. Details default to an empty string;
    callers can supply readable details alongside diagnostic JSON metadata.
    """
    return stats.select(
        F.lit(correlation_id).alias("correlation_id"),
        F.lit(check_type).alias("type"),
        F.lit(name).alias("name"),
        F.lit(expected_value).cast("string").alias("expected_value"),
        F.coalesce(outcome, F.lit(ValidationStatus.FAIL.value)).alias("outcome"),
        (F.lit("") if details is None else details).alias("details"),
        F.coalesce(F.to_json(metadata), F.lit("{}")).alias("additional_metadata"),
        F.current_timestamp().alias("load_timestamp"),
    )


@dataclass(frozen=True)
class ThresholdBounds:
    """Immutable numeric limits expressed in the input metric's units.

    None disables a limit. Inclusive endpoints permit equality; exclusive
    endpoints treat equality as a breach. Limits must be finite and ordered.
    """

    minimum: Optional[float] = None
    maximum: Optional[float] = None
    minimum_inclusive: bool = True
    maximum_inclusive: bool = True


def get_threshold_violations(value: Column, bounds: ThresholdBounds) -> Column:
    """Build a Spark expression returning the breached limit or null.

    Missing values and values within the configured bounds return null.
    Endpoint comparisons follow the inclusivity flags in ``bounds``.
    """
    breached_bounds = []
    if bounds.minimum is not None:
        below_minimum = (
            value < bounds.minimum if bounds.minimum_inclusive else value <= bounds.minimum
        )
        breached_bounds.append(F.when(below_minimum, F.lit(bounds.minimum)))
    if bounds.maximum is not None:
        above_maximum = (
            value > bounds.maximum if bounds.maximum_inclusive else value >= bounds.maximum
        )
        breached_bounds.append(F.when(above_maximum, F.lit(bounds.maximum)))
    return F.coalesce(*breached_bounds, F.lit(None).cast("double"))


def evaluate_iroas_thresholds(
    reporting_df: DataFrame,
    iroas: Column,
    bounds: ThresholdBounds,
) -> DataFrame:
    """Add ``iroas_below_minimum`` and ``iroas_above_maximum`` boolean columns.

    Missing values breach neither limit. The caller owns aggregation, spend
    eligibility and the precedence of warning and failure outcomes.
    """
    lower_bounds = ThresholdBounds(minimum=bounds.minimum, minimum_inclusive=bounds.minimum_inclusive)
    upper_bounds = ThresholdBounds(maximum=bounds.maximum, maximum_inclusive=bounds.maximum_inclusive)
    below_minimum = get_threshold_violations(iroas, lower_bounds).isNotNull()
    above_maximum = get_threshold_violations(iroas, upper_bounds).isNotNull()
    return (
        reporting_df
        .withColumn("iroas_below_minimum", below_minimum)
        .withColumn("iroas_above_maximum", above_maximum)
    )


def calculate_iroas(
    incremental_sales: Column,
    media_spend: Column,
    nonpositive_spend_value: Optional[float] = None,
) -> Column:
    """Build incremental-sales / positive-spend iROAS as a Spark expression.

    Missing or nonpositive spend returns ``nonpositive_spend_value`` (null
    by default). Missing sales with positive spend remains null.
    """
    positive_spend = media_spend > 0
    return F.when(positive_spend, safe_ratio(incremental_sales, media_spend)).otherwise(
        F.lit(nonpositive_spend_value).cast("double"),
    )


def evaluate_brand_offer_sales(
    sales_df: DataFrame,
    decimal_places: Optional[int] = None,
) -> DataFrame:
    """
    Add ``offer_exceeds_brand`` and ``sales_equal`` comparison columns.

    Requires ``brand_sales`` and ``offer_sales``. Optional rounding replaces
    those values before comparison; missing sales retain null comparison flags.
    """
    comparison_sales = (
        sales_df
        .withColumn("brand_sales", F.round(F.col("brand_sales"), decimal_places))
        .withColumn("offer_sales", F.round(F.col("offer_sales"), decimal_places))
        if decimal_places is not None else sales_df
    )
    return (
        comparison_sales
        .withColumn("offer_exceeds_brand", F.col("offer_sales") > F.col("brand_sales"))
        .withColumn("sales_equal", F.col("brand_sales") == F.col("offer_sales"))
    )


def safe_ratio(numerator: Column, denominator: Column) -> Column:
    """Build guarded division, returning null for missing inputs or zero denominators.

    Negative denominators are permitted, preserving SQL ``NULLIF(value, 0)``.
    """
    return F.when(denominator != 0, numerator / denominator)


def evaluate_expected_value(
    reporting_df: DataFrame,
    actual_value: Column,
    expected_value: Column,
    result_column: str = "matches_expected_value",
) -> DataFrame:
    """Add a boolean comparison while preserving SQL null comparison semantics."""
    return reporting_df.withColumn(result_column, actual_value == expected_value)


def evaluate_incremental_sales(
    reporting_df: DataFrame,
    incremental: Column,
    attributed: Column,
    warning_threshold: Optional[float] = None,
    fail_on_equal: bool = False,
) -> DataFrame:
    """Add ``incremental_ratio``, ``incremental_breach`` and ``incremental_warning``.

    Inputs may be row-level or aggregated. ``fail_on_equal`` selects > or >=
    comparison; warnings use >= when configured and are disabled otherwise.
    Missing or zero attributed sales leave the ratio and configured warning null.
    """
    ratios = reporting_df.withColumn("incremental_ratio", safe_ratio(incremental, attributed))
    exceeds_attributed = incremental >= attributed if fail_on_equal else incremental > attributed
    exceeds_warning_share = (
        F.col("incremental_ratio") >= warning_threshold
        if warning_threshold is not None else F.lit(False)
    )
    return (
        ratios
        .withColumn("incremental_breach", exceeds_attributed)
        .withColumn("incremental_warning", exceeds_warning_share)
    )


def summarize_ratio_spread(
    reporting_df: DataFrame,
    numerator: Column,
    denominator: Column,
) -> DataFrame:
    """Return one row with ratio count, minimum, maximum and max/min spread.

    Ratios use guarded division before aggregation, not a ratio of summed
    inputs. Empty/null-only input has count zero; a zero minimum yields null spread.
    """
    ratios = reporting_df.withColumn("ratio", safe_ratio(numerator, denominator))
    stats = ratios.agg(
        F.count(F.col("ratio")).alias("value_count"),
        F.min(F.col("ratio")).alias("minimum_ratio"),
        F.max(F.col("ratio")).alias("maximum_ratio"),
    )
    return stats.withColumn(
        "spread", safe_ratio(F.col("maximum_ratio"), F.col("minimum_ratio")),
    )


def evaluate_conversion_rate_thresholds(
    reporting_df: DataFrame,
    thresholds: Mapping[str, ThresholdBounds],
    positive_only: bool = False,
    trim_marketing_type: bool = True,
) -> DataFrame:
    """Add breached-limit and boolean flags for marketing-type conversion rates.

    Requires ``conversion_rate`` and ``marketing_type``; rates are cast to double.
    Threshold keys must be lowercase. Output adds ``marketing_type_lower``,
    ``threshold_value`` and ``is_breach``; unknown types are nonbreaching.
    Null rates are excluded; ``positive_only`` also excludes rates <= 0.
    Disable trimming for SQL UPPER-only matching. No aggregation is performed.
    """
    marketing_type = F.col("marketing_type")
    if trim_marketing_type:
        marketing_type = F.trim(marketing_type)
    normalized_rates = (
        reporting_df
        .withColumn("conversion_rate", F.col("conversion_rate").cast("double"))
        .withColumn("marketing_type_lower", F.lower(marketing_type))
    )
    rate = F.col("conversion_rate")
    eligible_rate = rate.isNotNull()
    if positive_only:
        eligible_rate = eligible_rate & (rate > 0)
    eligible_rates = normalized_rates.filter(eligible_rate)

    breached_thresholds = []
    for marketing_type_name, bounds in thresholds.items():
        matches_type = F.col("marketing_type_lower") == marketing_type_name
        breached_thresholds.append(
            F.when(matches_type, get_threshold_violations(rate, bounds))
        )

    return (
        eligible_rates
        .withColumn("threshold_value", F.coalesce(*breached_thresholds, F.lit(None).cast("double")))
        .withColumn("is_breach", F.col("threshold_value").isNotNull())
    )
