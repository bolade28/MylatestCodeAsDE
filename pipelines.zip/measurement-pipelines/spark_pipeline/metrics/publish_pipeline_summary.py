from typing import List, Optional

from pyspark.sql import SparkSession

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import Severity
from spark_pipeline.metrics.pipeline_summary.input_layer_summary import (
    _filter_by_booking_id_if_present,
    input_layer_summary,
)
from spark_pipeline.metrics.pipeline_summary.incrementality_layer_summary import (
    incrementality_layer_summary,
)
from spark_pipeline.metrics.pipeline_summary.mta_layer_summary import (
    mta_layer_summary,
)
from spark_pipeline.utils.mta_events import PipelineSummaryMetrics
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.publish_metrics import MetricsPublisher
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.utils.stdout_logger import get_stdout_logger


def publish_pipeline_summary(
    spark: SparkSession,
    baseline_modelling_dataset_path: str,
    feature_prioritisation_path: str,
    incremental_shrinkage_path: str,
    calibration_audit_path: str,
    ucm_output_data_path: str,
    ucm_base_data_path: str,
    metrics_topic_arn: str,
    slack_topic_arn: str,
    correlation_id: str,
    user_journey_offer_path: str,
    user_journey_brand_path: str,
    attribution_model_results_path: str,
    sku_level_attributed_sales_offer_path: str,
    sku_level_attributed_sales_brand_path: str,
    unified_campaign_path: Optional[str] = None,
    campaign_product_type_path: Optional[str] = None,
    campaign_booking_media_channel_path: Optional[str] = None,
    booking_id: Optional[str] = None,
    severity: Severity = Severity.HIGH,
) -> None:
    """Publish input-layer, incrementality-layer, and MTA-layer pipeline summary metrics to SNS.

    Reads campaign-details, incrementality, and MTA inputs, computes all summary
    DataFrames, unions them, and publishes each row as a
    :class:`PipelineSummaryMetrics` event to the SNS metrics topic.
    A Slack notification is sent on completion (or on failure).

    Args:
        spark: SparkSession object.
        unified_campaign_path: S3 path for unified campaign data.
        campaign_product_type_path: S3 path for campaign product type data.
        baseline_modelling_dataset_path: S3 path for the baseline modelling dataset.
        campaign_booking_media_channel_path: S3 path for campaign booking media channel data.
        booking_id: Booking ID used to scope campaign-details metrics.
        feature_prioritisation_path: S3 path for the feature-prioritisation output.
        incremental_shrinkage_path: S3 path for the calibration (incremental shrinkage) output.
        calibration_audit_path: S3 path for the calibration audit output.
        ucm_output_data_path: S3 path for the UCM output data.
        ucm_base_data_path: S3 path for the UCM base data.
        metrics_topic_arn: ARN of the SNS topic to publish metrics events to.
        slack_topic_arn: ARN of the SNS topic to publish Slack notifications to.
        correlation_id: Correlation ID for tracing the pipeline run.
        user_journey_offer_path: S3 path for the offer-level user journey data.
        user_journey_brand_path: S3 path for the brand-level user journey data.
        attribution_model_results_path: S3 path for the Attribution Model Result data.
        sku_level_attributed_sales_offer_path: S3 path for the SKU-level attributed sales offer data.
        sku_level_attributed_sales_brand_path: S3 path for the SKU-level attributed sales brand data.
        severity: Alert severity level applied to all summaries (default ``Severity.HIGH``).
    """
    logger = get_stdout_logger()

    should_build_campaign_details = all([
        unified_campaign_path,
        campaign_product_type_path,
        campaign_booking_media_channel_path,
        booking_id,
    ])

    logger.info(
        (
            "Starting pipeline summary publish "
            f"for correlation_id={correlation_id}, booking_id={booking_id}"
        ),
        log_type="publish_pipeline_summary",
    )

    campaign_details_summary_df = None
    modelling_df = load_parquet_dataset(spark, baseline_modelling_dataset_path, "baseline_modelling_dataset")
    if should_build_campaign_details and booking_id is not None:
        unified_campaign_df = load_parquet_dataset(
            spark=spark,
            path=unified_campaign_path,
            dataset_name="unified_campaign",
            columns=[
                "campaign_id",
                "booking_id",
                "campaign_start_dt",
                "campaign_end_dt",
                "post_campaign_dt",
                "subchannel_name",
                "media_spend_amt",
                "unique_brand_name",
                "super_category_name",
            ],
        )
        unified_campaign_df = _filter_by_booking_id_if_present(unified_campaign_df, booking_id)

        product_details_raw_df = load_parquet_dataset(
            spark=spark,
            path=campaign_product_type_path,
            dataset_name="campaign_product_type",
        )
        product_details_raw_df = _filter_by_booking_id_if_present(product_details_raw_df, booking_id)

        modelling_df = _filter_by_booking_id_if_present(modelling_df, booking_id)

        campaign_booking_media_channel_raw_df = load_parquet_dataset(
            spark=spark,
            path=campaign_booking_media_channel_path,
            dataset_name="campaign_booking_media_channel",
            columns=["campaign_id", "booking_id", "store_cd_list"],
        )
        campaign_booking_media_channel_raw_df = _filter_by_booking_id_if_present(
            campaign_booking_media_channel_raw_df,
            booking_id,
        )

        campaign_details_summary_df = input_layer_summary(
            unified_campaign_df=unified_campaign_df,
            product_details_raw_df=product_details_raw_df,
            baseline_modelling_dataset_df=modelling_df,
            campaign_booking_media_channel_raw_df=campaign_booking_media_channel_raw_df,
            booking_id=booking_id,
            correlation_id=correlation_id,
            severity=severity,
        )

    fp_df = load_parquet_dataset(spark, feature_prioritisation_path, "feature_prioritisation")
    calibration_df = load_parquet_dataset(spark, incremental_shrinkage_path, "incremental_shrinkage")
    calibration_audit_df = load_parquet_dataset(spark, calibration_audit_path, "calibration_audit")
    ucm_output_data_df = load_parquet_dataset(spark, ucm_output_data_path, "ucm_output_data")
    ucm_base_data_df = load_parquet_dataset(spark, ucm_base_data_path, "ucm_base_data")

    logger.info(
        "All input datasets loaded successfully",
        log_type="publish_pipeline_summary",
    )

    incrementality_summary_df = incrementality_layer_summary(
        modelling_df=modelling_df,
        fp_df=fp_df,
        calibration_df=calibration_df,
        calibration_audit_df=calibration_audit_df,
        ucm_output_data_df=ucm_output_data_df,
        ucm_base_data_df=ucm_base_data_df,
        correlation_id=correlation_id,
        severity=severity,
    )

    offer_adg_df = load_parquet_dataset(
        spark=spark,
        path=user_journey_offer_path,
        dataset_name="user_journey_offer",
        columns=[
            "booking_id",
            "loyalty_id",
            "channel_name",
            "subchannel_name",
            "userjourney_id",
            "transaction_key",
            "net_sales_amt",
        ],
    )
    brand_adg_df = load_parquet_dataset(
        spark=spark,
        path=user_journey_brand_path,
        dataset_name="user_journey_brand",
        columns=[
            "booking_id",
            "loyalty_id",
            "channel_name",
            "subchannel_name",
            "userjourney_id",
            "transaction_key",
            "net_sales_amt",
        ],
    )
    mta_result_df = load_parquet_dataset(
        spark=spark,
        path=attribution_model_results_path,
        dataset_name="attribution_model_results",
        columns=["journey_type", "channel_name", "subchannel_name", "normalized_weights"],
    )
    sku_level_attributed_sales_offer_df = load_parquet_dataset(
        spark=spark,
        path=sku_level_attributed_sales_offer_path,
        dataset_name="sku_level_attributed_sales_offer",
        columns=["attributed_sales_amt"],
    )
    sku_level_attributed_sales_brand_df = load_parquet_dataset(
        spark=spark,
        path=sku_level_attributed_sales_brand_path,
        dataset_name="sku_level_attributed_sales_brand",
        columns=["attributed_sales_amt"],
    )

    mta_summary_df = mta_layer_summary(
        offer_adg_df=offer_adg_df,
        brand_adg_df=brand_adg_df,
        mta_result_df=mta_result_df,
        sku_level_attributed_sales_offer_df=sku_level_attributed_sales_offer_df,
        sku_level_attributed_sales_brand_df=sku_level_attributed_sales_brand_df,
        correlation_id=correlation_id,
        severity=severity,
    )

    summary_frames = [incrementality_summary_df]
    if campaign_details_summary_df is not None:
        summary_frames.insert(0, campaign_details_summary_df)
    summary_frames.append(mta_summary_df)

    summary_df = summary_frames[0]
    for next_summary_df in summary_frames[1:]:
        summary_df = summary_df.unionByName(next_summary_df, allowMissingColumns=True)

    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)
    slack_messenger = SlackMessenger(topic_arn=slack_topic_arn, correlation_id=correlation_id)

    errors: List[str] = []
    published_count = 0

    for row in summary_df.toLocalIterator():
        try:
            row_dict = row.asDict(recursive=True)
            event_kwargs = {
                "correlation_id": row_dict["correlation_id"],
                "name": str(row_dict["name"]),
                "data_group": row_dict["data_group"],
                "data_sources": row_dict["data_sources"],
                "severity": row_dict["severity"],
                "metadata": str(row_dict["metadata"]),
            }

            if row_dict.get("load_timestamp") is not None:
                event_kwargs["load_timestamp"] = str(row_dict["load_timestamp"])

            event = PipelineSummaryMetrics(**event_kwargs)
            publisher.publish_event(
                message_subject="Pipeline Summary Metrics Event",
                event=event,
            )
            published_count += 1
        except Exception as publish_error:
            row_name = row_dict.get("name") if "row_dict" in locals() else None
            error_msg = f"Failed to publish row name={row_name}: {publish_error}"
            logger.error(error_msg, log_type="publish_pipeline_summary")
            errors.append(error_msg)

    logger.info(
        f"Published {published_count} pipeline summary metric(s) for correlation_id={correlation_id}",
        log_type="publish_pipeline_summary",
    )

    if errors:
        slack_messenger.send_message(
            event_type="Pipeline Summary — Publish Errors",
            data={
                "status": "Some pipeline summary metrics failed to publish",
                "published_count": published_count,
                "error_count": len(errors),
                "errors": errors,
                "correlation_id": correlation_id,
            },
        )
    else:
        slack_messenger.send_message(
            event_type="Pipeline Summary — Published",
            data={
                "status": "All pipeline summary metrics published successfully",
                "published_count": published_count,
                "correlation_id": correlation_id,
            },
        )


def entrypoint(
    spark: SparkSession,
    command_line_args: Optional[List[str]] = None,
) -> None:
    """Command-line entrypoint for publishing unified pipeline summary metrics.

    Args:
        spark: SparkSession object.
        command_line_args: Optional command-line arguments for testing.
    """
    parser = ThrowingArgumentParser(
        description="Publish unified pipeline summary metrics to Grafana via SNS."
    )
    parser.add_argument(
        "--unified-campaign-path",
        type=str,
        required=True,
        help="S3 path for unified campaign data.",
    )
    parser.add_argument(
        "--campaign-product-type-path",
        type=str,
        required=True,
        help="S3 path for campaign product type data.",
    )
    parser.add_argument(
        "--baseline-modelling-dataset-path",
        type=str,
        required=True,
        help="S3 path for the baseline modelling dataset.",
    )
    parser.add_argument(
        "--campaign-booking-media-channel-path",
        type=str,
        required=True,
        help="S3 path for campaign booking media channel data.",
    )
    parser.add_argument(
        "--booking-id",
        type=str,
        required=True,
        help="Booking ID to scope campaign-details metrics.",
    )
    parser.add_argument(
        "--feature-prioritisation-path",
        type=str,
        required=True,
        help="S3 path for the feature-prioritisation output.",
    )
    parser.add_argument(
        "--incremental-shrinkage-path",
        type=str,
        required=True,
        help="S3 path for the calibration (incremental shrinkage) output.",
    )
    parser.add_argument(
        "--calibration-audit-path",
        type=str,
        required=True,
        help="S3 path for the calibration audit output.",
    )
    parser.add_argument(
        "--ucm-output-data-path",
        type=str,
        required=True,
        help="S3 path for the UCM output data.",
    )
    parser.add_argument(
        "--ucm-base-data-path",
        type=str,
        required=True,
        help="S3 path for the UCM base data.",
    )
    parser.add_argument(
        "--metrics-topic-arn",
        type=str,
        required=True,
        help="ARN of the SNS topic to publish metrics events to.",
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="ARN of the SNS topic to publish Slack notifications to.",
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for the pipeline run.",
    )
    parser.add_argument(
        "--user-journey-offer-path",
        type=str,
        required=True,
        help="S3 path for the offer-level user journey data.",
    )
    parser.add_argument(
        "--user-journey-brand-path",
        type=str,
        required=True,
        help="S3 path for the brand-level user journey data.",
    )
    parser.add_argument(
        "--attribution-model-results-path",
        type=str,
        required=True,
        help="S3 path for the Attribution Model Result data.",
    )
    parser.add_argument(
        "--sku-level-attributed-sales-offer-path",
        type=str,
        required=True,
        help="S3 path for the SKU-level attributed sales offer data.",
    )
    parser.add_argument(
        "--sku-level-attributed-sales-brand-path",
        type=str,
        required=True,
        help="S3 path for the SKU-level attributed sales brand data.",
    )

    args = parser.parse_args(command_line_args)

    publish_kwargs = {
        "spark": spark,
        "unified_campaign_path": args.unified_campaign_path,
        "campaign_product_type_path": args.campaign_product_type_path,
        "baseline_modelling_dataset_path": args.baseline_modelling_dataset_path,
        "campaign_booking_media_channel_path": args.campaign_booking_media_channel_path,
        "booking_id": args.booking_id,
        "feature_prioritisation_path": args.feature_prioritisation_path,
        "incremental_shrinkage_path": args.incremental_shrinkage_path,
        "calibration_audit_path": args.calibration_audit_path,
        "ucm_output_data_path": args.ucm_output_data_path,
        "ucm_base_data_path": args.ucm_base_data_path,
        "metrics_topic_arn": args.metrics_topic_arn,
        "slack_topic_arn": args.slack_topic_arn,
        "correlation_id": args.correlation_id,
        "user_journey_offer_path": args.user_journey_offer_path,
        "user_journey_brand_path": args.user_journey_brand_path,
        "attribution_model_results_path": args.attribution_model_results_path,
        "sku_level_attributed_sales_offer_path": args.sku_level_attributed_sales_offer_path,
        "sku_level_attributed_sales_brand_path": args.sku_level_attributed_sales_brand_path,
    }

    publish_pipeline_summary(
        **publish_kwargs,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("PublishPipelineSummary").getOrCreate())  # NOSONAR pythonenterprise:S7471
