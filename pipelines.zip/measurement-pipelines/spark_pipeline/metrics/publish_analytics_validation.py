from typing import List, Optional

from pyspark.sql import SparkSession

from pyspark.sql import functions as F

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.metrics.qa_validation_metrics.analytics_validation_metrics.analytics_validation_metrics import (
    run_analytics_validation_checks,
)
from spark_pipeline.utils.mta_events import QAChecksMetric
from spark_pipeline.utils.publish_metrics import MetricsPublisher
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite
from spark_pipeline.utils.stdout_logger import get_stdout_logger


def publish_analytics_validation(
    spark: SparkSession,
    measurement_campaign_reporting_path: str,
    campaign_period: str,
    correlation_id: str,
    metrics_topic_arn: str,
    output_path: str,
) -> None:
    """
    Run analytics checks, persist and publish QA rows.
    The current checks use measurement campaign reporting.
    """

    logger = get_stdout_logger()
    logger.info(
        f"Reading measurement campaign reporting from: {measurement_campaign_reporting_path}",
        log_type="analytics_validation",
    )
    reporting_df = (
        spark
        .read
        .parquet(measurement_campaign_reporting_path)
        .withColumn("journey_type", F.upper("journey_type"))
        .select(
            "correlation_id",
            "campaign_duration",
            "booking_id",
            "campaign_id",
            "journey_type",
            "channel_name",
            "subchannel_name",
            "marketing_type",
            "attributed_recalibrated_sales_amt",
            "conversion_rate",
            "roas_exposed",
            "iroas_exposed",
            "uplift_exposed_sales_amt",
            "media_spend_amt",
            "incremental_sales_amt_exposed",
            "base_sales_amt_exposed",
        )
    )
    validation_results = run_analytics_validation_checks(
        reporting_df,
        correlation_id=correlation_id,
        campaign_period=campaign_period,
    )
    try:
        results = (
            validation_results
            .select(
                "correlation_id",
                "type",
                "name",
                "expected_value",
                "outcome",
                "details",
                "additional_metadata",
                "load_timestamp"
            )
        ).cache()

        publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

        try:
            spark_s3_overwrite(output_path, results)
            for row in results.collect():
                fields = row.asDict()
                fields["load_timestamp"] = str(fields.pop("load_timestamp"))
                publisher.publish_event(
                    message_subject="Analytics Validation Metric Event",
                    event=QAChecksMetric(**fields),
                )
        finally:
            results.unpersist()
    finally:
        validation_results.unpersist()

    logger.info(
        f"Published analytics validation checks for correlation_id={correlation_id}",
        log_type="analytics_validation",
    )


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Publish analytics validation metrics.")
    parser.add_argument("--measurement-campaign-reporting-path", type=str, required=True)
    parser.add_argument("--campaign-period", type=str, required=True, choices=("During", "Post"))
    parser.add_argument("--correlation-id", type=str, required=True)
    parser.add_argument("--metrics-topic-arn", type=str, required=True)
    parser.add_argument(
        "--output-path", type=str, required=True,
        help="S3 path for the per-check analytics validation output.",
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    publish_analytics_validation(
        spark=spark,
        measurement_campaign_reporting_path=known_args.measurement_campaign_reporting_path,
        campaign_period=known_args.campaign_period,
        correlation_id=known_args.correlation_id,
        metrics_topic_arn=known_args.metrics_topic_arn,
        output_path=known_args.output_path,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("PublishAnalyticsValidation").getOrCreate())
