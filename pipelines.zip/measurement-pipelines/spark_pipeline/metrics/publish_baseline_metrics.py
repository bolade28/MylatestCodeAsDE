from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame, functions as F, SparkSession

from spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage_helper import get_incrementality
from spark_pipeline.common.variables import BaselineModellingShrinkageConfig
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser, str_to_bool
from spark_pipeline.utils.baseline_events import CampaignMetrics, UCMIncrementalityMetrics
from spark_pipeline.utils.pipeline_utils import json_safe, collect_distinct_values
from spark_pipeline.utils.publish_metrics import MetricsPublisher


def build_incrementality_metadata(campaign_selection_df: DataFrame) -> Dict[str, Any]:
    """
    Build a compact JSON metadata payload attached to every UCM incrementality event.

    Hierarchy data such as super/sub category is available in the measurement
    campaign reporting table, which we can join to via the correlation ID, so we
    don't include it in the metadata.

    Args:
        campaign_selection_df: Dataframe containing the campaign details for the specific run

    Returns:
        JSON-serialisable metadata dictionary ready for SNS publishing and JSONB persistence.
    """
    aggregate_exprs = [
        F.countDistinct("unique_brand_name").alias("unique_brand_count"),
        F.min("min_campaign_start_dt").alias("min_campaign_start_dt"),
        F.max("max_campaign_end_dt").alias("max_campaign_end_dt"),
        F.max("max_post_campaign_dt").alias("max_post_campaign_dt"),
    ]

    aggregate_row = campaign_selection_df.agg(*aggregate_exprs).first().asDict()

    metadata = {
        "unique_brand_count": aggregate_row.get("unique_brand_count"),
        "unique_brand_names": collect_distinct_values(campaign_selection_df, "unique_brand_name"),
        # Date boundaries serialised to ISO-8601 strings via json_safe so json.dumps doesn't raise a TypeError
        "min_campaign_start_dt": json_safe(aggregate_row.get("min_campaign_start_dt")),
        "max_campaign_end_dt": json_safe(aggregate_row.get("max_campaign_end_dt")),
        "max_post_campaign_dt": json_safe(aggregate_row.get("max_post_campaign_dt")),
    }

    return metadata


def get_baseline_ucm_incrementality(
    spark: SparkSession,
    campaign_selection_df: DataFrame,
    baseline_modelling_output_path: str,
) -> Optional[float]:
    """
    Calculate the raw UCM incrementality summed over the full campaign booking window.

    Reads the baseline modelling output, filters to the best iteration only, then
    delegates to 'get_incrementality' from the UCM calibration script with incremental_type='all' to sum
    'TOTAL_INCREMENTAL_AMT' across all weeks that fall within the campaign dates.

    Args:
        spark: Active SparkSession.
        campaign_selection_df: Dataframe containing the campaign details for the specific run including the campaign booking widow
        baseline_modelling_output_path: S3 path to the baseline modelling output parquet.

    Returns:
        Total incremental sales as a Python float, or None if unavailable.
    """
    # Guard: date columns are required to define the booking window for the UCM filter.
    required_columns = {"min_campaign_start_dt", "max_campaign_end_dt"}
    if not required_columns.issubset(set(campaign_selection_df.columns)):
        return None

    config = BaselineModellingShrinkageConfig()

    baseline_modelling_output_df = (
        spark.read.parquet(baseline_modelling_output_path)
        .filter(F.col("best_iteration") == "Y")  # Only the best iteration contributes to incrementality.
        .select(
            "week_start_dt",
            "metric_name",
            "metric_value",
        )
    )

    total_incrementality = get_incrementality(
        campaign_facts=campaign_selection_df.select("min_campaign_start_dt", "max_campaign_end_dt"),
        baseline_modelling_output=baseline_modelling_output_df,
        incremental_type="all",
        bypass_marketing_types=[],  # No bypass channels, we want the full UCM output.
        config=config,
    )

    metric_value = total_incrementality.first()["incrementality"]
    return float(metric_value) if metric_value is not None else None


def get_incremental_shrinkage_metric_total(
    spark: SparkSession,
    incremental_shrinkage_output_path: str,
    metric_name: str,
) -> Optional[float]:
    """
    Aggregate named metric values from the incremental shrinkage output.

    Args:
        spark: Active SparkSession.
        incremental_shrinkage_output_path: S3 path to the incremental shrinkage output parquet.
        metric_name: The 'metric_name' value to filter on (e.g. 'calibrated_incrementality' or 'ucm_incrementality').

    Returns:
        Summed metric value as a Python float, or None if no matching rows found.
    """
    metric_value = (
        spark.read.parquet(incremental_shrinkage_output_path)
        .filter(F.col("metric_name") == metric_name)
        .agg(F.sum("metric_value").alias("metric_value"))
        .first()["metric_value"]
    )

    return float(metric_value) if metric_value is not None else None


def publish_baseline_metrics(
    spark: SparkSession,
    campaign_selection_path: str,
    baseline_modelling_output_path: str,
    incremental_shrinkage_output_path: str,
    metrics_topic_arn: str,
    correlation_id: str,
    unified_campaign_path: str,
    manual_campaign_list: Optional[List[str]] = None,
    manual_run_flag: bool = False,
) -> None:
    """
    Publish campaign-selection metrics and UCM incrementality metrics to SNS.

    1. Campaign selection metrics
       - Count of unique brand names and super categories.
       - Manual run diagnostics (when ``manual_run_flag`` is ``True``).

    2. UCM incrementality metric
       - 'ucm_incrementality': raw UCM total from baseline modelling output.
       - 'calibrated_incrementality': calibrated value from shrinkage output.
       - 'raw_incrementality_from_calibration': raw pre-calibration value from shrinkage output.
       Each event carries a shared metadata payload built from the campaign selection data.

    Note:
        I've removed Per-status campaign counts (CLUSTERING, REFACTORING, NEW_LAUNCH, NEW_LAUNCH_WITH_NO_SALES).
        As we don't separate them any more, currently the only status is CLUSTERING

    Args:
        spark (SparkSession): The Spark session.
        campaign_selection_path (str): The S3 path for the campaign selection.
        baseline_modelling_output_path: S3 path to the baseline modelling output parquet
            used to derive the raw UCM incrementality value.
        incremental_shrinkage_output_path: S3 path to the incremental shrinkage output
            parquet used to derive calibrated and raw calibration incrementality values.
        metrics_topic_arn (str): The ARN for the SNS topic to publish metrics.
        correlation_id (str): The correlation ID for the run.
        unified_campaign_path: S3 path to the unified campaigns parquet, used only when
            ``manual_run_flag`` is ``True``.
        manual_campaign_list: List of campaign IDs provided for a manual run.
            Only used when ``manual_run_flag`` is ``True``.
        manual_run_flag: When ``True``, publishes metrics comparing the
            manually provided campaign list against what was found in unified campaigns.
    """
    campaign_selection_df = (
        spark
        .read
        .parquet(campaign_selection_path)
        .select(
            "unique_brand_name",
            "super_category_name",
            "final_status",
            "product_type",
            "min_campaign_start_dt",
            "max_campaign_end_dt",
            "max_post_campaign_dt",
        )
    )

    campaign_selection_df = campaign_selection_df.cache()  # SonarQube static parser wasn't catching this was cached, so separated it out

    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

    unique_brand_name = CampaignMetrics(
        correlation_id=correlation_id,
        name="unique_brand_names",
        value=campaign_selection_df.select(F.countDistinct("unique_brand_name")).first()[0]
    )

    publisher.publish_event(
        message_subject="Campaign Metrics Event",
        event=unique_brand_name
    )

    unique_super_category = CampaignMetrics(
        correlation_id=correlation_id,
        name="unique_super_category",
        value=campaign_selection_df.select(F.countDistinct("super_category_name")).first()[0]
    )

    publisher.publish_event(
        message_subject="Campaign Metrics Event",
        event=unique_super_category
    )

    if manual_run_flag:
        unified_campaign_df = (
            spark
            .read
            .parquet(unified_campaign_path)
            .select(
                "job_bag_number",
            )
        )

        manually_provided_campaigns = (
            unified_campaign_df
            .filter(
                F.col('job_bag_number').isin(manual_campaign_list))
            .select(
                "job_bag_number",
            )
        )

        num_of_campaigns_provided_manually = CampaignMetrics(
            correlation_id=correlation_id,
            name="num_of_campaigns_provided_manually",
            value=len(manual_campaign_list) if manual_campaign_list else 0
        )

        publisher.publish_event(
            message_subject="Campaign Metrics Event",
            event=num_of_campaigns_provided_manually
        )

        num_of_campaigns_found_in_unified_campaigns = CampaignMetrics(
            correlation_id=correlation_id,
            name="num_of_manual_campaigns_found_in_unified_campaigns",
            value=manually_provided_campaigns.select(F.countDistinct("job_bag_number")).first()[0]
        )

        publisher.publish_event(
            message_subject="Campaign Metrics Event",
            event=num_of_campaigns_found_in_unified_campaigns
        )

        is_this_a_manual_campaign_run = CampaignMetrics(
            correlation_id=correlation_id,
            name="is_this_a_manual_campaign_run",
            int_value=1 if manual_run_flag else 0,
            type='yes'
        )

        publisher.publish_event(
            message_subject="Campaign Metrics Event",
            event=is_this_a_manual_campaign_run
        )

    # --- UCM incrementality metrics ---
    # Build one shared metadata payload so every related event carries the same
    # campaign context; this makes it easy to correlate events downstream.
    incrementality_metadata = build_incrementality_metadata(campaign_selection_df)

    # Creates exactly three rows per correlation id
    incrementality_metrics = [
        (
            # Raw incrementality derived directly from baseline modelling UCM output.
            "ucm_incrementality",
            get_baseline_ucm_incrementality(
                spark=spark,
                campaign_selection_df=campaign_selection_df,
                baseline_modelling_output_path=baseline_modelling_output_path,
            ),
        ),
        (
            # Calibrated value output from the incremental shrinkage calibration step.
            "calibrated_incrementality",
            get_incremental_shrinkage_metric_total(
                spark=spark,
                incremental_shrinkage_output_path=incremental_shrinkage_output_path,
                metric_name="calibrated_incrementality",
            ),
        ),
        (
            # Raw pre-calibration incrementality recorded by the shrinkage step, this may differ to the raw output from baseline modelling due to differences in filtering and aggregation logic, so it's worth tracking as a separate metric.
            "raw_incrementality_from_calibration",
            get_incremental_shrinkage_metric_total(
                spark=spark,
                incremental_shrinkage_output_path=incremental_shrinkage_output_path,
                metric_name="ucm_incrementality",
            ),
        ),
    ]

    # Only publish events for metrics that resolved to a non-null value;
    # If a value doesn't exist, it indicates a problem in the upstream pipeline (e.g. missing input data, or a failed modelling/shrinkage step)
    for metric_name, metric_value in incrementality_metrics:
        if metric_value is None:
            continue

        publisher.publish_event(
            message_subject="UCM Incrementality Metrics Event",
            event=UCMIncrementalityMetrics(
                correlation_id=correlation_id,
                name=metric_name,
                value=metric_value,
                metadata=incrementality_metadata,
            )
        )


def entrypoint(spark: SparkSession,
               command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(
        description="Prepare Meta processed data for baseline pipeline.")
    parser.add_argument(
        "--campaign-selection-path",
        type=str,
        required=True,
        help="The S3 path for the campaign selection."
    )
    parser.add_argument(
        "--baseline-modelling-output-path",
        type=str,
        required=True,
        help="The S3 path for baseline modelling output used to calculate raw UCM incrementality."
    )
    parser.add_argument(
        "--incremental-shrinkage-output-path",
        type=str,
        required=True,
        help="The S3 path for incremental shrinkage output used to publish calibrated incrementality metrics."
    )
    parser.add_argument(
        "--metrics-topic-arn",
        type=str,
        required=True,
        help="The ARN for the SNS topic to publish metrics."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="The correlation ID for the run."
    )
    parser.add_argument(
        "--manual-campaign-list",
        type=str,
        required=False,
        help="List of manually provided campaigns"
    )
    parser.add_argument(
        "--unified-campaign-path",
        type=str,
        required=True,
        help="The S3 path for the unified campaigns."
    )
    parser.add_argument(
        "--manual-run-flag",
        type=str,
        required=False,
        help="Flag to indicate manual run"
    )

    known_args, _ = parser.parse_known_args(command_line_args)
    campaign_list = [x.strip() for x in (known_args.manual_campaign_list or "").split(",") if x.strip()]

    publish_baseline_metrics(
        spark=spark,
        campaign_selection_path=known_args.campaign_selection_path,
        baseline_modelling_output_path=known_args.baseline_modelling_output_path,
        incremental_shrinkage_output_path=known_args.incremental_shrinkage_output_path,
        metrics_topic_arn=known_args.metrics_topic_arn,
        correlation_id=known_args.correlation_id,
        unified_campaign_path=known_args.unified_campaign_path,
        manual_campaign_list=campaign_list,
        manual_run_flag=str_to_bool(known_args.manual_run_flag)
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder.appName("PublishBaselineMetrics").getOrCreate())
