from typing import List, Optional

from pyspark.sql import SparkSession

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.metrics.campaign_reporting_metrics import (
    publish_campaign_reporting_metrics,
)
from spark_pipeline.metrics.reach_engagement_metrics import (
    publish_reach_engagement_detail_metrics,
)
from spark_pipeline.utils.slack_utils import SlackMessenger


def publish_mta_metrics(
    spark: SparkSession,
    measurement_campaign_reporting_path: str,
    reach_engagement_detail_path: str,
    correlation_id: str,
    slack_topic_arn: str,
    run_date: str,
    metrics_topic_arn: str
) -> None:
    """

    This is to publish MTA metrics on campaign performance using the output from the measurement campaign reporting.
    Args:
        spark : The Spark session.
        measurement_campaign_reporting_path: The S3 path for the measurement campaign reporting.
        reach_engagement_detail_path: The S3 path for the reach engagement reporting output.
        correlation_id : The correlation ID for the run.
        slack_topic_arn : The ARN for the Slack topic to publish metrics.
        run_date : The run date for the metrics.
        metrics_topic_arn : The ARN for the SNS topic to publish metrics.
    """
    measurement_campaign_reporting_df = (
        spark
        .read
        .parquet(measurement_campaign_reporting_path)
        .select(
            "correlation_id",
            "campaign_id",
            "booking_id",
            "campaign_duration",
            "journey_type",
            "marketing_type",
            "channel_name",
            "subchannel_name",
            "sub_category_name",
            "attributed_conversions",
            "incremental_sales_amt_exposed",
            "super_category_name",
            "campaign_name",
            "attributed_recalibrated_sales_amt",
            "attributed_recalibrated_units_qty",
            "incremental_units_qty_exposed",
            "attributed_units_qty",
            "attributed_sales_amt",
            "conversions_recalibrated",
            "recalibration_factor",
            "job_bag_number",
            "nectar_sales_amt",
            "non_nectar_sales_amt",
            "media_spend_amt",
            "campaign_type",
            "roas_exposed",
            "iroas_exposed",
            "base_sales_amt_exposed",
            "uplift_exposed_sales_amt",
            "uplift_exposed_units_qty",
            "num_user_journeys",
            "num_conversions",
            "attributed_recalibrated_sales_amt_per_uj",
            "attributed_recalibrated_sales_amt_per_conversion",
            "conversion_per_uj",
            "conversion_rate",
            "load_ts",
        )
    )
    reach_engagement_detail_df = (
        spark
        .read
        .parquet(reach_engagement_detail_path)
        .select(
            "campaign_id",
            "channel_name",
            "subchannel_name",
            "marketing_type",
            "booking_id",
            "reach_cnt",
            "dedup_campaign_reach",
            "clicks_cnt",
            "impressions_cnt",
            "sales_amt",
            "conversions_cnt",
            "media_spend_amt",
            "engagement_ctr_pct",
            "load_ts",
            "job_run_id",
        )
    )

    measurement_campaign_reporting_rows = publish_campaign_reporting_metrics(
        measurement_campaign_reporting_df=measurement_campaign_reporting_df,
        metrics_topic_arn=metrics_topic_arn,
    )

    measurement_reach_engagement_detail_rows = publish_reach_engagement_detail_metrics(
        reach_engagement_detail_df=reach_engagement_detail_df,
        metrics_topic_arn=metrics_topic_arn,
        correlation_id=correlation_id,
    )

    print(
        "Published MTA metrics. "
        f"measurement_campaign_reporting={measurement_campaign_reporting_rows}, "
        f"measurement_booking_reach_engagement_detail={measurement_reach_engagement_detail_rows}"
    )

    slack_messenger = SlackMessenger(
        topic_arn=slack_topic_arn,
        correlation_id=correlation_id
    )

    slack_messenger.send_message(
        event_type='MTA Metrics Status',
        data={
            "Total rows generated for measurement campaign reporting": measurement_campaign_reporting_rows,
            "Total rows generated for measurement booking reach engagement detail": measurement_reach_engagement_detail_rows,
            "run_date": run_date,
        }
    )


def entrypoint(
        spark: SparkSession,
        command_line_args: Optional[List[str]] = None
) -> None:
    parser = ThrowingArgumentParser(
        description="Prepare Meta processed data for baseline pipeline.")
    parser.add_argument(
        "--measurement-campaign-reporting-path",
        type=str,
        required=True,
        help="The S3 path for the measurement campaign reporting."
    )
    parser.add_argument(
        "--reach-engagement-detail-path",
        type=str,
        required=True,
        help="The S3 path for the reach engagement reporting output."
    )
    parser.add_argument(
        "--metrics-topic-arn",
        type=str,
        required=True,
        help="The ARN for the SNS topic to publish metrics."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="The correlation ID for the run."
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN for the SNS topic to publish Slack notifications."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=False,
        help="The run date for the pipeline."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    publish_mta_metrics(
        spark=spark,
        measurement_campaign_reporting_path=known_args.measurement_campaign_reporting_path,
        reach_engagement_detail_path=known_args.reach_engagement_detail_path,
        metrics_topic_arn=known_args.metrics_topic_arn,
        correlation_id=known_args.correlation_id,
        slack_topic_arn=known_args.slack_topic_arn,
        run_date=known_args.run_date
    )

# TODO: tests to be added for this script


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("PublishMTAMetrics").getOrCreate())
