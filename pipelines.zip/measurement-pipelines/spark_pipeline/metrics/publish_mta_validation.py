"""
Orchestrator for all MTA validation metrics.

Results are published to an SNS metrics topic, where they can be seen in the metrics.mta_validation_check_upsert
PostgreSQL table consumed by Grafana and used for monitoring and alerting.
"""

from typing import List, Optional

from pyspark.sql import SparkSession, functions as F

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics import (
    check_channel_contribution_distribution,
    check_channel_sales_ratio,
    check_normalized_weight_distribution,
    check_roas_thresholds,
    publish_mta_validation_metrics as validate_and_publish_metrics,
    media_spend_check,
    check_incremental_sales_iroas,
)
from spark_pipeline.metrics.mta_validation_metrics.user_journey_validation_metrics import (
    publish_user_journey_validation_metric,
)
from spark_pipeline.metrics.mta_validation_metrics.validation_helpers import run_validation_check
from spark_pipeline.schemas.user_journey import UserJourney
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.utils.stdout_logger import get_stdout_logger


def publish_mta_validation_metrics(
        spark: SparkSession,
        attribution_model_results_path: str,
        measurement_campaign_reporting_path: str,
        unified_campaign_path: str,
        brand_journey_path: str,
        offer_journey_path: str,
        metrics_topic_arn: str,
        correlation_id: str,
        slack_topic_arn: str,
) -> None:
    """
    Entry point for publishing all MTA validation metrics.

    Reads attribution model results and measurement campaign reporting data,
    runs all validation checks, and publishes results to SNS for monitoring
    and alerting via Grafana.

    Args:
        spark: SparkSession object.
        attribution_model_results_path: S3 path to the attribution model results data.
        measurement_campaign_reporting_path: S3 path to the measurement campaign reporting data.
        unified_campaign_path: S3 path to the unified campaign data (used to resolve unique_brand_name).
        brand_journey_path: S3 path to the brand-only user journey data.
        offer_journey_path: S3 path to the offer-only user journey data.
        metrics_topic_arn: ARN of the SNS topic to publish metrics to.
        correlation_id: Correlation ID for tracing the pipeline run.
        slack_topic_arn: ARN of the SNS topic to publish Slack notifications to.
    """
    logger = get_stdout_logger()

    logger.info(
        f"Starting MTA validation metrics for correlation_id={correlation_id}",
        log_type="mta_validation_metrics",
    )

    logger.info(
        f"Reading attribution model results from: {attribution_model_results_path}",
        log_type="mta_validation_metrics",
    )

    attribution_df = (
        spark
        .read
        .parquet(attribution_model_results_path)
        .select(
            "userjourney_id",
            "normalized_weights",
            "isconversion",
            "channel_name",
            "job_run_id",
        )
        .filter("isconversion = 1")
        .cache()
    )

    logger.info(
        f"Reading measurement campaign reporting from: {measurement_campaign_reporting_path}",
        log_type="mta_validation_metrics",
    )

    measurement_campaign_reporting_df = (
        spark
        .read
        .parquet(measurement_campaign_reporting_path)
        .select(
            "booking_id",
            "campaign_id",
            "journey_type",
            "marketing_type",
            "channel_name",
            "subchannel_name",
            "conversion_rate",
            "recalibration_factor",
            "roas_exposed",
            "media_spend_amt",
            "attributed_sales_amt",
            "attributed_recalibrated_sales_amt",
            "attributed_recalibrated_units_qty",
            "conversions_recalibrated",
            "incremental_sales_amt_exposed",
            "job_bag_number",
            "load_ts",
        )
        .cache()
    )

    breach_counts = []

    # Findings list to accumulate any error messages from validation checks for Slack notification
    findings: List[str] = []

    brand_journey_df = load_parquet_dataset(
        spark, brand_journey_path, "brand_journey",
        fallback_schema=UserJourney.UserJourneySchema,
    )
    offer_journey_df = load_parquet_dataset(
        spark, offer_journey_path, "offer_journey",
        fallback_schema=UserJourney.UserJourneySchema,
    )
    unified_campaign_df = (
        spark.read.parquet(unified_campaign_path)
        .select("job_bag_number", "channel_name", "subchannel_name", "item_cd_list")
        .distinct()
    )

    check_0_breaches = run_validation_check(
        logger,
        findings,
        "Check 0: User Journey Validation",
        publish_user_journey_validation_metric,
        brand_journey_df=brand_journey_df,
        offer_journey_df=offer_journey_df,
        unified_campaign_df=unified_campaign_df,
        correlation_id=correlation_id,
        metrics_topic_arn=metrics_topic_arn,
        spark=spark,
        reporting_df=measurement_campaign_reporting_df,
    )
    breach_counts.append(check_0_breaches)

    check_1_breaches = run_validation_check(
        logger,
        findings,
        "Check 1: Conversion Rate and Recalibration Factor Validation",
        validate_and_publish_metrics,
        measurement_campaign_reporting_df=measurement_campaign_reporting_df,
        correlation_id=correlation_id,
        metrics_topic_arn=metrics_topic_arn,
    )
    breach_counts.append(check_1_breaches)

    check_2_breaches = run_validation_check(
        logger,
        findings,
        "Check 2: Normalized Weight Distribution",
        check_normalized_weight_distribution,
        attribution_df=attribution_df,
        correlation_id=correlation_id,
        metrics_topic_arn=metrics_topic_arn,
    )
    breach_counts.append(check_2_breaches)

    check_3_breaches = run_validation_check(
        logger,
        findings,
        "Check 3: Channel Sales Ratio Validation",
        check_channel_sales_ratio,
        measurement_campaign_reporting_df=measurement_campaign_reporting_df,
        correlation_id=correlation_id,
        metrics_topic_arn=metrics_topic_arn,
    )
    breach_counts.append(check_3_breaches)

    check_4_breaches = run_validation_check(
        logger,
        findings,
        "Check 4: Media Spend Validation",
        media_spend_check,
        measurement_campaign_reporting_df=measurement_campaign_reporting_df,
        correlation_id=correlation_id,
        metrics_topic_arn=metrics_topic_arn,
    )
    breach_counts.append(check_4_breaches)

    check_5_breaches = run_validation_check(
        logger,
        findings,
        "Check 5: Channel Contribution Distribution",
        check_channel_contribution_distribution,
        attribution_df=attribution_df,
        campaign_reporting_df=measurement_campaign_reporting_df,
        correlation_id=correlation_id,
        metrics_topic_arn=metrics_topic_arn,
    )
    breach_counts.append(check_5_breaches)

    check_6_breaches = run_validation_check(
        logger,
        findings,
        "Check 6: ROAS Threshold Validation",
        check_roas_thresholds,
        campaign_reporting_df=measurement_campaign_reporting_df,
        correlation_id=correlation_id,
        metrics_topic_arn=metrics_topic_arn,
    )
    breach_counts.append(check_6_breaches)

    incremental_sales_iroas_df = (
        measurement_campaign_reporting_df
        .select(
            "booking_id",
            "job_bag_number",
            "channel_name",
            "incremental_sales_amt_exposed",
            "attributed_recalibrated_sales_amt",
            "media_spend_amt",
        )
        .join(
            F.broadcast(
                spark
                .read
                .parquet(unified_campaign_path)
                .select("job_bag_number", "unique_brand_name")
                .distinct()
            ),
            on="job_bag_number",
            how="left",
        )
        .drop("job_bag_number", "booking_id")
    )

    check_7_breaches = run_validation_check(
        logger,
        findings,
        "Check 7: Incremental Sales and iROAS Validation",
        check_incremental_sales_iroas,
        campaign_reporting_df=incremental_sales_iroas_df,
        correlation_id=correlation_id,
        metrics_topic_arn=metrics_topic_arn,
    )
    breach_counts.append(check_7_breaches)

    # Sum of all the breach counts from all validation checks
    total_breaches = sum(breach_counts)

    # Clear cached DataFrames to free up memory
    attribution_df.unpersist()
    measurement_campaign_reporting_df.unpersist()

    slack_messenger = SlackMessenger(
        topic_arn=slack_topic_arn,
        correlation_id=correlation_id,
    )

    if findings or total_breaches > 0:
        slack_messenger.send_message(
            event_type="MTA Validation Metrics Breach Detected",
            data={
                "status": "Validation threshold breaches or errors detected",
                "total_breaches": total_breaches,
                "user_journey_validation_breaches": check_0_breaches,
                "conversion_rate_and_recalibration_factor_breaches": check_1_breaches,
                "normalized_weight_distribution_breaches": check_2_breaches,
                "channel_sales_ratio_breaches": check_3_breaches,
                "media_spend_breaches": check_4_breaches,
                "channel_contribution_distribution_breaches": check_5_breaches,
                "roas_threshold_breaches": check_6_breaches,
                "incremental_sales_iroas_breaches": check_7_breaches,
                "errors": findings,
                "correlation_id": correlation_id,
            },
        )
    else:
        slack_messenger.send_message(
            event_type="MTA Validation Metrics Status",
            data={
                "status": "Validation metrics published successfully - no breaches detected",
                "total_breaches": 0,
                "correlation_id": correlation_id,
            },
        )


def entrypoint(
        spark: SparkSession,
        command_line_args: Optional[List[str]] = None,
) -> None:
    """
    Command-line entrypoint for publishing MTA validation metrics.

    Args:
        spark: SparkSession object.
        command_line_args: Optional command-line arguments for testing.
    """
    parser = ThrowingArgumentParser(
        description="Publish MTA validation metrics for monitoring and alerting."
    )
    parser.add_argument(
        "--attribution-model-results-path",
        type=str,
        required=True,
        help="The S3 path for the attribution model results data.",
    )
    parser.add_argument(
        "--measurement-campaign-reporting-path",
        type=str,
        required=True,
        help="The S3 path for the measurement campaign reporting data.",
    )
    parser.add_argument(
        "--unified-campaign-path",
        type=str,
        required=True,
        help="The S3 path for the unified campaign data.",
    )
    parser.add_argument(
        "--user-journey-brand-path",
        type=str,
        required=True,
        help="The S3 path for the brand-only user journey data.",
    )
    parser.add_argument(
        "--user-journey-offer-path",
        type=str,
        required=True,
        help="The S3 path for the offer-only user journey data.",
    )
    parser.add_argument(
        "--metrics-topic-arn",
        type=str,
        required=True,
        help="The ARN for the SNS topic to publish metrics.",
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="The correlation ID for the run.",
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN for the Slack topic to publish notifications.",
    )

    args = parser.parse_args(command_line_args)

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path=args.attribution_model_results_path,
        measurement_campaign_reporting_path=args.measurement_campaign_reporting_path,
        unified_campaign_path=args.unified_campaign_path,
        brand_journey_path=args.user_journey_brand_path,
        offer_journey_path=args.user_journey_offer_path,
        metrics_topic_arn=args.metrics_topic_arn,
        correlation_id=args.correlation_id,
        slack_topic_arn=args.slack_topic_arn,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("PublishMTAValidationMetrics").getOrCreate())  # NOSONAR pythonenterprise:S7471
