import uuid

from pyspark.sql import DataFrame

from spark_pipeline.utils.pipeline_utils import make_unique_key, safe_float_conversion
from spark_pipeline.utils.mta_events import (
    ReachEngagementDetails,
)
from spark_pipeline.utils.publish_metrics import MetricsPublisher


def publish_reach_engagement_detail_metrics(
    reach_engagement_detail_df: DataFrame,
    metrics_topic_arn: str,
    correlation_id: str,
) -> int:
    batch_id = str(uuid.uuid4())
    rows = reach_engagement_detail_df.collect()
    publisher = MetricsPublisher(topic_arn=metrics_topic_arn)

    for row in rows:
        event = ReachEngagementDetails(
            correlation_id=row["job_run_id"] or correlation_id,
            name=f"REACH_DETAILS|{make_unique_key(campaign_id=row['campaign_id'], subchannel_name=row['subchannel_name'], booking_id=row['booking_id'])}",
            batch_id=batch_id,
            campaign_id=row["campaign_id"],
            booking_id=row["booking_id"],
            marketing_type=row["marketing_type"],
            channel_name=row["channel_name"],
            subchannel_name=row["subchannel_name"],
            reach_cnt=safe_float_conversion(row["reach_cnt"]),
            dedup_campaign_reach=safe_float_conversion(row["dedup_campaign_reach"]),
            clicks_cnt=safe_float_conversion(row["clicks_cnt"]),
            impressions_cnt=safe_float_conversion(row["impressions_cnt"]),
            sales_amt=safe_float_conversion(row["sales_amt"]),
            conversions_cnt=safe_float_conversion(row["conversions_cnt"]),
            media_spend_amt=safe_float_conversion(row["media_spend_amt"]),
            engagement_ctr_pct=safe_float_conversion(row["engagement_ctr_pct"]),
            load_ts=str(row["load_ts"]),
            dag_run_ts=str(row["load_ts"]),
        )

        publisher.publish_event(
            message_subject="Campaign Metrics Event",
            event=event,
        )

    return len(rows)
