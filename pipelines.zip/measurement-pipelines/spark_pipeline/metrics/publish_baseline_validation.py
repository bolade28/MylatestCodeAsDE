from typing import List, Optional

from pyspark.sql import SparkSession, functions as F

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics import (
    check_non_zero_during_campaign_period,
    check_spike_outliers,
    check_zero_null_week_count,
)
from spark_pipeline.metrics.baseline_validation_metrics.marketing_validation_metrics import (
    publish_marketing_validation_metrics,
)
from spark_pipeline.metrics.baseline_validation_metrics.sales_validation_metrics import publish_sales_validation_metrics
from spark_pipeline.utils.stdout_logger import get_stdout_logger


def publish_baseline_validation(
    spark: SparkSession,
    campaign_selection_path: str,
    baseline_modelling_dataset_path: str,
    metrics_topic_arn: str,
    correlation_id: str,
    campaign_duration: Optional[str] = None,
) -> None:
    """
    Read input data and run all baseline validation checks, publishing any warnings to SNS.

    Runs two sets of checks:
      1. Marketing input signal checks (zero impressions/spend, range checks) against
         the baseline modelling dataset and campaign selection.
      2. Sales input signal checks (zero sales, range checks) against
         the baseline modelling dataset and campaign selection.
      3. ADS checks (non-zero during campaign period, zero/null week count, spike outliers)
         against the baseline modelling dataset filtered to CLUSTERING campaigns.

    Args:
        spark: The Spark session.
        campaign_selection_path: S3 path for the campaign selection output.
        baseline_modelling_dataset_path: S3 path for the baseline modelling dataset.
        metrics_topic_arn: ARN of the SNS topic to publish metrics events to.
        correlation_id: Correlation ID for the current pipeline run.
        campaign_duration: Current run duration label (for example During or Post).
    """
    logger = get_stdout_logger()

    logger.info(
        f"Reading campaign selection from: {campaign_selection_path}",
        log_type="baseline_validation",
    )

    campaign_selection_df = (
        spark.read.parquet(campaign_selection_path)
        .select(
            "unique_brand_name",
            "super_category_name",
            "min_campaign_start_dt",
            "max_campaign_end_dt",
            "max_post_campaign_dt",
            "marketing_types",
            "channel_name",
            "subchannel_name",
            "final_status",
        )
    )

    logger.info(
        f"Reading baseline modelling dataset from: {baseline_modelling_dataset_path}",
        log_type="baseline_validation",
    )
    baseline_modelling_dataset_df = (
        spark.read.parquet(baseline_modelling_dataset_path)
        .select(
            "unique_brand_name",
            "super_category_name",
            "marketing_type_name",
            "marketing_channel_name",
            "week_start_dt",
            "metric_name",
            "metric_value",
            "cluster_num",
            "variable_cd",
        )
    )

    # --- Marketing input signal checks ---
    publish_marketing_validation_metrics(
        spark=spark,
        campaign_selection_df=campaign_selection_df,
        baseline_modelling_dataset_df=baseline_modelling_dataset_df,
        metrics_topic_arn=metrics_topic_arn,
        correlation_id=correlation_id,
    )

    # --- Sales input signal checks ---
    publish_sales_validation_metrics(
        campaign_selection_df=campaign_selection_df,
        baseline_modelling_dataset_df=baseline_modelling_dataset_df,
        metrics_topic_arn=metrics_topic_arn,
        correlation_id=correlation_id,
        campaign_duration=campaign_duration,
    )

    # --- ADS checks (checks 4, 5, 6) ---
    ads_campaign_selection_df = (
        campaign_selection_df
        .filter(F.col("final_status") == F.lit("CLUSTERING"))
        .select("unique_brand_name", "super_category_name", "min_campaign_start_dt", "max_campaign_end_dt")
    )

    check_non_zero_during_campaign_period(
        baseline_modelling_dataset_df, ads_campaign_selection_df, correlation_id, metrics_topic_arn
    )
    check_zero_null_week_count(baseline_modelling_dataset_df, correlation_id, metrics_topic_arn)
    check_spike_outliers(baseline_modelling_dataset_df, correlation_id, metrics_topic_arn)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Publish marketing input signal validation metrics.")
    parser.add_argument(
        "--campaign-selection-path",
        type=str,
        required=True,
        help="S3 path for the campaign selection output.",
    )
    parser.add_argument(
        "--baseline-modelling-dataset-path",
        type=str,
        required=True,
        help="S3 path for the baseline modelling dataset.",
    )
    parser.add_argument(
        "--metrics-topic-arn",
        type=str,
        required=True,
        help="ARN of the SNS topic to publish metrics.",
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for the pipeline run.",
    )
    parser.add_argument(
        "--campaign-duration",
        type=str,
        required=False,
        default=None,
        help="Campaign duration label for the current run (for example During or Post).",
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    publish_baseline_validation(
        spark=spark,
        campaign_selection_path=known_args.campaign_selection_path,
        baseline_modelling_dataset_path=known_args.baseline_modelling_dataset_path,
        metrics_topic_arn=known_args.metrics_topic_arn,
        correlation_id=known_args.correlation_id,
        campaign_duration=known_args.campaign_duration,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("PublishBaselineValidation").getOrCreate())
