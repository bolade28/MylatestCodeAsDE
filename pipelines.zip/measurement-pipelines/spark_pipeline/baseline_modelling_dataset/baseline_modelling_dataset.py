from typing import List, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.pipeline_utils import get_model_dates
from pyspark.sql.types import TimestampType
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite
from spark_pipeline.common.variables import BaselineModellingDataSetConfig, CampaignDurations


def get_tlc_df(three_letter_coding_df, column, code_alias):
    """
    Helper to filter and rename TLC DataFrame for a specific column.
    """
    return (three_letter_coding_df.filter(F.col("column_name") == column)
            .withColumnRenamed("original_column_value", column.lower())
            .withColumnRenamed("final_code", code_alias)
            .drop("column_name")
            )


def apply_post_period_clamping(
        spark: SparkSession,
        baseline_modelling_dataset_df,
        campaign_selection_path: str,
):
    """
    Set metric_value to 0 for configured marketing types starting from the week
    after end_dt of the campaign.

    Args:
        spark: Active SparkSession.
        baseline_modelling_dataset_df: Baseline modelling dataset with weekly metrics.
        campaign_selection_path: Parquet path to campaign selection data containing
        unique_brand_name, super_category_name, max_campaign_end_dt, and marketing_types.

    Returns:
        DataFrame with post-period clamping applied and helper join column removed.

    Example:
    - campaign_end_dt: 2026-03-18
    - zero_start_week: 2026-03-23
    - marketing_type_name: TV (configured for clamping)
    week_start_dt    metric_value(before)    metric_value(after)
    2026-03-16       120                     120
    2026-03-23       140                     0
    2026-03-30       90                      0
    """
    clamped_sources = set(BaselineModellingDataSetConfig().post_period_clamped_marketing_types)
    clamped_marketing_type_names = set(BaselineModellingDataSetConfig().post_period_clamped_marketing_type_names)
    post_period_clamp_start_week_df = (
        (
            spark.read.parquet(campaign_selection_path)
            .select(
                "unique_brand_name",
                "super_category_name",
                "max_campaign_end_dt",
                F.explode_outer(F.col("marketing_types")).alias("marketing_types"),
            )
            .filter(F.col("marketing_types").isin(clamped_sources))
            .groupBy(
                "unique_brand_name",
                "super_category_name",
            )
        )
        .agg(F.max("max_campaign_end_dt").alias("max_campaign_end_dt"))
        .withColumn(
            "zero_start_week",
            F.to_date(
                F.date_add(F.date_trunc("week", F.col("max_campaign_end_dt")), 7)
            ),
        )
    )

    return (
        baseline_modelling_dataset_df.join(
            F.broadcast(post_period_clamp_start_week_df.select(["unique_brand_name", "super_category_name", "zero_start_week"])),
            on=["unique_brand_name", "super_category_name"],
            how="left",
        ).withColumn(
            "metric_value",
            F.when(
                F.col("marketing_type_name").isin(list(clamped_marketing_type_names))
                & F.col("zero_start_week").isNotNull()
                & (F.col("week_start_dt") >= F.col("zero_start_week")),
                F.lit(0),
            ).otherwise(F.col("metric_value")),
        ).drop("zero_start_week")
    )


def prepare_baseline_modelling_dataset(
        spark: SparkSession,
        weekly_dates_path: str,
        channel_processed_data_path: str,
        three_letter_coding_path: str,
        output_path: str,
        campaign_selection_path: str,
        run_date: str,
        correlation_id: str,
        campaign_period: str
) -> None:

    """
        * Objective:
            - This script is used to create final time series dataset that would be later used in the baseline pipeline
              to run unobserved component modelling.
            - ADS forms the main dataset that goes into the UCM modelling process. It contains all the required input data
            in the required granularity for UCM. It also has data in a standardized ADS Hierarchy so that UCM can automatically
            pickup required data and test variables correctly without any manual intervention since raw data comes in multiple formats and granularities.

        Parameters:

        spark : SparkSession
            An active SparkSession used for reading and writing data using Apache Spark.

        weekly_dates_path : str
            Path to the input file containing weekly date information. This is typically used to filter or join datasets based on time periods.

        channel_processed_data_path : str
            Path to the processed data for different channels.

        three_letter_coding_path : str
            Path to the reference file containing three-letter coding information.

        output_path : str
            Destination path where the final output will be written. This could be a directory or file depending on the output format.

        run_date : str
            The date on which the job is executed. Format is expected to be 'YYYY-MM-DD'.

        correlation_id : str
            Dag correlation id.


        * Lineage:
            Upstream:
                - 08_ads_creation (three_letter_coding.sql)
            Downstream:
                - 14_stored_procedure_call (feature_prioritization_call.sql)

        * Confluence:
            https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/834536187/ADS
    """
    weekly_dates_df = (
        spark
        .read
        .parquet(weekly_dates_path)
        .select(
            'week_start_dt'
        )
    )
    channel_processed_data_df = (
        spark
        .read
        .parquet(channel_processed_data_path)
        .select(
            'week_start_dt',
            'metric_value',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name',
            'job_run_id',
            'load_ts'
        )
    )
    three_letter_coding_df = (
        spark
        .read
        .parquet(three_letter_coding_path)
        .select(
            'column_name',
            'original_column_value',
            'final_code'
        )
    )

    max_ts_df = channel_processed_data_df.select("load_ts").agg(F.max("load_ts").alias("load_ts"))
    channel_processed_data = channel_processed_data_df.join(max_ts_df, "load_ts")

    # -- Merging with three letter coding for matching values in each respective column from three letter code

    tlc_super_category = get_tlc_df(three_letter_coding_df, "SUPER_CATEGORY_NAME", "super_category_code")

    tlc_unique_brand = get_tlc_df(three_letter_coding_df, "UNIQUE_BRAND_NAME", "unique_brand_code")

    tlc_cluster = get_tlc_df(three_letter_coding_df, "CLUSTER_NUM", "cluster_code")

    tlc_marketing_type = get_tlc_df(three_letter_coding_df, "MARKETING_TYPE_NAME", "marketing_type_code")

    tlc_marketing_channel = get_tlc_df(three_letter_coding_df, "MARKETING_CHANNEL_NAME", "marketing_channel_code")

    tlc_marketing_sub_channel = get_tlc_df(three_letter_coding_df, "MARKETING_SUB_CHANNEL_NAME", "marketing_sub_channel_code")

    tlc_metric = get_tlc_df(three_letter_coding_df, "METRIC_NAME", "metric_code")

    data_with_codes = (
        channel_processed_data
        .join(tlc_super_category, ["super_category_name"], "left")
        .join(tlc_unique_brand, ["unique_brand_name"], "left")
        .join(tlc_cluster, ["cluster_num"], "left")
        .join(tlc_marketing_type, ["marketing_type_name"], "left")
        .join(tlc_marketing_channel, ["marketing_channel_name"], "left")
        .join(tlc_marketing_sub_channel, ["marketing_sub_channel_name"], "left")
        .join(tlc_metric, ["metric_name"], "left")
        .select(
            'week_start_dt',
            'metric_value',
            'super_category_name',
            'unique_brand_name',
            'cluster_num',
            'marketing_type_name',
            'marketing_channel_name',
            'marketing_sub_channel_name',
            'metric_name',
            'job_run_id',
            'LOAD_TS',
            "super_category_code",
            "unique_brand_code",
            "marketing_type_code",
            "marketing_channel_code",
            "marketing_sub_channel_code",
            "metric_code",
            F.when(F.col("cluster_code").isNull() | (F.col("cluster_code") == ""),
                   "TOT").otherwise(F.col("cluster_code")).alias("cluster_code")
        )
    )
    # -- Creating three letter code in variable_cd column by concatenating using underscore
    baseline_modelling_dataset = (
        data_with_codes.select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            F.concat_ws(
                "_",
                "super_category_code",
                "unique_brand_code",
                "cluster_code",
                "marketing_type_code",
                "marketing_channel_code",
                "marketing_sub_channel_code",
                "metric_code"
            ).alias("variable_cd")
        )
    )
    temp_date_dataset = weekly_dates_df.select(F.col("week_start_dt").alias("week_start_date"))
    min_date, max_date = get_model_dates(temp_date_dataset)

    # -- Filtering out dataset for required weeks only
    baseline_modelling_dataset_filtered = (
        baseline_modelling_dataset.filter(
            (F.col("week_start_dt") >= min_date) & (F.col("week_start_dt") <= max_date)
        )
    )
    # TODO(PI3): Temporary fix for post-period feature clamping.
    # Remove this block once DURING-overlap logic is implemented in PI3.
    if campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST:
        # Post period clamping: For marketing types, if the week_start_dt is after the max_campaign_end_dt of the campaign, set metric_value to 0
        if not campaign_selection_path:
            raise ValueError("campaign_selection_path is required when campaign_period is 'Post'.")
        baseline_modelling_dataset_filtered = apply_post_period_clamping(
            spark=spark,
            baseline_modelling_dataset_df=baseline_modelling_dataset_filtered,
            campaign_selection_path=campaign_selection_path,
        )

    # -- Creation of baseline_modelling_dataset output table containing weekly time series data for all marketing and non-marketing channels
    # -- super_category_name,unique_brand_name,marketing_type_name,marketing_channel_name,cluster_num,metric_name,job_run_id,variable_cd have varchar as datatype, metric_value is number, load_ts is time and week_start_dt is date.

    baseline_modelling_dataset_final = (
        baseline_modelling_dataset_filtered
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "variable_cd",
            F.current_timestamp().cast(TimestampType()).alias("load_ts")
        )
        .withColumn("correlation_id", F.lit(correlation_id))
    ).distinct()

    spark_s3_overwrite(output_path, baseline_modelling_dataset_final)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Baseline Modelling Dataset..")

    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="S3 path for weekly calendar reference data."
    )
    parser.add_argument(
        "--channel-processed-data-path",
        type=str,
        required=True,
        help="S3 path for SKU to channel processed data."
    )
    parser.add_argument(
        "--three-letter-coding-path",
        type=str,
        required=True,
        help="S3 path for three-letter coding data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for output of baseline modelling dataset data."
    )
    parser.add_argument(
        "--campaign-selection-path",
        type=str,
        required=True,
        help="S3 path for campaign selection data."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for traceability."
    )
    parser.add_argument(
        "--campaign-period",
        type=str,
        required=False,
        default=None,
        choices=[CampaignDurations.CAMPAIGN_DURATION_DURING, CampaignDurations.CAMPAIGN_DURATION_POST],
        help=f"Campaign period ({CampaignDurations.CAMPAIGN_DURATION_DURING} or {CampaignDurations.CAMPAIGN_DURATION_POST})."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    # Call your main processing function here
    prepare_baseline_modelling_dataset(
        spark=spark,
        weekly_dates_path=known_args.weekly_dates_path,
        channel_processed_data_path=known_args.channel_processed_data_path,
        three_letter_coding_path=known_args.three_letter_coding_path,
        output_path=known_args.output_path,
        campaign_selection_path=known_args.campaign_selection_path,
        run_date=known_args.run_date,
        correlation_id=known_args.correlation_id,
        campaign_period=known_args.campaign_period
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("BaselineModellingDataset").getOrCreate())
