from typing import Optional
from pyspark.sql import Column, DataFrame, functions as F
from spark_pipeline.measurement_campaign_reporting.reporting_utils import (
    SPEND_WEIGHT_SCALED_COLUMNS,
    add_derived_metrics,
    calculate_conversion_rate,
)
from spark_pipeline.utils.pipeline_utils import safe_div
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


# Metrics that are differenced between During+Post and During without any weighting.
UNWEIGHTED_DIFFERENCED_COLUMNS = [
    "nectar_sales_amt",
    "non_nectar_sales_amt",
    "num_user_journeys",
    "modelling_weight",
]

# Campaign dimension columns joining During+Post to During.
POST_JOIN_KEYS = [
    "campaign_id",
    "booking_id",
    "marketing_type",
    "channel_name",
    "subchannel_name",
    "marketing_hierarchy_cd",
    "sub_category_name",
    "super_category_name",
    "job_bag_number",
    "journey_type",
    "campaign_type",
    "campaign_name",
]


def normalise_join_key(column_name: str) -> Column:
    """product_type keeps its BRAND/OFFER casing so it still matches the spend weights."""
    cast_col = F.col(column_name).cast("string")
    if column_name == "product_type":
        return F.upper(F.trim(cast_col))
    return F.trim(F.initcap(cast_col))


def calculate_post_period_metrics(
    measurement_campaign_reporting_df: DataFrame,
    measurement_campaign_reporting_during: DataFrame,
    slack_messenger: Optional[SlackMessenger] = None,
    reach_df: Optional[DataFrame] = None,
    spend_weights: Optional[DataFrame] = None,
    post_audit_path: Optional[str] = None,
) -> DataFrame:
    """
    Calculate Post period metrics by subtracting During period metrics from During+Post period metrics.

    This function performs the following steps:
    1. Filters During period data for matching booking_ids and gets the latest load_ts
    2. Filters During+Post period data from the input DataFrame
    3. Standardizes join key columns using trim and initcap transformations
    4. Joins During+Post with During data on campaign dimension keys
    5. Calculates Post metrics as: Post = (During+Post) - (During) for all numeric fields
    6. Computes derived metrics including ROAS, IROAS, uplift percentages, and conversion rates

    Args:
        measurement_campaign_reporting_df: DataFrame containing During+Post combined metrics.
                                          Must have campaign_duration column marked as "During+Post".
        measurement_campaign_reporting_during: Historical During period data loaded from parquet.
                                              Used as the baseline to subtract from During+Post.
        slack_messenger: Optional SlackMessenger for error notifications.
        reach_df: Optional reach data to override conversion_rate calculation using During reach.
        spend_weights: Optional overlapping-campaign spend weights keyed by booking_id, product_type
                       and weight_period. When supplied, the stored During weight is reversed out
                       before differencing, the Post component is scaled by the Post weight, and the
                       returned frame additionally contains rebuilt During+Post rows.
        post_audit_path: Optional S3 path. When supplied, writes the intermediate joined_df
                          (dp_*/d_* columns for both During+Post and During, pre-differencing)
                          for audit purposes.

    Returns:
        DataFrame: Post period metrics with the following characteristics:
                  - campaign_duration set to "Post"
                  - All numeric metrics calculated as (During+Post) - (During)
                  - Derived metrics: roas_exposed, iroas_exposed, uplift metrics, conversion rates
                  - Same schema structure as input for union compatibility
                  - When spend_weights is supplied, also includes the During+Post rows, which the
                    caller must therefore not union separately.

    Raises:
        ValueError: If no During period data is found for the booking_ids in input DataFrame
    """

    # Filter During period data for this booking_id
    booking_ids_df = measurement_campaign_reporting_df.select("booking_id").distinct()
    df_during_only = (
        measurement_campaign_reporting_during
        .filter(F.col("campaign_duration") == "During")
        .join(booking_ids_df, on="booking_id", how="inner")
    )

    # Validate that During period data exists
    if df_during_only.isEmpty():
        # Get the booking_ids that were expected
        booking_ids_list = [row.booking_id for row in booking_ids_df.collect()]
        if slack_messenger:
            slack_messenger.send_message(
                event_type="Measurement Campaign Reporting - Missing During Data",
                text=f"No During period data found for booking_ids: {booking_ids_list}",
                data={"booking_ids": booking_ids_list}
            )
        raise ValueError(f"No During period data found for booking_ids: {booking_ids_list}")

    # Get latest load_ts for During period to ensure we use the most recent data
    max_load_ts_row = df_during_only.agg(F.max("load_ts").alias("max_ts")).first()
    max_load_ts = max_load_ts_row["max_ts"]

    if max_load_ts is None:
        # Get the booking_ids that were expected
        booking_ids_list = [row.booking_id for row in booking_ids_df.collect()]
        if slack_messenger:
            slack_messenger.send_message(
                event_type="Measurement Campaign Reporting - Missing load_ts",
                text=f"No valid load_ts found in During period data for booking_ids: {booking_ids_list}",
                data={"booking_ids": booking_ids_list}
            )
        raise ValueError(f"No valid load_ts found in During period data for booking_ids: {booking_ids_list}")

    df_during_only = df_during_only.filter(F.col('load_ts') == max_load_ts)
    df_during_only = df_during_only.withColumn("during_campaign_name", F.col("campaign_name"))
    df_during_only = df_during_only.withColumn("during_subchannel_name", F.col("subchannel_name"))

    # Filter During+Post data from input DataFrame
    df_during_plus_post = measurement_campaign_reporting_df.filter(
        F.col("campaign_duration") == "During+Post"
    )

    # Define join keys - these are the campaign dimension columns
    # Only include unique_brand_name if it exists in both DataFrames for backward compatibility
    join_keys = list(POST_JOIN_KEYS)

    # Conditionally add unique_brand_name only if it exists in both DataFrames
    if "unique_brand_name" in df_during_only.columns and "unique_brand_name" in df_during_plus_post.columns:
        join_keys.append("unique_brand_name")

    # Brand and offer rows must never be crossed, so product_type joins when both sides carry it.
    if "product_type" in df_during_only.columns and "product_type" in df_during_plus_post.columns:
        join_keys.append("product_type")
    product_type_only_cols = (
        ["product_type"]
        if "product_type" in df_during_plus_post.columns and "product_type" not in join_keys
        else []
    )

    # Apply trim and initcap to handle case sensitivity and whitespace
    for c in join_keys:
        df_during_only = df_during_only.withColumn(c, normalise_join_key(c))
        df_during_plus_post = df_during_plus_post.withColumn(c, normalise_join_key(c))

    # Define columns not used in join, most of which are subtracted between during+post and during
    non_join_cols = [
        "conversions_recalibrated",
        "attributed_recalibrated_sales_amt",
        "incremental_sales_amt_exposed",
        "media_spend_amt",
        "attributed_conversions",
        "attributed_recalibrated_units_qty",
        "incremental_units_qty_exposed",
        "attributed_units_qty",
        "attributed_sales_amt",
        "recalibration_factor",
        "nectar_sales_amt",
        "non_nectar_sales_amt",
        "base_sales_amt_exposed",
        "num_user_journeys",
        "num_conversions",
        # Carried through so the converted-journey numerator behind it can be reconstructed.
        "conversion_per_uj",
        "load_ts",
        "correlation_id",
        "modelling_weight",
        "run_type",
        "dag_run_ts",
        "overlapping_campaign_flag",
    ]
    passthrough_cols = ["brand_id"]

    weights_available = spend_weights is not None and "product_type" in df_during_plus_post.columns
    # Outputs written before weighting carry no weight and are already unweighted.
    during_weight_stored = (
        weights_available
        and "spend_weight" in df_during_only.columns
        and "spend_weight" in df_during_plus_post.columns
    )
    if during_weight_stored:
        non_join_cols.append("spend_weight")

    # Prefix columns to avoid naming conflicts after join
    # dp_ = During+Post, d_ = During
    df_during_plus_post = df_during_plus_post.select(
        *[F.col(c) for c in join_keys],
        *[F.col(c) for c in product_type_only_cols],
        *[F.col(c).alias(f"dp_{c}") for c in non_join_cols],
        *[F.col(c).alias(f"dp_{c}") for c in passthrough_cols],
    )

    df_during_only = df_during_only.select(
        *[F.col(c) for c in join_keys],
        *[F.col(c).alias(f"d_{c}") for c in non_join_cols],
        *[F.col(c).alias(f"d_{c}") for c in passthrough_cols],
        "during_campaign_name",
        "during_subchannel_name"
    )

    # Left join so unweighted During+Post rows survive; Post rows are filtered to matches below.
    joined_df = df_during_plus_post.join(
        df_during_only, on=join_keys, how="left" if weights_available else "inner"
    )

    if weights_available:
        post_weights = (
            spend_weights
            .filter(F.col("weight_period") == "Post")
            .select(
                F.lower(F.col("booking_id")).alias("w_booking_id"),
                F.col("product_type").alias("w_product_type"),
                F.col("spend_weight").alias("w_post_spend_weight"),
            )
        )
        joined_df = (
            joined_df
            .join(
                F.broadcast(post_weights),
                on=(
                    (F.lower(F.col("booking_id")) == F.col("w_booking_id"))
                    & (F.upper(F.col("product_type")) == F.col("w_product_type"))
                ),
                how="left",
            )
            .drop("w_booking_id", "w_product_type")
        )
        # Reverse out the weight the During run applied, then weight the Post component on its own.
        during_weight = (
            F.when(F.col("d_spend_weight") > 0, F.col("d_spend_weight")).otherwise(F.lit(1.0))
            if during_weight_stored
            else F.lit(1.0)
        )
        post_weight = F.coalesce(F.col("w_post_spend_weight"), F.lit(1.0))
    else:
        during_weight = F.lit(1.0)
        post_weight = F.lit(1.0)

    if post_audit_path is not None:
        # Raw dp_*/d_* pairs plus the weight columns, before any differencing is applied.
        post_audit_df = joined_df
        spark_s3_overwrite(post_audit_path, post_audit_df)

    post_metrics = {
        c: (F.col(f"dp_{c}") - F.col(f"d_{c}") / during_weight) * post_weight
        for c in SPEND_WEIGHT_SCALED_COLUMNS
    }
    unweighted_metrics = {
        c: F.col(f"dp_{c}") - F.col(f"d_{c}")
        for c in UNWEIGHTED_DIFFERENCED_COLUMNS
    }

    # Calculate Post = (During+Post) - (During) for all numeric columns
    result_df = (
        joined_df
        .filter(F.col("d_load_ts").isNotNull())
        .withColumns(post_metrics)
        .withColumns(unweighted_metrics)
        # Conversions are reported as a whole number, so the weighted count is rounded back.
        .withColumn("num_conversions", F.round(F.col("num_conversions")))
        # Media spend stays the same (use During period value)
        .withColumn("media_spend_amt", F.col("d_media_spend_amt"))
        # Mark this as Post period
        .withColumn("campaign_duration", F.lit("Post"))
        # Use During+Post timestamp and recalibration factor
        .withColumn("overlapping_campaign_flag", F.col("dp_overlapping_campaign_flag"))
        .withColumn("load_ts", F.col("dp_load_ts"))
        .withColumn("recalibration_factor", F.col("dp_recalibration_factor"))
        .withColumn("correlation_id", F.col("dp_correlation_id"))
        .withColumn("run_type", F.col("dp_run_type"))
        .withColumn("dag_run_ts", F.col("dp_dag_run_ts"))
        .withColumn("brand_id", F.col("d_brand_id"))
    )

    if during_weight_stored:
        result_df = result_df.withColumn("spend_weight", post_weight)

    # Post's share of the converted journeys behind conversion_per_uj, recovered from the rate
    # and journey count on each side. Collapses to a plain difference when no weights apply.
    post_conversions = (
        (F.col("dp_conversion_per_uj") * F.col("dp_num_user_journeys"))
        - (F.col("d_conversion_per_uj") * F.col("d_num_user_journeys")) / during_weight
    ) * post_weight

    result_df = (
        result_df
        .transform(add_derived_metrics)
        .withColumn("conversion_per_uj",
                    safe_div(post_conversions, F.col("num_user_journeys")))
    )

    # If reach_df is provided, override conversion_rate using During reach as the denominator.
    # Reach always comes from the During run; conversions_recalibrated here is the Post value.

    result_df = (
        result_df
        .join(
            F.broadcast(reach_df),
            on=(
                (F.col('booking_id') == F.col('re_booking_id')) &
                (F.lower(F.col('channel_name')) == F.col('re_channel_name')) &
                (F.lower(F.col('subchannel_name')) == F.col('re_subchannel_name'))
            ),
            how='left'
        )
        .drop('re_booking_id', 're_channel_name', 're_subchannel_name')
        .transform(calculate_conversion_rate)
    )

    # Select final columns in the correct order
    final_columns = (
        join_keys +
        product_type_only_cols +
        passthrough_cols +
        non_join_cols +
        [
            "campaign_duration",
            "roas_exposed",
            "iroas_exposed",
            "uplift_exposed_sales_amt",
            "uplift_exposed_units_qty",
            "attributed_recalibrated_sales_amt_per_uj",
            "attributed_recalibrated_sales_amt_per_conversion",
            "conversion_rate",
        ]
    )

    result_df = (
        result_df
        .withColumn("campaign_name", F.col("during_campaign_name"))
        .withColumn("subchannel_name", F.col("during_subchannel_name"))
    )

    result_df = result_df.select(*final_columns)

    if not weights_available:
        return result_df

    return result_df.unionByName(
        _rebuild_during_plus_post(
            measurement_campaign_reporting_df=measurement_campaign_reporting_df,
            joined_df=joined_df,
            join_keys=join_keys,
            during_weight=during_weight,
            post_weight=post_weight,
        ),
        allowMissingColumns=True,
    )


def _rebuild_during_plus_post(
    measurement_campaign_reporting_df: DataFrame,
    joined_df: DataFrame,
    join_keys: list,
    during_weight: Column,
    post_weight: Column,
) -> DataFrame:
    """
    Rebuild the During+Post rows as (weighted During) + (weighted Post).

    Corrections are joined back onto the original rows rather than rebuilt from the joined frame,
    so the untouched dimension values keep their original casing.
    """
    # conversion_per_uj is built upstream from converted journeys, which the reporting schema drops;
    # the rate times the journey count recovers that numerator so it can be corrected like the rest.
    during_conversions = F.col("d_conversion_per_uj") * F.col("d_num_user_journeys")
    during_plus_post_conversions = F.col("dp_conversion_per_uj") * F.col("dp_num_user_journeys")
    corrected_conversions = (
        during_conversions
        + (during_plus_post_conversions - during_conversions / during_weight) * post_weight
    )

    corrections = joined_df.select(
        *[F.col(c).alias(f"k_{c}") for c in join_keys],
        *[
            (F.col(f"d_{c}") + (F.col(f"dp_{c}") - F.col(f"d_{c}") / during_weight) * post_weight).alias(f"corrected_{c}")
            for c in SPEND_WEIGHT_SCALED_COLUMNS
        ],
        # Plain division so an absent During match stays null and falls back to the original rate.
        (corrected_conversions / F.col("dp_num_user_journeys")).alias("corrected_conversion_per_uj"),
    )

    join_condition = None
    for c in join_keys:
        key_match = normalise_join_key(c) == F.col(f"k_{c}")
        join_condition = key_match if join_condition is None else join_condition & key_match

    during_plus_post_df = (
        measurement_campaign_reporting_df
        .filter(F.col("campaign_duration") == "During+Post")
        .join(F.broadcast(corrections), on=join_condition, how="left")
        # Rows with no During match cannot be split into components, so they are left untouched.
        .withColumn(
            "conversions_recalibrated_scale",
            F.when(
                F.col("corrected_conversions_recalibrated").isNotNull() & (F.col("conversions_recalibrated") != 0),
                F.col("corrected_conversions_recalibrated") / F.col("conversions_recalibrated"),
            ).otherwise(F.lit(1.0)),
        )
        .withColumns({c: F.coalesce(F.col(f"corrected_{c}"), F.col(c)) for c in SPEND_WEIGHT_SCALED_COLUMNS})
        .withColumn(
            "conversion_per_uj",
            F.coalesce(F.col("corrected_conversion_per_uj"), F.col("conversion_per_uj")),
        )
        # conversion_rate shares the conversions_recalibrated numerator, so it scales by that factor.
        .withColumn("conversion_rate", F.col("conversion_rate") * F.col("conversions_recalibrated_scale"))
        .withColumn("num_conversions", F.round(F.col("num_conversions")))
        .drop(
            "conversions_recalibrated_scale",
            "corrected_conversion_per_uj",
            *[f"k_{c}" for c in join_keys],
            *[f"corrected_{c}" for c in SPEND_WEIGHT_SCALED_COLUMNS],
        )
    )

    return during_plus_post_df.transform(add_derived_metrics)
