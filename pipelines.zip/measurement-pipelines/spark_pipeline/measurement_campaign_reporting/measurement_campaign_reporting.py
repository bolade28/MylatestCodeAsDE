import logging
from typing import List, Optional

from spark_pipeline.schemas.measurement_campaign_reporting import MeasurementCampaignReportingPollen
from spark_pipeline.utils.slack_utils import SlackMessenger
from pyspark.sql import DataFrame, SparkSession, functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.measurement_campaign_reporting.post_period_utils import calculate_post_period_metrics
from spark_pipeline.measurement_campaign_reporting.reporting_utils import (
    SPEND_WEIGHT_SCALED_COLUMNS,
    AUDIT_KEY_COLUMNS,
    add_derived_metrics,
    add_fallback_audit,
    add_to_reporting_audit,
    calculate_conversion_rate,
)
from spark_pipeline.measurement_campaign_reporting.incrementality_fallback import (
    check_if_incrementality_fallback_needed,
    apply_period_fallback,
    floor_post_incrementality,
    period_mask,
    get_fallback_metadata
)

from spark_pipeline.utils.pipeline_utils import safe_div

from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite
from spark_pipeline.common.variables import CampaignDurations, EventName, IncrementalityFallbackConfig


logger = logging.getLogger(__name__)


SELECTED_IO_COLUMNS = [
    'unique_brand_name',
    'channel_name',
    'correlation_id',
    'campaign_id',
    'booking_id',
    'campaign_duration',
    'journey_type',
    'marketing_type',
    'subchannel_name',
    'marketing_hierarchy_cd',
    'sub_category_name',
    'attributed_conversions',
    'incremental_sales_amt_exposed',
    'super_category_name',
    'campaign_name',
    'attributed_recalibrated_sales_amt',
    'attributed_recalibrated_units_qty',
    'incremental_units_qty_exposed',
    'attributed_units_qty',
    'attributed_sales_amt',
    'conversions_recalibrated',
    'recalibration_factor',
    'job_bag_number',
    'nectar_sales_amt',
    'non_nectar_sales_amt',
    'media_spend_amt',
    'campaign_type',
    'roas_exposed',
    'iroas_exposed',
    'base_sales_amt_exposed',
    'uplift_exposed_sales_amt',
    'uplift_exposed_units_qty',
    'num_user_journeys',
    'num_conversions',
    'attributed_recalibrated_sales_amt_per_uj',
    'attributed_recalibrated_sales_amt_per_conversion',
    'conversion_per_uj',
    'conversion_rate',
    'load_ts',
    'run_type',
    'dag_run_ts',
    'overlapping_campaign_flag',
    'modelling_weight',
    'product_type',
    'spend_weight',
]

# conversions is not in the reporting schema but feeds conversion_per_uj, so it scales with the rest.
DURING_SPEND_WEIGHT_SCALED_COLUMNS = SPEND_WEIGHT_SCALED_COLUMNS + ['conversions']


def ensure_io_columns_present(integration_output_uplift: DataFrame) -> DataFrame:
    """Ensure expected io columns exist so explicit select statements remain stable."""
    expected_types = {
        field.name: field.dataType
        for field in MeasurementCampaignReportingPollen().measures_schema.fields
    }
    existing_columns = set(integration_output_uplift.columns)
    for col_name in SELECTED_IO_COLUMNS:
        if col_name not in existing_columns:
            integration_output_uplift = integration_output_uplift.withColumn(
                col_name,
                F.lit(None).cast(expected_types.get(col_name, "string")),
            )
    return integration_output_uplift


def load_campaign_brand_id_mapping(
    spark: SparkSession,
    campaign_booking_media_channel_path: str,
) -> DataFrame:
    """Load booking-level brand metadata and aggregate brand information for reporting."""
    return (
        spark.read.parquet(campaign_booking_media_channel_path)
        .select(
            F.col('booking_id').alias('booking_id'),
            F.col('brand_id').cast('string').alias('brand_id'),
        )
        .filter(F.col('booking_id').isNotNull())
        # Prevents null brand IDs from being treated as meaningful values in the aggregation below.
        .filter(F.col('brand_id').isNotNull())
        .groupBy('booking_id')
        .agg(
            F.sort_array(F.collect_set('brand_id')).alias('brand_id_list'),
            F.countDistinct('brand_id').alias('brand_count'),
        )
        .withColumn(
            'brand_id',
            F.when(F.col('brand_count') == 1,
                   F.element_at(F.col('brand_id_list'), 1))
            .otherwise(F.lit(None).cast('string'))
        )
    )


def resolve_column_name(previous_reporting: DataFrame, column_name: str) -> Optional[str]:
    """Match a column case-insensitively, as Snowflake unloads write uppercase parquet names.
    Args:
        previous_reporting: DataFrame containing the previous reporting data.
        column_name: The name of the column to match case-insensitively.

    Returns:
        The matched column name if found, otherwise None.
    """
    target = column_name.lower()
    return next(
        (existing for existing in previous_reporting.columns if existing.lower() == target),
        None,
    )


def get_brand_id_column(previous_reporting: DataFrame):
    """Return brand_id column expression with backward compatibility for older outputs."""

    brand_id_column_name = resolve_column_name(previous_reporting, 'brand_id')
    brand_id_col = (
        F.col(brand_id_column_name).alias('brand_id')
        if brand_id_column_name
        else F.lit(None).cast('string').alias('brand_id')
    )
    return brand_id_col


def load_spend_weights(spark: SparkSession, overlapping_campaign_spend_weights_path: str) -> DataFrame:
    """Load each booking's share of overlapping spend, per product type and campaign period.
    Args:
        spark: SparkSession object.
        overlapping_campaign_spend_weights_path: Path to the parquet file containing overlapping campaign spend weights.

    Returns:
        DataFrame with each booking's share of overlapping spend, per product type and campaign period.
    """
    return (
        spark.read.parquet(overlapping_campaign_spend_weights_path)
        .select(
            F.col('booking_id').cast('string').alias('booking_id'),
            F.upper(F.trim(F.col('product_type').cast('string'))
                    ).alias('product_type'),
            F.initcap(F.trim(F.col('campaign_duration').cast('string'))).alias(
                'weight_period'),
            F.col('spend_weight').cast('double').alias('spend_weight'),
        )
        .dropDuplicates(['booking_id', 'product_type', 'weight_period'])
    )


def apply_spend_weights(integration_output: DataFrame, spend_weights: DataFrame, weight_period: str) -> DataFrame:
    """Scale volume metrics by the booking's share of overlapping spend; ratios are derived afterwards.
    Args:
        integration_output: DataFrame containing the intermediate measurement results for booking.
        spend_weights: DataFrame containing the spend weights for each booking.
        weight_period: The weight period to apply from the spend weights.

    Returns:
        DataFrame with scaled volume metrics.
    """
    period_weights = (
        spend_weights
        .filter(F.col('weight_period') == weight_period)
        .select('booking_id', 'product_type', 'spend_weight')
    )
    scaled_columns = [
        c for c in DURING_SPEND_WEIGHT_SCALED_COLUMNS if c in integration_output.columns]

    return (
        integration_output
        .join(F.broadcast(period_weights), on=['booking_id', 'product_type'], how='left')
        # Bookings with no overlapping campaigns are left unscaled.
        .withColumn('spend_weight', F.coalesce(F.col('spend_weight'), F.lit(1.0)))
        .withColumns({column_name: F.col(column_name) * F.col('spend_weight') for column_name in scaled_columns})
        # Conversions are reported as a whole number, so the weighted count is rounded back.
        .withColumn('num_conversions', F.round(F.col('num_conversions')))
    )


def add_brand_id_to_integration_output(
    integration_output_uplift: DataFrame,
    spark: SparkSession,
    campaign_booking_media_channel_path: Optional[str],
) -> DataFrame:
    """Attach booking-level brand_id and outputs multi-brand validation diagnostics."""

    if not campaign_booking_media_channel_path:
        return (
            integration_output_uplift
            .withColumn('brand_id', F.lit(None).cast('string'))
        )

    campaign_brand_id_mapping = load_campaign_brand_id_mapping(
        spark=spark,
        campaign_booking_media_channel_path=campaign_booking_media_channel_path,
    )

    # Validation signal: this does not affect output shape, but helps monitor multi-brand bookings.
    multi_brand_booking_count = (
        campaign_brand_id_mapping
        .filter(F.col('brand_count') > 1)
        .count()
    )
    logger.info(
        'Multi-brand booking_id count in campaign booking mapping: %s',
        multi_brand_booking_count,
    )

    # Keep explicit column selection (no wildcard) and backfill any missing expected columns.
    integration_output_uplift = ensure_io_columns_present(
        integration_output_uplift)

    return (
        integration_output_uplift.alias('io')
        .join(
            F.broadcast(campaign_brand_id_mapping).alias('cbmc'),
            on='booking_id',
            how='left'
        )
        .select(
            *[F.col(f'io.{col_name}') for col_name in SELECTED_IO_COLUMNS],
            F.col('cbmc.brand_id'),
        )
    )


def combine_baseline_mta(
    pre_mta_brand: DataFrame,
    pre_mta_offer: DataFrame,
    slaso: DataFrame,
    slasb: DataFrame,
    cme: DataFrame,
    ic: DataFrame,
    bp: DataFrame,
    uc: DataFrame,
    product_type: str = 'brand',
    run_type: str = 'Pollen'
) -> DataFrame:
    """
    Combines baseline incremental sales outputs with MTA attribution outputs for unified reporting.
    This function performs the following steps:
    1. Aggregates user journey data to calculate conversion metrics.
    2. Aggregates MTA outputs to calculate attributed sales and units.
    3. Joins with baseline incremental sales data to calculate incremental sales and units exposed.
    4. Combines all metrics into a unified dataframe for reporting.

    Args:
        pre_mta_brand: DataFrame containing pre-MTA data for brand campaigns.
        pre_mta_offer: DataFrame containing pre-MTA data for offer campaigns.
        slaso: DataFrame containing SKU level attributed sales and units for offer SKUs.
        slasb: DataFrame containing SKU level attributed sales and units for brand SKUs.
        cme: DataFrame containing campaign measurement execution data.
        ic: DataFrame containing incremental calibration data.
        bp: DataFrame containing base price data for UCM.
        uc: DataFrame containing unified campaign data.
        product_type: String indicating whether to process 'brand' or 'offer' data. Determines which pre-MTA and SLAS tables to use.
        run_type: String indicating the type of run, e.g., 'Pollen'.

    Returns:
        DataFrame containing the combined metrics for baseline and MTA integration.
    """
    if product_type == 'brand':
        pre_mta = pre_mta_brand
        slas = slasb
    elif product_type == 'offer':
        pre_mta = pre_mta_offer
        slas = slaso
    else:
        raise Exception(
            "Incorrect argument passed to integration function, please pass `offer` or `brand`")
    # Aggregate user journeys for conversion metrics.
    # Touchpoint rows are used for journey/reach metrics; transaction rows for conversion metrics.
    group_cols = [
        F.initcap(F.col('journey_type')).alias('journey_type'),
        F.col('booking_id'),
        F.col('campaign_id'),
        F.col('channel_name'),
        F.col('subchannel_name'),
    ]
    # TODO:: have not tested this for dtp world
    user_journey_processed = (
        pre_mta
        .filter(F.lower(F.col('event_name')) != EventName.TRANSACTION.value.lower())
        .groupBy(*group_cols)
        .agg(
            # Count distinct converted userjourney_ids, not sum of per-row isconversion flags.
            # After filtering to touchpoints, isconversion is 1 on every row of converted journeys,
            # so sum() would count touchpoints, not conversions. Use countDistinct instead.
            F.countDistinct(
                F.when(F.col('isconversion') == 1, F.col('userjourney_id'))
            ).alias('conversions'),
            F.countDistinct(
                F.when(F.col('isconversion') == 1, F.col('userjourney_id'))
            ).alias('converted_user_journeys'),
            F.countDistinct(F.col('userjourney_id')).alias(
                'num_user_journeys'),
            F.countDistinct(
                F.when(F.col('isconversion') == 1, F.col('loyalty_id'))
            ).alias('num_conversions'),
            F.countDistinct(F.col('loyalty_id')).alias('total_users'),
        )
    )
    # Window function to sum sales over booking_id
    booking_window = Window.partitionBy(F.col('booking_id'))

# Aggregate MTA outputs for attributed sales/units
    brand_mta_processed = (
        slas
        .groupBy(
            F.initcap(F.col('journey_type')).alias('journey_type'),
            F.col('userjourney_id'),
            F.col('booking_id'),
            F.col('marketing_type'),
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.col('campaign_id'),
            F.col('campaign_duration'),
            F.col('recalibration_factor'),
        )
        .agg(
            F.sum(F.col('attributed_recalibrated_units_qty')).alias(
                'attributed_recalibrated_units_qty'),
            F.sum(F.col('attributed_units_qty')).alias('attributed_units_qty'),
            F.sum(F.col('attributed_recalibrated_sales_amt')).alias(
                'attributed_recalibrated_sales_amt'),
            F.sum(F.col('attributed_sales_amt')).alias('attributed_sales_amt'),
            F.max(F.col('isconversion')).alias('isconversion'),
            F.max(F.col('normalized_weights')).alias('normalized_weights'),
            F.sum(F.col('normalized_weights')).alias(
                'normalized_total_weights'),
        )
        .groupBy(
            F.col('journey_type'),
            F.col('booking_id'),
            F.col('marketing_type'),
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.col('campaign_id'),
            F.col('campaign_duration'),
            F.col('recalibration_factor')
        )
        .agg(
            F.sum('attributed_recalibrated_units_qty').alias(
                'attributed_recalibrated_units_qty'),
            F.sum('attributed_units_qty').alias('attributed_units_qty'),
            F.sum('attributed_recalibrated_sales_amt').alias(
                'attributed_recalibrated_sales_amt'),
            F.sum('attributed_sales_amt').alias('attributed_sales_amt'),
            # Sum the per-journey isconversion values from the first groupBy.
            # After the first groupBy/agg, each row represents one unique userjourney with isconversion=max(0,1).
            # Summing these deduplicated values gives the count of converted journeys in this group.
            F.sum('isconversion').alias('conversions'),
            F.sum('normalized_total_weights').alias('modelling_weight'),
            F.sum(F.col('normalized_weights') * F.col('isconversion')
                  ).alias('attributed_conversions'),
            F.sum(F.col('normalized_weights') * F.col('isconversion') *
                  F.col('recalibration_factor')).alias('conversions_recalibrated')
        )
        .withColumns({
            'incremental_pct': F.col('attributed_recalibrated_sales_amt') / F.sum(F.col('attributed_recalibrated_sales_amt')).over(booking_window)
        }
        )
    )

    # Find total booking date window to filter UCM model
    booking_dates = (
        cme
        .agg(
            F.min(F.col('campaign_start_dt')).alias('booking_start_dt'),
            F.max(F.col('campaign_end_dt')).alias('booking_end_dt')
        )
    )

    # Get UCM data from Callibrated step
    # This is already filtered to booking dates and aggregated to a single combined, calibrated UCM
    # Note: For campaigns that contain multiple sub-categories, we will have to aggregate all UCM outputs and report combined UCM
    # This is because we don't have granularity to unpick and reallocate SKU-level incremental sales

    date_join_cond = (
        (F.col('week_start_dt') >= F.date_trunc('week', F.col('bd.booking_start_dt'))) &
        (F.col('week_start_dt') <= F.dateadd(
            F.date_trunc('week', F.col('bd.booking_end_dt')), 7))
    )

    base_price_aggregation = (
        bp
        .join(booking_dates.alias('bd'), date_join_cond, how='inner')
        .agg(F.avg(F.col('metric_value')).alias('avg_price'))
    )

    # If calibration metric is available - use this for baseline sales, otherwise use UCM

    has_calibrated_incrementality = (
        ic.filter(
            (F.col('metric_name') == 'adjusted_calibrated_incrementality')
            & F.col('metric_value').isNotNull()
        )
        .limit(1)
        .count() > 0
    )

    incrementality_metric = (
        'adjusted_calibrated_incrementality' if has_calibrated_incrementality
        else 'ucm_incrementality'
    )
    # TODO: Add alert if incrementality_metric is not 'adjusted_calibrated_incrementality'

    # Aggregate total incremental sales & use avg. base price to infer units
    # Sum metric_value across all rows (potentially multiple per super_category_name, etc.)
    # to ensure a single-row DataFrame for the cross join.
    # Note: All rows for a given metric_name should have the same unique_brand_name,
    # so we take max (which just returns the single value) when aggregating.
    # TODO Add explicit select statements to only select necessary columns from each table
    total_incremental_sales = (
        ic.filter(
            (F.col('metric_name') == incrementality_metric)
        )
        .agg(
            F.sum(F.col('metric_value')).alias('total_incremental_sales'),
            F.max(F.col('unique_brand_name')).alias('unique_brand_name')
        )
    )

    booking_incremental_metrics = (
        total_incremental_sales
        .join(base_price_aggregation.alias('bp'), how='cross')
        .withColumn('booking_incremental_units', F.col('total_incremental_sales') / F.col('bp.avg_price'))
        .select(
            F.col('unique_brand_name'),
            F.col('total_incremental_sales').alias(
                'booking_incremental_sales'),
            F.col('booking_incremental_units')
        )
    )

    # Combine user journey, MTA and UCM to consolidate all metrics
    mta_uj_combined = (
        brand_mta_processed.alias('mta')
        .join(user_journey_processed.alias('uj'), ['journey_type', 'booking_id', 'campaign_id', 'channel_name', 'subchannel_name'], 'inner')
        .join(F.broadcast(booking_incremental_metrics.alias('bi')), how='cross')
        .select(
            F.col('journey_type'),
            F.col('mta.booking_id'),
            F.col('marketing_type'),
            F.col('campaign_id'),
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.col('mta.campaign_duration'),
            F.col('mta.modelling_weight'),
            F.col('attributed_recalibrated_units_qty'),
            F.col('attributed_units_qty'),
            F.col('attributed_recalibrated_sales_amt'),
            F.col('attributed_sales_amt'),
            F.col('mta.conversions'),
            F.col('attributed_conversions'),
            F.col('uj.conversions').alias('user_journey_conversions'),
            F.col('num_user_journeys'),
            F.col('converted_user_journeys'),
            F.col('total_users'),
            F.col('num_conversions'),
            F.col('recalibration_factor'),
            F.col('conversions_recalibrated'),
            F.col('bi.booking_incremental_sales'),
            F.col('bi.booking_incremental_units'),
            F.col('bi.unique_brand_name'),
            F.col('incremental_pct'),
        )
        .withColumn(
            'incremental_sales_amt_exposed',
            F.greatest(F.lit(0), F.col('booking_incremental_sales')
                       * F.col('incremental_pct'))
        )
        .withColumn(
            'incremental_units_qty_exposed',
            F.greatest(F.lit(0), F.col('booking_incremental_units')
                       * F.col('incremental_pct'))
        )
    )

    # Set marketing hierarchy cd to NULL for DTP run_type campaigns
    if run_type == 'DTP':
        marketing_hierarchy_cd_col = F.lit(None).cast(
            'string').alias('marketing_hierarchy_cd')
    elif run_type == 'Pollen':
        marketing_hierarchy_cd_col = F.col('uc.marketing_hierarchy_cd')
    else:
        raise Exception(
            "Incorrect argument passed to integration function, please pass `run_type` as `Pollen` or `DTP`")

    # Filter unified campaign using measurement campaign execution to get campaign and channel details, which are required for reporting and analysis. This will also filter to in-scope channels based on CME
    uc_filtered = (
        uc.alias('uc')
        .join(cme, ['campaign_id', 'channel_name', 'subchannel_name'], 'inner')
        .select(
            F.col('uc.booking_id'),
            F.col('uc.job_bag_number'),
            F.col('campaign_id'),
            F.col('uc.campaign_name'),
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.col('media_spend_amt'),
            F.col('super_category_name'),
            F.col('sub_category_name'),
            marketing_hierarchy_cd_col,
            F.col('is_multi_channel'),
            F.col('overlapping_campaign_flag'),
        )
        .withColumn('campaign_type', F.when(F.col('is_multi_channel'), 'Multi Channel').otherwise('Single Channel'))
    )

    if product_type == 'brand':
        booking_inc_sales_col = F.col('booking_incremental_sales')
        booking_inc_units_col = F.col('booking_incremental_units')
        inc_pct_col = F.col('incremental_pct')
        inc_sales_exposed_col = F.col('incremental_sales_amt_exposed')
        inc_units_exposed_col = F.col('incremental_units_qty_exposed')
    elif product_type == 'offer':
        booking_inc_sales_col = F.lit(0).alias('booking_incremental_sales')
        booking_inc_units_col = F.lit(0).alias('booking_incremental_units')
        inc_pct_col = F.lit(0).alias('incremental_pct')
        inc_sales_exposed_col = F.lit(0).alias('incremental_sales_amt_exposed')
        inc_units_exposed_col = F.lit(0).alias('incremental_units_qty_exposed')
    else:
        raise Exception(
            "Incorrect argument passed to integration function, please pass `offer` or `brand`")
    # Combine with spend; ratios are derived after spend weighting
    all_metrics = (
        mta_uj_combined
        .join(uc_filtered, ['campaign_id', 'channel_name', 'subchannel_name'], how='left')
        .select(
            F.col('journey_type'),
            F.col('uc.booking_id'),
            F.lit(product_type.upper()).alias('product_type'),
            F.col('overlapping_campaign_flag'),
            F.col('campaign_type'),
            F.col('job_bag_number'),
            F.col('super_category_name'),
            F.col('sub_category_name'),
            F.col('marketing_type'),
            F.col('campaign_id'),
            F.col('campaign_name'),
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.col('marketing_hierarchy_cd'),
            F.col('campaign_duration'),
            F.col('modelling_weight'),
            F.col('attributed_recalibrated_units_qty'),
            F.col('attributed_units_qty'),
            F.col('attributed_recalibrated_sales_amt'),
            F.col('attributed_sales_amt'),
            F.col('mta.conversions'),
            F.col('attributed_conversions'),
            F.col('recalibration_factor'),
            F.col('conversions_recalibrated'),
            F.col('user_journey_conversions'),
            F.col('num_user_journeys'),
            F.col('converted_user_journeys'),
            F.col('total_users'),
            F.col('num_conversions'),
            F.col('unique_brand_name'),
            booking_inc_sales_col,
            booking_inc_units_col,
            inc_pct_col,
            inc_sales_exposed_col,
            inc_units_exposed_col,
            F.col('media_spend_amt')
        )
    )
    return all_metrics


def prepare_baseline_mta_integration(
    spark: SparkSession,
    incremental_shrinkage_path: str,
    campaign_execution_path: str,
    unified_campaign_path: str,
    sku_level_attributed_sales_units_brand_path: str,
    sku_level_attributed_sales_units_offer_path: str,
    pre_mta_brand_path: str,
    pre_mta_offer_path: str,
    base_price_path: str,
    reach_engagement_path: str,
    measurement_marketing_channel_hierarchy_path: str,
    published_campaign_reporting_path: str,
    output_path: str,
    run_date: str,
    correlation_id: str,
    campaign_period: Optional[str] = None,
    previous_measurement_campaign_reporting: Optional[str] = None,
    measurement_legacy_campaign_performance: Optional[str] = None,
    brand_data_path: Optional[str] = None,
    post_audit_path: Optional[str] = None,
    slack_topic_arn: Optional[str] = None,
    campaign_booking_media_channel_path: Optional[str] = None,
    overlapping_campaign_spend_weights_path: Optional[str] = None,
    measurement_campaign_reporting_audit_path: Optional[str] = None,
    fallback_metadata_path: Optional[str] = None,

) -> None:
    """
    Integrates baseline and MTA outputs for comparison analysis.

    This function:
    1. Reads all input data sources
    2. Performs necessary transformations and integrations (in order):
        - Integrated Incrementality and MTA outputs
        - For overlapping campaigns, applies spend weight adjustments
        - Filters to in scope marketing channels based on the hierarchy
        - Applies incrementality fallback adjustments.
    3. Writes the integrated output using safe S3 overwrite

    Args:
        spark: The SparkSession object.
        incremental_shrinkage_path: S3 path for calibrated incrementality output (IC).
        campaign_execution_path: S3 path for measurement execution table (CME).
        campaign_booking_media_channel_path: Optional S3 path for campaign booking media channel output containing brand_id.
        unified_campaign_path: S3 path for unified campaign tables (UC).
        sku_level_attributed_sales_units_brand_path: S3 path for SKU level output with attribution (SLASH).
        sku_level_attributed_sales_units_offer_path: S3 path for SKU level recalibration (SLASO).
        pre_mta_brand_path: S3 path for direct MTA output - brand (AMB).
        pre_mta_offer_path: S3 path for direct MTA output - offer (AMO).
        pre_requisite_mta_brand_path: S3 path for MTA pre-requisite data - brand (PRE_MTA_BRAND).
        pre_requisite_mta_offer_path: S3 path for MTA pre-requisite data - offer (PRE_MTA_OFFER).
        reach_engagement_path: S3 path for the During period reach_engagement output. Reach is
            always sourced from the During run and is used as the denominator in conversion_rate.
        output_path: S3 path where the integrated output will be saved.
        published_campaign_reporting_path: S3 path for published campaign reporting output.
        run_date: The pipeline execution date in YYYY-MM-DD format.
        correlation_id: Unique identifier for the pipeline run.
        marketing_channel_hierarchy_path: S3 path for measurement marketing channel hierarchy table to filter in-scope channels.
        campaign_period: Optional string indicating campaign period (pre, during, post) for additional metrics.
        previous_measurement_campaign_reporting: Optional S3 path for previous measurement campaign reporting output, required
        measurement_legacy_campaign_performance: Optional S3 path for legacy measurement campaign reporting output.
        slack_topic_arn: Optional string for Slack topic ARN to send notifications
        overlapping_campaign_spend_weights_path: Optional S3 path for overlapping campaign spend weights.
            When supplied, volume metrics are scaled by the booking's share of overlapping spend,
            matched on product type and applied to the During and Post components separately.
        measurement_campaign_reporting_audit_path: Optional S3 path for the measurement campaign reporting audit
            output, containing attributed sales/units metrics prior to spend-weight scaling, keyed by the
            same campaign dimensions as the main output.
        fallback_metadata_path: Optional S3 path for the run's incrementality
            fallback metadata parquet output.
        post_audit_path: Optional S3 path. When supplied, writes the intermediate post calculation built for audit purposes.

    Returns:
        None
    """
    # Initialize Slack messenger for notifications
    slack_messenger = SlackMessenger(
        topic_arn=slack_topic_arn,
        correlation_id=correlation_id
    )

    if 'pollen' in unified_campaign_path.lower():
        run_type = 'Pollen'
    else:
        run_type = 'DTP'

    # Read all input data sources

    ic = (
        spark.read.parquet(incremental_shrinkage_path)
        .select(
            F.col('unique_brand_name'),
            F.col('super_category_name'),
            F.col('sub_category_name'),
            F.col('metric_name'),
            F.col('metric_value'),
        )
    )

    cme = (
        spark.read.parquet(campaign_execution_path)
        .select(
            F.col('booking_id'),
            F.col('campaign_id'),
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.col('campaign_start_dt'),
            F.col('campaign_end_dt'),
            F.col('overlapping_campaign_flag')
        )
    )
    
    # Read only the columns needed for the join — mce is only used to get booking_id
    mce_booking_ids = (
        cme
        .select(F.col('booking_id'))
        .distinct()  
    )

    uc_columns = [
        'booking_id',
        'job_bag_number',
        'campaign_id',
        'campaign_name',
        'channel_name',
        'subchannel_name',
        'media_spend_amt',
        'super_category_name',
        'sub_category_name',
        'is_multi_channel',
    ]

    if run_type == 'Pollen':
        uc_columns.append('marketing_hierarchy_cd')

    uc = (
        spark.read.parquet(unified_campaign_path)
        .select(*uc_columns)
        .join(
            mce_booking_ids.alias('mce'),
            F.col('job_bag_number') == F.col('mce.booking_id'),
            how='left_semi',
        )
    )

    slasb = (
        spark.read.parquet(sku_level_attributed_sales_units_brand_path)
        .select(
            F.col('journey_type'),
            F.col('userjourney_id'),
            F.col('booking_id'),
            F.col('marketing_type'),
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.col('campaign_id'),
            F.col('campaign_duration'),
            F.col('recalibration_factor'),
            F.col('attributed_recalibrated_units_qty'),
            F.col('attributed_units_qty'),
            F.col('attributed_recalibrated_sales_amt'),
            F.col('attributed_sales_amt'),
            F.col('isconversion'),
            F.col('normalized_weights'),
        )
    )

    slaso = (
        spark.read.parquet(sku_level_attributed_sales_units_offer_path)
        .select(
            F.col('journey_type'),
            F.col('userjourney_id'),
            F.col('booking_id'),
            F.col('marketing_type'),
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.col('campaign_id'),
            F.col('campaign_duration'),
            F.col('recalibration_factor'),
            F.col('attributed_recalibrated_units_qty'),
            F.col('attributed_units_qty'),
            F.col('attributed_recalibrated_sales_amt'),
            F.col('attributed_sales_amt'),
            F.col('isconversion'),
            F.col('normalized_weights'),
        )
    )

    pre_mta_brand = (
        spark.read.parquet(pre_mta_brand_path)
        .select(
            F.col('journey_type'),
            F.col('userjourney_id'),
            F.col('loyalty_id'),
            F.col('booking_id'),
            F.col('marketing_type'),
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.col('campaign_id'),
            F.col('campaign_duration'),
            F.col('event_name'),
            F.col('transaction_key'),
            F.col('isconversion')
        )
    )

    pre_mta_offer = (
        spark.read.parquet(pre_mta_offer_path)
        .select(
            F.col('journey_type'),
            F.col('userjourney_id'),
            F.col('loyalty_id'),
            F.col('booking_id'),
            F.col('marketing_type'),
            F.col('channel_name'),
            F.col('subchannel_name'),
            F.col('campaign_id'),
            F.col('campaign_duration'),
            F.col('event_name'),
            F.col('transaction_key'),
            F.col('isconversion')
        )
    )

    bp = (
        spark.read.parquet(base_price_path)
        .select(
            F.col('week_start_dt'),
            F.col('metric_name'),
            F.col('metric_value')
        )
    )

    # Load measurement marketing channel hierarchy and get in-scope channels
    inscope_marketing_channel_names = (
        spark
        .read
        .parquet(measurement_marketing_channel_hierarchy_path)
        .select('marketing_channel')
        .withColumn('channel_name', F.lower(F.col('marketing_channel')))
        .drop('marketing_channel')
        .dropDuplicates()
    )

    #  Load data for fallback
    published_campaign_reporting = (
        spark
        .read
        .parquet(published_campaign_reporting_path)
        .select(
            "job_bag_number",
            "marketing_type",
            "campaign_duration",
            "product_type",
            "incremental_sales_amt_exposed",
            "attributed_recalibrated_sales_amt"
        )
    )

    if campaign_period == CampaignDurations.CAMPAIGN_DURATION_DURING:
        legacy_measurement_campaign_reporting = (
            spark
            .read
            .parquet(measurement_legacy_campaign_performance)
            .select(
                "item_cd",
                "campaign_id",
                "period",
                "uplift",
                "media_cost"
            )
        )

        brand_data = spark.read.parquet(brand_data_path).select("item_cd")

    else:
        legacy_measurement_campaign_reporting = None
        brand_data = None

    # Set current timestamp variable for consistent timestamps in output
    current_ts = F.current_timestamp()

    if campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST:
        if not previous_measurement_campaign_reporting:
            raise ValueError(
                "previous_measurement_campaign_reporting is required when campaign_period is 'Post'")
        previous_reporting = spark.read.parquet(
            previous_measurement_campaign_reporting)

        # Backward compatibility: older reporting outputs may not include brand_id.
        brand_id_col = get_brand_id_column(previous_reporting)
        # Outputs written before weighting carry no weight, so they are treated as already unweighted.
        spend_weight_column_name = resolve_column_name(
            previous_reporting, 'spend_weight')
        spend_weight_col = (
            F.col(spend_weight_column_name).cast('double')
            if spend_weight_column_name
            else F.lit(1.0)
        ).alias('spend_weight')
        during_columns = [
            'correlation_id',
            brand_id_col,
            'campaign_id',
            'booking_id',
            'campaign_duration',
            'journey_type',
            'marketing_type',
            'channel_name',
            'subchannel_name',
            'marketing_hierarchy_cd',
            'sub_category_name',
            'attributed_conversions',
            'incremental_sales_amt_exposed',
            'super_category_name',
            'campaign_name',
            'attributed_recalibrated_sales_amt',
            'attributed_recalibrated_units_qty',
            'incremental_units_qty_exposed',
            'attributed_units_qty',
            'attributed_sales_amt',
            'conversions_recalibrated',
            'recalibration_factor',
            'job_bag_number',
            'nectar_sales_amt',
            'non_nectar_sales_amt',
            'media_spend_amt',
            'campaign_type',
            'roas_exposed',
            'iroas_exposed',
            'base_sales_amt_exposed',
            'uplift_exposed_sales_amt',
            'uplift_exposed_units_qty',
            'num_user_journeys',
            'num_conversions',
            'attributed_recalibrated_sales_amt_per_uj',
            'attributed_recalibrated_sales_amt_per_conversion',
            'overlapping_campaign_flag',
            'conversion_per_uj',
            'conversion_rate',
            'load_ts',
            'modelling_weight',
            spend_weight_col,
            F.lit(run_type).alias('run_type'),
            current_ts.alias('dag_run_ts'),
        ]
        # product_type is only usable as a join key when the previous output actually carries it.
        product_type_column_name = resolve_column_name(
            previous_reporting, 'product_type')
        has_product_type = (
            product_type_column_name is not None
            and previous_reporting.filter(F.col(product_type_column_name).isNotNull()).limit(1).count() > 0
        )
        if has_product_type:
            # Aliased because the post-period join key check is case-sensitive.
            during_columns.append(
                F.col(product_type_column_name).alias('product_type'))

        measurement_campaign_reporting_during = previous_reporting.select(
            *during_columns)
    else:
        # Create empty dataframe with same schema for During period
        measurement_campaign_reporting_during = spark.createDataFrame(
            [],
            schema=MeasurementCampaignReportingPollen().measures_schema
        )

    # Run function to combine the baseline & MTA outputs
    offer_integration = combine_baseline_mta(
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc, 'offer', run_type)
    brand_integration = combine_baseline_mta(
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc, 'brand', run_type)

    # Union the offer and brand results
    integration_output = offer_integration.union(brand_integration)

    reporting_audit = add_to_reporting_audit(integration_output.select(AUDIT_KEY_COLUMNS),
                                             integration_output,
                                             prefix='integration',
                                             additional_columns=SPEND_WEIGHT_SCALED_COLUMNS)

    # Snapshot pre-weighting metrics for the unscaled audit output; apply_spend_weights below
    # only reassigns integration_output, so this reference is unaffected either way.

    spend_weights = (
        load_spend_weights(spark, overlapping_campaign_spend_weights_path)
        if overlapping_campaign_spend_weights_path
        else None
    )

    if spend_weights is None:
        # No weights configured, so rows carry their full value rather than an unknown weight.
        integration_output = integration_output.withColumn(
            'spend_weight', F.lit(1.0))
        reporting_audit = add_to_reporting_audit(reporting_audit,
                                                 integration_output, prefix='overlap',
                                                 additional_literals={'spend_weight': 1.0})

    elif campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST:
        # Post runs cover During+Post, so each component is weighted after the During baseline is removed.
        integration_output = integration_output.withColumn(
            'spend_weight', F.lit(None).cast(DoubleType()))
        reporting_audit = add_to_reporting_audit(reporting_audit,
                                                 integration_output, prefix='overlap',
                                                 additional_columns=['spend_weight'])
    else:
        integration_output = apply_spend_weights(
            integration_output, spend_weights, CampaignDurations.CAMPAIGN_DURATION_DURING
        )

        reporting_audit = add_to_reporting_audit(reporting_audit,
                                                 integration_output, prefix='overlap',
                                                 additional_columns=[
                                                     "spend_weight",],
                                                 )

    if campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST:
        # Integration rows hold the During+Post totals, so they line up with During+Post output rows.
        reporting_audit = reporting_audit.withColumn('campaign_duration', F.lit('During+Post'))

    # Read reach_engagement output (always from the During run) and aggregate per booking/channel/subchannel.
    # Channel and subchannel names are lowercased to enable case-insensitive joining.
    reach_df = (
        spark.read.parquet(reach_engagement_path)
        .select(
            F.col('booking_id').alias('re_booking_id'),
            F.lower(F.col('channel_name')).alias('re_channel_name'),
            F.lower(F.col('subchannel_name')).alias('re_subchannel_name'),
            F.col('reach_cnt'),
        )
        .groupBy('re_booking_id', 're_channel_name', 're_subchannel_name')
        .agg(F.sum('reach_cnt').alias('reach_cnt'))
    )

    # Join reach onto the combined integration output. Reach is used as the denominator for
    # conversion_rate; it always comes from the During run regardless of campaign_period.
    integration_output = (
        integration_output
        .join(
            F.broadcast(reach_df),
            on=(
                (F.col('booking_id') == F.col('re_booking_id')) &
                (F.lower(F.col('channel_name')) == F.col('re_channel_name')) &
                (F.lower(F.col('subchannel_name')) == F.col('re_subchannel_name'))
            ),
            how='left'
        )
        .drop('re_booking_id', 're_channel_name', 're_subchannel_name')
        .transform(calculate_conversion_rate)
    )

    # Additional calculated fields that are required including conversions, incrementality ratios and metadata
    integration_output_uplift = (
        integration_output
        .transform(add_derived_metrics)
        .withColumn(
            'conversion_per_uj',
            safe_div(F.col('conversions'), F.col('num_user_journeys'))
        )
        .withColumn(
            'nectar_sales_amt',  # Adding these as NULL for now, will remove entirely from schema
            F.lit(None).cast(DoubleType())
        )
        .withColumn(
            'non_nectar_sales_amt',  # Adding these as NULL for now, will remove entirely from schema
            F.lit(None).cast(DoubleType())
        )
        .withColumn(
            'run_date',
            F.lit(run_date)
        )
        .withColumn(
            'correlation_id',
            F.lit(correlation_id)
        )
        .withColumn(
            'dag_run_ts',
            current_ts
        )
        .withColumn(
            'load_ts',
            current_ts
        )
        .withColumn(
            'run_type',
            F.lit(run_type)
        )
    )
    # Single source-of-truth rule for brand_id:
    # Post uses previous MCR output, During/default uses current booking-brand mapping.
    if campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST:
        previous_brand_source = previous_reporting
        campaign_duration_column_name = next(
            (column_name for column_name in previous_brand_source.columns if column_name.lower(
            ) == 'campaign_duration'),
            None,
        )
        if campaign_duration_column_name:
            previous_brand_source = previous_brand_source.filter(
                F.lower(F.trim(F.col(campaign_duration_column_name))
                        ) == CampaignDurations.CAMPAIGN_DURATION_DURING.lower()
            )

        previous_brand_map = previous_brand_source.select(
            F.col('booking_id'),
            get_brand_id_column(previous_brand_source).alias('brand_id'),
            F.col('load_ts'),
        )

        latest_previous_brand_window = Window.partitionBy('booking_id').orderBy(
            F.col('load_ts').desc())  # NOSONAR pythonenterprise:S7181
        previous_brand_map = (
            previous_brand_map
            # Exclude null brands before ranking so a null latest row cannot be selected.
            .filter(F.col('brand_id').isNotNull())
            .withColumn('rn', F.row_number().over(latest_previous_brand_window))
            .filter(F.col('rn') == 1)
            .drop('rn', 'load_ts')
        )

        integration_output_uplift = ensure_io_columns_present(
            integration_output_uplift)
        integration_output_uplift = (
            integration_output_uplift.alias('io')
            .join(
                F.broadcast(previous_brand_map).alias('pb'),
                on='booking_id',
                how='left',
            )
            .select(
                *[F.col(f'io.{col_name}') for col_name in SELECTED_IO_COLUMNS],
                F.col('pb.brand_id').alias('brand_id'),
            )
        )
    else:
        # For During/default runs, preserve current mapping-based brand_id enrichment behaviour.
        integration_output_uplift = add_brand_id_to_integration_output(
            integration_output_uplift=integration_output_uplift,
            spark=spark,
            campaign_booking_media_channel_path=campaign_booking_media_channel_path,
        )

    schema = [
        F.col('unique_brand_name'),
        F.col('brand_id'),
        F.col('channel_name'),
        F.col('correlation_id'),
        F.col('campaign_id'),
        F.col('booking_id'),
        F.col('campaign_duration'),
        F.col('journey_type'),
        F.col('marketing_type'),
        F.col('subchannel_name'),
        F.col('marketing_hierarchy_cd'),
        F.col('sub_category_name'),
        F.col('attributed_conversions'),
        F.col('incremental_sales_amt_exposed'),
        F.col('super_category_name'),
        F.col('campaign_name'),
        F.col('attributed_recalibrated_sales_amt'),
        F.col('attributed_recalibrated_units_qty'),
        F.col('incremental_units_qty_exposed'),
        F.col('attributed_units_qty'),
        F.col('attributed_sales_amt'),
        F.col('conversions_recalibrated'),
        F.col('recalibration_factor'),
        F.col('job_bag_number'),
        F.col('nectar_sales_amt'),
        F.col('non_nectar_sales_amt'),
        F.col('media_spend_amt'),
        F.col('campaign_type'),
        F.col('roas_exposed'),
        F.col('iroas_exposed'),
        F.col('base_sales_amt_exposed'),
        F.col('uplift_exposed_sales_amt'),
        F.col('uplift_exposed_units_qty'),
        F.col('num_user_journeys'),
        F.col('num_conversions'),
        F.col('attributed_recalibrated_sales_amt_per_uj'),
        F.col('attributed_recalibrated_sales_amt_per_conversion'),
        F.col('conversion_per_uj'),
        F.col('conversion_rate'),
        F.col('load_ts'),
        F.col('run_type'),
        F.col('dag_run_ts'),
        F.col('overlapping_campaign_flag'),
        F.col('modelling_weight'),
        F.col('product_type'),
        F.col('spend_weight')]

    # Finalise output schema
    measurement_campaign_reporting_df = (
        integration_output_uplift
        .select(*schema).dropDuplicates())

    print(f'Campaign Period Variable is {campaign_period}')

    if campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST:

        print('Running Post period integration logic')

        measurement_campaign_reporting_df = (
            measurement_campaign_reporting_df
            .withColumn("campaign_duration", F.lit("During+Post"))
        )

        # Calculate Post period metrics by subtracting During from During+Post
        post_period_df = calculate_post_period_metrics(
            measurement_campaign_reporting_df=measurement_campaign_reporting_df,
            measurement_campaign_reporting_during=measurement_campaign_reporting_during,
            slack_messenger=slack_messenger,
            reach_df=reach_df,
            spend_weights=spend_weights,
            post_audit_path=post_audit_path,
        )

        if spend_weights is not None:
            # The weighted During+Post rows are rebuilt from their components and returned alongside Post.
            measurement_campaign_reporting_df = post_period_df.select(
                *schema).dropDuplicates()
        else:
            # Union During+Post with calculated Post period
            # Only select columns that exist in post_period_df to avoid schema mismatch
            post_period_columns = [
                col for col in measurement_campaign_reporting_df.columns if col in post_period_df.columns]
            measurement_campaign_reporting_df = (
                measurement_campaign_reporting_df.select(*schema)
                .unionByName(post_period_df.select(*post_period_columns), allowMissingColumns=True)
                .dropDuplicates()
                # Post rows arrive without the column, so they inherit the same full weight.
                .withColumn('spend_weight', F.coalesce(F.col('spend_weight'), F.lit(1.0)))
            )

    if run_type == 'Pollen':
        print(
            'Pollen run detected, Filter to include only in-scope channels from hierarchy')

        measurement_campaign_reporting_df = (
            measurement_campaign_reporting_df
            .withColumn('channel_name', F.lower(F.col('channel_name')))
            .join(inscope_marketing_channel_names, on='channel_name', how='left_semi')
        )

    elif run_type == 'DTP':
        print('DTP run detected, skipping marketing channel filtering')
    else:
        raise Exception(
            "Incorrect argument passed for run_type, please pass `Pollen` or `DTP`")

    needs_fallback = False
    # DTP receives no campaign period, so fallback can't be scoped and is skipped.
    if run_type == 'Pollen':
        pre_fallback_df = measurement_campaign_reporting_df
        floored = False
        if (campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST
                and IncrementalityFallbackConfig().floor_post_incrementality):
            measurement_campaign_reporting_df, floored = floor_post_incrementality(
                measurement_campaign_reporting_df, slack_messenger)

        needs_fallback = check_if_incrementality_fallback_needed(
            measurement_campaign_reporting_df.filter(period_mask(campaign_period)))

        if needs_fallback:
            measurement_campaign_reporting_df = apply_period_fallback(
                measurement_campaign_reporting_df,
                campaign_period,
                published_campaign_reporting,
                legacy_measurement_campaign_reporting,
                brand_data,
                uc,
                slack_messenger
            )

        reporting_audit = add_fallback_audit(
            reporting_audit, pre_fallback_df, measurement_campaign_reporting_df,
            needs_fallback, floored
        )

        if floored or needs_fallback:
            measurement_campaign_reporting_df = (
                measurement_campaign_reporting_df.transform(add_derived_metrics).select(*schema))

    # Write output using safe S3 overwrite
    print(
        f"[Data Output] Writing integrated baseline + MTA output to {output_path}")

    spark_s3_overwrite(output_path, measurement_campaign_reporting_df)

    if measurement_campaign_reporting_audit_path:
        logger.info(
            f"[Data Output] Writing audit output to {measurement_campaign_reporting_audit_path}"
        )

        if spend_weights is not None:
            # Reference weight matches whichever period's scaling actually applies to this
            # audit snapshot: During weight scales During rows, Post weight scales Post rows.
            reference_weight_period = (
                CampaignDurations.CAMPAIGN_DURATION_POST
                if campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST
                else CampaignDurations.CAMPAIGN_DURATION_DURING
            )
            reference_weights = (
                spend_weights
                .filter(F.col('weight_period') == reference_weight_period)
                .select(
                    'booking_id',
                    'product_type',
                    F.col('spend_weight').alias('reference_spend_weight'),
                )
            )

            reporting_audit = reporting_audit.join(
                F.broadcast(reference_weights), on=['booking_id', 'product_type'], how='left'
            )

        spark_s3_overwrite(
            measurement_campaign_reporting_audit_path, reporting_audit)

    if fallback_metadata_path:
        fallback_metadata = get_fallback_metadata(spark=spark,
                                                  correlation_id=correlation_id,
                                                  needs_fallback=needs_fallback)
        spark_s3_overwrite(fallback_metadata_path, fallback_metadata, type='json')

    print(f"[{correlation_id}] Baseline MTA integration completed successfully")


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    """Entrypoint wrapper compatible with project conventions.

    Parses required command-line arguments for input and output S3 paths, along with
    metadata parameters, then invokes prepare_baseline_mta_integration.

    Args:
        spark: SparkSession provided by the caller.
        command_line_args: Optional list of CLI arguments to parse (for programmatic calls).
            If None, uses sys.argv by default.

    Command-line Arguments:
        --incremental-shrinkage-path (str): S3 path for calibrated incrementality output (IC).
        --campaign-execution-path (str): S3 path for measurement campaign execution table (CME).
        --campaign-booking-media-channel-path (str, optional): S3 path for campaign booking media channel output containing brand_id.
        --overlapping-campaign-spend-weights-path (str, optional): S3 path for overlapping campaign
            spend weights, keyed by booking, product type and campaign period.
        --unified-campaign-path (str): S3 path for unified campaign data (UC).
        --sku-level-attributed-sales-units-brand-path (str): S3 path for SKU level attributed sales/units - brand (SLASB).
        --sku-level-attributed-sales-units-offer-path (str): S3 path for SKU level attributed sales/units - offer (SLASO).
        --pre-mta-brand-path (str): S3 path for MTA pre-requisite data - brand.
        --pre-mta-offer-path (str): S3 path for MTA pre-requisite data - offer.
        --base-price-path (str): S3 path for UCM base price data.
        --reach-engagement-path (str): S3 path for During period reach_engagement output.
            Reach is always sourced from the During run and used as the conversion_rate denominator.
        --measurement-marketing-channel-hierarchy-path (str): S3 path for measurement marketing
            channel hierarchy used to filter in-scope channels.
        --published-campaign-reporting-path (str): S3 path for published campaign reporting data.
        --measurement-legacy-campaign-performance (str): S3 path for legacy campaign performance data.
            Required when --campaign-period is 'During'.
        --output-path (str): S3 path where the integrated output will be saved.
        --previous-measurement-campaign-reporting (str, optional): S3 path for the During period
            measurement campaign reporting output. Required when --campaign-period is 'Post'.
        --measurement-campaign-reporting-audit-path (str, optional): S3 path for the measurement campaign reporting audit output.
        --run-date (str): Pipeline execution date in YYYY-MM-DD format.
        --correlation-id (str): Unique identifier for the pipeline run.
        --slack-topic-arn (str): ARN of the Slack topic for notifications.
        --campaign-period (str, optional): Campaign period — 'During' or 'Post'. Defaults to None.


    Raises:
        ArgumentError: If required command-line arguments are missing or invalid.
    """
    parser = ThrowingArgumentParser(description="Baseline MTA Integration")

    # Input paths
    parser.add_argument(
        "--incremental-shrinkage-path",
        type=str,
        required=True,
        help="S3 path for calibrated incrementality output (IC)"
    )
    parser.add_argument(
        "--campaign-execution-path",
        type=str,
        required=True,
        help="S3 path for campaign execution table (CME)"
    )
    parser.add_argument(
        "--campaign-booking-media-channel-path",
        type=str,
        required=False,
        default=None,
        help="Optional S3 path for campaign booking media channel output containing brand_id"
    )
    parser.add_argument(
        "--overlapping-campaign-spend-weights-path",
        type=str,
        required=False,
        default=None,
        help="Optional S3 path for overlapping campaign spend weights"
    )
    parser.add_argument(
        "--unified-campaign-path",
        type=str,
        required=True,
        help="S3 path for unified campaign (UC)"
    )
    parser.add_argument(
        "--sku-level-attributed-sales-units-brand-path",
        type=str,
        required=True,
        help="S3 path for SKU level output with attribution (SLASH)"
    )
    parser.add_argument(
        "--sku-level-attributed-sales-units-offer-path",
        type=str,
        required=True,
        help="S3 path for SKU level recalibration (SLASO)"
    )
    parser.add_argument(
        "--pre-mta-brand-path",
        type=str,
        required=True,
        help="S3 path for MTA pre-requisite data - brand (PRE_MTA_BRAND)"
    )
    parser.add_argument(
        "--pre-mta-offer-path",
        type=str,
        required=True,
        help="S3 path for MTA pre-requisite data - offer (PRE_MTA_OFFER)"
    )
    parser.add_argument(
        "--base-price-path",
        type=str,
        required=True,
        help="S3 path for UCM base price data)"
    )
    parser.add_argument(
        "--reach-engagement-path",
        type=str,
        required=True,
        help="S3 path for During period reach_engagement output (used as conversion_rate denominator)"
    )
    parser.add_argument(
        "--measurement-marketing-channel-hierarchy-path",
        type=str,
        required=True,
        help="S3 path for measurement marketing channel hierarchy"
    )
    parser.add_argument(
        "--published-campaign-reporting-path",
        type=str,
        required=True,
        help="S3 path for published measurement campaign reporting"
    )

    parser.add_argument(
        "--measurement-legacy-campaign-performance",
        type=str,
        # TODO(HC): Needed if during run - add some conditional logic
        required=False,
        default=None,
        help="S3 path for legacy campaign performance"
    )

    parser.add_argument(
        "--brand-data-path",
        type=str,
        required=False,
        default=None,
        help="Optional S3 path for brand data"
    )

    # Output path
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path where the integrated output will be saved"
    )

    # Metadata
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline execution date in YYYY-MM-DD format"
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the pipeline run"
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN of the Slack topic for notifications."
    )
    parser.add_argument(
        "--campaign-period",
        type=str,
        required=False,
        default=None,
        help="Campaign period: 'During', 'Post'"
    )
    parser.add_argument(
        "--previous-measurement-campaign-reporting",
        type=str,
        required=False,
        default=None,
        help="S3 path for previous measurement campaign reporting (During period)"
    )
    parser.add_argument(
        "--measurement-campaign-reporting-audit-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for the measurement campaign reporting audit output"
    )
    parser.add_argument(
        "--fallback-metadata-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for the incrementality fallback metadata parquet output",
    )
    parser.add_argument(
        "--post-audit-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for an audit output of the intermediate During+Post/During join, before differencing"
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_baseline_mta_integration(
        spark=spark,
        incremental_shrinkage_path=known_args.incremental_shrinkage_path,
        campaign_execution_path=known_args.campaign_execution_path,
        campaign_booking_media_channel_path=known_args.campaign_booking_media_channel_path,
        unified_campaign_path=known_args.unified_campaign_path,
        sku_level_attributed_sales_units_brand_path=known_args.sku_level_attributed_sales_units_brand_path,
        sku_level_attributed_sales_units_offer_path=known_args.sku_level_attributed_sales_units_offer_path,
        pre_mta_brand_path=known_args.pre_mta_brand_path,
        pre_mta_offer_path=known_args.pre_mta_offer_path,
        base_price_path=known_args.base_price_path,
        reach_engagement_path=known_args.reach_engagement_path,
        measurement_marketing_channel_hierarchy_path=known_args.measurement_marketing_channel_hierarchy_path,
        output_path=known_args.output_path,
        run_date=known_args.run_date,
        correlation_id=known_args.correlation_id,
        slack_topic_arn=known_args.slack_topic_arn,
        campaign_period=known_args.campaign_period,
        previous_measurement_campaign_reporting=known_args.previous_measurement_campaign_reporting,
        measurement_legacy_campaign_performance=known_args.measurement_legacy_campaign_performance,
        brand_data_path=known_args.brand_data_path,
        overlapping_campaign_spend_weights_path=known_args.overlapping_campaign_spend_weights_path,
        measurement_campaign_reporting_audit_path=known_args.measurement_campaign_reporting_audit_path,
        fallback_metadata_path=known_args.fallback_metadata_path,
        published_campaign_reporting_path=known_args.published_campaign_reporting_path,
        post_audit_path=known_args.post_audit_path,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName(
        "MeasurementCampaignReporting").getOrCreate())
