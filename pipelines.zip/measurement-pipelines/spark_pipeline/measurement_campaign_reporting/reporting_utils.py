
from typing import Dict, Optional

from pyspark.sql import Column, DataFrame, functions as F
from spark_pipeline.utils.pipeline_utils import safe_div


# Volume metrics scaled by the overlapping-campaign spend weight. Media spend and
# num_user_journeys are deliberately excluded; ratios are recomputed from these instead.
SPEND_WEIGHT_SCALED_COLUMNS = [
    "attributed_sales_amt",
    "attributed_recalibrated_sales_amt",
    "attributed_units_qty",
    "attributed_recalibrated_units_qty",
    "incremental_sales_amt_exposed",
    "incremental_units_qty_exposed",
    "attributed_conversions",
    "conversions_recalibrated",
    "num_conversions",
]

AUDIT_KEY_COLUMNS = [
    "booking_id",
    "job_bag_number",
    "unique_brand_name",
    "super_category_name",
    "sub_category_name",
    "marketing_type",
    "subchannel_name",
    "product_type",
    "campaign_duration",
    "campaign_id",
    "channel_name",
    "journey_type",
]

FALLBACK_AUDIT_COLUMNS = {
    "state": "string",
    "control_factor": "double",
    "ratio": "double",
}

INCREMENTALITY_AUDIT_COLUMNS = [
    "incremental_sales_amt_exposed",
    "attributed_recalibrated_sales_amt"
]


def add_derived_metrics(df: DataFrame) -> DataFrame:
    """
    Single definition of the reporting columns derived from the volume metrics.

    Call on any rows whose volume metrics were created or changed (scaled, differenced, rebuilt).
    ROAS/iROAS are NULL on zero spend, which the ROAS validation relies on to skip rows.

    Args:
        df: DataFrame containing the attributed, incremental, spend and journey volume columns.

    Returns:
        DataFrame with the derived columns added or replaced.
    """
    sales = F.col("attributed_recalibrated_sales_amt")
    units = F.col("attributed_recalibrated_units_qty")
    incremental_sales = F.col("incremental_sales_amt_exposed")
    incremental_units = F.col("incremental_units_qty_exposed")
    base_sales = sales - incremental_sales

    return df.withColumns({
        "base_sales_amt_exposed": base_sales,
        "uplift_exposed_sales_amt": safe_div(incremental_sales, base_sales),
        "uplift_exposed_units_qty": safe_div(incremental_units, units - incremental_units),
        "roas_exposed": sales / F.col("media_spend_amt"),
        "iroas_exposed": incremental_sales / F.col("media_spend_amt"),
        "attributed_recalibrated_sales_amt_per_uj": safe_div(sales, F.col("num_user_journeys")),
        "attributed_recalibrated_sales_amt_per_conversion": safe_div(sales, F.col("num_conversions")),
    })


def calculate_conversion_rate(df: DataFrame) -> DataFrame:
    """
    Adds or overwrites the conversion_rate column using During-period reach as the denominator.

    conversion_rate = (conversions_recalibrated / reach_cnt) * 100, expressed as a percentage.
    Defaults to 0.0 when reach_cnt is null or zero.

    Args:
        df: DataFrame containing conversions_recalibrated and reach_cnt columns.

    Returns:
        DataFrame with conversion_rate column added or replaced.
    """

    conversion_rate = safe_div(F.col('conversions_recalibrated'), F.col('reach_cnt')) * 100

    df = (
        df
        .withColumn(
            'conversion_rate',
            F.when(F.col('reach_cnt').isNotNull() & (F.col('reach_cnt') > 0), conversion_rate).otherwise(F.lit(0.0))
        )
    )

    return df


def normalised_audit_keys() -> Dict[str, Column]:
    """Return case-insensitive audit key expressions."""
    # Null-safe, as Post rows carry no unique_brand_name.
    return {
        f"_key_{column_name}": F.coalesce(
            F.lower(F.trim(F.col(column_name).cast("string"))), F.lit("\u0000")
        )
        for column_name in AUDIT_KEY_COLUMNS
    }


def add_to_reporting_audit(audit_df: DataFrame,
                           processed_df: DataFrame,
                           prefix: str,
                           additional_columns: Optional[list] = None,
                           additional_literals: Optional[dict] = None) -> DataFrame:
    """
    Adds prefixed versions of key reporting audit columns to the DataFrame.

    Keys are matched lowercased and trimmed, so steps that change their casing (the channel filter,
    Post separation) still line up with the base rows.

    Args:
        audit_df: DataFrame containing the reporting audit columns.
        processed_df: DataFrame containing the processed data to be joined.
        prefix: String prefix to add to the audit columns.
        additional_columns (Optional): List of additional columns from the processed_df to include in the join.
        additional_literals (Optional): Dictionary of additional literal values to include in the join.

    Returns:
        DataFrame with prefixed reporting audit columns added.
    """

    columns = set(INCREMENTALITY_AUDIT_COLUMNS + (additional_columns or []))
    prefixed_columns = [F.col(col).alias(f"{prefix}_{col}") for col in columns]

    additional_literals = [F.lit(value).alias(f"{prefix}_{key}") for key, value in (additional_literals or {}).items()]

    normalised_keys = normalised_audit_keys()
    processed_df = processed_df.select(
        *[key.alias(name) for name, key in normalised_keys.items()], *prefixed_columns, *additional_literals
    )

    audit_df = (
        audit_df
        .withColumns(normalised_keys)
        .join(processed_df, on=list(normalised_keys), how='left')
        .drop(*normalised_keys)
    )

    return audit_df


def add_fallback_audit(
    audit_df: DataFrame,
    pre_fallback_df: DataFrame,
    fallback_df: DataFrame,
    needs_fallback: bool,
    floored: bool,
) -> DataFrame:
    """Add pre- and post-fallback values, appending rows created during Post separation first."""
    normalised_keys = normalised_audit_keys()
    missing_keys = (
        pre_fallback_df.select(AUDIT_KEY_COLUMNS)
        .withColumns(normalised_keys)
        .join(
            audit_df.select(*[key.alias(name) for name, key in normalised_keys.items()]),
            on=list(normalised_keys),
            how="left_anti",
        )
        .select(*AUDIT_KEY_COLUMNS)
    )
    audit_df = audit_df.unionByName(missing_keys, allowMissingColumns=True)

    fallback_df = fallback_df.withColumns({
        column_name: F.lit(None).cast(data_type)
        for column_name, data_type in FALLBACK_AUDIT_COLUMNS.items()
        if column_name not in fallback_df.columns
    })

    audit_df = add_to_reporting_audit(
        audit_df, pre_fallback_df, "pre_fallback", ["incremental_units_qty_exposed"]
    )
    return add_to_reporting_audit(
        audit_df, fallback_df, "fallback",
        ["incremental_units_qty_exposed", *FALLBACK_AUDIT_COLUMNS],
        {"floored": floored, "is_fallback": needs_fallback},
    )
