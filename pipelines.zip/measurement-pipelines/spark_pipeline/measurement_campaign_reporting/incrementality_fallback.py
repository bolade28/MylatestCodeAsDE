import logging
from functools import reduce
from typing import Optional, Tuple

from spark_pipeline.common.variables import CampaignDurations, IncrementalityFallbackConfig, FallbackTypes
from spark_pipeline.measurement_campaign_reporting.post_period_utils import POST_JOIN_KEYS, normalise_join_key
from spark_pipeline.utils.slack_utils import SlackMessenger

from pyspark.sql import functions as F, Column, DataFrame, SparkSession
from pyspark.sql.types import DoubleType, StringType


logger = logging.getLogger(__name__)

# The only columns the floor or fallback can change.
FALLBACK_ADJUSTED_COLUMNS = [
    "incremental_sales_amt_exposed", "incremental_units_qty_exposed"]


def apply_period_fallback(
    df: DataFrame, campaign_period: str, published_campaign_reporting: DataFrame,
    legacy_measurement_campaign_reporting: Optional[DataFrame] = None, brand_data: Optional[DataFrame] = None,
    unified_campaign: Optional[DataFrame] = None, slack_messenger: Optional[SlackMessenger] = None
) -> DataFrame:
    """
    Apply fallback to BRAND rows in the run's period; on Post runs, carry each change into its During+Post row.

    Post campaign transforms can lead to negative incrementality, which is floored at 0.

    _pre prefixed columns are used to maintain the original values of the adjusted columns
    before any fallback is applied, so deltas can be calculated.
    """
    is_post_run = campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST
    pre_columns = {f"_pre_{c}": F.col(c) for c in FALLBACK_ADJUSTED_COLUMNS}

    eligible_rows = period_mask(campaign_period) & brand_product_mask()
    period_rows = df.filter(eligible_rows)
    if period_rows.isEmpty():
        return df

    period_rows = period_rows.withColumns(pre_columns)
    other_rows = df.filter(~eligible_rows)

    adjusted = apply_fallback(
        period_rows, campaign_period, published_campaign_reporting,
        legacy_measurement_campaign_reporting, brand_data, unified_campaign,
        slack_messenger
    )
    if is_post_run:
        if IncrementalityFallbackConfig().floor_post_incrementality:
            adjusted = floor_incrementality(adjusted)
        other_rows = propagate_post_changes(
            adjusted, other_rows)

    return adjusted.drop(*pre_columns).unionByName(other_rows, allowMissingColumns=True)


def apply_fallback(
    integration_output: DataFrame, campaign_duration: str, published_campaign_reporting: DataFrame,
    legacy_measurement_campaign_reporting: Optional[DataFrame] = None, brand_data: Optional[DataFrame] = None,
    unified_campaign: Optional[DataFrame] = None, slack_messenger: Optional[SlackMessenger] = None
) -> DataFrame:
    """
    Applies the fallback methodology to integration output.
    Checks the appropriate fallback method to use based on campaign duration and control type.

    The control fallback calibrates aggregate incrementality to the control uplift, then applies
    that factor to granular rows. The published fallback scales attributed sales by a configured
    percentile of published campaign ratios.
    """

    config = IncrementalityFallbackConfig()
    fallback_method = get_fallback_method(
        config, campaign_duration, integration_output)

    fallback_ratio = None

    if fallback_method == FallbackTypes.FALLBACK_CONTROL:
        fallback_adjusted_output = apply_control_fallback(
            config, integration_output, legacy_measurement_campaign_reporting,
            brand_data, unified_campaign)

        #  if control method does not produce a result, use fallback published
        if fallback_adjusted_output is None:
            fallback_method = FallbackTypes.FALLBACK_PUBLISHED
            if slack_messenger:
                slack_messenger.send_message(
                    event_type="Measurement Campaign Reporting - Incrementality Fallback Control None",
                    text="Warning: Control fallback did not produce a result, falling back to published method."
                )

    if fallback_method == FallbackTypes.FALLBACK_PUBLISHED:
        fallback_adjusted_output, fallback_ratio = apply_published_fallback(
            config, campaign_duration, integration_output, published_campaign_reporting)

        fallback_adjusted_output = fallback_adjusted_output.withColumn(
            "control_factor", F.lit(None).cast(DoubleType()))

    # Cast new columns to floats
    fallback_adjusted_output = (
        fallback_adjusted_output
        .withColumn("ratio", F.lit(fallback_ratio).cast(DoubleType()))
        .withColumn("state", F.lit(fallback_method).cast(StringType()))
    )

    return fallback_adjusted_output


def propagate_post_changes(
    post_rows: DataFrame, during_plus_post_rows: DataFrame,
) -> DataFrame:
    """
    Carry the fallback's change to each Post row into its During+Post row, so During+Post = During + Post.

    Before fallback, every matched During+Post row already equals During + Post. Fallback moves Post's
    incremental sales and units by delta = final - _pre_, so adding the same delta to the During+Post
    row keeps the identity without recomputing it from During.

    Steps:
        1. Compute the delta for each Post row and keep the rows where either delta is non-zero.
        2. Match Post to During+Post on normalise_join_key over POST_JOIN_KEYS + product_type,
           which absorbs the casing differences between separated Post rows and During+Post rows.
        3. Add the delta (0 when unmatched) to the During+Post incremental columns; nothing else changes.

    Returns:
        The During+Post rows with adjusted incremental volumes. Derived metrics are left to the caller.

    Raise error when keys are shared by more than one changed Post row or when changed Post rows have no During+Post row.
    """

    delta_key = F.concat_ws(
        "\u0001",
        *[F.coalesce(normalise_join_key(c), F.lit("\u0000"))
          for c in POST_JOIN_KEYS + ["product_type"]],
    )
    delta_columns = [f"_delta_{c}" for c in FALLBACK_ADJUSTED_COLUMNS]

    # Delta column is the difference between the final and pre-fallback values for each adjusted column.
    # Compute the delta for each Post row and keep only the changed rows.
    deltas = (
        post_rows
        .withColumns({f"_delta_{c}": F.col(c) - F.col(f"_pre_{c}") for c in FALLBACK_ADJUSTED_COLUMNS})
        .filter(reduce(lambda a, b: a | b, [F.col(d) != 0 for d in delta_columns]))
        .groupBy(delta_key.alias("_delta_key"))
        .agg(F.count(F.lit(1)).alias("_rows"), *[F.first(d).alias(d) for d in delta_columns])
    )

    keyed_during_plus_post = during_plus_post_rows.withColumn("_delta_key", delta_key)
    during_plus_post_keys = (
        keyed_during_plus_post
        .select(
            "_delta_key",
            F.lit(True).alias("_matched")
        )
        .distinct())

    unique_deltas = deltas.filter(F.col("_rows") == 1).drop("_rows")

    # Check validity of join keys:
    summary = (
        deltas
        .join(during_plus_post_keys, on="_delta_key", how="left")
        .agg(
            F.collect_list(
                F.when(F.col("_rows") > 1, F.col("_delta_key"))
            ).alias("duplicate_keys"),
            F.count(
                F.when((F.col("_rows") == 1) & F.col("_matched").isNull(), 1)
            ).alias("unmatched_count"),
        )
        .first()
    )
    duplicate_keys, unmatched_count = summary["duplicate_keys"], summary["unmatched_count"]

    if duplicate_keys:
        raise RuntimeError(
            "Incrementality Fallback failure - Duplicate Post keys found")
    if unmatched_count:
        raise RuntimeError(
            "Incrementality Fallback failure - Unmatched Post keys found")

    # Propagate unique deltas into During+Post rows.
    during_plus_post_propogated = (
        keyed_during_plus_post
        .join(F.broadcast(unique_deltas), on="_delta_key", how="left")
        .withColumns({c: F.col(c) + F.coalesce(F.col(f"_delta_{c}"), F.lit(0.0)) for c in FALLBACK_ADJUSTED_COLUMNS})
        .drop("_delta_key", *delta_columns)
    )

    return during_plus_post_propogated


def floor_post_incrementality(
    df: DataFrame, slack_messenger: Optional[SlackMessenger] = None
) -> Tuple[DataFrame, bool]:
    """
    Floor Post incrementality at 0, carry each change into its During+Post row and alert.

    Returns the frame and whether any Post row was floored.
    """
    is_post = period_mask(CampaignDurations.CAMPAIGN_DURATION_POST)
    pre_columns = {f"_pre_{c}": F.col(c) for c in FALLBACK_ADJUSTED_COLUMNS}

    if df.filter((F.col('incremental_sales_amt_exposed') < 0)).isEmpty():
        floored = False
        return df, floored

    logger.warning("Floored Post row(s) at 0 incrementality")
    if slack_messenger:
        slack_messenger.send_message(
            event_type="Measurement Campaign Reporting - Post Incrementality Floored",
            text="Post rows floored at 0 incrementality",
        )

    post_rows = floor_incrementality(df.filter(is_post).withColumns(pre_columns))
    during_plus_post_rows = propagate_post_changes(post_rows, df.filter(~is_post))
    floored = True

    return post_rows.drop(*pre_columns).unionByName(during_plus_post_rows), floored


def floor_incrementality(post_rows: DataFrame) -> DataFrame:
    """Zero incremental sales and units where incremental sales are negative."""
    negative = F.col("incremental_sales_amt_exposed") < 0
    return post_rows.withColumns({c: F.when(negative, F.lit(0.0)).otherwise(F.col(c)) for c in FALLBACK_ADJUSTED_COLUMNS})


def period_mask(campaign_period: str) -> Column:
    """Rows of the run's period."""
    return F.coalesce(F.initcap(F.trim(F.col("campaign_duration"))) == campaign_period, F.lit(False))


def brand_product_mask() -> Column:
    """Rows eligible for incrementality fallback under MCR's canonical product-type convention."""
    return F.coalesce(F.upper(F.col('product_type')) == F.lit('BRAND'), F.lit(False))


def check_if_incrementality_fallback_needed(integration_output: DataFrame) -> bool:
    """Return whether eligible BRAND incremental sales meet or exceed attributed sales."""

    incremental_greater_than_attr = (
        integration_output
        .filter(brand_product_mask())
        .groupBy("product_type")
        .agg(
            F.sum("incremental_sales_amt_exposed").alias(
                "total_incremental_sales_amt_exposed"),
            F.sum("attributed_recalibrated_sales_amt").alias(
                "total_attributed_recalibrated_sales_amt"),
        )
        .filter(
            (F.col("total_attributed_recalibrated_sales_amt") > 0) &
            (F.col("total_incremental_sales_amt_exposed") >=
             F.col("total_attributed_recalibrated_sales_amt"))
        )
    )

    return not incremental_greater_than_attr.isEmpty()


def get_fallback_method(config: IncrementalityFallbackConfig, campaign_duration: str, integration_output: DataFrame):
    """
    Determine the fallback method to use based on the campaign duration, channels included in booking and
    and campaign duration.
    """

    channels = integration_output.agg(
        F.collect_set("channel_name").alias("channels")
    ).first()["channels"]

    if not channels:
        return FallbackTypes.FALLBACK_PUBLISHED

    is_control_type = (
        len(channels) == 1 and
        any(
            control_type.upper() in channels[0].upper()
            for control_type in config.control_lift_marketing_types
        )
    )

    if campaign_duration == CampaignDurations.CAMPAIGN_DURATION_DURING and is_control_type:
        return FallbackTypes.FALLBACK_CONTROL

    return FallbackTypes.FALLBACK_PUBLISHED


def apply_control_fallback(
    config: IncrementalityFallbackConfig, integration_output: DataFrame,
    legacy_measurement_campaign_reporting: DataFrame, brand_data: DataFrame, unified_campaign: DataFrame
):
    """
    Calibrate aggregate incrementality to control uplift and apply the factor to granular rows.
    If configured, negative control lift incrementality will be floored at 0.
    Return None if no usable control campaign exists.
    """

    control_campaign = get_control_campaign_report(
        legacy_measurement_campaign_reporting, brand_data, unified_campaign, integration_output)

    control_fallback_factor = calculate_control_fallback_factor(
        config, integration_output, control_campaign)

    # If a relevant control campaign does not exist for every row, we cannot use this method
    if control_fallback_factor is None:
        return None

    integration_fallback = apply_control_fallback_factor(integration_output, control_fallback_factor)

    if config.floor_control_lift_incrementality:
        integration_fallback = floor_incrementality(integration_fallback)

    return integration_fallback


def get_control_campaign_report(
    legacy_measurement_campaign_reporting: DataFrame, brand_data: DataFrame, unified_campaign: DataFrame,
    integration_output: DataFrame
) -> DataFrame:

    aggregated_legacy_reporting = (
        legacy_measurement_campaign_reporting
        .join(brand_data, on="item_cd", how="inner")
        .groupBy("campaign_id", "period")
        .agg(
            F.first("uplift", ignorenulls=True).alias("uplift"),
            F.first("media_cost", ignorenulls=True).alias("media_cost"),
        )
    )

    campaign = unified_campaign.join(
        integration_output.select("job_bag_number", "campaign_id").distinct(),
        on=["job_bag_number", "campaign_id"],
        how="inner"
    )

    control_campaign_report = (
        aggregated_legacy_reporting
        .join(
            campaign.select("job_bag_number", "campaign_id").distinct(),
            on="campaign_id",
            how="inner"
        )
        # One uplift estimate per campaign: super categories are summed, so the factor stays one row per campaign
        .groupBy("job_bag_number", "period")
        .agg(F.sum("uplift").alias("uplift"))
    )

    return control_campaign_report


def calculate_control_fallback_factor(config: IncrementalityFallbackConfig, integration_output: DataFrame,
                                      control_campaign: DataFrame) -> Optional[DataFrame]:
    """
    Calculate the factor that aligns aggregate incrementality estimate to control uplift.
    Return None if any input campaign-period key lacks a usable control factor.
    """
    aggregated_output = (
        aggregate_reporting(integration_output)
        .filter(
            (F.upper(F.col("product_type")) == F.lit(
                config.control_fallback_product_type))
            & (F.col("attributed_recalibrated_sales_amt") != 0)
        )
        .select(
            "job_bag_number",
            "campaign_duration",
            "product_type",
            "incremental_sales_amt_exposed",
            "attributed_recalibrated_sales_amt",
        )
    )

    control_lift = control_campaign.select(
        "job_bag_number",
        F.initcap(F.col("period")).alias("campaign_duration"),
        "uplift",
    )

    control_result = (
        aggregated_output
        .join(
            control_lift,
            on=["job_bag_number", "campaign_duration"],
            how="inner",
        )
        .filter(F.col("uplift") < F.col("attributed_recalibrated_sales_amt"))
        .select(
            "job_bag_number",
            "campaign_duration",
            "product_type",
            "incremental_sales_amt_exposed",
            "attributed_recalibrated_sales_amt",
            "uplift",
            (F.col("uplift") / F.col("incremental_sales_amt_exposed")).cast(DoubleType()).alias("control_factor")
        )
        .filter(F.col("control_factor").isNotNull())
    )

    join_keys = ["job_bag_number", "campaign_duration"]
    missing_controls = (
        integration_output.select(*join_keys).distinct()
        .join(
            control_result.select(*join_keys).distinct(),
            on=join_keys,
            how="left_anti",
        )
    )

    if not missing_controls.isEmpty():
        return None

    return control_result


def apply_control_fallback_factor(integration_output: DataFrame, control_fallback_factor: DataFrame) -> DataFrame:
    """Apply the aggregate control factor to each granular row for the booking and period."""
    join_keys = ["job_bag_number", "campaign_duration",]

    integration_output_fallback = (
        integration_output
        .join(
            control_fallback_factor.select(
                *join_keys, "control_factor"),
            on=join_keys,
            how="inner",
        )
        .withColumns({
            "fallback_ratio": F.col("control_factor"),
            "incremental_sales_amt_exposed": F.col("incremental_sales_amt_exposed") * F.col("control_factor"),
            "incremental_units_qty_exposed": F.col("incremental_units_qty_exposed") * F.col("control_factor"),
        })
        .drop("fallback_ratio")
    )

    return integration_output_fallback


def apply_published_fallback(config: IncrementalityFallbackConfig, campaign_duration: str,
                             integration_output: DataFrame, published_campaign_reporting: DataFrame
                             ) -> Tuple[DataFrame, float]:
    """Scale incrementality by the configured percentile of eligible published campaign ratios."""

    fallback_ratio = compute_fallback_ratio(
        config, campaign_duration, published_campaign_reporting)

    # ratio is applied to the disaggregated incrementality (ie. at channel level)

    integration_fallback = apply_fallback_ratio(
        integration_output, fallback_ratio)

    return integration_fallback, fallback_ratio


def apply_fallback_ratio(integration_output: DataFrame, fallback_ratio: float) -> DataFrame:
    return integration_output.withColumns({
        "incremental_sales_amt_exposed": F.col("attributed_recalibrated_sales_amt") * fallback_ratio,
        "incremental_units_qty_exposed": F.col("attributed_recalibrated_units_qty") * fallback_ratio,
    })


def compute_fallback_ratio(config: IncrementalityFallbackConfig, campaign_duration: str,
                           published_campaign_reporting: DataFrame) -> float:
    """Return the configured percentile of eligible published campaign ratios."""

    aggregated_published_campaigns = aggregate_reporting(published_campaign_reporting)

    published_ratios = get_published_ratios(config, campaign_duration, aggregated_published_campaigns)

    ratio = published_ratios.approxQuantile("published_ratio", [config.fallback_percentile], 0.01)[0]

    return ratio


def get_published_ratios(config: IncrementalityFallbackConfig, campaign_duration: str,
                         aggregated_published_campaigns: DataFrame) -> DataFrame:
    """
    Eligible rows are from the same campaign duration and have non-null sales values, positive attributed sales,
    and a ratio below the configured maximum.

    Return eligible ratios; raise RuntimeError if fewer than the configured minimum qualify.
    """

    aggregated_published_campaigns = (
        aggregated_published_campaigns
        .filter(
            (F.col("attributed_recalibrated_sales_amt").isNotNull())
            & (F.col("incremental_sales_amt_exposed").isNotNull())
            & (F.col("attributed_recalibrated_sales_amt") > 0)
            & (F.col("campaign_duration") == campaign_duration)
            & brand_product_mask()
        )
    )

    published_campaigns_ratios = aggregated_published_campaigns.withColumn(
        "published_ratio",
        F.col("incremental_sales_amt_exposed") /
        F.col("attributed_recalibrated_sales_amt")
    )

    eligible_ratios = published_campaigns_ratios.filter(
        (F.col("published_ratio").isNotNull())
        & (F.col("published_ratio") < config.max_fallback_ratio)
    )

    if eligible_ratios.count() < config.min_published_campaigns:
        raise RuntimeError("Insufficient published campaigns for fallback")

    return eligible_ratios


def aggregate_reporting(integration_output: DataFrame) -> DataFrame:

    aggregated = (
        integration_output
        .groupby('job_bag_number', 'campaign_duration', 'product_type')
        .agg(
            F.sum("incremental_sales_amt_exposed").alias(
                "incremental_sales_amt_exposed"),
            F.sum("attributed_recalibrated_sales_amt").alias(
                "attributed_recalibrated_sales_amt"),
        )
        .select(
            'job_bag_number',
            'campaign_duration',
            'product_type',
            'incremental_sales_amt_exposed',
            'attributed_recalibrated_sales_amt'
        )
    )

    return aggregated


def get_fallback_metadata(spark: SparkSession, correlation_id: str, needs_fallback: bool) -> DataFrame:
    """
    Write fallback status and run ID to S3 for downstream metadata publishing.
    This is used to identify fallback campaigns, so they are not used for subsequent fallback calculations.
    """

    return spark.createDataFrame([{
        "correlation_id": correlation_id,
        "is_fallback": needs_fallback
    }])
