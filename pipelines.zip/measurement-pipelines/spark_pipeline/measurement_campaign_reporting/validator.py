from typing import List
from prettytable import PrettyTable
from pyspark.sql import DataFrame, functions as F


def null_validation_checker(df: DataFrame, other_null_cols: List[str] = None, nectar_flag=False) -> DataFrame:
    """
    Checks all columns for NULL values and computes the DataFrame for failed rows.
    By default all columns of a dataframe are considered mandatory.
    1. fail_dataframe: Contains rows with at least ONE NULL value.

    Args:
        df: The input PySpark DataFrame.

    Returns:
        A dataframe of all rows that failed the null validation.
    """

    # 1. Build the dynamic validation expression

    nectar_null_cols = []

    if nectar_flag:
        nectar_null_cols = [c for c in df.columns if 'nectar' in c.lower()]
    if other_null_cols is None:
        other_null_cols = []

    nullable_cols = nectar_null_cols + other_null_cols

    # Get non-nullable columns
    non_nullable_cols = [col for col in df.columns if col not in nullable_cols]

    # Handle edge case: no columns to validate
    if not non_nullable_cols:
        empty_df = df.limit(0)
        return empty_df.withColumn(
            "failed_null_columns",
            F.array().cast("array<string>")
        ).withColumn(
            "null_column_count",
            F.lit(0)
        )

    # Build condition to find rows with any NULL in non-nullable columns
    non_null_condition = F.lit(False)
    for col_name in non_nullable_cols:
        non_null_condition = non_null_condition | F.col(col_name).isNull()

    # Filter to get only invalid rows
    df_invalid = df.filter(non_null_condition)

    # Build array of failed column names for each row - FIXED VERSION
    failed_col_expressions = []
    for col_name in non_nullable_cols:
        failed_col_expressions.append(
            F.when(F.col(col_name).isNull(), F.lit(col_name))
        )

    df_invalid_cols = df_invalid.withColumn(
        "failed_null_columns",
        F.filter(
            F.array(*failed_col_expressions),
            lambda x: x.isNotNull()
        )
    )

    # Add count of failed columns
    df_invalid_cols = df_invalid_cols.withColumn(
        "null_column_count",
        F.size(F.col("failed_null_columns"))
    )

    # Reorder columns so failed_null_columns and null_column_count come first
    reordered_cols = ["failed_null_columns", "null_column_count"] + [
        c for c in df_invalid_cols.columns if c not in ["failed_null_columns", "null_column_count"]
    ]

    return df_invalid_cols.select(*reordered_cols)


# Function to convert a PySpark DataFrame to a PrettyTable
def spark_df_to_prettytable(df, limit: int = 20):
    """
    Converts a PySpark DataFrame to a PrettyTable for display.

    Args:
        df (DataFrame): The PySpark DataFrame.
        limit (int): Number of rows to display (default = 20).
    """
    # Collect rows to the driver (safe for small datasets)
    rows = df.limit(limit).collect()

    # Create PrettyTable with DataFrame column names
    table = PrettyTable()
    table.field_names = df.columns

    # Add each row to the table
    for row in rows:
        # Convert Row object to list of values
        table.add_row([row[c] for c in df.columns])

    # Disable width limitation
    table.max_width = None

    # Optional: align columns and adjust formatting
    table.align = "l"
    print(table)
    return table
