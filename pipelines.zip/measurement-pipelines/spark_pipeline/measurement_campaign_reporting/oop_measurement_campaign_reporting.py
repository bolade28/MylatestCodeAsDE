from pyspark.sql import DataFrame, SparkSession, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T
from typing import List, Optional, Tuple, Dict, Any
from functools import reduce
from abc import ABC, abstractmethod
from spark_pipeline.common.throwing_argument_parser import (
    ThrowingArgumentParser,
    str_to_bool,
)
from spark_pipeline.common.variables import UNTARGETED_CHANNELS
from spark_pipeline.schemas.attribution_pre_requisite import (
    AttributionPreRequisiteSchema,
)
from spark_pipeline.schemas.baseline_attribution_integration_sku_level import (
    BaselineAttributionIntegrationSkuLevel,
)
from spark_pipeline.schemas.measurement_campaign_reporting import (
    MeasurementCampaignReporting,
)
from spark_pipeline.schemas.mta_attribution_model import AttributionModel
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


class BaseDataProcessor(ABC):
    """Abstract base class for data processing functionality"""

    def __init__(self, untargeted_channels: List[str] = UNTARGETED_CHANNELS):
        self.untargeted_channels = untargeted_channels

    def get_latest_data(self, data_df: DataFrame, filter_df: DataFrame) -> DataFrame:
        """
        Retrieves the latest records for all booking IDs.
        """
        has_campaign_duration = "campaign_duration" in data_df.columns

        if has_campaign_duration and "campaign_duration" in filter_df.columns:
            join_keys = ["booking_id", "campaign_duration"]
        else:
            join_keys = ["booking_id"]

        # Step 1: Restrict data to relevant booking_id (+ campaign_duration if available)
        joined_df = data_df.join(filter_df, on=join_keys, how="inner")

        # Step 2: Find latest load_ts per grouping keys
        latest_ts_df = (
            joined_df.groupBy(*join_keys)
            .agg(F.max("load_ts").alias("latest_load_ts"))
        )

        # Step 3: Join back to keep only rows with the latest timestamp
        filtered_data = (
            joined_df.alias("a").join(
                latest_ts_df.alias("b"),
                [joined_df[k] == latest_ts_df[k] for k in join_keys] +
                [joined_df["load_ts"] == latest_ts_df["latest_load_ts"]],
                "inner"
            )
        )

        # For Code 1 style, select only columns from joined_df
        filtered_data = filtered_data.select("a.*")

        return filtered_data

    def process_nectar_data(self, reporting_df: DataFrame) -> DataFrame:
        """
        Process nectar data calculations - common to both code versions
        """
        # === 1. Aggregate totals in one pass ===
        totals = (
            reporting_df
            .agg(
                F.sum("attributed_recalibrated_sales_amt").alias("total_attributed_recalibrated_sales_amt"),
                F.sum("attributed_recalibrated_units_qty").alias("total_attributed_recalibrated_units_qty"),
                F.sum("incremental_sales_amt_exposed").alias("total_incremental_sales_amt_exposed"),
                F.sum("incremental_units_qty_exposed").alias("total_incremental_units_qty_exposed"),
                F.sum("nectar_sales_amt").alias("total_nectar_sales_amt"),
                F.sum("non_nectar_sales_amt").alias("total_non_nectar_sales_amt")
            )
            .collect()[0]
        )

        total_attributed_sales = totals["total_attributed_recalibrated_sales_amt"] or 0.0
        total_attributed_qty = totals["total_attributed_recalibrated_units_qty"] or 0.0
        total_incremental_sales_amt_exposed = totals["total_incremental_sales_amt_exposed"] or 0.0
        total_incremental_units_qty_exposed = totals["total_incremental_units_qty_exposed"] or 0.0
        total_nectar_sales = totals["total_nectar_sales_amt"] or 0.0
        total_non_nectar_sales = totals["total_non_nectar_sales_amt"] or 0.0

        # === 2. Add constants and calculate initial weights ===
        df = (
            reporting_df
            .withColumn("nectar_sales_amt", F.lit(total_nectar_sales).cast(T.DoubleType()))
            .withColumn("non_nectar_sales_amt", F.lit(total_non_nectar_sales).cast(T.DoubleType()))
            .withColumn(
                "nectar_weights",
                F.when(F.col("nectar_sales_amt") > 0,
                       F.col("nectar_sales_amt") / (F.col("nectar_sales_amt") + F.col("non_nectar_sales_amt"))
                       ).otherwise(F.lit(0.0))
            )
            .withColumn(
                "non_nectar_weights",
                F.when((F.col("nectar_sales_amt") + F.col("non_nectar_sales_amt")) > 0,
                       F.col("non_nectar_sales_amt") / (F.col("nectar_sales_amt") + F.col("non_nectar_sales_amt"))
                       ).otherwise(F.lit(0.0))
            )
        )

        # === 3. Calculate new nectar/non-nectar sales & units ===
        df = (
            df
            .withColumn("new_nectar_sales_amt", F.lit(total_incremental_sales_amt_exposed).cast(T.DoubleType()) * F.col("nectar_weights"))
            .withColumn("new_non_nectar_sales_amt", F.lit(total_incremental_sales_amt_exposed).cast(T.DoubleType()) * F.col("non_nectar_weights"))
            .withColumn("new_nectar_units_qty", F.lit(total_incremental_units_qty_exposed).cast(T.DoubleType()) * F.col("nectar_weights"))
            .withColumn("new_non_nectar_units_qty", F.lit(total_incremental_units_qty_exposed).cast(T.DoubleType()) * F.col("non_nectar_weights"))
        )

        # ---- 4. New nectar weights (sales & qty) ----
        df = (
            df
            .withColumn("new_nectar_weight",
                        F.when(F.lit(total_attributed_sales) != 0,
                               F.col("attributed_recalibrated_sales_amt") / F.lit(total_attributed_sales).cast(T.DoubleType()))
                        .otherwise(F.lit(0.0)))
            .withColumn("new_nectar_qty_weight",
                        F.when(F.lit(total_attributed_qty) != 0,
                               F.col("attributed_recalibrated_units_qty") / F.lit(total_attributed_qty).cast(T.DoubleType()))
                        .otherwise(F.lit(0.0)))
        )

        # === 4. Calculate total non-nectar weights (only once) ===
        non_nectar_totals = (
            df.filter(
                F.lower(F.col("channel_name")).isin([ch.lower() for ch in self.untargeted_channels]) |
                F.lower(F.col("marketing_type")).isin(["in-store"])
            )
            .agg(
                F.sum("new_nectar_weight").alias("total_non_nectar_weights"),
                F.sum("new_nectar_qty_weight").alias("total_non_nectar_qty_weights")
            )
            .collect()[0]
        )

        total_non_nectar_weights = non_nectar_totals["total_non_nectar_weights"] or 0.0
        total_non_nectar_qty_weights = non_nectar_totals["total_non_nectar_qty_weights"] or 0.0

        # === 5. Add incremental metrics ===
        df = (
            df
            .withColumn(
                "incremental_nectar_sales_amt",
                F.when(F.col("new_nectar_sales_amt") > 0,
                       F.col("new_nectar_sales_amt") * F.col("new_nectar_weight")
                       ).otherwise(F.lit(0.0))
            )
            .withColumn(
                "new_non_nectar_weights",
                F.when(
                    (F.lower(F.col("channel_name")).isin([ch.lower() for ch in self.untargeted_channels])) |
                    (F.lower(F.col("marketing_type")).isin(["in-store"])),
                    F.col("new_nectar_weight") / F.lit(total_non_nectar_weights).cast(T.DoubleType())
                ).otherwise(F.lit(0.0))
            )
            .withColumn(
                "incremental_nectar_units_qty",
                F.when(F.col("new_nectar_units_qty") > 0,
                       F.col("new_nectar_units_qty") * F.col("new_nectar_qty_weight")
                       ).otherwise(F.lit(0.0))
            )
            .withColumn(
                "new_non_nectar_qty_weights",
                F.when(
                    (F.lower(F.col("channel_name")).isin(["onsite-gol", "in-store", "magazine"])) |
                    (F.lower(F.col("marketing_type")).isin(["in-store"])),
                    F.col("new_nectar_qty_weight") / F.lit(total_non_nectar_qty_weights)
                ).otherwise(F.lit(0.0))
            )
        )

        # === 6. Final totals and base sales ===
        df = (
            df
            .withColumn(
                "incremental_non_nectar_sales_amt",
                F.when((F.col("new_non_nectar_sales_amt") > 0) & (F.col("new_non_nectar_weights") > 0),
                       F.col("new_non_nectar_sales_amt") * F.col("new_non_nectar_weights")
                       ).otherwise(F.lit(0.0))
            )
            .withColumn(
                "total_incremental_nectar_sales_amt",
                F.col("incremental_nectar_sales_amt") + F.col("incremental_non_nectar_sales_amt")
            )
            .withColumn(
                "incremental_non_nectar_units_qty",
                F.when((F.col("new_non_nectar_units_qty") > 0) & (F.col("new_non_nectar_qty_weights") > 0),
                       F.col("new_non_nectar_units_qty") * F.col("new_non_nectar_qty_weights")
                       ).otherwise(F.lit(0.0))
            )
            .withColumn(
                "total_incremental_nectar_units_qty",
                F.col("incremental_nectar_units_qty") + F.col("incremental_non_nectar_units_qty")
            )
            .withColumn(
                "base_sales_amt_nectar_exposed",
                F.when(F.col("attributed_recalibrated_sales_amt") > 0,
                       F.col("attributed_recalibrated_sales_amt") - F.col("total_incremental_nectar_sales_amt")
                       ).otherwise(F.lit(0.0))
            )
        )

        return df

    def _get_user_journey_metrics(self, attribution_pre_requisite_filtered: DataFrame) -> Tuple[Optional[DataFrame], int, int]:
        """
        Helper function to get user journey metrics
        """
        # Pre-calculate total conversion counts
        conv_stats = attribution_pre_requisite_filtered.agg(
            F.countDistinct(F.when(F.col("isconversion") == 1, F.col("userjourney_id"))).alias("conv_count"),
            F.countDistinct("userjourney_id").alias("total_count")
        ).first()
        conv_count, total_count = conv_stats["conv_count"], conv_stats["total_count"]

        user_journey_metrics = None
        if self.dtp():
            user_journey_metrics = (
                attribution_pre_requisite_filtered
                .groupBy("channel_name", "campaign_id", "subchannel_name", "marketing_type")
                .agg(
                    F.countDistinct("userjourney_id").alias("num_user_journeys"),
                    F.countDistinct(F.when(F.col("isconversion") == 1, F.col("userjourney_id"))).alias("num_conversions"),
                )
            )

        return user_journey_metrics, conv_count, total_count

    def _build_unified_campaign_columns(self) -> List[str]:
        """Get columns for unified campaign selection"""
        unified_columns = [
            "campaign_id", "channel_name", "subchannel_name", "super_category_name",
            "sub_category_name", "campaign_name", "marketing_type"
        ]
        if self.dtp():
            unified_columns.append("job_bag_number")
        return unified_columns

    def _build_join_conditions(self, unified_campaign_df: DataFrame, filtered_df_with_factor: DataFrame) -> dict:
        """
        Build different join conditions based on requirements
        """
        conditions = {}

        # Unified campaign join condition
        if self.dtp():
            # Code 2 style join condition
            conditions['uni_join'] = (
                (F.lower(unified_campaign_df["campaign_id_uni"]) == F.lower(filtered_df_with_factor["campaign_id"])) &
                (F.lower(unified_campaign_df["marketing_type_uni"]) == F.lower(filtered_df_with_factor["marketing_type"])) &
                (F.lower(unified_campaign_df["channel_name_uni"]) == F.lower(filtered_df_with_factor["channel_name"]))
            )
        else:
            # Code 1 style join condition with subchannel exclusion
            subchannel_exclusion_pattern = r'meta|dv360|tube'
            is_excluded_subchannel = F.lower(F.col("subchannel_name")).rlike(subchannel_exclusion_pattern)

            base_condition = (
                (F.lower(unified_campaign_df["campaign_id_uni"]) == F.lower(filtered_df_with_factor["campaign_id"])) &
                (F.lower(unified_campaign_df["marketing_type_uni"]) == F.lower(filtered_df_with_factor["marketing_type"])) &
                (F.lower(unified_campaign_df["channel_name_uni"]) == F.lower(filtered_df_with_factor["channel_name"]))
            )

            subchannel_match = (
                F.lower(unified_campaign_df["subchannel_name_uni"]) == F.lower(filtered_df_with_factor["subchannel_name"])
            )

            full_condition = base_condition & subchannel_match
            conditions['uni_join'] = F.when(~is_excluded_subchannel, full_condition).otherwise(base_condition)

        # Attribution join condition (common to both)
        conditions['attr_join'] = (
            (F.lower(filtered_df_with_factor["campaign_id"]) == F.lower(F.col("campaign_id_attr"))) &
            (F.lower(filtered_df_with_factor["marketing_type"]) == F.lower(F.col("marketing_type_attr"))) &
            (F.lower(filtered_df_with_factor["channel_name"]) == F.lower(F.col("channel_name_attr"))) &
            (F.lower(filtered_df_with_factor["subchannel_name"]) == F.lower(F.col("subchannel_name_attr")))
        )

        return conditions

    def _apply_recalibration(self, df: DataFrame) -> DataFrame:
        """Apply recalibration based on version-specific logic"""
        if self.dtp():
            return df.withColumn(
                "conversions_recalibrated",
                F.when(F.lower(F.col("channel_name")).isin(["meta", "youtube", "dv360"]),
                       F.col("conversions_attr") * F.col("recalibration_factor")).otherwise(F.col("conversions_attr"))
            )
        else:
            return df.withColumn(
                "conversions_recalibrated",
                F.when(F.lower(F.col("subchannel_name")).rlike(r'meta|dv360|tube'),
                       F.col("conversions_attr") * F.col("recalibration_factor")).otherwise(F.col("conversions_attr"))
            )

    def _get_select_columns(self) -> List[Any]:
        """Get the final select columns based on version"""
        select_columns = [
            "booking_id", "campaign_id", "campaign_duration", "journey_type", "marketing_type",
            "channel_name", "subchannel_name", F.col("sub_category_name_uni").alias("sub_category_name"),
            F.col("conversions_attr").alias("conversions"), "incremental_sales_amt_exposed",
            F.col("super_category_name_uni").alias("super_category_name"),
            F.col("campaign_name_uni").alias("campaign_name"), "attributed_recalibrated_sales_amt",
            "attributed_recalibrated_units_qty", "incremental_units_qty_exposed", "attributed_units_qty",
            "attributed_sales_amt", "conversions_recalibrated", "recalibration_factor",
            "nectar_sales_amt", "non_nectar_sales_amt"
        ]

        if self.dtp():
            select_columns.extend([
                F.col("job_bag_number_uni").alias("job_bag_number"),
                F.col("num_user_journeys_uj").alias("num_user_journeys"),
                F.col("num_conversions_uj").alias("num_conversions")
            ])

        return select_columns

    def _get_roas_columns(self, win: Window) -> Dict[str, Any]:
        """Get ROAS columns based on version"""
        roas_columns = {
            "roas_exposed": F.when(F.sum("media_spend_amt").over(win) > 0,
                                   F.sum("attributed_recalibrated_sales_amt").over(win) /
                                   F.sum("media_spend_amt").over(win)).otherwise(F.lit(0.0)),
            "iroas_exposed": F.when(F.col("media_spend_amt") > 0,
                                    F.col("incremental_sales_amt_exposed") / F.col("media_spend_amt")).otherwise(0.0),
            "iroas_exposed_nectar": F.when(F.col("media_spend_amt") > 0,
                                           F.col("total_incremental_nectar_sales_amt") /
                                           F.col("media_spend_amt")).otherwise(0.0)
        }

        if self.dtp():
            roas_columns.update({
                "conversion_per_uj": F.when(F.col("num_user_journeys") > 0,
                                            F.col("num_conversions") / F.col("num_user_journeys")).otherwise(0.0),
                "attributed_recalibrated_sales_amt_per_uj": F.when(F.col("num_user_journeys") > 0,
                                                                   F.col("attributed_recalibrated_sales_amt") / F.col("num_user_journeys")).otherwise(0.0),
                "attributed_recalibrated_sales_amt_per_conversion": F.when(F.col("num_conversions") > 0,
                                                                           F.col("attributed_recalibrated_sales_amt") / F.col("num_conversions")).otherwise(0.0)
            })

        return roas_columns

    @abstractmethod
    def dtp(self) -> bool:
        """Abstract method to determine if user journey metrics should be included"""
        pass

    def process_booking_ids(
        self,
        baseline_df: DataFrame,
        unified_campaign: DataFrame,
        baseline_offer_df: DataFrame,
        reach_engagement: DataFrame,
        attribution_data_filtered: DataFrame,
        attribution_pre_requisite_filtered: DataFrame,
    ) -> List[DataFrame]:
        """
        Unified process_booking_ids function that handles both code versions
        """
        results_list = []
        win = Window.partitionBy("booking_id")

        # Get user journey metrics based on flag
        user_journey_metrics, conv_count, total_count = self._get_user_journey_metrics(
            attribution_pre_requisite_filtered
        )

        # Common processing steps
        attribution_aggr = attribution_data_filtered.groupBy(
            "channel_name", "campaign_id", "subchannel_name", "marketing_type"
        ).agg(F.sum("normalized_weights").alias("conversions"))

        campaign_type_df = (
            baseline_df.withColumn("is_non_direct", F.when(F.col("customer_journey_type") == "Non-direct", 1).otherwise(0))
            .groupBy("campaign_id")
            .agg((F.sum("is_non_direct") > 0).alias("has_non_direct"))
            .withColumn("campaign_type", F.when(F.col("has_non_direct"), "Multi Channel").otherwise("Single Channel"))
            .select("campaign_id", "campaign_type")
        )

        factor_df = baseline_offer_df.filter(F.col("recalibration_factor") > 0).select(
            "recalibration_factor", "channel_name", "campaign_id"
        ).distinct()

        # Unified campaign selection
        unified_campaign_df = unified_campaign.select(
            [F.col(c).alias(f"{c}_uni") for c in self._build_unified_campaign_columns()]
        ).distinct()

        reach_engagement_df = reach_engagement.select(
            [F.col(c).alias(f"{c}_reach") for c in [
                "campaign_id", "channel_name", "subchannel_name", "media_spend_amt", "marketing_type"
            ]]
        )

        if factor_df.count() > 0:
            # Aggregate baseline metrics
            baseline_aggr = baseline_df.groupBy(
                "booking_id", "campaign_id", "campaign_duration", "journey_type",
                "marketing_type", "channel_name", "subchannel_name"
            ).agg(
                F.sum("incremental_sales_amt_exposed").alias("incremental_sales_amt_exposed"),
                F.sum("attributed_recalibrated_sales_amt").alias("attributed_recalibrated_sales_amt"),
                F.sum("attributed_recalibrated_units_qty").alias("attributed_recalibrated_units_qty"),
                F.sum("attributed_sales_amt").alias("attributed_sales_amt"),
                F.sum("attributed_units_qty").alias("attributed_units_qty"),
                F.sum("incremental_units_qty_exposed").alias("incremental_units_qty_exposed"),
                F.sum("nectar_sales_amt").alias("nectar_sales_amt"),
                F.sum("non_nectar_sales_amt").alias("non_nectar_sales_amt")
            )

            # Join factors
            filtered_df_with_factor = baseline_aggr.join(F.broadcast(factor_df), ["channel_name", "campaign_id"], "left")

            # Prepare joins
            attribution_df = attribution_aggr.select([F.col(c).alias(f"{c}_attr") for c in attribution_aggr.columns])
            join_conditions = self._build_join_conditions(unified_campaign_df, filtered_df_with_factor)

            # Join attribution data
            filtered_df_with_factor = filtered_df_with_factor.join(attribution_df, join_conditions['attr_join'], "left")

            # Join user journey metrics if needed
            if self.dtp() and user_journey_metrics:
                user_journey_df = user_journey_metrics.select([F.col(c).alias(f"{c}_uj") for c in user_journey_metrics.columns])
                join_cond_uj = (
                    (F.lower(filtered_df_with_factor["campaign_id"]) == F.lower(user_journey_df["campaign_id_uj"])) &
                    (F.lower(filtered_df_with_factor["marketing_type"]) == F.lower(user_journey_df["marketing_type_uj"])) &
                    (F.lower(filtered_df_with_factor["channel_name"]) == F.lower(user_journey_df["channel_name_uj"])) &
                    (F.lower(filtered_df_with_factor["subchannel_name"]) == F.lower(user_journey_df["subchannel_name_uj"]))
                )
                filtered_df_with_factor = filtered_df_with_factor.join(user_journey_df, join_cond_uj, "left")

            # Apply recalibration
            filtered_df_with_factor = self._apply_recalibration(filtered_df_with_factor)

            # Drop unnecessary columns
            columns_to_drop = ["subchannel_name_attr", "channel_name_attr", "marketing_type_attr", "campaign_id_attr"]
            if self.dtp():
                columns_to_drop.extend(["subchannel_name_uj", "channel_name_uj", "marketing_type_uj", "campaign_id_uj"])

            for col_name in columns_to_drop:
                if col_name in filtered_df_with_factor.columns:
                    filtered_df_with_factor = filtered_df_with_factor.drop(col_name)

            # Join unified campaign
            enriched_df = filtered_df_with_factor.join(unified_campaign_df, join_conditions['uni_join'], "left")

            # Select final columns
            enriched_df = enriched_df.select(*self._get_select_columns())

            # Join reach engagement & campaign type
            join_cond_reach = (
                (F.trim(F.lower(reach_engagement_df["campaign_id_reach"])) == F.trim(F.lower(enriched_df["campaign_id"]))) &
                (F.trim(F.lower(reach_engagement_df["marketing_type_reach"])) == F.trim(F.lower(enriched_df["marketing_type"]))) &
                (F.trim(F.lower(reach_engagement_df["channel_name_reach"])) == F.trim(F.lower(enriched_df["channel_name"]))) &
                (F.trim(F.lower(reach_engagement_df["subchannel_name_reach"])) == F.trim(F.lower(enriched_df["subchannel_name"])))
            )

            enriched_df_new = (
                enriched_df.join(F.broadcast(reach_engagement_df), join_cond_reach, "left")
                .drop("campaign_id_reach", "subchannel_name_reach", "channel_name_reach", "marketing_type_reach")
                .join(campaign_type_df, on=["campaign_id"], how="left")
                .withColumnRenamed("media_spend_amt_reach", "media_spend_amt")
            )

            # Nectar processing
            enriched_df_new = self.process_nectar_data(enriched_df_new)

            # ROAS & IROAS calculations
            enriched_df_new = enriched_df_new.withColumns(self._get_roas_columns(win))

            # Base sales & Uplift
            uplift_columns = {
                "base_sales_amt_exposed": F.col("attributed_recalibrated_sales_amt") - F.col("incremental_sales_amt_exposed"),
                "uplift_exposed_sales_amt": F.when(F.sum("attributed_recalibrated_sales_amt").over(win) > 0,
                                                   F.sum("incremental_sales_amt_exposed").over(win) /
                                                   F.sum("attributed_recalibrated_sales_amt").over(win)).otherwise(0.0),
                "uplift_exposed_units_qty": F.when(F.sum("attributed_recalibrated_units_qty").over(win) > 0,
                                                   F.sum("incremental_units_qty_exposed").over(win) /
                                                   F.sum("attributed_recalibrated_units_qty").over(win)).otherwise(0.0),
                "uplift_exposed_nectar_sales_amt": F.when(F.col("attributed_recalibrated_sales_amt") > 0,
                                                          F.col("total_incremental_nectar_sales_amt") /
                                                          F.col("attributed_recalibrated_sales_amt")).otherwise(0.0),
                "uplift_exposed_nectar_units_qty": F.when(F.col("attributed_recalibrated_units_qty") > 0,
                                                          F.col("total_incremental_nectar_units_qty") /
                                                          F.col("attributed_recalibrated_units_qty")).otherwise(0.0)
            }

            enriched_df_new = enriched_df_new.withColumns(uplift_columns)

            # Conversion rate
            enriched_df_new = enriched_df_new.withColumn(
                "conversion_rate",
                F.when(F.lit(total_count) > 0, (F.lit(conv_count) / F.lit(total_count)) * 100).otherwise(0.0)
            )

            results_list.append(enriched_df_new)

        return results_list

    ######################################################

    def processor(
            self,
            spark: SparkSession,
            measurement_campaign_execution_df: DataFrame,
            unified_campaign_df: DataFrame,
            reach_engagement_df: DataFrame,
            attribution_model_result_offer_df: DataFrame,
            attribution_model_result_brand_df: DataFrame,
            attribution_model_result_aisle_df: DataFrame,
            attribution_pre_requisite_offer_df: DataFrame,
            attribution_pre_requisite_brand_df: DataFrame,
            attribution_pre_requisite_aisle_df: DataFrame,
            baseline_offer_df: DataFrame,
            baseline_brand_df: DataFrame,
            baseline_aisle_df: DataFrame,
            correlation_id: str,
            untargeted_channels_list: list[str],
            include_aisle_skus: bool
    ):

        in_progress_data_df = (measurement_campaign_execution_df
                               .select("booking_id", "campaign_duration").distinct())

        if in_progress_data_df.rdd.isEmpty():
            raise ValueError("Error: no data found to execute the model!")

        # Offer-level data
        target_baseline_offer = self.get_latest_data(baseline_offer_df, in_progress_data_df)
        target_pre_req_offer = self.get_latest_data(attribution_pre_requisite_offer_df, in_progress_data_df)
        target_model_offer = self.get_latest_data(attribution_model_result_offer_df, in_progress_data_df)

        # Brand-level data
        target_baseline_brand = self.get_latest_data(baseline_brand_df, in_progress_data_df)
        target_pre_req_brand = self.get_latest_data(attribution_pre_requisite_brand_df, in_progress_data_df)
        target_model_brand = self.get_latest_data(attribution_model_result_brand_df, in_progress_data_df)

        if include_aisle_skus:
            # Aisle-level data
            target_baseline_aisle = self.get_latest_data(baseline_aisle_df, in_progress_data_df)
            target_pre_req_aisle = self.get_latest_data(attribution_pre_requisite_aisle_df, in_progress_data_df)
            target_model_aisle = self.get_latest_data(attribution_model_result_aisle_df, in_progress_data_df)

        target_reach_engagement = self.get_latest_data(reach_engagement_df, in_progress_data_df)
        target_unified_campaign = self.get_latest_data(unified_campaign_df, in_progress_data_df)

        # === Process booking IDs for all levels in one pass ===
        combined_results = []

        # New code to filter out None dataframes

        if include_aisle_skus:
            datasets_to_process = [
                (target_baseline_offer, target_model_offer, target_pre_req_offer),
                (target_baseline_brand, target_model_brand, target_pre_req_brand),
                (target_baseline_aisle, target_model_aisle, target_pre_req_aisle),
            ]
        else:
            datasets_to_process = [
                (target_baseline_offer, target_model_offer, target_pre_req_offer),
                (target_baseline_brand, target_model_brand, target_pre_req_brand),
            ]

        for baseline_df, model_df, pre_req_df in datasets_to_process:
            if baseline_df and model_df and pre_req_df:
                processed = self.process_booking_ids(
                    baseline_df,
                    target_unified_campaign,
                    target_baseline_offer,  # baseline_offer_df always offer-level recalibration
                    target_reach_engagement,
                    model_df,
                    pre_req_df,
                    UNTARGETED_CHANNELS
                )
                combined_results.extend(processed)

        # === Union all results ===
        if combined_results:
            measurement_campaign_reporting = reduce(DataFrame.unionByName, combined_results)
        else:
            measurement_campaign_reporting = spark.createDataFrame([], MeasurementCampaignReporting().measures_schema)

        column_seq = measurement_campaign_reporting.columns

        # === Add tracking columns ===
        measurement_campaign_reporting = (
            measurement_campaign_reporting
            .select(*column_seq)
            .withColumn("job_run_id", F.lit(correlation_id))
            .withColumn("load_ts", F.current_timestamp()))

        if not self.dtp:
            measurement_campaign_reporting = measurement_campaign_reporting.withColumn("job_bag_number", F.lit("NA"))

        return measurement_campaign_reporting

    ######################################################

    def prepare_measurement_campaign_report(
            self,
            spark: SparkSession,
            measurement_campaign_execution_path: str,
            unified_campaigns_path: str,
            reach_engagement_path: str,
            attribution_model_result_offer_path: str,
            attribution_model_result_brand_path: str,
            attribution_model_result_aisle_path: str,
            attribution_pre_requisite_offer_path: str,
            attribution_pre_requisite_brand_path: str,
            attribution_pre_requisite_aisle_path: str,
            baseline_offer_path: str,
            baseline_brand_path: str,
            baseline_aisle_path: str,
            output_path: str,
            correlation_id: str,
            run_date: str,
            include_aisle_skus: bool,
    ) -> DataFrame:

        measurement_campaign_execution_df = (
            spark.read.parquet(measurement_campaign_execution_path).select(
                "campaign_id",
                "booking_id",
                "marketing_type",
                "campaign_duration"
            )
        )

        reach_engagement_df = (
            spark.read.parquet(reach_engagement_path).select(
                "campaign_id",
                "channel_name",
                "subchannel_name",
                "media_spend_amt",
                "marketing_type",
                "booking_id",
                "load_ts"
            )
        )

        attribution_model_result_offer_df = (
            spark.read.parquet(attribution_model_result_offer_path).select(
                "channel_name",
                "campaign_id",
                "subchannel_name",
                "marketing_type",
                "normalized_weights",
                "campaign_duration",
                "booking_id",
                "load_ts",
                "userjourney_id",
                "isconversion"
            )
        )

        attribution_model_result_brand_df = (
            spark.read.parquet(attribution_model_result_brand_path).select(
                "channel_name",
                "campaign_id",
                "subchannel_name",
                "marketing_type",
                "normalized_weights",
                "campaign_duration",
                "booking_id",
                "load_ts",
                "userjourney_id",
                "isconversion"
            )
        )

        if include_aisle_skus:
            attribution_model_result_aisle_df = (
                spark.read.parquet(attribution_model_result_aisle_path).select(
                    "channel_name",
                    "campaign_id",
                    "subchannel_name",
                    "marketing_type",
                    "normalized_weights",
                    "campaign_duration",
                    "booking_id",
                    "load_ts",
                )
            )
        else:
            attribution_model_result_aisle_df = spark.createDataFrame([], schema=AttributionModel.reporting_aisle_schema)

        attribution_pre_requisite_offer_df = (
            spark.read.parquet(attribution_pre_requisite_offer_path).select(
                "userjourney_id",
                "isconversion",
                "booking_id",
                "campaign_duration",
                "campaign_id",
                "channel_name",
                "subchannel_name",
                "marketing_type",
                "load_ts"
            )
        )

        attribution_pre_requisite_brand_df = (
            spark.read.parquet(attribution_pre_requisite_brand_path).select(
                "userjourney_id",
                "isconversion",
                "booking_id",
                "campaign_duration",
                "campaign_id",
                "channel_name",
                "subchannel_name",
                "marketing_type",
                "load_ts"
            )
        )

        if include_aisle_skus:
            attribution_pre_requisite_aisle_df = (
                spark.read.parquet(attribution_pre_requisite_aisle_path).select(
                    "userjourney_id",
                    "isconversion",
                    "booking_id",
                    "campaign_duration",
                    "campaign_id",
                    "channel_name",
                    "subchannel_name",
                    "marketing_type",
                    "load_ts"
                )
            )
        else:
            attribution_pre_requisite_aisle_df = spark.createDataFrame([], schema=AttributionPreRequisiteSchema.attribution_pre_requisite_schema)

        baseline_offer_df = (
            spark.read.parquet(baseline_offer_path).select(
                "booking_id",
                "campaign_id",
                "campaign_duration",
                "journey_type",
                "marketing_type",
                "channel_name",
                "subchannel_name",
                "customer_journey_type",
                "incremental_sales_amt_exposed",
                "attributed_recalibrated_sales_amt",
                "attributed_recalibrated_units_qty",
                "attributed_sales_amt",
                "attributed_units_qty",
                "incremental_units_qty_exposed",
                "nectar_sales_amt",
                "non_nectar_sales_amt",
                "recalibration_factor",
                "load_ts"
            )
        )

        baseline_brand_df = (
            spark.read.parquet(baseline_brand_path).select(
                "booking_id",
                "campaign_id",
                "campaign_duration",
                "journey_type",
                "marketing_type",
                "channel_name",
                "subchannel_name",
                "customer_journey_type",
                "incremental_sales_amt_exposed",
                "attributed_recalibrated_sales_amt",
                "attributed_recalibrated_units_qty",
                "attributed_sales_amt",
                "attributed_units_qty",
                "incremental_units_qty_exposed",
                "nectar_sales_amt",
                "non_nectar_sales_amt",
                "load_ts"
            )
        )

        if include_aisle_skus:
            baseline_aisle_df = (
                spark.read.parquet(baseline_aisle_path).select(
                    "booking_id",
                    "campaign_id",
                    "campaign_duration",
                    "journey_type",
                    "marketing_type",
                    "channel_name",
                    "subchannel_name",
                    "customer_journey_type",
                    "incremental_sales_amt_exposed",
                    "attributed_recalibrated_sales_amt",
                    "attributed_recalibrated_units_qty",
                    "attributed_sales_amt",
                    "attributed_units_qty",
                    "incremental_units_qty_exposed",
                    "nectar_sales_amt",
                    "non_nectar_sales_amt",
                    "load_ts"
                )
            )
        else:
            baseline_aisle_df = spark.createDataFrame([], schema=BaselineAttributionIntegrationSkuLevel.reporting_aisle_schema)

        unified_campaign_df = (
            spark.read.parquet(unified_campaigns_path).select(
                "campaign_id",
                "channel_name",
                "subchannel_name",
                "super_category_name",
                "sub_category_name",
                "campaign_name",
                "marketing_type",
                "job_bag_number",
                "booking_id",
                "load_ts"
            )
        )

        measurement_campaign_reporting_df = (
            self.processor(
                spark,
                measurement_campaign_execution_df,
                unified_campaign_df,
                reach_engagement_df,
                attribution_model_result_offer_df,
                attribution_model_result_brand_df,
                attribution_model_result_aisle_df,
                attribution_pre_requisite_offer_df,
                attribution_pre_requisite_brand_df,
                attribution_pre_requisite_aisle_df,
                baseline_offer_df,
                baseline_brand_df,
                baseline_aisle_df,
                correlation_id,
                UNTARGETED_CHANNELS,
                include_aisle_skus,
            )
        )

        print(f'\n\nMeasurement Campaign Reporting Count: {measurement_campaign_reporting_df.count()}')

        output_df = (
            measurement_campaign_reporting_df
            .withColumnRenamed("job_run_id", "correlation_id")
            .select(
                'correlation_id',
                'campaign_id',
                'booking_id',
                'campaign_duration',
                'journey_type',
                'marketing_type',
                'channel_name',
                'subchannel_name',
                'sub_category_name',
                'attributed_conversions',
                'incremental_sales_amt_exposed',
                'super_category_name',
                'campaign_name',
                'attributed_recalibrated_sales_amt',
                'attributed_recalibrated_units_qty',
                'incremental_units_qty_exposed',
                'attributed_units_qty',
                'attributed_sales_amt',
                'conversions_recalibrated',
                'recalibration_factor',
                'job_bag_number',
                'nectar_sales_amt',
                'non_nectar_sales_amt',
                'media_spend_amt',
                'campaign_type',
                'nectar_weights',
                'non_nectar_weights',
                'new_nectar_sales_amt',
                'new_non_nectar_sales_amt',
                'new_nectar_units_qty',
                'new_non_nectar_units_qty',
                'new_nectar_weight',
                'new_nectar_qty_weight',
                'incremental_nectar_sales_amt',
                'new_non_nectar_weights',
                'incremental_nectar_units_qty',
                'new_non_nectar_qty_weights',
                'incremental_non_nectar_sales_amt',
                'total_incremental_nectar_sales_amt',
                'incremental_non_nectar_units_qty',
                'total_incremental_nectar_units_qty',
                'base_sales_amt_nectar_exposed',
                'roas_exposed',
                'iroas_exposed',
                'iroas_exposed_nectar',
                'base_sales_amt_exposed',
                'uplift_exposed_sales_amt',
                'uplift_exposed_units_qty',
                'uplift_exposed_nectar_sales_amt',
                'uplift_exposed_nectar_units_qty',
                'num_user_journeys',
                'num_conversions',
                'attributed_recalibrated_sales_amt_per_uj',
                'attributed_recalibrated_sales_amt_per_conversion',
                'conversion_per_uj',
                'conversion_rate',
                'load_ts'
            )
        )

        # Use custom method to write to s3 destination output
        spark_s3_overwrite(output_path, output_df)

        return measurement_campaign_execution_df

    ###############################################

    def entrypoint(self,
                   spark: SparkSession,
                   command_line_args: Optional[List[str]] = None) -> None:
        """
        Entry point for the New Launch Estimation baseline pipeline.

        Parses required command-line arguments for input and output S3 paths, along with
        metadata parameters, then invokes the main processing function to run the pipeline.

        """
        parser = ThrowingArgumentParser(description="New Launch Estimation for baseline pipeline.")
        parser.add_argument(
            "--measurement-campaign-execution-path",
            type=str,
            required=True,
            help="S3 path for measurement campaign execution."
        )
        parser.add_argument(
            "--unified-campaigns-path",
            type=str,
            required=True,
            help="The output S3 path for the unified campaigns."
        )
        parser.add_argument(
            "--reach-engagement-path",
            type=str,
            required=True,
            help="The output S3 path for the reach engagement data."
        )
        parser.add_argument(
            "--attribution-model-result-offer-path",
            type=str,
            required=True,
            help="S3 path for attribution model offer."
        )
        parser.add_argument(
            "--attribution-model-result-brand-path",
            type=str,
            required=True,
            help="S3 path for attribution model brand."
        )
        parser.add_argument(
            "--attribution-model-result-aisle-path",
            type=str,
            required=True,
            help="S3 path for attribution model aisle."
        )
        parser.add_argument(
            "--attribution-pre-requisite-offer-path",
            type=str,
            required=True,
            help="The output S3 path for the attribution pre requisite offer."
        )
        parser.add_argument(
            "--attribution-pre-requisite-brand-path",
            type=str,
            required=True,
            help="S3 path for attribution pre requisite brand."
        )

        parser.add_argument(
            "--attribution-pre-requisite-aisle-path",
            type=str,
            required=True,
            help="S3 path for attribution pre requisite aisle."
        )
        parser.add_argument(
            "--baseline-offer-path",
            type=str,
            required=True,
            help="S3 path for baseline offer."
        )
        parser.add_argument(
            "--baseline-brand-path",
            type=str,
            required=True,
            help="S3 path for baseline brand."
        )
        parser.add_argument(
            "--baseline-aisle-path",
            type=str,
            required=True,
            help="S3 path for baseline aisle."
        )
        parser.add_argument(
            "--output-path",
            type=str,
            required=True,
            help="The path in S3 to output the new launch estimation."
        )
        parser.add_argument(
            "--correlation-id",
            type=str,
            required=True,
            help="unique correlation id."
        )
        parser.add_argument(
            "--run-date",
            type=str,
            required=True,
            help="Pipeline run date in YYYY-MM-DD format."
        )
        parser.add_argument(
            "--include-aisle-skus",
            type=str,
            required=True,
            help="Flag to include aisle SKUs."
        )

        known_args, _ = parser.parse_known_args(command_line_args)

        _ = self.prepare_measurement_campaign_report(
            spark=spark,
            measurement_campaign_execution_path=known_args.measurement_campaign_execution_path,
            reach_engagement_path=known_args.reach_engagement_path,
            unified_campaigns_path=known_args.unified_campaigns_path,
            attribution_model_result_offer_path=known_args.attribution_model_result_offer_path,
            attribution_model_result_brand_path=known_args.attribution_model_result_brand_path,
            attribution_model_result_aisle_path=known_args.attribution_model_result_aisle_path,
            attribution_pre_requisite_offer_path=known_args.attribution_pre_requisite_offer_path,
            attribution_pre_requisite_brand_path=known_args.attribution_pre_requisite_brand_path,
            attribution_pre_requisite_aisle_path=known_args.attribution_pre_requisite_aisle_path,
            baseline_offer_path=known_args.baseline_offer_path,
            baseline_brand_path=known_args.baseline_brand_path,
            baseline_aisle_path=known_args.baseline_aisle_path,
            output_path=known_args.output_path,
            correlation_id=known_args.correlation_id,
            run_date=known_args.run_date,
            include_aisle_skus=str_to_bool(known_args.include_aisle_skus)
        )


class PollenDataProcessor(BaseDataProcessor):
    """Processor for Code 1 version (without user journey metrics)"""

    def dtp(self) -> bool:
        return False


class DTPDataProcessor(BaseDataProcessor):
    """Processor for Code 2 version (with user journey metrics)"""

    def dtp(self) -> bool:
        return True


# Factory function to create the appropriate processor
def create_data_processor(version: str = "code1", **kwargs) -> BaseDataProcessor:
    """Factory function to create the appropriate data processor"""
    if version.lower() == "code2":
        return DTPDataProcessor(**kwargs)
    else:
        return PollenDataProcessor(**kwargs)
