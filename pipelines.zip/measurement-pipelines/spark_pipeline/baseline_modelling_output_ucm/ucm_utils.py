import pandas as pd
from pyspark.sql import functions as F, DataFrame
from typing import Dict, Any, Tuple, List

import itertools

from spark_pipeline.baseline_modelling_output_ucm.ucm_feature_engineering import seasonality_index_creator
from spark_pipeline.common.variables import BaselineModellingOutputConfig


def marketing_contribution_filter(
    ucm_fin_summary,
    ucm_base_data_fixed,
    ucm_base_long,
    model_metrics,
    best_iteration_df,
    params: Dict[str, Dict[str, Any]] = None
):
    """
    Filters all intermediate outputs based on iterations that contain negative marketing coefficients
    Args:
        ucm_fin_summary (DataFrame): Model variable outputs.
        ucm_base_data_fixed (DataFrame): All iterations and feature contributions over time.
        ucm_base_long (DataFrame): Long format of all iterations and feature contributions over time.
        model_metrics (DataFrame): Summary of different model metrics.
        best_iteration_df (DataFrame): Filtered best iteration of the UCM model.
        params (Dict[str, Dict[str, Any]]): Parameters for the UCM model.

    Returns:
        Tuple[DataFrame, DataFrame, DataFrame, DataFrame, DataFrame]: Filtered UCM outputs with negative marketing contribution iterations removed.
    """

    if params is None:
        params = get_params()

    negative_marketing_variable_patterns = [
        pattern.lower()
        for pattern in params["DEFAULT"].get("negative_marketing_variable_patterns", [])
    ]

    if not negative_marketing_variable_patterns:
        print('No negative marketing variable patterns configured, returning original datasets')
        return ucm_fin_summary, ucm_base_data_fixed, ucm_base_long, model_metrics, best_iteration_df

    variable_apl_lower = F.lower(F.col("variable_apl"))
    marketing_pattern_filter = F.lit(False)
    for pattern in negative_marketing_variable_patterns:
        marketing_pattern_filter = marketing_pattern_filter | variable_apl_lower.contains(pattern)

    # Collect the iteration and cluster IDs which have any marketing contributions as negative

    negative_marketing_cont = (
        ucm_fin_summary
        .filter(
            (
                marketing_pattern_filter &
                (F.col("estimate") < 0))
        )
        .select(
            F.col('Iteration_Number'),
            F.col('modelling_cluster')
        )
        .distinct()
    )

    total_iterations = ucm_fin_summary.select(
        F.col('Iteration_Number'),
        F.col('modelling_cluster')
    ).distinct()

    # Store the count of total iterations for reference before filtering
    total_iterations_count = total_iterations.count()

    # Store the count of negative marketing contribution iterations
    negative_marketing_cont_count = negative_marketing_cont.count()

    print(f'Total Iterations available: {total_iterations_count}')
    print(f'Negative Marketing Contributions Count: {negative_marketing_cont_count}')

    if negative_marketing_cont_count == total_iterations_count:
        print('All iterations have negative marketing contributions, cannot filter on this variable, returning original datasets')
        return ucm_fin_summary, ucm_base_data_fixed, ucm_base_long, model_metrics, best_iteration_df

    # Broadcast the negative_marketing_cont DataFrame for efficient joins, as it is expected to be small after filtering
    negative_marketing_cont = F.broadcast(negative_marketing_cont)

    # Update UCM datasets with negative marketing coefficients filtered out
    # Fin Summary
    ucm_fin_summary_filtered = (
        ucm_fin_summary
        .join(
            negative_marketing_cont,
            on=["modelling_cluster", "Iteration_Number"],
            how="leftanti"
        )
    )

    # Base Data
    ucm_base_data_fixed_filtered = (
        ucm_base_data_fixed
        .join(
            negative_marketing_cont,
            on=["modelling_cluster", "Iteration_Number"],
            how="leftanti"
        )
    )

    # Long Format UCM
    ucm_base_long_filtered = (
        ucm_base_long
        .join(
            negative_marketing_cont,
            on=["modelling_cluster", "Iteration_Number"],
            how="leftanti"
        )
    )

    # Model Metrics
    model_metrics_filtered = (
        model_metrics
        .join(
            negative_marketing_cont,
            on=["modelling_cluster", "Iteration_Number"],
            how="leftanti"
        )
    )

    # Best Iteration
    best_iteration_df_filtered = (
        best_iteration_df
        .join(
            negative_marketing_cont,
            on=["modelling_cluster", "Iteration_Number"],
            how="leftanti"
        )
    )

    return ucm_fin_summary_filtered, ucm_base_data_fixed_filtered, ucm_base_long_filtered, model_metrics_filtered, best_iteration_df_filtered


def get_params(config: BaselineModellingOutputConfig = None) -> Dict[str, Dict[str, Any]]:
    """
    Function which collates the parameters defined in the config to be used in the code

    Objective:
        Function used to get all the parameters required from config. Parameters relevant to ucm have the suffix ucm.
        This adapts the BaselineModellingOutputConfig to the dictionary format expected by the code.

    Args:
        config (BaselineModellingOutputConfig, optional): Config object with parameters. If None, creates a new one.

    Returns:
        params (dict): parameter dictionary in required format for the main function
    """
    if config is None:
        config = BaselineModellingOutputConfig()

    params = {}
    params["DEFAULT"] = {}
    params["UCM"] = {}
    params["FP"] = {}
    params["job_run"] = {}

    # DEFAULT parameters
    params["DEFAULT"]["dependent"] = config.dependent
    params["DEFAULT"]["var_len"] = config.var_len
    params["DEFAULT"]["marketing_type_list"] = config.marketing_type_list
    params["DEFAULT"]["negative_metric_names"] = config.negative_metric_name
    params["DEFAULT"]["negative_marketing_variable_patterns"] = config.negative_marketing_variable_patterns
    params["DEFAULT"]["dummy_vars_list"] = config.dummy_variable_list
    params["DEFAULT"]["proportion_of_ext_vars"] = config.proportion_of_ext_vars
    params["DEFAULT"]["baseline_lower_bound"] = config.baseline_lower_bound
    params["DEFAULT"]["count_latest_weeks_no_sales"] = config.count_latest_weeks_no_sales
    params["DEFAULT"]["seasonality_bucket_channel_list"] = config.seasonality_bucket_channel_list
    params["DEFAULT"]["seasonality_bucket_variable_list"] = config.seasonality_bucket_variable_list
    params["DEFAULT"]["wsmape_wt"] = config.wsmape_wt
    params["DEFAULT"]["rsq_wt"] = config.rsq_wt
    params["DEFAULT"]["last_run_wt"] = config.last_run_wt
    params["DEFAULT"]["Inc_Perc_wt"] = config.Inc_Perc_wt
    params["DEFAULT"]["so_wsmape_wt"] = config.so_wsmape_wt
    params["DEFAULT"]["so_rsq_wt"] = config.so_rsq_wt
    params["DEFAULT"]["so_last_run_wt"] = config.so_last_run_wt
    params["DEFAULT"]["so_base_contri_wt"] = config.so_base_contri_wt
    params["DEFAULT"]["so_seasonality_wt"] = config.so_seasonality_wt
    params["DEFAULT"]["highest_permissible_wsmape"] = config.highest_permissible_wsmape
    params["DEFAULT"]["least_permissible_rsq"] = config.least_permissible_rsq
    params["DEFAULT"]["rsq_lower_bound"] = config.rsq_lower_bound
    params["DEFAULT"]["wsmape_upper_bound"] = config.wsmape_upper_bound

    # UCM parameters
    params["UCM"]["level_variance"] = config.ucm_config.level_variance
    params["UCM"]["apl_ad"] = config.ucm_config.apl_ad
    params["UCM"]["apl_pw"] = config.ucm_config.apl_pw
    params["UCM"]["apl_lg"] = config.ucm_config.apl_lg
    params["UCM"]["seasonal"] = config.ucm_config.seasonal
    params["UCM"]["cycle"] = config.ucm_config.cycle
    params["UCM"]["cycle_period_bounds"] = config.ucm_config.cycle_period_bounds

    # FP parameters
    params["FP"]["external_marketing_type_names"] = config.external_marketing_type_names
    params["FP"]["external_metric"] = config.external_metric

    # Job run parameters
    params["job_run"]["job_run_id"] = 'Test'

    return params


def get_modelling_cluster(cluster_df: DataFrame, filter_df: DataFrame, return_as_list: bool = False) -> DataFrame:
    """
    This function filters the clusters based on the campaign selection output, to create a list of modelling clusters the UCM will run on

    Args:
        cluster_df (DataFrame): Latest clustering results
        filter_df (DataFrame): Campaign selection DataFrame to filter the clusters with
        return_as_list (bool): If True, returns a list of distinct modelling_cluster (Brand, Super Cat, Cluster) values as wel as the DataFrame.

    Returns:
        DataFrame: Contains distinct MODELLING_CLUSTER_LIST values to run UCM on.
    """
    # Generate join key in both DataFrames
    key_col = F.concat_ws("", F.col("unique_brand_name"), F.col("super_category_name"))
    cluster_df = cluster_df.withColumn("join_key", key_col)
    filter_keys = filter_df.select(key_col.alias("join_key")).distinct()

    # Semi-join to filter clusters
    filtered_df = cluster_df.join(filter_keys, on="join_key", how="semi")

    # Create the modelling_cluster_list column
    result_df = (
        filtered_df
        .withColumn(
            "modelling_cluster_list",
            F.concat_ws("~", "unique_brand_name", "super_category_name", "cluster_num")
        )
        .distinct()
    )

    if return_as_list:
        modelling_cluster_list = [row.modelling_cluster_list for row in result_df.select("modelling_cluster_list").collect()]

        return result_df.select("modelling_cluster_list"), modelling_cluster_list
    else:
        return result_df.select("modelling_cluster_list"), []


def primary_metric_update(primary_metric_df: DataFrame, ads_df: DataFrame) -> Tuple[DataFrame, DataFrame]:
    """
    Adds any new metric entries from the ADS dataset that are not already in the primary metric table.

    By default, new entries are appended with 'N' for both PRIMARY_METRIC_CD and INVESTMENT_METRIC_CD,
    meaning they will not be tested in the model until manually updated.

    The DS team currently manually review these and decide which one to set as 'Y' based on importance.

    Purpose:
    - The `primary_metric_df` is used by both Feature Prioritization and UCM modules.
    - It determines which metrics (e.g., impressions, clicks) should be included for modeling (PRIMARY_METRIC_CD = 'Y').
    - It also indicates which metrics represent investment (spend) (INVESTMENT_METRIC_CD = 'Y').
    - This function ensures the table stays updated with any new metrics added to ADS.

    Args:
        primary_metric_df (DataFrame): Table defining whether a metric is modeled and/or investment-related.
        ads_df (DataFrame): Analytical dataset containing the latest available marketing variables.

    Returns:
        updated_df (DataFrame): Updated primary metric table with newly added rows appended.
        new_rows (DataFrame): Only the rows newly added from ads_df.
    """
    common_cols = ['marketing_type_name', 'marketing_channel_name', 'marketing_sub_channel_name', 'metric_name']

    # Get distinct combinations from ads_df
    latest_metrics_df = ads_df.select(common_cols).dropDuplicates()

    # Anti-join to find new metrics not yet in primary_metric_df
    new_rows = latest_metrics_df.join(primary_metric_df, on=common_cols, how='left_anti')

    # Add default columns for new metrics
    new_rows = (
        new_rows
        .withColumn("primary_metric_cd", F.lit("N"))
        .withColumn("investment_metric_cd", F.lit("N"))
    )

    # ToDo: Add logging for new rows for visibility

    # Append new rows to existing primary_metric_df
    updated_df = primary_metric_df.unionByName(new_rows, allowMissingColumns=True)

    return updated_df, new_rows


def ads_preprocessing(
        master_df: DataFrame,
        primary_metric_df: DataFrame,
        modelling_cluster_df: DataFrame,
        params: Dict[str, Dict[str, Any]]
) -> Tuple[DataFrame, DataFrame]:

    # ToDo: This is from the original code but we can probably remove all this renaming logic
    rename_master = {
        "WEEK_START_DT": "WEEK_START_DATE",
        "UNIQUE_BRAND_NAME": "UNIQUE_BRAND",
        "CLUSTER_NUM": "CLUSTER",
        "MARKETING_TYPE_NAME": "MARKETING_TYPE",
        "MARKETING_CHANNEL_NAME": "MARKETING_CHANNEL",
        "MARKETING_SUB_CHANNEL_NAME": "MARKETING_SUB_CHANNEL",
        "METRIC_NAME": "METRIC",
        "METRIC_VALUE": "VALUE",
        "VARIABLE_CD": "VARIABLE",
        "JOB_RUN_ID": "JOB_ID",
    }
    rename_primary = {
        "MARKETING_TYPE_NAME": "MARKETING_TYPE",
        "MARKETING_CHANNEL_NAME": "MARKETING_CHANNEL",
        "MARKETING_SUB_CHANNEL_NAME": "MARKETING_SUB_CHANNEL",
        "METRIC_NAME": "METRIC",
        "PRIMARY_METRIC_CD": "PRIMARY_METRIC",
        "INVESTMENT_METRIC_CD": "INVESTMENT_METRIC"
    }

    start_date = params["DEFAULT"]["model_start_date"]
    end_date = params["DEFAULT"]["model_end_date"]
    dependent = params["DEFAULT"]["dependent"]

    for old, new in rename_master.items():
        master_df = master_df.withColumnRenamed(old, new)

    for old, new in rename_primary.items():
        primary_metric_df = primary_metric_df.withColumnRenamed(old, new)

    # Filter by the modelling period
    master_df = (
        master_df
        .withColumn("week_start_date", F.to_date("week_start_date"))
        .filter(
            (F.col("week_start_date") >= F.lit(start_date)) &
            (F.col("week_start_date") <= F.lit(end_date))
        )
    )

    master_backup = master_df

    # Update variable if it's the dependent sales variable
    master_df = master_df.withColumn(
        "variable",
        F.when(
            (F.col("marketing_type") == "SALES") & (F.col("metric") == "TOTAL_SALES"),
            F.lit(dependent)
        ).otherwise(F.col("variable"))
    )

    join_keys = ["marketing_type", "marketing_channel", "marketing_sub_channel", "metric"]
    master_df = master_df.join(primary_metric_df.drop("load_ts"), on=join_keys, how="left")

    # Add the modelling_cluster key, so we can operate per modelling cluster
    master_df = master_df.withColumn(
        "modelling_cluster",
        F.concat_ws("~", "unique_brand", "super_category_name", "cluster")
    )

    # Filter the data by the selection we want to run the UCM on
    master_df = (
        master_df.join(
            F.broadcast(modelling_cluster_df.select(F.col("modelling_cluster_list").alias("modelling_cluster"))),
            on="modelling_cluster",
            how="semi"
        )
        .unionByName(
            master_df.filter(F.col("unique_brand") == "TOTAL")
        )
    )

    filtered = (
        master_df.join(
            F.broadcast(modelling_cluster_df.select(F.col("modelling_cluster_list").alias("modelling_cluster"))),
            on="modelling_cluster",
            how="semi"
        )
    )

    total_rows = master_df.filter(F.col("unique_brand") == "TOTAL")

    # ToDo Replace the drop duplicates with a better logic if possible
    master_df = (
        filtered
        .unionByName(total_rows)
        .dropDuplicates(["modelling_cluster", "week_start_date", "variable"])
    )

    master_df = master_df.withColumnRenamed("week_start_date", "week_date")

    for col in master_df.columns:
        master_df = master_df.withColumnRenamed(col, col.lower())

    master_sales = master_df.filter(
        (F.col("marketing_channel") == "SALES") & (F.col("metric") == "TOTAL_SALES")
    )

    # Adds in seasonality dummy variables to the input dataset
    seasonal_df = seasonality_index_creator(master_sales)

    seasonal_df = seasonal_df.withColumn(
        "modelling_cluster",
        F.concat_ws("~", "unique_brand", "super_category_name", "cluster")
    )

    final_df = master_df.unionByName(seasonal_df, allowMissingColumns=True)

    return final_df, master_backup


def generate_combination(data: Dict[str, Dict[str, Any]]) -> Tuple[List, List]:
    """
    Function used to create combinations of configurations for multiple Iterations

    Looks at the model inputs and makes a list of all combinations of model inputs to feed into the ucm
    e.g. A = [10, 20] B = [1, 2], then we'll have [10, 1], [10, 2], [20, 1], [20, 2] as combinations

    First return is the variable order

    Objective:
        Multiple parameters are passed in the dbt_project config file for UCM. These parameters contain lists.
        These lists form multiple combinations. Eg. Level Variance of 0.05 along with Cycle = True and Cycle Bounds = [26,104]
        forms a different combination from Level Variance of 0.25 along with Cycle = False. However, there are also parameters that we do not
        iterate over and remain the same for all UCM iterations. The ignore_parameter list contains such parameters which are lists, but we do not iterate over them.
        This function creates multiple configuration copies, where copy contains one specific combination of iterable parameters,
        along with the non-iterable parameters attached to each copy.

    Used In:
        split_config function where the configuration file splitting process is completed.

    Args:
        data (Dict): Contains input configuration parameters

    Returns:
        iter_par (List): Contains parameters on which the model is iterated upon
        res (List): Contains tuples of all possible values that iter_par can take (ie. all the required iterations" are listed)
    """
    # List of parameters in Config which are lists we do not iterate over
    ignore_parameter = ["apl_ad",
                        "apl_pw",
                        "apl_lg",
                        "covid_emrgncy_time",
                        "dummy_var",
                        "promo_var",
                        "marketing_type_list",
                        "negative_metric_names",
                        "negative_variables_list",
                        "festive_periods",
                        "external_factors_list",
                        "dummy_vars_list",
                        "external_marketing_type_names",
                        "seasonality_bucket_channel_list",
                        "seasonality_bucket_variable_list",
                        "external_metric"]
    iter_par = []
    lst = []
    for i in data:
        for j in data[i]:
            if (j not in ignore_parameter) & isinstance(data[i][j], list):
                iter_par.append(f"{i}:{j}")
                lst.append(data[i][j])

    res = list(itertools.product(*lst))
    return iter_par, res


def remove_cycle_periods_bounds(iter_par: List, res: List) -> List:
    """
    Function to remove redundant iterations on Cycle Bounds where Cycle is false

    Objective:
        Edge Case handler for split config. In case Cycle is False, we do not create 2 config copies with [26,104] and [52,104]/
        These cases are dealt with in this function.

    Used In:
        split_config function where the config splitting process is complete

    Args:
        iter_par (List): Contains parameters on which the model is iterated upon
        res (List): Contains tuples of all possible values that iter_par can take (i.e all the required iterations' are listed)

    Returns:
        updated_res_2 (List): Contains tuples of all possible values that iter_par can take (i.e all the required iterations' are listed) with duplicates for Cycle Bound - False cases excluded
    """
    # Creating constant string for reuse in function
    string_cycle = "UCM:cycle"
    string_cycle_bounds = "UCM:cycle_period_bounds"

    index1 = None
    index2 = None

    if string_cycle in iter_par:
        index1 = iter_par.index(string_cycle)
    if string_cycle_bounds in iter_par:
        index2 = iter_par.index(string_cycle_bounds)

    updated_res = []

    for tup in res:
        temp_list = list(tup)  # Convert tuple to list
        if temp_list[index1].lower() == "false":  # Edit the first specified index
            temp_list[index2] = "None"  # Edit the second specified index
        updated_res.append(tuple(temp_list))

    updated_res_2 = []
    [updated_res_2.append(x) for x in updated_res if x not in updated_res_2]

    return updated_res_2


def split_config(config: Dict[str, Dict[str, Any]]) -> Tuple[List, Dict[str, List]]:
    """
    Function to split up config for each iteration to pass separately for each run

    Objective:
        Each iteration of UCM requires different configuration parameters. In the input config file we pass them as lists.
        Here we make multiple copies of the same config, but all the parameters which are lists have only 1 item of the list in each copy.
        So for each iteration 1 copy is passed with different config values.
        Helper function generate_combination iterates over the list parameters (excluding a few iterable parameters).
        Also, parameters which are not lists are not iterated on, they are replicated in each copy.

    Used In:
        main function where the config is first split and iterated upon in subsequent steps

    Args:
        config (Dict): Contains input configuration parameters

    Returns:
        brand_list (List): List of clusters on which model is to be run
        brand_iterations (List): List of config parameters for each cluster used specifically in the model
    """
    # Combinations are generated based on inputs from config. These combinations decide the number of iterations run for each cluster
    iter_par, res = generate_combination(config)  # Iter is the list of variables res is the list of values

    # Removing duplicate combinations
    res = remove_cycle_periods_bounds(iter_par, res)

    # Initializing values
    brand_list = config["DEFAULT"]["modelling_cluster_list"]  # All brands

    config_exp_list = []
    brand_counts = {}
    brand_iterations = {}
    res_iter_num = []

    # Iterate over the original list of tuples
    for comb in res:
        brand = comb[0]  # Extract brand from tuple
        rest_of_values = comb[1:]  # Extract rest of the values
        brand_counts[brand] = brand_counts.get(brand, 0) + 1
        # Append the modified tuple with the iteration number
        res_iter_num.append((brand,) + tuple(rest_of_values) + (brand_counts[brand],))

    # For each iteration, duplicate the config and assign values to each iteration parameter
    for iters in res_iter_num:
        # Prosb don't need this
        config_temp = {}
        config_temp["DEFAULT"] = {}
        config_temp["UCM"] = {}

        test = []

        for i in range(len(iter_par)):
            j, k = iter_par[i].split(":")[0], iter_par[i].split(":")[1]
            config_temp[j][k] = iters[i]
            test.extend([k + ":" + str(iters[i])])

        config_temp["Iteration_Number"] = "Iteration:" + str(iters[-1]) + "-" + ("-").join(test)
        config_exp_list.append(config_temp)

    # Each duplicated config is then assigned to each Cluster as well to create all the iterations
    for br in brand_list:
        for con_dict in config_exp_list:
            if br == con_dict["DEFAULT"]["modelling_cluster_list"]:
                if br not in brand_iterations:
                    brand_iterations[br] = []
                brand_iterations[br].append(con_dict)

    return brand_list, brand_iterations


def check_all_zero_values(master_df: DataFrame, independent_all_df: DataFrame) -> DataFrame:
    """
    Identifies and returns a variable's that have non-zero values in master_df for a given modelling cluster

    Args:
        master_df (DataFrame): Spark DataFrame containing 'modelling_cluster', 'variable', and 'value'.
        independent_all_df (DataFrame): Spark DataFrame with a column 'var' listing independent variables.

    Returns:
        DataFrame: Filtered Spark DataFrame of independent variables with non-zero activity. Columns: ['var']
    """

    # Standardize case
    master_df_cleaned = master_df.withColumn("var_upper", F.upper(F.col("variable")))
    independent_all_cleaned = independent_all_df.withColumn("var_upper", F.upper(F.col("var")))

    # Join on variable (uppercase)
    joined_df = (
        master_df_cleaned
        .join(
            independent_all_cleaned,
            on=['modelling_cluster', 'var_upper'],
            how="inner"
        )
    )

    variable_sums = (
        joined_df
        .groupBy("modelling_cluster", "var_upper")
        .agg(F.sum("value").alias("total_value"))
    )

    # Keep only non-zero variables
    all_zero_df = variable_sums.filter(F.col("total_value") <= 0)

    # Anti-join to exclude zero-activity variables but not remove any variables that are missing entirely
    non_zero_vars_df = independent_all_cleaned.join(
        all_zero_df,
        on=["modelling_cluster", "var_upper"],
        how="left_anti"
    )

    # Return consistent column names
    return non_zero_vars_df.select(
        F.col("modelling_cluster"),
        F.col("var_upper").alias("variable"),
        F.col("rank")
    ).orderBy(F.col("rank").asc())


def remove_brands_with_zero_sales(
        df: DataFrame,
        config: Dict[str, Dict[str, Any]],
        date_col: str = "week_date",
        group_col: str = "modelling_cluster",
        sales_col: str = "value",
) -> DataFrame:
    """
    Remove modelling clusters that had zero sales in the last N weeks.

    This function checks sales values over the most recent N weeks (default set in config),
    identifies clusters where all sales are zero, and removes those clusters from the input DataFrame.
    The result is a filtered Spark DataFrame ready for modelling.

    Args:
        df (DataFrame):
            Input Spark DataFrame containing sales time series at cluster level.
        config :
            Configuration including: config["DEFAULT"]["count_latest_weeks_no_sales"] specifying the number of weeks to check
            and the latest modelling date (end of time window)
        date_col (str, optional):
            Name of the column containing weekly dates. Defaults to "week_date".
        group_col (str, optional):
            Name of the column containing brand/cluster identifiers. Defaults to "modelling_cluster".
        sales_col (str, optional):
            Name of the column containing sales values. Defaults to "value".

    Returns:
        DataFrame:
            A Spark DataFrame with clusters that had all-zero sales in the last N weeks removed.
    """

    latest_date = config["DEFAULT"]["model_end_date"]
    n_weeks = int(config["DEFAULT"]["count_latest_weeks_no_sales"])

    cutoff_date = latest_date - pd.DateOffset(weeks=n_weeks)

    # Filter to the last N weeks to check for zero sales
    df_last_year = df.filter(F.col(date_col) >= F.lit(cutoff_date))

    brands_with_zero_sales = (
        df_last_year
        .groupBy(group_col)
        .agg(F.max(sales_col).alias("max_sales"))
        .filter(F.col("max_sales") == 0)
        .select(group_col)
    )

    # Remove those clusters from master df
    df_filtered = df.join(brands_with_zero_sales, on=group_col, how="left_anti")

    return df_filtered


def clean_variable_apl(df: DataFrame, variable_col: str):
    """
    Removes APL combinations from variables
    """
    exclude_columns_list = [
        'level', 'seasonal', 'cycle', 'level_base', 'nec_sal_tot_xxx_xxx_xxx_sls'
    ]
    return df.withColumn(
        variable_col,
        F.when(
            ~F.lower(F.col(variable_col)).isin(exclude_columns_list),
            F.regexp_replace(
                F.expr(f"substring({variable_col}, 1, length({variable_col})-7)"),
                r"(?i)^beta\.", ""
            )
        ).otherwise(F.col(variable_col))
    )


def aggregate_seasonality(df: DataFrame, config: Dict[str, Dict[str, Any]]) -> DataFrame:
    """
    Aggregates seasonality-related variables and total_baseline components into a single buckets (variables)

    Objective:
        Function is used to calculate seasonality component and aggregate it with the pure baseline.
        The function also aggregates the external components with the pure baseline, thereby calculating the total_baseline.
        The total_baseline is subtracted from the sales to calculate the marketing incremental.

    Used In:
        baseline_output_buckets_creation function where the total_baseline and nec_tot_tot_tot_tot_tot_sea total_seasonality buckets are created.

    Args:
        df (pd.DataFrame): Contains modelling outputs with contributions of all variables
        config (Dict): Contains configuration parameters from inputs

    Returns:
        result_df (pd.DataFrame): Contains updated modelling outputs with seasonal factors
        contributions combined with Baseline
    """

    # These lists are used to determine which variables should be used to calculate seasonality
    seasonality_bucket_channel_list = config['DEFAULT']['seasonality_bucket_channel_list']
    seasonality_bucket_variable_list = config['DEFAULT']['seasonality_bucket_variable_list']

    # Create the seasonality bucket over each modelling cluster, iteration number, and week date
    seasonality_df = (
        df.filter(  # variables are lower case
            (F.lower(F.col("variable")).isin(seasonality_bucket_variable_list)) |
            (F.col("marketing_channel").isin(seasonality_bucket_channel_list))
        )
        .groupBy("modelling_cluster", "Iteration_Number", "wdate")
        .agg(F.sum("value").alias("value"))
        .withColumn("variable", F.lit("nec_tot_tot_tot_tot_tot_sea"))
    )

    # Separate seasonality components from baseline components e.g. level
    df_clean = (
        df.filter(
            ~(
                (F.lower(F.col("variable")).isin(seasonality_bucket_variable_list)) |
                (F.col("marketing_channel").isin(seasonality_bucket_channel_list))
            )
        )
        .drop("marketing_type", "marketing_channel", "marketing_sub_channel", "metric")
    )

    # Combine baseline + seasonality rows
    combined_df = df_clean.unionByName(seasonality_df)

    # Create total baseline by adding external variables to the pure baseline
    combined_df = ext_var_baseline_combine(combined_df, config)

    return combined_df


def ext_var_baseline_combine(df: DataFrame, config: Dict[str, Dict[str, Any]]) -> DataFrame:
    """
    Function to combine external factors' contribution with the baseline

    Objective:
        The model proves granular outputs with the pure baseline and the external variables' contribution separately.
        The total baseline includes the pure baseline as well as the external factors' contribution because they are not part of the marketing incremental.
        In this function we add the external factors with the pure baseline to calculate total baseline.
        The external factors' are identified using parameters passed from config.

    Args:
        df (pd.DataFrame): Contains modelling outputs with contributions of all variables
        config (Dict): Contains configuration parameters from inputs

    Returns:
        result_df (pd.DataFrame): Contains updated modelling outputs with external contributions combined with Baseline
    """
    # Filtering for external variables - final 'level_base' has seasonality already added to it
    ext_vars = config['DEFAULT']['external_factors_list']
    dummy_vars = config['DEFAULT']['dummy_vars_list']

    # Filter for rows we want to include in baseline calculation, vars from config are in lowercase
    filtered_df = (
        df
        .filter(
            (F.lower(F.col("variable")).isin(ext_vars)) |
            (F.lower(F.col("variable")).isin(dummy_vars)) |
            (F.col("variable") == "level_base") |
            (F.lower(F.col("variable")) == "nec_tot_tot_tot_tot_tot_sea")
        )
    )

    # Filter for rows we want to keep as-is
    non_filtered_df = (
        df.filter(
            ~((F.lower(F.col("variable")).isin(ext_vars)) |
              (F.lower(F.col("variable")).isin(dummy_vars)) |
              (F.col("variable") == "level_base"))
        )
    )

    baseline_df = (
        filtered_df
        .groupBy("modelling_cluster", "Iteration_Number", "wdate")
        .agg(F.sum("value").alias("value"))
        .withColumn("variable", F.lit("level_base"))
        .select("wdate", "modelling_cluster", "Iteration_Number", "variable", "value")
    )

    # Combine the non-filtered rows with the new baseline rows
    result_df = non_filtered_df.unionByName(
        baseline_df,
        allowMissingColumns=True
    )

    return result_df


def modelling_cluster_split(model_metrics_df: DataFrame) -> DataFrame:
    """
    Split the modelling_cluster column into it's separate components

    Args:
        model_metrics_df (DataFrame): Input DataFrame with 'modelling_cluster' column,
                                      formatted as "super_category_brand_clusterNo".

    Returns:
        DataFrame: DataFrame with new columns: 'super_category_name', 'unique_brand', 'cluster_no'.
    """
    split_cols = F.split(model_metrics_df["modelling_cluster"], "~")

    return (
        model_metrics_df
        .withColumn("super_category_name", F.trim(split_cols.getItem(1)))
        .withColumn("unique_brand", F.trim(split_cols.getItem(0)))
        .withColumn("cluster_no", F.trim(split_cols.getItem(2)))
    )


def check_value_in_range_udf(
        seasonality_measure_abs: float,
        seasonality_benchmark: str
) -> bool:
    """
    Check if a numeric value falls within a benchmark range.

    Args:
        seasonality_measure_abs (float): Absolute seasonality measure value.
        seasonality_benchmark (str): Range string in the format "min-max".

    Returns:
        bool: True if within range, False if outside. None if inputs invalid.
    """
    if seasonality_benchmark is None:
        return None

    range_parts = seasonality_benchmark.split("-")
    if len(range_parts) != 2:
        return False

    try:
        min_val = float(range_parts[0])
        max_val = float(range_parts[1])

        if seasonality_measure_abs is None:
            return None

        return min_val <= seasonality_measure_abs <= max_val
    except Exception:
        return False


def filter_by_latest_load_ts(df: DataFrame, ts_col: str = "load_ts") -> DataFrame:
    """
    Filters a DataFrame to retain only rows with the latest timestamp value in the given column.
    If the specified timestamp column does not exist in the DataFrame, the DataFrame is returned unchanged.

    Args:
        df (DataFrame): DataFrame containing a timestamp column used to identify the latest load.

        ts_col (str, optional): Name of the timestamp column to filter on. Defaults to "load_ts".

    Returns:
        DataFrame: DataFrame filtered to only include rows where `ts_col` equals the maximum timestamp value.
            If `ts_col` is not present in the DataFrame, the original DataFrame is returned unchanged.
    """
    if ts_col not in df.columns:
        return df

    max_load_ts = (
        df
        .agg(F.max(ts_col).alias("max_load_ts"))
        .first()["max_load_ts"]
    )

    return df.filter(F.col(ts_col) == F.lit(max_load_ts))


def cap_level_base(df: DataFrame) -> DataFrame:
    """
    Caps baseline sales to actual sales values and prevents negative baseline contributions.

    This function applies business rules to ensure baseline predictions are realistic by:
        - Capping baseline sales (level_base) to not exceed actual sales (nec_sal_tot_xxx_xxx_xxx_sls)
        - Setting baseline to zero when actual sales are zero and baseline is negative
        - Setting baseline to zero when baseline is negative regardless of sales

    Args:
        df (DataFrame): UCM output data containing variable contributions.
            Must include 'level_base' and 'nec_sal_tot_xxx_xxx_xxx_sls' variables.

    Returns:
        DataFrame: Original dataset with capped baseline values replacing the original
            level_base entries where capping rules were applied.

    Business Context:
        Prevents unrealistic baseline predictions that could indicate model instability
        or poor convergence, ensuring baseline contributions remain within sensible bounds.
    """

    # pivot the variables we want to check into columns
    pivoted = (
        df.filter(F.col("variable").isin(["level_base", "nec_sal_tot_xxx_xxx_xxx_sls"]))
          .groupBy("modelling_cluster", "Iteration_Number", "wdate")
          .pivot("variable")
          .agg(F.first("value"))
    )

    # apply capping rules
    capped = (
        pivoted
        .withColumn(
            "level_base_capped",
            F.when((F.col("nec_sal_tot_xxx_xxx_xxx_sls") == 0) & (F.col("level_base") < 0), F.lit(0))
            .when(F.col("level_base") < 0, F.lit(0))
            .otherwise(F.col("level_base"))
        )
    )

    # create rows for capped baseline
    capped_rows = (
        capped.select(
            "modelling_cluster",
            "Iteration_Number",
            F.lit("level_base").alias("variable"),
            F.col("level_base_capped").alias("value"),
            "wdate"
        )
    )

    # remove old level_base rows where they were capped
    df_no_old_levelbase = (
        df.join(
            capped
            .withColumn(
                "was_capped",
                F.col("level_base") != F.col("level_base_capped")
            )
            .select("modelling_cluster", "Iteration_Number", "wdate", "was_capped"),
            on=["modelling_cluster", "Iteration_Number", "wdate"],
            how="left"
        )
        .filter(~((F.col("variable") == "level_base") & (F.col("was_capped"))))
        .drop("was_capped")
    )

    # append capped rows back in
    result_df = df_no_old_levelbase.unionByName(capped_rows)

    return result_df


def parse_iteration_name(
        df: DataFrame,
        iteration_column: str
) -> DataFrame:
    """
    Simplifies UCM iteration names into a standardised readable format for data pipeline output.

    This function parses the iteration column that contain model configuration
    parameters and converts them into a human-readable format for reporting and analysis.

    The original iteration names contain technical parameters like level variance, cycle
    settings, and iteration type that are reformatted for clarity.

    Args:
        df (DataFrame): Input DataFrame containing UCM iteration results with complex
            iteration names in the specified column.
        iteration_column (str): Name of the column containing the iteration identifiers
            to be parsed and simplified.

    Returns:
        DataFrame: Enhanced DataFrame with simplified iteration names in the format:
            "level_var:{value} | cycle:{True/False}[{bounds}]_{iteration_type}"
            where bounds are included only for cycle:True cases.

    Example:
        Input iteration name:
        Iteration:16-modelling_cluster_list:LURPAK|ARLA FOODS~DAIRY~CL2-level_variance:0.50-seasonal:False-cycle:True-cycle_period_bounds:[26, 104]-set_2

        Output iteration name:
        "level_var:0.50 | cycle:True[26, 104]_set_2"

    """

    if not df.take(1):
        return df

    # Extract parts using regex
    level_var = F.regexp_extract(F.col(iteration_column), r'level_variance:(\d+\.\d+)', 1)

    cycle_true = F.regexp_extract(F.col(iteration_column), r'cycle:(True)-cycle_period_bounds:\[(\d+, \d+)\]', 1)
    cycle_bounds = F.regexp_extract(F.col(iteration_column), r'cycle:(True)-cycle_period_bounds:\[(\d+, \d+)\]', 2)

    cycle_false = F.regexp_extract(F.col(iteration_column), r'cycle:(False)-cycle_period_bounds:None', 1)

    iteration_type = F.regexp_extract(F.col(iteration_column), r'(set_\d+(?:_rerun)?)', 1)

    # Build new iteration name string
    new_iteration_name = F.concat_ws(
        " | ",
        F.concat(F.lit("level_var:"), level_var),
        F.when(cycle_true == "True",
               F.concat(F.lit("cycle:True["), cycle_bounds, F.lit("]"))
               ).when(cycle_false == "False", F.lit("cycle:False[]"))
    )

    df = (
        df
        .withColumn("iteration_type", iteration_type)
        .withColumn(iteration_column, new_iteration_name)
        .withColumn(iteration_column, F.concat_ws("_", F.col(iteration_column), F.col("iteration_type")))
        .drop("iteration_type")
    )

    return df


def fix_split_variable_name(df: DataFrame, col_name: str, times: str = "1") -> DataFrame:
    """
    Restores variable names from their encoded 27-character format back to original naming convention.

    This function reverses variable name transformations applied during UCM processing where variable
    names were standardized to a fixed 27-character format. It reconstructs the original variable
    names by parsing the encoded components and inserting appropriate separators.

    Args:
        df (DataFrame): Input DataFrame containing the column to be processed.
        col_name (str): Name of the column containing encoded variable names to restore.
        times (str, optional): Restoration mode. Defaults to "1".
            - "1": Standard restoration with underscore separator
            - "2": Extended restoration including year suffix (_year1 or _year2)

    Returns:
        DataFrame: DataFrame with restored variable names in the specified column.

    Encoding Format:
        The function expects encoded variable names with this structure:
        - Total length: 27 characters
        - Characters 1-23: Base variable name (truncated if necessary)
        - Character 24: Numeric digit (1 or 2 for year variants)
        - Characters 25-27: Variable suffix/extension

    Restoration Logic:
        - times="1": Restores as "{base}_{suffix}"
        - times="2": Restores as "{base}_{suffix}_year{digit}"

    Example:
        Encoded: "example_variable_name3abc"  # 27 chars, digit at pos 24
        times="1": "marketing_channel_tv_abc"
        times="2": "marketing_channel_tv_abc_year1"
    """
    # condition: 27 characters long and 24th char is digit
    condition = (F.length(F.col(col_name)) == 27) & (F.substring(F.col(col_name), 24, 1).rlike(r'[0-9]'))

    if times == "2":
        df = df.withColumn(
            col_name,
            F.when(
                condition,
                F.concat(
                    F.substring(F.col(col_name), 1, 23),
                    F.lit("_"),
                    F.substring(F.col(col_name), 25, 3),
                    F.when(F.substring(F.col(col_name), 24, 1) == "1", F.lit("_year1")).otherwise(F.lit("_year2"))
                )
            ).otherwise(F.col(col_name))
        )
    else:
        df = df.withColumn(
            col_name,
            F.when(
                condition,
                F.concat(
                    F.substring(F.col(col_name), 1, 23),
                    F.lit("_"),
                    F.substring(F.col(col_name), 25, 3)
                )
            ).otherwise(F.col(col_name))
        )

    return df


def fix_control_variable_hierarchy(df: DataFrame) -> DataFrame:
    """
    Updates ADS hierarchy columns for control variables in the DataFrame.

    Marks specific control variables with standardized labels for marketing hierarchy fields.

    Args:
        df (DataFrame): Input DataFrame with VARIABLE_CD and hierarchy columns.

    Returns:
        DataFrame: Updated DataFrame with adjusted hierarchy values for control variables.
    """

    # ToDo: Add these to the variables config file
    constant_std_dev_dummy = "STD DEV DUMMY"
    constant_seasonality_index = "SEASONALITY INDEX"
    constant_week_start_dummy = "WEEK START DUMMY"

    # Start with base
    col = F.col("variable_cd")

    df = (
        df
        # STD DEV DUMMY
        .withColumn(
            "marketing_type_name",
            F.when(col == "nec_xxx_xxx_xxx_xxx_pea_dum", constant_std_dev_dummy)
            .when(col == "nec_xxx_xxx_xxx_xxx_dip_dum", constant_std_dev_dummy)
            .otherwise(F.col("marketing_type_name"))
        )
        .withColumn(
            "marketing_channel_name",
            F.when(col == "nec_xxx_xxx_xxx_xxx_pea_dum", constant_std_dev_dummy)
            .when(col == "nec_xxx_xxx_xxx_xxx_dip_dum", constant_std_dev_dummy)
            .otherwise(F.col("marketing_channel_name"))
        )
        .withColumn(
            "marketing_sub_channel_name",
            F.when(col.isin("nec_xxx_xxx_xxx_xxx_pea_dum", "nec_xxx_xxx_xxx_xxx_dip_dum"), "TOTAL")
            .otherwise(F.col("marketing_sub_channel_name"))
        )
        .withColumn(
            "metric_name",
            F.when(col.isin("nec_xxx_xxx_xxx_xxx_pea_dum", "nec_xxx_xxx_xxx_xxx_dip_dum"), constant_std_dev_dummy)
            .otherwise(F.col("metric_name"))
        )
        # SEASONALITY INDEX
        .withColumn(
            "marketing_type_name",
            F.when(col == "nec_xxx_xxx_xxx_sea_pea_dum", constant_seasonality_index)
             .when(col == "nec_xxx_xxx_xxx_sea_dip_dum", constant_seasonality_index)
             .otherwise(F.col("marketing_type_name"))
        )
        .withColumn(
            "marketing_channel_name",
            F.when(col == "nec_xxx_xxx_xxx_sea_pea_dum", constant_seasonality_index)
            .when(col == "nec_xxx_xxx_xxx_sea_dip_dum", constant_seasonality_index)
            .otherwise(F.col("marketing_channel_name"))
        )
        .withColumn(
            "marketing_sub_channel_name",
            F.when(col.isin("nec_xxx_xxx_xxx_sea_pea_dum", "nec_xxx_xxx_xxx_sea_dip_dum"), "TOTAL")
            .otherwise(F.col("marketing_sub_channel_name"))
        )
        .withColumn(
            "metric_name",
            F.when(col.isin("nec_xxx_xxx_xxx_sea_pea_dum", "nec_xxx_xxx_xxx_sea_dip_dum"), constant_seasonality_index)
            .otherwise(F.col("metric_name"))
        )
    )

    # WEEK START DUMMY
    for i in range(1, 5):
        code = f"nec_xxx_xxx_xxx_xxx_pe{i}_dum"
        df = (
            df.withColumn(
                "marketing_type_name",
                F.when(col == code, constant_week_start_dummy).otherwise(F.col("marketing_type_name"))
            )
            .withColumn(
                "marketing_channel_name",
                F.when(col == code, constant_week_start_dummy).otherwise(F.col("marketing_channel_name"))
            )
            .withColumn(
                "marketing_sub_channel_name",
                F.when(col == code, "TOTAL").otherwise(F.col("marketing_sub_channel_name"))
            )
            .withColumn(
                "metric_name",
                F.when(col == code, constant_week_start_dummy).otherwise(F.col("metric_name"))
            )
        )

    return df


def sales_variable_restore(master_backup: DataFrame, base_data: DataFrame) -> DataFrame:
    """
    Restore dependent variable name to original name from the ADS in PySpark

    Args:
        master_backup (DataFrame): Analytical Dataset used as input to modelling
        base_data (DataFrame): Raw outputs from modelling exercise

    Returns:
        DataFrame: Raw outputs with restored dependent variable name
    """
    if base_data.take(1):

        master_backup = master_backup.withColumn(
            "modelling_cluster",
            F.concat_ws("~", F.col("unique_brand"), F.col("super_category_name"), F.col("cluster"))
        )

        # Filter for sales variables in ADS
        master_backup = master_backup.filter(
            (F.col("marketing_type") == "SALES") & (F.col("metric") == "TOTAL_SALES")
        )

        # Lowercase variable column and select relevant columns
        master_backup = master_backup.withColumn("variable", F.lower(F.col("variable"))) \
                                     .select("modelling_cluster", F.col("variable").alias("variable_original")) \
                                     .dropDuplicates()

        # Left join with base_data to get original variable names
        base_data = base_data.join(
            master_backup,
            on="modelling_cluster",
            how="left"
        )

        # Replace sales placeholder variable with original from ADS
        base_data = base_data.withColumn(
            "variable",
            F.when(F.col("variable") == "nec_sal_tot_xxx_xxx_xxx_sls", F.col("variable_original"))
             .otherwise(F.col("variable"))
        )

        # Drop temporary column
        base_data = base_data.drop("variable_original")

    return base_data


def get_campaign_details(
        master_dataset: DataFrame,
        campaign_selection_df: DataFrame
) -> DataFrame:
    """
    Extracts campaign details such as start and end dates and total media spend for each modelling cluster.

    Args:
        master_dataset (DataFrame): The main input dataset into UCM containing the 'modelling_cluster' that should be run.
        campaign_selection_df (DataFrame): A DataFrame containing campaign details with columns 'unique_brand_name', 'super_category_name', 'min_campaign_start_dt', 'max_campaign_end_dt', and 'total_media_spend'.

    Returns:
        DataFrame: An enriched DataFrame with campaign details on the modelling_cluster level
    """
    campaign_details = (
        master_dataset
        .select("modelling_cluster")
        .distinct()
        .withColumn("super_category_name", F.split(F.col("modelling_cluster"), "~").getItem(1))
        .withColumn("unique_brand_name", F.split(F.col("modelling_cluster"), "~").getItem(0))
        .join(
            campaign_selection_df,
            on=["unique_brand_name", "super_category_name"],
            how="inner"
        )
        .select(
            "modelling_cluster",
            "min_campaign_start_dt",
            "max_campaign_end_dt",
            "total_media_spend"
        )
        # Fill null media spend with 1.0 to avoid division by zero
        .withColumn("total_media_spend", F.coalesce(F.col("total_media_spend"), F.lit(1.0)))
    )

    if campaign_details.isEmpty():
        raise ValueError(
            "The modelling_cluster values do not match between the master data and campaign selection."
        )

    return campaign_details


def filter_by_campaign_bounds(
        source_data: DataFrame,
        campaign_details: DataFrame,
        date_column_name: str = "wdate",
        drop_extra_column: bool = False
) -> DataFrame:
    """
    Filters the source DataFrame to include only rows that fall within the campaign bounds specified in the campaign details DataFrame.
    As well as enriching the source data with campaign details such as start and end date and media spend

    Args:
        source_data (DataFrame): The DataFrame containing the data to be filtered, which must include a date column.
        campaign_details (DataFrame): The DataFrame containing campaign bounds, which must include the min and max campaign_start_date and campaign_end_date columns.
        date_column_name (str): The name of the date column in the source_data DataFrame to be compared against the campaign bounds. Defaults to "wdate".
        drop_extra_column (bool): Whether to drop the campaign bounds columns from the resulting DataFrame after filtering. Defaults to False.

        Returns:
            DataFrame: A filtered DataFrame that includes only rows from the source_data that fall within the campaign bounds specified in campaign_details.

    """

    filtered_df = (
        source_data
        .join(
            F.broadcast(campaign_details),
            on='modelling_cluster',
            how='inner'
        )
        .filter(
            (F.col(date_column_name) >= F.col('min_campaign_start_dt')) &
            (F.col(date_column_name) <= F.col('max_campaign_end_dt'))
        )
    )

    if drop_extra_column:
        filtered_df = filtered_df.drop('min_campaign_start_dt', 'max_campaign_end_dt', 'total_media_spend')

    if filtered_df.isEmpty():
        raise ValueError("No data points fall within the campaign bounds. Or the modelling_cluster values do not match between source_data and campaign_details.")

    return filtered_df
