import numpy as np
import pandas as pd
import pickle
import base64
import re
import scipy.stats as ss

from pyspark.sql import functions as F, DataFrame, SparkSession
from pyspark.sql import types as T
from typing import List, Tuple
from spark_pipeline.baseline_modelling_output_ucm.ucm_output_processing import seasonality_measure_calculation
from spark_pipeline.utils.pipeline_utils import safe_div
from statsmodels.tsa.statespace import structural as sm
from threadpoolctl import threadpool_limits

# Chosen for better convergence stability given the noise in the UCM likelihood surface,
# especially with many variables and APL combinations.

UCM_METHOD = "powell"


def stdize(
        dependent: str,
        lagdata_2: DataFrame
) -> Tuple[DataFrame, DataFrame]:
    """
    Standardize value column per (modelling_cluster, variable) by dividing by mean (of value)
    Calculates mean scaling ratios for variables vs dependent per cluster

    Args:
        dependent (str): Name of the dependent variable.
        lagdata_2 (DataFrame): Enriched DataFrame with all dummy features and apl transformations.

    Returns:
        scaling_df: DataFrame with scaling ratios per (modelling_cluster, variable)
        standardized_df: Standardized DataFrame in long format (value/mean)
    """

    # Compute mean value per (modelling_cluster, variable)
    means_df = (
        lagdata_2
        .groupBy("modelling_cluster", "variable")
        .agg(F.mean("value").alias("mean_value"))
    )

    # Join means back to original data
    joined_df = lagdata_2.join(means_df, on=["modelling_cluster", "variable"], how="left")

    # Standardised values
    standardized_df = (
        joined_df
        .withColumn(
            "value",
            F.col("value") / F.col("mean_value")
        )
        .select("modelling_cluster", "wdate", "variable", "value")
    )

    # Compute scaling ratios per cluster: dependent mean vs each independent variable mean
    dep_means_df = (
        means_df
        .filter(F.col("variable") == dependent)
        .select(
            F.col("modelling_cluster"),
            F.col("mean_value").alias("dep_mean")
        )
    )

    # Join dependent means to all means per cluster
    scaling_df = means_df.join(dep_means_df, on="modelling_cluster", how="left")

    # Calculate ratio dep_mean / indep_mean (avoid division by zero)
    scaling_df = (
        scaling_df
        .filter(F.col("variable") != dependent)
        .withColumn(
            "ratio",
            F.when(F.col("mean_value") != 0, F.col("dep_mean") / F.col("mean_value")).otherwise(None)
        )
        .select(
            "modelling_cluster", "variable", "mean_value", "dep_mean", "ratio"
        )
        .withColumnRenamed("variable", "var")
        .withColumnRenamed("mean_value", "indep_mean")
    )

    return scaling_df, standardized_df


def post_period_stdize(
        dependent: str,
        scalers_df: DataFrame,
        lagdata_2: DataFrame
) -> Tuple[DataFrame, DataFrame]:
    """
    Standardize value column per (modelling_cluster, variable) by dividing by mean (of the same variable from during period)
    Does this separately for the dependent and independent variables.
    Returns the standardised df and the same scaler table used for standardisation.

    Args:
        dependent (str): Name of the dependent variable.
        scalers_df (DataFrame): DataFrame with scaling ratios from the during period.
        lagdata_2 (DataFrame): Enriched DataFrame with all dummy features and apl transformations.

    Returns:
        scalers_df: Returns the input dataset unchanged for consistency with the during-period model S3 output workflow.
        standardized_df: Standardized DataFrame in long format (value/mean).
    """

    # Join dependent means to all means per cluster
    scalers_df_renamed = scalers_df.withColumnRenamed("var", "variable")

    joined_df = lagdata_2.join(
        scalers_df_renamed,
        on=["modelling_cluster", "variable"],
        how="left"
    )

    standardized_df = (
        joined_df
        .filter(F.col("variable") != dependent)
        .withColumn(
            "value",
            safe_div(F.col("value"), F.col("indep_mean"))
        )
        .select("modelling_cluster", "wdate", "variable", "value")
    )

    dep_df = (
        lagdata_2
        .filter(F.col("variable") == dependent)
    )

    dep_scaler_df = (
        scalers_df_renamed.limit(1).drop("variable")
    )

    dep_scaler_df = (
        dep_scaler_df.withColumn("variable", F.lit(dependent))
    )

    dep_df = dep_df.join(
        dep_scaler_df,
        on=["modelling_cluster", "variable"],
        how="left"
    )

    dep_df = (
        dep_df
        .withColumn(
            "value",
            safe_div(F.col("value"), F.col("dep_mean"))
        )
        .select("modelling_cluster", "wdate", "variable", "value")
    )

    standardized_df = standardized_df.unionByName(dep_df)

    return scalers_df, standardized_df


# Function to unpack the during period models
# This function collects a small dataset to the driver for Pandas processing.
# Safe to use because the data is always under 20 rows with only 3 columns,
# so there is no PySpark performance impact.
def during_period_model_reader(
        spark: SparkSession,
        during_models: DataFrame
):

    # convert to pandas
    pdf = during_models.select(
        "modelling_cluster",
        "iteration",
        "ucm_fin_1_serialized"
    ).toPandas()

    # regex precompile
    cycle_re = re.compile(r"cycle:(True|False)\[(.*?)\]", re.IGNORECASE)

    # parse iteration string
    def parse_iteration(it):
        try:
            level_var = float(it.split("level_var:")[1].split(" |")[0])
        except Exception as e:
            raise ValueError(
                f"Exception occurred: {type(e).__name__}: {e}"
            ) from e
            level_var = None

        m = cycle_re.search(it)
        cycle = m.group(1).lower() == "true" if m else False
        cycle_bound = f"[{m.group(2)}]" if (m and m.group(2)) else "[]"

        return pd.Series([level_var, cycle, cycle_bound])

    pdf[["level_variance", "cycle", "cycle_period_bounds"]] = (
        pdf["iteration"].apply(parse_iteration)
    )

    # decode model
    def decode_model(x):
        return pickle.loads(base64.b64decode(x))

    pdf["model"] = pdf["ucm_fin_1_serialized"].apply(decode_model)

    # build summary per row
    def build_summary(row):
        model = row["model"]

        df = pd.DataFrame({
            "estimate": model.params,
            "approx_std_err": model.bse,
            "zvalue": model.zvalues,
            "pvalue_zdist": ss.norm.sf(abs(model.zvalues)),
        }).reset_index().rename(columns={"index": "variable_apl"})

        df["modelling_cluster"] = row["modelling_cluster"]
        df["level_variance"] = row["level_variance"]
        df["cycle"] = str(row["cycle"]).lower()
        df["cycle_period_bounds"] = row["cycle_period_bounds"]
        df["iteration_number"] = row["iteration"]

        df["level_std"] = ",".join(map(str, model.level.smoothed))
        df["slope_std"] = ",".join(map(str, model.trend.smoothed))

        df["cycle_std"] = (
            ",".join(map(str, model.cycle.smoothed))
            if row["cycle"] and hasattr(model, "cycle")
            else None
        )

        df["selected_variables"] = ", ".join(model.model.exog_names)

        return df

    # apply and combine
    result = pd.concat(
        pdf.apply(build_summary, axis=1).tolist(),
        ignore_index=True
    )

    output_schema = T.StructType([
        T.StructField("variable_apl", T.StringType(), True),
        T.StructField("estimate", T.DoubleType(), True),
        T.StructField("approx_std_err", T.DoubleType(), True),
        T.StructField("zvalue", T.DoubleType(), True),
        T.StructField("pvalue_zdist", T.DoubleType(), True),
        T.StructField("modelling_cluster", T.StringType(), True),
        T.StructField("level_variance", T.DoubleType(), True),
        T.StructField("cycle", T.StringType(), True),
        T.StructField("cycle_period_bounds", T.StringType(), True),
        T.StructField("iteration_number", T.StringType(), True),
        T.StructField("level_std", T.StringType(), True),
        T.StructField("slope_std", T.StringType(), True),
        T.StructField("cycle_std", T.StringType(), True),
        T.StructField("selected_variables", T.StringType(), True),
        T.StructField("ucm_fin_1_serialized", T.StringType(), True)  # Included in the schema to preserve consistency with the during-period model output; values will remain null.
    ])

    result["ucm_fin_1_serialized"] = None
    return spark.createDataFrame(result, schema=output_schema)


def serialize_ucm_model(ucm_model):
    """
    Serialize a UCM model object to a base64-encoded string for storage in Spark DataFrame.

    Args:
        ucm_model: The fitted UCM model object (results object from statsmodels)

    Returns:
        str: Base64 encoded pickled model, or None if serialization fails
    """
    try:
        # Pickle the model and encode as base64
        pickled = pickle.dumps(ucm_model)
        serialized = base64.b64encode(pickled).decode('utf-8')
        return serialized
    except Exception as e:
        print(f"Warning: Failed to serialize UCM model: {str(e)}")
        return None


def deserialize_ucm_model(serialized_model_str):
    """
    Deserialize a base64-encoded pickled UCM model object.

    Args:
        serialized_model_str (str): Base64 encoded pickled model

    Returns:
        object: The deserialized UCM model object, or None if deserialization fails
    """
    try:
        pickled = base64.b64decode(serialized_model_str.encode('utf-8'))
        model = pickle.loads(pickled)
        return model
    except Exception as e:
        print(f"Warning: Failed to deserialize UCM model: {str(e)}")
        return None


def ucm_model_runner_factory(
        dependent: str,
        constant_sigma2_level: str,
        constant_sigma2_trend: str,
        marketing_variables_list: List[str],
        negative_factors_list: List[str],
        var_len: str,
        all_combinations,
):
    """
    This function takes the independent variables specified and fits the UCM on each APL transformation in these variables.
    Creating a list of significant variables based on estimate rules and then fitting the final model on these variables.
    Based on this list we then fit the UCM model and extract the outputs for each modelling cluster and iteration.

    Extracting the level, slope, cycle and regressor components from the model to be used in seasonality calculation.

    Objective:
        Function initializes and fits the UCM model. It reads input parameters, iterates through all variables
        to be tested, applies APL transformations to marketing variables, and fits the model.
        External variables are tested without APL. Checks are applied to filter significant variables,
        which are then used to build the final model for this iteration.


    Business Context:
        Function calls the main UCM model and runs an iteration. Each variable is iterated upon and
        the best variables are chosen to build the final model.

     Args:
        dependent (str):  Name of the dependent variable (target) to be modeled.
        constant_sigma2_level (str):  Parameter name in the UCM model corresponding to the variance of the level component.
        constant_sigma2_trend (str):  Parameter name in the UCM model corresponding to the variance of the trend component.
        marketing_variables_list (List[str]):  List of variable names considered as marketing drivers
        negative_factors_list (List[str]):  List of variable names expected to have negative effects (e.g., price).
        var_len (str):  Length of the base variable name, used when parsing variable and APL keys from transformed variable names
        all_combinations (Iterable[Tuple[int, int, int]]):  Iterable of tuples defining possible APL transformation parameter combinations (Adstock, Power, Lag) to be tested for marketing variables.

    Returns:
        Callable[[pd.DataFrame], pd.DataFrame]:
            The function ucm_model_runner that takes a pandas DataFrame representing a single
            modeling cluster + iteration (with dependent and independent variables in long format),
            fits the Unobserved Components Model (UCM), and returns a DataFrame summarizing
            parameter estimates, standard errors, z-values, p-values, smoothed components
            (level, slope, cycle), and the final list of selected variables.
    """

    def ucm_model_runner(pdf: pd.DataFrame) -> pd.DataFrame:
        """
        Runs the UCM model for a single cluster + iteration combination
        Iterates through independent variables and tests APL combinations for marketing variables
        Selects significant variables based on estimate rules and refits the final model
        """
        with threadpool_limits(limits=1):
            np.random.seed(0)  # Reset numpy random state per call for determinism
            modelling_cluster = pdf["modelling_cluster"].iloc[0]

            # Grid Search Parameters
            level_variance_p = float(pdf["level_variance"].iloc[0])
            cycle_param = bool(pdf["cycle"].iloc[0])
            cycle_bounds_raw = pdf["cycle_period_bounds"].iloc[0]  # may be numpy array
            seasonal_param = None  # currently always False

            # Process cycle bounds if cycle is enabled
            if cycle_param:
                try:
                    if cycle_bounds_raw is not None and len(cycle_bounds_raw) >= 2:
                        cycle_bounds = tuple(np.array(cycle_bounds_raw).astype(int).tolist())
                    else:
                        cycle_bounds = None
                except (ValueError, TypeError, IndexError):
                    cycle_bounds = None
            else:
                cycle_bounds = None

            iteration_number = pdf["Iteration_Number"].iloc[0]
            independent_variables = sorted(list(pdf["variable_list"].iloc[0]))  # Sort for deterministic processing order
            ext_vars_list = sorted(list(pdf["ext_variable_list"].iloc[0]))      # Sort external vars too

            # Pivot data to wide format for UCM
            master_file = pdf.pivot(index="wdate", columns="variable", values="value").reset_index()

            # Ensure temporal order — Spark shuffle does not guarantee row order within a group
            # so pd.pivot preserves arrival order, not wdate order. Kalman filter is order-sensitive.
            master_file = master_file.sort_values("wdate").reset_index(drop=True)

            # Clean data after pivot, not all data will have the full 104-week period so the pivot add NaN values
            master_file = master_file.fillna(0)

            # Intitialising empty variable list
            rhs_ucm_init = []

            # Iterative Greedy Selection Algorithm to select best APL variables
            for i in range(len(independent_variables)):
                ucm_1_summary_all = pd.DataFrame()

                # Apply APL only to marketing variables
                if independent_variables[i].lower() not in ext_vars_list:

                    for ad, po, la in all_combinations:
                        key = f"{str(ad).zfill(2)}{str(po).zfill(3)}{str(la)}"
                        ind_upd = f"{independent_variables[i]}_{key}"
                        rhs_ucm_fin = rhs_ucm_init + [ind_upd]

                        ucm_init = ucm_model_initialization(master_file, dependent, rhs_ucm_fin,
                                                            seasonal_param, cycle_param, cycle_bounds)

                        _init_start_params = np.round(ucm_init.start_params, 8)  # Quantise to absorb BLAS noise in start_params
                        ucm_init_fit = ucm_init.fit(start_params=_init_start_params, cov_type="oim", method=UCM_METHOD, maxiter=500, disp=False)

                        # Retrieve level & slope coefficients
                        vs_level_fin = ucm_init_fit.params[constant_sigma2_level]
                        vs_slope_fin = ucm_init_fit.params[constant_sigma2_trend]

                        vs_level_fin, vs_slope_fin = level_normalizer(master_file, dependent, vs_level_fin, vs_slope_fin)
                        vs_level_fin = round(vs_level_fin, 3)  # Normalise to absorb residual BLAS noise
                        vs_slope_fin = round(vs_slope_fin, 3)

                        _constrained_names = {constant_sigma2_level, constant_sigma2_trend}
                        _free_idx = [i for i, n in enumerate(ucm_init.param_names) if n not in _constrained_names]
                        ucm_init_1 = ucm_init.fit_constrained(
                            constraints={
                                constant_sigma2_level: round(vs_level_fin * level_variance_p, 8),
                                constant_sigma2_trend: round(vs_slope_fin * level_variance_p, 8),
                            },
                            start_params=np.round(ucm_init_fit.params, 3)[_free_idx],
                            cov_type="oim",
                            method=UCM_METHOD,
                            maxiter=500,
                            disp=False,
                        )

                        # Round both params and bse before computing z-values so that
                        # small BLAS-induced differences in the Hessian evaluation do not
                        # alter the pvalue used for APL variable selection.
                        _params_r = ucm_init_1.params.round(4)
                        _bse_r = ucm_init_1.bse.round(4)
                        _zv = (_params_r / _bse_r).round(4)
                        ucm_init_summary = pd.DataFrame({
                            "estimate": _params_r,
                            "approx_std_err": _bse_r,
                            "zvalue": _zv,
                            "pvalue_zdist": np.round(2 * ss.norm.sf(np.abs(_zv)), 8),
                        }).reset_index().rename(columns={"index": "variable_apl"})

                        ucm_1_summary_all = pd.concat([ucm_1_summary_all, ucm_init_summary], ignore_index=True)

                # Fitting Variables with no APL transformation
                else:
                    # Creating key to refer right APL combination as per apl transformation
                    key = "001000"
                    ind_upd = f"{independent_variables[i]}_{key}"
                    rhs_ucm_fin = rhs_ucm_init + [ind_upd]

                    ucm_init = ucm_model_initialization(master_file, dependent, rhs_ucm_fin,
                                                        seasonal_param, cycle_param, cycle_bounds)

                    _ext_start_params = np.round(ucm_init.start_params, 8)  # Quantise to absorb BLAS noise in start_params

                    ucm_init_fit = ucm_init.fit(start_params=_ext_start_params, cov_type="oim", method=UCM_METHOD, maxiter=500, disp=False)

                    vs_level_fin = ucm_init_fit.params[constant_sigma2_level]
                    vs_slope_fin = ucm_init_fit.params[constant_sigma2_trend]
                    vs_level_fin, vs_slope_fin = level_normalizer(master_file, dependent, vs_level_fin, vs_slope_fin)
                    vs_level_fin = round(vs_level_fin, 3)  # Normalise to absorb residual BLAS noise
                    vs_slope_fin = round(vs_slope_fin, 3)

                    _constrained_names = {constant_sigma2_level, constant_sigma2_trend}
                    _free_idx = [i for i, n in enumerate(ucm_init.param_names) if n not in _constrained_names]
                    ucm_init_1 = ucm_init.fit_constrained(
                        constraints={
                            constant_sigma2_level: round(vs_level_fin * level_variance_p, 8),
                            constant_sigma2_trend: round(vs_slope_fin * level_variance_p, 8),
                        },
                        start_params=np.round(ucm_init_fit.params, 3)[_free_idx],
                        cov_type="oim",
                        method=UCM_METHOD,
                        maxiter=500,
                        disp=False,
                    )

                    # Round both params and bse before computing z-values so that
                    # small BLAS-induced differences in the Hessian evaluation do not
                    # alter the pvalue used for ext variable selection.
                    _params_r = ucm_init_1.params.round(4)
                    _bse_r = ucm_init_1.bse.round(4)
                    _zv = (_params_r / _bse_r).round(4)
                    ucm_init_summary = pd.DataFrame({
                        "estimate": _params_r,
                        "approx_std_err": _bse_r,
                        "zvalue": _zv,
                        "pvalue_zdist": np.round(2 * ss.norm.sf(np.abs(_zv)), 8),
                    }).reset_index().rename(columns={"index": "variable_apl"})

                    ucm_1_summary_all = pd.concat([ucm_1_summary_all, ucm_init_summary], ignore_index=True)

                # Force variable_apl to lowercase for consistent parsing
                ucm_1_summary_all["variable_apl"] = ucm_1_summary_all["variable_apl"].str.lower()

                # Remove all APL transformations that have a negative coefficient for marketing variables
                # Drop any APL transforms that produce negative estimations for the marketing variables
                ucm_1_summary_all = ucm_1_summary_all[
                    ~(
                        (ucm_1_summary_all['estimate'] < 0) &
                        (
                            ucm_1_summary_all['variable_apl']
                            .str.lower()
                            .str.contains('|'.join([x.lower() for x in marketing_variables_list]))
                        )
                    )
                ]

                # Creating conditional flag for the estimate check - Iterations with  positive base price estimates are removed (as per business experience)
                condition_a = (ucm_1_summary_all['estimate'] > 0) & (
                    ucm_1_summary_all['variable_apl'].str.contains('|'.join([x.lower() for x in negative_factors_list])))

                # Iterations with variables having absolute estimates > 0.9 are removed
                condition_b = (ucm_1_summary_all['estimate'].abs() > 0.9)

                # Creating flag with conditions for filtering valid Iterations
                ucm_1_summary_all['flag_estimate_negative'] = np.where(condition_a, 1, 0)
                ucm_1_summary_all['flag_estimate_negative'] = np.where(
                    condition_b, 1, ucm_1_summary_all['flag_estimate_negative']
                )

                # Parsing Variable name and APLs
                ucm_1_summary_all['var_apl'] = ucm_1_summary_all['variable_apl'].str.slice(5, 5 + var_len + 7)
                ucm_1_summary_all['var'] = ucm_1_summary_all['variable_apl'].str.slice(5, 5 + var_len)

                # Filtering for selecting valid iterations after applying conditions
                ucm_1_summary_all['model_no'] = 1
                ucm_1_summary_all['flag_estimate_negative_sum'] = ucm_1_summary_all.groupby(['model_no'])[
                    'flag_estimate_negative'].transform('sum')
                ucm_1_summary_all_signficant = ucm_1_summary_all[(ucm_1_summary_all['flag_estimate_negative_sum'] == 0)]

                # Selecting the variables with apl combination with minimum p-value
                ucm_var_select_dat = ucm_1_summary_all_signficant[
                    (ucm_1_summary_all_signficant['var'] == independent_variables[i].lower())].copy()

                # Force sorting on explicitly rounded keys to eliminate float64 residual precision
                # Pandas sort_values compares full float64 precision (~15 digits) even after np.round(x, 8)
                # This creates a deterministic sort key at exactly 8dp precision
                if ucm_var_select_dat.shape[0] > 0:
                    ucm_var_select_dat['_sort_key'] = ucm_var_select_dat['pvalue_zdist'].round(8)
                    ucm_var_select_dat = ucm_var_select_dat.sort_values(
                        by=['_sort_key', 'var_apl'],
                        ascending=[True, True]
                    ).reset_index(drop=True)
                    ucm_var_select = [ucm_var_select_dat.loc[0, 'var_apl'].upper()]
                else:
                    ucm_var_select = []

                rhs_ucm_init = rhs_ucm_init + ucm_var_select

            # Fit final UCM with selected variables
            ucm_fin = ucm_model_initialization(master_file, dependent, rhs_ucm_init, seasonal_param, cycle_param, cycle_bounds)
            # Compute start_params explicitly outside fit() so powell always starts from the same point
            # regardless of LAPACK/BLAS state accumulated from prior tasks in the reused Python worker process
            _fin_start_params = np.round(ucm_fin.start_params, 8)  # Quantise to absorb BLAS noise in start_params

            ucm_fin_fit = ucm_fin.fit(start_params=_fin_start_params, cov_type="oim", method=UCM_METHOD, maxiter=500, disp=False)

            vs_level_fin = ucm_fin_fit.params[constant_sigma2_level]
            vs_slope_fin = ucm_fin_fit.params[constant_sigma2_trend]
            vs_level_fin, vs_slope_fin = level_normalizer(master_file, dependent, vs_level_fin, vs_slope_fin)
            vs_level_fin = round(vs_level_fin, 3)  # Normalise to absorb residual BLAS noise
            vs_slope_fin = round(vs_slope_fin, 3)

            _constrained_names = {constant_sigma2_level, constant_sigma2_trend}
            _free_idx = [i for i, n in enumerate(ucm_fin.param_names) if n not in _constrained_names]
            ucm_fin_1 = ucm_fin.fit_constrained(
                constraints={
                    constant_sigma2_level: round(vs_level_fin * level_variance_p, 8),
                    constant_sigma2_trend: round(vs_slope_fin * level_variance_p, 8),
                },
                start_params=np.round(ucm_fin_fit.params, 3)[_free_idx],
                cov_type="oim",
                method=UCM_METHOD,
                maxiter=500,
                disp=False,
            )

            # Extract and format final results
            try:
                # Serialize the full model object
                ucm_fin_1_serialized = serialize_ucm_model(ucm_fin_1)
                # Round params to 4dp for both estimate and the Kalman smoother.
                # L-BFGS-B accumulates BLAS floating-point state from prior fits within the same
                # Python worker process. On heterogeneous EMR hardware this causes fit_constrained()
                # to converge to different local optima differing by O(1e-4) in param space.
                # Rounding to 4dp collapses these into a single canonical value, then re-applying
                # the Kalman smoother at that rounded point ensures both the smoothed states
                # (level_std/slope_std) AND the regression contributions (estimate) are computed
                # from the same deterministic params — eliminating divergence in TOTAL_BASELINE_AMT.
                _rounded_params = ucm_fin_1.params.round(4)
                # Apply same BSE fix as APL/ext loops: round both params and bse before dividing
                # so that BLAS-noisy Hessian evaluation does not affect pvalue_zdist output.
                _fin_bse_r = ucm_fin_1.bse.round(4)
                _fin_zv = (_rounded_params / _fin_bse_r).round(4)
                ucm_fin_summary = pd.DataFrame({
                    "estimate": _rounded_params,
                    "approx_std_err": _fin_bse_r,
                    "zvalue": _fin_zv,
                    "pvalue_zdist": np.round(2 * ss.norm.sf(np.abs(_fin_zv)), 8),
                }).reset_index().rename(columns={"index": "variable_apl"})

                ucm_fin_summary["modelling_cluster"] = modelling_cluster
                ucm_fin_summary["level_variance"] = level_variance_p
                ucm_fin_summary["cycle"] = cycle_param
                ucm_fin_summary["cycle_period_bounds"] = str(cycle_bounds)
                ucm_fin_summary["iteration_number"] = iteration_number

                ucm_fin_summary["level_std"] = None
                ucm_fin_summary["slope_std"] = None
                ucm_fin_summary["cycle_std"] = None
                ucm_fin_summary["ucm_fin_1_serialized"] = ucm_fin_1_serialized

                # Re-apply Kalman smoother at the same rounded params used for estimate above.
                # Both must use identical params so regression contributions and smoothed states
                # are computed from the same canonical rounded parameter vector.
                _det_smooth = ucm_fin.smooth(_rounded_params)
                ucm_fin_summary.loc[0, "level_std"] = ",".join(map(str, np.round(_det_smooth.level.smoothed, 8)))
                ucm_fin_summary.loc[0, "slope_std"] = ",".join(map(str, np.round(_det_smooth.trend.smoothed, 8)))

                # If there is no cycle component this won't exist
                if cycle_param:
                    ucm_fin_summary.loc[0, "cycle_std"] = ",".join(map(str, np.round(_det_smooth.cycle.smoothed, 8)))

                ucm_fin_summary["selected_variables"] = ", ".join(rhs_ucm_init)

                return ucm_fin_summary

            except Exception as e:
                final_list = ", ".join(rhs_ucm_init)
                return pd.DataFrame([{
                    "variable_apl": f"ERROR: {str(e)}",
                    "estimate": None,
                    "approx_std_err": None,
                    "zvalue": None,
                    "pvalue_zdist": None,
                    "modelling_cluster": modelling_cluster,
                    "level_variance": level_variance_p,
                    "cycle": cycle_param,
                    "cycle_period_bounds": cycle_bounds,
                    "iteration_number": iteration_number,
                    "selected_variables": final_list,
                    "level_std": None,
                    "slope_std": None,
                    "cycle_std": None,
                    "ucm_fin_1_serialized": None,
                }])

    def ucm_model_initialization(master_file, dependent, rhs_ucm_fin, seasonal_param, cycle_param, cycle_bounds):
        """
        Initialize Unobserved Components Model with specified hyperparameters

        Objective:
            Model initialization happens here where we pass the hyper-parameters and dependent and independent variables to the model.
            Once the model is initialized then we use the object to run fit method to get the results in subsequent steps.

        Args:
            master_file (pd.DataFrame): Contains ADS
            dependent (String): Contains dependent variable as a three letter code
            rhs_ucm_fin (List): Contains list of independent variables to be tested
            seasonal_param (Bool): Contains whether seasonality to be tested internally in model
            cycle_param (Bool): Contains whether cyclicity to be tested in model
            cycle_bounds (List): Contains the cycle bounds for which model should test parsed

        Returns:
            ucm_init (Object): Contains UCM model initialized

        """
        if len(rhs_ucm_fin) > 0:
            ucm_init = sm.UnobservedComponents(
                endog=master_file[dependent],
                exog=master_file[rhs_ucm_fin],
                irregular=True,
                level=True,
                trend=True,
                seasonal=seasonal_param,
                stochastic_level=True,
                stochastic_trend=True,
                cycle=cycle_param,
                cycle_period_bounds=cycle_bounds,
                random_state=1234,
            )
        else:
            ucm_init = sm.UnobservedComponents(
                endog=master_file[dependent],
                irregular=True,
                level=True,
                trend=True,
                seasonal=seasonal_param,
                stochastic_level=True,
                stochastic_trend=True,
                cycle=cycle_param,
                cycle_period_bounds=cycle_bounds,
                random_state=1234,
            )
        return ucm_init

    def level_normalizer(master_file, dependent, vs_level_fin, vs_slope_fin):
        """
        Cap extremely low level and slope coefficients for model stability.

        Objective:
            In case the coefficients are extremely low the model does not estimate baseline accurately
            so we cap the values to be used in the fit step.

        Args:
            master_file (pd.DataFrame): Contains ADS
            dependent (String): Contains dependent variable as a three letter code
            vs_level_fin (float): Contains Coefficient of Level
            vs_slope_fin (float): Contains Coefficient of Slope value

        Returns:
            vs_level_fin (float): Contains capped Coefficient of Level
            vs_slope_fin (float): Contains capped Coefficient of Slope value

        """
        if vs_level_fin < 1e-8:
            vs_level_fin = np.std(master_file[dependent]) / (len(master_file) - 1)
            vs_slope_fin = np.std(master_file[dependent]) / (len(master_file) - 1)
        return vs_level_fin, vs_slope_fin

    return ucm_model_runner


def cal_smape(df, y_true_col, y_pred_col):
    """
    Symmetric Mean Absolute Percentage Error (SMAPE).

    Formula:
        (1/n) * Σ [ |y_hat - y| / ((|y| + |y_hat|) / 2) ]

    Args:
        df (DataFrame): DataFrame containing actual and predicted columns.
        y_true_col (str): Column name with actual values.
        y_pred_col (str): Column name with predicted values.

    Returns:
        DataFrame: SMAPE value per modelling_cluster & Iteration_Number.
    """

    # Boolean mask for rows where both actual and predicted are zero
    mask_both_zero = (F.col(y_true_col) == 0) & (F.col(y_pred_col) == 0)

    # Numerator and denominator for SMAPE formula
    numerator = F.abs(F.col(y_true_col) - F.col(y_pred_col))
    denominator = (F.abs(F.col(y_true_col)) + F.abs(F.col(y_pred_col))) / F.lit(2.0)

    # SMAPE value for each row; set to 0 if both actual & predicted are 0
    smape_col = F.when(mask_both_zero, F.lit(0.0)).otherwise(numerator / denominator)

    # Group by and calculate mean SMAPE
    result_df = (
        df.withColumn("smape_val", smape_col)
        .groupBy('modelling_cluster', 'Iteration_Number')
        .agg(F.avg("smape_val").alias("SMAPE"))
    )

    return result_df.select('modelling_cluster', 'Iteration_Number', 'SMAPE')


def r_square(df, y_true_col, y_pred_col):
    """
    Calculated R-squared.

    Formula:
        1 - (Σ (y_hat - y)^2 / Σ (y - y_mean)^2)

    Interpretation:
        - 1.0 = perfect fit
        - 0.0 = no predictive power
    """

    # Calculate mean of actual values by group
    mean_actual = (
        df
        .groupBy('modelling_cluster', 'Iteration_Number')
        .agg(F.avg(y_true_col).alias('mean_actual'))
    )

    # Join with original data to calculate deviations
    df_with_mean = df.join(mean_actual, on=['modelling_cluster', 'Iteration_Number'])

    # Calculate SST (total sum of squares) and SSE (sum of squared errors)
    df_with_metrics = (
        df_with_mean
        .withColumn('squared_residuals', F.pow(F.col(y_true_col) - F.col(y_pred_col), 2))
        .withColumn('total_sum_of_squares', F.pow(F.col(y_true_col) - F.col('mean_actual'), 2))
    )

    # Aggregate to get SST and SSE
    df_agg = (
        df_with_metrics
        .groupBy('modelling_cluster', 'Iteration_Number')
        .agg(
            F.sum('total_sum_of_squares').alias('SST'),
            F.sum('squared_residuals').alias('SSE'),
            F.sum(
                F.when((F.col(y_true_col) == 0) & (F.col(y_pred_col) == 0), 1).otherwise(0)
            ).alias('zero_count'),
            F.count('*').alias('total_count')
        )
    )

    # Calculate R-squared, handling all-zeros and divide-by-zero cases
    result = (
        df_agg
        .withColumn('all_zeros', F.col('zero_count') == F.col('total_count'))
        .withColumn('all_actual_zeros', F.col('SST') == 0)  # Prevent divide-by-zero error
        .withColumn(
            'RSQ',
            F.when(F.col('all_zeros'), 1.0)  # Perfect prediction if all values are zero
            .when(F.col('all_actual_zeros') & ~F.col('all_zeros'), 0.0)
            .otherwise(1.0 - (F.col('SSE') / F.col('SST')))
        )
    )

    return result.select('modelling_cluster', 'Iteration_Number', 'RSQ')


def cal_mape(df, y_true_col, y_pred_col):
    """
    Calculate Mean Absolute Percentage Error (MAPE).

    Formula:
        (1/n) * Σ [ |y_hat - y| / |y| ]
    """

    # Create MAPE column
    df_with_mape = (
        df.withColumn(
            'mape_val',
            F.when(F.col(y_true_col) == 0, F.lit(0).cast('double'))
            .otherwise(F.abs((F.col(y_true_col) - F.col(y_pred_col)) / F.col(y_true_col)))
        )
    )

    # Aggregate average MAPE, excluding NaNs and infinities
    # Filter out NaN and infinite values
    df_filtered = df_with_mape.filter(
        ~F.isnan("mape_val") &
        (F.abs(F.col("mape_val")) != float("inf"))
    )

    # Aggregate average MAPE
    result = (
        df_filtered
        .groupBy("modelling_cluster", "Iteration_Number")
        .agg(F.avg("mape_val").alias("MAPE"))
    )

    return result


def weighted_mape(df, y_true_col, y_pred_col):
    """
    Calculate Weighted Mean Absolute Percentage Error (WMAPE).

    Weights are proportional to each row's contribution to total sales.
    """

    # Get total sales for each group
    sales_totals = (
        df.groupBy('modelling_cluster', 'Iteration_Number')
        .agg(F.sum(y_true_col).alias('total_sales'))
    )

    # Join with original data to scale actuals
    df_with_totals = df.join(sales_totals, on=['modelling_cluster', 'Iteration_Number'])

    # Calculate scaled values and weighted MAPE components
    df_with_components = (
        df_with_totals
        .withColumn(
            'actual_scaled',
            F.when(F.col('total_sales') != 0, F.col(y_true_col) / F.col('total_sales'))
            .otherwise(F.lit(0.0))
        )
        .withColumn(
            'mape_val',
            F.when(F.col(y_true_col) == 0, F.lit(0).cast('double'))
            .otherwise(F.abs((F.col(y_true_col) - F.col(y_pred_col)) / F.col(y_true_col)))
        )
        .withColumn('scaled_mape', F.coalesce(F.col('actual_scaled') * F.col('mape_val'), F.lit(0.0)))
    )

    # Aggregate weighted MAPE
    aggregated = (
        df_with_components
        .groupBy('modelling_cluster', 'Iteration_Number')
        .agg(
            F.sum('scaled_mape').alias('sum_scaled_mape'),
            F.sum('actual_scaled').alias('sum_actual_scaled')
        )
    )

    # Calculate final WMAPE
    result = (
        aggregated
        .withColumn('WMAPE', F.col('sum_scaled_mape') / F.col('sum_actual_scaled'))
        .select('modelling_cluster', 'Iteration_Number', 'WMAPE')
    )

    return result


def weighted_smape(df, y_true_col, y_pred_col):
    """
    Calculate Weighted Symmetric Mean Absolute Percentage Error (WSMAPE).

    Formula:
        Weighted version of SMAPE using proportional actual sales as weights.
    """

    # Get total sales for each group
    sales_totals = (
        df.groupBy('modelling_cluster', 'Iteration_Number')
        .agg(F.sum(y_true_col).alias('total_sales'))
    )

    # Join with original data to scale actuals
    df_with_totals = df.join(sales_totals, on=['modelling_cluster', 'Iteration_Number'])

    # Calculate weighted SMAPE components
    df_with_components = (
        df_with_totals
        .withColumn(
            'actual_scaled',
            F.when(F.col('total_sales') != 0, F.col(y_true_col) / F.col('total_sales'))
            .otherwise(F.col(y_true_col))
        )
        .withColumn('numerator', F.abs(F.col(y_true_col) - F.col(y_pred_col)))
        .withColumn(
            'denominator',
            (F.abs(F.col(y_true_col)) + F.abs(F.col(y_pred_col))) / 2.0
        )
        .withColumn(
            'smape_val',
            F.when((F.col(y_true_col) == 0) & (F.col(y_pred_col) == 0), 0)
            .otherwise(F.col('numerator') / F.col('denominator'))
        )
        .withColumn('scaled_smape', F.col('actual_scaled') * F.col('smape_val'))
    )

    # Aggregate weighted SMAPE
    aggregated = (
        df_with_components
        .groupBy('modelling_cluster', 'Iteration_Number')
        .agg(
            F.sum('scaled_smape').alias('sum_scaled_smape'),
            F.sum('actual_scaled').alias('sum_actual_scaled')
        )
    )

    # Calculate final WSMAPE
    result = (
        aggregated
        .withColumn(
            'WSMAPE',
            F.when(F.col('sum_actual_scaled') != 0,
                   F.col('sum_scaled_smape') / F.col('sum_actual_scaled'))
            .otherwise(F.lit(3.0))  # Arbitrary high error when denominator is zero
        )
        .select('modelling_cluster', 'Iteration_Number', 'WSMAPE')
    )

    return result


def calculate_model_metrics(ucm_base_data_df: DataFrame, dependent: str) -> DataFrame:
    """
    Function used to calculate model metrics to choose the best iteration.

    Args:
        ucm_base_data_df (DataFrame): Model output containing variable contributions.
        dependent (str): Column name of dependent variable.

    Returns:
        DataFrame: Metrics for each iteration (baseline %, seasonal %, errors, RSQ, etc.)
    """

    # If DataFrame is empty, return an empty DataFrame with iteration & cluster columns
    if not ucm_base_data_df.take(1):
        return ucm_base_data_df.sparkSession.createDataFrame(
            [], "Iteration_Number STRING, modelling_cluster STRING"
        )

    # Convert from long format to wide format
    ucm_base_data_wide = (
        ucm_base_data_df
        .groupBy("modelling_cluster", "Iteration_Number", "wdate")
        .pivot('variable')
        .agg(F.max('value'))
    )

    # Define columns to exclude from SMAPE calculation
    smape_exclude_columns = [
        'modelling_cluster', 'Iteration_Number', 'wdate', 'level',
        'seasonal', 'cycle', dependent, 'nec_tot_tot_tot_tot_tot_sea'
    ]

    # Keep only exclude columns that exist in the DF (safety check)
    all_columns = ucm_base_data_wide.columns
    smape_columns_to_exclude = [col for col in smape_exclude_columns if col in all_columns]

    # Get the sum of all prediction columns (excluding the ones in smape_columns_to_exclude) (per row)
    pred_cols_to_sum = [c for c in all_columns if c not in smape_columns_to_exclude]

    if pred_cols_to_sum:
        # Create an array of all prediction columns and sum over each row using array functions
        cols_array = F.array([F.coalesce(F.col(c), F.lit(0.0)) for c in pred_cols_to_sum])
        sum_expr = F.aggregate(cols_array, F.lit(0.0), lambda acc, x: acc + x)
        ucm_base_data_wide = ucm_base_data_wide.withColumn("predicted", sum_expr)
    else:
        ucm_base_data_wide = ucm_base_data_wide.withColumn("predicted", F.lit(0.0))

    # Calculate baseline percentage
    model_metrics = (
        ucm_base_data_wide
        .groupBy('Iteration_Number', 'modelling_cluster')
        .agg(
            F.sum('level_base').alias('level_base_sum'),
            F.sum(F.col(dependent)).alias(f'{dependent}_sum')
        )
        .withColumn(
            'Baseline_Perc',
            (F.col('level_base_sum') / F.col(f'{dependent}_sum')) * 100
        )
        .select('Iteration_Number', 'modelling_cluster', 'Baseline_Perc')
    )

    # Add seasonality percentage if available
    if 'nec_tot_tot_tot_tot_tot_sea' in all_columns:
        seasonal_pct = (
            ucm_base_data_wide
            .groupBy('Iteration_Number', 'modelling_cluster')
            .agg(
                F.sum('nec_tot_tot_tot_tot_tot_sea').alias('seasonal_sum'),
                F.sum(dependent).alias(f'{dependent}_sum')
            )
            .withColumn('Seasonal_Perc',
                        (F.col('seasonal_sum') / F.col(f'{dependent}_sum')) * 100)
            .select('Iteration_Number', 'modelling_cluster', 'Seasonal_Perc')
        )

        model_metrics = model_metrics.join(
            seasonal_pct, on=['Iteration_Number', 'modelling_cluster'], how='left'
        )
    else:
        model_metrics = model_metrics.withColumn('Seasonal_Perc', F.lit(0.0))

    # Calculate incremental percentage
    model_metrics = model_metrics.withColumn(
        'Incremental_Perc', F.lit(100.0) - F.col('Baseline_Perc')
    )

    # Ensure time-series order for error metrics
    ucm_base_data_wide = ucm_base_data_wide.orderBy(
        "modelling_cluster", "Iteration_Number", "wdate"
    )

    # Calculate various metrics
    smape_df = cal_smape(ucm_base_data_wide, dependent, 'predicted')
    rsq_df = r_square(ucm_base_data_wide, dependent, 'predicted')
    mape_df = cal_mape(ucm_base_data_wide, dependent, 'predicted')
    wgtd_mape_df = weighted_mape(ucm_base_data_wide, dependent, 'predicted')
    wgtd_smape_df = weighted_smape(ucm_base_data_wide, dependent, 'predicted')

    # Join all metrics
    model_metrics = (
        model_metrics
        .join(smape_df, on=['modelling_cluster', 'Iteration_Number'], how='left')
        .join(rsq_df, on=['modelling_cluster', 'Iteration_Number'], how='left')
        .join(mape_df, on=['modelling_cluster', 'Iteration_Number'], how='left')
        .join(wgtd_mape_df, on=['modelling_cluster', 'Iteration_Number'], how='left')
        .join(wgtd_smape_df, on=['modelling_cluster', 'Iteration_Number'], how='left')
    )

    # Calculate minimum baseline value
    min_level_df = (
        ucm_base_data_wide
        .groupBy('modelling_cluster', 'Iteration_Number')
        .agg(F.min('level_base').alias('min_level'))
    )
    model_metrics = model_metrics.join(min_level_df, on=['modelling_cluster', 'Iteration_Number'], how='left')

    # Add seasonality measure
    seasonality_index_df = seasonality_measure_calculation(ucm_base_data_wide, dependent)

    model_metrics = model_metrics.join(
        seasonality_index_df, on=['modelling_cluster', 'Iteration_Number'], how='left'
    )

    return model_metrics
