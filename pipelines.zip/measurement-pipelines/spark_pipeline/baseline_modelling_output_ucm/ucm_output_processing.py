from pyspark.sql import functions as F, types as T, DataFrame, Column
from pyspark.sql.window import Window

from typing import Dict, Any, Tuple, List

from spark_pipeline.baseline_modelling_output_ucm.ucm_utils import clean_variable_apl, aggregate_seasonality, \
    modelling_cluster_split, fix_control_variable_hierarchy, fix_split_variable_name, \
    parse_iteration_name, get_campaign_details, filter_by_campaign_bounds
from spark_pipeline.common.variables import BaselineModellingOutputConfig
from functools import reduce
from operator import add


def get_marketing_column_names(pivoted_columns: List[str], marketing_variables_list: list) -> List[str]:
    """Return pivoted column names that match the configured marketing patterns."""
    return [item for item in list(map(str.lower, pivoted_columns)) if any(sub in item for sub in marketing_variables_list)]


def get_marketing_contribution_column(pivoted_columns: List[str], marketing_variables_list: list) -> Column:
    """Build the marketing contribution column, defaulting to 0.0 when no marketing columns exist."""
    marketing_col_name = get_marketing_column_names(pivoted_columns, marketing_variables_list)

    if not marketing_col_name:
        print(f"No marketing contribution columns found for patterns {marketing_variables_list} — marketing contribution set to 0.0, no incrementality attributed.")
        return F.lit(0.0)

    return reduce(add, [F.coalesce(F.col(c), F.lit(0.0)) for c in marketing_col_name])


def process_ucm_outputs(
        ucm_results: DataFrame,
        master_dataset: DataFrame,
        lagdata_1_df: DataFrame,
        sc: DataFrame,
        dependent: str
) -> Tuple[DataFrame, DataFrame]:
    """
    Processes UCM model outputs to generate baseline modelling inputs and
    cluster-level UCM contributions for dependent variables.

    Objective:
        Extract the final selected variables per iteration and cluster.
        Build the baseline modelling input dataset including scaled and unscaled data.
        Calculate UCM level, slope, and cycle contributions based on smoothed outputs and dependent mean.

    Args:
        ucm_results (DataFrame): Contains outputs of the UCM model including smoothed arrays and selected variables.
        master_dataset (DataFrame): Full analytical dataset in long format with cluster, variable, and wdate.
        lagdata_1_df (DataFrame): Original lagged dataset for all variables, unscaled.
        sc (DataFrame): Contains cluster-level dependent mean for scaling UCM contributions.
        dependent (str): Name of the dependent variable in the dataset.

    Returns:
        ucm_base_data (DataFrame): Contains UCM-level, slope, cycle, and baseline contributions joined with actual dependent values.
        baseline_modelling_input_data (DataFrame): Contains modelling input data with both scaled and unscaled variables.
    """

    df_ucm_arr_long = (
        ucm_results
        .select("modelling_cluster", "iteration_number", "selected_variables")
        .distinct()
        .withColumn(
            'var_list_arr',
            F.split(F.regexp_replace(F.col("selected_variables"), r"\s+", ""), ",")  # remove spaces & split
        )
        .withColumnRenamed("iteration_number", "Iteration_Number")
        .select("modelling_cluster", "Iteration_Number", "var_list_arr")
    )

    # This has all the selected variables per modelling_cluster/Iteration Number
    final_input_dataset = (
        master_dataset.alias("m")
        .join(
            F.broadcast(df_ucm_arr_long.alias("u")),
            on=["modelling_cluster", "Iteration_Number"]
        )
        .filter(
            (F.array_contains(F.col("u.var_list_arr"), F.col("m.variable"))) |
            (F.col("m.variable") == F.lit(dependent))
        )
        .select("m.modelling_cluster", "m.Iteration_Number", "m.wdate", "m.variable", "m.value")
        .withColumn('scaled', F.lit(True))
    )

    lagdata_with_iter = (
        lagdata_1_df.alias("l")
        .join(
            df_ucm_arr_long.select("modelling_cluster", "Iteration_Number").distinct(),
            on="modelling_cluster",
            how="inner"
        )
        .select("l.modelling_cluster", "Iteration_Number", "l.wdate", "l.variable", "l.value")
        .withColumn("scaled", F.lit(False))
    )

    baseline_modelling_input_data = final_input_dataset.unionByName(lagdata_with_iter, allowMissingColumns=True)

    # Create a window to preserve the order of the arrays as they are exploded

    # We store the arrays and estimates in one ucm output, so explode the arrays so we can process them
    df_ucm_exploded = (
        ucm_results
        .filter(F.col('level_std').isNotNull())  # We store the arrays only in pos [0] so we filter to only get these rows
        .select(
            "modelling_cluster",
            F.col("iteration_number").alias("Iteration_Number"),
            F.split(F.regexp_replace(F.col("level_std"), r"\s+", ""), ",").alias("level_std_arr"),
            F.split(F.regexp_replace(F.col("slope_std"), r"\s+", ""), ",").alias("slope_std_arr"),
            F.split(F.regexp_replace(F.col("cycle_std"), r"\s+", ""), ",").alias("cycle_std_arr")
        )
        .withColumn("level_std_arr", F.expr("transform(level_std_arr, x -> cast(x as double))"))
        .withColumn("slope_std_arr", F.expr("transform(slope_std_arr, x -> cast(x as double))"))
        .withColumn("cycle_std_arr", F.expr("transform(coalesce(cycle_std_arr, array()), x -> cast(x as double))"))
        .withColumn("zipped", F.arrays_zip("level_std_arr", "slope_std_arr", "cycle_std_arr"))
        .select(
            "modelling_cluster",
            "Iteration_Number",
            F.posexplode("zipped").alias("rn", "element")
        )
        .select(
            "modelling_cluster",
            "Iteration_Number",
            (F.col("rn") + F.lit(1)).alias("rn"),
            F.col("element.level_std_arr").alias("level_std"),
            F.col("element.slope_std_arr").alias("slope_std"),
            F.col("element.cycle_std_arr").alias("cycle_std"),
        )
    )

    # Calculate UCM contributions (level, slope, cycle) scaled by cluster mean
    sc_ucm_df = (
        sc
        .select(
            "modelling_cluster",
            "dep_mean"
        )
        .distinct()
        .join(
            F.broadcast(df_ucm_exploded),
            on="modelling_cluster",
            how="left"
        )
        .withColumn(
            "cycle_param",
            F.when(F.lower(F.col("Iteration_Number")).rlike(r"(?i)cycle:\s*true"),
                   F.lit(True))  # In the pandas code this is handled by an if statement
            .otherwise(F.lit(False))
        )
        .withColumn("ucm_level", F.col("dep_mean") * F.col("level_std"))
        .withColumn("ucm_slope", F.col("dep_mean") * F.col("slope_std"))
        .withColumn("ucm_cycle", F.col("dep_mean") * F.col("cycle_std"))
        .withColumn("level", F.col("ucm_level") + F.col("ucm_slope"))
        .withColumn(
            "level_base",
            F.when(F.col("cycle_param"), F.col("level") + F.col("ucm_cycle")).otherwise(F.col("level"))
        )
        .withColumn("seasonal", F.lit(None))
        .withColumn("cycle", F.when(F.col("cycle_param"), F.col("ucm_cycle")).otherwise(F.lit(None).cast("double")))
        .select(
            "modelling_cluster",
            "Iteration_Number",
            "level",
            "seasonal",
            "cycle",
            "level_base",
            "rn"
        )
    )

    # Create a deterministic ordering of wdate and get the dependent values
    wdate_window = Window.partitionBy("modelling_cluster").orderBy("wdate")
    join_lag_data = (
        lagdata_1_df
        .filter(F.col('variable') == dependent)
        .select("modelling_cluster", "wdate", F.col("value").alias(dependent))
        .withColumn("rn", F.row_number().over(wdate_window))
    )

    ucm_base_data = (
        sc_ucm_df
        .join(
            join_lag_data,
            on=["modelling_cluster", "rn"],
            how="inner"
        )
        .drop("rn")  # Drop auxiliary row number, was just for the join to get consistent ordering
    )

    return ucm_base_data, baseline_modelling_input_data


def baseline_output_buckets_creation(base_data_df: DataFrame, master_df: DataFrame, config: Dict[str, Dict[str, Any]]):
    """
    Function used to create buckets like Seasonal for contributions of different variables

    Objective:
        Function is used to place the contributions of different variables into buckets like
        total_seasonality and total_baseline. The model provides granular inputs, and to calculate marketing incremental
        we place the outputs into these buckets. Then the marketing incremental is total sales - total baseline

        So essentially it takes multiple variables and combine their values into one bucket (variable) labeled seasonality
        and then sums these values to get total seasonality, and does the same for the other buckets

    Args:
        base_data_df (pyspark.DataFrame): Contains contributions of variables from model outputs
        master (pyspark.DataFrame): Contains Analytical Dataset
        config (Dict): Contains input configuration parameters

    Returns:
        result_df (pyspark.DataFrame): Contains contributions of variables from model outputs placed into buckets like seasonality
    """

    # Select distinct required columns to remove duplicates from weekly data
    master_df = master_df.select(
        "variable", "marketing_type", "marketing_channel", "marketing_sub_channel", "metric"
    ).distinct()

    # Removing APL combinations from variables
    base_data_df = clean_variable_apl(base_data_df, "variable")

    # Join with master metadata so we can label the variables in order to place them into buckets
    base_data_df = base_data_df.join(master_df, on="variable", how="left")

    # Clean up null variables as created variables have a null marketing channel and spark doesn't like nulls in filter conditions since it's treats them a option along with True and False
    base_data_df = base_data_df.withColumn(
        "marketing_channel",
        F.coalesce(F.col("marketing_channel"), F.lit("default"))
    )

    # Places the results into buckets
    result_df = aggregate_seasonality(base_data_df, config)

    return result_df


def seasonality_measure_calculation(ucm_base_data_df, dependent):
    """
    Function used to calculate contribution percentage of Seasonality in each iteration.

    Args:
        ucm_base_data_df (DataFrame): Contains contributions of variables from model output.
        dependent (str): Contains reference to the dependent variable.

    Returns:
        DataFrame: Contains contribution of Seasonality for each iteration.
    """

    # Check if seasonality column exists
    if 'nec_tot_tot_tot_tot_tot_sea' in ucm_base_data_df.columns:

        # Group by cluster & iteration, aggregate required values
        ucm_base_data_df = (
            ucm_base_data_df
            .groupBy('modelling_cluster', 'Iteration_Number')
            .agg(
                F.sum(F.col('nec_tot_tot_tot_tot_tot_sea')).alias('seasonality_val'),
                F.sum(F.col('level_base')).alias('baseline_val'),
                F.sum(F.col(dependent)).alias('sales_val')
            )
        )

        # Calculate seasonality measure as % of sales
        ucm_base_data_df = (
            ucm_base_data_df
            .withColumn(
                'seasonality_measure',
                (F.col('seasonality_val') / F.col('sales_val')) * 100
            )
            .fillna(0, subset=['seasonality_measure'])
            .select('modelling_cluster', 'Iteration_Number', 'seasonality_measure')
        )

    else:
        # If no seasonality column, return zeros for seasonality_measure
        ucm_base_data_df = (
            ucm_base_data_df
            .select('modelling_cluster', 'Iteration_Number')
            .distinct()
            .withColumn('SEASONALITY_MEASURE', F.lit(0))
        )

    return ucm_base_data_df


def filter_modelling_data(
        master_df: DataFrame,
        features_table: DataFrame,
        incremental_check_bool_df: DataFrame
) -> Tuple[DataFrame, DataFrame]:
    """
    Filter the datasets to only include modelling clusters that need another ucm pass based on incremental checks

    This is determined by the 'iteration_not_found' boolean flag in incremental_check_bool_df.
    This is because we run UCM on all modelling clusters, so if we've already found the best iteration for a modelling cluster,
    we don't need to run it again.

    Args:
        master_df (DataFrame): Main modelling dataset containing all modelling clusters.
        features_table (DataFrame): Set of features for each modelling cluster.
        incremental_check_bool_df (DataFrame): DataFrame with 'modelling_cluster' and 'iteration_not_found' boolean flag.

    Returns:
        Tuple[DataFrame, DataFrame]:
            - Filtered master_df containing only clusters needing another pass.
            - Filtered features_table for those clusters.
    """
    # Filter datasets to only include clusters that need another pass
    filtered_master_df = (
        master_df
        .join(
            incremental_check_bool_df.filter(F.col("iteration_not_found")),
            on="modelling_cluster",
            how="inner"
        )
        .drop("iteration_not_found")
    )

    filtered_features_table = (
        features_table
        .join(
            incremental_check_bool_df.filter(F.col("iteration_not_found")),
            on="modelling_cluster",
            how="inner"
        )
        .drop("iteration_not_found")
    )

    return filtered_master_df, filtered_features_table


def reiterate_baseline_selector(
    best_iteration_df: DataFrame
) -> DataFrame:
    """
    Function used to find the best iteration for each cluster

    With the new best interation logic, we rank the best iteration per cluster per UCM pass, so even
    if we're found the best iteration for a cluster in UCM pass 2, we still need re-rank it as we'll have two results
    in the best_iteration_df, likewise for single result that one will just be picked as the best iteration for that cluster.


    Args:
        best_iteration_df: DataFrame containing the best interation found for each cluster so far per UCM pass

    Returns:
        DataFrame containing the best iteration was found for all clusters


    Used In:
        main function called after each UCM run to choose the best iteration in cases where we haven't
        found the best iteration from best_iteration_picker

    Business Context:
        Function is used to select a best iteration by reiterating the checks on business rules
        in case a best iteration was not found in the previous Runs of UCM. Based on different
        metrics and criteria we create multiple ranks, and a final rank is created based on
        weighting the different ranks using weights from input config. This final rank is then
        chosen as the best iteration
    """

    # Rank iterations by penalty within each cluster
    window_penalty = Window.partitionBy("modelling_cluster").orderBy(
        F.col("total_penalty").asc(),
        F.col("Iteration_Number").asc()
    )

    # Select best iteration (lowest penalty) per cluster
    final_best_iteration_df = (
        best_iteration_df
        .withColumn("penalty_rank", F.dense_rank().over(window_penalty))
        .filter(F.col("penalty_rank") == 1)
        .select(
            "modelling_cluster",
            "Iteration_Number",
            "rsq",
            "wsmape"
        )
    )

    # Getting Brand, Cluster and Super-category name from Modelling Cluster column for downstream joins
    final_best_iteration_df = modelling_cluster_split(final_best_iteration_df)

    return final_best_iteration_df


def baseline_output_parser(baseline_output_pre_df: DataFrame, marketing_variables_list: list) -> DataFrame:
    """
    Function used to convert the raw Baseline Output into required format for the baseline modelling output table,
    used in the MTA, Baseline integration

    Args:
        baseline_output_pre_df (DataFrame): Raw baseline outputs with contributions of variables
        marketing_variables_list (list): List of marketing variables to identify which variables in the outputs are marketing levers

    Returns:
        DataFrame: Baseline outputs formatted for the pipeline
    """

    # Set up all variables for long form dataFrame filter
    filter_variables = marketing_variables_list + ["level_base", "nec_sal_tot_xxx_xxx_xxx_sls", "nec_tot_tot_tot_tot_tot_sea"]

    # Set up filter to check for string matching
    combined_filter = reduce(lambda a, b: a | b, [F.lower(F.col("variable")).contains(item) for item in filter_variables])

    if baseline_output_pre_df.take(1):

        # Filter only required variables we want for the final output
        baseline_output_pre_df = baseline_output_pre_df.filter(combined_filter)

        baseline_output_pre_df = baseline_output_pre_df.groupBy(
            "wdate", "Iteration_Number", "modelling_cluster"
        ).pivot("variable").agg(
            F.first("value")
        )

        # Marketing columns
        marketing_contribution_col = get_marketing_contribution_column(
            baseline_output_pre_df.columns,
            marketing_variables_list
        )

        # Rename specific variables that coincide with key metrics such as sales, baseline, seasonality
        baseline_output_pre_df = (
            baseline_output_pre_df
            .withColumnRenamed("level_base", "total_baseline")
            .withColumnRenamed("nec_sal_tot_xxx_xxx_xxx_sls", "sales")
            .withColumnRenamed("nec_tot_tot_tot_tot_tot_sea", "total_seasonality")
            .withColumnRenamed("wdate", "week_start_date")
            .withColumn(
                "marketing_contribution",
                marketing_contribution_col
            )
            .withColumn(
                "total_baseline",
                F.coalesce(F.col("sales"), F.lit(0.0)) - F.col("marketing_contribution")
            )
        )

        # If no seasonality column, add it with 0 values to prevent errors
        if "total_seasonality" not in baseline_output_pre_df.columns:
            baseline_output_pre_df = baseline_output_pre_df.withColumn("total_seasonality", F.lit(0))

        # Split modelling cluster into components (super_cat, brand, cluster_no)
        baseline_output_pre_df = modelling_cluster_split(baseline_output_pre_df)
        baseline_output_pre_df = baseline_output_pre_df.drop("modelling_cluster")

        # Calculate the incremental, which is the true sales - predicted baseline sales
        baseline_output_pre_df = baseline_output_pre_df.withColumnRenamed(
            "marketing_contribution", "incremental"
        )

        baseline_output_pre_df = baseline_output_pre_df.withColumn("job_id", F.lit(""))

        # Select and reorder final columns
        baseline_output_pre_df = (
            baseline_output_pre_df
            .select(
                "week_start_date",
                "super_category_name",
                "unique_brand",
                "cluster_no",
                "sales",
                "total_baseline",
                "incremental",
                "total_seasonality",
                "Iteration_Number",
                "job_id"
            )
        )

    return baseline_output_pre_df


def prepare_baseline_intermediate_data(
        baseline_intermediate_output_pre_df: DataFrame,
        baseline_output_pre_df: DataFrame,
        baseline_output_df: DataFrame,
        constant_sigma2: str,
        constant_frequency: str
) -> Tuple[DataFrame, DataFrame, DataFrame]:
    """
    Prepares intermediate baseline output data for parsing by grouping aggregated data and creating keys to join on

    This helper function performs the initial data preparation steps for converting the raw UCM model outputs
    into the standardized baseline intermediate output format.

    Args:
        baseline_intermediate_output_pre_df (DataFrame): Raw intermediate output containing variable estimates
            and statistics from UCM model with columns like 'variable_apl', 'estimate', 'pvalue'.
        baseline_output_pre_df (DataFrame): Raw baseline output with variable contributions containing
            'modelling_cluster', 'Iteration_Number', 'variable', 'value' columns.
        baseline_output_df (DataFrame): Parsed baseline output with sales totals containing
            'super_category_name', 'unique_brand', 'cluster_no', 'sales', 'total_baseline' columns.
        constant_sigma2 (str): String constant used to identify and clean sigma2 parameters from variable names.
        constant_frequency (str): String constant used to identify and clean frequency parameters from variable names.

    Returns:
        Tuple[DataFrame, DataFrame, DataFrame]: A tuple containing:
            - baseline_intermediate_output_pre_df: Enhanced with modelling cluster components and variable_merge_key
              for joining with contribution data
            - baseline_output_pre_grouped_df: Aggregated variable contributions grouped by cluster, iteration, and variable
            - baseline_output_grouped_df: Aggregated sales and baseline totals grouped by cluster and iteration
    """

    baseline_output_pre_grouped_df = (
        baseline_output_pre_df.groupBy("modelling_cluster", "Iteration_Number", "variable")
        .agg(F.sum("value").alias("value"))
    )

    baseline_output_grouped_df = (
        baseline_output_df.groupBy("super_category_name", "unique_brand", "cluster_no", "Iteration_Number")
        .agg(
            F.sum("sales").alias("sales"),
            F.sum("total_baseline").alias("total_baseline")
        )
    )

    # Split modelling_cluster into super_cat, brand, cluster_num
    baseline_intermediate_output_pre_df = modelling_cluster_split(baseline_intermediate_output_pre_df)

    # Create variable_merge_key to join on later depending on the type of input variable from the ucm base data (e.g. remove structural ucm components, keep predictors and variables)
    baseline_intermediate_output_pre_df = (
        baseline_intermediate_output_pre_df
        .withColumn(
            "variable_merge_key",
            F.when(F.col("variable_apl").contains("beta."),
                   F.regexp_replace("variable_apl", "beta.", ""))
            .otherwise(F.lit(""))
        )
    )

    baseline_intermediate_output_pre_df = (
        baseline_intermediate_output_pre_df
        .withColumn(
            "variable_merge_key",
            F.when(F.col("variable_apl").contains(constant_sigma2),
                   F.regexp_replace("variable_apl", constant_sigma2, ""))
            .otherwise(F.col("variable_merge_key"))
        )
    )

    baseline_intermediate_output_pre_df = (
        baseline_intermediate_output_pre_df
        .withColumn(
            "variable_merge_key",
            F.when(F.col("variable_apl").contains(constant_frequency),
                   F.regexp_replace("variable_apl", constant_frequency, ""))
            .otherwise(F.col("variable_merge_key"))
        )
    )

    return baseline_intermediate_output_pre_df, baseline_output_pre_grouped_df, baseline_output_grouped_df


def merge_estimates_with_contributions(
        baseline_intermediate_output_pre_df: DataFrame,
        baseline_output_pre_grouped_df: DataFrame,
        baseline_output_grouped_df: DataFrame
) -> DataFrame:
    """
    Merges UCM model estimates with variable contributions and calculates contribution proportions.

    This helper function combines variable estimates (coefficients, p-values) from the UCM model
    with their corresponding variable contributions, then calculates the percentage contribution
    of each variable to total sales for the baseline intermediate output.

    Args:
        baseline_intermediate_output_pre_df (DataFrame): Enhanced intermediate output with variable
            estimates containing 'variable_merge_key', 'estimate', 'pvalue_zdist', 'approx_std_err'.
        baseline_output_pre_grouped_df (DataFrame): Aggregated variable contributions grouped by
            cluster, iteration, and variable with 'modelling_cluster', 'Iteration_Number', 'variable', 'value'.
        baseline_output_grouped_df (DataFrame): Aggregated sales totals grouped by cluster and iteration
            with 'super_category_name', 'unique_brand', 'cluster_no', 'sales', 'total_baseline'.

    Returns:
        DataFrame: Combined dataset with variable estimates, contributions, and contribution proportions

    """

    pre_df = baseline_intermediate_output_pre_df.withColumnRenamed("variable_merge_key", "variable")

    # Join aggregated contributions with variable estimates
    intermediate_output = (
        pre_df
        .join(
            baseline_output_pre_grouped_df,
            on=["modelling_cluster", "Iteration_Number", "variable"],
            how="inner"
        )
    )

    drop_cols = ["modelling_cluster", "approx_std_err", "zvalue"]
    intermediate_output = intermediate_output.drop(*drop_cols)

    intermediate_output = (
        intermediate_output
        .withColumnRenamed("estimate", "estimates")
        .withColumnRenamed("pvalue_zdist", "pvalue")
        .withColumnRenamed("value", "contribution")
    )

    # Add incremental to grouped sales and add it to the intermediate output
    baseline_output_grouped_df = (
        baseline_output_grouped_df
        .withColumn("incremental", F.col("sales") - F.col("total_baseline"))
    )

    intermediate_output = (
        intermediate_output
        .join(
            baseline_output_grouped_df,
            on=["super_category_name", "unique_brand", "cluster_no", "Iteration_Number"],
            how="left"
        )
    )

    # Contribution proportion excluding level and cycle components
    intermediate_output = (
        intermediate_output
        .withColumn(
            "contribution_proportion",
            (F.col("contribution") / F.col("sales")) * F.lit(100.0)
        )
        .withColumn(
            "contribution_proportion",
            F.when(F.col("variable").isin(["level", "cycle"]), F.lit(None))
            .otherwise(F.col("contribution_proportion"))
        )
    )

    intermediate_output = (
        intermediate_output
        .drop("sales", "total_baseline", "incremental")
        .withColumn("job_id", F.lit(""))
    )

    return intermediate_output


def baseline_intermediate_output_parser(
        baseline_intermediate_output_pre_df: DataFrame,
        baseline_output_pre_df: DataFrame,
        baseline_output_df: DataFrame,
) -> DataFrame:
    """
    Converts raw UCM intermediate outputs into standardized baseline intermediate format.

    This parser function orchestrates the transformation of UCM model statistics and variable
    contributions into the final baseline intermediate output format required by downstream
    processes. It combines variable estimates, p-values, and contribution metrics into a
    standardized dataset for analysis and reporting.

    Args:
        baseline_intermediate_output_pre_df (DataFrame): Raw intermediate output containing UCM
            variable estimates and statistics with columns 'variable_apl', 'estimate', 'pvalue_zdist'.
        baseline_output_pre_df (DataFrame): Raw baseline output with variable contributions containing
            'modelling_cluster', 'Iteration_Number', 'variable', 'value' columns.
        baseline_output_df (DataFrame): Parsed baseline output with weekly sales data containing
            'super_category_name', 'unique_brand', 'cluster_no', 'sales', 'total_baseline' columns.

    Returns:
        DataFrame: Standardized baseline intermediate output with columns: 'super_category_name',
            'unique_brand', 'cluster_no', 'variable', 'estimates', 'pvalue', 'contribution',
            'contribution_proportion', 'Iteration_Number', 'job_id'. Returns empty DataFrame
            if no baseline output data exists.

    Objective:
        Creates the final baseline intermediate output by merging UCM model estimates with variable
        contributions and calculating contribution proportions. This output provides detailed
        variable-level insights for model interpretation and validation.


    Business Context:
        The intermediate output enables stakeholders to understand which variables drive model
        predictions and their relative importance, supporting model validation and business insights.
    """
    constant_sigma2 = "sigma2."
    constant_frequency = "frequency."

    if baseline_output_pre_df.take(1):
        # Create join keys and aggregate grouped data
        baseline_intermediate_output_pre_df, baseline_output_pre_grouped_df, baseline_output_grouped_df = prepare_baseline_intermediate_data(
            baseline_intermediate_output_pre_df,
            baseline_output_pre_df,
            baseline_output_df,
            constant_sigma2,
            constant_frequency
        )

        baseline_intermediate_output_pre_df = merge_estimates_with_contributions(
            baseline_intermediate_output_pre_df,
            baseline_output_pre_grouped_df,
            baseline_output_grouped_df
        )

        baseline_intermediate_output_pre_df = baseline_intermediate_output_pre_df.select(
            "super_category_name", "unique_brand", "cluster_no",
            "variable", "estimates", "pvalue", "contribution",
            "contribution_proportion", "Iteration_Number", "job_id"
        )

    return baseline_intermediate_output_pre_df


def add_best_iteration_flag(
        best_iteration_df: DataFrame,
        baseline_output_df: DataFrame
) -> Tuple[DataFrame, DataFrame]:
    """
    Flags best iterations in baseline output data for downstream MTA integration.

    This helper function adds the best iteration flag to identify which UCM model iterations
    were selected as optimal for each cluster. The flag is used by downstream MTA and Baseline processes
    to filter and process the best baseline predictions.

    Args:
        best_iteration_df (DataFrame): Selected best iterations containing cluster identifiers
            and iteration numbers
        baseline_output_df (DataFrame): Parsed baseline output or intermediate output with weekly sales predictions

    Returns:
        Tuple[DataFrame, DataFrame]: A tuple containing:
            - best_iteration_df: Enhanced with 'best_iteration_flag' column set to 'Y'
            - baseline_output_df: Enhanced with 'best_iteration_flag' column where 'Y' indicates
              the best iteration for each cluster and 'N' for all other iterations
    """

    # Add flag to best_iteration_df to show which is the best iteration
    best_iteration_df = best_iteration_df.withColumn("best_iteration_flag", F.lit("Y"))

    # Join the best iteration flag to the baseline output, this is the data will join on in the MTA integration
    baseline_output_df = (
        baseline_output_df
        .join(
            F.broadcast(
                best_iteration_df
                .select(
                    "unique_brand",
                    "super_category_name",
                    "Iteration_Number",
                    "cluster_no",
                    "best_iteration_flag"
                )
            ),
            on=["unique_brand", "super_category_name", "Iteration_Number", "cluster_no"],
            how="left"
        )
        .withColumn(
            "best_iteration_flag",
            F.coalesce(F.col("best_iteration_flag"), F.lit("N"))
        )
    )

    return best_iteration_df, baseline_output_df


def standardise_baseline_outputs_to_long_format(
        baseline_output_df: DataFrame,
        baseline_intermediate_output_df: DataFrame
) -> Tuple[DataFrame, DataFrame]:
    """
    Parse iteration name and rename columns in Baseline Output & Intermediate Output
    """
    # Select only required columns from intermediate
    baseline_intermediate_output_df = baseline_intermediate_output_df.select(
        "super_category_name", "unique_brand", "cluster_no", "variable",
        "estimates", "pvalue", "contribution", "contribution_proportion",
        "Iteration_Number", "job_id", "best_iteration_flag"
    )

    # Rename columns to match the expected final output in DBT
    baseline_output_df = baseline_output_df.select(
        F.col("week_start_date").alias("week_start_dt"),
        F.col("super_category_name"),
        F.col("unique_brand").alias("unique_brand_name"),
        F.col("cluster_no").alias("cluster_num"),
        F.col("sales").cast(T.DoubleType()).alias("total_sales_amt"),
        F.col("total_baseline").cast(T.DoubleType()).alias("total_baseline_amt"),
        F.col("incremental").cast(T.DoubleType()).alias("total_incremental_amt"),
        F.col("total_seasonality").cast(T.DoubleType()).alias("total_seasonality_amt"),
        F.col("Iteration_Number").alias("iteration"),
        F.lit("baseline_modelling").alias("modelling_type"),
        F.col("job_id").alias("job_run_id"),
        F.col("best_iteration_flag").alias("best_iteration")
    )

    try:
        baseline_output_df = (
            baseline_output_df
            .selectExpr(
                "week_start_dt",
                "super_category_name",
                "unique_brand_name",
                "cluster_num",
                "iteration",
                "modelling_type",
                "job_run_id",
                "best_iteration",
                """stack(4,
                    'TOTAL_SALES_AMT', total_sales_amt,
                    'TOTAL_BASELINE_AMT', total_baseline_amt,
                    'TOTAL_INCREMENTAL_AMT', total_incremental_amt,
                    'TOTAL_SEASONALITY_AMT', total_seasonality_amt
                ) as (metric_name, metric_value)"""
            )
        )
    except Exception as e:
        raise RuntimeError(f"Failed to transform baseline output to long format: {str(e)}")

    return baseline_output_df, baseline_intermediate_output_df


def baseline_output_creation_helper_4(baseline_intermediate_output_df, master):
    """
    Filters out UCM time series components and prepares master metadata for later use,
    to merge with baseline intermediate output.

    This function removes structural UCM components (level, cycle) from the intermediate output
    to retain only predictive modeling variables, whilst preparing the master
    dataset metadata for downstream variable enrichment and categorization

    Args:
        baseline_intermediate_output_df (DataFrame): Baseline intermediate output containing
            variable estimates and contributions with columns 'variable', 'estimates', 'pvalue',
            'contribution', 'contribution_proportion'.
        master (DataFrame): Master analytical dataset containing variable metadata with columns
            'variable', 'marketing_type', 'marketing_channel', 'marketing_sub_channel', 'metric'.

    Returns:
        Tuple[DataFrame, DataFrame]: A tuple containing:
            - baseline_intermediate_output_df: Filtered to exclude UCM structural components,
              containing only predictive modeling variables for business interpretation
            - master: Deduplicated metadata with standardized lowercase variable names ready
              for joining with intermediate output for variable categorization
    """

    baseline_intermediate_output_df = (
        baseline_intermediate_output_df
        .filter(
            ~F.col("variable").isin(["level", "cycle"])
        )
    )
    # We have to drop duplicates since we ignore the time component
    master = (
        master
        .select(
            "variable",
            "marketing_type",
            "marketing_channel",
            "marketing_sub_channel",
            "metric"
        )
        .dropDuplicates()
        .withColumn("variable", F.lower(F.col("variable")))
    )

    return baseline_intermediate_output_df, master


def baseline_output_creation_helper_5(
        baseline_intermediate_output_df: DataFrame,
        master: DataFrame
) -> Tuple[DataFrame, DataFrame]:

    baseline_intermediate_output_df = (
        baseline_intermediate_output_df
        .join(master, on=["variable"], how="left")
    )

    baseline_intermediate_output_df = (
        baseline_intermediate_output_df
        .select(
            F.col("super_category_name"),
            F.col("unique_brand").alias("unique_brand_name"),
            F.col("cluster_no").alias("cluster_num"),
            F.col("variable").alias("variable_cd"),
            F.col("job_id").alias("job_run_id"),
            F.col("pvalue").alias("p_value"),
            F.col("marketing_type").alias("marketing_type_name"),
            F.col("marketing_channel").alias("marketing_channel_name"),
            F.col("marketing_sub_channel").alias("marketing_sub_channel_name"),
            F.col("metric").alias("metric_name"),
            F.col("best_iteration_flag").alias("best_iteration"),
            "estimates",
            "contribution",
            "contribution_proportion",
            "Iteration_Number",
            "variable_backup"
        )
    )

    return baseline_intermediate_output_df, master


def select_columns_baseline_intermediate_output(
        baseline_intermediate_output_df: DataFrame
) -> DataFrame:
    """
    Args:
       baseline_intermediate_output_df (DataFrame): Contains outputs from model of each variable required format
    Returns:
        baseline_intermediate_output_df (DataFrame): Contains outputs from model of each variable required format
    """
    # Replace NaN with empty string for string columns
    baseline_intermediate_output_df = baseline_intermediate_output_df.fillna("")

    baseline_intermediate_output_df = baseline_intermediate_output_df.select(
        "super_category_name",
        "unique_brand_name",
        "cluster_num",
        "variable_cd",
        "estimates",
        "p_value",
        "contribution",
        "contribution_proportion",
        "Iteration_Number",
        "job_run_id",
        "marketing_type_name",
        "marketing_channel_name",
        "marketing_sub_channel_name",
        "metric_name",
        "best_iteration"
    )

    return baseline_intermediate_output_df


def baseline_output_creation(
        fin_summary_df: DataFrame,
        base_data_fixed_df: DataFrame,
        base_data_df: DataFrame,
        best_iteration_df: DataFrame,
        master: DataFrame,
        marketing_variables_list: list
) -> Tuple[DataFrame, DataFrame]:
    """
    Function used to convert and collate raw Baseline Outputs into required data pipeline outputs

    Objective:
        BASELINE_MODELLING_INTERMEDIATE_OUTPUT and BASELINE_MODELLING_OUTPUT tables
        are created in this call using raw outputs from the model.
        These are used in Forecasting and Baseline MTA integration.
        We need to clean and reformt the raw outputs of the UCM into it's
        component parts and then reassemble them into the required format.

    Args:
        fin_summary_df (pyspark.DataFrame): Contains outputs from model of each variable
        base_data_fixed_df (pyspark.DataFrame): Contains contributions of variables to sales with external effects combined with baseline
        base_data_df (pyspark.DataFrame): Contains raw contributions of variables to sales
        best_iteration_df (pyspark.DataFrame): Contains certain model metrics for best iteration
        master (pyspark.DataFrame): Contains Analytical Dataset
        marketing_variables_list (list): List of marketing variables to identify which variables in the outputs are marketing levers

    Returns:
        baseline_output_df (pyspark.DataFrame): Contains contributions of variables to sales with external effects combined with baseline formatted in required format
        baseline_intermediate_output_df (pyspark.DataFrame): Contains outputs from model of each variable required format
    """

    # Parsing baseline Output into required format
    baseline_output_df = baseline_output_parser(base_data_fixed_df, marketing_variables_list)
    best_iteration_df, baseline_output_df = add_best_iteration_flag(best_iteration_df, baseline_output_df)

    # Parsing Intermediate Outputs into required format
    baseline_intermediate_output_df = baseline_intermediate_output_parser(
        fin_summary_df,
        base_data_df,
        baseline_output_df
    )
    best_iteration_df, baseline_intermediate_output_df = add_best_iteration_flag(best_iteration_df, baseline_intermediate_output_df)

    if baseline_output_df.take(1):

        # Parsing iteration name for readability and cleaning variable_apl column into a standard format
        baseline_output_df = parse_iteration_name(baseline_output_df, "Iteration_Number")
        baseline_intermediate_output_df = parse_iteration_name(baseline_intermediate_output_df, "Iteration_Number")
        baseline_intermediate_output_df = clean_variable_apl(baseline_intermediate_output_df, "Iteration_Number")

        # Formating then melting baseline output to long format
        baseline_output_df, baseline_intermediate_output_df = standardise_baseline_outputs_to_long_format(
            baseline_output_df,
            baseline_intermediate_output_df
        )

        # Removing Time Series Components and leaving only Modelling variables
        baseline_intermediate_output_df, master = baseline_output_creation_helper_4(
            baseline_intermediate_output_df,
            master
        )

        # Backup of variable names
        baseline_intermediate_output_df = baseline_intermediate_output_df.withColumn(
            "variable_backup", F.col("variable")
        )

        # Restore split variable names introduced if we ran ucm_pass_no = set_2
        master = fix_split_variable_name(master, "variable")
        baseline_intermediate_output_df = fix_split_variable_name(baseline_intermediate_output_df, "variable")

        baseline_intermediate_output_df, master = baseline_output_creation_helper_5(
            baseline_intermediate_output_df,
            master
        )

        # Restore split variable names introduced if we ran ucm_pass_no = set_2 retaining which year they belong to
        baseline_intermediate_output_df = fix_split_variable_name(
            baseline_intermediate_output_df, "variable_backup", "2"
        )

        # Restore original variable names
        baseline_intermediate_output_df = baseline_intermediate_output_df.withColumn(
            "variable_cd", F.col("variable_backup")
        ).drop("variable_backup")

        # Add ADS Hierarchy for Dummy Variables
        baseline_intermediate_output_df = fix_control_variable_hierarchy(baseline_intermediate_output_df)
        baseline_intermediate_output_df = select_columns_baseline_intermediate_output(baseline_intermediate_output_df)

    return baseline_output_df, baseline_intermediate_output_df


def recalibrate_baseline(
        baseline_modelling_output: DataFrame,
        final_best_iteration_df: DataFrame,
        config: Dict[str, Dict[str, Any]]
) -> DataFrame:
    """
    Set baseline sales to actual sales for clusters failing statistical thresholds

    Objective:
        Edge case handling, in case a function does not meet basic statistical requirements, we do not report any incremental
        and cap the baseline sales.

    Used In:
        main function at the end of modelling process

    Business Context: Function is used to assign 0 incremental to cases where a baseline does not meet statistical requirements
    (currently given by ucm_lowest_permissible_rsq at 70% minimum Rsq and ucm_highest_permissible_wsmape at 20% maximum WSMAPE parameters in the config).
    This is to ensure that incremental is not reported in case our models are not statistically sound.

    Args:
        baseline_modelling_output (DataFrame): Contains Final Baseline Sales and Actual Sales
        final_best_iteration_df (DataFrame): Contains model stats of best iteration
        config (Dict): Dictionary containing input configuration parameters

    Returns:
        baseline_modelling_output_new (DataFrame): Contains Final Baseline Sales and Actual Sales with adjustment
    """

    highest_permissible_wsmape = config["DEFAULT"]["highest_permissible_wsmape"]
    least_permissible_rsq = config["DEFAULT"]["least_permissible_rsq"]

    # filter clusters failing thresholds and flag them for recalibration
    recalibrate_clusters = (
        final_best_iteration_df
        .filter(
            (F.col("wsmape") > highest_permissible_wsmape) &
            (F.col("rsq") < least_permissible_rsq)
        )
        .select("modelling_cluster")
        .distinct()
        .withColumn("flag_recalibrate", F.lit(1))
    )

    # create modelling_cluster key
    baseline_modelling_output = (
        baseline_modelling_output
        .withColumn(
            "modelling_cluster",
            F.concat_ws(
                "~",
                F.col("unique_brand_name"),
                F.col("super_category_name"),
                F.col("cluster_num")
            )
        )
    )

    pivoted = (
        baseline_modelling_output
        .groupBy(
            "week_start_dt", "unique_brand_name", "super_category_name", "cluster_num",
            "iteration", "best_iteration", "job_run_id", "modelling_type", "modelling_cluster"
        )
        .pivot("metric_name")
        .agg(F.first("metric_value"))
    )

    # join recalibration flags
    pivoted = pivoted.join(recalibrate_clusters, on="modelling_cluster", how="left")

    # adjust baseline if flagged + best_iteration = Y
    pivoted = pivoted.withColumn(
        "TOTAL_BASELINE_AMT",
        F.when(
            (F.col("best_iteration") == "y") & (F.col("flag_recalibrate") == 1),
            F.col("TOTAL_SALES_AMT")
        ).otherwise(F.col("TOTAL_BASELINE_AMT"))
    )

    # drop helper cols
    pivoted = pivoted.drop("modelling_cluster", "flag_recalibrate")

    # Select the metrics in upper case since we do list operations in the pivot to long
    metric_cols = ["TOTAL_SALES_AMT", "TOTAL_BASELINE_AMT", "TOTAL_INCREMENTAL_AMT", "TOTAL_SEASONALITY_AMT"]

    id_cols = ["week_start_dt", "unique_brand_name", "super_category_name", "cluster_num",
               "iteration", "best_iteration", "job_run_id", "modelling_type"]

    melted = (
        pivoted.select(
            *id_cols,
            F.explode(
                F.array(*[
                    F.struct(F.lit(c).alias("metric_name"), F.col(c).alias("metric_value"))
                    for c in metric_cols if c in pivoted.columns
                ])
            ).alias("kv")
        )
        .select(
            *id_cols,
            F.col("kv.metric_name"),
            F.col("kv.metric_value")
        )
    )

    return melted


def calculate_unstd_marketing_contributions(ucm_base_data: DataFrame, config: BaselineModellingOutputConfig) -> DataFrame:
    """
    Aggregates the contributions of each marketing variable per modelling cluster and iteration, excluding external variables and structural components,
    to calculate the unstandardized marketing contribution. Then, it calculates the iROAS by dividing the unstandardized marketing contribution by the total media spend for each cluster and iteration.

    Args:
        ucm_base_data (DataFrame): UCM base data in long format (variable, value) with contributions of each feature per modelling cluster
        config (BaselineModellingOutputConfig): Configuration object containing patterns to identify marketing variables and external variables.

    Returns:
        DataFrame: Contains iROAS for each cluster and iteration.
    """
    marketing_contribution_unstd = (
        ucm_base_data
        .filter(
            (~F.lower(F.col("variable")).contains(config.external_variable_pattern)) &
            (F.lower(F.col("variable")).rlike(config.marketing_variables_pattern))
        )
        .groupBy('modelling_cluster', 'Iteration_Number', 'total_media_spend')
        .agg(F.sum(F.col('value')).alias('marketing_contribution_unstd'))
        .withColumn(
            "iroas",
            F.col("marketing_contribution_unstd") / F.col("total_media_spend")
        )
        .select(
            "modelling_cluster",
            "Iteration_Number",
            "iroas"
        )
    )

    return marketing_contribution_unstd


def combine_penalty_metrics_and_contributions(
    rsq_mape_pen_df: DataFrame,
    pval_penalisation_df: DataFrame,
    marketing_contribution_unstd: DataFrame
) -> DataFrame:
    """
    Unifies different sources of model evaluation metrics and contributions into a single DataFrame for
    best model selection using weighted scoring downstream.

    Args:
        rsq_mape_pen_df (DataFrame): DataFrame containing RSQ and WSMAPE penalties for each iteration and cluster.
        pval_penalisation_df (DataFrame): DataFrame containing p-value penalties for each variable, iteration, and cluster.
        marketing_contribution_unstd (DataFrame): DataFrame containing iROAS for each iteration and cluster.
    Returns:
        DataFrame: A unified DataFrame that combines all the input metrics and contributions, with calculated fields for standardized sales value and marketing contribution to sales ratio.
    """

    # Spark struggles to disambiguate the columns automatically since the plan is complex, so we rename the columns to remove any ambiguity before joining for safety

    pval_renamed = (
        pval_penalisation_df
        .withColumnRenamed("modelling_cluster", "pval_modelling_cluster")
        .withColumnRenamed("Iteration_Number", "pval_Iteration_Number")
    )

    joined_df = (
        rsq_mape_pen_df
        .join(
            pval_renamed,
            (F.col("modelling_cluster") == F.col("pval_modelling_cluster")) &
            (F.col("Iteration_Number") == F.col("pval_Iteration_Number")),
            how="left"
        )
        .select(
            # Left side
            "modelling_cluster",
            "Iteration_Number",
            "penalisation_rsq",
            "penalisation_wsmape",
            "rsq",
            "wsmape",
            # Right side
            "penalisation_pval"
        )
    )

    mkt_renamed = (
        marketing_contribution_unstd
        .withColumnRenamed("modelling_cluster", "mkt_modelling_cluster")
        .withColumnRenamed("Iteration_Number", "mkt_Iteration_Number")
    )

    final_df = (
        joined_df
        .join(
            mkt_renamed,
            (F.col("modelling_cluster") == F.col("mkt_modelling_cluster")) &
            (F.col("Iteration_Number") == F.col("mkt_Iteration_Number")),
            how="left"
        )
        .select(
            # Left side
            "modelling_cluster",
            "Iteration_Number",
            "penalisation_rsq",
            "penalisation_wsmape",
            "rsq",
            "wsmape",
            "penalisation_pval",
            # Right side
            "iroas"
        )
        .fillna({"iroas": 0})
    )

    return final_df


def calculate_iroas_penalty(model_metrics_df: DataFrame) -> DataFrame:
    """
    Calculates a penalty score based on iROAS values to be used in the model selection process.

    The penalty is designed to reflect the desirability of different iROAS outcomes:
        - Negative iROAS indicates that the marketing spend is generating negative returns, which is undesirable and should incur a high scaled penalty,
            with a fixed value so even small negative iROAS values are penalised but the penalty increases as iROAS becomes more negative.
        - An iROAS of zero indicates that the marketing spend is generating no returns, which is also undesirable and should incur a high fixed penalty.
        - Positive iROAS values up to a reasonable threshold (e.g., 10) indicate that the marketing spend is generating returns, which is desirable and should not incur a penalty.
        - Extremely high iROAS values (e.g., above 10) may indicate unrealistic model behavior or overfitting, which should incur an increasing penalty as the iROAS value grows further beyond the threshold which is 10

    Args:
        model_metrics_df (DataFrame): DataFrame containing model metrics for each iteration, including iROAS values.

    Returns:
        DataFrame: The input DataFrame augmented with a new column 'penalisation_iroas' representing the calculated penalty based on iROAS values, and a flag 'iteration_not_found' indicating whether the iteration failed based on negative iROAS.
    """

    # ToDo make this penalty values configurable
    model_metrics_df = (
        model_metrics_df
        .withColumn(
            "iteration_not_found",
            F.when(
                F.col("iroas") < 0,
                F.lit(True)
            )
            .otherwise(F.lit(False))
        )
        .withColumn(
            "penalisation_iroas",
            F.when(
                F.col("iroas") < 0,
                F.pow(F.abs(F.col("iroas")) / 10, 2) + F.lit(3.0)
            )
            .when(
                F.col("iroas") == 0,
                F.lit(2.0)
            )
            .when(
                (F.col("iroas") > 0) & (F.col("iroas") <= 10),
                F.lit(0.0)
            )
            .otherwise(
                F.pow((F.col("iroas") - 10) / 10, 2)
            )
        )
        .select(
            "modelling_cluster",
            "Iteration_Number",
            "penalisation_rsq",
            "penalisation_wsmape",
            "penalisation_iroas",
            "penalisation_pval",
            "rsq",
            "wsmape",
            "iteration_not_found"
        )
    )

    return model_metrics_df


def rank_and_select_best_iterations(
        model_metrics_df: DataFrame,
        config: BaselineModellingOutputConfig
) -> DataFrame:
    """
    Ranks and selects the best iterations based on a penalty-based scoring approach that combines multiple model selection criteria.

    This function calculates penalties for p-values, model fit metrics (RSQ, WSMAPE), and iROAS, then combines these penalties using weighted scoring to rank iterations.
    The iteration with the lowest total penalty is selected as the best iteration for each cluster.

    Args:
        model_metrics_df (DataFrame): DataFrame containing model metrics for each iteration, including p-values, RSQ, WSMAPE, and iROAS values.
        config (BaselineModellingOutputConfig): Configuration object containing weights for each selection criterion (p-value, RSQ, WSMAPE, iROAS)

    Returns:
        DataFrame: DataFrame containing the best iteration for each cluster based on the lowest total penalty,
    """

    # Calculate the total penalty for each iteration based on the weighted sum of the different selection criteria
    weighted_scores_df = (
        model_metrics_df
        .withColumn(
            "total_penalty",
            F.round(
                config.weight_pvalue * F.coalesce(F.col("penalisation_pval"), F.lit(0.0)) +
                config.weight_rsq * F.col("penalisation_rsq") +
                config.weight_wsmape * F.col("penalisation_wsmape") +
                config.weight_iroas * F.col("penalisation_iroas"),
                8
            )
        )
    )

    # Rank iterations by penalty within each cluster
    window_penalty = Window.partitionBy("modelling_cluster").orderBy(
        F.col("total_penalty").asc(),
        F.col("Iteration_Number").asc()
    )

    weighted_scores_df = (
        weighted_scores_df
        .withColumn(
            "penalty_rank",
            F.dense_rank().over(window_penalty)
        )
    )

    # Keep only top-ranked iteration mirroring previous implementation
    best_iteration_df = (
        weighted_scores_df
        .filter(F.col("penalty_rank") == 1)
    )

    return best_iteration_df


def best_iteration_picker_penalty_based(
        master_dataset: DataFrame,
        final_model_summary_df: DataFrame,
        model_metrics_df: DataFrame,
        ucm_base_long: DataFrame,
        campaign_selection_df: DataFrame
) -> Tuple[DataFrame, DataFrame]:
    """
    Selects the best iteration using a penalty-based scoring approach

    This function implements an improved model selection logic that:
    1. Calculates penalties for p-values (penalisation_pval)
    2. Calculates penalties for model fit metrics (RSQ, WSMAPE)
    3. Calculates penalties based on iROAS (incremental Return on Ad Spend)
    4. Combines penalties using weighted scoring
    5. Selects the iteration with the lowest total penalty

    Arg names reflect their conventions in the codebase and then the names used in
    this function reflect their corresponding final output names in s3

    Args:
        master_dataset (DataFrame): Master dataset containing variable metadata for filtering and joining
        final_model_summary_df (DataFrame): Model variable outputs with estimates and p-values to determine significance and calculate p-value penalties
        model_metrics_df (DataFrame): Iteration metrics (RSQ, WSMAPE, etc.)
        ucm_base_long (DataFrame): UCM base data in long format (variable, value) with contributions of each feature, including model outputs like level, trend etc., used to calculate iROAS
        campaign_selection_df (DataFrame): Campaign selection data with total_media_spend

    Returns:
        Tuple:
            - incremental_check_bool_df (DataFrame): Boolean flags for clusters needing re-evaluation
            - best_iteration_df (DataFrame): Best iteration selected per cluster
    """
    # Get the iteration selection config parameters
    # ToDo pass this in instead of creating a local copy
    config = BaselineModellingOutputConfig()

    # Get campaign details to use in the iroas calculations and filtering
    campaign_details = get_campaign_details(master_dataset, campaign_selection_df)
    ucm_base_data = filter_by_campaign_bounds(ucm_base_long, campaign_details)

    # Strip the beta prefix so they match with variable names in the base data later
    final_model_summary_df = (
        final_model_summary_df
        .withColumn("variable_no_beta", F.regexp_replace("variable_apl", config.beta_prefix_pattern, ""))
        .select(
            "modelling_cluster",
            "Iteration_Number",
            "variable_apl",
            "estimate",
            "pvalue_zdist",
            "variable_no_beta"
        )
    )

    # Calculate marketing contribution (unstandardised)
    marketing_contribution_unstd = calculate_unstd_marketing_contributions(ucm_base_data, config)

    # Calculate p-value penalties
    pval_penalisation_df = (
        final_model_summary_df
        .withColumn(
            "penalisation_pval",
            F.when(F.col("pvalue_zdist") <= config.alpha, F.lit(0.0))
            .otherwise((F.col("pvalue_zdist") - config.alpha) / (1 - config.alpha))
        )
        .groupBy('modelling_cluster', 'Iteration_Number')
        .agg(F.avg(F.col('penalisation_pval')).alias('penalisation_pval'))
        .select(
            "modelling_cluster",
            "Iteration_Number",
            "penalisation_pval"
        )
    )

    # We need to persist the rsq and wsmape to mirror the previous logic where we ranked on rsq and wsmape to ensure the re-iterator function works later in the code
    rsq_mape_pen_df = (
        model_metrics_df
        .withColumn("penalisation_rsq", 1 - F.col("rsq"))
        .withColumn("penalisation_wsmape", F.col("wsmape"))
        .select(
            "modelling_cluster",
            "Iteration_Number",
            "penalisation_rsq",
            "penalisation_wsmape",
            "rsq",
            "wsmape"
        )
    )

    model_metrics_df = combine_penalty_metrics_and_contributions(
        rsq_mape_pen_df, pval_penalisation_df,
        marketing_contribution_unstd
    )

    model_metrics_df = calculate_iroas_penalty(model_metrics_df)

    best_iteration_df = rank_and_select_best_iterations(model_metrics_df, config)

    # Based on best iteration build a dataframe of modelling_clusters that no longer need to be run
    incremental_check_bool_df = (
        final_model_summary_df
        .select("modelling_cluster")
        .distinct()
        .join(
            best_iteration_df
            .select("modelling_cluster", "iteration_not_found"),
            on="modelling_cluster",
            how="left"
        )
        .withColumn(
            "iteration_not_found",
            F.coalesce(F.col("iteration_not_found"), F.lit(True))
        )
    )

    # ToDo maybe we want to save some of the penalty metrics for analysis purposes
    # Clean up temporary columns and persist ranking in case of multiple UCM passes so we can quickly indentify the best iteration without having to recalculate the penalties
    best_iteration_df = (
        best_iteration_df
        .select(
            "modelling_cluster",
            "Iteration_Number",
            "rsq",
            "wsmape",
            "total_penalty"
        )
    )

    return incremental_check_bool_df, best_iteration_df


def aggregate_pvalues_by_variable_type(final_model_summary_df: DataFrame) -> DataFrame:
    """
    Aggregates p-values from model summary into collapsed strings by variable type.

    This function separates variables into marketing and external categories, then
    concatenates their p-values into pipe-delimited strings for each modelling cluster
    and iteration combination.

    It is currently unused but can directly take the ucm_summary DataFrame as input and can be used
    for analysis purposes to understand the distribution of p-values across variable types and iterations.

    Args:
        final_model_summary_df (DataFrame): Model summary containing variables with their
            p-values, must include columns: variable_no_beta, pvalue_zdist, modelling_cluster,
            Iteration_Number

    Returns:
        DataFrame: Contains columns:
            - modelling_cluster: Cluster identifier
            - Iteration_Number: Model iteration number
            - pvalues_collapsed: Combined string of marketing & external p-values

    Business Context:
        Used in model evaluation to assess statistical significance across variable types.
        Marketing variables are identified by channel patterns (_ons_, _off_, _in-_, _tar_).
    """
    # Filter out frequency and sigma variables, then classify remaining variables
    classified_df = (
        final_model_summary_df
        .filter(~F.lower(F.col("variable_no_beta")).rlike("frequency|sigma"))
        .withColumn(
            "variable_type",
            F.when(
                F.lower(F.col("variable_no_beta")).rlike("_ons_|_off_|_in-_|_tar_"),
                F.lit("marketing")
            ).otherwise(F.lit("external"))
        )
        # Standardize p-value precision
        .withColumn("pvalue_zdist", F.col("pvalue_zdist").cast(T.DecimalType(20, 4)))
    )

    # Separate and aggregate marketing variables
    marketing_pvalues = (
        classified_df
        .filter(F.col("variable_type") == "marketing")
        .groupBy("modelling_cluster", "Iteration_Number")
        .agg(F.concat_ws("|", F.collect_list("pvalue_zdist")).alias("pvalues_collapsed_mar"))
    )

    # Separate and aggregate external variables
    external_pvalues = (
        classified_df
        .filter(F.col("variable_type") == "external")
        .groupBy("modelling_cluster", "Iteration_Number")
        .agg(F.concat_ws("|", F.collect_list("pvalue_zdist")).alias("pvalues_collapsed_ext"))
    )

    # Combine marketing and external p-values into single string
    result_df = (
        marketing_pvalues
        .join(external_pvalues, ["modelling_cluster", "Iteration_Number"], "inner")
        .withColumn(
            "pvalues_collapsed",
            F.concat_ws(" & ", F.col("pvalues_collapsed_mar"), F.col("pvalues_collapsed_ext"))
        )
        .select("modelling_cluster", "Iteration_Number", "pvalues_collapsed")
    )

    return result_df
