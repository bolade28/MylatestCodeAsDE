from pyspark.sql import functions as F, DataFrame
from pyspark.sql.window import Window

from typing import Dict, Any, Tuple

from spark_pipeline.common.variables import BaselineModellingOutputConfig
from spark_pipeline.schemas.baseline_modelling_output_ucm import BaselineModellingOutput


# ToDo this is very slighly different to the pandas version due to null checking (this contains all data from the pandas version but may have a few extra rows)
def seasonality_index_creator(master: DataFrame) -> DataFrame:
    """
    Identifies recurring peaks and dips in sales due to seasonality by comparing
    week-over-week percentage changes with the same period in future years.

    Args:
        master (DataFrame): Input DataFrame with sales data

    Returns:
        DataFrame: Long-format DataFrame with seasonality dummy variables and modelling metadata
    """
    config = BaselineModellingOutputConfig()

    group_cols = ["unique_brand", "super_category_name", "cluster"]
    w = Window.partitionBy(*group_cols).orderBy("week_date")

    # Compute week-over-week percent change in sales
    master = master.withColumn(
        "sales_pct_change",
        (F.col("value") - F.lag("value", 1).over(w)) / F.lag("value", 1).over(w)
    ).fillna({"sales_pct_change": 0})

    window_length = config.seasonality_index_window_length
    min_threshold = config.seasonality_index_min_threshold
    threshold_2 = config.seasonality_index_strict_threshold

    # Compare each change to similar weeks (3 week window) ~1 year later
    for i in range(window_length):
        shifted = F.lead("sales_pct_change", 51 + i).over(w)
        shifted_col = f"shifted_value_{i}"
        diff_col = f"shifted_valuediff_{i}"

        # Apply filter conditions

        # Ignore small changes
        condition_1 = F.when(
            (F.abs(shifted) < min_threshold) | (F.abs(F.col("sales_pct_change")) < min_threshold),
            F.lit(None)
        ).otherwise(shifted)
        # Ignore changes that are in opposite direction
        condition_2 = F.when(
            ((condition_1 < 0) & (F.col("sales_pct_change") > 0)) |
            ((condition_1 > 0) & (F.col("sales_pct_change") < 0)),
            F.lit(None)
        ).otherwise(condition_1)

        filtered = F.when(
            (F.abs(condition_2) < threshold_2) & (F.abs(F.col("sales_pct_change")) < threshold_2),
            F.lit(None)
        ).otherwise(condition_2)

        # Store filtered values and calculate difference with current week
        master = master.withColumn(shifted_col, filtered)
        master = master.withColumn(diff_col, F.abs(F.col("sales_pct_change") - F.col(shifted_col)))

    # Identify which shifted comparison was most similar
    diff_cols = [f"shifted_valuediff_{i}" for i in range(window_length)]

    master = master.withColumn(
        "min_column_idx",
        F.expr(f"array_position(array({','.join(diff_cols)}), array_min(array({','.join(diff_cols)}))) - 1")
    )
    master = master.withColumn(
        "min_column",
        F.when(F.col("min_column_idx") >= 0, F.col("min_column_idx").cast("string"))
    )
    # Flag seasonal peaks and dips
    master = master.withColumn(
        "seasonality_index_pea",
        F.when((F.col("sales_pct_change") > min_threshold) & F.col("min_column").isNotNull(), 1).otherwise(0)
    )
    master = master.withColumn(
        "seasonality_index_dip",
        F.when((F.col("sales_pct_change") < -min_threshold) & F.col("min_column").isNotNull(), 1).otherwise(0)
    )

    # Project seasonal pattern flags to future dates
    projected = (
        master
        .filter(F.col("min_column").isNotNull())
        .withColumn("min_column_int", F.col("min_column").cast("int"))
        .withColumn("future_date", F.expr("date_add(week_date, 7 * (51 + min_column_int))"))
    )

    pea_dates = (
        projected
        .filter(F.col("seasonality_index_pea") == 1)
        .select(
            *group_cols,
            F.col("future_date").alias("week_date"),
            F.lit(1).alias("future_pea")
        )
    )

    dip_dates = (
        projected
        .filter(F.col("seasonality_index_dip") == 1)
        .select(
            *group_cols,
            F.col("future_date").alias("week_date"),
            F.lit(1).alias("future_dip")
        )
    )

    # Join back projected patterns to original DataFrame
    master = (
        master
        .join(pea_dates, on=group_cols + ["week_date"], how="left")
        .join(dip_dates, on=group_cols + ["week_date"], how="left")
        .withColumn(
            "seasonality_index_pea",
            F.when(F.col("future_pea") == 1, 1).otherwise(F.col("seasonality_index_pea"))
        ).withColumn(
            "seasonality_index_dip",
            F.when(F.col("future_dip") == 1, 1).otherwise(F.col("seasonality_index_dip"))
        )
    )
    # Select relevant columns for the stack function
    out_cols = ["week_date", *group_cols, "seasonality_index_pea", "seasonality_index_dip"]
    master = master.select(*out_cols)

    # Convert to long format with variable and value columns
    master = master.selectExpr(
        "week_date", *group_cols,
        "stack(2, 'seasonality_index_pea', seasonality_index_pea, 'seasonality_index_dip', seasonality_index_dip) as (variable, value)"
    )
    # Add meta-data to the baseline modelling dataset
    master = (
        master
        .withColumn("marketing_type", F.lit(config.seasonality_index_name))
        .withColumn("marketing_channel", F.lit(config.seasonality_index_name))
        .withColumn("marketing_sub_channel", F.lit(config.seasonality_index_name))
        .withColumn("metric", F.lit(config.seasonality_index_name))
        .withColumn("primary_metric", F.lit(config.seasonality_primary_metric))
        .withColumn("investment_metric", F.lit(config.seasonality_investment_metric))
    )

    # Rename variables
    master = master.withColumn(
        "variable",
        F.when(F.col("variable") == "seasonality_index_pea", config.seasonality_index_pea_name)
        .when(F.col("variable") == "seasonality_index_dip", config.seasonality_index_dip_name)
        .otherwise(F.col("variable"))
    )
    # Remove all-zero variables per group
    non_zero_vars = (
        master
        .groupBy("unique_brand", "super_category_name", "cluster", "variable")
        .agg(F.max(F.when(F.col("value") != 0, 1).otherwise(0)).alias("has_nonzero"))
        .filter(F.col("has_nonzero") == 1)
        .select("unique_brand", "super_category_name", "cluster", "variable")
    )

    master = master.join(
        non_zero_vars,
        on=["unique_brand", "super_category_name", "cluster", "variable"],
        how="inner"
    )
    return master


def list_independent_ext_factors(df: DataFrame, config: Dict[str, Dict[str, Any]]) -> DataFrame:
    """
    Creates a DataFrame of distinct external variable names (lowercase),
    based on marketing type and metric filters from the config

    Args:
        df (DataFrame): The input dataset.
        config (Dict): Config dictionary

    Returns:
        DataFrame: Distinct lowercase variable names as a single-column DataFrame.
    """

    df = df.filter(F.col('primary_metric') == 'Y')

    ext_marketing_types = set(x.lower() for x in config["FP"]["external_marketing_type_names"])
    ext_metrics = set(x.lower() for x in config["FP"]["external_metric"])

    # Get's all the variables with external marketing types e.g. holidays
    by_type = (
        df
        .filter(
            F.lower(F.col("marketing_type")).isin(ext_marketing_types)
        )
        .select(F.lower(F.col("variable")).alias("variable")).distinct()
    )

    # Get's all the variables with external metrics e.g. base unit price
    by_metric = (
        df
        .filter(
            F.lower(F.col("metric")).isin(ext_metrics)
        )
        .select(F.lower(F.col("variable")).alias("variable")).distinct()
    )

    # ToDo remove the distinct call if not needed
    return by_type.union(by_metric).distinct()


def select_variable_percentile(master_df, config: Dict[str, Dict[str, Any]]) -> DataFrame:
    """
    Function to identify number of variables given required percentile of variables

    Objective:
        From Feature Prioritization output we want to select the top 20% of variables. However each cluster has different slightly different number of total variables
        depending on whether Value Index Data exists for the cluster etc. So we calculate the number of variables we need to select for UCM testing given a percentage
        using this function.

    Args:
        master_df (DataFrame): The input dataset containing weekly time series data for all marketing and non-marketing variables
        config (Dict): Config dictionary

    Returns:
        master (DataFrame): Contains the number of variables from the Feature Prioritization output for each modelling cluster that the will an input into UCM
    """

    # Retrieve required parameters
    percentile_of_vars = config["DEFAULT"]["proportion_of_ext_vars"] / 100

    external_marketing_types = [x.lower() for x in config["FP"]["external_marketing_type_names"]]
    external_metrics = [x.lower() for x in config["FP"]["external_metric"]]

    # Calculate total number of variables per modelling cluster
    ads_df = (
        master_df.groupBy("super_category_name", "unique_brand", "cluster")
        .agg(F.countDistinct("variable").alias("total_no_of_vars"))
    )

    # Filter for primary metric (one's that have been deemed important)
    primary_df = master_df.filter(F.col("primary_metric") == "Y")

    # Filter for external marketing type and total metrics
    external_marketing_df = primary_df.filter(F.lower(F.col("marketing_type")).isin(external_marketing_types))
    external_metric_df = primary_df.filter(F.lower(F.col("metric")).isin(external_metrics))

    external_df = external_marketing_df.unionByName(external_metric_df).dropDuplicates()

    # Group to get count of external vars per modelling cluster
    external_vars_df = (
        external_df.groupBy("super_category_name", "unique_brand", "cluster")
        .agg(F.countDistinct("variable").alias("no_of_vars"))
    )

    result_df = (
        ads_df.join(external_vars_df, on=["super_category_name", "unique_brand", "cluster"], how="left")
        .withColumn("no_of_vars", F.coalesce(F.col("no_of_vars"), F.lit(0)))
        .drop("total_no_of_vars")
    )

    # Determine external var count (external vars have the super category name TOTAL)
    external_var_count = (
        result_df.filter(F.col("super_category_name") == "TOTAL")
        .agg(F.max("no_of_vars"))
        .first()[0]
    )
    # Handle the null case
    external_var_count = external_var_count or 0

    # Get all the modelling clusters and calculate number of variables to select
    result_df = (
        result_df
        .filter(F.col("super_category_name") != "TOTAL")
        .withColumn(
            "no_of_vars",
            F.floor((F.col("no_of_vars") + F.lit(external_var_count)) * F.lit(percentile_of_vars))
        )
        .withColumnRenamed("unique_brand", "unique_brand_name")
        .withColumnRenamed("cluster", "cluster_num")
        .select("super_category_name", "unique_brand_name", "cluster_num", "no_of_vars")
    )

    return result_df


def get_marketing_variables(ads_df: DataFrame, config: Dict[str, Dict[str, Any]]) -> DataFrame:
    """
    Function to identify all three-letter codes of all marketing variables from modelling dataset

    Args:
        ads_df (pd.DataFrame): Contains the Analytical Dataset which contains all the weekly variable/metric data
        config (Dict): Contains the marketing type lists of channels we consider as incremental
    Returns:
        marketing_variables_list (List): Contains the three-letter codes for all marketing variables
        to be tested in the model
    """

    marketing_type_list = config['DEFAULT']['marketing_type_list']
    marketing_vars_df = ads_df.filter(F.col("marketing_type").isin(marketing_type_list))

    marketing_variable_df = (
        marketing_vars_df
        .withColumn("var_code", F.substring("variable", config["DEFAULT"]["var_len"] - 14, 7))
        .select("var_code")
        .distinct()
    )

    return marketing_variable_df


def get_negative_metrics(ads_df: DataFrame, config: Dict[str, Dict[str, Any]]) -> DataFrame:
    """
    Function to identify list of variables which are expected to have a negative impact on sales
    e.g. (increase in base price generally leads to a decrease in sales).

    Args:
        ads_df (pd.DataFrame): Contains the Analytical Dataset which contains all the weekly variable/metric data
        config (Dict): Contains the configuration parameters which are inputs to the model

    Returns:
        negative_variable_list (List): Contains the three letter codes for all variables expected to have negative impact on sales
    """
    negative_metric_list = config['DEFAULT']['negative_metric_names']

    negative_variable_df = (
        ads_df
        .filter(F.col("metric").isin(negative_metric_list))
        .select("variable")
        .distinct()
    )

    return negative_variable_df


def rank_marketing_variables(
        ads_df: DataFrame, config: Dict[str, Dict[str, Any]]
) -> Tuple[DataFrame, DataFrame, DataFrame]:
    """
    Function to rank importance of marketing variables based on descending order of spend

    Objective:
        Marketing variables with Higher spend are tested before Marketing variables with lower spend in the model.
        This spend variable is identified using the baseline_primary_metric table where metrics corresponding to the spend of marketing variables are tagged as 'Y'
        in the investment_metric_cd column.

        The idea is to give more importance to marketing channels with higher spend which will be tested earlier in the model.
        However, all Marketing variables will be tested in the model.

        (Since we use a greedy algorithm to try different combinations of variables, the order in which we test the variables matters)

    Args:
        ads_df (pd.DataFrame): Contains the Analytical Dataset which contains all the weekly variable/metric data
        config (Dict): Contains the configuration parameters which are inputs to the model

    Returns:
        temp_df (pd.DataFrame): Contains the ranking of marketing variables for all clusters used to test
        variables in the model
        marketing_variables_list (List): Contains the three letter codes for all marketing variables
        to be tested in the model
        negative_variables_list (List): Contains the three letter codes for all variables where negative impact on sales is expected
    """

    # Get marketing and negative variable lists
    marketing_variable_df = get_marketing_variables(ads_df, config)
    negative_variable_df = get_negative_metrics(ads_df, config)

    # Filter investment metric for variables with spend (investment)
    spend_ads_df = ads_df.filter(F.col("investment_metric") == "Y")

    # Group by for total spend
    spend_grouped = (
        spend_ads_df
        .groupBy("modelling_cluster", "marketing_type", "marketing_channel", "marketing_sub_channel")
        .agg(F.sum("value").alias("total_spend"))
    )

    # Rank by spend within each cluster, with tie-breaking by marketing type/channel/sub-channel in alphabetical order to ensure consistent ranking
    window_spec = Window.partitionBy("modelling_cluster").orderBy(
        F.desc("total_spend"),
        F.asc("marketing_type"),
        F.asc("marketing_channel"),
        F.asc("marketing_sub_channel"))
    spend_ranked = spend_grouped.withColumn("final_rank", F.dense_rank().over(window_spec))

    # Primary metric filter and select
    primary_metric_ads = (
        ads_df
        .filter(
            (F.col("primary_metric") == "Y") &
            (~F.col("marketing_type").isin("EXTERNAL", "SALES"))
        )
        .select("modelling_cluster", "super_category_name", "unique_brand", "cluster",
                "marketing_type", "marketing_channel", "marketing_sub_channel", "metric", "variable")
        .dropDuplicates()
    )

    # Join back to the primary metrics to get the ranking of the variables
    temp_df = (
        primary_metric_ads
        .join(
            spend_ranked,
            on=["modelling_cluster", "marketing_type", "marketing_channel", "marketing_sub_channel"],
            how="left"
        )
    )

    # Identify and remove non-monetary channels
    non_monetary_channels = (
        temp_df
        .filter(F.col("final_rank").isNull())
        .select("marketing_channel")
        .distinct()
    )

    temp_df = (
        temp_df
        .join(
            non_monetary_channels.withColumn("flag", F.lit(1)),
            on="marketing_channel",
            how="left"
        )
        .filter(F.col("flag").isNull())
        .drop("flag")
    )

    # Fallback auxiliary rank if no rank is present
    aux_window = Window.partitionBy("modelling_cluster").orderBy("variable")

    temp_df = (
        temp_df
        .withColumn(
            "aux_rank",
            F.row_number().over(aux_window)
        )
        .withColumn(
            "final_rank",
            F.when(F.col("final_rank").isNull(), F.col("aux_rank")).otherwise(F.col("final_rank"))
        )
    )

    result_df = temp_df.select("modelling_cluster", "variable", "final_rank")

    return result_df, marketing_variable_df, negative_variable_df


# ToDo optimise this function to avoid multiple count calls and checkpointing
def create_priority_list(
        config: Dict[str, Dict[str, Any]],
        fp_output_df: DataFrame,
        marketing_fp_df: DataFrame,
        number_of_ext_vars_df: DataFrame
) -> DataFrame:
    """
    Function to combine all variables in modelling and create a combined importance rank which decides order in which variables
    are tested in the model

    Objective:
        Function returns a list of external variables three letter codes that need to be tested along with the order in which they need to be tested in.
        The variables are then tested in the order after testing of marketing variables.


    Args:
        config (Dict): Contains the configuration parameters for  BaselineModellingOutput
        fp_output_df (pd.DataFrame): Contains feature Prioritization output for all clusters
        marketing_fp_df (pd.DataFrame): Contains marketing variables sorted in descending order of marketing spend
        number_of_ext_vars (pd.DataFrame): Contains number of external variables to be considered for each cluster

    Raises:
        ValueError: Raises error in case Feature Prioritization has not been run successfully for a given cluster

    Returns:
        final_priority (List): Contains List of variables in the order of testing in the model
    """

    # ToDo remove all these renaming operations in optimisation

    # Prepare marketing variables for all modelling_clusters
    marketing_prepared = (
        marketing_fp_df
        .withColumnRenamed("variable", "var")
        .withColumnRenamed("final_rank", "rank")
        .withColumn("rank", F.col("rank").cast("float"))
        .select("modelling_cluster", "var", "rank")
    )

    # Create modelling cluster column for fp_output_df to join on
    fp_with_cluster = (
        fp_output_df
        .withColumn(
            "modelling_cluster",
            F.concat_ws("~", "unique_brand_name", "super_category_name", "cluster_num")
        )
    )

    # Get diversified external variables for all clusters
    diversified_df = dist_ext_vars_priority(config, fp_with_cluster, number_of_ext_vars_df)

    # Checkpoint to break lineage
    diversified_df = diversified_df.checkpoint(eager=True)

    # Add dummy variables for all clusters
    diversified_with_dummies = add_dummy_variables(diversified_df, fp_output_df)

    # Prepare external variables dataframe
    external_prepared = (
        diversified_with_dummies
        .withColumnRenamed("variable_cd", "var")
        .withColumnRenamed("variable_importance_rank", "rank")
        .withColumn("rank", F.col("rank").cast("float"))
        .select("modelling_cluster", "var", "rank")
    )

    # Calculate max rank per modelling_cluster for marketing variables
    max_ranks = (
        marketing_prepared
        .groupBy("modelling_cluster")
        .agg(F.max("rank").alias("max_marketing_rank"))
    )

    # Shift external variable ranks by adding max marketing rank per cluster, so the marketing variables go first
    # Added edge case for when there are no marketing variables for a given cluster, using left join instead of an inner join
    external_shifted = (
        external_prepared
        .join(max_ranks, on="modelling_cluster", how="left")
        .withColumn(
            "rank",
            F.col("rank") + F.coalesce(F.col("max_marketing_rank"), F.lit(0))
        )
        .filter(F.col("modelling_cluster").isNotNull())
        .select("modelling_cluster", "var", "rank")
    )

    # Checkpoint to break lineage
    external_shifted = external_shifted.checkpoint(eager=True)

    final_priority_df = (
        marketing_prepared
        .select("modelling_cluster", "var", "rank")
        .unionByName(external_shifted, allowMissingColumns=True)
        .withColumn("var", F.lower(F.col("var")))
        .orderBy("modelling_cluster", "rank")
    )

    return final_priority_df


def dist_ext_vars_priority(config: Dict[str, Dict[str, Any]],
                           df: DataFrame,
                           no_of_vars_df: DataFrame) -> DataFrame:
    """
    Function used to select external variables from different Marketing Types and Channels,
    to make sure variables tested are more diverse.

    It is applied to all modelling_clusters

    Objective:
        We choose the top variables from different marketing channels until we reach the top 20% of variables to
        be tested from the feature prioritization output. Intent is to ensure impact from the different channels are tested in the
        model to explain variation in sales.

    Args:
        config (Dict[str, Dict[str, Any]]): Contains the configuration parameters for BaselineModellingOutput
        df (pd.DataFrame): Contains the Feature Prioritization output
        no_of_vars (pd.DataFrame): Contains the maximum number of feature prioritization variables for each cluster
        to be tested in model

    Returns:
        df (pd.DataFrame): Contains the filtered Feature Prioritization output containing variables
        we want to test in model
    """
    # Rank within brand/category/cluster/type/channel by variable importance
    window_rank = Window.partitionBy(
        "unique_brand_name", "super_category_name", "cluster_num",
        "marketing_type_name", "marketing_channel_name"
    ).orderBy("variable_importance_rank")

    # Select lowest variable_importance_rank (the most important one) per group
    # Keep all variables for marketing types where we want to allow
    # multiple variables within the same type, as defined in the config
    accept_multiple_types = config.accept_multiple_within_type or []
    df_ranked = (
        df.withColumn("row_num", F.row_number().over(window_rank))
        .filter(
            (F.col("row_num") == 1) | (F.col("marketing_type_name").isin(
                accept_multiple_types)))
        .drop("row_num")
    )

    # Join with no_of_vars_df on brand/category/cluster (modelling cluster)
    df_with_limits = df_ranked.join(
        no_of_vars_df,
        on=["unique_brand_name", "super_category_name", "cluster_num"],
        how="inner"
    )

    # Re-rank by variable importance within each cluster
    window_cluster = Window.partitionBy(
        "unique_brand_name", "super_category_name", "cluster_num"
    ).orderBy("variable_importance_rank")

    df_final_ranked = df_with_limits.withColumn("rank", F.row_number().over(window_cluster))

    # Filter by required number of variables per cluster
    # Keep top N vars where N is <= no_of_vars (the allowed number of variables)
    df_filtered = (
        df_final_ranked
        .filter((F.col("rank") <= F.col("no_of_vars")))
        .drop("rank", "no_of_vars")
    )

    return df_filtered.orderBy("super_category_name", "unique_brand_name", "cluster_num", "variable_importance_rank")


# ToDo optimise this function to avoid multiple count calls
def add_dummy_variables(fp_output_df: DataFrame, fp_output_df_backup: DataFrame) -> DataFrame:
    """
    Add dummy variables (seasonal, stddev, weekstart) to the feature prioritization output if
    any member of their respective group already exists in the dataset.

    Objective:
        Ensures that if at least one variable from a dummy group is selected in the current
        feature prioritization output, all variables from that group are included. This maintains
        consistency across seasonal, standard deviation, and weekstart variable groups.

    Args:
        fp_output_df (DataFrame): Contains the current feature prioritization output for a cluster.
        fp_output_df_backup (DataFrame): Contains the complete set of feature prioritization variables,
                                             including all members of the dummy groups.

    Returns:
        DataFrame: Updated feature prioritization output containing all relevant dummy variables
        based on the presence of any member in the current selection.
    """

    # Define dummy groups
    dummy_groups = {
        "seasonal": [
            "nec_xxx_xxx_xxx_sea_pea_dum",
            "nec_xxx_xxx_xxx_sea_dip_dum"
        ],
        "stddev": [
            "nec_xxx_xxx_xxx_xxx_pea_dum",
            "nec_xxx_xxx_xxx_xxx_dip_dum"
        ],
        "weekstart": [
            "nec_xxx_xxx_xxx_xxx_pe1_dum",
            "nec_xxx_xxx_xxx_xxx_pe2_dum",
            "nec_xxx_xxx_xxx_xxx_pe3_dum",
            "nec_xxx_xxx_xxx_xxx_pe4_dum"
        ]
    }

    # Ensure uppercase consistency
    fp_output_df = fp_output_df.withColumn("variable_cd", F.upper("variable_cd"))
    fp_output_df_backup = fp_output_df_backup.withColumn("variable_cd", F.upper("variable_cd"))

    result_df = fp_output_df

    for group_codes in dummy_groups.values():
        # Check if any dummy from this group exists in current df
        check_df = result_df.filter(F.col("variable_cd").isin([c.upper() for c in group_codes]))

        if check_df.take(1):
            # Pull the full group from backup
            add_all_dum = fp_output_df_backup.filter(F.col("variable_cd").isin([c.upper() for c in group_codes]))
            # Union back
            result_df = result_df.unionByName(add_all_dum, allowMissingColumns=True)

    result_df = result_df.dropDuplicates()

    return result_df


def week_start_control_creator_all(sales_ads: DataFrame) -> DataFrame:
    """
    Create dummy variables for the start of each week in the month,
    vectorized across the full DataFrame

    Args:
        sales_ads (DataFrame): Input DataFrame with 'week_date', 'job_id', 'load_ts',
                               and other identifying columns.

    Returns:
        DataFrame: Long-format DataFrame with week start dummy variables.
    """

    config = BaselineModellingOutputConfig()

    # Check for empty DataFrame
    if not sales_ads.take(1):
        return sales_ads.sparkSession.createDataFrame([], BaselineModellingOutput.master_empty)

    df = sales_ads.withColumn(
        "week_of_month", ((F.dayofmonth("week_date") - 1) / 7 + 1).cast("int")
    )

    # One hot encode week_of_month into 4 dummy variables
    for i in range(1, 5):
        col_name = f"nec_xxx_xxx_xxx_xxx_pe{i}_dum"
        df = df.withColumn(col_name, F.when(F.col("week_of_month") == i, 1).otherwise(0))

    # Convert to long format with variable and value columns
    base_cols = ["week_date", "super_category_name", "unique_brand", "cluster"]
    stack_expr = ", ".join([
        f"'nec_xxx_xxx_xxx_xxx_pe{i}_dum', nec_xxx_xxx_xxx_xxx_pe{i}_dum" for i in range(1, 5)
    ])

    df = df.selectExpr(*base_cols, f"stack(4, {stack_expr}) as (variable, value)")

    # Extract metadata
    job_id = sales_ads.select("job_id").first()["job_id"]
    load_ts = sales_ads.select("load_ts").first()["load_ts"]

    # Add metadata columns from the config
    meta_values = {
        "marketing_type": config.week_start_control_index_name,
        "marketing_channel": config.week_start_control_index_name,
        "marketing_sub_channel": config.week_start_control_index_name,
        "metric": config.week_start_control_index_name,
        "primary_metric": config.week_start_primary_metric,
        "investment_metric": config.week_start_investment_metric,
        "job_id": job_id,
        "load_ts": load_ts
    }

    for k, v in meta_values.items():
        df = df.withColumn(k, F.lit(v))

    return df


def modelling_variable_splitter(
        master_df: DataFrame,
        independent_all_df: DataFrame,
        marketing_variables: DataFrame,
        fraction: float = 0.5
) -> Tuple[DataFrame, DataFrame]:
    """
    Function used to split activity of marketing variables into 2 parts to test separately in the model
    The function identifies where to split these variables based on the number of unique weeks in the data
    and the fraction parameter

    Previously this was defined in ucm runner 2 which I have deleted, this function is now called directly from main


    Objective:
        In Run 2 of UCM marketing variables are split based on 2 years into 2 parts. This helps the model get a better read
        on the marketing impact on baseline sales. This can help the model capture marketing impact better. Applies across all modelling clusters


    Behavior:
        - Finds variables in independent_all_df whose name contains any marketing code (case-insensitive).
        - For those variables, splits each time series per cluster into 2 halves along the date axis:
            part 1 active on first 'fraction' of unique weeks, part 2 active on remaining weeks.
            Values outside the active half are set to 0.
        - Renames variables by inserting '1' or '2' at position -4 (before last 3 chars).
        - Drops split variables with zero total activity per cluster.
        - Prepends the surviving split variables to `independent_all_df`, preserving original order:
            for each original var → part1 then part2; then all remaining non-split vars.
        - Returns:
            master_out: master with split variables appended and flag removed
            independent_all_out: reordered independent_all as a Spark DF (same columns)

    Args:
        master_df (DataFrame): Analytical dataset which goes as input to modelling
        independent_all_df (DataFrame): List of variables tested in modelling with their rank per cluster
        marketing_variables (DataFrame): Small Spark DF with marketing codes (single column 'var_code')
        fraction (float): Proportion of unique weeks in first half split. Defaults to 0.5

    Returns:
        master_out (DataFrame): Analytical dataset with split marketing variables appended
        independent_all_out (DataFrame): Independent variable list reordered with split variables first
    """

    master_df = master_df.withColumn("week_date", F.to_date("week_date"))

    indep = independent_all_df.select("modelling_cluster", "var", "rank")

    marketing_variables_df = marketing_variables.select(F.upper(F.col("var_code")).alias("var_code"))

    # Get marketing variables from independent_all, these are the variables to split per cluster
    reqd = (
        indep
        .join(
            F.broadcast(marketing_variables_df),
            on=F.expr("lower(var) like concat('%', lower(var_code), '%')"),
            how="inner"
        )
        .select("modelling_cluster", "var", "rank")
        .distinct()
        .withColumn("var_upper", F.upper("var"))
    )

    # Create a dense ranking of dates to calculate the split index
    uniq_dates = (
        master_df
        .select("modelling_cluster", "week_date")
        .distinct()
    )

    w_dates = Window.partitionBy("modelling_cluster").orderBy("week_date")
    uniq_dates = uniq_dates.withColumn("rnk", F.dense_rank().over(w_dates))
    per_cluster_counts = uniq_dates.groupBy("modelling_cluster").agg(F.max("rnk").alias("max_rnk"))

    # Determine the split point per cluster by the fraction of unique weeks
    split_point = (
        uniq_dates
        .join(
            per_cluster_counts,
            "modelling_cluster",
            "inner"
        )
        .withColumn(
            "split_idx",
            F.floor(F.col("max_rnk") * F.lit(fraction))
        )
        .withColumn(
            "flag",
            F.when(F.col("rnk") <= F.col("split_idx"), F.lit(1)).otherwise(F.lit(2))
        )
        .select("modelling_cluster", "week_date", "flag")
    )

    # Attach the flag so we can use it to split the variables later
    master_flagged = (
        master_df
        .join(
            split_point,
            on=["modelling_cluster", "week_date"],
            how="left"
        )
    )

    master_with_key = master_flagged.withColumn("var_upper", F.upper("variable"))

    to_split = (
        master_with_key
        .join(
            reqd.select("modelling_cluster", "var_upper"),
            on=["modelling_cluster", "var_upper"],
            how="inner"
        )
    )

    no_split = (
        master_with_key
        .join(
            reqd.select("modelling_cluster", "var_upper"),
            on=["modelling_cluster", "var_upper"],
            how="left_anti"
        )
        .drop("var_upper")
    )

    # Helper to edit the variable code: insert 'part' before last 3 chars (i.e., at -4) to create new var names
    def mutate_var(col_name: str, part_char: str):
        return F.concat(
            F.expr(f"substring({col_name}, 1, length({col_name})-4)"),
            F.lit(part_char),
            F.expr(f"substring({col_name}, length({col_name})-2, 3)")
        )

    # part 1 active where flag == 1, else value = 0
    split_1 = (
        to_split
        .withColumn("value", F.when(F.col("flag") == 1, F.col("value")).otherwise(F.lit(0)))
        .withColumn("variable", mutate_var("variable", "1"))
        .drop("var_upper")
    )

    # part 2 active where flag == 2, else value = 0
    split_2 = (
        to_split
        .withColumn("value", F.when(F.col("flag") == 2, F.col("value")).otherwise(F.lit(0)))
        .withColumn("variable", mutate_var("variable", "2"))
        .drop("var_upper")
    )

    split_all = split_1.unionByName(split_2)

    # Remove split variables with zero total activity per cluster
    active_split_keys = (
        split_all
        .groupBy("modelling_cluster", "variable")
        .agg(F.sum("value").alias("tot"))
        .filter(F.col("tot") > 0)
        .select("modelling_cluster", "variable")
    )

    split_all = (
        split_all
        .join(
            active_split_keys,
            on=["modelling_cluster", "variable"],
            how="inner"
        )
    )

    # Rebuild master with both split and non-split variables, dropping the unneeded columns
    master_out = (
        no_split.select([c for c in no_split.columns if c != "flag"])
        .unionByName(split_all.select([c for c in split_all.columns if c != "flag"]))
    )

    # Rebuild independent_all, preserving order (split vars first: part1 then part2)
    reqd2 = reqd.select("modelling_cluster", F.col("var_upper").alias("orig_var_upper"), "rank")

    # Generate the two split variables
    parts = (
        reqd2
        .withColumn("part", F.array(F.lit(1), F.lit(2)))
        .withColumn("part", F.explode("part"))
        .withColumn(
            "var",
            F.when(F.col("part") == 1,
                   mutate_var("orig_var_upper", "1")
                   ).otherwise(
                mutate_var("orig_var_upper", "2")
            )
        )
        .select("modelling_cluster", "var", "rank", "part")
    )

    # Keep only active split vars
    active_split_vars = active_split_keys.withColumnRenamed("variable", "var")
    split_vars_ordered = (
        parts
        .join(
            active_split_vars,
            on=["modelling_cluster", "var"],
            how="inner"
        )
        .withColumn("order_group", F.lit(0))  # split vars come first
    )

    # remaining vars = independent_all minus any original reqd vars
    reqd_lower = reqd.select("modelling_cluster", F.lower("var_upper").alias("orig_var_lower")).distinct()

    rest = (
        indep
        .withColumn("var_lower", F.lower("var"))
        .join(
            reqd_lower,
            (indep.modelling_cluster == reqd_lower.modelling_cluster) &
            (F.col("var_lower") == F.col("orig_var_lower")),
            "left_anti"
        )
        .select("modelling_cluster", F.col("var").alias("var"), "rank")
        .withColumn("order_group", F.lit(1))
    )

    # 9 is just an arbitrary large number to push the rest of the variables to the bottom when ordering by part.
    final_union = (
        split_vars_ordered.select("modelling_cluster", "var", "rank", "order_group", "part")
        .unionByName(
            rest.select("modelling_cluster", "var", "rank", "order_group").withColumn("part", F.lit(9))
        )
    )

    # Retain the previous ordering
    # "var" added as tie-breaker to make row_number() fully deterministic when rank+part are tied
    order_win = Window.partitionBy("modelling_cluster", "order_group").orderBy("rank", "part", "var")

    independent_all_out = (
        final_union
        .withColumn("row_num", F.row_number().over(order_win))
        .select(
            "modelling_cluster",
            F.lower("var").alias("var"),
            "rank",
            "row_num",  # must be in select so orderBy below can reference it
        )
        .orderBy("modelling_cluster", "row_num")
        .drop("row_num")
    )

    return master_out.distinct(), independent_all_out


def identify_peaks_and_dips_std(
    df: DataFrame,
    variable_name: str,
    peak_dummy_name: str,
    dip_dummy_name: str,
    ucm_pass_no: str
) -> DataFrame:
    """
    Identify peaks and dips in a weekly time series data using standard deviation.

    Objective:
        Function to create control variable that helps model get better read on variation in sales.
        Standard Deviation is used to create the control variable

    Used In:
        run_base_script function and append variable to ADS

    Args:
    df (pd.DataFrame): DataFrame containing the time series data.
    column_name (str): Name of the column containing the time series values.
    peak_dummy_name (str): Name of the column to flag peaks.
    dip_dummy_name (str): Name of the column to flag dips.
    ucm_pass_no (Str): Contains current set of iterations being run

    Returns:
    df (pd.DataFrame): DataFrame with additional columns for peaks and dips.
    """
    threshold = 2.5 if ucm_pass_no == 'set_3' else 2.0

    # Filter only the dependent variable we care about
    df_filtered = df.filter(F.col("variable") == variable_name)

    # Partition by cluster
    cluster_window = Window.partitionBy("modelling_cluster")

    # Calculate mean and stddev within cluster
    df_flagged = (
        df_filtered
        .withColumn("mean_val", F.mean("value").over(cluster_window))
        .withColumn("std_val", F.stddev("value").over(cluster_window))
        .withColumn(
            "value",
            F.col("value").cast("double")
        )
        .withColumn(
            peak_dummy_name,
            F.when(F.col("value") > F.col("mean_val") + threshold * F.col("std_val"), F.lit(1)).otherwise(F.lit(0))
        )
        .withColumn(
            dip_dummy_name,
            F.when(F.col("value") < F.col("mean_val") - threshold * F.col("std_val"), F.lit(1)).otherwise(F.lit(0))
        )
        .select("modelling_cluster", "wdate", peak_dummy_name, dip_dummy_name)
        .distinct()
    )

    return df_flagged
