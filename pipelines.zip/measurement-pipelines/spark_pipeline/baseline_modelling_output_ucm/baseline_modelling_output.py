from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple
from itertools import product
from pyspark.sql import functions as F, SparkSession, DataFrame, types as T

from spark_pipeline.baseline_modelling_output_ucm.ucm_output_processing import baseline_output_buckets_creation, \
    best_iteration_picker_penalty_based, process_ucm_outputs, reiterate_baseline_selector, filter_modelling_data, \
    baseline_output_creation, recalibrate_baseline
from spark_pipeline.baseline_modelling_output_ucm.ucm_feature_engineering import list_independent_ext_factors, \
    select_variable_percentile, rank_marketing_variables, create_priority_list, modelling_variable_splitter
from spark_pipeline.baseline_modelling_output_ucm.ucm_ml_functions import stdize, ucm_model_runner_factory, \
    calculate_model_metrics, post_period_stdize, during_period_model_reader
from spark_pipeline.baseline_modelling_output_ucm.ucm_runner_functions import add_dairy_week_start_control_variable, \
    prepare_modeling_dataset, apply_apl_transformations, calculate_variable_contributions, prioritise_stddev_dummy_variables, add_peak_dip_dummy_variables
from spark_pipeline.baseline_modelling_output_ucm.ucm_utils import get_modelling_cluster, get_params, \
    primary_metric_update, split_config, check_all_zero_values, ads_preprocessing, \
    filter_by_latest_load_ts, cap_level_base, parse_iteration_name, sales_variable_restore, \
    remove_brands_with_zero_sales
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineModellingOutputConfig, CampaignDurations
from spark_pipeline.schemas.baseline_modelling_output_ucm import BaselineModellingOutput
from spark_pipeline.utils.pipeline_utils import get_model_dates
from spark_pipeline.schemas.previous_baseline_modelling_output import PreviousBaselineModellingOutput
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite
from spark_pipeline.utils.stdout_logger import get_stdout_logger


logger = get_stdout_logger()


def create_empty_previous_baseline_modelling_output_df(spark: SparkSession):
    """Create an empty DataFrame with previous baseline modelling output schema."""
    return spark.createDataFrame([], PreviousBaselineModellingOutput.schema)


def prepare_baseline_modelling_output(
    spark: SparkSession,
    baseline_modelling_dataset_path: str,
    campaign_selection_path: str,
    cluster_path: str,
    feature_prioritisation_path: str,
    weekly_dates_path: str,
    checkpoint_path: str,
    baseline_modelling_base_data_output_path: str,
    baseline_modelling_fin_summary_output_path: str,
    baseline_modelling_input_path: str,
    baseline_modelling_intermediate_output_path: str,
    new_baseline_modelling_output_path: str,
    baseline_modelling_ucm_models_output_path: str,
    baseline_modelling_scalers_output_path: str,
    slack_topic_arn: str,
    correlation_id: str,
    run_date: str,
    baseline_modelling_during_ucm_output_data_path: Optional[str] = None,
    baseline_modelling_during_serialised_model_path: Optional[str] = None,
    baseline_modelling_during_scaler_path: Optional[str] = None,
    campaign_period: Optional[str] = None
) -> None:

    # Create config object to get parameters
    config = BaselineModellingOutputConfig()
    params = get_params(config)

    print('Reading S3 Data')

    baseline_modelling_df = (
        spark
        .read
        .parquet(baseline_modelling_dataset_path)
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "variable_cd",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            F.col("correlation_id").alias("job_run_id"),
            "load_ts"
        )
    )

    cluster_df = (
        spark
        .read
        .parquet(cluster_path)
        .select(
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "load_ts"
        )
    )

    campaign_selection_filter_df = (
        spark
        .read
        .parquet(campaign_selection_path)
        # We filter so we only get campaigns that are in the clustering logic
        .filter(F.col("final_status") == F.lit("CLUSTERING"))
        .select(
            "unique_brand_name",
            "super_category_name",
            "min_campaign_start_dt",
            "max_campaign_end_dt",
            "total_media_spend",
            "marketing_types"
        )
    )

    feature_prioritisation_df = (
        spark
        .read
        .parquet(feature_prioritisation_path)
        .select(
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "variable_importance_rank",
            "job_run_id",
            "variable_cd",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "load_ts",
            "metric_name"
        )
    )

    weekly_dates_df = (
        spark
        .read
        .parquet(weekly_dates_path)
        .select(
            F.col("week_start_dt").alias("week_start_date")
        )
    )

    def read_parquet_if_path(spark, path, select_cols=None, filter_expr=None):
        if not path:
            return None
        else:
            df = spark.read.parquet(path)
            if filter_expr is not None:
                df = df.filter(filter_expr)

            if select_cols:
                df = df.select(*select_cols)

            logger.info(f"Reading from - {path}")
            return df

    during_period_models_df = read_parquet_if_path(
        spark,
        baseline_modelling_during_serialised_model_path,
        select_cols=["modelling_cluster", "iteration", "ucm_fin_1_serialized"]
    )

    during_period_scaler_df = read_parquet_if_path(
        spark,
        baseline_modelling_during_scaler_path,
        select_cols=["modelling_cluster", "var", "indep_mean", "dep_mean", "ratio"]
    )

    during_period_ucm_output_df = read_parquet_if_path(
        spark,
        baseline_modelling_during_ucm_output_data_path,
        select_cols=["iteration", "best_iteration"],
        filter_expr=F.col("best_iteration") == "Y"
    )

    if during_period_models_df is not None and during_period_ucm_output_df is not None:
        best_during_model = (
            during_period_models_df
            .join(during_period_ucm_output_df, on="iteration", how="inner")
        )
        print('UCM model for best iteration from during period found')
    else:
        best_during_model = None

    print('Start Data Preprocessing')

    # Filter incremental tables by latest load timestamp
    baseline_modelling_df = filter_by_latest_load_ts(baseline_modelling_df)
    cluster_df = filter_by_latest_load_ts(cluster_df)
    feature_prioritisation_df = filter_by_latest_load_ts(feature_prioritisation_df)

    # Get the modelling clusters we will run the ucm on from campaign selection and cluster dataframes
    modelling_cluster_df, cluster_list = get_modelling_cluster(cluster_df, campaign_selection_filter_df, True)

    # Set the modelling period to filter the weekly data on
    model_start_date, model_end_date = get_model_dates(weekly_dates_df)

    params["DEFAULT"]["modelling_cluster_list"] = cluster_list
    params["DEFAULT"]["model_start_date"] = model_start_date
    params["DEFAULT"]["model_end_date"] = model_end_date

    baseline_primary_metric_df = spark.createDataFrame(config.primary_metrics, BaselineModellingOutput.primary_metrics_schema)
    # ToDo: Add alert to see which primary metrics were missing
    primary_metric_df, primary_metric_append_df = primary_metric_update(baseline_primary_metric_df, baseline_modelling_df)

    # Adds seasonality dummy data and filters the baseline modelling dataset
    # Master is the main dataset we will use for the ucm modelling and will be named master going forward
    master, master_backup = ads_preprocessing(baseline_modelling_df, primary_metric_df, modelling_cluster_df, params)

    external_variables_df = list_independent_ext_factors(master, params)
    number_of_ext_vars_df = select_variable_percentile(master, params)
    marketing_fp_df, marketing_variables_list, negative_variables_list = rank_marketing_variables(master, params)

    # ToDo refactor code to remove this temp copy
    temp_copy = params

    # Generate the config object containing all the combinations of different brands and iterations
    # Instead of using this in a loop, we will join this to the main dataset later
    brand_list, brand_iterations = split_config(temp_copy)

    # ToDo: Remove this collect logic, for now this is easier to pass lists to the pandas UCM functions and other methods

    # Collect list data to params, this will be used in all the static parts of the script to check for different variable conditions
    params["DEFAULT"]["external_factors_list"] = [row[0] for row in external_variables_df.collect()]
    params["DEFAULT"]["negative_factors_list"] = [row[0] for row in negative_variables_list.collect()]
    params["DEFAULT"]["marketing_variables_list"] = [row[0] for row in marketing_variables_list.collect()]

    # This is where the temp checkpoint data will be stored
    # Checkpointing is required due to the complexity of the ucm logic and the multiple joins and wide transformations, etc...
    # ToDo: In the future we can look to optimise this and use less checkpoints or alternate methods
    spark.sparkContext.setCheckpointDir(checkpoint_path)

    print('Feature Prioritisation')

    # Creates the list of variables to be tested in ucm model along with their ranks per modelling cluster
    variable_priority_list = create_priority_list(config,
                                                  feature_prioritisation_df,
                                                  marketing_fp_df,
                                                  number_of_ext_vars_df)

    # Some of the variable names have special characters which cause issues in SQL operations so we clean them now
    features_table = (
        variable_priority_list
        .orderBy(F.col("modelling_cluster"), F.col("rank"))
        .withColumn(
            "var",
            F.regexp_replace(F.col("var"), r"[`'\".]", "")
        )
    )

    # Break the linage before we step into the ucm pass to prevent any errors
    features_table = features_table.checkpoint(eager=True)

    master = add_dairy_week_start_control_variable(master)

    # Filter the master dataset to keep only clusters that have sales acitvity in the last N weeks for all features
    master = remove_brands_with_zero_sales(master, params, date_col='week_date', group_col='modelling_cluster',
                                           sales_col='value')

    # We also clean the corresponding variable names in the master dataset
    master = master.withColumn(
        "variable",
        F.regexp_replace(F.col("variable"), r"[`'\".]", "")
    )

    master_df = master.checkpoint(eager=True)

    # Create a dataset of all iterations to join to the master dataset later, so we can apply on the modelling cluster + iteration level
    grid_params = [
        {
            "modelling_cluster": parameter["DEFAULT"]["modelling_cluster_list"],
            "level_variance": float(parameter["UCM"]["level_variance"]),
            "cycle": True if str(parameter["UCM"]["cycle"]) == 'True' else False,
            "cycle_period_bounds": (
                parameter["UCM"].get("cycle_period_bounds", [])
                if isinstance(parameter["UCM"].get("cycle_period_bounds", []), list)
                else []
            ),
            "Iteration_Number": parameter["Iteration_Number"]
        }
        for brand in sorted(set(brand_list))  # de-duplicate ToDo: this could be handled straight from the config func
        for parameter in brand_iterations[brand][0:30]  # All iters ToDo: add config option to limit/set iters
    ]

    hyper_parameters_df = spark.createDataFrame(grid_params, schema=BaselineModellingOutput.grid_params)

    # ToDo we don't really need this but for now we use it as a timestamp column for some of the intermediate outputs
    start_time = datetime.now()

    print(f'UCM Pass 1 - {start_time}')

    # This variable determines how we split the marketing variables for the ucm passes
    ucm_pass_no: str = 'set_1'
    (
        ucm_fin_summary,
        ucm_base_data_fixed,
        ucm_base_long,
        model_metrics,
        baseline_modelling_input_data,
        incremental_check_bool,
        best_iteration_df,
        scaler_df
    ) = ucm_pass(
        spark, ucm_pass_no, campaign_period, master_df, features_table, marketing_variables_list, external_variables_df,
        hyper_parameters_df, params, campaign_selection_filter_df, during_period_scaler_df, best_during_model,
    )

    start_time_pass_two = datetime.now()

    # UCM RUN-2 for clusters where we didn't find the best iteration in the first run
    if not incremental_check_bool.filter(F.col('iteration_not_found')).isEmpty():
        print(f'UCM Pass 2 - {start_time_pass_two}')

        ucm_pass_no = 'set_2'
        (
            ucm_fin_summary_set_2,
            ucm_base_data_fixed_set_2,
            ucm_base_long_set_2,
            _,  # We no longer need the model metrics here as we will directly rank the best iteration dfs from both passes against each other, and we recalculate the rankings anyway, so we can ignore this output
            baseline_modelling_input_data_set_2,
            _,  # We no longer need the incremental check after the second pass as we will rank the best iteration from both passes so we can ignore this output
            best_iteration_df_set_2,
            scaler_df
        ) = ucm_pass(
            spark, ucm_pass_no, campaign_period, master_df, features_table, marketing_variables_list, external_variables_df,
            hyper_parameters_df, params, campaign_selection_filter_df, during_period_scaler_df, best_during_model, incremental_check_bool
        )

        # In case some of the data is empty they may not have the same schema, so we use allowMissingColumns=True
        best_iteration_df = best_iteration_df.unionByName(best_iteration_df_set_2, allowMissingColumns=True)
        ucm_base_data_fixed = ucm_base_data_fixed.unionByName(ucm_base_data_fixed_set_2, allowMissingColumns=True)
        ucm_fin_summary = ucm_fin_summary.unionByName(ucm_fin_summary_set_2, allowMissingColumns=True)
        ucm_base_long = ucm_base_long.unionByName(ucm_base_long_set_2, allowMissingColumns=True)
        baseline_modelling_input_data = baseline_modelling_input_data.unionByName(baseline_modelling_input_data_set_2, allowMissingColumns=True)

    # Reiterating checks for UCM for final output in case of multiple UCM passes to select best iteration results
    final_best_iteration_df = reiterate_baseline_selector(best_iteration_df)

    # Capping Baseline to in cases where baseline sales predicted as negative
    final_base_data_fixed_df = cap_level_base(ucm_base_data_fixed)

    # Recalculating model metrics and update the values in the final_best_iteration_df
    final_model_metrics_df = calculate_model_metrics(final_base_data_fixed_df, params["DEFAULT"]["dependent"])

    cols = [c.lower() for c in final_best_iteration_df.columns]

    print('Check WSMAPE and RSQ in final model metrics df before join')

    if "wsmape" in cols and "rsq" in cols:
        # Drop old metric columns
        final_best_iteration_df = final_best_iteration_df.drop("wsmape", "rsq")

        # Select only needed cols from metrics df
        metrics_df = (
            final_model_metrics_df
            .select(
                "Iteration_Number",
                "modelling_cluster",
                "wsmape",
                "rsq"
            )
        )

        # Inner join on iteration + modelling_cluster
        final_best_iteration_df = (
            final_best_iteration_df
            .join(metrics_df, on=["Iteration_Number", "modelling_cluster"], how="inner")
        )

    print('Reformatting Baseline Outputs')

    # We add the marketing variable patterns from the config to the params dict which is used in the baseline output creation function to determine which variables are marketing variables and which are not for the contribution calculations and final output formatting
    marketing_variable_column_patterns_all = config.negative_marketing_variable_patterns

    # Pull the specific marketing types from campaign selection to filter our config so that we are only calculating incremental sales based on relevant marketing contribution.
    # Aggregate all distinct marketing types across the DataFrame, normalising to lower case and handling the empty DataFrame case safely.
    # TODO: Remove collect logic here and handle this with Spark SQL functions to avoid collecting data to the driver, this is just easier for now but not ideal for larger datasets
    campaign_marketing_types_rows = (
        campaign_selection_filter_df
        .select(F.explode_outer("marketing_types").alias("marketing_type"))
        .select(F.lower(F.col("marketing_type")).alias("marketing_type"))
        .distinct()
        .collect()
    )
    campaign_marketing_types = [row["marketing_type"] for row in campaign_marketing_types_rows]

    # Filter on dictionary values to include only marketing types used in the current booking
    marketing_variable_column_patterns = [k for k, v in marketing_variable_column_patterns_all.items() if v in campaign_marketing_types]

    # Creating and Formatting Baseline Outputs as per Data pipeline requirement
    baseline_output_df, baseline_intermediate_output_df = baseline_output_creation(ucm_fin_summary, final_base_data_fixed_df, ucm_base_long, final_best_iteration_df, master_backup, marketing_variable_column_patterns)

    print('Rename iteration column')
    # ToDo: before raname this column it shouldn't been Iteration_Number in the first place...
    # Parsing iteration names into more readable format in Outputs
    final_fin_summary_df = parse_iteration_name(ucm_fin_summary, "Iteration_Number")
    final_base_data_df = parse_iteration_name(ucm_base_long, "Iteration_Number")
    final_model_metrics_df = parse_iteration_name(final_model_metrics_df, "Iteration_Number")
    final_best_iteration_df = parse_iteration_name(final_best_iteration_df, "Iteration_Number")

    # Restoring sales variable name as per original input in ADS
    final_base_data_df = sales_variable_restore(master_backup, final_base_data_df)

    print('Recalibrate baseline modelling output')

    # Creates the dataset in the required output format
    baseline_modelling_output = recalibrate_baseline(baseline_output_df, final_best_iteration_df, params)

    print('Add modelling_cluster column to baseline_modelling_output')

    baseline_modelling_output = (
        baseline_modelling_output
        .withColumn(
            "modelling_cluster",
            F.concat_ws(
                "~",
                F.col("unique_brand_name"),
                F.col("super_category_name"),
                F.col("cluster_num")
            )
        )
    )

    print('Join final model metrics to baseline_modelling_output')

    baseline_modelling_output = (
        baseline_modelling_output
        .join(
            final_model_metrics_df.select(
                "modelling_cluster",
                F.col("Iteration_Number").alias("iteration"),
                "rsq",
                "wsmape",
                "baseline_perc"
            ),
            on=["modelling_cluster", "iteration"],
            how="left"
        )
        .drop("modelling_cluster")
    )

    # Generate a consistent timestamp for this run
    run_ts = F.current_timestamp()

    print('Prepare final outputs for parquet write')

    # Prepare the final outputs to be written to parquet, including intermediate outputs for DS review
    final_base_data_df = (
        final_base_data_df
        .select
        (
            "wdate",
            "modelling_cluster",
            F.col("Iteration_Number").alias('iteration'),
            "variable",
            "value",
        )
        .withColumn('time_stamp', F.lit(start_time))
        .withColumn('load_ts', F.lit(run_ts))
    )

    final_fin_summary_df = (
        final_fin_summary_df
        .select
        (
            "variable_apl",
            "estimate",
            "approx_std_err",
            "zvalue",
            "pvalue_zdist",
            F.col("Iteration_Number").alias('iteration'),
            "modelling_cluster",
            "ucm_fin_1_serialized",
        )
        .withColumn('time_stamp', F.lit(start_time))
        .withColumn('load_ts', F.lit(run_ts))
    )

    ucm_serialised_models = (
        final_fin_summary_df.select(
            "modelling_cluster",
            "iteration",
            "ucm_fin_1_serialized"
        ).distinct()
    )

    final_baseline_modelling_input_data = (
        baseline_modelling_input_data
        .withColumn('load_ts', F.lit(run_ts))
        .withColumn('job_run_id', F.lit(correlation_id))
    )

    baseline_intermediate_output_df = (
        baseline_intermediate_output_df
        .select(
            F.col("super_category_name").cast(T.StringType()).alias("super_category_name"),
            F.col("unique_brand_name").cast(T.StringType()).alias("unique_brand_name"),
            F.col("cluster_num").cast(T.StringType()).alias("cluster_num"),
            F.col("variable_cd").cast(T.StringType()).alias("variable_cd"),
            F.col("estimates").cast(T.FloatType()).alias("estimates"),
            F.col("p_value").cast(T.FloatType()).alias("p_value"),
            F.col("contribution").cast(T.FloatType()).alias("contribution"),
            F.col("contribution_proportion").cast(T.FloatType()).alias("contribution_proportion"),
            F.col("Iteration_Number").cast(T.StringType()).alias("iteration"),
            F.col("marketing_type_name").cast(T.StringType()).alias("marketing_type_name"),
            F.col("marketing_channel_name").cast(T.StringType()).alias("marketing_channel_name"),
            F.col("marketing_sub_channel_name").cast(T.StringType()).alias("marketing_sub_channel_name"),
            F.col("metric_name").cast(T.StringType()).alias("metric_name"),
            F.col("best_iteration").cast(T.StringType()).alias("best_iteration")
        )
        .withColumn('load_ts', F.lit(run_ts))
        .withColumn('job_run_id', F.lit(correlation_id))
    )

    baseline_modelling_output = (
        baseline_modelling_output.select(
            F.col("week_start_dt").cast(T.DateType()).alias("week_start_dt"),
            F.col("super_category_name").cast(T.StringType()).alias("super_category_name"),
            F.col("unique_brand_name").cast(T.StringType()).alias("unique_brand_name"),
            F.col("cluster_num").cast(T.StringType()).alias("cluster_num"),
            F.col("iteration").cast(T.StringType()).alias("iteration"),
            F.upper(F.col("modelling_type")).cast(T.StringType()).alias("modelling_type"),
            F.col("metric_name").cast(T.StringType()).alias("metric_name"),
            F.col("best_iteration").cast(T.StringType()).alias("best_iteration"),
            F.col("metric_value").cast(T.FloatType()).alias("metric_value"),
            F.col("rsq").cast(T.FloatType()).alias("rsq"),
            F.col("wsmape").cast(T.FloatType()).alias("wsmape"),
            F.col("baseline_perc").cast(T.FloatType()).alias("baseline_perc")
        )
        .withColumn('load_ts', F.lit(run_ts))
        .withColumn('job_run_id', F.lit(correlation_id))
    )

    print('Write final outputs to parquet')

    spark_s3_overwrite(baseline_modelling_base_data_output_path, final_base_data_df)
    spark_s3_overwrite(baseline_modelling_fin_summary_output_path, final_fin_summary_df)
    spark_s3_overwrite(baseline_modelling_scalers_output_path, scaler_df)
    spark_s3_overwrite(baseline_modelling_input_path, final_baseline_modelling_input_data)
    spark_s3_overwrite(baseline_modelling_intermediate_output_path, baseline_intermediate_output_df)
    spark_s3_overwrite(new_baseline_modelling_output_path, baseline_modelling_output)

    # Write serialized models
    if baseline_modelling_ucm_models_output_path:
        spark_s3_overwrite(baseline_modelling_ucm_models_output_path, ucm_serialised_models)


def ucm_pass(
        spark: SparkSession,
        ucm_pass_no: str,
        campaign_period: str,
        master_df: DataFrame,
        independent_all: DataFrame,
        marketing_variables_list: DataFrame,
        external_variables_list: DataFrame,
        hyper_parameters_df: DataFrame,
        config: Dict[str, Dict[str, Any]],
        campaign_selection_df: DataFrame,
        during_period_scaler_df: Optional[DataFrame] = None,
        best_during_model: Optional[DataFrame] = None,
        incremental_check_bool: Optional[DataFrame] = None,
) -> Tuple[DataFrame, DataFrame, DataFrame, DataFrame, DataFrame, DataFrame, DataFrame, DataFrame, DataFrame]:
    """
    Executes a pass of the Unobserved Components Model (UCM) on the provided data.
    A pass refers to running the UCM on every modelling cluster and iteration that does not have a best iteration selected yet.

    This function processes marketing data through a series of transformations and applies
    the UCM to identify components in time series data. It supports different configuration
    sets (set_1, set_2, set_3) that determine how variables are processed.

    The process includes:
        1. Variable splitting and preprocessing based on pass number
        2. Removing modelling clusters with no activity
        3. Applying APL (Adstock, Power, Lag) transformations to independent variables
        4. Standardizing data
        5. Running the UCM model with different apl combinations
        6. Calculating variable contributions
        7. Processing and formatting results

    Args:
        ucm_pass_no (str): The pass number/set identifier ('set_1', 'set_2', or 'set_3')
        master_df (DataFrame): Master dataset containing time series data
        independent_all (DataFrame): DataFrame with all independent variables
        marketing_variables_list (DataFrame): DataFrame with marketing variables
        external_variables_list (DataFrame): DataFrame with external factors
        hyper_parameters_df (DataFrame): DataFrame containing hyperparameters for model iterations
        config (Dict[str, Dict[str, Any]]): Configuration dictionary with model parameters
        campaign_selection_df (DataFrame): Campaign selection data with media spend on Brand X Supercategory level to use in the best interation selection logic
        incremental_check_bool (Optional[DataFrame]): DataFrame indicating which clusters need re-evaluation

    Returns:
        Tuple[DataFrame, DataFrame, DataFrame]: A tuple containing:
            - ucm_results: Raw UCM model results
            - ucm_base_data_fixed: Processed baseline data with buckets
            - model_metrics: Performance metrics for each model iteration
    """

    if ucm_pass_no == "set_2":
        master_df, independent_all = modelling_variable_splitter(master_df, independent_all, marketing_variables_list)

        # Within the modelling_variable_splitter, it contains many unoptimized complex shuffles and expands the data, so I checkpoint it to prevent any session errors
        independent_all = independent_all.checkpoint(eager=True)
        master_df = master_df.checkpoint(eager=True)

    if ucm_pass_no == "set_3":
        independent_all = prioritise_stddev_dummy_variables(independent_all)

    # Removes any modelling clusters that have no activity
    independent_all = check_all_zero_values(master_df, independent_all)

    # Filter and format the input dataset and duplicate all external variables to all modelling clusters
    master_df, raw_org_df, raw_long_df = prepare_modeling_dataset(master_df, config["DEFAULT"]["model_start_date"], config["DEFAULT"]["model_end_date"], duplicate_external=True)

    # Once we've copied over the external variables to all clusters, we can filter to only contain the clusters we need to process
    if ucm_pass_no != "set_1":
        if incremental_check_bool is not None:
            master_df, independent_all = filter_modelling_data(master_df, independent_all, incremental_check_bool)

    master_df = master_df.select("modelling_cluster", "wdate", "variable", "value")

    independent_all = independent_all.checkpoint(eager=True)
    master_df = master_df.checkpoint(eager=True)

    apl_ad = config['UCM']['apl_ad']
    apl_pw = config['UCM']['apl_pw']
    apl_lg = config['UCM']['apl_lg']

    dep = config["DEFAULT"]["dependent"]
    var_len = config["DEFAULT"]["var_len"]

    # Identify peaks and dips in the dependent variable and add them to the dataset
    master_df, independent_all = add_peak_dip_dummy_variables(master_df, independent_all, ucm_pass_no, dep)

    # Apply APL transformation to the independent variables in the dataset
    ext_vars, lagdata_1_df, adstock_drv, power_drv, lag_drv = apply_apl_transformations(
        config, master_df, independent_all, external_variables_list, dep, apl_ad, apl_pw, apl_lg
    )

    # ToDo: fix this, sometimes we encounter column errors due to the internal behaviour of spark so a quick and dirty way to prevent this is to break the linage
    lagdata_1_df = lagdata_1_df.checkpoint(eager=True)

    # Standardize the data using x / mean(x)
    if campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST:
        sc, master_dataset = post_period_stdize(dep, during_period_scaler_df, lagdata_1_df)
        logger.info(f"Campaign period - {campaign_period}")
        logger.info("Using the post-period scalers to stdize")
    else:
        sc, master_dataset = stdize(dep, lagdata_1_df)
        logger.info("Fresh standardisation")

    master_dataset = master_dataset.fillna(0)

    # Create the final dataset to apply UCM over
    # Adding the hyperparameters, the independent variable list and the external variable list (variables with no apl)

    # Remove error variables from the independent variable list
    independent_vars_with_errors = (
        independent_all
        .filter(F.col("variable").like("ERROR%"))
        .select('modelling_cluster')
    )

    master_dataset = (
        master_dataset
        .join(
            F.broadcast(hyper_parameters_df),
            on="modelling_cluster",
            how="left"
        )
        .withColumn(
            "Iteration_Number",
            F.concat_ws("-", F.col("Iteration_Number"), F.lit(ucm_pass_no))
        )
        .join(
            F.broadcast(independent_vars_with_errors),
            on="modelling_cluster",
            how="anti"
        )
    )

    # Add the full variable list to the main dataset per modelling cluster so we can loop over them in the apl calculations within the applied group
    independent_all_list = (
        independent_all
        .groupBy('modelling_cluster')
        .agg(
            F.sort_array(
                F.collect_list(F.struct("rank", "variable"))
            ).alias('variable_list')
        )
        .withColumn('variable_list', F.col('variable_list.variable'))
    )

    ext_vars_list = (
        ext_vars
        .groupBy('modelling_cluster')
        .agg(
            F.sort_array(F.collect_list('variable')).alias('ext_variable_list')
        )
    )

    # Join all the list params, so we can access them via spark instead of collecting them
    master_dataset = (
        master_dataset
        .join(
            F.broadcast(independent_all_list),
            on="modelling_cluster",
            how="left"
        )
        .filter(F.col("variable_list").isNotNull())
        .join(
            F.broadcast(ext_vars_list),
            on="modelling_cluster",
            how="left"
        )
    )

    constant_sigma2_level = 'sigma2.level'
    constant_sigma2_trend = 'sigma2.trend'

    marketing_variables_list = config["DEFAULT"]["marketing_variables_list"]
    negative_factors_list = config["DEFAULT"]["negative_factors_list"]

    all_combinations = list(product(adstock_drv, power_drv, lag_drv))

    # Create UCM factory function, allowing the UDF function to have access to these varible's from the outer scope
    ucm_runner = ucm_model_runner_factory(
        dependent=dep,
        constant_sigma2_level=constant_sigma2_level,
        constant_sigma2_trend=constant_sigma2_trend,
        marketing_variables_list=marketing_variables_list,
        negative_factors_list=negative_factors_list,
        var_len=var_len,
        all_combinations=all_combinations
    )

    # Sanity check to make sure the data is in the correct order, since order matters
    master_dataset = master_dataset.orderBy('modelling_cluster', 'Iteration_Number', 'wdate')

    # Apply the UCM results over every modelling cluster + Iteration
    if campaign_period == CampaignDurations.CAMPAIGN_DURATION_POST:
        ucm_results = during_period_model_reader(spark, during_models=best_during_model)
        logger.info("Using the during period UCM model objects")
    else:
        ucm_results = (
            master_dataset
            .groupby("modelling_cluster", "Iteration_Number")
            .applyInPandas(ucm_runner, schema=BaselineModellingOutput.full_ucm_output)
        )

    # Checkpoint the UCM results to speed up procesing after
    ucm_results = ucm_results.checkpoint(eager=True)

    ucm_base_data, baseline_modelling_input_data = process_ucm_outputs(ucm_results, master_dataset, lagdata_1_df, sc, dep)

    ucm_base_data = ucm_base_data.checkpoint(eager=True)

    level_base_n = "level_base"

    # Get contributions of all variables
    lagdata_3, _ = calculate_variable_contributions(raw_org_df, lagdata_1_df, sc, ucm_results, ucm_base_data, level_base_n)

    # Melt the ucm_base_data into long format so we can add it to lagdata_3
    ucm_cols = [c for c in ucm_base_data.columns if
                c not in ["wdate", "modelling_cluster", "Iteration_Number", "seasonal"]]

    # Build an SQL safe stack expression with escapes due to special chars in some column names
    stack_expr = ", ".join([f"'{c}', `{c}`" for c in ucm_cols])

    ucm_base_long = (
        ucm_base_data
        .selectExpr(
            "wdate",
            "modelling_cluster",
            "Iteration_Number",
            f"stack({len(ucm_cols)}, {stack_expr}) as (variable, value)"
        )
    )

    ucm_base_long = ucm_base_long.unionByName(lagdata_3)

    ucm_base_long = ucm_base_long.checkpoint(eager=True)

    # Create new bucket variables so we can measure seasonality and baseline values
    ucm_base_data_fixed = baseline_output_buckets_creation(ucm_base_long, raw_long_df, config)

    ucm_base_data_fixed = ucm_base_data_fixed.checkpoint(eager=True)

    model_metrics = calculate_model_metrics(ucm_base_data_fixed, dep)

    model_metrics = model_metrics.filter(F.col('Iteration_Number').isNotNull())

    incremental_check_bool, best_iteration_df = best_iteration_picker_penalty_based(
        master_df,
        ucm_results,
        model_metrics,
        ucm_base_long,
        campaign_selection_df
    )

    return ucm_results, ucm_base_data_fixed, ucm_base_long, model_metrics, baseline_modelling_input_data, incremental_check_bool, best_iteration_df, sc


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Baseline Modelling Output for baseline pipeline.")
    parser.add_argument(
        "--baseline-modelling-dataset-path",
        type=str,
        required=True,
        help="S3 path for baseline modelling dataset."
    )

    parser.add_argument(
        "--campaign-period",
        type=str,
        required=False,
        default=None,
        help="Campaign period: 'During', 'Post'"
    )

    parser.add_argument(
        "--baseline-modelling-during-ucm-output-data-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for UCM input data from the During run, used in Post runs."
    )

    parser.add_argument(
        "--baseline-modelling-during-serialised-model-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for serialised UCM models from the During run, used in Post runs."
    )

    parser.add_argument(
        "--baseline-modelling-during-scaler-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for scalers from the During run, used to standardise the Post period."
    )
    parser.add_argument(
        "--campaign-selection-path",
        type=str,
        required=True,
        help="S3 path for campaign selection data."
    )
    parser.add_argument(
        "--cluster-path",
        type=str,
        required=True,
        help="S3 path for cluster data."
    )
    parser.add_argument(
        "--feature-prioritisation-path",
        type=str,
        required=True,
        help="S3 path for feature prioritisation data."
    )
    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="S3 path for weekly dates reference data."
    )
    parser.add_argument(
        "--checkpoint-path",
        type=str,
        required=True,
        help="S3 path for checkpoint data."
    )
    parser.add_argument(
        "--baseline-modelling-base-data-output-path",
        type=str,
        required=True,
        help="S3 path for baseline modelling base data output."
    )
    parser.add_argument(
        "--baseline-modelling-fin-summary-output-path",
        type=str,
        required=True,
        help="S3 path for baseline modelling fin summary output."
    )
    parser.add_argument(
        "--baseline-modelling-input-path",
        type=str,
        required=True,
        help="S3 path for baseline modelling input."
    )
    parser.add_argument(
        "--baseline-modelling-intermediate-output-path",
        type=str,
        required=True,
        help="S3 path for baseline modelling intermediate output."
    )
    parser.add_argument(
        "--new-baseline-modelling-output-path",
        type=str,
        required=True,
        help="S3 path for new baseline modelling output."
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="SNS topic ARN for Slack notifications."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for tracking."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Run date for the pipeline."
    )

    parser.add_argument(
        "--baseline-modelling-ucm-models-output-path",
        type=str,
        required=False,
        default=None,
        help="Serialized UCM models output."
    )

    parser.add_argument(
        "--baseline-modelling-scalers-output-path",
        type=str,
        required=False,
        default=None,
        help="Save scalares to standardardise post-period"
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_baseline_modelling_output(
        spark=spark,
        baseline_modelling_dataset_path=known_args.baseline_modelling_dataset_path,
        campaign_selection_path=known_args.campaign_selection_path,
        cluster_path=known_args.cluster_path,
        feature_prioritisation_path=known_args.feature_prioritisation_path,
        weekly_dates_path=known_args.weekly_dates_path,
        checkpoint_path=known_args.checkpoint_path,
        baseline_modelling_base_data_output_path=known_args.baseline_modelling_base_data_output_path,
        baseline_modelling_fin_summary_output_path=known_args.baseline_modelling_fin_summary_output_path,
        baseline_modelling_input_path=known_args.baseline_modelling_input_path,
        baseline_modelling_intermediate_output_path=known_args.baseline_modelling_intermediate_output_path,
        new_baseline_modelling_output_path=known_args.new_baseline_modelling_output_path,
        baseline_modelling_ucm_models_output_path=known_args.baseline_modelling_ucm_models_output_path,
        baseline_modelling_scalers_output_path=known_args.baseline_modelling_scalers_output_path,
        slack_topic_arn=known_args.slack_topic_arn,
        correlation_id=known_args.correlation_id,
        campaign_period=known_args.campaign_period,
        run_date=known_args.run_date,
        baseline_modelling_during_ucm_output_data_path=known_args.baseline_modelling_during_ucm_output_data_path,
        baseline_modelling_during_serialised_model_path=known_args.baseline_modelling_during_serialised_model_path,
        baseline_modelling_during_scaler_path=known_args.baseline_modelling_during_scaler_path,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("BaselineModellingOutput").getOrCreate())
