import statsmodels.tsa.filters.filtertools as tsf

import pandas as pd
import numpy as np

from itertools import product

from pyspark.sql import functions as F, DataFrame
from pyspark.sql.window import Window

from typing import List, Dict, Any, Tuple

from spark_pipeline.baseline_modelling_output_ucm.ucm_feature_engineering import week_start_control_creator_all, \
    identify_peaks_and_dips_std

from spark_pipeline.schemas.baseline_modelling_output_ucm import BaselineModellingOutput


def add_dairy_week_start_control_variable(master_df: DataFrame) -> DataFrame:
    """
    Objective:
        Function used to add week start control variable for Dairy super category
    Args:
        master_df (DataFrame): Contains the master data with sales and marketing data
    Returns:
        master (DataFrame): Contains the master data with sales and marketing data along with week start control variable for Dairy super category
    """

    master_sales = master_df.filter(
        (F.col("marketing_channel") == "SALES") & (F.col("metric") == "TOTAL_SALES")
    )

    dairy_sales = master_sales.filter(F.col("super_category_name") == "DAIRY")

    # Create week start dummy variable for Dairy super category
    result_df_3 = week_start_control_creator_all(dairy_sales)

    result_df_3 = result_df_3.withColumn(
        "modelling_cluster",
        F.concat_ws("~", "unique_brand", "super_category_name", "cluster")
    )

    master_df = master_df.unionByName(result_df_3, allowMissingColumns=True)

    return master_df


def prioritise_stddev_dummy_variables(independent_all: DataFrame) -> DataFrame:
    """
    Objective:
        Function used to add standard deviation dummy variables at the start of the list
        of independent variables (per modelling_cluster).

        Most modelling_clusters have this dummy variable but it may not have been selected,
        so this basically enforces it's inclusion in the ucm model

    Used In:
        ucm_runner() function
    Args:
        independent_all (DataFrame): Spark DataFrame containing the list of independent
                                     variables with schema:
                                     - modelling_cluster (string)
                                     - variable (string)
    Returns:
        DataFrame: Same schema as input, but with standard deviation dummy variables
                   moved to the start of the variable order for each cluster.
    """

    # Define stddev dummy vars
    remove_vars = ['nec_xxx_xxx_xxx_xxx_pea_dum', 'nec_xxx_xxx_xxx_xxx_dip_dum']
    remove_vars_upper = [x.upper() for x in remove_vars]

    # Flag variables that are dummies vs. others
    reordered = (
        independent_all
        .withColumn(
            "is_dummy",
            F.when(F.upper(F.col("var")).isin(remove_vars_upper), F.lit(1)).otherwise(F.lit(2))
        )
    )

    order_win = Window.partitionBy("modelling_cluster").orderBy("is_dummy", "rank", "var")

    result = (
        reordered
        .withColumn("final_rank", F.row_number().over(order_win).cast("double"))
        .select("modelling_cluster", F.col("var"), F.col("final_rank").alias("rank"))
        .orderBy("modelling_cluster", "rank")
    )

    return result


def prepare_modeling_dataset(
        raw: DataFrame,
        model_start_date: str,
        model_end_date: str,
        duplicate_external: bool = True
) -> Tuple[DataFrame, DataFrame, DataFrame]:
    """
    Prepare the analytical dataset (ADS) for UCM modeling in long format

    It supports two modes for handling EXTERNAL marketing variables:
        1. duplicate_external=True (default): Duplicates EXTERNAL rows into every cluster
        2. duplicate_external=False: Keeps EXTERNAL rows as their own cluster

    Objective:
        Keeps ADS in long format so it can grouped and parallelised automatically by spark
        It ensures EXTERNAL marketing variables are handled consistently across clusters,
        and cleans column names to avoid downstream SQL issues.

    Args:
        raw (DataFrame): Input analytical dataset in long format with columns:
                         ["week_date", "modelling_cluster", "variable", "value", "marketing_type", ...]
        model_start_date (str): Start date for model training period (YYYY-MM-DD).
        model_end_date (str): End date for model training period (YYYY-MM-DD).
        duplicate_external (bool, default=True): If True, duplicates EXTERNAL rows into every cluster.
                                                 If False, keeps EXTERNAL rows as their own cluster.

    Returns:
        Tuple[DataFrame, DataFrame, DataFrame]:
            raw_filtered (DataFrame): Filtered dataset (date range applied).
            raw (DataFrame): Original input dataset (with cleaned colnames).
            raw_with_external (DataFrame): Long-format dataset with EXTERNAL handled
                                           (duplicated into clusters if duplicate_external=True).
    """

    # Clean column names
    ads_df = raw

    for c in ads_df.columns:
        new_c = c.replace("`", "").lower()
        ads_df = ads_df.withColumnRenamed(c, new_c)

    ads_df = (
        ads_df.withColumn("week_date", F.to_date("week_date"))
        .withColumn("wdate", F.col("week_date"))
    )

    raw_filtered = (
        ads_df.filter(
            (F.col("wdate") >= F.lit(model_start_date)) &
            (F.col("wdate") <= F.lit(model_end_date))
        )
        .orderBy("wdate")
    )

    if duplicate_external:
        # Collect distinct clusters
        clusters_df = raw_filtered.select("modelling_cluster").distinct()

        # Duplicate EXTERNAL rows into every cluster
        external_dup = (
            raw_filtered
            .filter(F.col("marketing_type") == "EXTERNAL")
            .drop("modelling_cluster")
            .crossJoin(F.broadcast(clusters_df))
            .dropDuplicates(["modelling_cluster", "wdate", "variable"])
        )

        # Union back into dataset
        raw_with_external = (
            raw_filtered
            .filter(F.col("marketing_type") != "EXTERNAL")
            .unionByName(external_dup)
        )
    else:
        # Keep EXTERNAL as its own cluster
        raw_with_external = raw_filtered

    return raw_with_external, ads_df, raw


def add_peak_dip_dummy_variables(
        raw: DataFrame,
        independent_all: DataFrame,
        ucm_pass_no: int,
        dependent: str
) -> Tuple[DataFrame, DataFrame]:
    """
    Objective:
        Function used to identify peaks and dips in the dependent variable in long format data
        The function also adds the identified peaks and dips as dummy variables to the dataset

    Args:
        raw (pd.DataFrame): Contains the modelling dataset in long format
        independent_all (List): Contains the list of independent variables
        ucm_pass_no (int): Contains the current pass number of the UCM model
        dependent (String): Contains the reference to the dependent variable
    Returns:
        raw (pd.DataFrame): Contains the updated modelling dataset with dummy variables for peaks and dips
        independent_all (List): Contains the updated list of independent variables
    """

    peak_dummy = "nec_xxx_xxx_xxx_xxx_pea_dum"
    dip_dummy = "nec_xxx_xxx_xxx_xxx_dip_dum"

    dummy_df = identify_peaks_and_dips_std(
        raw.select("modelling_cluster", "wdate", "variable", "value"),
        dependent,
        peak_dummy,
        dip_dummy,
        ucm_pass_no
    )

    if not dummy_df.take(1):
        return raw, independent_all

    # Check if peak dummy has >1 unique value per cluster
    peak_valid_clusters = (
        dummy_df
        .groupBy("modelling_cluster")
        .agg(F.countDistinct(peak_dummy).alias("n_unique"))
        .filter(F.col("n_unique") > 1)
        .select("modelling_cluster")
    )

    # Check if dip dummy has >1 unique value per cluster
    dip_valid_clusters = (
        dummy_df
        .groupBy("modelling_cluster")
        .agg(F.countDistinct(dip_dummy).alias("n_unique"))
        .filter(F.col("n_unique") > 1)
        .select("modelling_cluster")
    )

    # Add peak dummy in long form
    if peak_valid_clusters.take(1):
        peak_long = (
            dummy_df
            .select("modelling_cluster", "wdate", F.lit(peak_dummy).alias("variable"), F.col(peak_dummy).alias("value"))
        )
        raw = raw.unionByName(peak_long)
    else:
        independent_all = independent_all.filter(F.lower(F.col("variable")) != peak_dummy)

    # Add dip dummy in long form
    if dip_valid_clusters.take(1):
        dip_long = (
            dummy_df
            .select("modelling_cluster", "wdate", F.lit(dip_dummy).alias("variable"), F.col(dip_dummy).alias("value"))
        )
        raw = raw.unionByName(dip_long)
    else:
        independent_all = independent_all.filter(F.lower(F.col("variable")) != dip_dummy)

    return raw, independent_all


def apply_apl_transformations(
        config: Dict[str, Dict[str, Any]],
        raw: DataFrame,
        independent_all_df: DataFrame,
        external_factors_df: DataFrame,
        dependent: str,
        apl_ad: List[float],
        apl_pw: List[float],
        apl_lg: List[int],
) -> Tuple[DataFrame, DataFrame, List[float], List[float], List[int]]:
    """
    Objective:
        Function used to apply Adstock–Power–Lag (APL) transformation to the independent
        variables in the dataset. It separates dummy and external variables (which are excluded
        from APL), applies APL transformations to the rest, and then recombines everything.

    Adstock
        Captures the carryover effect of marketing spend.
    Power
        Models diminishing returns (the idea that doubling spend does not double sales).
    Lag
        Captures the delayed effect of marketing.

    Args:
        config (dict): Contains configuration parameters (e.g., dummy variables list).
        raw (DataFrame): Spark DataFrame containing the modelling dataset in long format
                         with columns (modelling_cluster, wdate, variable, value).
        independent_all_df (DataFrame): DataFrame containing the list of independent variables
                                        per modelling cluster
        external_factors_df (DataFrame): DataFrame containing external variables (excluded from APL).
        dependent (str): The dependent variable name.
        apl_ad (List[float]): List of APL adstock values.
        apl_pw (List[float]): List of APL power values.
        apl_lg (List[int]): List of APL lag values.

    Returns:
        ext_vars (DataFrame): Independent variables list after stripping the "_001000" suffix.
        final_df (DataFrame): Long-format modelling dataset with APL-transformed variables,
                              dummy/external variables, and dependent variable.
        apl_ad (List[float]): List of adstock parameters applied.
        apl_pw (List[float]): List of power parameters applied.
        apl_lg (List[int]): List of lag parameters applied.
    """

    dummy_vars_list = config["DEFAULT"]["dummy_vars_list"]

    # Extract dependent variable rows to add back later
    dependent_data_df = raw.filter(F.col("variable") == dependent)

    # Add a flag for dummy variables as these are excluded from APL
    dummy_vars_df = (
        independent_all_df
        .withColumn(
            'variable',
            F.upper(F.col("variable"))
        )
        .withColumn(
            "is_dummy",
            F.col("variable").isin([v.upper() for v in dummy_vars_list]),
        )
    )

    # Flag all the external variables as these are also excluded from APL
    external_factors_df = (
        external_factors_df
        .withColumn("is_external", F.lit(True))
        .withColumn("variable", F.upper(F.col("variable")))
    )

    # Mark if apl needs to be applied, coalesce is important to handle nulls
    flagged_vars_df = (
        dummy_vars_df
        .join(
            external_factors_df,
            on="variable",
            how="left",
        )
        .withColumn("is_external", F.coalesce(F.col("is_external"), F.lit(False)))
        .withColumn("apply_apl", ~(F.col("is_external") | F.col("is_dummy")))
        .select("variable", "modelling_cluster", "is_dummy", "is_external", "apply_apl")
        .dropDuplicates(["variable", "modelling_cluster"])
    )

    # Constrain the dataset to match the variables X modelling_cluster in the flagged_vars_df
    raw_flagged = (
        raw
        .withColumn("variable", F.upper(F.col("variable")))
        .join(
            flagged_vars_df,
            on=["variable", "modelling_cluster"],
            how="inner"
        )
        .select("modelling_cluster", "wdate", "variable", "value", "apply_apl")
    )

    # Separate APL vs. non-APL datasets
    apl_df = raw_flagged.filter(F.col("apply_apl")).select(
        "modelling_cluster", "wdate", "variable", "value"
    )

    # Non-APL: append "_001000" suffix
    non_apl_df = (
        raw_flagged.filter(~F.col("apply_apl"))
        .select(
            "modelling_cluster",
            "wdate",
            F.concat(F.col("variable"), F.lit("_001000")).alias("variable"),
            "value",
        )
        .dropDuplicates(["modelling_cluster", "wdate", "variable"])
    )

    # ToDo maybe make a spark implementation of the apl function below
    # Pandas UDF for APL transformation, so we can copy the existing logic easily
    def apl_pandas_udf(pdf: pd.DataFrame) -> pd.DataFrame:
        # Ensure chronological order
        pdf = pdf.sort_values("wdate").reset_index(drop=True)
        variable_name = pdf["variable"].iloc[0]
        cluster = pdf["modelling_cluster"].iloc[0]

        values = pdf["value"].values
        dates = pdf["wdate"].values
        all_combinations = list(product(apl_ad, apl_pw, apl_lg))

        # Precompute adstock series
        adstock_dict = {ad: tsf.recursive_filter(values, ad / 100) for ad in apl_ad}

        output_rows = []
        for ad, po, la in all_combinations:
            adstock_series = adstock_dict[ad]
            ad_power = np.power(adstock_series, po / 100)
            ad_power_lag = np.roll(ad_power, la)

            if la > 0:
                ad_power_lag[:la] = np.nan

            suffix = f"{str(ad).zfill(2)}{str(po).zfill(3)}{str(la)}"
            new_variable = f"{variable_name}_{suffix}"

            output_rows.extend(
                (cluster, date, new_variable, val)
                for date, val in zip(dates, ad_power_lag)
            )

        return pd.DataFrame(
            output_rows, columns=["modelling_cluster", "wdate", "variable", "value"]
        )

    # Apply APL transformations per (cluster, variable)
    apl_transformed = apl_df.groupBy("modelling_cluster", "variable").applyInPandas(
        apl_pandas_udf, BaselineModellingOutput.apl_variables
    )

    # Recombine all parts
    final_df = (
        apl_transformed.select("modelling_cluster", "wdate", "variable", "value")
        .unionByName(non_apl_df)
        .unionByName(dependent_data_df)
    )

    # Create a specific external variable list for each cluster and strip "_001000" suffix to return cleaned dataframe
    ext_vars = (
        non_apl_df
        .withColumn(
            "variable",
            F.lower(F.col('variable'))
        )
        .withColumn(
            "variable",
            F.regexp_replace(F.col("variable"), "_001000$", "")
        )
        .select("modelling_cluster", "variable")
        .distinct()  # We need to squash the duplicate values from wdate
    )

    return ext_vars, final_df, apl_ad, apl_pw, apl_lg


def calculate_variable_contributions(
        raw_org: DataFrame,
        lagdata_2: DataFrame,
        sc: DataFrame,
        ucm_fin_summary: DataFrame,
        ucm_base_data: DataFrame,
        level_base_n: str
) -> Tuple[DataFrame, DataFrame]:
    """
    Objective:
        Calculate the contributions of variables to sales and merge them into the
        modelling dataset. This includes adjusting estimates, applying them to the
        lagged dataset, and ensuring baseline information is properly included.

    Args:
        raw_org (DataFrame): Original modelling dataset in long format.
        lagdata_2 (DataFrame):
        sc (DataFrame): Scaling/standardization dataset containing ratios at cluster+variable level.
        ucm_fin_summary (DataFrame): UCM model summary with variable contributions.
        ucm_base_data (DataFrame): Baseline dataset from UCM model.
        level_base_n (str): Name of the level base variable column.

    Returns:
        lagdata_3 (DataFrame): Lagged dataset with contributions applied (long format).
    """

    # Extract beta coefficients from UCM summary and scale them using sc
    contributions = (
        ucm_fin_summary
        .select(
            "variable_apl", "estimate", "approx_std_err", "zvalue", "pvalue_zdist",
            "modelling_cluster", "iteration_number"
        )
        .filter(F.col("variable_apl").like("%beta%"))  # Keep only beta variables (regression coefficients)
        .withColumn("variable_apl",
                    F.regexp_replace(F.col("variable_apl"), "^beta\\.", "")
                    )  # This removes the "beta." prefix from variable names so we can join with sc
        .withColumnRenamed("variable_apl", "var")
        .join(
            sc,
            on=["modelling_cluster", "var"],
            how="left"
        )
        .withColumn("adj_estimate", F.col("estimate") * F.col("ratio"))
        .select(
            F.col("var").alias("variable"),
            "adj_estimate",
            "modelling_cluster",
            "iteration_number"
        )
    )

    # Apply contributions to the lagged dataset
    lagdata_2_filtered = (
        lagdata_2
        .join(
            contributions,
            on=["modelling_cluster", "variable"],
            how="inner"
        )
        .withColumn("value", F.col("value") * F.col("adj_estimate"))
    )

    lagdata_3 = lagdata_2_filtered.select(
        "wdate", "variable", "value", "modelling_cluster", "iteration_number"
    )

    if level_base_n in raw_org.columns:
        raw_org = raw_org.drop(level_base_n)

    # ToDo: check if this is needed, raw_org isn 't returned in the original function but I think it's modified in place
    # Join the baseline trend into the raw baseline data
    raw_org = (
        raw_org
        .join(
            ucm_base_data.select("modelling_cluster", "wdate", level_base_n),
            on=["modelling_cluster", "wdate"],
            how="left"
        )
        .drop("wdate")
    )

    if "level_base" not in raw_org.columns:
        raw_org = raw_org.withColumn("level_base", F.lit(0))

    raw_org = raw_org.withColumn("level_base", F.col(level_base_n))

    # Fill nulls in case of missing joins
    raw_org = raw_org.withColumn("level_base", F.coalesce(F.col("level_base"), F.lit(0)))

    return lagdata_3, raw_org
