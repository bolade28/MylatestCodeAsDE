from typing import List, Optional

from pyspark.sql import functions as F, SparkSession, types as T

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_fb_campaign_normalize(
    spark: SparkSession,
    campaign_bookings_path: str,
    output_path: str,
    correlation_id: str
) -> None:
    """
    This function prepares the facebook campaign normalize data.

    :param spark: The SparkSession object.
    :param campaign_bookings_path: The S3 path for the fb campaigns.
    :param output_path: The S3 path for the output facebook campaigns.
    """

    # Load the required table and filter for META campaigns
    # Discard any bookings without any skus
    # ToDo: the static values should come from a config file
    meta_campaigns = (
        spark
        .read
        .parquet(campaign_bookings_path)
        .withColumn("item_cd_list", F.from_json(F.col("item_cd_list"), ProcessedData.item_schema))  # Parse JSON string to array
        .filter(
            (F.upper(F.col("channel_type")) == "OFFSITE") &
            (F.upper(F.col("media_provider")) == "META") &
            (F.upper(F.col("booking_status")) == "COMPLETED") &
            (F.upper(F.col("media_business_group")).like("%SAINSBURY%")) &
            (F.size(F.col("item_cd_list")) > 0)
        )
        .select
        (
            "booking_id",
            "campaign_id",
            "booking_media_live_start_dt",
            "booking_media_live_end_dt",
            "item_cd_list",
        )
    )

    # Explode ITEM_CD_LIST so we get each sku on its own row
    meta_campaigns_exploded = (
        meta_campaigns
        .withColumn("item", F.explode("item_cd_list"))
        .withColumn("item_cd", F.col("item.skuId"))
        .withColumn("channel", F.lit("Facebook"))
        .withColumnRenamed("booking_media_live_start_dt", "start_dt")
        .withColumnRenamed("booking_media_live_end_dt", "end_dt")
        .select(
            "booking_id",
            "campaign_id",
            "start_dt",
            "end_dt",
            "item_cd",
            "channel"
        )
        .dropna()
    )

    fb_campaign_normalize = (
        meta_campaigns_exploded
        .groupby("booking_id", "campaign_id", "item_cd", "end_dt", "channel")
        .agg(F.max("start_dt").alias("start_dt"))
        .filter(~F.col("end_dt").like("%9999%"))
        .filter(~F.col("campaign_id").like("~~"))
        .filter(~F.col("campaign_id").like("-1"))
        .distinct()
    )

    # Select and transform final columns
    fb_campaign_normalize = (
        fb_campaign_normalize
        .withColumn("jobbagid", F.lit(correlation_id))
        .select(
            F.col("start_dt").cast(T.StringType()),
            F.col("end_dt").cast(T.StringType()),
            F.col("item_cd").cast(T.StringType()),
            F.col("booking_id").cast(T.StringType()),
            F.col("jobbagid").cast(T.StringType()),
            F.col("channel").cast(T.StringType()),
            F.col("campaign_id").cast(T.StringType()),
        )
    )

    # Use custom method to write to s3 destination output
    spark_s3_overwrite(output_path, fb_campaign_normalize)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Facebook Campaigns for baseline pipeline.")
    parser.add_argument(
        "--campaign-bookings-path",
        type=str,
        required=True,
        help="The output S3 path for the fb campaigns."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The path in S3 to output the fb campaigns data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="The global correlation id for the job run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_fb_campaign_normalize(
        spark=spark,
        campaign_bookings_path=known_args.campaign_bookings_path,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("FacebookCampaignNormalize").getOrCreate())
