from typing import List, Optional

from pyspark.sql import functions as F, SparkSession, DataFrame
from pyspark.sql.types import DateType
from pyspark.sql.window import Window

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_fb_campaign_normalize(
    spark: SparkSession,
    fb_campaign: str,
    output_path: str,
    run_date: str,
) -> DataFrame:
    """This function prepares the facebook campaign normalize data.

    :param spark: The SparkSession object.
    :param fb_campaign: The S3 path for the fb campaigns.
    :param output_path: The S3 path for the output facebook campaigns.
    :param run_date: The pipeline run date.
    """

    fb_io_reqd = (
        spark
        .read
        .parquet(fb_campaign)
        .select(
            "CAMPAIGN_ID",
            "CAMPAIGN_START_TS",
            "CAMPAIGN_END_TS",
            "CAMPAIGN_NAME",
            "MEASUREMENT_SKU_LIST",
            "JOB_BAG_ID"
        )
    )

    # Filter test campaigns
    fb_filtered = fb_io_reqd.filter(
        ~F.lower(F.col("CAMPAIGN_NAME")).contains("test")
    )

    # Process SKU list
    fb_processed = fb_filtered.withColumn(
        "MEASUREMENT_SKU_LIST",
        F.regexp_replace(
            F.regexp_replace(
                F.regexp_replace(
                    F.col("MEASUREMENT_SKU_LIST"),
                    "\"", ""
                ),
                r"[\[\]]", ""
            ),
            "\\\\", ""
        )
    ).withColumn(
        "MEASUREMENT_SKU_LIST",
        F.split(F.col("MEASUREMENT_SKU_LIST"), ",")
    ).withColumn(
        "MEASUREMENT_SKU_LIST",
        F.explode("MEASUREMENT_SKU_LIST")
    )

    # Select and transform final columns
    fb_final = fb_processed.select(
        F.col("JOB_BAG_ID").alias("JOBBAGID"),
        F.col("MEASUREMENT_SKU_LIST").alias("ITEM_CD"),
        F.col("CAMPAIGN_START_TS").cast(DateType()).alias("START_DT"),
        F.col("CAMPAIGN_END_TS").cast(DateType()).alias("END_DT"),
        F.col("CAMPAIGN_ID")
    ).filter(
        F.col("JOBBAGID").isNotNull() &
        F.col("JOBBAGID").rlike("^nec.*a$")
    ).withColumn(
        "CHANNEL", F.lit("Facebook")
    )

    # Group and aggregate
    window_spec = Window.partitionBy("JOBBAGID", "CAMPAIGN_ID", "ITEM_CD")
    fb_grouped = fb_final.withColumn(
        "max_START_DT", F.max("START_DT").over(window_spec)
    ).filter(
        F.col("START_DT") == F.col("max_START_DT")
    ).drop("max_START_DT")

    # Final transformations
    fb_campaign_normalized = fb_grouped.select(
        F.col("START_DT"),
        F.col("END_DT"),
        F.col("ITEM_CD").cast("string").substr(1, 1000).alias("ITEM_CD"),
        F.col("JOBBAGID").substr(1, 1000).alias("JOBBAGID"),
        F.col("CHANNEL").cast("string").substr(1, 1000).alias("CHANNEL"),
        F.col("CAMPAIGN_ID").cast("string").substr(1, 1000).alias("CAMPAIGN_ID")
    ).distinct().filter(
        F.col("ITEM_CD").isNotNull() &
        F.col("END_DT").isNotNull()
    )

    # Use custom method to write to s3 destination output
    spark_s3_overwrite(output_path, fb_campaign_normalized)

    return fb_campaign_normalized


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Facebook Campaigns for baseline pipeline.")
    parser.add_argument(
        "--fb-campaign",
        type=str,
        required=True,
        help="The output S3 path for the fb campaigns."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The path in S3 to output the fb campaigns data."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_fb_campaign_normalize(
        spark=spark,
        fb_campaign=known_args.fb_campaign,
        output_path=known_args.output_path,
        run_date=known_args.run_date,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("FacebookCampaignNormalize").getOrCreate())
