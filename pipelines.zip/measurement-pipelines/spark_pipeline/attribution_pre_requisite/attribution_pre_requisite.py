from typing import List, Optional

from pyspark.sql import SparkSession

from spark_pipeline.attribution_pre_requisite.attribution_pre_requisite_helper import create_attribution_pre_requisite
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import EventType
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_attribution_pre_requisite(
        spark: SparkSession,
        measurement_campaign_execution_path: str,
        user_journey_path: str,
        output_path: str,
        journey_type: str,
        run_date: str,
        correlation_id: str,
        slack_topic_arn: str,
) -> None:
    attribution_pre_requisite = create_attribution_pre_requisite(
        spark=spark,
        measurement_campaign_execution_path=measurement_campaign_execution_path,
        user_journey_type_path=user_journey_path,
        journey_type=journey_type,
        run_date=run_date,
        correlation_id=correlation_id,
    )
    slack_messenger = SlackMessenger(
        topic_arn=slack_topic_arn,
        correlation_id=correlation_id
    )
    slack_messenger.send_message(
        event_type=EventType.attribution_pre_requisite,
        text=f"Attribution pre requisite status for {journey_type}",
        data={f"number of rows updated for {journey_type}": attribution_pre_requisite.count()}
    )
    attribution_pre_requisite = (
        attribution_pre_requisite
        .select(
            'loyalty_id',
            'marketing_type',
            'channel_name',
            'subchannel_name',
            'purchase_type',
            'event_ts',
            'event_name',
            'net_sales_amt',
            'transaction_key',
            'campaign_id',
            'booking_id',
            'userjourney_id',
            'position',
            'isconversion',
            'campaign_duration',
            'journey_type',
            'customer_journey_type',
            'regression_variable',
            'load_ts',
            'job_run_id'
        ))

    spark_s3_overwrite(output_path, attribution_pre_requisite)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare attribution pre requisite.")

    parser.add_argument(
        "--measurement-campaign-execution-path",
        type=str,
        required=True,
        help="S3 path for measurement campaign execution data."
    )
    parser.add_argument(
        "--user-journey-path",
        type=str,
        required=True,
        help="S3 path for user journey data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for output of user journey aisle."
    )
    parser.add_argument(
        "--journey-type",
        type=str,
        required=True,
        help="Journey path to choose a specific product type whether its brand, aisle or offer."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for traceability."
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN of the Slack topic for notifications."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    # Call your main processing function here
    prepare_attribution_pre_requisite(
        spark=spark,
        measurement_campaign_execution_path=known_args.measurement_campaign_execution_path,
        user_journey_path=known_args.user_journey_path,
        output_path=known_args.output_path,
        journey_type=known_args.journey_type,
        run_date=known_args.run_date,
        correlation_id=known_args.correlation_id,
        slack_topic_arn=known_args.slack_topic_arn,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("AttributionPreRequisite").getOrCreate())
