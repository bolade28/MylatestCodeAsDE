from pyspark.sql import functions as F, types as T, DataFrame
from pyspark.sql.window import Window
from pyspark.sql import SparkSession

from spark_pipeline.common.variables import AttributionPreRequisitesConfig, EventName

"""
    Objective - The objective of this script is to create regression variables and classify user journeys (as "Direct" or "Non-direct") by
    calculating total touchpoints from user journey brand data. It processes campaign data, cleans and transforms regression variables and
    prepares a dataset for machine learning models to analyze customer behavior and marketing attribution.
        Confluence Link : https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/852498406/ADS+-+Attribution+Pre-requisites
        Upstream: USER_JOURNEY_BRAND, MEASUREMENT_CAMPAIGN_EXECUTION
        Downstream: MTA_ATTRIBUTION_MODEL_RESULT_BRAND
    This script will return create regression variable and type of user journey by calculating total touchpoint from user journey brand table.
"""


def create_clean_regvarlist_expr(columns_to_concat):
    """
    Create a cleaned regression variable expression from a list of columns.

    Concatenates column values with underscores and replaces all non-alphanumeric
    characters (except underscores) with underscores. This ensures consistent
    feature names for downstream model training and joins.

    Args:
        columns_to_concat: List of column names to concatenate

    Returns:
        PySpark Column expression with cleaned concatenated values

    Output Example:
        Input: ['email-marketing', 'newsletter', 'camp-123']
        Output: 'email_marketing_newsletter_camp_123'
    """
    # First concatenate the columns
    result = F.concat_ws("_", *[F.col(column) for column in columns_to_concat])

    # Replace all non-alphanumeric characters (except underscores) with underscores
    result = F.regexp_replace(result, "[^a-zA-Z0-9_]", "_")

    return result


def create_attribution_pre_requisite(
        spark: SparkSession,
        measurement_campaign_execution_path: str,
        user_journey_type_path: str,
        journey_type: str,
        run_date: str,
        correlation_id: str
) -> DataFrame:
    # getting the in progress booking id  as we will run for in progress booking id only
    campaign_booking_id = (
        spark
        .read
        .parquet(measurement_campaign_execution_path)
        .select(
            'booking_id',
            'campaign_duration',
        )
        .distinct()
    )

    campaign_bc = F.broadcast(campaign_booking_id)

    user_journey_df = (
        spark
        .read
        .parquet(user_journey_type_path)
        .select(
            'loyalty_id',
            'transaction_key',
            'event_ts',
            'purchase_type',
            'channel_name',
            'subchannel_name',
            'event_name',
            'booking_id',
            'campaign_id',
            'sub_path',
            'userjourney_id',
            'rank',
            'position',
            'isconversion',
            'load_ts',
            'campaign_duration',
            'job_run_id',
            'marketing_type',
            'net_sales_amt',
            'units_qty',
            'journey_type'
        )
    )

    """
    Creating the regression variable column by concatenating configured columns.
    This regression_variable will be used as a feature identifier in downstream
    attribution model training and analysis.

    Note: The regression variable list is read from AttributionPreRequisitesConfig to ensure
    consistency with downstream attribution modelling. Default includes marketing_type,
    subchannel_name, and campaign_id which provides:
    - Compatibility with synergy analysis
    - Prevents the potential issue of different marketing types/subchannels having the same
      campaign_id which can lead to incorrect attribution in the model
    """
    config = AttributionPreRequisitesConfig()
    regvarlist_expr = create_clean_regvarlist_expr(config.regression_variable_list)

    # For Transaction rows the CDC rebuild clears channel/subchannel/campaign_id to '',
    # so concatenating them would produce an empty/meaningless string.
    # Use event_name directly so transaction rows get regression_variable = 'Transaction',
    # which is excluded from model pivot columns by the dataset_helper filters.
    regvarlist_with_transaction_override = (
        F.when(
            F.col('event_name') == EventName.TRANSACTION.value,
            F.col('event_name'),
        ).otherwise(regvarlist_expr)
    )

    user_journey_clean = (
        user_journey_df
        .join(campaign_bc,
              on=["booking_id", "campaign_duration"],
              how="inner"
              )
        .select(
            'loyalty_id',
            'marketing_type',
            'channel_name',
            'subchannel_name',
            'purchase_type',
            'event_ts',
            'event_name',
            'net_sales_amt',
            'transaction_key',
            'campaign_id',
            'booking_id',
            'userjourney_id',
            'position',
            'isconversion',
            'campaign_duration',
            regvarlist_with_transaction_override.alias('regvarlist')
        )
    )
    # calculating total touchpoints to classify the journey ad direct or non-direct
    window_spec = Window.partitionBy('booking_id', 'userjourney_id', 'campaign_duration')

    user_journey_regression = (
        user_journey_clean
        .select(
            'loyalty_id',
            'marketing_type',
            'channel_name',
            'subchannel_name',
            'purchase_type',
            'event_ts',
            'event_name',
            'net_sales_amt',
            'transaction_key',
            'campaign_id',
            'booking_id',
            'userjourney_id',
            'position',
            'isconversion',
            'regvarlist',
            'campaign_duration',
            F.sum(
                F.when(F.col('event_name') == EventName.TOUCHPOINT.value, 1).otherwise(0)
            ).over(window_spec).alias('total_touchpoint')
        )
    )

    """
    In case no of touchpoints is greater than 1 then it is non direct else direct
    1. Persisting the final output of the model in the table attribution_pre_requisite_aisle
    2. The table will be used as input for the machine learning model script.
    3. Type casting the columns to the required data types.
    """
    attribution_pre_requisite = (
        user_journey_regression
        .withColumn('subchannel_name', F.coalesce('subchannel_name', F.lit('NA')))
        .withColumn('journey_type', F.lit(journey_type))
        .withColumn('customer_journey_type',
                    F.when(F.col('total_touchpoint') == 1, 'Direct').otherwise('Non-direct'))
        .withColumn('regression_variable', F.col('regvarlist'))
        .withColumn('load_ts', F.lit(run_date))
        .withColumn('job_run_id', F.lit(correlation_id))
        .select(
            F.col('loyalty_id').cast(T.StringType()),
            F.col('marketing_type').cast(T.StringType()),
            F.col('channel_name').cast(T.StringType()),
            F.col('subchannel_name').cast(T.StringType()),
            F.col('purchase_type').cast(T.StringType()),
            F.col('event_ts').cast(T.TimestampType()),
            F.col('event_name').cast(T.StringType()),
            F.col('net_sales_amt').cast(T.DecimalType(38, 4)),
            F.col('transaction_key').cast(T.StringType()),
            F.col('campaign_id').cast(T.StringType()),
            F.col('booking_id').cast(T.StringType()),
            F.col('userjourney_id').cast(T.StringType()),
            F.col('position').cast(T.StringType()),
            F.col('isconversion').cast(T.IntegerType()),
            F.col('campaign_duration').cast(T.StringType()),
            F.col('journey_type').cast(T.StringType()),
            F.col('customer_journey_type').cast(T.StringType()),
            F.col('regression_variable').cast(T.StringType()),
            F.col('load_ts').cast(T.TimestampType()),
            F.col('job_run_id').cast(T.StringType())
        )
        .dropDuplicates()
    )

    return attribution_pre_requisite
