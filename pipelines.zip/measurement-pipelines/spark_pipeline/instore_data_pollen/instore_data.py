from typing import List, Optional, Sequence

from pyspark.sql import SparkSession

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser, str_to_bool
from spark_pipeline.instore_data_pollen.instore_data_helper import (
    create_campaign_date_range,
    create_store_location,
    finalise_instore_data,
    get_campaign_window_baskets,
    get_campaign_window_items,
    get_channel_transactions,
    get_in_scope_campaigns,
    get_instore_converted_touchpoints,
    get_instore_nonconverted_touchpoints,
    get_instore_relevant_transactions,
    get_loyalty_transactions,
    get_min_timestamp,
    get_online_touchpoints,
    get_online_transactions,
    get_post_period_customers,
    get_store_location,
    get_targeted_skus,
    get_unified_campaigns,
    get_unified_data,
    union_instore_data_collection,
)
from spark_pipeline.schemas.instore_data_pollen import InStoreDataPollen
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite
from spark_pipeline.utils.stdout_logger import StdOutLogger

logger = StdOutLogger()


def prepare_instore_data_pollen(
    spark: SparkSession,
    measurement_campaign_execution_status_path: str,
    measurement_unified_campaign_pollen_path: str,
    campaign_booking_media_channel_path: str,
    campaign_product_type_path: str,
    fact_sale_transaction_basket_path: str,
    fact_sale_transaction_item_path: str,
    dim_customer_loyalty_path: str,
    output_path: str,
    correlation_id: str,
    hierarchy_codes: Sequence[int],
    sales_origination_all_codes: Sequence[int],
    sales_origination_instore_codes: Sequence[int],
    sales_origination_online_codes: Sequence[int],
    campaign_duration_is_post: bool,
    transaction_event_name: str,
    touchpoint_event_name: str,
    during_correlation_id: Optional[str] = None,
    customer_data_collection_path: Optional[str] = None,
) -> None:
    logger.info("STARTING IN-STORE POLLEN DATA PROCESSING")

    campaign_execution_status = (
        spark
        .read
        .parquet(measurement_campaign_execution_status_path)
        .select(
            "campaign_name",
            "channel_name",
            "subchannel_name",
            "campaign_start_dt",
            "campaign_end_dt",
            "campaign_id",
            "booking_id",
            "campaign_duration",
            "marketing_type",
            "marketing_hierarchy_cd",
            "job_bag_number",
        )
    )

    unified_campaign_source_df = (
        spark
        .read
        .parquet(measurement_unified_campaign_pollen_path)
        .select(
            "campaign_id",
            "job_bag_number",
            "channel_name",
            "subchannel_name",
            "marketing_type",
            "campaign_start_dt",
            "campaign_end_dt",
            "post_campaign_dt",
        )
    )

    campaign_booking_media_channel_df = (
        spark
        .read
        .parquet(campaign_booking_media_channel_path)
        .select("campaign_id", "booking_id", "store_cd_list")
    )

    campaign_product_type_df = (
        spark
        .read
        .parquet(campaign_product_type_path)
        .select(
            "campaign_id",
            "channel_name",
            "subchannel_name",
            "load_ts",
            "product_type",
            "unique_brand_name",
            "item_cd",
        )
    )

    fact_sale_transaction_basket_df = (
        spark
        .read
        .parquet(fact_sale_transaction_basket_path)
        .select(
            "transaction_end_ts",
            "nectar_card_num_hash",
            "transaction_id",
            "transaction_dt",
            "sales_origination_channel_cd",
        )
    )

    fact_sale_transaction_item_df = (
        spark
        .read
        .parquet(fact_sale_transaction_item_path)
        .select(
            "transaction_id",
            "transaction_dt",
            "item_cd",
            "net_retail_sales_amt",
            "item_qty",
            "item_sequence_num",
            "store_cd",
        )
    )

    dim_customer_loyalty_df = (
        spark
        .read
        .parquet(dim_customer_loyalty_path)
        .select(
            "nectar_collector_card_num",
            "household_num",
            "customer_account_type_name",
            "customer_loyalty_cd",
        )
    )

    campaign_details_df = get_in_scope_campaigns(campaign_execution_status, hierarchy_codes)

    min_campaign_start_dt, max_campaign_end_dt = create_campaign_date_range(campaign_details_df)
    logger.info(f"Campaign window: {min_campaign_start_dt} to {max_campaign_end_dt}")

    basket_df = get_campaign_window_baskets(
        fact_sale_transaction_basket_df,
        min_campaign_start_dt,
        max_campaign_end_dt,
        sales_origination_all_codes,
    )
    item_df = get_campaign_window_items(
        fact_sale_transaction_item_df,
        min_campaign_start_dt,
        max_campaign_end_dt,
    )
    loyalty_transactions_df = get_loyalty_transactions(dim_customer_loyalty_df, basket_df, item_df)
    instore_transactions_df = get_channel_transactions(loyalty_transactions_df, sales_origination_instore_codes)
    online_transactions_df = get_channel_transactions(loyalty_transactions_df, sales_origination_online_codes)

    store_location_df = create_store_location(campaign_booking_media_channel_df, campaign_execution_status)
    in_scope_store_location_df = get_store_location(store_location_df, campaign_details_df)

    targeted_skus_df = get_targeted_skus(campaign_product_type_df, campaign_details_df)
    matched_unified_campaigns_df = get_unified_campaigns(unified_campaign_source_df, campaign_details_df)
    unified_data_df = get_unified_data(matched_unified_campaigns_df)

    post_period_customers_df = None
    if campaign_duration_is_post:
        logger.info(f"Post run: keeping customers from During run {during_correlation_id}")
        customer_data_collection_df = (
            spark
            .read
            .parquet(customer_data_collection_path)
            .select(
                "job_run_id",
                "loyalty_id",
                "campaign_id",
                "channel_name",
                "subchannel_name",
                "marketing_type",
                "event_dt",
            )
        )
        post_period_customers_df = get_post_period_customers(
            matched_unified_campaigns_df,
            customer_data_collection_df,
            during_correlation_id,
        )

    instore_relevant_transaction_df = get_instore_relevant_transactions(
        instore_transactions_df,
        targeted_skus_df,
        campaign_details_df,
        in_scope_store_location_df,
        transaction_event_name,
        post_period_customers_df,
    )
    instore_converted_touchpoint_df = get_instore_converted_touchpoints(
        instore_relevant_transaction_df,
        campaign_details_df,
        unified_data_df,
        touchpoint_event_name,
    )
    instore_nonconverted_touchpoint_df = get_instore_nonconverted_touchpoints(
        instore_transactions_df,
        campaign_details_df,
        in_scope_store_location_df,
        unified_data_df,
        targeted_skus_df,
        instore_converted_touchpoint_df,
        touchpoint_event_name,
    )
    min_timestamp_df = get_min_timestamp(instore_relevant_transaction_df, instore_nonconverted_touchpoint_df)
    online_transaction_df = get_online_transactions(
        online_transactions_df,
        min_timestamp_df,
        targeted_skus_df,
        campaign_details_df,
        transaction_event_name,
    )
    online_touchpoint_df = get_online_touchpoints(
        online_transaction_df,
        min_timestamp_df,
        campaign_details_df,
        unified_data_df,
        touchpoint_event_name,
    )

    instore_data_collection_df = union_instore_data_collection(
        instore_relevant_transaction_df,
        instore_converted_touchpoint_df,
        instore_nonconverted_touchpoint_df,
        online_transaction_df,
        online_touchpoint_df,
    )
    final_instore_data_df = finalise_instore_data(instore_data_collection_df, correlation_id)

    if final_instore_data_df.isEmpty():
        logger.warning("No in-store data produced, writing empty output")
        final_instore_data_df = spark.createDataFrame([], InStoreDataPollen.schema)

    spark_s3_overwrite(output_path, final_instore_data_df)

    logger.info("PROCESSING COMPLETED SUCCESSFULLY")


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare in-store pollen customer engagement data.")

    parser.add_argument(
        "--measurement-campaign-execution-status-path",
        type=str,
        required=True,
        help="S3 path for measurement campaign execution status data."
    )
    parser.add_argument(
        "--measurement-unified-campaign-pollen-path",
        type=str,
        required=True,
        help="S3 path for measurement unified campaign pollen data."
    )
    parser.add_argument(
        "--campaign-booking-media-channel-path",
        type=str,
        required=True,
        help="S3 path for campaign booking media channel data."
    )
    parser.add_argument(
        "--campaign-product-type-path",
        type=str,
        required=True,
        help="S3 path for campaign product type data."
    )
    parser.add_argument(
        "--fact-sale-transaction-basket-path",
        type=str,
        required=True,
        help="S3 path for fact sale transaction basket data."
    )
    parser.add_argument(
        "--fact-sale-transaction-item-path",
        type=str,
        required=True,
        help="S3 path for fact sale transaction item data."
    )
    parser.add_argument(
        "--dim-customer-loyalty-path",
        type=str,
        required=True,
        help="S3 path for dim customer loyalty data."
    )
    parser.add_argument(
        "--customer-data-collection-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for customer data collection data (Post runs only)."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for output of in-store pollen data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for traceability."
    )
    parser.add_argument(
        "--during-correlation-id",
        type=str,
        required=False,
        default=None,
        help="Correlation ID of the During run (Post runs only)."
    )
    parser.add_argument(
        "--hierarchy-codes",
        type=int,
        nargs="+",
        required=True,
        help="In-store marketing hierarchy codes."
    )
    parser.add_argument(
        "--sales-origination-all-codes",
        type=int,
        nargs="+",
        required=True,
        help="Sales origination codes for all channels."
    )
    parser.add_argument(
        "--sales-origination-instore-codes",
        type=int,
        nargs="+",
        required=True,
        help="Sales origination codes for in-store."
    )
    parser.add_argument(
        "--sales-origination-online-codes",
        type=int,
        nargs="+",
        required=True,
        help="Sales origination codes for online."
    )
    parser.add_argument(
        "--campaign-duration-is-post",
        type=str,
        required=True,
        help="Whether this is a Post campaign run (true/false)."
    )
    parser.add_argument(
        "--transaction-event-name",
        type=str,
        required=True,
        help="Event name for transaction rows."
    )
    parser.add_argument(
        "--touchpoint-event-name",
        type=str,
        required=True,
        help="Event name for touchpoint rows."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    campaign_duration_is_post = str_to_bool(known_args.campaign_duration_is_post)
    if campaign_duration_is_post and not (known_args.customer_data_collection_path and known_args.during_correlation_id):
        parser.error(
            "--customer-data-collection-path and --during-correlation-id are required "
            "when --campaign-duration-is-post is true"
        )

    prepare_instore_data_pollen(
        spark=spark,
        measurement_campaign_execution_status_path=known_args.measurement_campaign_execution_status_path,
        measurement_unified_campaign_pollen_path=known_args.measurement_unified_campaign_pollen_path,
        campaign_booking_media_channel_path=known_args.campaign_booking_media_channel_path,
        campaign_product_type_path=known_args.campaign_product_type_path,
        fact_sale_transaction_basket_path=known_args.fact_sale_transaction_basket_path,
        fact_sale_transaction_item_path=known_args.fact_sale_transaction_item_path,
        dim_customer_loyalty_path=known_args.dim_customer_loyalty_path,
        customer_data_collection_path=known_args.customer_data_collection_path,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id,
        during_correlation_id=known_args.during_correlation_id,
        hierarchy_codes=known_args.hierarchy_codes,
        sales_origination_all_codes=known_args.sales_origination_all_codes,
        sales_origination_instore_codes=known_args.sales_origination_instore_codes,
        sales_origination_online_codes=known_args.sales_origination_online_codes,
        campaign_duration_is_post=campaign_duration_is_post,
        transaction_event_name=known_args.transaction_event_name,
        touchpoint_event_name=known_args.touchpoint_event_name,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("InStoreDataPollen").getOrCreate())
