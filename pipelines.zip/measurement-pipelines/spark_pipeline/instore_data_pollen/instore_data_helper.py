from datetime import date
from typing import Optional, Sequence, Tuple

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from spark_pipeline.schemas.instore_data_pollen import InStoreDataPollen


def campaign_details_for_join(campaign_details_df: DataFrame) -> DataFrame:
    """Distinct campaign columns used by the in-store joins."""
    return (
        campaign_details_df
        .select(
            "campaign_id",
            "campaign_name",
            "channel_name",
            "subchannel_name",
            "campaign_start_dt",
            "campaign_end_dt",
            "booking_id",
            "marketing_type",
        )
        .distinct()
    )


def store_locations_for_join(in_scope_store_location_df: DataFrame) -> DataFrame:
    """Distinct campaign stores, with store_ prefixed column names."""
    return (
        in_scope_store_location_df
        .select(
            F.col("campaign_id").alias("store_campaign_id"),
            F.col("location_key").alias("store_location_key"),
        )
        .distinct()
    )


def get_in_scope_campaigns(
    campaign_execution_status: DataFrame,
    hierarchy_codes: Sequence[int],
) -> DataFrame:
    """
    Get all in-scope in-store campaigns.

    Keeps only campaigns with marketing_hierarchy_cd in hierarchy_codes.

    Returns one distinct row per campaign.
    """
    campaign_details_df = (
        campaign_execution_status
        .filter(F.col("marketing_hierarchy_cd").isin([str(c) for c in hierarchy_codes]))
        .select(
            "campaign_name",
            "channel_name",
            "subchannel_name",
            "campaign_start_dt",
            "campaign_end_dt",
            "campaign_id",
            "booking_id",
            "campaign_duration",
            "marketing_type",
            "marketing_hierarchy_cd",
        )
        .distinct()
    )

    return campaign_details_df


def create_campaign_date_range(campaign_details_df: DataFrame) -> Tuple[date, date]:
    """
    Build campaign date bounds for in-scope campaigns.

    Returns min_campaign_start_dt and max_campaign_end_dt.
    """
    campaign_date_range = (
        campaign_details_df
        .agg(
            F.min("campaign_start_dt").alias("min_campaign_start_dt"),
            F.max("campaign_end_dt").alias("max_campaign_end_dt"),
        )
        .first()
    )

    return campaign_date_range["min_campaign_start_dt"], campaign_date_range["max_campaign_end_dt"]


def get_loyalty_transactions(
    dim_customer_loyalty_df: DataFrame,
    basket_df: DataFrame,
    item_df: DataFrame,
) -> DataFrame:
    """
    Join valid Nectar customers to their basket and item rows.

    Customer filters:
    - nectar_collector_card_num != '~~'
    - household_num != '0'
    - customer_account_type_name is 'NECTAR' (case-insensitive)

    Reused by the in-store, non-converted and online steps.
    """
    valid_loyalty_df = (
        dim_customer_loyalty_df
        .filter(F.col("nectar_collector_card_num") != "~~")
        .filter(F.col("household_num") != "0")
        .filter(F.upper(F.col("customer_account_type_name")) == "NECTAR")
        .select(
            "nectar_collector_card_num",
            "customer_loyalty_cd",
        )
        .withColumnRenamed("nectar_collector_card_num", "loyalty_id")
    )

    loyalty_transactions_df = (
        basket_df
        .join(valid_loyalty_df, F.col("nectar_card_num_hash") == F.col("customer_loyalty_cd"), "inner")
        .join(item_df, ["transaction_id", "transaction_dt"], "inner")
        .select(
            "loyalty_id",
            "transaction_id",
            "transaction_dt",
            "transaction_end_ts",
            "sales_origination_channel_cd",
            "item_cd",
            "net_retail_sales_amt",
            "item_qty",
            "item_sequence_num",
            "store_cd",
        )
    )

    return loyalty_transactions_df


def get_channel_transactions(loyalty_transactions_df: DataFrame, channel_codes: Sequence[int]) -> DataFrame:
    """
    Keeps loyalty transactions whose sales_origination_channel_cd is in channel_codes.
    """
    return loyalty_transactions_df.filter(
        F.col("sales_origination_channel_cd").cast("int").isin(list(channel_codes))
    )


def get_store_location(
    store_location_df: DataFrame,
    campaign_details_df: DataFrame,
) -> DataFrame:
    """
    Keep store locations for in-scope campaigns only.

    - Semi-joins store_location to campaign_details on campaign_id
    - Returns distinct location_key, campaign_id
    """
    in_scope_store_location_df = (
        store_location_df
        .join(campaign_details_df.select("campaign_id"), "campaign_id", "left_semi")
        .select("location_key", "campaign_id")
        .distinct()
    )

    return in_scope_store_location_df


def get_unified_campaigns(
    unified_campaign_source_df: DataFrame,
    campaign_details_df: DataFrame,
) -> DataFrame:
    """
    Match unified campaigns to in-scope campaigns.

    Joins unified campaign source rows to campaign_details on:
    - job_bag_number = booking_id
    - channel_name, subchannel_name, marketing_type, campaign_start_dt

    Shared by get_unified_data and get_post_period_customers.
    """
    unified_campaign_join_df = (
        unified_campaign_source_df
        .select(
            "campaign_id",
            "job_bag_number",
            "channel_name",
            "subchannel_name",
            "marketing_type",
            "campaign_start_dt",
            "campaign_end_dt",
            "post_campaign_dt",
        )
    )

    campaign_details_join_df = (
        campaign_details_df
        .select(
            F.col("booking_id").alias("job_bag_number"),
            "channel_name",
            "subchannel_name",
            "marketing_type",
            "campaign_start_dt",
            F.col("campaign_end_dt").alias("cd_campaign_end_dt"),
        )
        .distinct()
    )

    matched_unified_campaigns_df = (
        unified_campaign_join_df
        .join(
            F.broadcast(campaign_details_join_df),
            on=["job_bag_number", "channel_name", "subchannel_name", "marketing_type", "campaign_start_dt"],
            how="inner",
        )
    )

    return matched_unified_campaigns_df


def get_unified_data(matched_unified_campaigns_df: DataFrame) -> DataFrame:
    """
    Get overall campaign dates per unified campaign.

    Returns uc_campaign_id with its earliest start and latest end date.
    """
    unified_data_df = (
        matched_unified_campaigns_df
        .groupBy(F.col("campaign_id").alias("uc_campaign_id"))
        .agg(
            F.min("campaign_start_dt").alias("uc_campaign_start_dt"),
            F.max("campaign_end_dt").alias("uc_campaign_end_dt"),
        )
    )

    return unified_data_df


def get_post_period_customers(
    matched_unified_campaigns_df: DataFrame,
    customer_data_collection_df: DataFrame,
    during_correlation_id: str,
) -> DataFrame:
    """
    Get customers seen in the 'During' run.

    - Keeps unified campaigns where LEAST(post_campaign_dt, today) <= campaign_end_dt
    - Keeps customer rows from the 'During' run (job_run_id = during_correlation_id)
    - Matches them on campaign, channel, subchannel, marketing type and event date
    - Returns customers with post_ prefixed column names

    Only used for POST runs.
    """
    unified_post_df = (
        matched_unified_campaigns_df
        .filter(F.least(F.col("post_campaign_dt"), F.current_date()) <= F.col("cd_campaign_end_dt"))
        .select(
            "campaign_id",
            "channel_name",
            "subchannel_name",
            "marketing_type",
            "campaign_start_dt",
            "campaign_end_dt",
        )
        .withColumnRenamed("campaign_id", "uc_campaign_id")
        .withColumnRenamed("channel_name", "uc_channel_name")
        .withColumnRenamed("subchannel_name", "uc_subchannel_name")
        .withColumnRenamed("marketing_type", "uc_marketing_type")
        .withColumnRenamed("campaign_start_dt", "uc_campaign_start_dt")
        .withColumnRenamed("campaign_end_dt", "uc_campaign_end_dt")
        .distinct()
    )

    post_period_customers_df = (
        customer_data_collection_df
        .filter(F.col("job_run_id") == during_correlation_id)
        .select(
            "loyalty_id",
            F.col("campaign_id").cast("string").alias("campaign_id"),
            "channel_name",
            "subchannel_name",
            "marketing_type",
            "event_dt",
        )
        .join(
            F.broadcast(unified_post_df),
            (F.col("campaign_id") == F.col("uc_campaign_id"))
            & (F.col("channel_name") == F.col("uc_channel_name"))
            & (F.col("subchannel_name") == F.col("uc_subchannel_name"))
            & (F.col("marketing_type") == F.col("uc_marketing_type"))
            & F.col("event_dt").between(F.col("uc_campaign_start_dt"), F.col("uc_campaign_end_dt")),
            "inner",
        )
        .withColumnRenamed("loyalty_id", "post_loyalty_id")
        .withColumnRenamed("uc_campaign_id", "post_campaign_id")
        .withColumnRenamed("uc_channel_name", "post_channel_name")
        .withColumnRenamed("uc_subchannel_name", "post_subchannel_name")
        .withColumnRenamed("uc_marketing_type", "post_marketing_type")
        .select(
            "post_loyalty_id",
            "post_campaign_id",
            "post_channel_name",
            "post_subchannel_name",
            "post_marketing_type",
        )
    )

    return post_period_customers_df


def get_campaign_window_baskets(
    fact_sale_transaction_basket_df: DataFrame,
    min_campaign_start_dt: date,
    max_campaign_end_dt: date,
    sales_origination_all_codes: Sequence[int],
) -> DataFrame:
    """
    Filter basket transactions to the campaign date window.

    Keeps only:
    - non-null nectar_card_num_hash
    - transaction_dt between campaign min/max bounds
    - sales_origination_channel_cd in sales_origination_all_codes
    """
    fact_sale_transaction_basket_filtered_df = (
        fact_sale_transaction_basket_df
        .filter(F.col("nectar_card_num_hash").isNotNull())
        .filter(F.col("transaction_dt").between(min_campaign_start_dt, max_campaign_end_dt))
        .filter(F.col("sales_origination_channel_cd").cast("int").isin(list(sales_origination_all_codes)))
    )

    return fact_sale_transaction_basket_filtered_df


def get_campaign_window_items(
    fact_sale_transaction_item_df: DataFrame,
    min_campaign_start_dt: date,
    max_campaign_end_dt: date,
) -> DataFrame:
    """
    Filter item-level transactions to the campaign date window.

    Keeps only:
    - transaction_dt between campaign min/max bounds
    - positive net_retail_sales_amt
    """
    fact_sale_transaction_item_filtered_df = (
        fact_sale_transaction_item_df
        .filter(F.col("transaction_dt").between(min_campaign_start_dt, max_campaign_end_dt))
        .filter(F.col("net_retail_sales_amt") > 0)
    )

    return fact_sale_transaction_item_filtered_df


def get_targeted_skus(
    campaign_product_type_df: DataFrame,
    campaign_details_df: DataFrame,
) -> DataFrame:
    """
    Get targeted SKUs for all in-scope campaigns.

    - Keeps product rows for in-scope campaigns
    - Keeps only the latest load_ts per campaign, channel and subchannel
    - Returns distinct SKUs with sku_ prefixed column names
    """
    keys = ["campaign_id", "channel_name", "subchannel_name"]

    in_scope_products_df = (
        campaign_product_type_df
        .withColumn("campaign_id", F.col("campaign_id").cast("string"))
        .join(F.broadcast(campaign_details_df.select(*keys)), keys, "left_semi")
    )

    latest_load_window = Window.partitionBy(*keys).rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)

    targeted_skus_df = (
        in_scope_products_df
        .withColumn("max_load_ts", F.max("load_ts").over(latest_load_window))
        .filter(F.col("load_ts") == F.col("max_load_ts"))
        .withColumnRenamed("product_type", "sku_product_type")
        .withColumnRenamed("unique_brand_name", "sku_brand_name")
        .withColumnRenamed("item_cd", "sku_item_cd")
        .withColumnRenamed("campaign_id", "sku_campaign_id")
        .withColumnRenamed("channel_name", "sku_channel_name")
        .withColumnRenamed("subchannel_name", "sku_subchannel_name")
        .select(
            "sku_product_type",
            "sku_brand_name",
            "sku_item_cd",
            "sku_campaign_id",
            "sku_channel_name",
            "sku_subchannel_name",
        )
        .distinct()
    )

    return targeted_skus_df


def create_store_location(
    campaign_booking_media_channel_df: DataFrame,
    campaign_execution_status: DataFrame,
) -> DataFrame:
    """
    Build exploded campaign-to-store mapping from booking media channel data.

    - Drops rows with no store list
    - Parses store_cd_list (JSON array string) into an array of strings
    - Joins to campaign filters on any of:
      booking_id/campaign_id vs job_bag_number, booking_id, campaign_id
    - Explodes into one location_key per row
    - Returns distinct campaign_id, location_key, booking_id
    """
    campaign_filters_df = (
        campaign_execution_status
        .select(
            "job_bag_number",
            "booking_id",
            "campaign_id",
        )
        .distinct()
    )

    st_loc = (
        campaign_booking_media_channel_df
        .filter(F.col("store_cd_list").isNotNull())
        .select(
            F.col("campaign_id").cast("string").alias("campaign_id"),
            F.col("booking_id").cast("string").alias("booking_id"),
            F.from_json(F.col("store_cd_list"), "array<string>").alias("store_cd_array"),
        )
    )

    join_cond = (
        (st_loc["booking_id"] == campaign_filters_df["job_bag_number"])
        | (st_loc["campaign_id"] == campaign_filters_df["job_bag_number"])
        | (st_loc["booking_id"] == campaign_filters_df["booking_id"])
        | (st_loc["campaign_id"] == campaign_filters_df["campaign_id"])
    )

    store_location_df = (
        st_loc
        .join(F.broadcast(campaign_filters_df), join_cond, "inner")
        .select(
            st_loc["campaign_id"].alias("campaign_id"),
            st_loc["booking_id"].alias("booking_id"),
            F.explode(st_loc["store_cd_array"]).alias("location_key"),
        )
        .select("campaign_id", "location_key", "booking_id")
        .dropDuplicates(["campaign_id", "location_key", "booking_id"])
    )

    return store_location_df


def get_instore_relevant_transactions(
    instore_transactions_df: DataFrame,
    targeted_skus_df: DataFrame,
    campaign_details_df: DataFrame,
    in_scope_store_location_df: DataFrame,
    transaction_event_name: str,
    post_period_customers_df: Optional[DataFrame] = None,
) -> DataFrame:
    """
    In-store purchases of targeted SKUs, in campaign stores, during the campaign

    - Expects in-store channel transactions only
    - Item must be a targeted SKU for the campaign
    - Transaction date within the campaign start and end dates
    - Store must be one of the campaign's stores
    - POST runs only: customer must be in post_period_customers_df
    - Sums sales and units per transaction line
    """
    campaign_details_join_df = campaign_details_for_join(campaign_details_df)
    store_location_join_df = store_locations_for_join(in_scope_store_location_df)

    matched_df = (
        instore_transactions_df
        .join(F.broadcast(targeted_skus_df), F.col("item_cd") == F.col("sku_item_cd"), "inner")
        .join(
            F.broadcast(campaign_details_join_df),
            (F.col("sku_campaign_id") == F.col("campaign_id"))
            & (F.col("sku_channel_name") == F.col("channel_name"))
            & (F.col("sku_subchannel_name") == F.col("subchannel_name"))
            & F.col("transaction_dt").between(F.col("campaign_start_dt"), F.col("campaign_end_dt")),
            "inner",
        )
        .join(
            F.broadcast(store_location_join_df),
            (F.col("store_cd").cast("string") == F.col("store_location_key"))
            & (F.col("campaign_id") == F.col("store_campaign_id")),
            "inner",
        )
    )

    if post_period_customers_df is not None:
        matched_df = matched_df.join(
            post_period_customers_df,
            (F.col("loyalty_id") == F.col("post_loyalty_id"))
            & (F.col("campaign_id") == F.col("post_campaign_id"))
            & (F.col("channel_name") == F.col("post_channel_name"))
            & (F.col("subchannel_name") == F.col("post_subchannel_name"))
            & (F.col("marketing_type") == F.col("post_marketing_type")),
            "left_semi",
        )

    instore_relevant_transaction_df = (
        matched_df
        .select(
            "loyalty_id",
            F.col("transaction_id").alias("transaction_key"),
            F.col("transaction_dt").alias("event_date"),
            "item_cd",
            F.col("transaction_end_ts").alias("event_time"),
            F.lit("NA").alias("marketing_type"),
            F.lit("instore").alias("purchase_type"),
            F.col("channel_name").alias("channel"),
            F.col("subchannel_name").alias("subchannel"),
            F.col("campaign_name").alias("campaign_name"),
            F.col("campaign_id").alias("campaign_id"),
            F.lit(transaction_event_name).alias("event_name"),
            F.col("booking_id").alias("booking_id"),
            F.col("sku_product_type").alias("product_type"),
            F.col("sku_brand_name").alias("unique_brand_name"),
            "net_retail_sales_amt",
            "item_qty",
        )
        .groupBy(
            "loyalty_id", "event_date", "event_time", "transaction_key", "item_cd",
            "unique_brand_name", "marketing_type", "channel", "subchannel", "campaign_name",
            "campaign_id", "event_name", "booking_id", "product_type", "purchase_type",
        )
        .agg(
            F.sum("net_retail_sales_amt").alias("net_targetted_sales"),
            F.sum("item_qty").alias("units"),
        )
    )

    return instore_relevant_transaction_df


def get_instore_converted_touchpoints(
    instore_relevant_transaction_df: DataFrame,
    campaign_details_df: DataFrame,
    unified_data_df: DataFrame,
    touchpoint_event_name: str,
) -> DataFrame:
    """
    One touchpoint per converting in-store transaction.

    - Joins each relevant transaction back to its campaign
    - Event date must be on or before the unified campaign end date
    """
    instore_converted_touchpoint_df = (
        instore_relevant_transaction_df
        .select("loyalty_id", "transaction_key", "event_date", "event_time", "campaign_id")
        .join(F.broadcast(campaign_details_df), "campaign_id", "inner")
        .join(
            F.broadcast(unified_data_df),
            (F.col("campaign_id") == F.col("uc_campaign_id"))
            & (F.col("event_date") <= F.col("uc_campaign_end_dt")),
            "inner",
        )
        .select(
            "loyalty_id",
            "transaction_key",
            "event_date",
            "event_time",
            "marketing_type",
            F.col("channel_name").alias("channel"),
            F.col("subchannel_name").alias("subchannel"),
            "campaign_name",
            "campaign_id",
            F.lit(touchpoint_event_name).alias("event_name"),
            "booking_id",
        )
        .distinct()
    )

    return instore_converted_touchpoint_df


def get_instore_nonconverted_touchpoints(
    instore_transactions_df: DataFrame,
    campaign_details_df: DataFrame,
    in_scope_store_location_df: DataFrame,
    unified_data_df: DataFrame,
    targeted_skus_df: DataFrame,
    instore_converted_touchpoint_df: DataFrame,
    touchpoint_event_name: str,
) -> DataFrame:
    """
    In-store visits to a campaign store during the campaign with no targeted purchase

    Expects in-store channel transactions only.

    Keeps transactions where:
    - store is one of the campaign's stores
    - transaction date is within the campaign dates
    - transaction date is on or before the unified campaign end date

    Excludes transactions where:
    - the item is a targeted SKU for the campaign
    - the transaction is already a converted touchpoint for the campaign
    """
    campaign_details_join_df = campaign_details_for_join(campaign_details_df)
    store_location_join_df = store_locations_for_join(in_scope_store_location_df)

    converted_keys_df = (
        instore_converted_touchpoint_df
        .select(
            F.col("transaction_key").alias("converted_transaction_key"),
            F.col("campaign_id").alias("converted_campaign_id"),
        )
    )

    instore_nonconverted_touchpoint_df = (
        instore_transactions_df
        .join(
            F.broadcast(store_location_join_df),
            F.col("store_cd").cast("string") == F.col("store_location_key"),
            "inner",
        )
        .join(
            F.broadcast(campaign_details_join_df),
            (F.col("store_campaign_id") == F.col("campaign_id"))
            & F.col("transaction_dt").between(F.col("campaign_start_dt"), F.col("campaign_end_dt")),
            "inner",
        )
        .join(
            F.broadcast(unified_data_df),
            (F.col("campaign_id") == F.col("uc_campaign_id"))
            & (F.col("transaction_dt") <= F.col("uc_campaign_end_dt")),
            "inner",
        )
        .join(
            F.broadcast(targeted_skus_df),
            (F.col("item_cd") == F.col("sku_item_cd"))
            & (F.col("campaign_id") == F.col("sku_campaign_id"))
            & (F.col("channel_name") == F.col("sku_channel_name"))
            & (F.col("subchannel_name") == F.col("sku_subchannel_name")),
            "left_anti",
        )
        .join(
            converted_keys_df,
            (F.col("transaction_id") == F.col("converted_transaction_key"))
            & (F.col("campaign_id") == F.col("converted_campaign_id")),
            "left_anti",
        )
        .select(
            "loyalty_id",
            F.lit(None).cast("string").alias("transaction_key"),
            F.col("transaction_dt").alias("event_date"),
            F.col("transaction_end_ts").alias("event_time"),
            F.col("marketing_type").alias("marketing_type"),
            F.col("channel_name").alias("channel"),
            F.col("subchannel_name").alias("subchannel"),
            F.col("campaign_name").alias("campaign_name"),
            F.col("campaign_id").alias("campaign_id"),
            F.lit(touchpoint_event_name).alias("event_name"),
            F.col("booking_id").alias("booking_id"),
        )
        .distinct()
    )

    return instore_nonconverted_touchpoint_df


def get_min_timestamp(
    instore_relevant_transaction_df: DataFrame,
    instore_nonconverted_touchpoint_df: DataFrame,
) -> DataFrame:
    """
    First in-store touch per customer per campaign
    """
    all_loyalty_ts_df = (
        instore_relevant_transaction_df
        .select("loyalty_id", "campaign_id", "event_time")
        .unionByName(instore_nonconverted_touchpoint_df.select("loyalty_id", "campaign_id", "event_time"))
    )

    min_timestamp_df = (
        all_loyalty_ts_df
        .groupBy("loyalty_id", "campaign_id")
        .agg(F.min("event_time").alias("event_ts"))
    )

    return min_timestamp_df


def get_online_transactions(
    online_transactions_df: DataFrame,
    min_timestamp_df: DataFrame,
    targeted_skus_df: DataFrame,
    campaign_details_df: DataFrame,
    transaction_event_name: str,
) -> DataFrame:
    """
    Online purchases of targeted SKUs after the customer's first in-store touch

    Expects online channel transactions only.

    Keeps transactions where:
    - customer had an in-store touch for the campaign
    - item is a targeted SKU for that campaign
    - transaction date is on or before the campaign end date
    - transaction time is after the first in-store touch

    Sums sales and units per transaction line.
    """
    cd_cols = ["campaign_id", "campaign_name", "channel_name", "subchannel_name", "campaign_end_dt", "booking_id"]
    campaign_details_join_df = campaign_details_df.select(*cd_cols).distinct()

    online_transaction_df = (
        online_transactions_df
        .join(min_timestamp_df, "loyalty_id", "inner")
        .join(
            F.broadcast(targeted_skus_df),
            (F.col("item_cd") == F.col("sku_item_cd"))
            & (F.col("sku_campaign_id") == F.col("campaign_id")),
            "inner",
        )
        .join(F.broadcast(campaign_details_join_df), "campaign_id", "inner")
        .filter(F.col("transaction_dt") <= F.col("campaign_end_dt"))
        .filter(F.col("transaction_end_ts") > F.col("event_ts"))
        .select(
            "loyalty_id",
            F.col("transaction_id").alias("transaction_key"),
            F.col("transaction_dt").alias("event_date"),
            "item_cd",
            F.col("transaction_end_ts").alias("event_time"),
            F.lit("").alias("marketing_type"),
            F.lit("online").alias("purchase_type"),
            F.col("channel_name").alias("channel"),
            F.col("subchannel_name").alias("subchannel"),
            "campaign_name",
            "campaign_id",
            F.lit(transaction_event_name).alias("event_name"),
            "booking_id",
            F.col("sku_product_type").alias("product_type"),
            F.col("sku_brand_name").alias("unique_brand_name"),
            "net_retail_sales_amt",
            "item_qty",
        )
        .groupBy(
            "loyalty_id", "event_date", "event_time", "transaction_key", "item_cd",
            "unique_brand_name", "marketing_type", "channel", "subchannel", "campaign_name",
            "campaign_id", "event_name", "booking_id", "product_type", "purchase_type",
        )
        .agg(
            F.sum("net_retail_sales_amt").alias("net_targetted_sales"),
            F.sum("item_qty").alias("units"),
        )
    )

    return online_transaction_df


def get_online_touchpoints(
    online_transaction_df: DataFrame,
    min_timestamp_df: DataFrame,
    campaign_details_df: DataFrame,
    unified_data_df: DataFrame,
    touchpoint_event_name: str,
) -> DataFrame:
    """
    Touchpoint for each online conversion, timed at the first in-store visit
    """
    online_touchpoint_df = (
        online_transaction_df
        .select("loyalty_id", "transaction_key", "campaign_id")
        .join(min_timestamp_df, ["loyalty_id", "campaign_id"], "inner")
        .join(F.broadcast(campaign_details_df), "campaign_id", "inner")
        .join(
            F.broadcast(unified_data_df),
            (F.col("campaign_id") == F.col("uc_campaign_id"))
            & (F.to_date("event_ts") <= F.col("uc_campaign_end_dt")),
            "inner",
        )
        .select(
            "loyalty_id",
            "transaction_key",
            F.to_date("event_ts").alias("event_date"),
            F.col("event_ts").alias("event_time"),
            "marketing_type",
            F.col("channel_name").alias("channel"),
            F.col("subchannel_name").alias("subchannel"),
            "campaign_name",
            "campaign_id",
            F.lit(touchpoint_event_name).alias("event_name"),
            "booking_id",
        )
        .distinct()
    )

    return online_touchpoint_df


def union_instore_data_collection(
    instore_relevant_transaction_df: DataFrame,
    instore_converted_touchpoint_df: DataFrame,
    instore_nonconverted_touchpoint_df: DataFrame,
    online_transaction_df: DataFrame,
    online_touchpoint_df: DataFrame,
) -> DataFrame:
    """
    Stack the five outputs into one DataFrame.

    - Renames columns to the output names
    - Adds the blank '' columns the SQL sets per branch
    - Columns a branch does not have come through as NULL
    """
    renames = {
        "event_date": "event_dt",
        "event_time": "event_ts",
        "channel": "channel_name",
        "subchannel": "subchannel_name",
        "net_targetted_sales": "net_sales_amt",
        "units": "units_qty",
    }
    blank = F.lit("")

    instore_txn_df = (
        instore_relevant_transaction_df
        .withColumnsRenamed(renames)
        .withColumns({"marketing_type": blank, "channel_name": blank, "subchannel_name": blank})
    )

    online_txn_df = (
        online_transaction_df
        .withColumnsRenamed(renames)
        .withColumns({
            "marketing_type": blank,
            "channel_name": blank,
            "subchannel_name": blank,
            "campaign_name": blank,
            "campaign_id": blank,
        })
    )

    instore_converted_df = instore_converted_touchpoint_df.withColumnsRenamed(renames).withColumn("purchase_type", blank)
    instore_nonconverted_df = instore_nonconverted_touchpoint_df.withColumnsRenamed(renames).withColumn("purchase_type", blank)
    online_touch_df = online_touchpoint_df.withColumnsRenamed(renames).withColumn("purchase_type", blank)

    instore_data_collection_df = (
        instore_txn_df
        .unionByName(instore_converted_df, allowMissingColumns=True)
        .unionByName(instore_nonconverted_df, allowMissingColumns=True)
        .unionByName(online_txn_df, allowMissingColumns=True)
        .unionByName(online_touch_df, allowMissingColumns=True)
    )

    return instore_data_collection_df


def finalise_instore_data(instore_data_collection_df: DataFrame, correlation_id: str) -> DataFrame:
    """
    Final select: types, defaults, load_ts and job_run_id in InStoreDataPollen.schema order.
    """
    schema_fields = InStoreDataPollen.schema.fields
    final_instore_data_df = (
        instore_data_collection_df
        .withColumn("transaction_key", F.coalesce(F.col("transaction_key"), F.lit("NA")))
        .withColumn("load_ts", F.current_timestamp())
        .withColumn("item_cd", F.coalesce(F.col("item_cd"), F.lit("0")))
        .withColumn("product_type", F.coalesce(F.col("product_type"), F.lit("NA")))
        .withColumn("unique_brand_name", F.coalesce(F.col("unique_brand_name"), F.lit("NA")))
        .withColumn("net_sales_amt", F.coalesce(F.col("net_sales_amt"), F.lit(0)))
        .withColumn("units_qty", F.coalesce(F.col("units_qty"), F.lit(0)))
        .withColumn("job_run_id", F.lit(correlation_id))
        .select(
            *[F.col(field.name).cast(field.dataType).alias(field.name) for field in schema_fields]
        )
    )

    return final_instore_data_df
