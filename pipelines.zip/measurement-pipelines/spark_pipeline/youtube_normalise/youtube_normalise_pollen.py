from typing import List, Optional

from pyspark.sql import functions as F, SparkSession
from pyspark.sql import types as T
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData


def youtube_normalize_pipeline(
    spark: SparkSession,
    source_table_path: str,
    output_path: str,
    correlation_id: str,
) -> None:
    """
    * Objective:
    - This script is used to normalize YouTube campaign data by extracting item codes from campaign data
      and creating a standardized format for downstream processing.
    """

    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")

    # Setting parameter
    job_run_id = correlation_id

    # ToDo: the static values should come from a config file
    # Load the source table with filters applied
    camp_io = (
        spark.read.parquet(source_table_path)
        .select(
            "booking_id",
            "campaign_id",
            "booking_media_live_start_dt",
            "booking_media_live_end_dt",
            "item_cd_list",
            "channel_type",
            "media_provider",
            "booking_status",
            "media_business_group"
        )
        .filter(
            # Filtering for only offsite channel
            (F.upper(F.col('channel_type')) == "OFFSITE") &
            # Filtering for only YOUTUBE campaigns
            (F.upper(F.col('media_provider')) == "YOUTUBE") &
            # Filtering for only completed bookings
            (F.upper(F.col('booking_status')) == "COMPLETED") &
            # Filtering for only sainsburys business group
            (F.upper(F.col('media_business_group')).like("%SAINSBURY%")) &
            # At-least one item code is present
            (F.col("item_cd_list").isNotNull()) &
            (F.col("item_cd_list") != "") &
            (F.col("item_cd_list") != "[]")
        )
    )

    # Selecting required columns and parse JSON string to array
    camp_io_latest = (
        camp_io
        .withColumn("item_cd_list", F.from_json(F.col("item_cd_list"), ProcessedData.item_schema))
        .select(
            "booking_id",
            "campaign_id",
            "booking_media_live_start_dt",
            "booking_media_live_end_dt",
            "item_cd_list"
        )
    )

    # Extract item codes
    extract_known_skus_df = (
        camp_io_latest.select(
            F.col("booking_id"),
            F.col("campaign_id"),
            F.explode(F.col("item_cd_list"))
        )
        .withColumnRenamed("col", "item_element")
        .withColumn("item_cd", F.col("item_element.skuId"))
        .select("booking_id", "campaign_id", "item_cd")
    )

    # Remove the JSON columns
    camp_io_latest = camp_io_latest.drop("item_cd_list")

    # Merging the SKUs with the campaign data
    camp_io_latest = camp_io_latest.join(
        extract_known_skus_df,
        on=["booking_id", "campaign_id"],
        how="inner"
    )

    # Finalizing the DataFrame with required columns and renaming them
    camp_io_latest = camp_io_latest.selectExpr(
        "campaign_id",
        "booking_media_live_start_dt as start_dt",
        "booking_media_live_end_dt as end_dt",
        "item_cd",
        "booking_id"
    )

    # Add channel column
    youtube_normalize = camp_io_latest.withColumn("channel", F.lit("Youtube"))

    # Handle null values
    youtube_normalize = youtube_normalize.dropna()

    # Group by 'booking_id','campaign_id' and 'item_cd' and get the max 'start_dt'
    youtube_normalize = (youtube_normalize.groupBy(
                         ('booking_id'),
                         ('campaign_id'),
                         ('item_cd'),
                         ('end_dt'),
                         ("channel")).agg(F.max(F.col("start_dt")))
                         .withColumnRenamed("max(start_dt)", "start_dt"))

    youtube_normalize = youtube_normalize.filter(
        (~F.col("end_dt").like("%9999%")) &
        (~F.col("campaign_id").like("~~")) &
        (~F.col("campaign_id").like("-1"))
    ).dropDuplicates()

    # Add jobbagid column to support backward compatibility
    youtube_normalize = youtube_normalize.withColumn("jobbagid", F.lit("NA"))

    # Cast to string type and add job metadata
    youtube_normalize_final = (youtube_normalize.select(
        F.col("campaign_id").cast(T.StringType()),
        F.col("start_dt").cast(T.StringType()),
        F.col("end_dt").cast(T.StringType()),
        F.col("item_cd").cast(T.StringType()),
        F.col("booking_id").cast(T.StringType()),
        F.col("jobbagid").cast(T.StringType()),
        F.col("channel").cast(T.StringType()),
        F.lit(job_run_id).cast(T.StringType()),
        F.current_timestamp()
    ).withColumnRenamed("lit(job_run_id)", "job_run_id")
        .withColumnRenamed("current_timestamp()", "load_ts")
    )

    # Print number of rows and show sample data
    row_count = youtube_normalize_final.count()
    print(f'\n\nYOUTUBE_NORMALIZE Count: {row_count}')
    print('\nSample data (first 20 rows):')
    youtube_normalize_final.show(20, truncate=False)

    # Write output to S3
    youtube_normalize_final.write.mode("overwrite").parquet(output_path)
    print(f'\nData successfully written to: {output_path}')


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Normalize YouTube campaign data for pollen pipeline.")
    parser.add_argument(
        "--source-table-path",
        type=str,
        required=True,
        help="The path/table name for the source campaign booking data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The path in S3 to output the normalized YouTube data."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    youtube_normalize_pipeline(
        spark=spark,
        source_table_path=known_args.source_table_path,
        output_path=known_args.output_path,
        correlation_id=known_args.correlation_id,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName(__file__).getOrCreate())
