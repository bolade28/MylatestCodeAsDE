from typing import List, Optional, Dict, Any
from pyspark.sql import DataFrame, SparkSession

from spark_pipeline.attribution_model_dataset.dataset_helper import get_all_campaigns_stats
from spark_pipeline.schemas.attribution_model_dataset import AttributionModelDatasetSchema
from spark_pipeline.schemas.mta_attribution_model import AttributionModel
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset, write_parquet_dataset, is_dtp_run
from spark_pipeline.attribution_model_results.helper_functions import (
    get_training_params,
    reconstruct_from_nested_journeys,
    run_multi_booking_attribution,
)
from spark_pipeline.attribution_model_results.slack_notifications import AttributionSlackNotifier
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import AttributionModelResultConfig, PipelineRunType, ProductType
from spark_pipeline.utils.stdout_logger import StdOutLogger

logger = StdOutLogger()

NON_TRAIN_COLS: list[str] = [
    "userjourney_id",
    "loyalty_id",
    "transaction_key",
    "booking_id",
    "customer_journey_type",
    "journey_type",
    "campaign_duration",
]

OTHER_COLS: list[str] = NON_TRAIN_COLS + [AttributionModelResultConfig.label_col]

FINAL_RESULT_COLS: list[str] = [f.name for f in AttributionModel.schema.fields]


def prepare_campaign_inputs(
    spark: SparkSession,
    attribution_model_dataset_flattened_path: str,
    journey_channel_metadata_path: str,
    slack_notifier: AttributionSlackNotifier,
) -> tuple[DataFrame, DataFrame, DataFrame, int]:
    channel_mapping_cols: list[str] = AttributionModelDatasetSchema.columns(
        AttributionModelDatasetSchema.journey_channel_metadata_schema
    )
    attribution_model_dataset_cols: list[str] = AttributionModelDatasetSchema.columns(
        AttributionModelDatasetSchema.attribution_model_dataset_schema
    )

    attribution_model_dataset_nested = load_parquet_dataset(
        spark,
        attribution_model_dataset_flattened_path,
        "attribution_model_dataset_flattened",
        slack_notifier,
        columns=attribution_model_dataset_cols,
    )
    attribution_model_dataset_flattened = reconstruct_from_nested_journeys(
        attribution_model_dataset_nested,
        AttributionModelDatasetSchema.journey_schema,
    )

    journey_channel_metadata_df = load_parquet_dataset(
        spark,
        journey_channel_metadata_path,
        "channel_mapping",
        slack_notifier,
        columns=channel_mapping_cols,
    ).cache()

    booking_scope_df = (
        attribution_model_dataset_flattened
        .select("booking_id", "campaign_duration")
        .distinct()
    )

    if booking_scope_df.isEmpty():
        slack_notifier.send_no_data_error()
        raise RuntimeError("No data found to execute the attribution model results step!")

    total_campaigns = int(booking_scope_df.count())
    logger.info(f"Found {total_campaigns} campaigns to process")

    return (
        attribution_model_dataset_flattened,
        journey_channel_metadata_df,
        booking_scope_df,
        total_campaigns,
    )


def process_multi_campaign_attribution(
    spark: SparkSession,
    attribution_model_dataset_flattened_path: str,
    journey_channel_metadata_path: str,
    output_path: str,
    synergy_output_path: Optional[str],
    job_run_id: str,
    slack_topic_arn: str,
    journey_type: str,
    pipeline_run_type: str,
) -> Dict[str, Any]:

    is_dtp = is_dtp_run(pipeline_run_type)

    # Config differs per pipeline type
    if is_dtp:
        config = AttributionModelResultConfig()
    else:
        config = AttributionModelResultConfig(use_bdv_version=True)
    params = get_training_params(config)

    slack_notifier = AttributionSlackNotifier(slack_topic_arn, job_run_id, journey_type)
    journey_channel_metadata_df: Optional[DataFrame] = None
    stats_df: Optional[DataFrame] = None
    total_campaigns: int = 0
    campaign_errors: Dict[str, str] = {}

    try:
        logger.info("STARTING MULTI-CAMPAIGN ATTRIBUTION PROCESSING")

        (
            attribution_model_dataset_flattened,
            journey_channel_metadata_df,
            booking_scope_df,
            total_campaigns,
        ) = prepare_campaign_inputs(
            spark=spark,
            attribution_model_dataset_flattened_path=attribution_model_dataset_flattened_path,
            journey_channel_metadata_path=journey_channel_metadata_path,
            slack_notifier=slack_notifier,
        )

        stats_df = get_all_campaigns_stats(
            attribution_model_dataset_flattened, int(params.minimum_conversion_lower_limit), slack_notifier
        )

        if total_campaigns == 1:
            first_scope = booking_scope_df.first()
            first_booking_id = first_scope["booking_id"]
            first_campaign_duration = first_scope["campaign_duration"]
        else:
            first_booking_id = "multi_booking_batch"
            first_campaign_duration = "multi_booking_batch"

        logger.info(
            f"Processing {total_campaigns} campaigns in a single multi-booking attribution run"
        )

        try:
            campaign_results, conversion_rate = run_multi_booking_attribution(
                spark=spark,
                attribution_model_dataset_flattened=attribution_model_dataset_flattened,
                booking_id=first_booking_id,
                campaign_duration=first_campaign_duration,
                is_dtp=is_dtp,
                journey_type=journey_type,
                synergy_output_path=synergy_output_path,
                params=params,
                stats_df=stats_df,
                journey_channel_metadata_df=journey_channel_metadata_df,
                run_type=pipeline_run_type,
                slack_notifier=slack_notifier,
                job_run_id=job_run_id,
                non_train_cols=NON_TRAIN_COLS,
                label_col=AttributionModelResultConfig.label_col,
                booking_scope_df=booking_scope_df,
                booking_scope_size=total_campaigns,
            )
        except Exception as campaign_error:
            error_msg = f"Attribution run failed for scope multi_booking_batch: {campaign_error}"
            campaign_errors["multi_booking_batch"] = error_msg
            slack_notifier.send_progress_update(total_campaigns, total_campaigns, "multi_booking_batch", "FAILED")
            slack_notifier.send_all_campaigns_failed_notification(total_campaigns, total_campaigns, campaign_errors)
            raise RuntimeError(error_msg) from campaign_error

        slack_notifier.add_conversion_rate(conversion_rate)
        logger.info("Completed multi-booking attribution run")
        slack_notifier.send_progress_update(
            total_campaigns, total_campaigns, "multi_booking_batch", "SUCCESS"
        )

        final_results = campaign_results.select(*FINAL_RESULT_COLS)
        write_parquet_dataset(final_results, output_path, slack_notifier)
        final_count = int(final_results.count())

        logger.info("PROCESSING COMPLETED SUCCESSFULLY")
        slack_notifier.send_success_notification(
            total_campaigns, total_campaigns, 0,
            final_count, campaign_errors, final_results
        )

        return {
            'status': 'success',
            'total_campaigns': total_campaigns,
            'campaign_errors': campaign_errors,
            'final_record_count': final_count,
            'output_path': output_path,
            'avg_conversion_rate': slack_notifier.get_average_conversion_rate()
        }

    except Exception as e:
        error_msg = f"Multi-campaign attribution processing failed: {str(e)}"
        logger.error(error_msg)
        slack_notifier.send_general_failure_notification(error_msg, campaign_errors)
        return {
            'status': 'failed',
            'error': error_msg,
            'campaign_errors': campaign_errors
        }
    finally:
        if stats_df is not None:
            stats_df.unpersist()
        if journey_channel_metadata_df is not None:
            journey_channel_metadata_df.unpersist()


def entrypoint(
    spark: SparkSession,
    command_line_args: Optional[List[str]] = None,
) -> None:
    """Entry point for Multi-Campaign Attribution modeling pipeline."""
    parser = ThrowingArgumentParser(
        description="Execute Multi-Campaign Attribution Model Processing with Offer Synergy Logic."
    )

    parser.add_argument(
        "--attribution-model-dataset-flattened-path",
        type=str,
        required=True,
        help="S3 path for the pre-computed flattened journey dataset (output of attribution_model_dataset step).",
    )
    parser.add_argument(
        "--journey-channel-metadata-path",
        type=str,
        required=True,
        help="S3 path for the journey channel metadata dataset (output of attribution_model_dataset step).",
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help=(
            "S3 path for output of attribution modeling results with "
            "normalized weights per touchpoint."
        ),
    )
    parser.add_argument(
        "--synergy-output-path",
        type=str,
        required=False,
        help=(
            "S3 path for output of synergy values data containing "
            "channel interaction analysis with chi-square p-values."
        ),
    )
    parser.add_argument(
        "--journey-type",
        type=str,
        required=True,
        choices=[e.value.lower() for e in ProductType],
        help=f"Journey type for campaign processing ({', '.join(e.value.lower() for e in ProductType)}).",
    )
    parser.add_argument(
        "--job-run-id",
        type=str,
        required=True,
        help="Unique job run identifier for tracking and traceability.",
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN of the Slack topic for notifications.",
    )
    parser.add_argument(
        "--pipeline-run-type",
        type=str, required=True,
        choices=[PipelineRunType().dtp_run_type, PipelineRunType().pollen_run_type],
        help="Pipeline run type for attribution model (DTP or Pollen).",
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    # Synergy only runs for DTP offer journeys — Pollen offer runs skip synergy entirely
    is_dtp_offer = (
        known_args.pipeline_run_type == PipelineRunType().dtp_run_type
        and known_args.journey_type
        and known_args.journey_type.lower() == ProductType.OFFER.value.lower()
    )
    if is_dtp_offer and not known_args.synergy_output_path:
        parser.error("--synergy-output-path is required when --pipeline-run-type is DTP and --journey-type is 'offer'")

    # Call the main processing function
    result = process_multi_campaign_attribution(
        spark=spark,
        attribution_model_dataset_flattened_path=known_args.attribution_model_dataset_flattened_path,
        journey_channel_metadata_path=known_args.journey_channel_metadata_path,
        output_path=known_args.output_path,
        synergy_output_path=known_args.synergy_output_path,
        job_run_id=known_args.job_run_id,
        slack_topic_arn=known_args.slack_topic_arn,
        journey_type=known_args.journey_type,
        pipeline_run_type=known_args.pipeline_run_type,
    )
    if result['status'] == 'failed':
        raise RuntimeError(f"Processing failed: {result['error']}")


if __name__ == "__main__":
    entrypoint(
        spark=(
            SparkSession.builder.appName("MultiCampaignAttributionModel").getOrCreate()
        )
    )
