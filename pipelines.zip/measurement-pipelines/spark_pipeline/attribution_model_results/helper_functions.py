import itertools
from dataclasses import asdict
from pyspark.sql import functions as F, Window
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.column import Column
from scipy.stats import chi2_contingency
from typing import Optional, Sequence
from pyspark.sql import types as T
from spark_pipeline.common.variables import AttributionModelResultConfig, PipelineRunType, EventName
from spark_pipeline.utils.pipeline_utils import validate_pipeline_run_type
from spark_pipeline.utils.stdout_logger import StdOutLogger
from spark_pipeline.attribution_model_results.slack_notifications import AttributionSlackNotifier
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite

logger = StdOutLogger()
PIPELINE_RUN_TYPE = PipelineRunType()


def reshape_to_long(
    df: DataFrame,
    id_cols: Sequence[str],
    target_col: str,
) -> tuple[DataFrame, DataFrame, Column]:
    """
    Validate, cast subchannel columns to double, and unpivot wide→long format.

    Args:
        df: Wide-format journey DataFrame with one column per subchannel.
        id_cols: Journey-level identifier columns to preserve (e.g. userjourney_id).
        target_col: Binary conversion label column name.

    Returns:
        Tuple of (base_df, long_df, target_col_double) where:
        - base_df retains all id_cols + target_col + subchannel columns cast to double.
        - long_df is unpivoted to (id_cols, target_col, channel_name, channel_value).
        - target_col_double is the column expression for the cast label.

    Raises:
        ValueError: If no subchannel feature columns are found after excluding id_cols and target_col.
    """
    exclude = set(id_cols) | {target_col}
    subchannel_cols = [c for c in df.columns if c not in exclude]

    if not subchannel_cols:
        raise ValueError(
            f"No subchannel feature columns detected — cannot compute lift. "
            f"DataFrame columns: {df.columns}. "
            f"Columns excluded as identifiers: {list(id_cols)}, target: '{target_col}'. "
            f"Ensure model_data contains at least one channel exposure column."
        )

    base_df = df.select(
        *id_cols,
        target_col,
        *[F.col(c).cast("double").alias(c) for c in subchannel_cols],
    )

    target_col_double = F.col(target_col).cast("double")

    stack_expr = "stack({0}, {1}) as (channel_name, channel_value)".format(
        len(subchannel_cols),
        ", ".join([f"'{c}', `{c}`" for c in subchannel_cols]),
    )
    long_df = base_df.select(*id_cols, target_col, F.expr(stack_expr))

    return base_df, long_df, target_col_double


def compute_channel_stats(
    base_df: DataFrame,
    long_df: DataFrame,
    target_col_double: Column,
) -> tuple[DataFrame, DataFrame]:
    """
    Compute overall booking stats and per-channel stats needed for the lift formula.

    Args:
        base_df: Wide-format DataFrame with subchannel columns cast to double.
        long_df: Unpivoted long-format DataFrame with channel_name and channel_value columns.
        target_col_double: Column expression for the cast conversion label.

    Returns:
        Tuple of (overall_stats_df, subchannel_stats_df) where:
        - overall_stats_df has n_all (total journeys) and y_all (total conversions) per booking.
        - subchannel_stats_df has n_c (journeys where channel present) and y_c (converting
          journeys where channel present) per (booking, channel).
    """
    overall_stats_df = (
        base_df
        .groupBy("booking_id", "campaign_duration")
        .agg(
            F.count(F.lit(1)).alias("n_all"),  # total journeys (converting + non-converting) per booking
            F.sum(target_col_double).alias("y_all"),  # total conversions per booking
        )
    )

    subchannel_stats_df = (
        long_df
        .groupBy("booking_id", "campaign_duration", "channel_name")
        .agg(
            # journeys where this channel was present, regardless of conversion
            F.sum(F.when(F.col("channel_value") > 0, 1.0).otherwise(0.0)).alias("n_c"),
            # converting journeys where this channel was present
            F.sum(
                F.when(F.col("channel_value") > 0, target_col_double).otherwise(0.0)
            ).alias("y_c"),
        )
    )

    return overall_stats_df, subchannel_stats_df


def compute_normalised_weights(
    long_df: DataFrame,
    overall_stats_df: DataFrame,
    subchannel_stats_df: DataFrame,
    id_cols: Sequence[str],
    target_col: str,
    target_col_double: Column,
) -> DataFrame:
    """
    Join stats, apply the lift formula, filter to conversions, and normalise weights per journey.

    lift = P(conversion | channel present) / P(conversion overall)
    raw_contribution = lift × channel_value
    normalized_weight = raw_contribution / sum(raw_contributions) within each journey

    Args:
        long_df: Unpivoted long-format DataFrame.
        overall_stats_df: Per-booking n_all and y_all from _compute_channel_stats.
        subchannel_stats_df: Per-(booking, channel) n_c and y_c from _compute_channel_stats.
        id_cols: Journey-level identifier columns used as the window partition key.
        target_col: Binary conversion label column name.
        target_col_double: Column expression for the cast conversion label.

    Returns:
        Long-format DataFrame of conversion journeys only, with columns:
        id_cols | target_col | regression_variable | normalized_weights
    """
    long_with_stats_df = (
        long_df
        .join(overall_stats_df, on=["booking_id", "campaign_duration"], how="left")
        .join(subchannel_stats_df, on=["booking_id", "campaign_duration", "channel_name"], how="left")
    )

    p_overall_expr = F.when(F.col("n_all") > 0, F.col("y_all") / F.col("n_all")).otherwise(0.0)
    p_subchannel_expr = F.when(F.col("n_c") > 0, F.col("y_c") / F.col("n_c")).otherwise(0.0)
    lift_expr = F.when(p_overall_expr > 0, p_subchannel_expr / p_overall_expr).otherwise(0.0)

    weighted_long_df = long_with_stats_df.withColumn(
        "raw_contribution",
        lift_expr * F.col("channel_value"),
    )

    # Restrict attribution to conversion journeys only
    conversion_long_df = weighted_long_df.filter(target_col_double == 1.0)

    # Normalise raw contributions within each journey so weights sum to 1.0
    journey_partition_window = Window.partitionBy(*id_cols)
    conversion_long_df = (
        conversion_long_df
        .withColumn("sum_raw", F.sum("raw_contribution").over(journey_partition_window))
        .withColumn(
            "normalized_weight",
            F.when(F.col("sum_raw") > 0, F.col("raw_contribution") / F.col("sum_raw")).otherwise(0.0),
        )
        .select(
            *id_cols,
            target_col,
            F.col("channel_name").alias("regression_variable"),
            F.col("normalized_weight").alias("normalized_weights"),
        )
    )

    return conversion_long_df


def lift_mta_weights(
    df: DataFrame,
    id_cols: Sequence[str],
    target_col: str = AttributionModelResultConfig.label_col,
) -> DataFrame:
    """
    Compute normalised lift-based attribution weights for conversion journeys.

    For each subchannel, lift = P(conversion | subchannel present) / P(conversion overall),
    computed per (booking_id, campaign_duration). Raw contributions (lift × subchannel_value)
    are then normalised within each journey so weights sum to 1.0.

    Only conversion journeys are returned. Any subchannel column not in `id_cols` or
    `target_col` is treated as a subchannel feature.

    Returns a long-format DataFrame with one row per (journey, subchannel):
        id_cols | target_col | regression_variable | normalized_weights
    """
    base_df, long_df, target_col_double = reshape_to_long(df, id_cols, target_col)
    overall_stats_df, subchannel_stats_df = compute_channel_stats(base_df, long_df, target_col_double)
    calculated_lift = compute_normalised_weights(long_df, overall_stats_df, subchannel_stats_df, id_cols, target_col, target_col_double)
    return calculated_lift


def process_attribution_model_lift(
    params: dict,
    model_data: DataFrame,
    non_train_cols: list[str],
    df_booking_id: DataFrame,
    pipeline_run_type: str,
) -> DataFrame:
    """
    Run lift-based attribution and resolve weights to reportable channel metadata.

    Lift weights carry only regression variable names; joining to `df_booking_id`
    resolves each to its channel hierarchy for downstream reporting. Pollen synergy
    terms are synthetic interaction variables with no booking-level metadata — they
    receive placeholder values rather than being dropped.

    Raises:
        ValueError: If pipeline_run_type is neither "Pollen" nor "DTP".
    """
    run_type = validate_pipeline_run_type(pipeline_run_type)
    is_pollen = run_type == PIPELINE_RUN_TYPE.pollen_run_type

    id_cols = non_train_cols
    target_col = AttributionModelResultConfig.label_col

    df_weights = lift_mta_weights(model_data, id_cols, target_col)

    # Drop sub channel rows where the attribution weight is zero - because no one converted when that subchannel was present
    attribution_model_results = df_weights.filter(F.col("normalized_weights") != 0)

    regression_variable_expr = (
        F.upper(F.col("regression_variable")).alias("regression_variable")
        if is_pollen
        else F.col("regression_variable")
    )

    channel_metadata_df = df_booking_id.select(
        "userjourney_id",
        "booking_id",
        "campaign_duration",
        "channel_name",
        "subchannel_name",
        "marketing_type",
        "campaign_id",
        regression_variable_expr,
    ).distinct()

    # For Pollen, uppercase regression_variable on the weights side to match channel_metadata_df
    if is_pollen:
        attribution_model_results = attribution_model_results.withColumn(
            "regression_variable", F.upper(F.col("regression_variable"))
        )

    joined_df = attribution_model_results.join(
        channel_metadata_df,
        on=["regression_variable", "userjourney_id", "booking_id", "campaign_duration"],
        how="left",
    )

    if is_pollen:
        # The regression_variable is built from  campaign data fields attribution_pre_requisite, so in practice
        # A NULL campaign_id (i.e. no match in channel_metadata_df) should never occur.
        # However, this guard is intentionally kept: if data changes for any reason — whether
        # In production, testing, or experimentation — and a regression_variable fails to join,
        # We surface it as "NA" rather than propagating NULLs silently into the output.
        # A future improvement could be to raise an alert on unmatched rows instead.
        is_unmatched = F.col("campaign_id").isNull()
        marketing_type_decoded = F.regexp_replace(F.col("marketing_type"), "[^a-zA-Z0-9_]", "_")
        channel_name_output = F.when(is_unmatched, F.lit("NA")).otherwise(F.col("channel_name"))
        subchannel_name_output = F.when(is_unmatched, F.lit("NA")).otherwise(F.col("subchannel_name"))
        campaign_id_output = F.when(is_unmatched, F.lit("NA")).otherwise(F.col("campaign_id"))
        marketing_type_output = F.when(is_unmatched, F.col("regression_variable")).otherwise(marketing_type_decoded)
    else:
        channel_name_output = F.col("channel_name")
        subchannel_name_output = F.col("subchannel_name")
        campaign_id_output = F.col("campaign_id")
        marketing_type_output = F.col("marketing_type")

    attribution_model_results = joined_df.select(
        *id_cols,
        target_col,
        "regression_variable",
        "normalized_weights",
        channel_name_output.alias("channel_name"),
        subchannel_name_output.alias("subchannel_name"),
        marketing_type_output.alias("marketing_type"),
        campaign_id_output.alias("campaign_id"),
    )

    attribution_model_results = (
        attribution_model_results
        .withColumn("job_run_id", F.lit(params['job_run_id']))
        .withColumn("load_ts", F.current_timestamp())
    )

    booking_context = params.get("booking_id", "multi_booking_batch")
    logger.info(f"Successfully processed attribution results for: {booking_context}")
    return attribution_model_results


def get_training_params(config: AttributionModelResultConfig) -> AttributionModelResultConfig:
    """Normalises config for use in the attribution pipeline (uppercases regression variable list)."""
    config.regression_variable_list = [elem.upper() for elem in config.regression_variable_list]
    return config


def split_pos_neg_class(df: DataFrame, label: str) -> tuple[DataFrame, DataFrame, list]:
    """
    Split journeys into positive and negative classes for all bookings.

    Bookings where all journeys have the same label (all conversions or all
    non-conversions) are excluded with a warning and do not appear in either
    returned DataFrame.

    Args:
        df: Full flattened DataFrame containing one or more bookings.
        label: Binary conversion indicator column (e.g. "isconversion").

    Returns:
        Tuple of (df_pos, df_neg, excluded_bookings) where excluded_bookings is a
        list of Row(booking_id, campaign_duration, skip_reason) for skipped bookings.
    """
    booking_class_counts = (
        df
        .groupBy("booking_id", "campaign_duration")
        .agg(
            F.sum(F.when(F.col(label) == 1, 1).otherwise(0)).alias("pos_count"),
            F.sum(F.when(F.col(label) == 0, 1).otherwise(0)).alias("neg_count"),
        )
    )

    invalid_bookings = (
        booking_class_counts
        .filter((F.col("pos_count") == 0) | (F.col("neg_count") == 0))
        .select(
            "booking_id",
            "campaign_duration",
            F.when(
                F.col("pos_count") == 0,
                F.lit("No positive samples (conversions). Verify isconversion column has value 1 for conversion journeys.")
            ).otherwise(
                F.lit("No negative samples (non-conversions). All journeys are conversions (unusual). Verify data quality.")
            ).alias("skip_reason"),
        )
        .collect()
    )

    for row in invalid_bookings:
        logger.warning(
            f"Excluding booking {row['booking_id']} ({row['campaign_duration']}): {row['skip_reason']}"
        )

    valid_booking_keys = (
        booking_class_counts
        .filter((F.col("pos_count") > 0) & (F.col("neg_count") > 0))
        .select("booking_id", "campaign_duration")
    )

    valid_df = df.join(
        F.broadcast(valid_booking_keys),
        on=["booking_id", "campaign_duration"],
        how="inner",
    )

    df_pos = valid_df.filter(F.col(label) == 1)
    df_neg = valid_df.filter(F.col(label) == 0)

    return df_pos, df_neg, invalid_bookings


# TODO:: this function is used in DTP but it's deprecated, however, will not remove this as DS team asked to keep for reference. We might use this in future.
def create_empty_synergy_file(spark, booking_id, campaign_duration, job_run_id, synergy_output_path):
    """Create and save an empty synergy DataFrame with metadata."""
    try:
        empty_synergy_df = spark.createDataFrame([], "channel_name STRING, chi_sq_p_val_num DOUBLE")
        empty_synergy_df = (empty_synergy_df.withColumn("booking_id", F.lit(booking_id))
                            .withColumn("campaign_duration", F.lit(campaign_duration))
                            .withColumn("job_run_id", F.lit(job_run_id))
                            .withColumn("load_ts", F.current_timestamp()))

        spark_s3_overwrite(synergy_output_path, empty_synergy_df)
        logger.info("Empty synergy file created")
    except Exception as save_error:
        logger.error(f"Failed to save empty synergy file: {str(save_error)}")


# TODO:: this function is used in DTP but it's deprecated, however, will not remove this as DS team asked to keep for reference. We might use this in future.
def process_offer_synergy(spark, flattened_path, regression_variable_list,
                          booking_id, campaign_duration, job_run_id, synergy_output_path):
    """
    Process synergy analysis for offer campaigns and always save results.
    """
    try:
        # Derive regression variable names from flattened_path columns
        # (after pivot, column names = regression variables; exclude journey-level metadata cols)
        non_var_cols = {
            "userjourney_id", "loyalty_id", "transaction_key", "booking_id",
            "customer_journey_type", "journey_type", "campaign_duration", AttributionModelResultConfig.label_col,
        }
        reg_var_list = [col for col in flattened_path.columns if col not in non_var_cols]
        label_col = AttributionModelResultConfig.label_col
        non_train_cols = [
            "userjourney_id",
            "loyalty_id",
            "transaction_key",
            "booking_id",
            "customer_journey_type",
            "journey_type",
            "campaign_duration"
        ]
        other_cols = non_train_cols + [label_col]

        # Extract channels based on marketing type position in regression variables
        channels = set()
        try:
            marketing_type_index = regression_variable_list.index("MARKETING_TYPE")

            for var in reg_var_list:
                if EventName.TRANSACTION.value.lower() not in var.lower():
                    parts = var.split("_")
                    if len(parts) > marketing_type_index:
                        channel = parts[marketing_type_index]
                        channels.add(channel)
        except (ValueError, IndexError):
            logger.warning("Could not find MARKETING_TYPE in regression_variable_list for channel extraction")
            # Create empty synergy file and return original data
            create_empty_synergy_file(spark, booking_id, campaign_duration, job_run_id, synergy_output_path)
            return flattened_path

        channels = sorted(list(channels))
        logger.info(f"Found {len(channels)} channels for synergy analysis: {channels}")

        if len(channels) < 2:
            logger.warning(f"Not enough channels ({len(channels)}) for synergy analysis, minimum 2 required")
            # Create empty synergy file and return original data
            create_empty_synergy_file(spark, booking_id, campaign_duration, job_run_id, synergy_output_path)
            return flattened_path

        # Create channel column mappings and generate interaction terms
        df_interactions = flattened_path
        channel_columns = {
            channel: [col for col in df_interactions.columns
                      if channel.upper() in col.upper() and col not in other_cols]
            for channel in channels
        }

        # TODO:: functions must be redesigned here  - will keep it as part of differnet ticket
        interaction_columns = []
        for r in range(2, len(channels) + 1):
            for combo in itertools.combinations(channels, r):
                combo_name = "_".join(combo)
                interaction_expr = F.lit(1.0)
                valid_combo = True

                for channel in combo:
                    matched_columns = channel_columns.get(channel, [])
                    if matched_columns:
                        if len(matched_columns) == 1:
                            max_expr = F.col(matched_columns[0])
                        else:
                            max_expr = F.greatest(*[F.col(col_name) for col_name in matched_columns])
                        interaction_expr = interaction_expr * max_expr
                    else:
                        valid_combo = False
                        break

                if valid_combo:
                    df_interactions = df_interactions.withColumn(combo_name, interaction_expr)
                    interaction_columns.append(combo_name)

        logger.info(f"Generated {len(interaction_columns)} interaction terms")

        # Test significance and collect all results
        significant_interactions = []
        correlation_data = []

        for column in interaction_columns:
            try:
                conversion_sum = (df_interactions.filter(F.col(AttributionModelResultConfig.label_col) == 1)
                                  .agg(F.sum(F.col(column)).alias("col_sum"))
                                  .collect()[0]["col_sum"])

                if conversion_sum and conversion_sum > 0:
                    contingency_df = (df_interactions.groupBy(column, AttributionModelResultConfig.label_col)
                                      .count().groupBy(column).pivot(AttributionModelResultConfig.label_col)
                                      .agg(F.sum("count")))

                    contingency_pd = contingency_df.toPandas().set_index(column).fillna(0)

                    if contingency_pd.shape[0] >= 2 and contingency_pd.shape[1] >= 2:
                        chi2, chi_p_val, dof, expected = chi2_contingency(contingency_pd)
                        correlation_data.append((column, float(chi_p_val)))

                        if chi_p_val < 0.05:
                            significant_interactions.append(column)
                    else:
                        # Add with p-value = 1.0 if contingency table is invalid
                        correlation_data.append((column, 1.0))
                else:
                    # Add with p-value = 1.0 if no conversions with this interaction
                    correlation_data.append((column, 1.0))
            except Exception as e:
                # Add with p-value = 1.0 if error in chi-square test
                correlation_data.append((column, 1.0))
                logger.warning(f"Error testing interaction {column}: {str(e)}")

        # Always save synergy data, even if empty
        if correlation_data:
            synergy_df = spark.createDataFrame(correlation_data, ["channel_name", "chi_sq_p_val_num"])
            logger.info(f"Synergy analysis found {len(correlation_data)} interaction terms, "
                        f"{len(significant_interactions)} significant")
        else:
            # Create empty synergy file if no interactions were tested
            synergy_df = spark.createDataFrame([], "channel_name STRING, chi_sq_p_val_num DOUBLE")
            logger.info("No interaction terms generated for synergy analysis")

        synergy_df = (synergy_df.withColumn("booking_id", F.lit(booking_id))
                      .withColumn("campaign_duration", F.lit(campaign_duration))
                      .withColumn("job_run_id", F.lit(job_run_id))
                      .withColumn("load_ts", F.current_timestamp()))

        # save synergy analysis results
        spark_s3_overwrite(synergy_output_path, synergy_df)
        logger.info(f"Synergy file saved with {synergy_df.count()} records")

        # Return model with significant interactions if any
        if significant_interactions:
            selected_columns = flattened_path.columns + significant_interactions
            final_model_data = df_interactions.select(*selected_columns)
            return final_model_data
        else:
            return flattened_path

    except Exception:
        logger.error(f"Synergy analysis failed for {booking_id}", exc_info=True)
        create_empty_synergy_file(spark, booking_id, campaign_duration, job_run_id, synergy_output_path)
        raise


def run_synergy_if_applicable(
    spark: SparkSession,
    flattened_path: DataFrame,
    params: AttributionModelResultConfig,
    booking_id: str,
    campaign_duration: str,
    job_run_id: str,
    synergy_output_path: Optional[str],
    is_dtp: bool,
    journey_type_from_data: str,
    booking_scope_size: int,
    booking_context: str,
) -> DataFrame:
    """
    Run synergy analysis for DTP offer journeys and return the model data.

    Synergy is only applicable for DTP offer campaigns with a single booking.
    For all other cases (Pollen, non-offer, multi-booking) the original
    flattened_path is returned unchanged.

    Args:
        spark: Active SparkSession.
        flattened_path: Filtered user journey DataFrame for the current booking scope.
        params: Config dataclass carrying the regression variable list.
        booking_id: Booking ID used for logging and synergy output metadata.
        campaign_duration: Campaign duration paired with booking_id.
        job_run_id: Pipeline run identifier used to tag synergy output rows.
        synergy_output_path: S3 path to write synergy results.
        is_dtp: True if running DTP pipeline.
        journey_type_from_data: Resolved journey type (e.g. "offer", "standard").
        booking_scope_size: Number of bookings in the current scope.
        booking_context: Human-readable scope label used in log messages.

    Returns:
        model_data DataFrame — either the original or with interaction columns appended.
    """
    if is_dtp and journey_type_from_data.lower() == "offer" and booking_scope_size == 1:
        try:
            model_data = process_offer_synergy(
                spark, flattened_path,
                params.regression_variable_list, booking_id,
                campaign_duration, job_run_id, synergy_output_path
            )
            added_cols = set(model_data.columns) - set(flattened_path.columns)
            logger.info(
                f"Synergy analysis completed for {booking_id}: "
                f"{len(added_cols)} interaction terms added" if added_cols else "no significant interactions found"
            )
        except Exception as e:
            logger.warning(f"Synergy analysis failed for {booking_id}, using original data: {str(e)}")
            model_data = flattened_path
    else:
        logger.info(f"Skipping synergy analysis for {journey_type_from_data} scope {booking_context}")
        model_data = flattened_path
    return model_data


def raise_booking_processing_error(
    error_msg: str,
    error_code: str,
    model_data: DataFrame,
    booking_context: str,
    slack_notifier: AttributionSlackNotifier,
    cause: Optional[Exception] = None,
) -> None:
    """
    Notify Slack, unpersist cached model data, and raise RuntimeError.

    Centralises the repeated pattern of alerting, cleanup, and failure signalling
    used across campaign error paths.

    Args:
        error_msg: Human-readable error description; used as the RuntimeError message.
        error_code: Short Slack error category tag (e.g. "no_positive_samples").
        model_data: Cached model DataFrame to unpersist before raising.
        booking_context: Human-readable scope label for the Slack alert.
        slack_notifier: Notifier instance for sending Slack alerts.
        cause: Optional originating exception to chain via ``raise ... from cause``.

    Raises:
        RuntimeError: Always.
    """
    slack_notifier.send_campaign_specific_error(booking_context, error_msg, error_code)
    model_data.unpersist()
    raise RuntimeError(error_msg) from cause


def validate_class_distribution(
    df_pos: DataFrame,
    df_neg: DataFrame,
    model_data: DataFrame,
    booking_context: str,
    slack_notifier: AttributionSlackNotifier,
) -> None:
    """
    Validate that model_data contains both positive and negative journey samples.

    Sends a Slack alert, unpersists the cached DataFrame, and raises RuntimeError
    if either class is missing — which would make attribution meaningless.

    Args:
        df_pos: DataFrame of converting journeys (label == 1).
        df_neg: DataFrame of non-converting journeys (label == 0).
        model_data: Cached model DataFrame to unpersist on failure.
        booking_context: Human-readable scope label used in error messages.
        slack_notifier: Notifier instance for sending Slack alerts.

    Raises:
        RuntimeError: If df_pos or df_neg is empty.
    """
    if df_pos.isEmpty():
        raise_booking_processing_error(
            "No positive samples (conversions) in model_data. Verify isconversion column has value 1 for conversion journeys.",
            "no_positive_samples", model_data, booking_context, slack_notifier,
        )

    if df_neg.isEmpty():
        raise_booking_processing_error(
            "No negative samples (non-conversions) in model_data. All journeys are conversions (unusual). Verify data quality.",
            "no_negative_samples", model_data, booking_context, slack_notifier,
        )


def resolve_journey_type(
    flattened_path: DataFrame,
    is_dtp: bool,
    journey_type: str,
    booking_context: str,
) -> str:
    """
    Resolve the effective journey type for the current booking scope.

    For DTP, journey_type is read directly from the data. For Pollen, the
    caller-supplied value is used as-is. If DTP data contains mixed journey
    types (only possible in multi-booking batches), the requested journey_type
    is kept and a warning is logged.

    Args:
        flattened_path: Filtered user journey DataFrame for the current scope.
        is_dtp: True if running the DTP pipeline.
        journey_type: Caller-supplied journey type; used directly for Pollen
            and as a fallback for mixed-type DTP batches.
        booking_context: Human-readable scope label used in log messages.

    Returns:
        Resolved journey type string.

    Raises:
        RuntimeError: If DTP data contains no journey_type values.
    """
    if not is_dtp:
        return journey_type

    journey_type_rows = (
        flattened_path
        .select("journey_type")
        .distinct()
        .limit(2)
        .collect()
    )
    if not journey_type_rows:
        raise RuntimeError(f"No journey type found for campaign scope {booking_context}")

    if len(journey_type_rows) > 1:
        # Mixed journey types can happen only for multi-booking batches.
        # Keep the requested journey_type to avoid selecting an arbitrary value.
        logger.warning(
            f"Multiple journey types found for {booking_context}; using requested journey_type={journey_type}"
        )
        return journey_type

    return str(journey_type_rows[0][0])


def build_campaign_params(
    params: AttributionModelResultConfig,
    stats_df: DataFrame,
    booking_scope_df: DataFrame,
    booking_id: str,
    campaign_duration: str,
    booking_scope_size: int,
    booking_context: str,
    journey_type_from_data: str,
    job_run_id: str,
    label_col: str,
) -> tuple[dict, float]:
    """
    Aggregate campaign statistics and assemble the params dict for attribution processing.

    Joins stats_df to the booking scope, sums conversions/non-conversions, computes the
    conversion rate, and merges everything into a copy of `params` as a plain dict.

    Args:
        params: Typed config dataclass carrying model hyperparameters.
        stats_df: Pre-aggregated DataFrame with total_conversions and total_nonconversions
            per (booking_id, campaign_duration).
        booking_scope_df: DataFrame of (booking_id, campaign_duration) pairs in the scope.
        booking_id: Single booking ID; used to build job_run_id for single-booking scopes.
        campaign_duration: Campaign duration paired with booking_id.
        booking_scope_size: Number of bookings in the current scope.
        booking_context: Human-readable scope label used in the params dict.
        journey_type_from_data: Resolved journey type (e.g. "offer", "standard").
        job_run_id: Pipeline run identifier used to tag output rows.
        label_col: Name of the binary conversion label column.

    Returns:
        Tuple of (campaign_params dict, conversion_rate float).
    """
    stats_scope_df = stats_df.join(
        F.broadcast(booking_scope_df),
        on=["booking_id", "campaign_duration"],
        how="inner",
    )
    stats_row = stats_scope_df.agg(
        F.sum("total_conversions").alias("total_conversions"),
        F.sum("total_nonconversions").alias("total_nonconversions"),
    ).collect()[0]

    total_conversions = stats_row["total_conversions"]
    total_nonconversions = stats_row["total_nonconversions"]
    total_journeys = (total_conversions or 0) + (total_nonconversions or 0)
    conversion_rate = float(((total_conversions or 0) / total_journeys) * 100 if total_journeys > 0 else 0.0)

    campaign_job_run_id = (
        f"{job_run_id}_{booking_id}_{campaign_duration}"
        if booking_scope_size == 1
        else f"{job_run_id}_multi_booking_batch"
    )
    campaign_params = asdict(params)
    campaign_params.update({
        'total_conversions': total_conversions,
        'total_nonconversions': total_nonconversions,
        'conversion_rate': conversion_rate,
        'booking_id': booking_context,
        'journey_type': journey_type_from_data,
        'job_run_id': campaign_job_run_id,
        'label_col': label_col,
        'pred_col': "predicted_conversion",
    })
    return campaign_params, conversion_rate


def resolve_booking_scope(
    spark: SparkSession,
    booking_id: str,
    campaign_duration: str,
    booking_scope: Optional[list[tuple[str, str]]],
    booking_scope_df: Optional[DataFrame],
    booking_scope_size: Optional[int],
) -> tuple[DataFrame, int]:
    """
    Resolve the booking scope inputs into a canonical (booking_scope_df, booking_scope_size) pair.

    Handles three calling patterns:
    - Single booking: booking_scope is None — wraps (booking_id, campaign_duration) into a DataFrame.
    - List of bookings: booking_scope is provided — creates a DataFrame from the list.
    - Pre-built DataFrame: booking_scope_df is provided — deduplicates and uses it directly.

    Args:
        spark: Active SparkSession.
        booking_id: Fallback booking ID used when booking_scope is None.
        campaign_duration: Fallback campaign duration used when booking_scope is None.
        booking_scope: Optional list of (booking_id, campaign_duration) tuples.
        booking_scope_df: Optional pre-built DataFrame with booking_id and campaign_duration columns.
        booking_scope_size: Optional pre-computed booking count; avoids an extra .count() if known.

    Returns:
        Tuple of (resolved booking_scope_df, booking_scope_size).
    """
    booking_scope_values = booking_scope or [(booking_id, campaign_duration)]
    if booking_scope_df is None:
        resolved_df = spark.createDataFrame(
            booking_scope_values,
            schema=["booking_id", "campaign_duration"],
        )
    else:
        resolved_df = booking_scope_df.select("booking_id", "campaign_duration").distinct()

    if booking_scope_size is None:
        resolved_size = len(booking_scope_values) if booking_scope else int(resolved_df.count())
    else:
        resolved_size = booking_scope_size

    return resolved_df, resolved_size


def run_multi_booking_attribution(
    spark: SparkSession,
    attribution_model_dataset_flattened: DataFrame,
    booking_id: str,
    campaign_duration: str,
    is_dtp: bool,
    journey_type: str,
    synergy_output_path: Optional[str],
    params: AttributionModelResultConfig,
    stats_df: DataFrame,
    journey_channel_metadata_df: DataFrame,
    run_type: str,
    slack_notifier: AttributionSlackNotifier,
    job_run_id: str,
    non_train_cols: list[str],
    label_col: str,
    booking_scope: Optional[list[tuple[str, str]]] = None,
    booking_scope_df: Optional[DataFrame] = None,
    booking_scope_size: Optional[int] = None,
) -> tuple[DataFrame, float]:
    """
    Process attribution model for one or more (booking_id, campaign_duration) pairs.

    If `booking_scope` is provided, it takes precedence over `booking_id` /
    `campaign_duration` and runs attribution for that full booking set in one call.

    Args:
        spark: Active SparkSession.
        attribution_model_dataset_flattened: Pivoted journey DataFrame — one row per journey,
            one column per regression variable.
        booking_id: Primary booking ID. Falls back to this when booking_scope is None.
        campaign_duration: Campaign duration string (e.g. "4W") paired with booking_id.
        is_dtp: True for DTP, False for Pollen. Governs synergy analysis and journey_type
            resolution.
        journey_type: Journey type (e.g. "offer", "standard"). Read from data for DTP;
            used as-is for Pollen.
        synergy_output_path: S3 path for synergy results. DTP offer journeys only; ignored
            for Pollen.
        params: Config dataclass carrying model hyperparameters and regression variable list.
        stats_df: Pre-aggregated conversion counts per (booking_id, campaign_duration).
        journey_channel_metadata_df: Maps (userjourney_id, regression_variable) to channel
            hierarchy (channel_name, subchannel_name, marketing_type, campaign_id).
        run_type: Pipeline run type — "Pollen" or "DTP".
        slack_notifier: Sends per-campaign error alerts to Slack.
        job_run_id: Pipeline run identifier used to tag output rows.
        non_train_cols: Journey-level metadata columns excluded from model training
            (e.g. userjourney_id, booking_id, campaign_duration).
        label_col: Binary conversion label column (e.g. "isconversion").
        booking_scope: Optional list of (booking_id, campaign_duration) tuples. When provided,
            takes precedence over the individual booking_id / campaign_duration args.
        booking_scope_df: Optional DataFrame with booking_id and campaign_duration columns,
            used when the caller already has the scope as a Spark DataFrame (e.g. from a
            prior query). Supersedes booking_scope; deduplicated before use.
        booking_scope_size: Optional pre-computed count of bookings in the scope. Pass this
            when the caller already knows the size (e.g. len(booking_scope)) to avoid an
            extra .count() Spark action.

    Returns:
        Tuple of (campaign_results DataFrame, conversion_rate float).

    Raises:
        RuntimeError: If the campaign should be skipped (no valid class distribution) or
            if attribution processing fails.
    """
    booking_scope_df, booking_scope_size = resolve_booking_scope(
        spark, booking_id, campaign_duration, booking_scope, booking_scope_df, booking_scope_size
    )

    flattened_path = attribution_model_dataset_flattened.join(
        F.broadcast(booking_scope_df),
        on=["booking_id", "campaign_duration"],
        how="inner",
    )

    booking_context = booking_id if booking_scope_size == 1 else f"{booking_scope_size} bookings"

    # DTP reads journey_type from data; Pollen uses the passed parameter
    journey_type_from_data = resolve_journey_type(flattened_path, is_dtp, journey_type, booking_context)

    # Synergy: DTP runs for offer journey, Pollen always skips
    model_data = run_synergy_if_applicable(
        spark, flattened_path, params, booking_id, campaign_duration,
        job_run_id, synergy_output_path, is_dtp, journey_type_from_data,
        booking_scope_size, booking_context,
    )

    model_data = model_data.cache()

    df_pos, df_neg, excluded_bookings = split_pos_neg_class(model_data, label_col)

    for excluded in excluded_bookings:
        slack_notifier.send_campaign_specific_error(
            f"{excluded['booking_id']}:{excluded['campaign_duration']}",
            excluded["skip_reason"],
            "invalid_class_distribution",
        )

    validate_class_distribution(df_pos, df_neg, model_data, booking_context, slack_notifier)

    campaign_params, conversion_rate = build_campaign_params(
        params, stats_df, booking_scope_df, booking_id, campaign_duration,
        booking_scope_size, booking_context, journey_type_from_data, job_run_id, label_col,
    )

    try:
        campaign_results = process_attribution_model_lift(
            params=campaign_params,
            model_data=model_data,
            non_train_cols=non_train_cols,
            df_booking_id=journey_channel_metadata_df.join(
                F.broadcast(booking_scope_df),
                on=["booking_id", "campaign_duration"],
                how="inner",
            ),
            pipeline_run_type=run_type,
        )
    except Exception as e:
        raise_booking_processing_error(
            f"Attribution model processing failed for scope {booking_context}",
            "model_runtime_error", model_data, booking_context, slack_notifier, cause=e,
        )

    if campaign_results is None:
        raise_booking_processing_error(
            "Attribution model returned empty results. Model training completed but produced zero attribution weights.",
            "empty_results", model_data, booking_context, slack_notifier,
        )

    model_data.unpersist()
    return campaign_results, conversion_rate


def reconstruct_from_nested_journeys(
    nested_df: DataFrame,
    journey_schema: T.StructType,
) -> DataFrame:
    journey_fields = [f.name for f in journey_schema.fields if f.name != "regression_variables"]
    TOP_LEVEL_COLS = [
        "loyalty_id", AttributionModelResultConfig.label_col, "booking_id",
        "customer_journey_type", "campaign_duration", "journey_type",
    ]

    journeys_flat_df = (
        nested_df
        .select(*TOP_LEVEL_COLS, F.explode("user_journeys").alias("journey"))
        .select(
            *TOP_LEVEL_COLS,
            *[F.col(f"journey.{f}") for f in journey_fields],
            F.col("journey.regression_variables"),
        )
    )

    long_format_df = (
        journeys_flat_df
        .select(
            *TOP_LEVEL_COLS,
            *journey_fields,
            F.explode("regression_variables").alias("reg_var"),
        )
        .select(
            *TOP_LEVEL_COLS,
            *journey_fields,
            F.col("reg_var.name").alias("variable_name"),
            F.col("reg_var.value").alias("variable_value"),
        )
    )

    distinct_var_names = [
        row["variable_name"]
        for row in long_format_df.select("variable_name").distinct().collect()
    ]

    groupby_cols = TOP_LEVEL_COLS + journey_fields

    reconstructed_df = (
        long_format_df
        .groupBy(*groupby_cols)
        .pivot("variable_name", distinct_var_names)
        .agg(F.first("variable_value"))
        .fillna({var: 0.0 for var in distinct_var_names})
    )

    return reconstructed_df
