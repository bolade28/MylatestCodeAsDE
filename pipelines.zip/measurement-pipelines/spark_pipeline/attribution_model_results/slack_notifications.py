"""
Slack notification utilities for Multi-Campaign Attribution Model
"""
from typing import Dict, Any, List
import time

from spark_pipeline.utils.slack_utils import SlackMessenger


class AttributionSlackNotifier:
    """
    Handles all Slack notifications for the Multi-Campaign Attribution Model pipeline
    """

    def __init__(self, slack_topic_arn: str, job_run_id: str, journey_type: str = "offer"):
        """
        Initialize the Slack notifier

        Args:
            slack_topic_arn: ARN for Slack topic
            job_run_id: Unique job run identifier
            journey_type: Journey type (offer, brand, aisle) for event naming
        """
        self.slack_messenger = SlackMessenger(
            topic_arn=slack_topic_arn,
            correlation_id=job_run_id
        )
        self.job_run_id = job_run_id
        self.journey_type = journey_type.title()  # Capitalize for display
        self.start_time = time.time()
        self.conversion_rates = []  # Track conversion rates for successful campaigns

    def add_conversion_rate(self, conversion_rate: float):
        """Add a conversion rate for a successful campaign"""
        self.conversion_rates.append(conversion_rate)

    def get_average_conversion_rate(self):
        """Calculate average conversion rate across successful campaigns"""
        if not self.conversion_rates:
            return None
        return sum(self.conversion_rates) / len(self.conversion_rates)

    def send_start_notification(self, total_campaigns: int,
                                measurement_records: int,
                                attribution_records: int,
                                decay_records: int):
        """Send campaign discovery notification at the beginning"""
        self.slack_messenger.send_message(
            event_type=f"Attribution Model Result {self.journey_type.lower().capitalize()}",
            text="Campaign Discovery Complete",
            data={
                "total_campaigns_found": total_campaigns,
                "measurement_records": measurement_records,
                "attribution_records": attribution_records,
                "decay_records": decay_records
            }
        )

    def send_data_loading_error(self, error_msg: str, stage: str):
        """Send data loading error notification"""
        self.slack_messenger.send_message(
            event_type=f"Attribution Model Result {self.journey_type.lower().capitalize()} Notification",
            text="❌ Attribution Model Failed - Data Loading Error",
            data={}
        )

    def send_no_data_error(self):
        """Send no data found error"""
        self.slack_messenger.send_message(
            event_type=f"Attribution Model Result {self.journey_type.lower().capitalize()} Notification",
            text="❌ Attribution Model Failed - No Data",
            data={}
        )

    def send_progress_update(self, current_campaign: int, total_campaigns: int,
                             booking_id: str, status: str):
        """Send periodic progress updates for long-running jobs"""
        if current_campaign % 5 == 0:  # Every 5 campaigns
            progress_percent = round((current_campaign / total_campaigns) * 100, 1)
            self.slack_messenger.send_message(
                event_type=f"Attribution Model Result {self.journey_type.lower().capitalize()} Notification",
                text=f"📊 Attribution Progress Update: {current_campaign}/{total_campaigns} campaigns ({progress_percent}%)\n🆔 Correlation ID: {self.job_run_id}\n📋 Latest: {booking_id} - {status}",
                data={}
            )

    def send_results_combination_error(self, error_msg: str):
        """Send results combination error notification"""
        self.slack_messenger.send_message(
            event_type=f"Attribution Model Result {self.journey_type.lower().capitalize()} Notification",
            text="❌ Attribution Model Failed - Results Combination Error",
            data={}
        )

    def send_all_campaigns_failed_notification(self, total_campaigns: int,
                                               failed_campaigns: int,
                                               campaign_errors: Dict[str, str]):
        """Send notification when all campaigns fail"""
        duration_minutes = self._calculate_duration()

        # Format failed campaigns list for Slack
        failed_campaigns_list = list(campaign_errors.keys())[:5]  # Show first 5 failed campaigns
        failed_campaigns_text = ", ".join(failed_campaigns_list)
        if len(campaign_errors) > 5:
            failed_campaigns_text += f" (+{len(campaign_errors) - 5} more)"

        slack_text = f"""❌ Attribution Model Failed - No Successful Campaigns
🆔 Correlation ID: {self.job_run_id}
📊 Total: {total_campaigns} campaigns | All {failed_campaigns} failed
🚫 Failed Campaigns: {failed_campaigns_text}
⏱️ Duration: {duration_minutes} minutes"""

        self.slack_messenger.send_message(
            event_type=f"Attribution Model Result {self.journey_type.lower().capitalize()} Notification",
            text=slack_text,
            data={}
        )

    def send_success_notification(self, total_campaigns: int, successful_campaigns: int,
                                  failed_campaigns: int, final_count: int,
                                  campaign_errors: Dict[str, str],
                                  all_campaign_results: List[Any]):
        """Send successful completion notification"""
        duration_minutes = self._calculate_duration()
        success_rate = round((successful_campaigns / total_campaigns) * 100, 1)
        avg_conversion_rate = self.get_average_conversion_rate()

        # Create error summary for Slack
        error_summary = self._categorize_errors(campaign_errors)

        # Format error string for Slack with failed campaigns
        error_text = ""
        if error_summary:
            error_parts = [f"{error_type}({count})" for error_type, count in error_summary.items()]
            failed_campaigns_list = list(campaign_errors.keys())[:3]  # Show first 3 failed campaigns
            failed_campaigns_text = ", ".join(failed_campaigns_list)
            if len(campaign_errors) > 3:
                failed_campaigns_text += f" (+{len(campaign_errors) - 3} more)"
            error_text = f"⚠️ Failed: {', '.join(error_parts)} | Campaigns: {failed_campaigns_text}\n"

        # Add conversion rate if available
        conversion_text = ""
        if avg_conversion_rate is not None:
            conversion_text = f"📈 Avg Conversion Rate: {avg_conversion_rate:.2f}%\n"

        slack_text = f"""🎯 Attribution Model Run Complete
🆔 Correlation ID: {self.job_run_id}
📊 Campaigns: {total_campaigns} total | {successful_campaigns} successful | {failed_campaigns} failed ({success_rate}% success rate)
📈 Generated {final_count:,} attribution records
{conversion_text}{error_text}⏱️ Duration: {duration_minutes} minutes"""

        self.slack_messenger.send_message(
            event_type=f"Attribution Model Result {self.journey_type.lower().capitalize()}",
            text=slack_text,
            data={}
        )

    def send_general_failure_notification(self, error_msg: str, campaign_errors: Dict[str, str]):
        """Send general failure notification"""
        # duration_minutes = self._calculate_duration()

        self.slack_messenger.send_message(
            event_type=f"Attribution Model Result {self.journey_type.lower().capitalize()} Notification",
            text="❌ Attribution Model Processing Failed",
            data={}
        )

    def _calculate_duration(self) -> float:
        """Calculate processing duration in minutes"""
        end_time = time.time()
        return round((end_time - self.start_time) / 60, 1)

    def _categorize_errors(self, campaign_errors: Dict[str, str]) -> Dict[str, int]:
        """Categorize campaign errors for summary"""
        error_summary = {}
        for booking_id, error in campaign_errors.items():
            if "insufficient conversions" in error.lower():
                error_summary["insufficient_data"] = error_summary.get("insufficient_data", 0) + 1
            elif "model" in error.lower():
                error_summary["model_error"] = error_summary.get("model_error", 0) + 1
            else:
                error_summary["other_error"] = error_summary.get("other_error", 0) + 1
        return error_summary

    def send_campaign_no_data_error(self, booking_id: str, error_msg: str):
        """Send notification for a campaign that produced no data"""
        self.slack_messenger.send_message(
            event_type=f"Attribution Model Result {self.journey_type.lower().capitalize()} Notification",
            text=f" Campaign No Data: {booking_id}\n {error_msg}",
            data={
                "booking_id": booking_id,
                "correlation_id": self.job_run_id
            }
        )

    def send_campaign_specific_error(self, booking_id: str, error_msg: str, error_category: str):
        """Send immediate notification for critical campaign errors"""
        self.slack_messenger.send_message(
            event_type=f"Attribution Model Result {self.journey_type.lower().capitalize()} Notification",
            text=f"⚠️ Campaign Error: {booking_id}\n🔴 {error_category.upper()}\n📋 {error_msg}",
            data={
                "booking_id": booking_id,
                "error_category": error_category,
                "correlation_id": self.job_run_id
            }
        )
