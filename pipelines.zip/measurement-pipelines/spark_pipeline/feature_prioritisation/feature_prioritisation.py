from typing import List, Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import FeaturePrioritisationConfig, BaselineModellingOutputConfig
from spark_pipeline.schemas.baseline_modelling_output_ucm import BaselineModellingOutput

from spark_pipeline.schemas.feature_prioritisation import FeaturePrioritisation
from spark_pipeline.utils.feature_prioritisation.dataset_creation import (
    dataset_preprocessing,
    dataset_variable_creation,
    initial_dataset_creation,
)
from spark_pipeline.utils.feature_prioritisation.dataset_post_processing import (
    fp_data_post_processing,
    fp_final_output,
)
from spark_pipeline.utils.feature_prioritisation.modelling_functions import (
    feature_prioritization_ensemble,
)
from spark_pipeline.utils.pipeline_utils import get_model_dates
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_feature_prioritisation(
    spark: SparkSession,
    weekly_dates_path: str,
    baseline_modelling_dataset_path: str,
    sku_cluster_mapping_path: str,
    campaign_selection_path: str,
    output_path_feature_prioritisation: str,
    correlation_id: str,
    run_date: str
) -> None:
    """
    This script calculates variable importance rank for all the external/internal factors to be tested in Baseline modelling.
    This decides which variables are given priority to be tested in UCM as they are more likely to help explain
    variation in sales.

    It includes both external and non-external variables, and uses an ensemble model,
    with a linear ranking system to determine the importance of each variable.

    Models used are random forest, XGBoost, and Lasso regression.

    Additionally control variables are created for seasonality, peak, dip, and week start effects.

    * Confluence:
        https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/656801928/Feature+Prioritization

    Args:
        spark (SparkSession): Spark session object.
        weekly_dates_path (str): S3 path for weekly dates data.
        baseline_modelling_dataset_path (str): S3 path for baseline modelling dataset.
        sku_cluster_mapping_path (str): S3 path for SKU cluster mapping.
        campaign_selection_path (str): S3 path for campaign selection data.
        output_path_feature_prioritisation (str): S3 path for feature prioritisation output.
        slack_topic_arn (str): The ARN of the Slack topic for notifications.
        correlation_id (str): The correlation ID for the pipeline run.
        run_date (str): Pipeline run date in YYYY-MM-DD format.
    """

    fp_config = FeaturePrioritisationConfig()
    bl_config = BaselineModellingOutputConfig()

    # Read input data from S3 paths
    weekly_dates_df = (
        spark
        .read
        .parquet(weekly_dates_path)
        .select(F.col("week_start_dt").alias("week_start_date"))
    )

    baseline_modelling_df = (
        spark
        .read
        .parquet(baseline_modelling_dataset_path)
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "variable_cd",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            F.col("correlation_id").alias("job_run_id"),
            "load_ts"
        )
    )

    baseline_primary_metric_df = spark.createDataFrame(
        bl_config.primary_metrics,
        BaselineModellingOutput.primary_metrics_schema)

    cluster_df = (
        spark
        .read
        .parquet(sku_cluster_mapping_path)
        .select(
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "load_ts",
        )
    )

    campaign_selection_filter_df = (
        spark
        .read
        .parquet(campaign_selection_path)
        .filter(F.col("final_status") == F.lit("CLUSTERING"))
        .select(
            "unique_brand_name",
            "super_category_name"
        )
    )

    # Get modelling period dates
    model_start_date, model_end_date = get_model_dates(weekly_dates_df)

    # ToDo Depending on other scripts may remove filtering by latest load_ts
    max_load_ts = (
        baseline_modelling_df
        .agg(F.max("load_ts").alias("max_load_ts"))
        .first()["max_load_ts"]
    )
    baseline_modelling_df = baseline_modelling_df.filter(F.col("load_ts") == max_load_ts)

    # Extract the initial input and target dataframes
    fp_input_y_df, baseline_modelling_df = initial_dataset_creation(baseline_modelling_df, baseline_primary_metric_df, model_start_date, model_end_date)

    # Generate external and non-external features
    external_vars_df, non_external_vars_df = dataset_variable_creation(baseline_modelling_df, fp_config)

    # Define the clusters for modelling
    if campaign_selection_filter_df.count() > 0:
        modelling_clusters_df = get_modelling_cluster_df(cluster_df, campaign_selection_filter_df)
    else:
        modelling_clusters_df = spark.createDataFrame([], FeaturePrioritisation.empty_campaign_selection_schema)

    # Apply pre-processing needed for ML models
    list_of_dependent_vars, input_df_processed, non_external_vars_processed, corr_df = dataset_preprocessing(fp_input_y_df, external_vars_df, non_external_vars_df, modelling_clusters_df)

    # Run the ensemble model to get variable importance ranks
    ml_results_df = feature_prioritization_ensemble(
        list_of_dependent_vars,
        input_df_processed,
        non_external_vars_processed,
        corr_df,
        FeaturePrioritisation.model_outputs_schema,
        fp_config
    )

    post_processed_output = fp_data_post_processing(ml_results_df)

    feature_prioritisation_output = fp_final_output(post_processed_output, baseline_modelling_df)

    # Select and cast required columns
    feature_prioritisation_output = (
        feature_prioritisation_output
        .select(
            F.col("super_category_name").cast(T.StringType()).alias("super_category_name"),
            F.col("unique_brand_name").cast(T.StringType()).alias("unique_brand_name"),
            F.col("cluster_num").cast(T.StringType()).alias("cluster_num"),
            F.col("variable_importance_rank").cast(T.FloatType()).alias("variable_importance_rank"),
            F.lit(correlation_id).alias("job_run_id"),
            F.col("variable_cd").cast(T.StringType()).alias("variable_cd"),
            F.col("marketing_type_name").cast(T.StringType()).alias("marketing_type_name"),
            F.col("marketing_channel_name").cast(T.StringType()).alias("marketing_channel_name"),
            F.col("marketing_sub_channel_name").cast(T.StringType()).alias("marketing_sub_channel_name"),
            F.lit(run_date).alias("load_ts"),
            F.col("metric_name").cast(T.StringType()).alias("metric_name")
        )
    )

    # Use custom method to write to s3 destination output
    spark_s3_overwrite(output_path_feature_prioritisation, feature_prioritisation_output)

    # ToDo Add Slack Alert


def get_modelling_cluster_df(cluster_df: DataFrame, filter_df: DataFrame) -> DataFrame:
    """
    Returns distinct modelling cluster keys for feature prioritization (FP).

    Args:
        cluster_df (DataFrame): Latest clustering results with UNIQUE_BRAND_NAME, SUPER_CATEGORY_NAME, CLUSTER_NUM
        filter_df (DataFrame): Filter combinations to run FP on

    Returns:
        DataFrame: Contains distinct MODELLING_CLUSTER_LIST values
    """
    # Generate join key in both DataFrames
    key_col = F.concat_ws("", F.col("unique_brand_name"), F.col("super_category_name"))
    cluster_df = cluster_df.withColumn("join_key", key_col)
    filter_keys = filter_df.select(key_col.alias("join_key")).distinct()

    # Semi-join to filter clusters
    filtered_df = cluster_df.join(filter_keys, on="join_key", how="semi")

    # Build MODELLING_CLUSTER_LIST column
    result_df = filtered_df.withColumn(
        "modelling_cluster_list",
        F.concat_ws("~", "unique_brand_name", "super_category_name", "cluster_num")
    )

    return result_df.select("modelling_cluster_list").distinct()


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Feature Prioritisation for baseline pipeline.")

    parser.add_argument(
        "--weekly-dates-path",
        type=str,
        required=True,
        help="S3 path for weekly data in the modelling period."
    )
    parser.add_argument(
        "--baseline-modelling-dataset-path",
        type=str,
        required=True,
        help="S3 path for baseline modelling dataset."
    )
    parser.add_argument(
        "--baseline-primary-metric-path",
        type=str,
        required=True,
        help="S3 path for baseline primary metric data."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="S3 path for SKU cluster mapping."
    )
    parser.add_argument(
        "--campaign-selection-path",
        type=str,
        required=True,
        help="S3 path for campaign selection data."
    )
    parser.add_argument(
        "--output-path-feature-prioritisation",
        type=str,
        required=True,
        help="S3 path for campaign selection output."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="The correlation ID for the pipeline run."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_feature_prioritisation(
        spark=spark,
        weekly_dates_path=known_args.weekly_dates_path,
        baseline_modelling_dataset_path=known_args.baseline_modelling_dataset_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        campaign_selection_path=known_args.campaign_selection_path,
        output_path_feature_prioritisation=known_args.output_path_feature_prioritisation,
        correlation_id=known_args.correlation_id,
        run_date=known_args.run_date,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("FeaturePrioritisation").getOrCreate())
