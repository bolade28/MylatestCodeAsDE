from typing import List, Optional
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StringType
from pyspark.sql.window import Window
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


# TODO: This is going to be optimized in the future
def create_three_letter_coding(
    spark: SparkSession,
    channel_processed_data_path: str,
    baseline_modelling_dataset_path: str,
    output_path: str,
    run_date: str,
    correlation_id: str
) -> DataFrame:
    """Create three-letter coding for various columns.

    * Objective:
        - This script creates three-letter coding for various columns from
          channel processed data
        - It maintains consistency with existing codes from baseline modelling
          dataset if available
        - Handles duplicates by adding numeric suffixes or alphabetic sequences
        - Uses conditional alphabetic sequence logic based on baseline existence
        - Produces the same output as the original dbt template
        - Now handles both uppercase and lowercase column names

    * Lineage:
        Upstream:
            - channel_processed_data
            - baseline_modelling_dataset (optional)
        Downstream:
            - Used by baseline modelling dataset creation process

    * Logic Flow:
        1. Get specific columns from channel_processed_data (case-insensitive)
        2. Create initial three-letter codes from first 3 characters
        3. Check if baseline_modelling_dataset exists
        4. If exists: preserve existing codes, handle only new values
        5. If not exists: create codes for all values
        6. Handle duplicates with numeric suffixes or conditional alphabetic sequences
           - If baseline exists: reverse alphabetic (ZZZ, ZZY, ZZX, etc.)
           - If baseline doesn't exist: forward alphabetic (AAA, AAB, AAC, etc.)
    """
    # Read channel processed data
    channel_processed_data_df = (
        spark.read.parquet(channel_processed_data_path)
        .select(
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name"
        )
    )

    # Define columns to process
    columns_to_process = [
        'super_category_name',
        'unique_brand_name',
        'cluster_num',
        'marketing_type_name',
        'marketing_channel_name',
        'marketing_sub_channel_name',
        'metric_name'
    ]

    # Create initial data - union of all specified columns and their distinct values
    def create_column_df(column_name: str):
        """Helper function to create column dataframe"""
        if column_name == 'cluster_num':
            return (
                channel_processed_data_df
                .select(F.col(column_name).cast(StringType()).alias("original_column_value"))
                .filter(F.col(column_name).isNotNull())
                .distinct()
                .withColumn("column_name", F.lit(column_name.upper()))
                .withColumn("first_three_characters", F.substring("original_column_value", 1, 3))
                .select("column_name", "original_column_value", "first_three_characters")
            )
        else:
            return (
                channel_processed_data_df
                .select(F.col(column_name).alias("original_column_value"))
                .filter(F.col(column_name).isNotNull())
                .distinct()
                .withColumn("column_name", F.lit(column_name.upper()))
                .withColumn("first_three_characters", F.substring("original_column_value", 1, 3))
                .select("column_name", "original_column_value", "first_three_characters")
            )

    # Create initial data by combining all column dataframes
    initial_data_dfs = [create_column_df(col) for col in columns_to_process]

    if not initial_data_dfs:
        raise ValueError("No valid columns found to process for three-letter coding")

    initial_data_df = initial_data_dfs[0]
    for df in initial_data_dfs[1:]:
        initial_data_df = initial_data_df.union(df)

    # Extract existing codes from baseline dataset
    def get_baseline_codes():
        """Helper function to get baseline codes if they exist"""
        if not baseline_modelling_dataset_path:
            return spark.createDataFrame([], schema="column_name string, original_column_value string, final_code string")

        try:
            baseline_df = (
                spark.read.parquet(baseline_modelling_dataset_path)
                .select(
                    F.col("SUPER_CATEGORY_NAME").alias("super_category_name"),
                    F.col("UNIQUE_BRAND_NAME").alias("unique_brand_name"),
                    F.col("CLUSTER_NUM").alias("cluster_num"),
                    F.col("MARKETING_TYPE_NAME").alias("marketing_type_name"),
                    F.col("MARKETING_CHANNEL_NAME").alias("marketing_channel_name"),
                    F.col("MARKETING_SUB_CHANNEL_NAME").alias("marketing_sub_channel_name"),
                    F.col("METRIC_NAME").alias("metric_name"),
                    F.col("VARIABLE_CD").alias("variable_cd")
                )
            )
            if baseline_df.count() == 0:
                return spark.createDataFrame([], schema="column_name string, original_column_value string, final_code string")

            # Extract existing codes from variable_cd column
            column_mappings = [
                ("SUPER_CATEGORY_NAME", "super_category_name", 0),
                ("UNIQUE_BRAND_NAME", "unique_brand_name", 1),
                ("CLUSTER_NUM", "cluster_num", 2),
                ("MARKETING_TYPE_NAME", "marketing_type_name", 3),
                ("MARKETING_CHANNEL_NAME", "marketing_channel_name", 4),
                ("MARKETING_SUB_CHANNEL_NAME", "marketing_sub_channel_name", 5),
                ("METRIC_NAME", "metric_name", 6)
            ]

            ads_dict_dfs = []
            for column_name_upper, column_name_lower, position in column_mappings:
                if column_name_lower == "cluster_num":
                    dict_df = (
                        baseline_df
                        .select(
                            F.lit(column_name_upper).alias("column_name"),
                            F.col(column_name_lower).cast(StringType()).alias("original_column_value"),
                            F.split(F.col('variable_cd'), "_").getItem(position).alias("final_code")
                        )
                        .filter(
                            F.col(column_name_lower).isNotNull() &
                            F.split(F.col('variable_cd'), "_").getItem(position).isNotNull()
                        )
                        .distinct()
                    )
                else:
                    dict_df = (
                        baseline_df
                        .select(
                            F.lit(column_name_upper).alias("column_name"),
                            F.col(column_name_lower).alias("original_column_value"),
                            F.split(F.col('variable_cd'), "_").getItem(position).alias("final_code")
                        )
                        .filter(
                            F.col(column_name_lower).isNotNull() &
                            F.split(F.col('variable_cd'), "_").getItem(position).isNotNull()
                        )
                        .distinct()
                    )
                ads_dict_dfs.append(dict_df)

            if ads_dict_dfs:
                ads_dict_df = ads_dict_dfs[0]
                for df in ads_dict_dfs[1:]:
                    ads_dict_df = ads_dict_df.union(df)
                return ads_dict_df.filter(F.col("final_code").isNotNull())
            else:
                return spark.createDataFrame([], schema="column_name string, original_column_value string, final_code string")

        except Exception:
            return spark.createDataFrame([], schema="column_name string, original_column_value string, final_code string")

    # Get baseline codes
    ads_dict_df = get_baseline_codes()

    # Check if baseline exists
    baseline_exists = ads_dict_df.count() > 0

    # Separate existing codes from new codes
    existing_codes_df = (
        initial_data_df
        .join(ads_dict_df.select("column_name", "original_column_value"),
              ["column_name", "original_column_value"], "inner")
        .withColumn("type_data", F.lit(0))
    )

    new_codes_df = (
        initial_data_df
        .join(ads_dict_df.select("column_name", "original_column_value"),
              ["column_name", "original_column_value"], "left_anti")
        .withColumn("type_data", F.lit(1))
    )

    # Combine existing and new codes
    ordered_codes_df = existing_codes_df.union(new_codes_df)

    # Count distinct values for each first_three_characters within each column
    distinct_counts_df = (
        ordered_codes_df
        .groupBy("column_name", "first_three_characters")
        .agg(F.countDistinct("original_column_value").alias("distinct_values_count"))
    )

    # Create window for ranking
    window_spec = Window.partitionBy("column_name", "first_three_characters").orderBy("type_data", "original_column_value")

    # Add ranking and create modified codes
    all_channels_with_codes_df = (
        ordered_codes_df
        .join(distinct_counts_df, ["column_name", "first_three_characters"], "left")
        .withColumn("rank", F.dense_rank().over(window_spec))
        .withColumn(
            "modified_code",
            F.when(
                F.col("distinct_values_count") > 1,
                F.upper(F.concat(
                    F.expr("substring(first_three_characters, 1, 3 - length(cast(rank as string)))"),
                    F.col("rank").cast(StringType())
                ))
            ).otherwise(F.upper(F.col("first_three_characters")))
        )
    )

    # Find duplicates in modified_code
    duplicate_modified_codes = (
        all_channels_with_codes_df
        .groupBy("column_name", "modified_code")
        .agg(F.count("*").alias("duplicate_count"))
        .filter(F.col("duplicate_count") > 1)
        .select("modified_code")
        .distinct()
    )

    # Handle duplicates with alphabetic sequences
    records_needing_duplicate_handling = (
        all_channels_with_codes_df
        .join(duplicate_modified_codes, ["modified_code"], "inner")
        .select("column_name", "original_column_value", "modified_code")
        .withColumn("row_num", F.row_number().over(Window.orderBy("column_name", "original_column_value")))
    )

    # Generate alphabetic codes
    duplicates_df = (
        records_needing_duplicate_handling
        .withColumn(
            "code",
            F.when(
                F.lit(baseline_exists),
                # Reverse alphabetic sequence (ZZZ, ZZY, ZZX, etc.)
                F.upper(F.concat(
                    F.expr("char(122 - ((row_num - 1) / 676))"),
                    F.expr("char(122 - (((row_num - 1) % 676) / 26))"),
                    F.expr("char(122 - ((row_num - 1) % 26))")
                ))
            ).otherwise(
                # Forward alphabetic sequence (AAA, AAB, AAC, etc.)
                F.upper(F.concat(
                    F.expr("char(96 + ((row_num - 1) / 676) + 1)"),
                    F.expr("char(96 + (((row_num - 1) % 676) / 26) + 1)"),
                    F.expr("char(96 + ((row_num - 1) % 26) + 1)")
                ))
            )
        )
        .select("column_name", "original_column_value", "modified_code", "code")
    )

    # Generate final three-letter codes
    # Use join instead of collect() for better performance
    duplicate_codes_indicator = duplicate_modified_codes.withColumn("is_duplicate", F.lit(True))

    three_letter_coding_df = (
        all_channels_with_codes_df
        .join(duplicates_df, ["column_name", "original_column_value", "modified_code"], "left")
        .join(duplicate_codes_indicator, ["modified_code"], "left")
        .withColumn(
            "final_code",
            F.when(
                F.col("is_duplicate").isNotNull(),  # If it's a duplicate
                F.coalesce(F.col("code"), F.col("modified_code"))
            ).otherwise(F.col("modified_code"))
        )
        .select("column_name", "original_column_value", "final_code")
    )

    # Create final output
    final_output_df = (
        ads_dict_df.select("column_name", "original_column_value", "final_code")
        .union(
            three_letter_coding_df
            .join(ads_dict_df.select("column_name", "original_column_value"),
                  ["column_name", "original_column_value"], "left_anti")
            .select("column_name", "original_column_value", "final_code")
        )
    ).orderBy("column_name", "original_column_value")

    write_output_df = (
        final_output_df
        .select(
            "column_name",
            "original_column_value",
            "final_code"
        )
    )

    # Use custom method to write to s3 destination output
    spark_s3_overwrite(output_path, write_output_df)

    return final_output_df


def entrypoint(
    spark: SparkSession,
    command_line_args: Optional[List[str]] = None
) -> None:
    """Entry point for the three letter coding pipeline."""
    parser = ThrowingArgumentParser(
        description="Create Three Letter Coding Dataset."
    )

    parser.add_argument(
        "--channel-processed-data-path",
        type=str,
        required=True,
        help="S3 path for channel processed data."
    )
    parser.add_argument(
        "--baseline-modelling-dataset-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for baseline modelling dataset (optional)."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for output of three letter coding dataset."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for traceability."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    # Call main processing function
    create_three_letter_coding(
        spark=spark,
        channel_processed_data_path=known_args.channel_processed_data_path,
        baseline_modelling_dataset_path=known_args.baseline_modelling_dataset_path,
        output_path=known_args.output_path,
        run_date=known_args.run_date,
        correlation_id=known_args.correlation_id
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder.appName("ThreeLetterCoding").getOrCreate()
    )
