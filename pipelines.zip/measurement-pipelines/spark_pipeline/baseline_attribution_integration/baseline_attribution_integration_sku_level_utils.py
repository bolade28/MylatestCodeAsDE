from typing import List

from prettytable import PrettyTable
from pyspark.sql import DataFrame
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.common.variables import EventType


def truncate_value(value, max_length=30):
    """Truncate value to max_length with ellipsis if needed."""
    str_value = str(value) if value is not None else ""
    return str_value[:max_length - 3] + "..." if len(str_value) > max_length else str_value


def publish_data_metrics(
    df: DataFrame,
    columns: List[str],
    product_type: str,
    slack_messenger: SlackMessenger,
    field_names: List[str],
    message_title: str = "Missing Data Analysis"
) -> None:
    """
    Publishes data metrics to Slack in a formatted table.

    Parameters:
    - df: Spark DataFrame containing the data.
    - columns: List of column names to select from the DataFrame.
    - product_type: A string describing the product type.
    - slack_messenger: Instance of SlackMessenger to send messages.
    - field_names: List of field names for the PrettyTable header.
    - message_title: Optional title for the Slack message.
    """
    data_analysis = df.select(*columns).collect()

    table = PrettyTable()
    table.field_names = field_names

    for row in data_analysis:
        row_data = [truncate_value(getattr(row, col, "")) for col in columns]
        table.add_row(row_data)

    slack_messenger.send_message(
        event_type=EventType.baseline_attribution_integration_sku_level,
        text=f"Baseline attribution missing data metrics for {product_type}:",
        data={message_title: f"```\n{table}\n```"},
    )
