from typing import List, Optional

from pyspark.sql import SparkSession

from spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level_helper import \
    model
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_baseline_integration_sku_level(
        spark: SparkSession,
        baseline_modelling_output_path: str,
        sku_cluster_mapping_path: str,
        sales_data_transformation_path: str,
        campaign_product_type_path: str,
        sku_level_attributed_sales_and_units_level_path: str,
        measurement_campaign_execution_path: str,
        output_path: str,
        mta_baseline_integration_missing_data_output_path: str,
        mta_baseline_integration_zero_or_incrementality_output_path: str,
        product_type: str,
        run_date: str,
        correlation_id: str,
        slack_topic_arn: str,
) -> None:
    baseline_attribution_integration_sku_level_final, missing_data_df, negative_or_zero_incrementality_df = model(
        spark=spark,
        baseline_modelling_output_path=baseline_modelling_output_path,
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        sales_data_transformation_path=sales_data_transformation_path,
        campaign_product_type_path=campaign_product_type_path,
        sku_level_attributed_sales_and_units_level_path=sku_level_attributed_sales_and_units_level_path,
        measurement_campaign_execution_path=measurement_campaign_execution_path,
        product_type=product_type,
        run_date=run_date,
        correlation_id=correlation_id,
        slack_topic_arn=slack_topic_arn
    )

    spark_s3_overwrite(output_path, baseline_attribution_integration_sku_level_final)

    spark_s3_overwrite(mta_baseline_integration_missing_data_output_path, missing_data_df)

    spark_s3_overwrite(mta_baseline_integration_zero_or_incrementality_output_path, negative_or_zero_incrementality_df)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare baseline attribution integration sku level.")
    parser.add_argument(
        "--baseline-modelling-output-path",
        type=str,
        required=True,
        help="S3 path for baseline modelling output data."
    )
    parser.add_argument(
        "--sku-cluster-mapping-path",
        type=str,
        required=True,
        help="S3 path for SKU cluster mapping data."
    )
    parser.add_argument(
        "--sales-data-transformation-path",
        type=str,
        required=True,
        help="S3 path for sales data transformation output."
    )
    parser.add_argument(
        "--campaign-product-type-path",
        type=str,
        required=True,
        help="S3 path for campaign product type data."
    )
    parser.add_argument(
        "--measurement-campaign-execution-path",
        type=str,
        required=True,
        help="S3 path for measurement campaign execution data."
    )
    parser.add_argument(
        "--sku-level-attributed-sales-and-units-level-path",
        type=str,
        required=True,
        help="S3 path for SKU level attributed sales and units data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for baseline attribution integration output."
    )
    parser.add_argument(
        "--mta-baseline-integration-missing-data-output-path",
        type=str,
        required=True,
        help="S3 path for baseline attribution integration output."
    )
    parser.add_argument(
        "--mta-baseline-integration-zero-or-incrementality-output-path",
        type=str,
        required=True,
        help="S3 path for baseline attribution integration output."
    )
    parser.add_argument(
        "--product-type",
        type=str,
        required=True,
        help="Product type to process (e.g., Offer, Brand, Aisle)."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for traceability."
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN of the Slack topic for notifications."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    # Call your main processing function here
    prepare_baseline_integration_sku_level(
        spark=spark,
        baseline_modelling_output_path=known_args.baseline_modelling_output_path,
        sku_cluster_mapping_path=known_args.sku_cluster_mapping_path,
        sales_data_transformation_path=known_args.sales_data_transformation_path,
        campaign_product_type_path=known_args.campaign_product_type_path,
        sku_level_attributed_sales_and_units_level_path=known_args.sku_level_attributed_sales_and_units_level_path,
        measurement_campaign_execution_path=known_args.measurement_campaign_execution_path,
        output_path=known_args.output_path,
        mta_baseline_integration_missing_data_output_path=known_args.mta_baseline_integration_missing_data_output_path,
        mta_baseline_integration_zero_or_incrementality_output_path=known_args.mta_baseline_integration_zero_or_incrementality_output_path,
        product_type=known_args.product_type,
        run_date=known_args.run_date,
        correlation_id=known_args.correlation_id,
        slack_topic_arn=known_args.slack_topic_arn
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("BaselineAttributionSKULevel").getOrCreate())
