import traceback
from typing import Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.window import Window

from spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level_utils import (
    publish_data_metrics,
)
from spark_pipeline.common.variables import (
    BaselineAttributionIntegrationSKULevel,
    EventType,
    ProductType,
)
from spark_pipeline.utils import slack_utils

"""
/**************************************************************************
* Script Name: baseline_attribution_integration_sku_level_aisle.py
*
* Objective:
* This script is designed to compute baseline and attribution integration
* results at the SKU level for aisles. It processes data from upstream
* Snowflake tables, applies business logic, and generates results that are
* stored in a downstream table for further analysis and reporting.
* The script filters the baseline results for the campaign period and the
* targeted SKUs, combining them at the SKU level for each customer journey.
* It calculates incremental sales by deducting baseline sales from attributed
* sales. Similarly, it calculates incremental units by following the same
* process. These computations are essential for understanding the impact of
* marketing campaigns and aisle performance at a granular level.
*
* Key Performance Indicators (KPIs):
* - Incremental Sales: Attributed Sales - Baseline Sales
* - Incremental Units: Attributed Units - Baseline Units
* - Baseline Sales and Units: Derived from historical data for the campaign period
* - Attributed Sales and Units: Derived from campaign performance data
*
* Functions Used from Staging File (ucm_integration_functions.py):
* 1. filter_data: Filters the input data based on specified conditions such as
*    campaign period, targeted SKUs, and customer journey.
* 2. get_campaign_start_end_date: Retrieves the start and end dates of the
*    campaign to ensure accurate filtering and processing of data.
* 3. calculate_sales_proportion: Computes the sales proportion for each SKU
*    based on the baseline and attributed sales data.
* 4. baseline_sku_level_integration: returns bseline and incrementality sales per SKU
*
* Confluence Link: https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/657653976/Integration+with+Baseline
*
* Upstream:
* - SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE
*
* Downstream:
* - MEASUREMENT_CAMPAIGN_REPORTING
*
*
**************************************************************************/
"""


def get_latest_source_data(
        sku_level_results: DataFrame,
        measurement_campaign_execution: DataFrame,
        product_type: str,
        slack_messenger
) -> DataFrame:
    """
    Retrieves the latest source data for a given booking ID and campaign duration.

    Objective:
    This function filters the input DataFrame to retrieve SKU-level sales and units data
    for a specific booking ID and campaign duration. It ensures that only the latest
    available records are returned by identifying the maximum LOAD_TS (timestamp).
    If no matching data is found, it raises an exception.

    Raises:
        ValueError: If no relevant data is found after filtering.
    """

    try:
        required_columns = [
            'booking_id',
            'campaign_duration',
            sku_level_results['campaign_id'].alias('campaign_id'),
            sku_level_results['channel_name'].alias('channel_name'),
            'userjourney_id',
            'loyalty_id',
            'customer_journey_type',
            'journey_type',
            'isconversion',
            'normalized_weights',
            'event_dt',
            'item_cd',
            'net_sales_amt',
            'units_qty',
            'unique_brand_name',
            'week_start_dt',
            'regression_variable',
            sku_level_results['subchannel_name'].alias('subchannel_name'),
            'attributed_sales_amt',
            'attributed_units_qty',
            'attributed_recalibrated_sales_amt',
            'attributed_recalibrated_units_qty',
            'load_ts',
            'marketing_type',
            'campaign_start_dt',
            'campaign_end_dt',
            measurement_campaign_execution['marketing_hierarchy_cd'].alias('marketing_hierarchy_cd'),
        ]
        # TODO: clean up this required_column variable and come up with a more consistent way to select column names.
        # Currently we have some names with string and in some places we are using dataframe and some of this aliasing is redundant.
        if product_type.lower() == ProductType.OFFER.value.lower():
            required_columns.append('recalibration_factor')

        sku_level_filtered = (
            sku_level_results
            .join(
                measurement_campaign_execution, on=['booking_id', 'campaign_id', 'campaign_duration', "subchannel_name"], how='inner'
            )
            .filter(F.col('net_sales_amt') >= 0)
            .select(*required_columns)
        )

        if sku_level_filtered.isEmpty():
            raise ValueError(
                "Error: no data found in SKU-level attributed sales and units to execute the model!"
            )
        mce_count = measurement_campaign_execution.select("campaign_id").distinct().count()
        sku_count = sku_level_filtered.select("campaign_id").distinct().count()
        error_message = "Error: Mismatch in the number of campaign_ids between measurement_campaign_execution and sku_level_results dataframes."
        if mce_count != sku_count:
            slack_messenger.send_message(
                event_type=EventType.baseline_attribution_integration_sku_level,
                text="Baseline Attribution Integration SKU Level",
                data={
                    "Status Update": error_message,
                    "measurement_campaign_execution_count": mce_count,
                    "sku_level_filtered_count": sku_count,
                    "difference": abs(mce_count - sku_count)
                }
            )
            print(error_message)

        window_spec = Window.partitionBy("booking_id", "campaign_duration")

        sku_level_with_max_ts = sku_level_filtered.withColumn(
            "max_load_ts", F.max("load_ts").over(window_spec)
        )

        sku_level_results_filtered = sku_level_with_max_ts.filter(
            F.col("load_ts") == F.col("max_load_ts")
        )

        return sku_level_results_filtered

    except Exception as e:
        error_msg = f"Exception occurred: {type(e).__name__}: {str(e)}"
        traceback_msg = traceback.format_exc()
        raise ValueError(f"{error_msg}\n\nFull traceback:\n{traceback_msg}")


def find_cluster_details(
    measurement_campaign_execution: DataFrame,
    campaign_product_type: DataFrame,
    clustering_df: DataFrame
) -> DataFrame:
    """
    Extracts brand, super category, and cluster details for the given campaign IDs.

    Objective:
    This function retrieves brand names, super category names, and cluster details
    for the specified campaign IDs. It ensures that the extracted data is unique
    and formatted correctly for downstream processing and analysis.
    Returns:
        DataFrame: A Dataframe containing:
            - brand (list): List of unique brand names(str) in uppercase.
            - super_category_name (str): Single unique super category name (if available).
            - final_cluster (list): List of distinct cluster numbers(int).
    Raises:
        Exception: If an error occurs during data extraction or processing, it raises an exception
                   with the error details.
    """
    try:

        skus_mta_df = (
            campaign_product_type
            .join(measurement_campaign_execution, on=["booking_id", "campaign_id", "subchannel_name"], how="inner")
            .select(
                campaign_product_type["booking_id"],
                "item_cd",
                "marketing_hierarchy_cd"
            )
            .distinct()
        )
        final_df = (
            clustering_df
            .join(skus_mta_df, on="item_cd", how="inner")
        )
        return final_df
    except Exception as e:
        error_msg = f"Exception occurred: {type(e).__name__}: {str(e)}"
        traceback_msg = traceback.format_exc()
        raise ValueError(f"{error_msg}\n\nFull traceback:\n{traceback_msg}")


def filter_dataframes_by_cluster(
        baseline_modelling_output: DataFrame,
        sku_cluster_mapping: DataFrame,
        sales_data_transformations_output: DataFrame,
        final_df: DataFrame
) -> Tuple[DataFrame, DataFrame, DataFrame]:
    try:
        filter_criteria = final_df.select(
            "booking_id",
            "unique_brand_name",
            "super_category_name",
            "cluster_num",
            "marketing_hierarchy_cd"
        ).distinct()

        brand_category_cluster_lookup = filter_criteria.select(
            "unique_brand_name", "super_category_name", "cluster_num"
        ).distinct()

        baseline_modelling_output_filtered = baseline_modelling_output.join(
            brand_category_cluster_lookup,
            on=["unique_brand_name", "super_category_name", "cluster_num"],
            how="semi"
        )

        sku_cluster_mapping_filtered = (
            sku_cluster_mapping
            .join(
                brand_category_cluster_lookup,
                on=["unique_brand_name", "super_category_name", "cluster_num"],
                how="semi"
            )
            .join(
                filter_criteria,
                on=["unique_brand_name", "super_category_name", "cluster_num"],
                how="inner"
            )
        )

        sku_item_lookup = (
            sku_cluster_mapping_filtered
            .select("item_cd", "booking_id", "marketing_hierarchy_cd")
            .distinct()
        )

        sales_data_transformation_filtered = (
            sales_data_transformations_output
            .join(sku_item_lookup, on=["item_cd"], how="inner")
        )

        return baseline_modelling_output_filtered, sku_cluster_mapping_filtered, sales_data_transformation_filtered

    except Exception as e:
        error_msg = f"Exception occurred: {type(e).__name__}: {str(e)}"
        traceback_msg = traceback.format_exc()
        raise ValueError(f"{error_msg}\n\nFull traceback:\n{traceback_msg}")


# TODO:: this is a duplicate method, exact same method exist in modelling and sku_attribution - better to create a utils method, therefore skipping the test here
def get_campaign_start_end_date(measurement_campaign_execution_df: DataFrame):
    """
    Retrieves the start and end dates of a campaign based on the booking ID.

    Objective:
    This function aims to provide the start and end dates of a campaign, adjusted to align
    with week boundaries. It ensures accurate date alignment for post-campaign or during-campaign
    analysis, facilitating consistent reporting and data aggregation.

    This function filters the input DataFrame to extract campaign data for a specific
    booking ID. It calculates the start and end dates of the campaign, grouped by
    channel name, booking ID, and campaign duration. Depending on whether the campaign
    is post-campaign or during-campaign, it adjusts the start and end dates to align
    with the week boundaries.

    Used in:
        This function is called within the model sku_level_attributed_sales_and_units_offer/brand/aisle and baseline_attribution_integration_sku_level_offer/brand/aisle.

    Args:
        df (DataFrame): Input DataFrame containing campaign data.
        is_post_campaign (bool): Whether the campaign is post-campaign or during-campaign.
        booking_id (str): Booking ID to filter the campaign.

    Returns:
        tuple: A tuple containing:
            - `campaign_start_date` (str): Campaign start date aligned to the week start.
            - `campaign_end_date` (str): Campaign end date aligned to the week end.
    """
    window_spec = Window.partitionBy('booking_id', 'campaign_id', 'campaign_duration')

    unified_campaign_df = (
        measurement_campaign_execution_df
        .withColumn('campaign_start_dt', F.min('campaign_start_dt').over(window_spec))
        .withColumn('campaign_end_dt', F.max('campaign_end_dt').over(window_spec))
        .select(
            'campaign_start_dt',
            'campaign_end_dt',
            'campaign_duration',
            'booking_id',
            'campaign_id'
        )
        .distinct()
    )

    unified_campaign_df = (
        unified_campaign_df
        .withColumn(
            'campaign_week_start_date',
            F.date_format(F.date_trunc('week', F.min('campaign_start_dt').over(window_spec)), 'yyyy-MM-dd')
        )
        .withColumn(
            'campaign_week_end_date',
            F.date_format(F.date_trunc('week', F.max('campaign_end_dt').over(window_spec)), 'yyyy-MM-dd')
        )
    )
    return unified_campaign_df


# TODO:: maybe add a logic to raise an error if the data is insufficient with pre_campaign_sales
# TODO:: braek this into two separate functions
def calculate_sales_proportion(
        sales_data_output: DataFrame,
        sku_cluster_mapping_filtered: DataFrame,
        campaign_date: DataFrame,
        pre_campaign_weeks: Optional[int] = 6,
        min_pre_camp_sales_threshold: Optional[float] = 0.1
):

    sales_data_output = sales_data_output.withColumn(
        "week_start_dt", F.col("week_start_dt").cast(T.DateType()))

    sales_with_clusters = (
        sales_data_output
        .withColumn("week_start_dt", F.col("week_start_dt").cast(T.DateType()))
        .join(
            sku_cluster_mapping_filtered.drop("marketing_hierarchy_cd") if "marketing_hierarchy_cd" in sku_cluster_mapping_filtered.columns else sku_cluster_mapping_filtered,
            on=["item_cd", "booking_id"],
            how="left",
        ).filter(F.col("cluster_num").isNotNull())
    )

    sales_with_campaign_info = (
        sales_with_clusters
        .join(
            campaign_date, on="booking_id", how="inner"
        )
    )
    cluster_window = Window.partitionBy("unique_brand_name", "super_category_name", "cluster_num", "campaign_id")

    campaign_sales = sales_with_campaign_info.filter(
        (F.col("week_start_dt") >= F.col("campaign_week_start_date")) &
        (F.col("week_start_dt") <= F.col("campaign_week_end_date"))
    )
    campaign_sales = campaign_sales.withColumn(
        "campaign_total_sales_amt",
        F.sum("total_sales_amt").over(cluster_window)
    )

    sales_proportions = campaign_sales.groupBy(
        "booking_id", "campaign_id", "super_category_name", "unique_brand_name", "cluster_num",
        "item_cd", "campaign_total_sales_amt"
    ).agg(
        F.when(F.col("campaign_total_sales_amt") == 0, 0).otherwise(
            F.sum(F.col("total_sales_amt")) / F.col("campaign_total_sales_amt")
        ).alias("campaign_sales_proportion")
    )

    sales_with_dates = sales_with_campaign_info.withColumn(
        "six_weeks_prior_date",
        F.to_date(F.col("campaign_week_start_date")) - F.expr(f"INTERVAL {pre_campaign_weeks * 7} DAYS")
    )

    min_sales_per_booking = (
        sales_with_dates
        .groupBy("booking_id", "campaign_id", "campaign_week_start_date")  # Include it in groupBy
        .agg(F.min("week_start_dt").alias("min_sales_date"))
        .withColumn("six_weeks_prior_date",
                    F.to_date(F.col("campaign_week_start_date")) - F.expr(f"INTERVAL {pre_campaign_weeks * 7} DAYS"))
        .withColumn("pre_campaign_sales_data_exists",
                    F.col("min_sales_date") <= F.col("six_weeks_prior_date"))
        .drop("campaign_week_start_date")
    )

    campaigns_with_history = min_sales_per_booking.filter(
        F.col("pre_campaign_sales_data_exists")
    ).select("booking_id", "campaign_id", "pre_campaign_sales_data_exists")

    sales_with_sufficient_history = sales_with_dates.join(
        campaigns_with_history, on=["booking_id", "campaign_id"], how="inner"
    )

    pre_campaign_sales_df = sales_with_sufficient_history.filter(
        (F.col("week_start_dt") >= F.col("six_weeks_prior_date")) &
        (F.col("week_start_dt") < F.col("campaign_week_start_date"))
    )

    avg_weekly_sales = sales_with_sufficient_history.filter(
        (F.col("week_start_dt") >= F.col("campaign_week_start_date")) &
        (F.col("week_start_dt") <= F.col("campaign_week_end_date"))
    ).groupBy("booking_id", "campaign_id", "super_category_name", "unique_brand_name", "cluster_num", "item_cd").agg(
        F.avg("total_sales_amt").alias("avg_weekly_sales")
    )

    sales_per_sku = pre_campaign_sales_df.join(
        avg_weekly_sales,
        on=["booking_id", "campaign_id", "super_category_name", "unique_brand_name", "cluster_num", "item_cd"],
        how="left"
    ).withColumn(
        "sufficient_pre_campaign_sales",
        F.when(F.col("total_sales_amt") >= F.col("avg_weekly_sales") * min_pre_camp_sales_threshold, 1).otherwise(0)
    ).groupBy(
        "booking_id", "campaign_id", "super_category_name", "unique_brand_name", "cluster_num"
    ).agg(
        F.min("sufficient_pre_campaign_sales").alias("sufficient_pre_campaign_sales")
    )

    sales_proportions = sales_proportions.join(
        sales_per_sku,
        on=["booking_id", "campaign_id", "super_category_name", "unique_brand_name", "cluster_num"],
        how="left"
    )

    filtered_sales_with_cluster = pre_campaign_sales_df.withColumn(
        "pre_campaign_total_sales_amt",
        F.sum("total_sales_amt").over(cluster_window)
    )

    pre_campaign_sales_proportion = filtered_sales_with_cluster.groupBy(
        "booking_id", "campaign_id", "super_category_name", "unique_brand_name", "cluster_num",
        "item_cd", "pre_campaign_total_sales_amt"
    ).agg(
        F.when(F.col("pre_campaign_total_sales_amt") == 0, 0).otherwise(
            F.sum("total_sales_amt") / F.col("pre_campaign_total_sales_amt")
        ).alias("pre_campaign_sales_proportion")
    )

    sales_proportions = sales_proportions.join(
        pre_campaign_sales_proportion,
        on=["booking_id", "campaign_id", "super_category_name", "unique_brand_name", "cluster_num", "item_cd"],
        how="left"
    )

    return sales_proportions, min_sales_per_booking.select("booking_id", "campaign_id", "pre_campaign_sales_data_exists")


def baseline_sku_level_calculation(integrated_df: DataFrame) -> DataFrame:
    """
    Computes the sales proportion, baseline, and incremental sales at the SKU level.

    The pre_campaign_sales_data_exists flag should already be in integrated_df per booking_id.
    """

    result_df = integrated_df.withColumn(
        "sales_proportion",
        F.when(
            (F.col("pre_campaign_sales_data_exists")) &
            (F.coalesce(F.col("sufficient_pre_campaign_sales"), F.lit(0)) >= 1),
            F.coalesce(F.col("pre_campaign_sales_proportion"), F.col("campaign_sales_proportion"))
        ).otherwise(F.col("campaign_sales_proportion"))
    )

    result_df = result_df.withColumn(
        "baseline",
        F.col("sales_proportion") * F.col("cluster_baseline")
    )

    result_df = result_df.withColumn(
        "incremental",
        F.col("total_sales_amt") - F.col("baseline")
    )

    return result_df


def baseline_sku_level_integration(
        baseline: DataFrame,
        sku_mapping: DataFrame,
        sales: DataFrame,
        sales_proportions: DataFrame,
        pre_campaign_sales_data_exists: DataFrame
) -> DataFrame:
    """
    Integrates cluster-level baseline data with SKU-level mappings and sales data.
    """

    # 1. Initial Cleanup
    baseline_renamed = (
        baseline
        .withColumnRenamed("total_sales_amt", "cluster_sales")
        .withColumnRenamed("total_baseline_amt", "cluster_baseline")
    )

    if "total_incremental_amt" in baseline_renamed.columns:
        baseline_renamed = baseline_renamed.drop("total_incremental_amt")

    # 2. Add Booking Context (with safe column merging)
    if "booking_id" not in baseline_renamed.columns:
        booking_context = sku_mapping.select(
            "booking_id", "super_category_name", "unique_brand_name", "cluster_num", "marketing_hierarchy_cd"
        ).distinct()

        # We must include marketing_hierarchy_cd in join keys if it exists
        # in the baseline to prevent creating a duplicate column.
        context_join_keys = ["super_category_name", "unique_brand_name", "cluster_num"]
        if "marketing_hierarchy_cd" in baseline_renamed.columns:
            context_join_keys.append("marketing_hierarchy_cd")

        baseline_with_booking = baseline_renamed.join(
            booking_context,
            on=context_join_keys,
            how="inner"
        )
    else:
        baseline_with_booking = baseline_renamed

    # 3. Safe Hierarchy Check
    # We use a safer check that doesn't trigger ambiguity if the column is already duplicated
    def has_hierarchy(df):
        return "marketing_hierarchy_cd" in df.columns and \
               df.filter(F.col("marketing_hierarchy_cd").isNotNull()).limit(1).count() > 0

    use_marketing_hierarchy = has_hierarchy(baseline_with_booking) and has_hierarchy(sku_mapping)

    # 4. SKU Mapping Join
    base_join_keys = ["booking_id", "super_category_name", "unique_brand_name", "cluster_num"]
    sku_mapping_to_join = sku_mapping

    if use_marketing_hierarchy:
        base_join_keys.append("marketing_hierarchy_cd")
    else:
        # CRITICAL FIX: If we aren't joining on it, drop it from the right side
        # so it doesn't conflict with the one already in baseline_with_booking.
        if "marketing_hierarchy_cd" in sku_mapping_to_join.columns:
            sku_mapping_to_join = sku_mapping_to_join.drop("marketing_hierarchy_cd")

    baseline_w_skus = baseline_with_booking.join(
        sku_mapping_to_join,
        on=base_join_keys,
        how="left"
    )

    # 5. Sales Join
    sales_join_keys = ["booking_id", "week_start_dt", "item_cd"]
    sales_to_join = sales

    if "marketing_hierarchy_cd" in sales_to_join.columns:
        sales_to_join = sales_to_join.drop("marketing_hierarchy_cd")

    baseline_and_sales = baseline_w_skus.join(
        sales_to_join,
        on=sales_join_keys,
        how="left"
    )

    # 6. Sales Proportions Join
    # Ensure sales_proportions doesn't bring in a duplicate hierarchy column either
    sales_prop_to_join = sales_proportions
    if not use_marketing_hierarchy and "marketing_hierarchy_cd" in sales_prop_to_join.columns:
        sales_prop_to_join = sales_prop_to_join.drop("marketing_hierarchy_cd")

    integrated_df = baseline_and_sales.join(
        sales_prop_to_join,
        on=["booking_id", "super_category_name", "unique_brand_name", "cluster_num", "item_cd"],
        how="left"
    )

    # 7. Final Integrations and Logic
    integrated_df = integrated_df.join(
        pre_campaign_sales_data_exists,
        on=["booking_id", "campaign_id"],
        how="left"
    ).fillna(False, subset=["pre_campaign_sales_data_exists"])

    # This function must handle its own column references carefully
    integrated_df = baseline_sku_level_calculation(integrated_df)

    # 8. Cleanup
    columns_to_drop = [
        "cluster_sales", "cluster_baseline", "sales_proportion",
        "campaign_total_sales_amt", "campaign_sales_proportion",
        "sufficient_pre_campaign_sales", "pre_campaign_total_sales_amt",
        "pre_campaign_sales_proportion", "pre_campaign_sales_data_exists"
    ]

    existing_columns_to_drop = [col for col in columns_to_drop if col in integrated_df.columns]
    return integrated_df.drop(*existing_columns_to_drop)


def log_missing_data(
        mta_mmm_integration: DataFrame, sku_level_results_filtered: DataFrame, correlation_id: str, run_date: str
):
    """
    Logs missing SKU data in the MTA-MMM integration process.

    Objective:
    This function identifies and logs missing SKU data by filtering rows where `SUM_BASELINE_AMT`
    is NULL in the MTA-MMM integration DataFrame. It determines whether all or some SKUs are
    missing and appends the relevant data to the `BASELINE_INTEGRATION_SKU` table with appropriate
    comments for further analysis.
    The log_missing_data function is logging missing SKU data where the baseline attribution modeling couldn't find matching baseline amounts (SUM_BASELINE_AMT is NULL). This typically happens when:

    SKU data is missing from the baseline modeling results
    Brand or super category data is absent from the underlying data sources
    There's a data quality issue in the attribution pipeline

    Raises:
        Exception: If an error occurs during the filtering or logging process, it raises an exception
                   with the error details.
    """
    try:
        expected_per_booking = (
            sku_level_results_filtered
            .select("item_cd", "booking_id", "journey_type", "campaign_duration")
            .distinct()
            .groupBy("booking_id", "journey_type", "campaign_duration")
            .agg(F.count("item_cd").alias("expected_sku_count"))
        )
        unmatched_rows = (
            mta_mmm_integration.filter(F.col("sum_baseline_amt").isNull())
            .select("item_cd", "booking_id", "journey_type", "campaign_duration")
            .distinct()
        )

        missing_per_booking = (
            unmatched_rows
            .groupBy("booking_id", "journey_type", "campaign_duration")
            .agg(
                F.count("item_cd").alias("missing_sku_count"),
                F.collect_list("item_cd").alias("missing_skus_list")  # Complete list, no truncation
            )
        )

        booking_analysis = (
            expected_per_booking
            .join(missing_per_booking, on=["booking_id", "journey_type", "campaign_duration"], how="left")
            .fillna(0, subset=["missing_sku_count"])
            .withColumn("all_missing", F.col("missing_sku_count") == F.col("expected_sku_count"))
            .withColumn("status",
                        F.when(F.col("missing_sku_count") == 0, " No missing SKUs")
                        .when(F.col("all_missing"), "ALL SKUs missing")
                        .otherwise("Some SKUs missing"))
            .withColumn("complete_sku_list",
                        F.when(F.col("missing_sku_count") > 0,
                               F.array_join(F.col("missing_skus_list"), ", ")  # Join ALL SKUs, no slicing
                               ).otherwise(F.lit("N/A")))
            .withColumn("correlation_id", F.lit(correlation_id))
            .withColumn("load_ts", F.lit(run_date))

        )

        return booking_analysis

    except Exception as e:
        error_msg = f"Exception occurred: {type(e).__name__}: {str(e)}"
        traceback_msg = traceback.format_exc()
        raise ValueError(f"{error_msg}\n\nFull traceback:\n{traceback_msg}")


def log_negative_or_zero_incrementality(
    baseline_attribution_integration_sku_level: DataFrame, correlation_id: str, run_date: str
):
    """
    Logs SKUs with negative or zero incrementality in the baseline attribution process.

    Objective:
    This function identifies and logs SKUs where the `INCREMENTALITY_EXPOSED` value
    is either negative or zero in the `baseline_attribution_integration_sku_level` DataFrame.
    It appends the relevant data to the `BASELINE_INTEGRATION_SKU` table with appropriate
    comments for further analysis and tracking.
    Returns:
        None: The function writes the identified SKU data to the `BASELINE_INTEGRATION_SKU` table
              and does not return any value.
    Raises:
        Exception: If an error occurs during the filtering or logging process, it raises an exception
                   with the error details.
    """
    try:
        zero_negative_incrementality = (
            baseline_attribution_integration_sku_level.filter(F.col("incrementality_exposed") <= 0)
            .select("item_cd", "booking_id", "journey_type", "campaign_duration", "incrementality_exposed")
            .withColumn("correlation_id", F.lit(correlation_id))
            .withColumn("load_ts", F.lit(run_date))
            .withColumn("comment",
                        F.when(F.col("incrementality_exposed") < 0, F.lit("incrementality is negative"))
                         .when(F.col("incrementality_exposed") == 0, F.lit("incrementality is zero")))
            .drop("incrementality_exposed")
            .distinct()
        )
        negative_incrementality = zero_negative_incrementality.filter(F.col("comment") == "incrementality is negative")
        zero_incrementality = zero_negative_incrementality.filter(F.col("comment") == "incrementality is zero")

        return negative_incrementality, zero_incrementality
    except Exception as e:
        error_msg = f"Exception occurred: {type(e).__name__}: {str(e)}"
        traceback_msg = traceback.format_exc()
        raise ValueError(f"{error_msg}\n\nFull traceback:\n{traceback_msg}")


def replace_nulls_with_zero(baseline_attribution_integration_sku_level: DataFrame) -> DataFrame:
    """
    Replaces null values with zero in specific columns using fillna() method.
    """
    try:
        columns_to_fill = [
            "frequency_of_purchase",
            "online_sales_pct",
            "supermarket_sales_pct",
            "convenience_sales_pct",
            "sum_baseline_amt",
            "sum_of_incr_amt",
            "sum_of_sales_amt",
            "baseline",
            "total_sales_amt",
        ]

        fill_dict = {col: 0 for col in columns_to_fill}

        return baseline_attribution_integration_sku_level.fillna(fill_dict)

    except Exception as e:
        error_msg = f"Exception occurred in replace_nulls_with_zero: {type(e).__name__}: {str(e)}"
        traceback_msg = traceback.format_exc()
        raise ValueError(f"{error_msg}\n\nFull traceback:\n{traceback_msg}")


def calculate_attributed_recalibrated_sales(campaign_date, sku_avg_window, mta_mmm_integration):
    """
    Objective:
    This function calculates the total attributed recalibrated sales amount (SUM_OF_ATTR_SALES_AMT) for a SKU during its campaign period.

    The approach varies based on the number of campaigns under the same booking ID:
    1. If there is only one campaign, the total attributed recalibrated sales amount is calculated by summing
    `attributed_recalibrated_sales_amt` across the SKU, campaign_id, and booking_id.
    2. If there are multiple campaigns under the same booking ID, the function joins with the `campaign_date` dataframe
    to calculate `attributed_recalibrated_sales_amt` over the campaign dates for the specific campaign.

    Note: When there are overlapping campaigns, performing the calculation at the campaign_id will underestimate
    the `attributed_recalibrated_sales_amt` for the SKU over the campaign period. This is why the calculation is adjusted
    to account for overlaps.
    Args:
        campaign_date: Dataframe has the campaign start and end date per booking_id and campaign_id
        sku_avg_window: window over "item_cd", "booking_id", "campaign_id"
        mta_mmm_integration: DataFrame containing SKU-level attributed sales data for the campaigns
    Returns:
        DataFrame: The input DataFrame with an additional column `sum_of_attr_sales_amt` representing the total attributed recalibrated sales amount.
    Raises:
        ValueError: If there is a mismatch in the number of campaign_ids between the `campaign_date` and `mta_mmm_integration` dataframes.
    """
    cnt_campaign = campaign_date.agg(F.countDistinct("campaign_id")).first()[0]
    cnt_mta = mta_mmm_integration.agg(F.countDistinct("campaign_id")).first()[0]
    if cnt_campaign != cnt_mta:
        raise ValueError("Mismatch in the number of campaign_ids between campaign_date and mta_mmm_integration dataframes.")

    if campaign_date.select("campaign_id").distinct().count() == 1:
        # Calculate SUM_OF_ATTR_SALES_AMT using a window function over SKU-level data
        mta_mmm_integration_with_total_sales = mta_mmm_integration.withColumn(
            "sum_of_attr_sales_amt",
            F.sum("attributed_recalibrated_sales_amt").over(sku_avg_window),)
    else:
        # Calculate SUM_OF_ATTR_SALES_AMT using a window function over SKU-level data

        # Below returns the total attributed sales amount for the campaign start and end date range
        # this is because we have multiple campaigns running and we need to get the attributed sales amount
        # for campaign overlapping date range
        total_attr_sales_campaign = (
            mta_mmm_integration.drop("campaign_id").join(
                campaign_date,
                (F.col("week_start_dt") >= F.col("campaign_week_start_date")) & (F.col("week_start_dt") <= F.col("campaign_week_end_date"))
            )
            .groupBy(F.col("campaign_id"), F.col("item_cd"))  # Group by campaign_id from campaign_dates
            .agg(F.sum(F.col("attributed_recalibrated_sales_amt")).alias("sum_of_attr_sales_amt"))
            .select(F.col("campaign_id"), F.col("item_cd"), F.col("sum_of_attr_sales_amt"))
        )

        mta_mmm_integration_with_total_sales = mta_mmm_integration.join(
            total_attr_sales_campaign,
            on=["campaign_id", "item_cd"],
            how="left"
        )
    return mta_mmm_integration_with_total_sales


# TODO:: too long need to break it into several functions
# TODO:: improve the exception handling
# TODO:: select the required columns rather than removing unnecessary ones
def model(
    spark: SparkSession,
    baseline_modelling_output_path: str,
    sku_cluster_mapping_path: str,
    sales_data_transformation_path: str,
    campaign_product_type_path: str,
    sku_level_attributed_sales_and_units_level_path: str,
    measurement_campaign_execution_path: str,
    product_type: str,
    run_date: str,
    correlation_id: str,
    slack_topic_arn: str
) -> tuple[DataFrame, DataFrame, DataFrame]:
    """
        Processes baseline attribution data at the SKU and offer level for marketing campaigns.

        Objective:
        This function integrates baseline and attribution data at the SKU and offer level,
        applying business logic to calculate key metrics such as incremental sales,
        incrementality ratios, and recalibrated sales. It ensures data consistency,
        handles missing values, and prepares the data for downstream reporting and analysis.

        Returns:
            DataFrame: A processed DataFrame containing integrated baseline attribution data at the SKU
                       level for offer, ready for downstream analysis and reporting at campaign level for each targeted
                       marketing type channel and sub channel.
        Raises:
            Exception: If an error occurs during data processing, it logs the error details
                       and raises the exception to stop execution.
        """

    slack_messenger = slack_utils.SlackMessenger(
        topic_arn=slack_topic_arn,
        correlation_id=correlation_id
    )
    try:
        baseline_modelling_output_df = (
            spark
            .read
            .parquet(baseline_modelling_output_path)
            .select(
                'week_start_dt',
                'super_category_name',
                'unique_brand_name',
                'cluster_num',
                'iteration',
                'modelling_type',
                'job_run_id',
                'metric_name',
                'load_ts',
                'best_iteration',
                'metric_value',
                'rsq',
                'wsmape',
                'baseline_perc'
            )
        )

        sku_cluster_mapping_df = (
            spark
            .read
            .parquet(sku_cluster_mapping_path)
            .select(
                'item_cd',
                'super_category_name',
                'unique_brand_name',
                'cluster_num',
                'load_ts',
                'modelling_type'

            )
            .withColumn("item_cd", F.col("item_cd").cast(T.IntegerType()))
        )

        sales_data_transformation_df = (
            spark
            .read
            .parquet(sales_data_transformation_path)
            .select(
                'week_start_dt',
                'item_cd',
                'total_sales_amt',
                'nectar_sales_amt',
                'non_nectar_sales_amt',
                'frequency_of_purchase',
                'distinct_customer_cnt',
                'avg_purchase_per_customer_cnt',
                'online_sales_pct',
                'supermarket_sales_pct',
                'convenience_sales_pct',
                'pack_size',
                'price_per_point',
                'base_price_amt'
            )
            .withColumn("item_cd", F.col("item_cd").cast(T.IntegerType()))
        )

        campaign_product_type_df = (
            spark
            .read
            .parquet(campaign_product_type_path)
            .select(
                'item_cd',
                'product_type',
                'channel_name',
                'subchannel_name',
                'booking_id',
                'campaign_id',
                'sku_name',
                'sub_cat_name',
                'brand_name',
                'brand_owner_name',
                'unique_brand_name',
                'load_ts',
            )
            .withColumn("item_cd", F.col("item_cd").cast(T.IntegerType()))

        )

        measurement_campaign_execution_df = (
            spark
            .read
            .parquet(measurement_campaign_execution_path)
            .select(
                'booking_id',
                'campaign_duration',
                'campaign_start_dt',
                'campaign_end_dt',
                'channel_name',
                'subchannel_name',
                'campaign_id',
                'marketing_hierarchy_cd'
            )
            .distinct()
        )

        if measurement_campaign_execution_df.isEmpty():
            message = f"no campaign found for {product_type}"
        else:
            message = f"{measurement_campaign_execution_df.count()} in-progress campaign found for {product_type}"

        slack_messenger.send_message(
            event_type=EventType.baseline_attribution_integration_sku_level,
            text="Baseline Attribution Integration SKU Level",
            data={"Status Update": message}
        )

        required_columns = [
            'campaign_id',
            'channel_name',
            'userjourney_id',
            'loyalty_id',
            'booking_id',
            'customer_journey_type',
            'journey_type',
            'isconversion',
            'normalized_weights',
            'campaign_duration',
            'event_dt',
            'item_cd',
            'net_sales_amt',
            'units_qty',
            'unique_brand_name',
            'week_start_dt',
            'regression_variable',
            'subchannel_name',
            'attributed_sales_amt',
            'attributed_units_qty',
            'attributed_recalibrated_sales_amt',  # change the typo later
            'attributed_recalibrated_units_qty',  # change the typo later
            'job_run_id',
            'load_ts',
            'marketing_type'
        ]

        if product_type.lower() == ProductType.OFFER.value.lower():
            required_columns.append('recalibration_factor')

        # TODO:: PostMigrationTask item_cd should be string tho, but we need to apply it everywhere
        sku_level_attributed_sales_and_units_level_df = (
            spark
            .read
            .parquet(sku_level_attributed_sales_and_units_level_path)
            .select(*required_columns)
            .distinct()
            .withColumn("item_cd", F.col("item_cd").cast(
                T.IntegerType()))
        )

        baseline_modelling_output_df = (
            baseline_modelling_output_df
            .filter(F.col('best_iteration') == 'Y')
        )

        baseline_max_cat = (
            baseline_modelling_output_df.groupBy(
                "week_start_dt", "super_category_name", "unique_brand_name"
            ).agg(F.max(F.col("load_ts")).alias("load_ts"))
        )

        baseline_modelling_output = (
            baseline_modelling_output_df
            .join(
                baseline_max_cat,
                on=["week_start_dt", "super_category_name", "unique_brand_name", "load_ts"],
                how='inner'
            )
        )

        # TODO: I was getting two columnns one with total_baseline_amt and another with TOTAL_BASELINE_AMT
        # and then on line 973 this code was failing when selecing total_baseline_amt with error
        #  [AMBIGUOUS_REFERENCE] Reference `total_baseline_amt` is ambiguous, could be: [`total_baseline_amt`, `total_baseline_amt`].
        # so here I've tried to standardise column names to avoid this error. Please double check this logic.
        baseline_modelling_output = baseline_modelling_output.withColumn(
            "metric_name",
            F.upper(F.trim(F.col("metric_name")))  # Standardize to uppercase
        )

        baseline_modelling_output = baseline_modelling_output.groupBy(
            "week_start_dt", "super_category_name", "unique_brand_name", "cluster_num", "iteration"
        ).pivot("metric_name").agg(F.sum("metric_value"))
        # # TODO:: source data issue, not sure if this is the best approach, temporary fix
        # expected_metrics = ["TOTAL_BASELINE_AMT", "TOTAL_INCREMENTAL_AMT", "TOTAL_SALES_AMT", "TOTAL_SEASONALITY_AMT"]
        #
        # baseline_modelling_output = baseline_modelling_output.groupBy(
        #     "week_start_dt", "super_category_name", "unique_brand_name", "cluster_num", "iteration"
        # ).pivot("metric_name", expected_metrics).agg(F.sum("metric_value"))

        # when converted some column names become upper case, concertig them all to lowercase
        baseline_modelling_output = baseline_modelling_output.toDF(
            *[c.lower() for c in baseline_modelling_output.columns])

        # TODO:: PostMigrationTask::
        #  selecting this column means all of these varible must exist(may cause error if any of these are missing in pivot, need to investiagte later)

        baseline_modelling_output = baseline_modelling_output.select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "total_sales_amt",
            "total_baseline_amt",
            "total_incremental_amt",
            "total_seasonality_amt",
            "iteration",
        ).distinct()

        sku_level_results_filtered = get_latest_source_data(
            sku_level_attributed_sales_and_units_level_df,
            measurement_campaign_execution_df,
            product_type=product_type,
            slack_messenger=slack_messenger
        )

        # TODO:: PostMigrationTask::
        #  Do we need to add only required one(the one that we have attribution data for? or everything?
        #  these campaigns are required for processing... need to test tho
        #  how are we gonna check for missing data
        required_campaigns = (
            sku_level_results_filtered.select(
                'booking_id',
                'campaign_duration',
                'campaign_start_dt',
                'campaign_end_dt',
                'campaign_id',
                'marketing_hierarchy_cd',
                'subchannel_name'
            )
            .distinct()
        )

        # TODO:: PostMigrationTask::
        #  need to move this to global method - also I deleted the channel name in partitioning
        campaign_date = get_campaign_start_end_date(
            required_campaigns
        )

        sku_cluster_mapping_max = sku_cluster_mapping_df.groupBy("item_cd").agg(
            F.max(F.col("load_ts")).alias("load_ts")
        )

        sku_cluster_mapping = sku_cluster_mapping_max.join(
            sku_cluster_mapping_df,
            on=["item_cd", "load_ts"],
            how="inner",
        )

        sku_level_results_filtered = sku_level_results_filtered.withColumn(
            "item_cd", F.col("item_cd").cast(T.IntegerType())
        ).withColumn("week_start_dt", F.col("week_start_dt").cast(T.DateType()))

        campaign_product_type_filtered = (
            campaign_product_type_df
            .filter(F.lower(F.col("product_type")) == F.lower(F.lit(product_type)))  # filter based on product type
            .join(
                required_campaigns,
                on=["booking_id"],
                how="inner"
            )
            .select(
                campaign_product_type_df['booking_id'],
                'item_cd',
                'product_type',
                campaign_product_type_df['channel_name'],
                campaign_product_type_df['subchannel_name'],
                campaign_product_type_df['campaign_id'],
                'sku_name',
                'sub_cat_name',
                'brand_name',
                'brand_owner_name',
                'unique_brand_name',
                'load_ts',
                'campaign_duration'
            )
        )

        final_df = find_cluster_details(
            required_campaigns,
            campaign_product_type_filtered,
            sku_cluster_mapping
        )

        baseline_output_filtered, sku_cluster_mapping_filtered, sales_data_output = filter_dataframes_by_cluster(
            baseline_modelling_output,
            sku_cluster_mapping,
            sales_data_transformation_df,
            final_df
        )

        sales_proportions, pre_campaign_sales_data_exists = calculate_sales_proportion(
            sales_data_output,
            sku_cluster_mapping_filtered,
            campaign_date,
            BaselineAttributionIntegrationSKULevel.pre_campaign_weeks,
            BaselineAttributionIntegrationSKULevel.min_pre_camp_sales_threshold
        )

        baseline_integrated_df_filtered = baseline_sku_level_integration(baseline_output_filtered,
                                                                         sku_cluster_mapping_filtered,
                                                                         sales_data_output, sales_proportions,
                                                                         pre_campaign_sales_data_exists)

        baseline_integrated_df_filtered = baseline_integrated_df_filtered.drop(
            "cluster_num",
            "super_category_name",
            "iteration",
            "unique_brand_name",
            "distinct_customer_cnt",
            "avg_purchase_per_customer_cnt",
            "job_run_id",
            "price_per_point",
            "base_price_amt",
            "marketing_hierarchy_cd",  # Drop to avoid ambiguity with sku_level_results_filtered
        )

        """
        Extracting the campaign start date and campaign end date
        from measurement campaign execution table, which are required to filter the
        baseline data
        """

        baseline_integrated_df_filtered = (
            baseline_integrated_df_filtered
            .join(
                campaign_date.select(
                    'booking_id',
                    'campaign_id',
                    'campaign_week_start_date',
                    'campaign_week_end_date'
                ),
                on=['booking_id', 'campaign_id'],
                how='inner'
            )
            .filter(
                (F.col("week_start_dt") >= F.col("campaign_week_start_date")) &
                (F.col("week_start_dt") <= F.col("campaign_week_end_date"))
            )
            .distinct()
        )

        sku_avg_window = Window.partitionBy("item_cd", "booking_id", "campaign_id")
        baseline_integrated_df_filtered = (
            baseline_integrated_df_filtered
            .withColumn(
                "sum_baseline_amt", F.sum("baseline").over(sku_avg_window)
            )
            .withColumn("sum_of_sales_amt", F.sum("total_sales_amt").over(sku_avg_window))
        )
        required_columns = [
            'week_start_dt',
            'item_cd',
            'booking_id',
            'campaign_id',
            'campaign_duration',
            'channel_name',
            'userjourney_id',
            'loyalty_id',
            'customer_journey_type',
            'journey_type',
            'isconversion',
            'normalized_weights',
            'event_dt',
            'net_sales_amt',
            'units_qty',
            'unique_brand_name',
            'regression_variable',
            'subchannel_name',
            'attributed_sales_amt',
            'attributed_units_qty',
            'attributed_recalibrated_sales_amt',
            'attributed_recalibrated_units_qty',
            'marketing_type',
            'campaign_start_dt',
            'campaign_end_dt',
            'total_seasonality_amt',
            'modelling_type',
            'total_sales_amt',
            'nectar_sales_amt',
            'non_nectar_sales_amt',
            'frequency_of_purchase',
            'online_sales_pct',
            'supermarket_sales_pct',
            'convenience_sales_pct',
            'pack_size',
            'baseline',
            'incremental',
            'sum_baseline_amt',
            'sum_of_sales_amt',
            'marketing_hierarchy_cd'
        ]

        if product_type.lower() == ProductType.OFFER.value.lower():
            required_columns.append('recalibration_factor')
        mta_mmm_integration = (
            sku_level_results_filtered
            .join(
                baseline_integrated_df_filtered, on=["week_start_dt", "item_cd", "booking_id", "campaign_id"],
                how="outer"
            )
            .select(*required_columns)
        )

        available_columns = mta_mmm_integration.columns
        final_required_columns = [col for col in required_columns if col in available_columns]
        mta_mmm_integration = mta_mmm_integration.select(*final_required_columns).cache()

        missing_data_df = log_missing_data(
            mta_mmm_integration, sku_level_results_filtered, correlation_id, run_date
        )

        publish_data_metrics(
            df=missing_data_df,
            columns=[
                "booking_id",
                "journey_type",
                "missing_sku_count",
            ],
            product_type=product_type,
            slack_messenger=slack_messenger,
            field_names=[
                "Booking ID",
                "Journey Type",
                "Missing SKUs"
            ],
            message_title="Missing Data Analysis"
        )

        mta_mmm_integration = mta_mmm_integration.withColumn(
            "sum_baseline_amt",
            F.when(F.col("sum_baseline_amt").isNull(), 0).otherwise(F.col("sum_baseline_amt")),
        )

        mta_mmm_integration = calculate_attributed_recalibrated_sales(campaign_date, sku_avg_window, mta_mmm_integration)

        baseline_attribution_integration_sku_level = (
            mta_mmm_integration
            .withColumn(
                "sum_of_incr_amt",
                F.coalesce(F.col("sum_of_sales_amt"), F.lit(0.0)) - F.coalesce(F.col("sum_baseline_amt"), F.lit(0.0))
            )
            .withColumn(
                "incrementality_total",
                F.when(
                    (F.col("sum_of_sales_amt").isNotNull()) &
                    (F.col("sum_of_sales_amt") > 0),
                    F.col("sum_of_incr_amt") / F.col("sum_of_sales_amt")
                ).otherwise(F.lit(0.0))
            )
            .withColumn(
                "incrementality_exposed",
                F.when(
                    (F.col("sum_of_attr_sales_amt").isNotNull()) &
                    (F.col("sum_of_attr_sales_amt") > 0),
                    F.col("sum_of_incr_amt") / F.col("sum_of_attr_sales_amt")
                ).otherwise(F.lit(0.0))
            )
        )

        negative_incrementality, zero_incrementality = log_negative_or_zero_incrementality(
            baseline_attribution_integration_sku_level, correlation_id, run_date
        )

        if not negative_incrementality.isEmpty():
            publish_data_metrics(
                df=negative_incrementality,
                columns=[
                    "item_cd",
                    "booking_id",
                    "journey_type",
                    "comment"
                ],
                product_type=product_type,
                slack_messenger=slack_messenger,
                field_names=[
                    "Item Code",
                    "Booking ID",
                    "Journey Type",
                    "Comment"
                ],
                message_title="Negative Incrementality SKUs"
            )

        if not zero_incrementality.isEmpty():
            publish_data_metrics(
                df=zero_incrementality,
                columns=[
                    "item_cd",
                    "booking_id",
                    "journey_type",
                    "comment"
                ],
                product_type=product_type,
                slack_messenger=slack_messenger,
                field_names=[
                    "Item Code",
                    "Booking ID",
                    "Journey Type",
                    "Comment"
                ],
                message_title="Zero Incrementality SKUs"
            )

        log_negative_or_zero_incrementality_df = negative_incrementality.union(zero_incrementality)

        baseline_attribution_integration_sku_level = (
            # Keep original incrementality values (including negative ones) at SKU level
            # to avoid inflating incrementality calculations. Negative values will be zeroed
            # out at the reporting level (measurement_campaign_reporting) instead.
            baseline_attribution_integration_sku_level
            # Compute incremental sales amount exposed customers obtained by multiplying attributed sales amount with
            # the calculated incrementality ratio for the exposed customers
            .withColumn(
                "incremental_sales_amt_exposed",
                F.col("attributed_recalibrated_sales_amt") * F.col("incrementality_exposed"),
            )
            # Compute incremental units exposed customers obtained by multiplying attributed unit amount with
            # the calculated incrementality ratio for the exposed customers
            .withColumn(
                "incremental_units_qty_exposed",
                F.col("attributed_recalibrated_units_qty") * F.col("incrementality_exposed"),
            )
            # Compute incremental sales amount and units for total SKUs
            .withColumn(
                "incremental_sales_amt_total",
                F.col("attributed_recalibrated_sales_amt") * F.col("incrementality_total"),
            )
            .withColumn(
                "incremental_units_qty_total",
                F.col("attributed_recalibrated_units_qty") * F.col("incrementality_total"),
            )
            # Add metadata columns for tracking job execution and load timestamp
            .withColumn("correlation_id", F.lit(correlation_id))
            .withColumn("load_ts", F.lit(run_date))
        )

        # Keep negative incrementality values - DO NOT zero them at this step
        # Negative values will be handled at the reporting level instead
        baseline_attribution_integration_sku_level = replace_nulls_with_zero(
            baseline_attribution_integration_sku_level
        )

        required_columns = [
            'campaign_id',
            'userjourney_id',
            'loyalty_id',
            'booking_id',
            'customer_journey_type',
            'journey_type',
            'isconversion',
            'normalized_weights',
            'campaign_duration',
            'event_dt',
            'net_sales_amt',
            'units_qty',
            'regression_variable',
            'attributed_sales_amt',
            'attributed_units_qty',
            'frequency_of_purchase',
            'online_sales_pct',
            'supermarket_sales_pct',
            'convenience_sales_pct',
            'correlation_id',
            'sum_baseline_amt',
            'sum_of_sales_amt',
            'sum_of_attr_sales_amt',
            'sum_of_incr_amt',
            'channel_name',
            'subchannel_name',
            'load_ts',
            'week_start_dt',
            'item_cd',
            'incrementality_total',
            'incrementality_exposed',
            'attributed_recalibrated_sales_amt',
            'attributed_recalibrated_units_qty',
            'unique_brand_name',
            'baseline',
            'marketing_hierarchy_cd',
            'marketing_type',
            'total_sales_amt',
            'incremental_sales_amt_exposed',
            'incremental_sales_amt_total',
            'incremental_units_qty_total',
            'incremental_units_qty_exposed',
            'nectar_sales_amt',
            'non_nectar_sales_amt'
        ]

        if product_type.lower() == ProductType.OFFER.value.lower():
            required_columns.append('recalibration_factor')
        baseline_attribution_integration_sku_level_final = (
            baseline_attribution_integration_sku_level.select(*required_columns)
        ).distinct()

        if baseline_attribution_integration_sku_level_final.isEmpty():
            message = f"no record processed for baseline attribution integration sku level for {product_type} "
        else:
            message = f"{baseline_attribution_integration_sku_level_final.count()} record processed for baseline attribution integration sku level for {product_type} journey"

        slack_messenger.send_message(
            event_type=EventType.baseline_attribution_integration_sku_level,
            text="Baseline Attribution Integration SKU Level",
            data={"Status Update": message}
        )

        return baseline_attribution_integration_sku_level_final.distinct(), missing_data_df, log_negative_or_zero_incrementality_df
    except Exception as e:
        error_msg = f"Exception occurred: {type(e).__name__}: {str(e)}"
        traceback_msg = traceback.format_exc()
        raise ValueError(f"{error_msg}\n\nFull traceback:\n{traceback_msg}")
