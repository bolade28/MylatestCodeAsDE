from datetime import datetime
from typing import List, Optional

from pyspark.sql import SparkSession, functions as F, types as T

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.schemas.baseline_attribution_integration.unified_baseline_attribution_integration import \
    UnifiedBaselineAttributionIntegration
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def create_empty_baseline_attribution_df(spark: SparkSession) -> SparkSession:
    """Create an empty DataFrame with unified baseline attribution schema."""
    return spark.createDataFrame([], UnifiedBaselineAttributionIntegration.schema)


def prepare_unified_baseline_integration_sku_level(
        spark: SparkSession,
        baseline_attribution_integration_sku_level_offer_path: str,
        baseline_attribution_integration_sku_level_brand_path: str,
        baseline_attribution_integration_sku_level_aisle_path: str,
        output_path: str,
        run_date: str,
        run_type: str,
        correlation_id: str,
        slack_topic_arn: str,
) -> None:
    """Prepare unified baseline attribution integration at SKU level by combining offer, brand, and aisle data.
    Args:
        spark: Spark session object.
        baseline_attribution_integration_sku_level_offer_path: S3 path for baseline attribution integration SKU level offer data.
        baseline_attribution_integration_sku_level_brand_path: S3 path for baseline attribution integration SKU level brand data.
        baseline_attribution_integration_sku_level_aisle_path: S3 path for baseline attribution integration SKU level aisle data.
        output_path: S3 path for unified baseline attribution integration output.
        run_date: Pipeline run date in YYYY-MM-DD format.
        run_type: either "Pollen" or "DTP".
        correlation_id: Correlation ID for traceability.
        slack_topic_arn: The ARN of the Slack topic for notifications.
    """

    # TODO: consider timezones also - should probably pass ZoneInfo("Europe/London") to this as well?
    current_ts = datetime.now()

    try:
        baseline_attribution_offer_df = (
            spark
            .read
            .parquet(baseline_attribution_integration_sku_level_offer_path)
            .withColumn("isconversion", F.col("isconversion").cast(T.IntegerType()))  # fixing data type for isconversion
            .withColumn("product_type", F.lit('Offer'))  # Adding product_type column with constant value 'Offer'
            .withColumn("run_type", F.lit(run_type))
            .withColumn("dag_run_ts", F.lit(current_ts))
            .select(
                'correlation_id',
                'product_type',
                'campaign_id',
                'userjourney_id',
                'loyalty_id',
                'booking_id',
                'customer_journey_type',
                'journey_type',
                'isconversion',
                'normalized_weights',
                'campaign_duration',
                'event_dt',
                'net_sales_amt',
                'units_qty',
                'regression_variable',
                'attributed_sales_amt',
                'attributed_units_qty',
                'frequency_of_purchase',
                'online_sales_pct',
                'supermarket_sales_pct',
                'convenience_sales_pct',
                'sum_baseline_amt',
                'sum_of_sales_amt',
                'sum_of_attr_sales_amt',
                'sum_of_incr_amt',
                'channel_name',
                'subchannel_name',
                'load_ts',
                'week_start_dt',
                'item_cd',
                'incrementality_total',
                'incrementality_exposed',
                'attributed_recalibrated_sales_amt',
                'attributed_recalibrated_units_qty',
                'unique_brand_name',
                'baseline',
                'marketing_type',
                'total_sales_amt',
                'incremental_sales_amt_exposed',
                'incremental_sales_amt_total',
                'incremental_units_qty_total',
                'incremental_units_qty_exposed',
                'nectar_sales_amt',
                'non_nectar_sales_amt',
                'recalibration_factor',
                'run_type',
                'dag_run_ts',
                'marketing_hierarchy_cd'
            )
        )

    except Exception as e:
        print(f"no baseline attribution offer data to load: {e}")
        baseline_attribution_offer_df = create_empty_baseline_attribution_df(spark=spark)

    baseline_attribution_offer_df.show(truncate=False)
    print(baseline_attribution_offer_df.count())

    try:
        baseline_attribution_brand_df = (
            spark
            .read
            .parquet(baseline_attribution_integration_sku_level_brand_path)
            .withColumn("recalibration_factor", F.lit(None))  # Adding missing column with null values
            .withColumn("isconversion", F.col("isconversion").cast(T.IntegerType()))  # Adding missing column with null values
            .withColumn("product_type", F.lit('Brand'))  # Adding product_type column with constant value 'Brand'
            .withColumn("run_type", F.lit(run_type))
            .withColumn("dag_run_ts", F.lit(current_ts))
            .select(
                'correlation_id',
                'product_type',
                'campaign_id',
                'userjourney_id',
                'loyalty_id',
                'booking_id',
                'customer_journey_type',
                'journey_type',
                'isconversion',
                'normalized_weights',
                'campaign_duration',
                'event_dt',
                'net_sales_amt',
                'units_qty',
                'regression_variable',
                'attributed_sales_amt',
                'attributed_units_qty',
                'frequency_of_purchase',
                'online_sales_pct',
                'supermarket_sales_pct',
                'convenience_sales_pct',
                'sum_baseline_amt',
                'sum_of_sales_amt',
                'sum_of_attr_sales_amt',
                'sum_of_incr_amt',
                'channel_name',
                'subchannel_name',
                'load_ts',
                'week_start_dt',
                'item_cd',
                'incrementality_total',
                'incrementality_exposed',
                'attributed_recalibrated_sales_amt',
                'attributed_recalibrated_units_qty',
                'unique_brand_name',
                'baseline',
                'marketing_type',
                'total_sales_amt',
                'incremental_sales_amt_exposed',
                'incremental_sales_amt_total',
                'incremental_units_qty_total',
                'incremental_units_qty_exposed',
                'nectar_sales_amt',
                'non_nectar_sales_amt',
                'recalibration_factor',
                'run_type',
                'dag_run_ts',
                'marketing_hierarchy_cd'
            )
        )

    except Exception as e:
        print(f"no baseline attribution offer data to load: {e}")
        baseline_attribution_brand_df = create_empty_baseline_attribution_df(spark=spark)

    baseline_attribution_brand_df.show(truncate=False)
    print(baseline_attribution_brand_df.count())

    try:
        baseline_attribution_aisle_df = (
            spark
            .read
            .parquet(baseline_attribution_integration_sku_level_aisle_path)
            .withColumn("recalibration_factor", F.lit(None))  # Adding missing column with null values
            .withColumn("isconversion", F.col("isconversion").cast(T.IntegerType()))  # Adding missing column with null values
            .withColumn("product_type", F.lit('Aisle'))  # Adding product_type column with constant value 'Aisle'
            .withColumn("run_type", F.lit(run_type))
            .withColumn("dag_run_ts", F.lit(current_ts))
            .select(
                'correlation_id',
                'product_type',
                'campaign_id',
                'userjourney_id',
                'loyalty_id',
                'booking_id',
                'customer_journey_type',
                'journey_type',
                'isconversion',
                'normalized_weights',
                'campaign_duration',
                'event_dt',
                'net_sales_amt',
                'units_qty',
                'regression_variable',
                'attributed_sales_amt',
                'attributed_units_qty',
                'frequency_of_purchase',
                'online_sales_pct',
                'supermarket_sales_pct',
                'convenience_sales_pct',
                'sum_baseline_amt',
                'sum_of_sales_amt',
                'sum_of_attr_sales_amt',
                'sum_of_incr_amt',
                'channel_name',
                'subchannel_name',
                'load_ts',
                'week_start_dt',
                'item_cd',
                'incrementality_total',
                'incrementality_exposed',
                'attributed_recalibrated_sales_amt',
                'attributed_recalibrated_units_qty',
                'unique_brand_name',
                'baseline',
                'marketing_type',
                'total_sales_amt',
                'incremental_sales_amt_exposed',
                'incremental_sales_amt_total',
                'incremental_units_qty_total',
                'incremental_units_qty_exposed',
                'nectar_sales_amt',
                'non_nectar_sales_amt',
                'recalibration_factor',
                'run_type',
                'dag_run_ts',
                'marketing_hierarchy_cd'
            )
        )

    except Exception as e:
        print(f"no baseline attribution aisle data to load: {e}")
        baseline_attribution_aisle_df = create_empty_baseline_attribution_df(spark=spark)

    baseline_attribution_aisle_df.show(truncate=False)
    print(baseline_attribution_aisle_df.count())

    unified_baseline_attribution_integration_sku_level_df = (
        baseline_attribution_offer_df
        .unionByName(baseline_attribution_brand_df)
        .unionByName(baseline_attribution_aisle_df)
        .withColumn("run_date", F.lit(run_date))
        .withColumn("load_ts", F.lit(current_ts))
    )
    print("Showing some rows of final df btw:")
    unified_baseline_attribution_integration_sku_level_df.show(truncate=False)

    spark_s3_overwrite(output_path, unified_baseline_attribution_integration_sku_level_df)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare united baseline attribution integration sku level.")

    parser.add_argument(
        "--baseline-attribution-integration-sku-level-offer-path",
        type=str,
        required=True,
        help="S3 path for baseline attribution integration SKU level offer data."
    )
    parser.add_argument(
        "--baseline-attribution-integration-sku-level-brand-path",
        type=str,
        required=True,
        help="S3 path for baseline attribution integration SKU level brand data."
    )
    parser.add_argument(
        "--baseline-attribution-integration-sku-level-aisle-path",
        type=str,
        required=True,
        help="S3 path for baseline attribution integration SKU level aisle data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for unified baseline attribution integration output."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--run-type",
        type=str,
        required=True,
        help="Run type for this run, either 'Pollen' or DTP'"
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for traceability."
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN of the Slack topic for notifications."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_unified_baseline_integration_sku_level(
        spark=spark,
        baseline_attribution_integration_sku_level_offer_path=known_args.baseline_attribution_integration_sku_level_offer_path,
        baseline_attribution_integration_sku_level_brand_path=known_args.baseline_attribution_integration_sku_level_brand_path,
        baseline_attribution_integration_sku_level_aisle_path=known_args.baseline_attribution_integration_sku_level_aisle_path,
        output_path=known_args.output_path,
        run_date=known_args.run_date,
        run_type=known_args.run_type,
        correlation_id=known_args.correlation_id,
        slack_topic_arn=known_args.slack_topic_arn
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName(__file__).getOrCreate())
