from pyspark.sql import types as T
from pyspark.sql import functions as F, DataFrame
from spark_pipeline.attribution_model_results.slack_notifications import AttributionSlackNotifier
from spark_pipeline.common.variables import EventName
from pyspark.sql.window import Window


def preprocess_all_campaigns(
    attribution_pre_requisite_df: DataFrame,
) -> DataFrame:
    """
    Adds a transaction_date column to every touchpoint in a journey.

    The date is taken from the Transaction (conversion) touchpoint and copied across
    all other touchpoints in the same journey, so every row knows when the
    conversion happened — needed for joining decay rates later.
    """
    win = Window.partitionBy("booking_id", "userjourney_id").rowsBetween(
        Window.unboundedPreceding, Window.unboundedFollowing
    )
    attribution_pre_requisite_df = (
        attribution_pre_requisite_df
        .withColumn(
            "transaction_date",
            F.when(F.col("event_name") == EventName.TRANSACTION.value, F.split(F.col("event_ts"), " ")[0])
            .otherwise(F.lit(None))
        )
        .withColumn("transaction_date", F.col("transaction_date").cast("date"))
        .withColumn(
            "transaction_date",
            F.coalesce(F.col("transaction_date"), F.last("transaction_date", ignorenulls=True).over(win))
        )
    )

    return attribution_pre_requisite_df


def get_all_campaigns_stats(
    preprocessed_df: DataFrame,
    min_conversion_lower_limit: int,
    slack_notifier: "AttributionSlackNotifier",
) -> DataFrame:
    """
    Computes journey stats for ALL campaigns at once.
    Validates minimum conversions per booking_id + campaign_duration.
    Sends alert for campaigns with insufficient conversions but does not raise,
    allowing the per-campaign loop to decide whether to skip or proceed.

    Args:
        preprocessed_df: Preprocessed DataFrame with all campaigns
        min_conversion_lower_limit: Minimum number of conversions required per campaign
        slack_notifier: Slack notifier instance for alerts

    Returns:
        DataFrame with stats per booking_id + campaign_duration
    """
    stats_df = (
        preprocessed_df
        .groupBy("booking_id", "campaign_duration")
        .agg(
            F.countDistinct(F.when(F.col("isconversion") == 1, F.col("userjourney_id"))).alias("total_conversions"),
            F.countDistinct(F.when(F.col("isconversion") == 0, F.col("userjourney_id"))).alias("total_nonconversions"),
            F.countDistinct("userjourney_id").alias("total_journeys"),
        )
        .withColumn(
            "conversion_rate",
            F.when(F.col("total_journeys") > 0, F.col("total_conversions") / F.col("total_journeys") * 100)
            .otherwise(F.lit(0.0))
        )
        .cache()
    )

    # Filter failed campaigns in Spark — only collect failed rows
    failed_campaigns = (
        stats_df
        .filter(F.col("total_conversions") < min_conversion_lower_limit)
        .select("booking_id", "total_conversions")
        .collect()
    )

    if failed_campaigns:
        for row in failed_campaigns:
            slack_notifier.send_campaign_no_data_error(
                row["booking_id"],
                f"Insufficient conversions ({row['total_conversions']}) for campaign {row['booking_id']}, "
                f"minimum required: {min_conversion_lower_limit}. Proceeding with lift model."
            )

    return stats_df


def pivot_regression_variables_all_campaigns(
    preprocessed_df: DataFrame,
    slack_notifier: "AttributionSlackNotifier",
    is_dtp: bool = False,
) -> DataFrame:
    """
    Args:
        preprocessed_df: Preprocessed DataFrame with all campaigns
        slack_notifier: Slack notifier instance for alerts
        is_dtp: True for DTP pipeline, False for Pollen

    Returns:
        Pivoted DataFrame with one binary column per regression variable per campaign.
    Raises:
        ValueError: If any campaign has no valid regression variables.
    """

    # DTP excludes subchannel_name; Pollen includes it
    select_cols = [
        "userjourney_id",
        "campaign_id",
        "channel_name",
        "loyalty_id",
        "transaction_key",
        "booking_id",
        "customer_journey_type",
        "journey_type",
        "regression_variable",
        "isconversion",
        "campaign_duration",
        "transaction_date",
    ]
    if not is_dtp:
        select_cols.insert(3, "subchannel_name")

    df_filtered = (
        preprocessed_df
        .select(*select_cols)
        .withColumn("regression_variable", F.lower(F.col("regression_variable")))
        .withColumn("isconversion", F.col("isconversion").cast("integer"))
        .cache()
    )

    # Get distinct regression variables across ALL campaigns — one Spark action
    distinct_variables = (
        df_filtered
        .filter(~F.lower(F.col("regression_variable")).contains("transaction"))
        .agg(F.collect_set("regression_variable").alias("vars"))
        .first()["vars"]
    )

    # Validate in Spark — find campaigns with no valid regression variables
    failed_campaigns = (
        df_filtered
        .groupBy("booking_id")
        .agg(
            F.countDistinct(
                F.when(~F.lower(F.col("regression_variable")).contains("transaction"), F.col("regression_variable"))
            ).alias("valid_var_count")
        )
        .filter(F.col("valid_var_count") == 0)
        .select("booking_id")
        .collect()
    )

    if failed_campaigns:
        for row in failed_campaigns:
            slack_notifier.send_campaign_no_data_error(
                row["booking_id"],
                f"No valid regression variables found for campaign {row['booking_id']}"
            )
        raise ValueError(
            f"Campaigns with no valid regression variables: {[row['booking_id'] for row in failed_campaigns]}"
        )

    # Build pivot expressions for ALL variables across ALL campaigns — Python list comprehension not a Spark loop
    pivot_exprs = [
        F.max(
            F.when(F.col("regression_variable") == F.lit(var), 1).otherwise(0)
        ).alias(var)
        for var in distinct_variables
    ]

    groupby_cols = [
        "userjourney_id",
        "campaign_id",
        "channel_name",
        "loyalty_id",
        "transaction_key",
        "booking_id",
        "customer_journey_type",
        "journey_type",
        "isconversion",
        "regression_variable",
        "campaign_duration",
        "transaction_date",
    ]
    if not is_dtp:
        groupby_cols.insert(3, "subchannel_name")

    pivot_df = (
        df_filtered
        .groupBy(*groupby_cols)
        .agg(*pivot_exprs)
    )

    # Fix pivot values — single select instead of N withColumn calls
    non_var_cols = [F.col(c) for c in pivot_df.columns if c not in distinct_variables]
    fix_exprs = [
        F.when((F.col("regression_variable") == F.lit(var)) & (F.col(var) == 0), 1)
        .otherwise(F.col(var))
        .alias(var)
        for var in distinct_variables
    ]

    df_filtered.unpersist()
    return pivot_df.select(*non_var_cols, *fix_exprs)


def apply_decay_rates_for_offsite_campaigns(
    pivot_df: DataFrame,
    campaign_decay_df: DataFrame,
    df_booking_id: DataFrame,
    is_dtp: bool = False,
) -> DataFrame:
    """
    Applies offsite decay rates to pivot DataFrame for ALL campaigns at once.
    Returns pivot DataFrame with decay applied and temporary columns dropped.

    DTP:    offsite detected via channel_name, decay joined on job_bag_number.
    Pollen: offsite detected via marketing_type, decay joined on campaign_id + subchannel.
    """
    if is_dtp:
        offsite_campaign_ids_df = (
            df_booking_id
            .filter(F.col("channel_name").isin(["Meta", "DV360", "YouTube"]))
            .select("campaign_id")
            .distinct()
        )
    else:
        offsite_campaign_ids_df = (
            df_booking_id
            .filter(F.col("marketing_type") == "OFFSITE")
            .select("campaign_id")
            .distinct()
        )

    no_offsite_drop_cols = ["regression_variable", "transaction_date", "channel_name", "campaign_id"]
    if not is_dtp:
        no_offsite_drop_cols.append("subchannel_name")

    if offsite_campaign_ids_df.isEmpty():
        return pivot_df.drop(*no_offsite_drop_cols)

    if is_dtp:
        # DTP decay schema uses job_bag_number (not campaign_id) as the campaign key
        decay_df = (
            campaign_decay_df
            .join(
                F.broadcast(offsite_campaign_ids_df.select(F.col("campaign_id").alias("_offsite_id"))),
                on=campaign_decay_df["job_bag_number"] == F.col("_offsite_id"),
                how="inner",
            )
            .drop("_offsite_id")
            .select(
                F.col("job_bag_number").alias("bag"),
                F.col("channel_name").alias("channel"),
                F.col("reporting_dt"),
                F.col("offsite_impressions_pct"),
            )
        )
        joined_data = (
            pivot_df
            .join(
                F.broadcast(decay_df),
                (pivot_df["transaction_date"] == F.col("reporting_dt")) &
                (pivot_df["campaign_id"] == F.col("bag")) &
                (pivot_df["channel_name"] == F.col("channel")),
                how="left",
            )
            .filter(~F.lower(F.col("regression_variable")).like("%transaction%"))
        )
        drop_cols = [
            "regression_variable", "transaction_date", "bag", "channel",
            "reporting_dt", "offsite_impressions_pct", "channel_name", "campaign_id",
        ]
    else:
        # Pollen: latest load_ts per campaign_id + channel + subchannel + reporting_dt
        window = Window.partitionBy("campaign_id", "channel_name", "subchannel_name", "reporting_dt")
        decay_df = (
            campaign_decay_df
            .join(F.broadcast(offsite_campaign_ids_df), on="campaign_id", how="inner")
            .withColumn("max_load_ts", F.max("load_ts").over(window))
            .filter(F.col("load_ts") == F.col("max_load_ts"))
            .drop("max_load_ts")
            .select(
                F.col("campaign_id").alias("cid"),
                F.col("channel_name").alias("channel"),
                F.col("subchannel_name").alias("subchannel"),
                F.col("reporting_dt"),
                F.col("offsite_impressions_pct"),
            )
        )
        joined_data = (
            pivot_df
            .join(
                F.broadcast(decay_df),
                (pivot_df["transaction_date"] == F.col("reporting_dt")) &
                (pivot_df["campaign_id"] == F.col("cid")) &
                (pivot_df["channel_name"] == F.col("channel")) &
                (pivot_df["subchannel_name"] == F.col("subchannel")),
                how="left",
            )
        )
        drop_cols = [
            "regression_variable", "transaction_date", "cid", "channel", "subchannel",
            "reporting_dt", "offsite_impressions_pct", "channel_name", "subchannel_name", "campaign_id",
        ]

    # Apply decay to meta/dv360/youtube columns
    meta_columns = [
        col for col in pivot_df.columns
        if any(keyword in col.lower() for keyword in ("meta", "dv360", "youtube"))
    ]

    non_meta_cols = [F.col(c) for c in joined_data.columns if c not in meta_columns]
    decay_exprs = [
        F.when(
            (F.col(col_name) > 0) &
            (F.col("isconversion") == 1) &
            (F.col("offsite_impressions_pct").isNotNull()),
            F.col("offsite_impressions_pct")
        ).otherwise(F.col(col_name))
        .cast("double")
        .alias(col_name)
        for col_name in meta_columns
    ]

    return (
        joined_data
        .select(*non_meta_cols, *decay_exprs)
        .fillna({col_name: 0 for col_name in meta_columns})
        .drop(*drop_cols)
    )


def flatten_journey_paths_all_campaigns(
    pivot_df: DataFrame,
    slack_notifier: "AttributionSlackNotifier",
    is_dtp: bool = False,
) -> DataFrame:
    """
    Aggregates touchpoint-level pivot DataFrame into one row per user journey
    for ALL campaigns at once.
    Sums independent variables and takes max isconversion per journey.
    Sends alert and raises ValueError if no independent variables found.

    Args:
        pivot_df: Pivoted DataFrame with all campaigns
        slack_notifier: Slack notifier instance for alerts

    Returns:
        Flattened DataFrame with one row per user journey per campaign.
    Raises:
        ValueError: If no independent variables found.
    """
    columns_to_exclude = [
        "userjourney_id", "loyalty_id", "transaction_key", "booking_id",
        "customer_journey_type", "journey_type", "isconversion", "campaign_duration",
    ]

    indep_vars = [col for col in pivot_df.columns if col not in columns_to_exclude]

    if not indep_vars:
        slack_notifier.send_no_data_error()
        raise ValueError("No independent variables found across all campaigns")

    # Handle NULL isconversion in Spark — no collect needed
    pivot_df = pivot_df.withColumn(
        "isconversion",
        F.coalesce(F.col("isconversion"), F.lit(0))
    )

    # Resolve "NA" -> null once; both aggregations then handle nulls naturally
    clean_tk = F.when(F.col("transaction_key") != "NA", F.col("transaction_key"))

    if is_dtp:
        # DTP: one purchase per userjourney_id — prefer a real UUID over 'NA' rows
        transaction_key_agg = [F.coalesce(F.first(clean_tk, ignorenulls=True), F.lit("NA")).alias("transaction_key")]
    else:
        # Pollen: one journey spans all purchases — collect all real UUIDs for later explode
        transaction_key_agg = [F.collect_set(clean_tk).alias("transaction_keys")]

    aggregations = (
        [F.sum(F.col(var)).cast("double").alias(var) for var in indep_vars]
        + [F.max(F.col("isconversion")).cast("integer").alias("isconversion")]
        + transaction_key_agg
    )

    flattened_df = (
        pivot_df
        .groupBy(
            "userjourney_id", "loyalty_id", "booking_id",
            "customer_journey_type", "journey_type", "campaign_duration",
        )
        .agg(*aggregations)
    )

    if not is_dtp:
        # Explode one row per transaction_key; non-converted journeys get 'NA'
        flattened_df = (
            flattened_df
            .withColumn(
                "transaction_keys",
                F.when(F.size(F.col("transaction_keys")) == 0, F.array(F.lit("NA")))
                .otherwise(F.col("transaction_keys"))
            )
            .withColumn("transaction_key", F.explode(F.col("transaction_keys")))
            .drop("transaction_keys")
        )

    flattened_df = flattened_df.cache()

    # Validate per campaign — one Spark action for ALL campaigns
    failed_campaigns = (
        flattened_df
        .groupBy("booking_id")
        .agg(F.count("*").alias("row_count"))
        .filter(F.col("row_count") == 0)
        .select("booking_id")
        .collect()
    )

    if failed_campaigns:
        for row in failed_campaigns:
            slack_notifier.send_campaign_no_data_error(
                row["booking_id"],
                f"No journey data found after flattening for campaign {row['booking_id']}"
            )
        raise ValueError(
            f"Campaigns with no journey data after flattening: {[row['booking_id'] for row in failed_campaigns]}"
        )
    return flattened_df


def nest_journeys_by_loyalty_id(
    wide_flat_df: DataFrame,
    journey_schema: T.StructType,
    static_journey_cols: list[str],
) -> DataFrame:
    TOP_LEVEL_COLS = [
        "loyalty_id", "isconversion", "booking_id",
        "customer_journey_type", "campaign_duration", "journey_type",
    ]
    excluded = set(static_journey_cols) | set(TOP_LEVEL_COLS)
    dynamic_columns = [c for c in wide_flat_df.columns if c not in excluded]

    regression_vars_expr = F.array(*[
        F.struct(
            F.lit(col_name).alias("name"),
            F.col(col_name).cast(T.DoubleType()).alias("value"),
        )
        for col_name in dynamic_columns
    ])

    # journey struct only has fields in journey_schema — no top-level fields
    journey_struct = F.struct(
        *[
            F.col(f.name).cast(f.dataType).alias(f.name)
            for f in journey_schema.fields
            if f.name != "regression_variables"
        ],
        regression_vars_expr.alias("regression_variables"),
    )

    nested_df = (
        wide_flat_df
        .select(*TOP_LEVEL_COLS, journey_struct.alias("journey"))
        .groupBy(*TOP_LEVEL_COLS)
        .agg(F.collect_list("journey").alias("user_journeys"))
    )

    return nested_df
