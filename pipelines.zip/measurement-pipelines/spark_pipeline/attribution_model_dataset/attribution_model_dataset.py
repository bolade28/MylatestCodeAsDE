from pyspark.sql import SparkSession, functions as F
from typing import List, Optional
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import ProductType
from spark_pipeline.attribution_model_results.slack_notifications import AttributionSlackNotifier
from spark_pipeline.attribution_model_dataset.dataset_helper import (
    preprocess_all_campaigns,
    pivot_regression_variables_all_campaigns,
    apply_decay_rates_for_offsite_campaigns,
    flatten_journey_paths_all_campaigns, nest_journeys_by_loyalty_id,
)
from spark_pipeline.schemas.attribution_model_dataset import AttributionModelDatasetSchema
from spark_pipeline.schemas.campaign_decay_rate import CampaignDecayType
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset, is_dtp_run
from spark_pipeline.utils.stdout_logger import StdOutLogger
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite

logger = StdOutLogger()


def process_attribution_model_dataset(
        spark: SparkSession,
        measurement_campaign_path: str,
        attribution_prerequisite_path: str,
        campaign_decay_path: str,
        journey_channel_metadata_path: str,
        attribution_model_dataset_flattened_path: str,
        job_run_id: str,
        slack_topic_arn: str,
        journey_type: str,
        pipeline_run_type: str,
) -> None:
    """
    Args:
        spark: SparkSession instance.
        measurement_campaign_path: S3 path for measurement campaign data.
        attribution_prerequisite_path: S3 path for attribution prerequisite data.
        campaign_decay_path: S3 path for campaign decay rates data.
        journey_channel_metadata_path: S3 path to write the journey channel metadata mapping.
        attribution_model_dataset_flattened_path: S3 path to write the flattened journey-level dataset.
        job_run_id: Unique job run identifier.
        slack_topic_arn: ARN for Slack notifications.
        journey_type: Journey type (offer, brand, aisle).
        pipeline_run_type: Run type, either pollen or dtp.

    Returns:
        None. Results are written directly to S3.

    Raises:
        ValueError: If pipeline_run_type is not a recognised value.
        RuntimeError: If no campaign data is found in the measurement campaign dataset.
    """

    is_dtp = is_dtp_run(pipeline_run_type)

    campaign_errors: dict = {}
    slack_notifier = AttributionSlackNotifier(slack_topic_arn, job_run_id, journey_type)

    try:
        # ---------- Load input datasets from S3 bucket ----------
        MEASUREMENT_CAMPAIGN_COLS: list[str] = AttributionModelDatasetSchema.columns(
            AttributionModelDatasetSchema.measurement_campaign_execution_schema
        )
        ATTRIBUTION_PREREQUISITE_COLS: list[str] = AttributionModelDatasetSchema.columns(
            AttributionModelDatasetSchema.attribution_prerequisite_schema
        )
        # TODO:: why the decay schema differs and can we standardize?
        CAMPAIGN_DECAY_COLS: list[str] = AttributionModelDatasetSchema.columns(
            CampaignDecayType.campaign_decay_rate_dtp_schema if is_dtp else CampaignDecayType.campaign_decay_rate_pollen_schema
        )

        measurement_campaign_df = load_parquet_dataset(
            spark, measurement_campaign_path, "campaign_execution", slack_notifier,
            columns=MEASUREMENT_CAMPAIGN_COLS,
        )
        attribution_pre_requisite_df = load_parquet_dataset(
            spark, attribution_prerequisite_path, "attribution_data", slack_notifier,
            columns=ATTRIBUTION_PREREQUISITE_COLS,
        )
        campaign_decay_df = load_parquet_dataset(
            spark, campaign_decay_path, "decay_data", slack_notifier,
            columns=CAMPAIGN_DECAY_COLS,
            fallback_schema=CampaignDecayType.campaign_decay_rate_dtp_schema if is_dtp else CampaignDecayType.campaign_decay_rate_pollen_schema,
        )

        campaign_combinations = (
            measurement_campaign_df
            .select("booking_id", "campaign_duration")
            .distinct()
        )

        if campaign_combinations.isEmpty():
            slack_notifier.send_no_data_error()
            raise RuntimeError("No data found to execute the ETL!")

        df_booking_id_joined = attribution_pre_requisite_df.join(
            F.broadcast(campaign_combinations), ["booking_id", "campaign_duration"], "inner"
        ).cache()
        if df_booking_id_joined.isEmpty():
            slack_notifier.send_no_data_error()
            raise RuntimeError("No attribution prerequisite data found for the discovered campaigns!")
        df_booking_id = df_booking_id_joined

        journey_channel_metadata_df = (
            df_booking_id
            .select(
                "userjourney_id",
                "regression_variable",
                "booking_id",
                "campaign_duration",
                "channel_name",
                "subchannel_name",
                "marketing_type",
                "campaign_id",
            )
            .distinct()
        )

        spark_s3_overwrite(journey_channel_metadata_path, journey_channel_metadata_df)

        logger.info(f"Journey channel metadata written to {journey_channel_metadata_path}")

        df_booking_id = preprocess_all_campaigns(df_booking_id)

        pivot_df = pivot_regression_variables_all_campaigns(df_booking_id, slack_notifier, is_dtp)

        pivot_df = apply_decay_rates_for_offsite_campaigns(
            pivot_df, campaign_decay_df, df_booking_id, is_dtp
        )
        df_booking_id_joined.unpersist()

        flattened_df = flatten_journey_paths_all_campaigns(pivot_df, slack_notifier, is_dtp)

        static_journey_cols = [
            "userjourney_id",
            "loyalty_id",
            "transaction_key",
            "booking_id",
            "customer_journey_type",
            "journey_type",
            "campaign_duration",
            "isconversion",
        ]

        # convert this to nested schem
        nested_df = nest_journeys_by_loyalty_id(flattened_df, AttributionModelDatasetSchema.journey_schema, static_journey_cols)

        spark_s3_overwrite(attribution_model_dataset_flattened_path, nested_df)
        nested_df.unpersist()
        logger.info(f"Flattened journey dataset written to {attribution_model_dataset_flattened_path}")

    except Exception as e:
        error_msg = f"Attribution model dataset ETL failed: {str(e)}"
        logger.error(error_msg)
        slack_notifier.send_general_failure_notification(error_msg, campaign_errors)
        raise


def entrypoint(
        spark: SparkSession,
        command_line_args: Optional[List[str]] = None,
) -> None:
    """Entry point for the Attribution Model Dataset ETL pipeline."""
    parser = ThrowingArgumentParser(
        description="Attribution Model Dataset ETL: loads, preprocesses and writes flattened journey data."
    )
    parser.add_argument(
        "--measurement-campaign-path",
        type=str,
        required=True,
        help="S3 path for measurement campaign data.",
    )
    parser.add_argument(
        "--attribution-prerequisite-path",
        type=str,
        required=True,
        help="S3 path for attribution prerequisite data.",
    )
    parser.add_argument(
        "--campaign-decay-path",
        type=str,
        required=True,
        help="S3 path for campaign decay rates data.",
    )
    parser.add_argument(
        "--journey-channel-metadata-path",
        type=str, required=True,
        help="S3 path to write the journey channel metadata mapping for the modelling step.",
    )
    parser.add_argument(
        "--attribution-model-dataset-flattened-path", type=str, required=True,
        help="S3 path to write the flattened journey-level dataset.",
    )
    parser.add_argument(
        "--journey-type", type=str, required=True, choices=[e.value.lower() for e in ProductType],
        help="Journey type for campaign processing.",
    )
    parser.add_argument(
        "--job-run-id", type=str, required=True,
        help="Unique job run identifier.",
    )
    parser.add_argument(
        "--slack-topic-arn", type=str, required=True,
        help="ARN of the Slack topic for notifications.",
    )
    parser.add_argument(
        "--pipeline-run-type", type=str, required=True,
        help="Pipeline run type (pollen or dtp).",
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    process_attribution_model_dataset(
        spark=spark,
        measurement_campaign_path=known_args.measurement_campaign_path,
        attribution_prerequisite_path=known_args.attribution_prerequisite_path,
        campaign_decay_path=known_args.campaign_decay_path,
        journey_channel_metadata_path=known_args.journey_channel_metadata_path,
        attribution_model_dataset_flattened_path=known_args.attribution_model_dataset_flattened_path,
        job_run_id=known_args.job_run_id,
        slack_topic_arn=known_args.slack_topic_arn,
        journey_type=known_args.journey_type,
        pipeline_run_type=known_args.pipeline_run_type,
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder.appName("AttributionModelDataset").getOrCreate()
    )
