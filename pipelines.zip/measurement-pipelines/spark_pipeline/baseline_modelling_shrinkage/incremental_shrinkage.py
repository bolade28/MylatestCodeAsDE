from typing import List, Optional, Tuple, Dict, Any

from pyspark.sql import SparkSession, functions as F, DataFrame
from spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage_helper import (
    outlier_filter,
    normalise_marketing_type,
    attach_product_hierarchy,
    aggregate_campaigns_to_brand_grain,
    get_incrementality,
    get_aggregate_prior,
    calibrate,
    get_bypass_incrementality,
    check_bypass_channels,
    check_full_bypass,
    generate_bypass_outputs,
    generate_bypass_metadata,
    build_incremental_shrinkage_output_df,
    build_incremental_shrinkage_audit_df,
    add_unscaled_incrementality,
)

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import BaselineModellingShrinkageConfig, CampaignDurations
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite
from spark_pipeline.utils.stdout_logger import get_stdout_logger


logger = get_stdout_logger()


def prepare_incremental_shrinkage(
    spark: SparkSession,
    baseline_output_path: str,
    avg_weekly_spend_data_path: str,
    measurement_legacy_campaign_performance: str,
    campaign_selection_path: str,
    output_path: str,
    output_path_audit: str,
    campaign_duration: str,
    run_date: str,
    correlation_id: str,
    brand_data_path: str,
    previous_measurement_campaign_reporting: Optional[str] = None,
    ucm_base_data: Optional[str] = None,
) -> None:
    """
    Integrates baseline and MTA outputs for comparison analysis.

    This function:
    1. Reads all input data sources
    2. Performs necessary transformations
    3. Writes the distribution output using safe S3 overwrite

    Args:
        spark: The SparkSession object.
        baseline_output_path: S3 path for baseline for incremental sales (DMO).
        avg_weekly_spend_data_path: S3 path for average weekly spend data.
        measurement_legacy_campaign_performance: S3 path for measurement legacy campaign performance data.
        campaign_selection_path: This contains campaign metadata such as sub_category name and media_spend metrics which are required for shrinkage calculation.
        brand_data_path: S3 path for brand data used to enrich the new item-level input sources.
        campaign_duration: The duration of the campaign for shrinkage calculation, e.g. 'During' or 'Post'.
        output_path: S3 path where the integrated shrinkage output will be saved.
        output_path_audit: S3 path where the audit output will be saved.
        run_date: The pipeline execution date in YYYY-MM-DD format.
        correlation_id: Unique identifier for the pipeline run.

    Returns:
        None
    """
    config = BaselineModellingShrinkageConfig()

    is_post_run = campaign_duration == CampaignDurations.CAMPAIGN_DURATION_POST
    is_during_run = campaign_duration == CampaignDurations.CAMPAIGN_DURATION_DURING

    # For post-period run, read in from previous measurement campaign reporting for the same campaign period to get the legacy incrementality for calibration.
    if is_post_run and previous_measurement_campaign_reporting:
        previous_reporting_df = (
            spark
            .read
            .parquet(previous_measurement_campaign_reporting)
        )
        previous_reporting_df = add_unscaled_incrementality(previous_reporting_df)

        # Get the calibrated incrementality for the during run which we will add onto the final result after calibrating the post-run
        during_incrementality = previous_reporting_df.agg(
            F.sum("unscaled_incrementality").alias("previous_incrementality")
        ).first()["previous_incrementality"]
        logger.info(f"[{correlation_id}] Previous measurement campaign reporting incrementality: {during_incrementality}")
    else:
        during_incrementality = 0

    # Get incrementality across campaign period
    baseline_modelling_output = (
        spark
        .read
        .parquet(baseline_output_path)
        .filter(F.col("best_iteration") == 'Y')  # We only care about the best iteration
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "metric_name",
            "metric_value",
        )
    )

    avg_weekly_spend_data_source = (
        spark
        .read
        .parquet(avg_weekly_spend_data_path)
        .select(
            "item_cd",
            "week",
            "year",
            "inflation_ratio",
            "avg_weekly_spend",
            "avg_weekly_spend_inf_adj",
        )
    )

    legacy_campaign_data_source = (
        spark
        .read
        .parquet(measurement_legacy_campaign_performance)
        .select(
            "campaign_id",
            "item_cd",
            "campaign_source",
            "period",
            "campaign_start_date",
            "campaign_end_date",
            "test",
            "control",
            "uplift",
            "media_cost",
        )
    )

    # To support a 1 to 1 mapping between old and new brand source, we use the same column names, however this script expects the updated column names to be super_category_name and sub_category_name, so we rename them here.
    # ToDo: make the naming consistent across the pipeline to avoid this renaming step in future.
    brand_data = (
        spark
        .read
        .parquet(brand_data_path)
        .withColumnRenamed("super_cat_name", "super_category_name")
        .withColumnRenamed("sub_cat_name", "sub_category_name")
        .select(
            "item_cd",
            "super_category_name",
            "sub_category_name",
            "unique_brand_name",
        )
        .filter(F.col("unique_brand_name") != '')  # This is needed for the old brand source
        .dropDuplicates()
    )

    legacy_campaign_data_source = aggregate_campaigns_to_brand_grain(
        legacy_campaign_data_source,
        brand_data,
    )
    avg_weekly_spend_data = attach_product_hierarchy(
        avg_weekly_spend_data_source,
        brand_data,
    )

    # Based on the campaign duration variable, we will filter the table on column period. for during, we filter on period set to DURING, for post-period we filter on period set to POST.
    # This ensures we are comparing the incrementality from the UCM to the correct legacy uplift distribution for calibration.

    period_filter = campaign_duration.upper()
    allowed_sources = config.allowed_sources_by_duration.get(campaign_duration)

    legacy_campaign_data = (
        legacy_campaign_data_source
        .filter(F.col("period") == period_filter)
        .withColumn(
            "marketing_type",
            normalise_marketing_type(F.col("campaign_source")),
        )
        .filter(F.col("marketing_type").isin(allowed_sources))
        .withColumn(
            "iroas",
            F.when(
                F.col("media_cost") != 0,
                (F.col("test") - F.col("control")) / F.col("media_cost"),
            ),
        )
        .select(
            "campaign_id",
            "campaign_source",
            "campaign_start_date",
            "campaign_end_date",
            "super_category_name",
            "sub_category_name_list",
            "unique_brand_name_list",
            "test",
            "control",
            "uplift",
            "iroas",
            "media_cost",
            "marketing_type",
            "num_unique_subcats",
            "num_unique_brands",
        )
    )

    # Set dynamic column names based on post campaign variable. If the campaign run is during-campaign, set the start date to min_campaign_start_dt and end date to max_campaign_end_dt as we want to include all data up until the end of the campaign period.
    # If the campaign run is post-campaign, set the start date to max_campaign_end_dt and end date to max_post_campaign_dt as we only want to include data up until the end of the post-campaign period for calibration.
    if is_post_run:
        start_col = F.to_date(F.date_add(F.date_trunc("week", F.col("max_campaign_end_dt")), 7))
        end_col = F.col("max_post_campaign_dt")
    elif is_during_run:
        start_col = F.col("min_campaign_start_dt")
        end_col = F.col("max_campaign_end_dt")
    else:
        raise ValueError(f"Invalid campaign_duration: {campaign_duration}. Expected 'During' or 'Post'.")

    # This contains multiple rows, as total_media_spend is aggregated per campaign source in line with our legacy data
    campaign_facts = (
        spark
        .read
        .parquet(campaign_selection_path)
        .select(
            "unique_brand_name",
            "super_category_name",
            "sub_category_name",
            "min_campaign_start_dt",
            "max_campaign_end_dt",
            "max_post_campaign_dt",
            F.explode(F.map_entries("media_spend_by_source")).alias("campaign_dict")
        )
        .withColumn(
            "marketing_type",
            normalise_marketing_type(F.col("campaign_dict.key"))
        )
        .filter(F.col("marketing_type").isin(allowed_sources))
        .withColumn("channel_spend", F.col("campaign_dict.value"))
        .select(
            "unique_brand_name",
            "super_category_name",
            "sub_category_name",
            start_col.alias('min_campaign_start_dt'),
            end_col.alias('max_campaign_end_dt'),
            "channel_spend",
            "marketing_type",
        )
    )

    # Check whether we have any channels that need to bypass normal calibration
    bypass_channels_flag, bypass_marketing_types = check_bypass_channels(campaign_facts, campaign_duration, config)

    # Update campaign_facts to capture bypassed channels
    campaign_facts = (
        campaign_facts
        .withColumn(
            'bypass_flag',
            F.col('marketing_type').isin(list(bypass_marketing_types.keys()))
        )
    )

    if bypass_channels_flag:
        if not ucm_base_data:
            raise ValueError("ucm_base_data path is required when bypass channels are present.")

        best_iterations = [
            row["iteration"]
            for row in (
                spark
                .read
                .parquet(baseline_output_path)
                .filter(F.upper(F.col("best_iteration")) == "Y")
                .select("iteration")
                .distinct()
                .collect()
            )
            if row["iteration"] is not None
        ]
        if not best_iterations:
            raise ValueError("No best iteration found in baseline output for bypass incrementality.")

        bypass_incrementality_filter = config.incrementality_filter_bypass
        bypass_incrementality = get_bypass_incrementality(
            spark=spark,
            ucm_base_data=ucm_base_data,
            best_iterations=best_iterations,
            campaign_facts=campaign_facts,
            bypass_incrementality_filter=bypass_incrementality_filter,
            bypass_marketing_types=bypass_marketing_types,
            config=config
        )
    else:
        bypass_incrementality = 0

    is_full_bypass = check_full_bypass(campaign_facts)

    if is_full_bypass:
        output_df, audit_df = generate_bypass_outputs(
            bypass_incrementality=bypass_incrementality,
            during_incrementality=during_incrementality,
            campaign_facts=campaign_facts,
            campaign_duration=campaign_duration,
            run_date=run_date,
            correlation_id=correlation_id
        )
        spark_s3_overwrite(output_path, output_df)
        spark_s3_overwrite(output_path_audit, audit_df)
        logger.info(f"[{correlation_id}] Full bypass scenario - Incremental Shrinkage completed with bypass incrementality of {bypass_incrementality}")
        return

    # Filter for the campaign period and get the incremental value
    incrementality_filter_all = config.incrementality_filter_all

    ucm_incrementality = get_incrementality(
        campaign_facts,
        baseline_modelling_output,
        incrementality_filter_all,
        bypass_marketing_types=bypass_marketing_types,
        config=config
    )

    ucm_incrementality, calibrated_ucm, audit, channel_prior = run_incremental_shrinkage(
        spark,
        campaign_facts,
        avg_weekly_spend_data,
        legacy_campaign_data,
        ucm_incrementality,
        bypass_incrementality,
        config,
    )

    # Calibration can return None when one or more channels fail; treat it as 0 for additive adjustment only.
    if calibrated_ucm is None:
        raise ValueError("Calibration failed for all channels, cannot proceed with shrinkage calculation.")
    else:
        adjusted_calibrated_ucm = calibrated_ucm + during_incrementality + bypass_incrementality

    output_df = build_incremental_shrinkage_output_df(
        campaign_facts=campaign_facts,
        ucm_incrementality=ucm_incrementality,
        calibrated_ucm=calibrated_ucm,
        adjusted_calibrated_ucm=adjusted_calibrated_ucm,
        during_incrementality=during_incrementality,
        bypass_incrementality=bypass_incrementality,
        campaign_duration=campaign_duration,
        run_date=run_date,
        correlation_id=correlation_id,
    )
    audit_df = build_incremental_shrinkage_audit_df(
        campaign_facts=campaign_facts,
        channel_priors=channel_prior,
        calibration_audit=audit,
        run_date=run_date,
        correlation_id=correlation_id,
    )

    spark_s3_overwrite(output_path, output_df)

    spark_s3_overwrite(output_path_audit, audit_df)

    logger.info(f"[{correlation_id}] Incremental Shrinkage completed successfully")


def run_incremental_shrinkage(
        spark: SparkSession,
        campaign_facts: DataFrame,
        avg_weekly_spend_data: DataFrame,
        legacy_campaign_data: DataFrame,
        total_incrementality: DataFrame,
        bypass_incrementality: Optional[float],
        config: BaselineModellingShrinkageConfig,
) -> Tuple[float, Optional[float], Dict[str, Any], Dict[str, Any]]:

    # The hierarchy of the data we run in the UCM with incrementality
    campaign_metadata = (
        campaign_facts
        .crossJoin(F.broadcast(total_incrementality))
        .filter(~F.col('bypass_flag'))
        .select(
            "super_category_name",
            "sub_category_name",
            "unique_brand_name",
            "incrementality",
            F.year("min_campaign_start_dt").alias("campaign_year"),
        )
        .distinct()
    )

    # Get the media spend per campaign source
    campaign_channel_df = (
        campaign_facts
        .select(
            "marketing_type",
            "channel_spend",
            "bypass_flag"
        )
    )

    # Only keep campaigns matching the allowed super-category count

    single_super_cat_campaigns = (
        legacy_campaign_data
        .groupBy("campaign_id")
        .agg(F.countDistinct("super_category_name").alias("num_super_categories"))
        .filter(F.col("num_super_categories") == config.allowed_super_cat_count)
        .select("campaign_id")
    )

    legacy_campaign_data_filtered = (
        legacy_campaign_data.join(
            single_super_cat_campaigns, on="campaign_id", how="left_semi"
        )
    )

    legacy_campaign_data_filtered = outlier_filter(legacy_campaign_data_filtered, config)

    # Gets each campaign source's media spend and average weekly spend for shrinkage calculation in dictionary structure where campaign source is the key
    campaign_channel = {
        channel["marketing_type"]: channel.asDict()
        for channel in campaign_channel_df.collect()
    }

    channels = [
        channel[0]
        for channel in campaign_facts.select("marketing_type").filter(~F.col('bypass_flag')).distinct().collect()
    ]

    prior_sampled_distribution_incrementality, channel_samples, failed_channels, channel_data_collection = (
        get_aggregate_prior(
            channels,
            campaign_metadata,
            campaign_channel,
            legacy_campaign_data_filtered,
            avg_weekly_spend_data,
            config,
        )
    )

    # Update the channel_priors to include the metadata from the bypassed channels
    updated_channel_priors = generate_bypass_metadata(
        spark=spark,
        campaign_channel=campaign_channel,
        channel_samples=channel_samples
    )

    raw_incrementality = total_incrementality.first()["incrementality"]
    if raw_incrementality is None:
        logger.warning("Calculated incrementality is None, setting to 0 for calibration.")
        raw_incrementality = 0.0

    # When the overall incrementality from UCM is negative, we convert this to zero and apply calibration to the zero uplift scenario.
    if raw_incrementality < 0:
        logger.info(f"Calculated incrementality is negative ({raw_incrementality}), setting to 0 for calibration.")
        incrementality = 0.0
    else:
        incrementality = raw_incrementality

    # Remove any incrementality from bypass channels before triggering calibration
    incrementality -= bypass_incrementality

    if len(failed_channels) > 0:
        # TODO: send a slack alert
        failure_audit = {'failed_channels': failed_channels}
        calibrated_ucm = None
        logger.warning(f"Calibration failed for channels: {failed_channels}.")
        return float(raw_incrementality), calibrated_ucm, failure_audit, updated_channel_priors

    calibrated_ucm, audit = calibrate(
        incrementality, prior_sampled_distribution_incrementality, config
    )

    logger.info(f"Calibrated UCM contribution: {calibrated_ucm}")
    # We still return the raw incrementality even when calibration fails as this still provides useful information, and the audit output will contain the failure reason for transparency.
    return float(raw_incrementality), float(calibrated_ucm), audit, updated_channel_priors


def entrypoint(
    spark: SparkSession, command_line_args: Optional[List[str]] = None
) -> None:
    """Entrypoint wrapper compatible with project conventions.

    Args:
        spark: SparkSession provided by the caller.
        command_line_args: Optional list of CLI arguments to parse (for programmatic calls).
    """
    parser = ThrowingArgumentParser(description="Incremental Shrinkage")

    # Input paths
    parser.add_argument(
        "--baseline-output-path",
        type=str,
        required=True,
        help="S3 path for baseline output (DMO)",
    )
    parser.add_argument(
        "--avg-weekly-spend-data-path",
        type=str,
        required=True,
        help="S3 path for average weekly spend data",
    )
    parser.add_argument(
        "--measurement-legacy-campaign-performance",
        type=str,
        required=True,
        help="S3 path for measurement legacy campaign performance data (used for media spend metrics)",
    ),
    parser.add_argument(
        "--campaign-selection-path",
        type=str,
        required=True,
        help="S3 path for campaign selection data",
    )
    parser.add_argument(
        "--brand-data-path",
        type=str,
        required=True,
        help="S3 path for brand data",
    )
    # Output path
    parser.add_argument(
        "--output-path-audit",
        type=str,
        required=True,
        help=""
    )
    # Output path
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path where the integrated shrinkage output will be saved",
    )
    # Campaign duration for shrinkage calculation, e.g. 'pre', 'post' or 'full'
    parser.add_argument(
        "--campaign-duration",
        type=str,
        required=True,
        choices=[CampaignDurations.CAMPAIGN_DURATION_DURING, CampaignDurations.CAMPAIGN_DURATION_POST],
        help="Campaign duration for shrinkage calculation, e.g. 'During' or 'Post'",
    )
    # Metadata
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline execution date in YYYY-MM-DD format",
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the pipeline run",
    )
    parser.add_argument(
        "--previous-measurement-campaign-reporting",
        type=str,
        required=False,
        help="S3 path for previous measurement campaign reporting data, required for Post period shrinkage calculation",
    )
    parser.add_argument(
        "--ucm-base-data",
        type=str,
        required=False,
        help="S3 path for Feature contributions from UCM model",
    )
    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_incremental_shrinkage(
        spark=spark,
        baseline_output_path=known_args.baseline_output_path,
        avg_weekly_spend_data_path=known_args.avg_weekly_spend_data_path,
        measurement_legacy_campaign_performance=known_args.measurement_legacy_campaign_performance,
        campaign_selection_path=known_args.campaign_selection_path,
        output_path=known_args.output_path,
        output_path_audit=known_args.output_path_audit,
        campaign_duration=known_args.campaign_duration,
        run_date=known_args.run_date,
        correlation_id=known_args.correlation_id,
        previous_measurement_campaign_reporting=known_args.previous_measurement_campaign_reporting,
        ucm_base_data=known_args.ucm_base_data,
        brand_data_path=known_args.brand_data_path,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("IncrementalShrinkage").getOrCreate())
