from decimal import Decimal
from typing import List, Dict, Any, Tuple, Optional, Union
from datetime import datetime

import numpy as np
from pyspark.sql import functions as F, DataFrame, Column, types as T
from spark_pipeline.common.variables import BaselineModellingShrinkageConfig
from spark_pipeline.utils.stdout_logger import get_stdout_logger
from spark_pipeline.schemas.baseline_modelling_shrinkage import BaselineModellingShrinkage
from spark_pipeline.common.variables import CampaignDurations

logger = get_stdout_logger()


def add_unscaled_incrementality(reporting_df: DataFrame) -> DataFrame:
    """
    Add an unscaled incrementality column to campaign reporting data.

    ``incremental_sales_amt_exposed`` is divided by ``spend_weight`` when a
    positive spend weight is available. Rows with a missing, zero, or negative
    spend weight, as well as DataFrames without a spend-weight column, retain
    their original incrementality value.

    Parameters
    ----------
    reporting_df : DataFrame
        Campaign reporting data containing ``incremental_sales_amt_exposed``
        and optionally  ``spend_weight`` column.

    Returns
    -------
    DataFrame
        The input DataFrame with ``unscaled_incrementality`` added.
    """
    spend_weight_column = next(
        (
            column
            for column in reporting_df.columns
            if column.lower() == "spend_weight"
        ),
        None,
    )

    if spend_weight_column:
        unscaled_incrementality = F.when(
            F.col(spend_weight_column).isNull()
            | (F.col(spend_weight_column) <= 0),
            F.col("incremental_sales_amt_exposed"),
        ).otherwise(
            F.col("incremental_sales_amt_exposed") / F.col(spend_weight_column)
        )
    else:
        unscaled_incrementality = F.col("incremental_sales_amt_exposed")

    return reporting_df.withColumn(
        "unscaled_incrementality",
        unscaled_incrementality,
    )


def get_campaign_bounds(campaign_facts: DataFrame) -> DataFrame:
    """
    Get the campaign booking window by calculating the min start date and max end date for the campaign.
    """
    return campaign_facts.agg(
        F.min("min_campaign_start_dt").alias("booking_start_dt"),
        F.max("max_campaign_end_dt").alias("booking_end_dt"),
    )


def get_incrementality(
    campaign_facts: DataFrame,
    baseline_modelling_output: DataFrame,
    incremental_type: str,
    bypass_marketing_types: Dict[str, str],
    config: BaselineModellingShrinkageConfig,
) -> DataFrame:
    """
    Calculate total incremental sales across the campaign booking window.
    """

    if incremental_type == 'all':
        filter_cond = ((
            F.col("week_start_dt") >= F.date_trunc("week", F.col("booking_start_dt")))
            & (
                F.col("week_start_dt")
                <= F.date_add(F.date_trunc("week", F.col("booking_end_dt")), 7)
        )
            & (F.col("metric_name") == config.incrementality_metric))
    elif incremental_type == 'bypass-only':

        # Get the regex patterns from the bypass channels, this will allow us to filter on the correct UCM features.
        bypass_patterns = list(bypass_marketing_types.values())
        # Join into a single regex pattern and match case-insensitively
        regex_pattern = f"(?i){'|'.join(bypass_patterns)}"

        filter_cond = (
            (F.col("week_start_dt") >= F.date_trunc("week", F.col("booking_start_dt")))
            & (
                F.col("week_start_dt")
                <= F.date_add(F.date_trunc("week", F.col("booking_end_dt")), 7)
            )
            & (
                F.col("metric_name").rlike(regex_pattern)
            )
        )
    else:
        raise ValueError(f"incremental_type must be 'all' or 'bypass-only', got '{incremental_type}'")

    # Get the min max campaign booking window for the campaign
    booking_dates = get_campaign_bounds(campaign_facts)

    total_incrementality = (
        baseline_modelling_output.crossJoin(F.broadcast(booking_dates))
        .filter(filter_cond)
        .agg(
            F.sum("metric_value").alias("incrementality"),
        )
    )

    return total_incrementality


def outlier_filter(
    historical_campaigns: DataFrame,
    config: BaselineModellingShrinkageConfig
) -> DataFrame:
    """
    Filters out outliers from the historical campaigns dataframe based on the provided configuration thresholds.
    These thresholds are based on estimates from the Analytics team
    """
    filtered_campaigns = (
        historical_campaigns
        .filter(
            (F.col("media_cost") >= config.spend_min_threshold)
            & (F.col("iroas") <= config.iroas_max_threshold)
            & (F.col("iroas") >= config.iroas_min_threshold)
            & (((F.col("test") - F.col("control")) / F.col("control")) * 100 <= config.pcnt_uplift_max_threshold)
        )
    )

    return filtered_campaigns


def normalise_marketing_type(column: Column) -> Column:
    """
    Legacy data doesn't follow the media hierarchy consistently,
    This function normalises the marketing type column by removing spaces and special characters and converting to upper case. This will help to ensure that we are grouping the campaigns correctly when we are creating the prior distribution for each channel.
    """

    return F.regexp_replace(
        F.upper(F.trim(column)),
        r"[\s\.\,\-\_\&\/\(\)\[\]\{\}\:\;\'\"\!\?]+",
        "",
    )


def normalise_brand_name(column: Column) -> Column:
    """
    Strips non-ASCII characters (e.g. accented characters like É, Ñ) from brand name columns.
    Used to ensure consistent joins when upstream data sources differ in special character encoding
    (e.g. 'NESCAFÉ' in benchmark_spend_data vs 'NESCAF' in campaign_selection data).
    """
    return F.regexp_replace(F.upper(F.trim(column)), r"[^\x00-\x7F]+", "")


def aggregate_campaigns_to_brand_grain(
    legacy_campaign_data: DataFrame,
    brand_data: DataFrame,
) -> DataFrame:
    """
    Aggregate item-level legacy campaign data to the legacy campaign/brand grain.

    Args:
        legacy_campaign_data: Campaign performance data at campaign/item grain, with
            campaign-level metrics repeated per ``item_cd``.
        brand_data: Product hierarchy mapping for each ``item_cd`` including super
            category, sub-category, and unique brand name.

    Returns:
        DataFrame aggregated to campaign/brand grain with hierarchy lists, distinct
        hierarchy counts, and the original campaign-level metrics preserved.
    """

    return (
        legacy_campaign_data
        .join(brand_data, on="item_cd", how="inner")
        .groupBy(
            "campaign_id",
            "campaign_source",
            "period",
            "campaign_start_date",
            "campaign_end_date",
            "super_category_name",
        )
        .agg(
            F.concat_ws(", ", F.sort_array(F.collect_set("sub_category_name"))).alias("sub_category_name_list"),
            F.concat_ws(", ", F.sort_array(F.collect_set("unique_brand_name"))).alias("unique_brand_name_list"),
            F.countDistinct("sub_category_name").alias("num_unique_subcats"),
            F.countDistinct("unique_brand_name").alias("num_unique_brands"),
            F.first("test", ignorenulls=True).alias("test"),
            F.first("control", ignorenulls=True).alias("control"),
            F.first("uplift", ignorenulls=True).alias("uplift"),
            F.first("media_cost", ignorenulls=True).alias("media_cost"),
        )
    )


def attach_product_hierarchy(
    avg_weekly_spend_data: DataFrame,
    brand_data: DataFrame,
) -> DataFrame:
    """
    Attach product hierarchy to item/week spend data and aggregate it to the legacy
    year/category/brand grain.

    Args:
        avg_weekly_spend_data: Average weekly spend input at item/week grain.
        brand_data: Product hierarchy mapping for each ``item_cd`` including super
            category, sub-category, and unique brand name.

    Returns:
        DataFrame at year/category/brand grain with hierarchy attached and weekly
        spend metrics averaged across distinct weeks for each hierarchy key.
    """

    return (
        avg_weekly_spend_data
        .join(brand_data, on="item_cd", how="inner")
        .groupBy(
            "year",
            "super_category_name",
            "sub_category_name",
            "unique_brand_name",
        )
        .agg(
            F.first("inflation_ratio", ignorenulls=True).alias("inflation_ratio"),
            (F.sum("avg_weekly_spend") / F.countDistinct("week")).alias("avg_weekly_spend"),
            (F.sum("avg_weekly_spend_inf_adj") / F.countDistinct("week")).alias("avg_weekly_spend_inf_adj"),
        )
    )


def get_dynamic_campaign_sample(
    benchmark_spends: DataFrame,
    target_spend: Union[float, Decimal],
    channel: str,
    config: BaselineModellingShrinkageConfig,
    filter_pass_no: int
) -> Tuple[DataFrame, float]:
    """
    Dynamically filters the benchmark spends dataframe to find a subset of campaigns with similar average weekly spend to the target spend.
    The function starts with a narrow percentage window (init_p) and expands it iteratively by a defined step until it finds a subset of campaigns that meets the minimum count requirement (min_n),
    or reaches a maximum window of 200%.
    """

    init_p = config.initial_percentage_window
    step = config.step_size
    pass_key = f'pass_{filter_pass_no}'
    min_n = config.min_n[pass_key][channel]

    target_spend = float(target_spend)
    curr_p = init_p

    while curr_p <= 2.0:
        bounds = (target_spend * (1 - curr_p), target_spend * (1 + curr_p))
        subset = benchmark_spends.filter(F.col("avg_weekly_spend").between(*bounds))

        # Check source counts
        count = subset.count()

        if count >= min_n:
            logger.info(f"Found {count} campaigns within +/- {curr_p * 100:.0f}% of target spend.")
            return subset, curr_p

        curr_p += step

    logger.warning("Max window (200%) reached.")
    return subset, curr_p


def filter_revenue_similarity(
    historical_campaigns: DataFrame,
    benchmark_spend_data: DataFrame,
    campaign_metadata: DataFrame,
    config: BaselineModellingShrinkageConfig,
    channel: str,
    filter_pass_no: int,
) -> Tuple[DataFrame, float]:
    """
    Filters the historical campaigns dataframe to find a subset of campaigns with similar average weekly spend to the target spend for the evaluated campaign.
    The function uses the benchmark spend data to find the target spend based on the campaign metadata (super category, sub category, brand) and the campaign years.
    It then calls the get_dynamic_campaign_sample function to find the subset of campaigns that are within a certain percentage of the target spend.
    The function returns the filtered historical campaigns dataframe and the percentage window used to find the subset.
    """

    campaign_hierarchy = (
        campaign_metadata
        .select(
            "super_category_name",
            "sub_category_name",
            "unique_brand_name",
            "campaign_year",
            normalise_brand_name(F.col("unique_brand_name")).alias("norm_brand"),
        )
    )
    benchmark_with_norm = benchmark_spend_data.withColumn(
        "norm_brand", normalise_brand_name(F.col("unique_brand_name"))
    )
    # Target data for the evaluated campaign.
    # Join on normalised brand name to handle encoding mismatches between data sources
    # (e.g. 'NESCAFÉ' in benchmark_spend_data vs 'NESCAF' in campaign_selection data).
    target_data = (
        (
            benchmark_with_norm.join(
                campaign_hierarchy,
                on=(
                    (
                        benchmark_with_norm.super_category_name
                        == campaign_hierarchy.super_category_name
                    )
                    & (
                        benchmark_with_norm.sub_category_name
                        == campaign_hierarchy.sub_category_name
                    )
                    & (
                        benchmark_with_norm["norm_brand"]
                        == campaign_hierarchy["norm_brand"]
                    )
                    & (benchmark_with_norm.year == campaign_hierarchy.campaign_year)
                ),
                how="inner",
            ).agg(F.sum("avg_weekly_spend").alias("avg_weekly_spend"))
        )
        .collect()
    )

    brand_name = campaign_metadata.select("unique_brand_name").collect()[0][0]
    sub_category = campaign_metadata.select("sub_category_name").collect()[0][0]

    if not target_data or target_data[0][0] is None:
        raise ValueError(f"No target spend found for {brand_name} / {sub_category}")

    target_spend_val = target_data[0][0]

    logger.info(f"Target Spend Value: {target_spend_val}")
    # Attributes an average weekly spend to each historical campaign
    # Note - where multiple brand/subcat, takes the sum spend across these.
    search_df = (
        historical_campaigns.withColumn(
            "sub_category_name", F.explode(F.split("sub_category_name_list", ", "))
        )
        .withColumn(
            "unique_brand_name", F.explode(F.split("unique_brand_name_list", ", "))
        )
        .withColumn("year", F.year("campaign_start_date"))
        .join(
            benchmark_spend_data,
            ["year", "sub_category_name", "unique_brand_name"],
            "inner",
        )
        .groupBy("campaign_id", "campaign_source")
        # We take the average for campaign metrics as these are duplicated across each sub_category as part of the explode function
        # We take the sum of the spend data as this is joined on after the sub-categories are exploded so we sum over each sub-cat
        .agg(
            F.avg("test").alias("test"),
            F.avg("control").alias("control"),
            F.avg("media_cost").alias("media_cost"),
            F.avg("iroas").alias("iroas"),
            F.avg("uplift").alias("uplift"),
            F.sum("avg_weekly_spend").alias("avg_weekly_spend"),
        )
    ).cache()
    search_df = search_df.filter(F.col("avg_weekly_spend") >= config.min_avg_weekly_spend)
    subset, rev_p = get_dynamic_campaign_sample(
        search_df, target_spend_val, channel, config, filter_pass_no
    )

    return subset, rev_p


def get_channel_data(
    channel: str,
    campaign_metadata: DataFrame,
    historical_campaigns: DataFrame,
    benchmark_spend_data: DataFrame,
    config: BaselineModellingShrinkageConfig,
    filter_pass_no: int
) -> Tuple[DataFrame, float]:
    """
    Gets the historical campaign data for a specific channel, filtered by revenue similarity to the target campaign.
    """

    logger.info(f"Processing channel: {channel}")

    channel_data = historical_campaigns.filter(F.col("marketing_type") == channel)

    super_category_name = campaign_metadata.select("super_category_name").collect()[0][0]

    if (
        super_category_name in config.instore_split_cats
        and channel.lower() == config.instore_channel
        and filter_pass_no == 1
    ):
        logger.info("Super Category level filtered")
        filter_df = campaign_metadata.select("super_category_name").distinct()
        channel_data = channel_data.join(
            filter_df, on="super_category_name", how="inner"
        )

    channel_data, rev_p = filter_revenue_similarity(
        channel_data, benchmark_spend_data, campaign_metadata, config, channel, filter_pass_no
    )

    return channel_data, rev_p


def draw_samples(
    channel_prior: DataFrame,
    media_spend: float,
    median_historical_spend: float,
    alpha: float = 0.5,
    shift_parameter: Optional[float] = None,
    n_samples: int = 10000,
    random_seed: Optional[int] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    rand_generator = np.random.default_rng(seed=random_seed)

    if shift_parameter is None:
        raise ValueError(
            "Shift constant must be provided for log normal distribution"
        )

    # Random sample from a NORMAL distribution of log(uplift + shift)
    mu = channel_prior.select("mean_log_uplift").collect()[0][0]
    sigma = (channel_prior.select("var_log_uplift").collect()[0][0]) ** 0.5
    y_samples = rand_generator.normal(mu, sigma, size=n_samples)
    uplift_samples = [np.exp(float(y)) - float(shift_parameter) for y in y_samples]

    # This ratio is used to account for the increase in expected incrementality for channels with higher media spend. We expect this relationship to to be sub-linear,
    # so we apply an exponent alpha to control the strength of this effect. When media spend is equal to the historical median, the ratio is 1 and has no effect on incrementality samples.
    # When media spend is higher than the historical median, the ratio increases and therefore increases the incrementality samples, with the strength of the increase controlled by alpha.
    dampened_ratio = (media_spend / median_historical_spend) ** alpha
    incrementality_samples = [
        uplift * dampened_ratio for uplift in uplift_samples
    ]

    return y_samples, incrementality_samples


def get_log_normal_params(
    channel_data: DataFrame, shift_parameter: Optional[float]
) -> Tuple[DataFrame, DataFrame]:

    channel_data = channel_data.withColumn(
        "uplift_shifted", F.col("uplift") + shift_parameter
    ).withColumn("uplift_log_shifted", F.ln(F.col("uplift_shifted")))

    channel_prior = (
        channel_data.agg(
            F.mean("uplift_log_shifted").alias("mean_log_uplift"),
            F.variance("uplift_log_shifted").alias("var_log_uplift"),
            F.count("campaign_id").alias("count_campaigns"),
        )
        .withColumn("distribution_type", F.lit("log_normal"))
        .withColumn("shift_parameter", F.lit(shift_parameter))
    )

    return channel_data, channel_prior


def get_channel_distribution(
    channel_data: DataFrame,
    media_spend: float,
    median_historical_spend: float,
    alpha: float = 0.5,
    shift_parameter: Optional[float] = None,
    n_samples: int = 10000,
    config: Optional[BaselineModellingShrinkageConfig] = None,
) -> Tuple[np.ndarray, np.ndarray, DataFrame, DataFrame]:

    channel_data, channel_prior = get_log_normal_params(channel_data, shift_parameter)

    y_samples, incrementality_random_samples = draw_samples(
        channel_prior,
        media_spend,
        median_historical_spend=median_historical_spend,
        alpha=alpha,
        shift_parameter=shift_parameter,
        n_samples=n_samples,
        random_seed=config.random_seed
    )

    return incrementality_random_samples, y_samples, channel_prior, channel_data


def collect_channel_data(
    channels: List[str],
    campaign_metadata: DataFrame,
    historical_campaigns: DataFrame,
    benchmark_spend_data: DataFrame,
    config: BaselineModellingShrinkageConfig,
) -> Tuple[Dict[str, DataFrame], Dict[str, float], List[str], float]:
    """
    For each channel, runs the filter pass escalation logic to find a sufficient sample of
    historical campaigns. Returns the collected data, revenue similarity thresholds, any
    channels that failed to meet the overall minimum, and the minimum uplift across all
    successful channels (used to compute the log-normal shift constant).

    For each channel, iteratively loosens guardrails until a sufficient sample size is reached
    or the maximum number of passes is exceeded.
    If we cannot meet a sufficient size - reported as failure for the channel
    """
    channel_data_collection = {}
    rev_similarity_thresholds = {}
    failed_channels = []
    min_uplift = float("inf")

    for channel in channels:
        filter_pass_no = 1
        # Iteratively loosens guardrails on sample similarity & size
        # until a sufficient sample size is reached, or max passes is exceeded
        # If we cannot meet a sufficient size - reported as failure for the channel
        while filter_pass_no <= config.max_passes:
            channel_data, rev_p = get_channel_data(
                channel,
                campaign_metadata,
                historical_campaigns,
                benchmark_spend_data,
                config,
                filter_pass_no,
            )

            channel_count = channel_data.count()
            if channel_count >= config.min_n[f'pass_{filter_pass_no}'][channel]:
                break

            print(
                f"Filter pass {filter_pass_no} for channel {channel} returned insufficient data. "
                f"Campaign count: {channel_count}. Rev similarity percentage window: {rev_p * 100:.2f}%"
            )
            filter_pass_no += 1

        if channel_count < config.min_n['overall']:
            failed_channels.append(channel)
            continue

        channel_data = channel_data.withColumn("marketing_type", F.lit(channel))
        channel_data_collection[channel] = channel_data
        min_uplift = min(min_uplift, float(channel_data.agg(F.min("uplift")).collect()[0][0]))
        rev_similarity_thresholds[channel] = rev_p

    return channel_data_collection, rev_similarity_thresholds, failed_channels, min_uplift


def sample_channel_distributions(
    channels: List[str],
    channel_data_collection: Dict[str, DataFrame],
    rev_similarity_thresholds: Dict[str, float],
    campaign_channel: Dict[str, Any],
    shift_constant: float,
    config: BaselineModellingShrinkageConfig,
) -> Tuple[Dict[str, DataFrame], Dict[str, DataFrame], Dict[str, np.ndarray], Dict[str, np.ndarray]]:
    """
    For each channel with sufficient data, fits the log-normal prior and draws incrementality
    samples. Returns channel data, priors (with rev_similarity_percentile attached),
    incrementality samples, and log-space y-samples.
    """
    channel_data_samples = {}
    channel_priors = {}
    channel_incrementality_samples = {}
    channel_y_samples = {}

    for channel in channels:
        media_spend = campaign_channel[channel]["channel_spend"]

        # Calculate the median historical spend for the channel to use in the dampening ratio when calculating incrementality samples.
        median_historical_spend = float(channel_data_collection[channel].agg(F.percentile_approx("media_cost", 0.5)).collect()[0][0])

        # Alpha controls the strength of the dampening effect on incrementality samples for channels with higher media spend than the historical median.
        alpha = config.alpha

        incrementality_random_samples, y_random_samples, channel_prior, channel_data = (
            get_channel_distribution(
                channel_data=channel_data_collection[channel],
                media_spend=media_spend,
                shift_parameter=shift_constant,
                median_historical_spend=median_historical_spend,
                alpha=alpha,
                config=config,
            )
        )

        channel_data_samples[channel] = channel_data
        channel_priors[channel] = (
            channel_prior
            .withColumn(
                "rev_similarity_percentile", F.lit(rev_similarity_thresholds[channel])
            )
            .withColumn(
                "bypass_flag", F.lit(False)
            ))

        channel_incrementality_samples[channel] = incrementality_random_samples
        channel_y_samples[channel] = y_random_samples

    return channel_data_samples, channel_priors, channel_incrementality_samples, channel_y_samples


def get_aggregate_prior(
    channels: List[str],
    campaign_metadata: DataFrame,
    campaign_channel: Dict[str, Any],
    historical_campaigns: DataFrame,
    benchmark_spend_data: DataFrame,
    config: BaselineModellingShrinkageConfig,
) -> Tuple[np.ndarray, Dict[str, Any], List[str], Dict[str, DataFrame]]:

    channel_data_collection, rev_similarity_thresholds, failed_channels, min_uplift = (
        collect_channel_data(
            channels,
            campaign_metadata,
            historical_campaigns,
            benchmark_spend_data,
            config,
        )
    )

    # Ensure any downstream log(uplift + shift_constant) is strictly defined.
    # Using only abs(min_uplift) would make the minimum shifted uplift exactly 0
    # when min_uplift is negative, which would produce -inf under log.
    shift_constant = abs(min_uplift) if min_uplift <= 0 else 0

    sufficient_data_channels = [c for c in channels if c not in failed_channels]

    channel_data_samples, channel_priors, channel_incrementality_samples, channel_y_samples = (
        sample_channel_distributions(
            sufficient_data_channels,
            channel_data_collection,
            rev_similarity_thresholds,
            campaign_channel,
            shift_constant,
            config,
        )
    )

    prior_sampled_distribution_incrementality = np.sum(
        np.array([channel_incrementality_samples[channel] for channel in sufficient_data_channels]),
        axis=0,
    )

    channel_samples = {
        "data": channel_data_samples,
        "priors": channel_priors,
        "incrementality_samples": channel_incrementality_samples,
        "channel_y_samples": channel_y_samples,
    }

    return (
        prior_sampled_distribution_incrementality,
        channel_samples,
        failed_channels,
        channel_data_collection,
    )


def interval_mode(arr, bins='auto'):
    """
    Compute the modal interval (range with highest frequency)
    and an approximate mode value (midpoint of that interval).
    Parameters:
        arr  : array-like of floats
        bins : number of bins or method ('auto', 'fd', 'sturges', etc.)
    Returns:
        mode_interval : tuple (lower_edge, upper_edge)
        mode_value    : midpoint of the modal interval
        counts        : histogram counts
        bin_edges     : bin boundaries
    """
    arr = np.asarray(arr)

    counts, bin_edges = np.histogram(arr, bins=bins)

    # index of most frequent bin
    idx = np.argmax(counts)

    mode_interval = (bin_edges[idx], bin_edges[idx + 1])
    mode_value = (mode_interval[0] + mode_interval[1]) / 2
    if mode_value < 0:
        logger.warning(f"Negative prior mode value {mode_value} adjusted to 0.")
        mode_value = 0
    return mode_interval, mode_value, counts, bin_edges


def get_median(arr):
    """
    Compute the median of an array (clamped to be non-negative).
    Parameters:
        arr : array-like of floats
    Returns:
        median_value : median of the array (>= 0)
    """
    arr = np.asarray(arr)
    median_value = np.median(arr)
    if median_value < 0:
        logger.warning(f"Negative prior median value {median_value} adjusted to 0.")
        median_value = 0
    return median_value


def calibrate(
    ucm_value: float,
    dist: np.ndarray,
    config: BaselineModellingShrinkageConfig,
) -> Tuple[float, Dict[str, float]]:

    sample_mode = interval_mode(dist)[1]
    sample_parameter = get_median(dist)
    iqr = np.percentile(dist, 75) - np.percentile(dist, 25)
    iqr = max(iqr, 1e-6)

    z = abs(ucm_value - sample_parameter) / iqr
    scaling_exponential_coeff = config.scaling_exponential_coeff
    if scaling_exponential_coeff <= 0:
        raise ValueError("Exponential scaling coefficient must be positive")

    scaling_factor = np.exp(-scaling_exponential_coeff * z)

    calibrated_incrementality = ucm_value * scaling_factor + (
        sample_parameter * (1 - scaling_factor)
    )

    audit = {
        "z_score": z,
        "scaling_factor": scaling_factor,
        "sample_mean": np.mean(dist),
        "sample_median": sample_parameter,
        "sample_mode": sample_mode,
    }
    return calibrated_incrementality, audit


def get_bypass_incrementality(
    spark,
    ucm_base_data,
    best_iterations,
    campaign_facts,
    bypass_incrementality_filter,
    bypass_marketing_types,
    config
):

    ucm_base_data_df = (
        spark.read.parquet(ucm_base_data)
        .filter(F.col("iteration").isin(best_iterations))
        .select(
            F.col("wdate").alias("week_start_dt"),
            "modelling_cluster",
            "iteration",
            F.col("variable").alias("metric_name"),
            F.col("value").alias("metric_value"),
        )
        .distinct()
    )

    # Filter for the campaign period and get the incremental value
    raw_bypass_incrementality_object = get_incrementality(campaign_facts, ucm_base_data_df, bypass_incrementality_filter, bypass_marketing_types, config)
    raw_bypass_incrementality = raw_bypass_incrementality_object.first()["incrementality"]
    bypass_incrementality = max(raw_bypass_incrementality or 0, 0)
    return bypass_incrementality


def check_bypass_channels(campaign_facts, campaign_duration, config):
    """
    Determine bypass channels and patterns based on campaign duration.

    For POST period: includes ONSITE, ECOUPON, COUPONATTILL
    For DURING period: includes only ONSITE
    """
    # Select appropriate patterns based on campaign duration
    if campaign_duration == CampaignDurations.CAMPAIGN_DURATION_POST:
        bypass_patterns_config = config.post_bypass_marketing_variable_patterns
    elif campaign_duration == CampaignDurations.CAMPAIGN_DURATION_DURING:
        bypass_patterns_config = config.during_bypass_marketing_variable_patterns
    else:
        return False, {}

    all_bypass_marketing_types = list(bypass_patterns_config.keys())

    bypass_channels = (
        campaign_facts
        .filter(F.col('marketing_type').isin(all_bypass_marketing_types))
        .select("marketing_type")
        .distinct()
        .collect()
    )

    bypass_channels_flag = len(bypass_channels) > 0

    if bypass_channels_flag:
        bypass_marketing_types = {
            k: v for k, v in bypass_patterns_config.items()
            if k in [row['marketing_type'] for row in bypass_channels]
        }
    else:
        bypass_marketing_types = {}

    return bypass_channels_flag, bypass_marketing_types


def check_full_bypass(campaign_facts):
    # Filter campaign list for bypass
    remaining_channels = (
        campaign_facts
        .filter(~F.col('bypass_flag'))
    )
    return remaining_channels.isEmpty()


def generate_bypass_outputs(
        bypass_incrementality,
        during_incrementality,
        campaign_facts,
        campaign_duration,
        run_date,
        correlation_id
) -> Tuple[DataFrame, DataFrame]:
    # Set channel_priors to None for processing the audit_df
    channel_prior = None

    # Set the audit values to none as we're skipping calibration
    audit = {
        "z_score": None,
        "scaling_factor": None,
        "sample_mean": None,
        "sample_median": None,
        "sample_mode": None,
    }

    # UCM incrementality is by definition the incrementality value from bypass
    ucm_incrementality = bypass_incrementality
    # No calibration taking place, so calibration is the same as bypass
    calibrated_ucm = bypass_incrementality
    # Only step is to add the during incrementality to get our final incrementality value
    adjusted_calibrated_ucm = bypass_incrementality + during_incrementality

    # Generate the output_df
    output_df = build_incremental_shrinkage_output_df(
        campaign_facts=campaign_facts,
        ucm_incrementality=ucm_incrementality,
        calibrated_ucm=calibrated_ucm,
        adjusted_calibrated_ucm=adjusted_calibrated_ucm,
        during_incrementality=during_incrementality,
        bypass_incrementality=bypass_incrementality,
        campaign_duration=campaign_duration,
        run_date=run_date,
        correlation_id=correlation_id,
    )

    # Generate the audit_df
    audit_df = build_incremental_shrinkage_audit_df(
        campaign_facts=campaign_facts,
        channel_priors=channel_prior,
        calibration_audit=audit,
        run_date=run_date,
        correlation_id=correlation_id,
    )
    return output_df, audit_df


def generate_bypass_metadata(
    spark,
    campaign_channel,
    channel_samples

):
    bypassed_channels = [
        k for k, v in campaign_channel.items()
        if v.get("bypass_flag", False) is True
    ]

    dummy_schema = (
        T.StructType([
            T.StructField("mean_log_uplift", T.DoubleType(), True),
            T.StructField("var_log_uplift", T.DoubleType(), True),
            T.StructField("count_campaigns", T.LongType(), True),
            T.StructField("distribution_type", T.StringType(), True),
            T.StructField("shift_parameter", T.DoubleType(), True),
            T.StructField("rev_similarity_percentile", T.DoubleType(), True),
            T.StructField("bypass_flag", T.BooleanType(), True),
        ])
    )

    blank_row = [{
        "mean_log_uplift": None,
        "var_log_uplift": None,
        "count_campaigns": None,
        "distribution_type": None,
        "shift_parameter": None,
        "rev_similarity_percentile": None,
        "bypass_flag": True,
    }]

    bypass_metadata_df = spark.createDataFrame(blank_row, schema=dummy_schema)

    updated_channel_priors = dict(channel_samples["priors"])

    for ch in bypassed_channels:
        updated_channel_priors.setdefault(ch, bypass_metadata_df)
    return updated_channel_priors


def build_incremental_shrinkage_output_df(
        campaign_facts: DataFrame,
        ucm_incrementality: float,
        calibrated_ucm: Optional[float],
        adjusted_calibrated_ucm: Optional[float],
        during_incrementality: Optional[float],
        bypass_incrementality: Optional[float],
        campaign_duration: Optional[str],
        run_date: str,
        correlation_id: str,
) -> DataFrame:
    """Build the main shrinkage output with one row per output metric."""

    metric_rows = campaign_facts.sparkSession.createDataFrame(
        [
            ("ucm_incrementality", float(ucm_incrementality)),
            ("calibrated_incrementality", float(calibrated_ucm) if calibrated_ucm is not None else None),
            ("adjusted_calibrated_incrementality", float(adjusted_calibrated_ucm) if adjusted_calibrated_ucm is not None else None),
            ("during_incrementality", float(during_incrementality) if campaign_duration == CampaignDurations.CAMPAIGN_DURATION_POST else None),
            ("bypass_incrementality", float(bypass_incrementality) if bypass_incrementality is not None else None),
        ],
        schema=BaselineModellingShrinkage.incrementality_metrics,
    )

    campaign_keys = (
        campaign_facts
        .groupBy("unique_brand_name", "super_category_name")
        .agg(
            F.concat_ws(", ", F.sort_array(F.collect_set(F.col("sub_category_name")))).alias("sub_category_name")
        )
    )

    return (
        campaign_keys
        .crossJoin(F.broadcast(metric_rows))
        .withColumn("run_date", F.lit(run_date).cast("date"))
        .withColumn("correlation_id", F.lit(correlation_id))
        .withColumn("load_ts", F.current_timestamp())
        .select(
            "run_date",
            "correlation_id",
            "load_ts",
            "unique_brand_name",
            "super_category_name",
            "sub_category_name",
            "metric_name",
            F.col("metric_value").cast("float").alias("metric_value"),
        )
    )


def build_incremental_shrinkage_audit_df(
    campaign_facts: DataFrame,
    channel_priors: Dict[str, Any],
    calibration_audit: Dict[str, Any],
    run_date: str,
    correlation_id: str,

) -> DataFrame:

    # if no channel priors were calculated, empty df other than failed channels audit info will be returned as audit output
    if not channel_priors:
        failed_channels = calibration_audit.get('failed_channels', [])
        return (
            campaign_facts.sparkSession.createDataFrame(
                [{
                    "run_date": datetime.strptime(run_date, "%Y-%m-%d").date(),
                    "correlation_id": correlation_id,
                    "load_ts": None,
                    "unique_brand_name": None,
                    "super_category_name": None,
                    "sub_category_name": None,
                    "marketing_type": None,
                    "mean_log_uplift": None,
                    "var_log_uplift": None,
                    "count_campaigns": None,
                    "distribution_type": None,
                    "shift_parameter": None,
                    "rev_similarity_percentile": None,
                    "scaling_factor": None,
                    "sample_median": None,
                    "z_score": None,
                    "channel_prior_failures": ",".join(failed_channels) if failed_channels else None,
                }],
                schema=BaselineModellingShrinkage.audit,
            )
            .withColumn("load_ts", F.current_timestamp())
        )

    campaign_keys = (
        campaign_facts
        .select(
            "unique_brand_name",
            "super_category_name",
            "sub_category_name",
        )
        .distinct()
    )

    audit_metrics_df = None

    failed_channels = calibration_audit.get('failed_channels')
    audit_fields = {
        "scaling_factor": calibration_audit.get("scaling_factor"),
        "sample_median": calibration_audit.get("sample_median"),
        "sample_mode": calibration_audit.get("sample_mode"),
        "z_score": calibration_audit.get("z_score"),
        "channel_prior_failures": ",".join(failed_channels) if failed_channels else None,
    }

    for channel, prior in channel_priors.items():

        audit_metrics = (
            prior
            .withColumn("marketing_type", F.lit(channel))
            .withColumn("scaling_factor", F.lit(audit_fields["scaling_factor"]).cast("double"))
            .withColumn("sample_median", F.lit(audit_fields["sample_median"]).cast("double"))
            .withColumn("sample_mode", F.lit(audit_fields["sample_mode"]).cast("double"))
            .withColumn("z_score", F.lit(audit_fields["z_score"]).cast("double"))
            .withColumn("channel_prior_failures", F.lit(audit_fields["channel_prior_failures"]).cast("string"))
            .select(
                "marketing_type",
                "mean_log_uplift",
                "var_log_uplift",
                "count_campaigns",
                "distribution_type",
                "shift_parameter",
                "rev_similarity_percentile",
                "scaling_factor",
                "sample_median",
                "sample_mode",
                "z_score",
                "channel_prior_failures",
            )
        )

        channel_audit_df = (
            audit_metrics.crossJoin(campaign_keys)
        )

        audit_metrics_df = (
            channel_audit_df
            if audit_metrics_df is None
            else audit_metrics_df.unionByName(channel_audit_df)
        )

    return (
        audit_metrics_df
        .withColumn("run_date", F.lit(run_date).cast("date"))
        .withColumn("correlation_id", F.lit(correlation_id))
        .withColumn("load_ts", F.current_timestamp())
        .select(
            "run_date",
            "correlation_id",
            "load_ts",
            "unique_brand_name",
            "super_category_name",
            "sub_category_name",
            "marketing_type",
            "mean_log_uplift",
            "var_log_uplift",
            "count_campaigns",
            "distribution_type",
            "shift_parameter",
            "rev_similarity_percentile",
            "scaling_factor",
            "sample_median",
            "sample_mode",
            "z_score",
            "channel_prior_failures",
        )
    )
