from typing import List, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StringType

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite

# TODO: Victor - please review the comments you have addedd in the code and only keep the ones that are relevant to the logic of the code.
# Also the doc string needs to be updated with more information including arguments and return values.
# Also this script also needs to be tested with unit tests. But this can be done in a separate PR - first priority is to comeplte the migration of the code from DBT to PySpark.


def normalize_dv360(
    spark: SparkSession,
    dv360_input_path: str,
    output_path: str,
    run_date: str,
) -> None:
    """This function normalizes DV360 campaign data following DBT logic exactly."""

    # Setting constants for reuse in functions (matching DBT)
    constant_integrationdetails_jobbagid = 'integrationDetails.jobBagId'

    # Read the DV360 data from the s3 bucket
    dv_df = (
        spark
        .read
        .parquet(dv360_input_path)
        .select("DTP_INPUT", "CAMPAIGN_START_DT", "CAMPAIGN_END_DT")
    )

    # Filter out rows with null DTP_INPUT
    dv_df = dv_df.filter(F.col("DTP_INPUT").isNotNull())

    # Remove special characters
    dv_df = dv_df.withColumn(
        "DTP_INPUT",
        F.regexp_replace(F.col("DTP_INPUT"), r'\n  ', '')
    )

    # Parse JSON from DTP_INPUT
    dv_df = dv_df.withColumn(
        "displayName", F.get_json_object(F.col("DTP_INPUT"), "$.displayName")
    ).withColumn(
        "measurementSkus", F.get_json_object(F.col("DTP_INPUT"), "$.measurementSkus")
    ).withColumn(
        "jobBagId", F.get_json_object(F.col("DTP_INPUT"), f"$.{constant_integrationdetails_jobbagid}")
    ).drop("DTP_INPUT")

    # Remove displayName that contains 'test'
    dv_df = dv_df.filter(
        ~F.lower(F.col("displayName")).contains("test") | F.col("displayName").isNull()
    )

    # Explode the 'measurementSkus' column with better error handling
    try:
        dv_df = dv_df.withColumn(
            "measurementSkus_array",
            F.from_json(F.col("measurementSkus"), "array<string>")
        )

        dv_df = dv_df.select(
            "jobBagId",
            F.explode(F.col("measurementSkus_array")).alias("measurementSkus"),
            "CAMPAIGN_START_DT",
            "CAMPAIGN_END_DT"
        )
    except Exception as e:
        print(f"Error during JSON array processing: {e}")
        # Fallback: treat measurementSkus as string if JSON parsing fails
        dv_df = dv_df.select(
            "jobBagId",
            "measurementSkus",
            "CAMPAIGN_START_DT",
            "CAMPAIGN_END_DT"
        )

    # Convert dates
    dv_df = dv_df.withColumn(
        "start_date", F.to_date(F.col("CAMPAIGN_START_DT"))
    ).withColumn(
        "end_date", F.to_date(F.col("CAMPAIGN_END_DT"))
    )

    # Filter out rows with null 'jobBagId'
    dv_df = dv_df.filter(F.col("jobBagId").isNotNull())

    # Filter for nectar campaigns only
    dv_df = dv_df.filter(F.col("jobBagId").rlike("^nec.*a$"))

    # Rename columns
    dv_df = dv_df.select(
        F.col("jobBagId").alias("JOBBAGID"),
        F.col("measurementSkus").alias("ITEM_CD"),
        F.col("start_date").alias("START_DT"),
        F.col("end_date").alias("END_DT")
    )

    # Add CHANNEL column
    dv_df = dv_df.withColumn("CHANNEL", F.lit("DV360"))

    # Drop nulls
    dv_df = dv_df.dropna()

    # Convert dates to string then back to datetime
    dv_df = dv_df.withColumn(
        "START_DT", F.col("START_DT").cast("string")
    ).withColumn(
        "END_DT", F.col("END_DT").cast("string")
    )

    # Convert start and end date to timestamp
    dv_df = dv_df.withColumn(
        "START_DT", F.to_timestamp(F.col("START_DT"))
    ).withColumn(
        "END_DT", F.to_timestamp(F.col("END_DT"))
    )

    # Drop duplicates and cast columns to required types - FIXED CASTING
    dv_df = dv_df.dropDuplicates().select(
        F.col("START_DT").alias("START_DT"),
        F.col("END_DT").alias("END_DT"),
        F.col("ITEM_CD").cast(StringType()).alias("ITEM_CD"),
        F.col("JOBBAGID").cast(StringType()).alias("JOBBAGID"),
        F.col("CHANNEL").cast(StringType()).alias("CHANNEL")
    )

    # Use custom method to write to s3 output
    spark_s3_overwrite(output_path, dv_df)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Normalise DV360 campaign data.")
    parser.add_argument(
        "--dv360-campaign",
        type=str,
        required=True,
        help="The input S3 path for the DV360 data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The path in S3 to output the normalised DV360 data."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    normalize_dv360(
        spark=spark,
        dv360_input_path=known_args.dv360_campaign,
        output_path=known_args.output_path,
        run_date=known_args.run_date,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("DV360Normalise").getOrCreate())
