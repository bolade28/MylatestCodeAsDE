from typing import List, Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite

# Also the doc string needs to be updated with more information including arguments and return values.
# Also this script also needs to be tested with unit tests. But this can be done in a separate PR - first priority is to comeplte the migration of the code from DBT to PySpark.


def normalize_dv360(
    spark: SparkSession,
    dv360_pollen_input_path: str,
    output_path: str,
    run_date: str,
) -> None:
    """This function normalizes DV360 campaign data following DBT logic exactly."""

    camp_io = (
        spark
        .read
        .parquet(dv360_pollen_input_path)
        .select(
            F.col("campaign_id"),
            F.col("booking_media_live_start_dt"),
            F.col("booking_media_live_end_dt"),
            F.col("booking_id"),
            F.col("sku_id"),
            F.col("channel_type"),
            F.col("media_provider"),
            F.col("booking_status"),
            F.col("media_business_group")
        )
        .filter(
            (F.upper(F.col('channel_type')) == "OFFSITE") & (F.upper(F.col('media_provider')) == "DV360") & (F.upper(F.col('booking_status')) == "COMPLETED") & (F.upper(F.col('media_business_group')).like("%SAINSBURY%")) & F.col('sku_id').isNotNull()
        )
    )
    camp_io = camp_io.withColumnRenamed("booking_media_live_start_dt", "start_dt")
    camp_io = camp_io.withColumnRenamed("booking_media_live_end_dt", "end_dt")
    camp_io = camp_io.withColumnRenamed("sku_id", "item_cd")
    dv360_normalize_null_drop = camp_io.na.drop()

    dv360_normalize_agg = (
        dv360_normalize_null_drop
        .groupBy(F.col('booking_id'), F.col('campaign_id'), F.col('item_cd'), F.col('end_dt'))
        .agg(F.max(F.col('start_dt')).alias('start_dt'))
    )

    dv360_normalize = (
        dv360_normalize_agg
        .filter((~F.col('end_dt').like("%9999%")) & (~F.col("campaign_id").like("~~")) & (~F.col("campaign_id").like("-1"))
                ).distinct()
    )

    dv360_normalize = dv360_normalize.withColumn('jobbagid', F.lit('NA'))
    dv360_normalize = dv360_normalize.withColumn('channel', F.lit('DV360'))

    dv360_normalize_final = (
        dv360_normalize
        .select(
            F.col("campaign_id"),
            F.col("start_dt"),
            F.col("end_dt"),
            F.col("item_cd"),
            F.col("booking_id"),
            F.col("jobbagid"),
            F.col("channel")
        )
    )

    # Use custom method to write to s3 destination output
    spark_s3_overwrite(output_path, dv360_normalize_final)


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Normalise DV360 campaign data.")
    parser.add_argument(
        "--dv360-pollen-campaign",
        type=str,
        required=True,
        help="The input S3 path for the DV360 data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The path in S3 to output the normalised DV360 data."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    normalize_dv360(
        spark=spark,
        dv360_pollen_input_path=known_args.dv360_pollen_campaign,
        output_path=known_args.output_path,
        run_date=known_args.run_date,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("DV360NormalisePollen").getOrCreate())
