from typing import List, Optional
from pyspark.sql import SparkSession, DataFrame
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import PipelineRunType
from spark_pipeline.user_journey.user_journey_helper import (
    build_user_journey_pollen,
    build_user_journey_dtp,
)
from spark_pipeline.utils.pipeline_utils import (
    load_parquet_dataset,
    validate_pipeline_run_type,
)
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_user_journey(
        spark: SparkSession,
        measurement_campaign_execution_path: str,
        customer_data_collection_path: str,
        output_path: str,
        product_type: str,
        journey_type: str,
        run_date: str,
        correlation_id: str,
        slack_topic_arn: str,
        pipeline_run_type: str,
        campaign_product_type_path: Optional[str] = None,
) -> DataFrame:

    validated_pipeline_run_type = validate_pipeline_run_type(pipeline_run_type)
    pipeline_run_type_config = PipelineRunType()

    customer_data_collection_columns: list[str] = [
        'loyalty_id', 'transaction_key', 'event_ts', 'channel_name',
        'subchannel_name', 'campaign_name', 'campaign_id', 'event_name', 'booking_id',
        'item_cd', 'product_type', 'net_sales_amt', 'units_qty', 'unique_brand_name',
        'marketing_type', 'load_ts', 'purchase_type'
    ]

    customer_data_collection_df = load_parquet_dataset(
        spark, customer_data_collection_path, "customer_data_collection", None,
        customer_data_collection_columns,
    )
    measurement_campaign_execution_df = load_parquet_dataset(
        spark, measurement_campaign_execution_path, "measurement_campaign_execution", None,
        ['booking_id', 'campaign_id', 'channel_name', 'subchannel_name', 'campaign_duration', 'job_status'],
    )

    if validated_pipeline_run_type == pipeline_run_type_config.pollen_run_type:
        user_journey_df = build_user_journey_pollen(
            measurement_campaign_execution_df=measurement_campaign_execution_df,
            customer_data_collection_df=customer_data_collection_df,
            product_type=product_type,
            journey_type=journey_type,
            slack_topic_arn=slack_topic_arn,
            correlation_id=correlation_id,
        )
    elif validated_pipeline_run_type == pipeline_run_type_config.dtp_run_type:
        if campaign_product_type_path is None:
            raise ValueError("campaign_product_type_path is required for DTP pipeline but was not provided")
        campaign_product_type_df = load_parquet_dataset(
            spark, campaign_product_type_path, "campaign_product_type", None,
            ['item_cd', 'product_type', 'channel_name', 'subchannel_name', 'booking_id', 'campaign_id', 'unique_brand_name'],
        )
        user_journey_df = build_user_journey_dtp(
            measurement_campaign_execution_df=measurement_campaign_execution_df,
            campaign_product_type_df=campaign_product_type_df,
            customer_data_collection_df=customer_data_collection_df,
            product_type=product_type,
            journey_type=journey_type,
            slack_topic_arn=slack_topic_arn,
            correlation_id=correlation_id,
        )
    else:
        raise ValueError(f"Unsupported pipeline_run_type: {validated_pipeline_run_type}")

    # Use custom method to write to s3 destination output
    spark_s3_overwrite(output_path, user_journey_df)

    return user_journey_df


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare User Journey Type.")

    parser.add_argument(
        "--measurement-campaign-execution-path",
        type=str,
        required=True,
        help="S3 path for measurement campaign execution data."
    )
    parser.add_argument(
        "--campaign-product-type-path",
        type=str,
        required=False,
        help="S3 path for campaign product type data."
    )
    parser.add_argument(
        "--customer-data-collection-path",
        type=str,
        required=True,
        help="S3 path for customer data collection data."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for output of user journey aisle."
    )
    parser.add_argument(
        "--product-type",
        type=str,
        required=True,
        help="Product type path to choose a specific product type whether its brand, aisle or offer."
    )
    parser.add_argument(
        "--journey-type",
        type=str,
        required=True,
        help="Journey path to choose a specific product type whether its brand, aisle or offer."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for traceability."
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN of the Slack topic for notifications."
    )
    parser.add_argument(
        "--pipeline-run-type",
        type=str,
        required=True,
        help="Pipeline run type: Pollen or DTP."
    )

    known_args, _ = parser.parse_known_args(command_line_args)
    validated_pipeline_run_type = validate_pipeline_run_type(known_args.pipeline_run_type)
    pipeline_run_type_config = PipelineRunType()

    if (validated_pipeline_run_type == pipeline_run_type_config.dtp_run_type
            and not known_args.campaign_product_type_path):
        parser.error("--campaign-product-type-path is required when --pipeline-run-type is DTP.")

    prepare_user_journey(
        spark=spark,
        measurement_campaign_execution_path=known_args.measurement_campaign_execution_path,
        campaign_product_type_path=known_args.campaign_product_type_path,
        customer_data_collection_path=known_args.customer_data_collection_path,
        output_path=known_args.output_path,
        product_type=known_args.product_type,
        journey_type=known_args.journey_type,
        run_date=known_args.run_date,
        correlation_id=known_args.correlation_id,
        pipeline_run_type=known_args.pipeline_run_type,
        slack_topic_arn=known_args.slack_topic_arn,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("UserJourney").getOrCreate())
