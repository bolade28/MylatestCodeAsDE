from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from pyspark.sql import functions as F  # noqa: F401
from spark_pipeline.common.variables import EventType, NUM_USER_JOURNEY_PARTITIONS, EventName
from spark_pipeline.schemas.user_journey import UserJourney
from spark_pipeline.user_journey.user_journey_utils import publish_user_journey_metrics
from spark_pipeline.utils.slack_utils import SlackMessenger
"""
    Objective -  The customer journey in the context of multi-touch attribution (MTA) involves tracking and analyzing customer interactions
    across all marketing channels—offsite, onsite, and instore—to understand how each touchpoint contributes to a customer's path
    to conversion. It involves collecting touchpoint and transaction data during campaigns to create customer journeys (Offer, Brand, Aisle)
    categorized into conversion/non-conversion journeys based on sales/no-sales.
    Confluence Link : https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/657653993/Customer+Journey+Creation
    Upstream: customer_data_collection
    Downstream: attribution_pre_requisite_offer, attribution_pre_requisite_brand, attribution_pre_requisite_aisle
    This script will return the query for the user journey creation for Offer, Brand & Aisle.
    The macro processes data from various tables to identify and aggregate user interactions, transactions, and touchpoints,
    ultimately creating a detailed user journey dataset.
    The query will be called from the user journey models and parameters will be passed to the macro

"""


def build_in_progress_campaigns(
    measurement_campaign_execution_df: DataFrame,
    product_type: str,
    slack_messenger: SlackMessenger,
) -> DataFrame:
    """Broadcast active campaign execution rows and notify Slack with the count."""
    in_progress_campaigns = (
        measurement_campaign_execution_df
        .select('booking_id', 'campaign_id', 'channel_name', 'subchannel_name', 'campaign_duration', 'job_status')
        .dropDuplicates()
    )
    in_progress_campaign_count = in_progress_campaigns.count()
    if in_progress_campaign_count == 0:
        message = f"no campaign found for {product_type} journey"
    else:
        message = f"{in_progress_campaign_count} in-progress campaign found for {product_type} journey"
    slack_messenger.send_message(
        event_type=EventType.user_journey,
        text="User Journey status",
        data={"Status Update": message}
    )
    return in_progress_campaigns


def build_user_journey_dtp(
        measurement_campaign_execution_df: DataFrame,
        campaign_product_type_df: DataFrame,
        customer_data_collection_df: DataFrame,
        product_type: str,
        journey_type: str,
        correlation_id: str,
        slack_topic_arn: str,
) -> DataFrame:

    slack_messenger = SlackMessenger(
        topic_arn=slack_topic_arn,
        correlation_id=correlation_id
    )

    """
        To get only the In-progress booking ids for campaign execution from the measurement_campaign_execution table
        to pick the data for the campaign on which we want to run the user journey analysis
        and later filter the data from customer data collection based on the booking id
    """

    in_progress_campaigns = F.broadcast(build_in_progress_campaigns(
        measurement_campaign_execution_df, product_type, slack_messenger
    ))

    """
        This ensures that only the SKUs relevant to specific marketing campaigns are selected,
        which will be used to filter the touchpoints and transactions for either Offer, Brand or Aisle
        TODO:: this might be unnecessary as we already have these details in customer data collection
    """
    get_targeted_skus = (
        campaign_product_type_df
        .select(
            'product_type',
            'unique_brand_name',
            'item_cd',
            'booking_id',
            'campaign_id',
            'channel_name',
            'subchannel_name'  # Needed for join
        )
        .distinct()
        # TODO:: consider broadcast for future as this might be an always small table
        .join(in_progress_campaigns,
              on=['campaign_id', 'channel_name', 'subchannel_name'],
              how='inner')
        .select(
            'product_type',
            'unique_brand_name',
            'item_cd',
            campaign_product_type_df['booking_id'],
            'campaign_id',
            'channel_name'
        )
        .filter(F.lower(F.col('product_type')) == F.lower(F.lit(product_type)))
        .distinct()
    )
    get_targeted_skus = F.broadcast(get_targeted_skus)

    # Get the max load_ts per product_type for records with booking_ids from active campaigns.
    # Grouping by product_type ensures Offer and Brand rows each use their own latest batch,
    # preventing a newer Brand delivery from dropping older-but-valid Offer rows (and vice versa).
    max_load_ts_df = (
        customer_data_collection_df
        .join(in_progress_campaigns.select('booking_id').distinct(),
              on='booking_id',
              how='inner')
        .groupBy('product_type')
        .agg(F.max('load_ts').alias('max_load_ts'))
    )

    """
        This CTE extracts detailed customer interaction data related to specific marketing campaigns.
        It filters records from the customer_data_collection table to include only those with booking_ids that match the
        campaign booking IDs values which are identified in the campaign_booking_id CTE
    """
    campaign_customer_data = (
        customer_data_collection_df
        .join(in_progress_campaigns.select('booking_id').distinct(),
              on='booking_id',
              how='inner')
        .join(max_load_ts_df,
              on='product_type',
              how='inner')
        .filter(F.col('load_ts') == F.col('max_load_ts'))
        .drop('max_load_ts')
        .select(
            'loyalty_id',
            'transaction_key',
            'event_ts',
            'channel_name',
            'subchannel_name',
            'campaign_name',
            'campaign_id',
            'event_name',
            'booking_id',
            'item_cd',
            'product_type',
            'net_sales_amt',
            'units_qty',
            'unique_brand_name',
            'marketing_type',
            'purchase_type'
        )
        .cache()
    )

    """
        This CTE ensures that each transaction is linked to the relevant campaign IDs,
        providing a comprehensive view of which campaigns influenced specific transactions.
        Also, to aggregate the campaign ids as we may have same transactions done via different channels which have different
        campaign ids
    """
    # Transaction rows have campaign_id='' in the new CDC (purchase_type stores the original
    # channel). Collect the real campaign_ids from touchpoint rows for the same booking_id
    # and join them to the purchase transactions.
    get_transaction_campaign_id = (
        campaign_customer_data
        .filter(
            (F.col('transaction_key') != 'NA') &
            (F.col('event_name') == EventName.TOUCHPOINT.value)
        )
        .groupBy('transaction_key', 'booking_id')
        .agg(
            F.expr("concat_ws(',', sort_array(collect_list(distinct campaign_id))) as campaign_id")
        )
    )

    """
        To retrieve only the transactions for passed product type and summarize the unit quantity
        and sales amount later, to have only one transaction row for every journey or transactions
    """
    get_distinct_customer_transaction_data = (
        campaign_customer_data
        .filter((F.lower(F.col('product_type')) == F.lower(F.lit(product_type))) &
                (F.col('event_name') == EventName.TRANSACTION.value))
        .select(
            'loyalty_id',
            'transaction_key',
            'event_ts',
            'marketing_type',
            'channel_name',
            'subchannel_name',
            'purchase_type',
            'item_cd',
            'event_name',
            'booking_id',
            'net_sales_amt',
            'units_qty'
        )
        .dropDuplicates()
        .cache()
    )

    """
        It joins the get_distinct_customer_transaction_data CTE with the get_targeted_skus
        CTE on product-related columns to ensure that only transactions involving the targeted SKUs are included.
    """
    get_specific_product_type_transaction = (
        get_transaction_campaign_id
        .join(
            get_distinct_customer_transaction_data,
            on=['transaction_key', 'booking_id'],
            how='inner'
        )
        .groupBy(
            'loyalty_id',
            'transaction_key',
            'event_ts',
            'marketing_type',
            'channel_name',
            'subchannel_name',
            'event_name',
            'booking_id',
            'campaign_id',
            'purchase_type'
        )
        .agg(
            F.sum('net_sales_amt').alias('net_sales_amt'),
            F.sum('units_qty').alias('units_qty')
        )
    )
    """
        To get only the relevant touchpoints associated with passed product type transactions
    """
    get_specific_product_type_touchpoints = (
        campaign_customer_data
        .select('loyalty_id', 'transaction_key', 'event_ts', 'marketing_type',
                'channel_name', 'subchannel_name', 'event_name', 'booking_id', 'campaign_id')
        .join(
            get_distinct_customer_transaction_data.select('transaction_key', 'item_cd'),
            on='transaction_key',
            how='inner')
        .join(
            get_targeted_skus.select('booking_id', 'campaign_id', 'channel_name', 'item_cd', 'product_type'),
            on=['booking_id', 'campaign_id', 'channel_name', 'item_cd'],
            how='inner')
        .filter(
            (F.col('event_name') == EventName.TOUCHPOINT.value) &
            (F.lower(F.col('product_type')) == F.lower(F.lit(product_type)))
        )
        .select(
            'loyalty_id',
            'transaction_key',
            'event_ts',
            'marketing_type',
            'channel_name',
            'subchannel_name',
            'event_name',
            'booking_id',
            'campaign_id',
            F.lit('').alias('purchase_type'),
            F.lit(0.00).alias('net_sales_amt'),
            F.lit(0.00).alias('units_qty')
        )
        .distinct()
    )
    if get_specific_product_type_touchpoints.isEmpty():
        message = f"No touchpoints found for product type {product_type} associated with passed product type transactions"
        slack_messenger.send_message(
            event_type=EventType.user_journey,
            text="User Journey status",
            data={"Status Update": message}
        )

    specific_transaction_keys = (
        get_specific_product_type_transaction
        .select('transaction_key', 'booking_id')
        .dropDuplicates()
    )

    """
        To retrieves touchpoint data for customers who did not purchase the specified product type
    """
    get_other_touchpoint_data = (
        campaign_customer_data
        .join(
            specific_transaction_keys,
            on=['transaction_key', 'booking_id'],
            how='left_anti'
        )
        .filter(F.col('event_name') == EventName.TOUCHPOINT.value)
        .select(
            'loyalty_id',
            F.lit('NA').alias('transaction_key'),
            'event_ts',
            'marketing_type',
            'channel_name',
            'subchannel_name',
            'event_name',
            'booking_id',
            'campaign_id',
            F.lit('').alias('purchase_type'),
            F.lit(0.00).alias('net_sales_amt'),
            F.lit(0.00).alias('units_qty')
        )
        .distinct()
    )
    if get_other_touchpoint_data.limit(1).count() == 0:
        message = f"No touchpoints found for product type {product_type} for customers who did not purchase the specified product type"
        slack_messenger.send_message(
            event_type=EventType.user_journey,
            text="User Journey status",
            data={"Status Update": message}
        )

    """
        This ensures that both types of data—transactions involving the specified product type
        and other relevant touchpoints—are included in the final dataset.
    """
    union_data = (
        get_specific_product_type_transaction
        .union(get_specific_product_type_touchpoints)
        .union(get_other_touchpoint_data)
    )
    dedup_window = Window.partitionBy(
        'loyalty_id',
        'transaction_key',
        'event_ts',
        'channel_name',
        'subchannel_name',
        'event_name',
        'booking_id',
        'campaign_id'
    ).orderBy(
        F.when(F.col('marketing_type') == 'NA', 0).otherwise(1)
    )

    # Add a row number, prioritizing marketing_type == 'NA'
    union_data_dedup = (
        union_data
        .withColumn('row_num', F.row_number().over(dedup_window))
        .filter(F.col('row_num') == 1)
        .drop('row_num')
    )

    user_journey = structure_events_into_user_journey(
        union_data_dedup,
        in_progress_campaigns,
        journey_type,
        correlation_id,
        single_journey_per_customer=False,
        isconversion_partition_cols=['booking_id', 'userjourney_id'],
    )
    final_user_journey = finalise_user_journey(user_journey, product_type, journey_type, slack_messenger)
    campaign_customer_data.unpersist(blocking=False)
    get_distinct_customer_transaction_data.unpersist(blocking=False)
    return final_user_journey


def structure_events_into_user_journey(
    df: DataFrame,
    in_progress_campaigns: DataFrame,
    journey_type: str,
    correlation_id: str,
    single_journey_per_customer: bool,
    isconversion_partition_cols: list[str],
) -> DataFrame:
    """Assign sub_path, userjourney_id, rank, position, and isconversion; then assemble the final user_journey DataFrame.

    Shared by both DTP and Pollen. The two behavioural differences are controlled via parameters:

    Args:
        single_journey_per_customer: When True (Pollen), sub_path is fixed at 1 — one journey per loyalty_id.
            When False (DTP), sub_path is dense_rank over transaction_key within (booking_id, loyalty_id),
            producing one sub-journey per distinct conversion.
        isconversion_partition_cols: Window partition columns for the isconversion flag.
            DTP uses ['booking_id', 'userjourney_id']; Pollen uses ['loyalty_id', 'booking_id'].
    """
    if single_journey_per_customer:
        with_sub_path = (
            df
            .withColumn('sub_path', F.lit(1))
            .withColumn('userjourney_id', F.concat_ws('_', F.col('loyalty_id'), F.lit(1)))
        )
    else:
        sub_path_window = Window.partitionBy('booking_id', 'loyalty_id').orderBy('transaction_key')
        with_sub_path = (
            df
            .withColumn('sub_path', F.dense_rank().over(sub_path_window))
            .withColumn('userjourney_id', F.concat_ws('_', F.col('loyalty_id'), F.col('sub_path')))
        )

    with_rank = (
        with_sub_path
        .withColumn(
            'rank',
            F.row_number().over(
                Window
                .partitionBy('booking_id', 'loyalty_id', 'sub_path')
                .orderBy(
                    F.col('event_ts').asc(),
                    F.col('campaign_id').asc(),
                    F.col('event_name').desc(),
                )
            )
        )
    )

    with_position = (
        with_rank
        .withColumn(
            'position',
            F.when(F.col('rank') == 1, 'Initiator')
            .when(F.col('event_name') == EventName.TRANSACTION.value, 'Convertor')
            .otherwise('Assistor')
        )
        .withColumn(
            'isconversion',
            F.max(
                F.when(F.col('event_name') == EventName.TRANSACTION.value, 1).otherwise(0)
            ).over(Window.partitionBy(*isconversion_partition_cols))
        )
    )

    user_journey_assembled_df = (
        with_position
        .join(in_progress_campaigns.select('booking_id', 'campaign_duration'), on='booking_id', how='inner')
        .select(
            'loyalty_id',
            'transaction_key',
            'event_ts',
            'channel_name',
            'subchannel_name',
            'event_name',
            'booking_id',
            'campaign_id',
            'sub_path',
            'userjourney_id',
            'rank',
            'position',
            'isconversion',
            'marketing_type',
            'net_sales_amt',
            'units_qty',
            'campaign_duration',
            'purchase_type',
        )
        .withColumn('journey_type', F.lit(journey_type))
        .withColumn('job_run_id', F.lit(correlation_id))
        .withColumn('load_ts', F.current_timestamp())
        .distinct()
    )
    return user_journey_assembled_df


def validate_converted_customers_have_touchpoints(user_journey_df: DataFrame) -> None:
    """Raise if any converted customer has no touchpoint row.

    A transaction with no preceding touchpoint indicates a CDC data defect and
    should never reach this point in production.
    """
    converted_without_touchpoint = (
        user_journey_df
        .filter(F.col("isconversion") == 1)
        .groupBy("loyalty_id", "booking_id", "userjourney_id")
        .agg(
            F.sum(
                F.when(F.col("event_name") == EventName.TOUCHPOINT.value, 1).otherwise(0)
            ).alias("touchpoint_count")
        )
        .filter(F.col("touchpoint_count") == 0)
    )
    if converted_without_touchpoint.limit(1).count() > 0:
        bad_rows = converted_without_touchpoint.limit(10).collect()
        details = ", ".join(
            f"loyalty_id={r.loyalty_id} booking_id={r.booking_id} userjourney_id={r.userjourney_id}"
            for r in bad_rows
        )
        raise ValueError(
            f"Data quality error: converted customers with no touchpoint detected — "
            f"indicates a CDC defect. Affected journeys (up to 10): {details}"
        )


def finalise_user_journey(
    user_journey: DataFrame,
    product_type: str,
    journey_type: str,
    slack_messenger: SlackMessenger,
) -> DataFrame:
    """
    Shared finalisation: cast all columns to the expected schema, repartition,
    cache, and publish metrics. Called independently by both DTP and Pollen paths.
    """
    final_user_journey = user_journey.select(
        [
            F.col(field.name).cast(field.dataType)
            for field in UserJourney.UserJourneySchema.fields
        ]
    )
    final_user_journey_optimized = (
        final_user_journey
        .repartition(NUM_USER_JOURNEY_PARTITIONS)
        .cache()
    )

    validate_converted_customers_have_touchpoints(final_user_journey_optimized)

    slack_messenger.send_message(
        event_type=EventType.user_journey,
        text=f"User journeys generated for {product_type}",
        data={"Rows Updated": final_user_journey_optimized.count()}
    )
    publish_user_journey_metrics(final_user_journey_optimized, journey_type, slack_messenger)
    return final_user_journey_optimized


def get_latest_campaign_customer_data(
    customer_data_collection_df: DataFrame,
    in_progress_campaigns: DataFrame,
    product_type: str,
) -> DataFrame:
    """Filter customer data to the latest load batch per product_type for active campaign booking IDs."""
    max_load_ts_df = (
        customer_data_collection_df
        .join(in_progress_campaigns.select('booking_id').distinct(), on='booking_id', how='inner')
        .groupBy('product_type')
        .agg(F.max('load_ts').alias('max_load_ts'))
    )
    latest_campaign_customer_data_df = (
        customer_data_collection_df
        .join(in_progress_campaigns.select('booking_id').distinct(), on='booking_id', how='inner')
        .join(max_load_ts_df, on='product_type', how='inner')
        .filter(F.col('load_ts') == F.col('max_load_ts'))
        .drop('max_load_ts')
        .filter(
            # Touchpoints carry product_type = 'NA' or null — keep all of them.
            # Only purchases have SKU-level product_type, so filter those by product_type.
            (F.col('event_name') == EventName.TOUCHPOINT.value) |
            (F.lower(F.col('product_type')) == F.lower(F.lit(product_type)))
        )
        .select(
            'loyalty_id',
            'transaction_key',
            'event_ts',
            'channel_name',
            'subchannel_name',
            'campaign_id',
            'event_name',
            'booking_id',
            'item_cd',  # kept so dedup can distinguish items with identical price/qty; dropped after dedup
            'product_type',  # kept so drop_touchpoints_after_last_conversion can scope cutoff to this product type
            'marketing_type',
            'net_sales_amt',
            'units_qty',
            'purchase_type',
        )
        .cache()
    )
    return latest_campaign_customer_data_df


def drop_touchpoints_after_last_conversion(df: DataFrame, product_type: str) -> DataFrame:
    """Drop touchpoints occurring after a customer's last Purchase Transaction for the given product_type.

    The trim is intentionally scoped to loyalty_id only, not (loyalty_id, booking_id).
    Pollen treats a customer as a single unified journey across all active campaigns —
    once they convert anywhere, they are a converted customer and trailing touchpoints
    from any campaign are irrelevant.

    Only purchases matching product_type are used as the cutoff so that, e.g., a brand
    purchase does not incorrectly trim offer touchpoints that preceded an offer purchase.
    """
    last_conversion_df = (
        df
        .filter(
            (F.col('event_name') == EventName.TRANSACTION.value) &
            (F.lower(F.col('product_type')) == product_type.lower())
        )
        .groupBy('loyalty_id')
        .agg(F.max('event_ts').alias('last_conversion_ts'))
    )
    filtered_df = (
        df
        .join(F.broadcast(last_conversion_df), on='loyalty_id', how='left')
        .filter(
            F.col('last_conversion_ts').isNull() |
            (F.col('event_ts') <= F.col('last_conversion_ts'))
        )
        .drop('last_conversion_ts')
    )
    return filtered_df


def build_user_journey_pollen(
    measurement_campaign_execution_df: DataFrame,
    customer_data_collection_df: DataFrame,
    product_type: str,
    journey_type: str,
    correlation_id: str,
    slack_topic_arn: str,
) -> DataFrame:
    """
    Pollen user journey: single chronological journey per loyalty_id.

    Key differences from DTP:
    - No three-way union (transaction / specific touchpoints / other touchpoints)
    - No campaign_product_type_df: product_type is already present in CDC
    - sub_path is always 1 — one journey per loyalty_id
    - Post-conversion events are trimmed here (per loyalty_id, drop anything after last Purchase Transaction)
    - isconversion partitioned over (loyalty_id, booking_id), not userjourney_id
    """
    slack_messenger = SlackMessenger(topic_arn=slack_topic_arn, correlation_id=correlation_id)

    in_progress_campaigns = F.broadcast(build_in_progress_campaigns(
        measurement_campaign_execution_df, product_type, slack_messenger
    ))

    campaign_customer_data = get_latest_campaign_customer_data(
        customer_data_collection_df, in_progress_campaigns, product_type
    )

    campaign_customer_data = drop_touchpoints_after_last_conversion(campaign_customer_data, product_type)
    # campaign_id and marketing_type are already blanked on Purchase Transaction rows in the CDC step,
    # so .distinct() collapses duplicate purchase rows that arose from multi-campaign attribution.
    campaign_customer_data = campaign_customer_data.distinct()

    # Sum sales across items per transaction before dropping item_cd.
    # Keep grouping keys explicit so schema changes upstream cannot silently alter aggregation behaviour.
    groupby_cols = [
        'loyalty_id',
        'transaction_key',
        'event_ts',
        'channel_name',
        'subchannel_name',
        'campaign_id',
        'event_name',
        'booking_id',
        'marketing_type',
        'purchase_type',
    ]
    campaign_customer_data = (
        campaign_customer_data
        .groupBy(*groupby_cols)
        .agg(
            F.sum('net_sales_amt').alias('net_sales_amt'),
            F.sum('units_qty').alias('units_qty'),
        )
    )

    campaign_customer_data = campaign_customer_data.withColumn(
        'transaction_key',
        F.when(F.col('event_name') == EventName.TOUCHPOINT.value, F.lit('NA')).otherwise(F.col('transaction_key'))
    ).distinct()

    user_journey = structure_events_into_user_journey(
        campaign_customer_data,
        in_progress_campaigns,
        journey_type,
        correlation_id,
        single_journey_per_customer=True,
        isconversion_partition_cols=['loyalty_id', 'booking_id'],
    )

    return finalise_user_journey(user_journey, product_type, journey_type, slack_messenger)
