from prettytable import PrettyTable
from pyspark.sql import DataFrame
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.common.variables import EventType


def publish_user_journey_metrics(
        user_journey_df: DataFrame,
        journey_type: str,
        slack_messenger: SlackMessenger
) -> None:
    """ Publishes the total number of refactored SKUs to Slack for this run.
    Args:
        refactoring_df (DataFrame): DataFrame containing the refactoring output,
                                    with one row per refactored SKU.
        slack_messenger (SlackMessenger): The messenger instance to send the message.
    """

    # Calculate the total number of refactored SKUs
    distinct_channels = (
        user_journey_df
        .select(
            "channel_name",
            "subchannel_name",
        )
        .distinct()
        .collect()
    )

    # Create and format the output table
    table = PrettyTable()
    table.field_names = [
        "channel_name",
        "subchannel_name",
    ]
    for row in distinct_channels:
        table.add_row([
            row.channel_name,
            row.subchannel_name
        ])

    # Send the formatted message to Slack
    slack_messenger.send_message(
        event_type=EventType.user_journey,
        text=f"User journey metrics for {journey_type}:",
        data={"Metrics Summary": f"```\n{table}\n```"},
    )
