from typing import List, Optional
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from pyspark.sql import SparkSession, DataFrame, functions as F
from spark_pipeline.common.variables import PipelineRunType
from spark_pipeline.schemas.customer_data_collection import CustomerDataCollection
from spark_pipeline.utils.pipeline_utils import load_parquet_dataset
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def create_empty_customer_data_collection_df(spark: SparkSession):
    """Create an empty DataFrame with customer data schema."""

    return spark.createDataFrame([], CustomerDataCollection.schema)


def get_filtered_campaign_execution(
    spark: SparkSession,
    measurement_campaign_execution_path: str,
    run_type: str,
    measurement_marketing_channel_hierarchy_path: Optional[str],
) -> DataFrame:
    """
    Load measurement_campaign_execution and apply hierarchy filtering for Pollen.
    DTP returns all campaigns unfiltered.
    """
    CAMPAIGN_EXECUTION_COLUMNS = [
        'campaign_id',
        'booking_id',
        'job_bag_number',
        'marketing_type',
        'channel_name',
        'subchannel_name',
        'campaign_name',
        'campaign_start_dt',
        'campaign_end_dt',
        'campaign_duration',
        'job_status',
        'load_ts',
        'job_run_id',
        'overlapping_campaign_flag',
        'marketing_hierarchy_cd'
    ]

    campaign_measurement_execution_df = load_parquet_dataset(
        spark, measurement_campaign_execution_path, "campaign_measurement_execution",
        None, CAMPAIGN_EXECUTION_COLUMNS
    )

    is_pollen = run_type.lower() == PipelineRunType.pollen_run_type.lower()

    if not is_pollen:
        return campaign_measurement_execution_df

    if measurement_marketing_channel_hierarchy_path is None:
        raise ValueError(
            "measurement_marketing_channel_hierarchy_path is required for Pollen pipeline but was not provided"
        )

    channel_hierarchy_code_df = load_parquet_dataset(
        spark, measurement_marketing_channel_hierarchy_path, "channel_hierarchy",
        None, ['marketing_hierarchy_cd']
    )
    campaign_measurement_execution_df = (
        campaign_measurement_execution_df
        .join(channel_hierarchy_code_df, on="marketing_hierarchy_cd", how='inner')
    )
    return campaign_measurement_execution_df


def apply_date_window_filter(
    all_channel_data_df: DataFrame,
    filtered_campaign_execution_df: DataFrame,
) -> DataFrame:
    """
    Shared helper: filter the unified channel data to the date window of
    non-overlapping campaigns. Called independently by both DTP and Pollen paths.
    """
    non_overlapping_df = filtered_campaign_execution_df.filter(~F.col('overlapping_campaign_flag'))

    campaign_date_window_df = (
        non_overlapping_df
        .agg(
            F.min('campaign_start_dt').alias('min_campaign_start_dt'),
            F.max('campaign_end_dt').alias('max_campaign_end_dt')
        )
    )

    filtered_df = (
        all_channel_data_df
        .join(campaign_date_window_df, how='cross')
        .filter(
            (F.to_date(F.col('event_ts')) >= F.col('min_campaign_start_dt')) &
            (F.to_date(F.col('event_ts')) <= F.col('max_campaign_end_dt'))
        )
        .select(
            'loyalty_id',
            'transaction_key',
            'event_dt',
            'event_ts',
            'marketing_type',
            'channel_name',
            'subchannel_name',
            'campaign_name',
            'campaign_id',
            'event_name',
            'purchase_type',
            'booking_id',
            'load_ts',
            'item_cd',
            'product_type',
            'unique_brand_name',
            'net_sales_amt',
            'units_qty',
            'job_run_id'
        )
    )
    return filtered_df


def validate_offer_surpassed_brand_flag(customer_data_collection_df: DataFrame) -> None:
    """
    Validate Offer vs Brand sales per campaign.

    Purpose:
    - This function performs a critical data quality check to ensure that for each campaign, the total sales amount for "Offer" products does not exceed that of "Brand" products.

    Raises:
        ValueError: If any campaigns have offer_sales > brand_sales. Includes failing
            campaign IDs in the error message to aid production triage.
    """

    violations_df = (
        customer_data_collection_df
        .groupBy("campaign_id")
        .agg(
            F.sum(F.when(F.lower(F.col("product_type")) == "offer", F.col("net_sales_amt")).otherwise(0)).alias("offer_sales"),
            F.sum(F.when(F.lower(F.col("product_type")) == "brand", F.col("net_sales_amt")).otherwise(0)).alias("brand_sales"),
            F.count(F.when(F.lower(F.col("product_type")) == "offer", True)).alias("offer_row_count"),
            F.count(F.when(F.lower(F.col("product_type")) == "brand", True)).alias("brand_row_count"),
        )
        .filter(
            (F.col("offer_row_count") > 0) &
            (F.col("brand_row_count") > 0) &
            (F.col("offer_sales") > F.col("brand_sales"))
        )
    )

    failing_campaigns = violations_df.select("campaign_id").distinct().collect()

    if failing_campaigns:
        campaign_ids = [row["campaign_id"] for row in failing_campaigns]
        raise ValueError(
            f"Data quality check failed: Offer sales exceed Brand sales for campaigns: {campaign_ids}. ")


def prepare_customer_data_collection(
    spark: SparkSession,
    youtube_data: str,
    dv360_data: str,
    citrus_data: str,
    instore_data: str,
    meta_data: str,
    magazine_data: str,
    ecoupon_data: str,
    coupon_at_till_data: str,
    measurement_campaign_execution_path: str,
    output_path: str,
    run_date: str,
    correlation_id: str,
    slack_topic_arn: str,
    run_type: str = PipelineRunType.dtp_run_type,
    measurement_marketing_channel_hierarchy_path: Optional[str] = None
) -> DataFrame:
    """
    * Objective:
    - Collect all customer touchpoint data from all the channels and concatenate them into a unified dataset.

    """
    CDC_COLUMNS = [
        'loyalty_id',
        'transaction_key',
        'event_dt',
        'event_ts',
        'marketing_type',
        'channel_name',
        'subchannel_name',
        'campaign_name',
        'campaign_id',
        'purchase_type',
        'event_name',
        'booking_id',
        'load_ts',
        'item_cd',
        'product_type',
        'unique_brand_name',
        'net_sales_amt',
        'units_qty',
        'job_run_id',
    ]
    # read all customer data from different channels.
    DATASET_PATHS = {
        'youtube': youtube_data,
        'dv360': dv360_data,
        'citrus': citrus_data,
        'instore': instore_data,
        'meta': meta_data,
        'magazine': magazine_data,
        'ecoupon': ecoupon_data,
        'coupon_at_till': coupon_at_till_data,
    }
    channel_data_dfs = [
        load_parquet_dataset(
            spark=spark,
            path=path,
            dataset_name=name,
            slack_notifier=None,
            columns=CDC_COLUMNS,
            fallback_schema=CustomerDataCollection.schema,
        )
        for name, path in DATASET_PATHS.items()
    ]

    all_channel_data_df = channel_data_dfs[0]
    for channel_data_df in channel_data_dfs[1:]:
        all_channel_data_df = all_channel_data_df.unionByName(channel_data_df)

    all_channel_data_df = (
        all_channel_data_df
        .withColumn('load_ts', F.lit(run_date))
        .select(CDC_COLUMNS)
    ).cache()
    if all_channel_data_df.limit(1).count() == 0:
        raise ValueError("No customer data found. Need investigation in upstream data sources.")

    filtered_campaign_execution_df = get_filtered_campaign_execution(
        spark=spark,
        measurement_campaign_execution_path=measurement_campaign_execution_path,
        run_type=run_type,
        measurement_marketing_channel_hierarchy_path=measurement_marketing_channel_hierarchy_path,
    ).cache()

    customer_data_collection_df = apply_date_window_filter(
        all_channel_data_df, filtered_campaign_execution_df
    )

    # [DATA VALIDATION] Perform the Offer vs Brand sales data quality check and write output data if it passes.
    validate_offer_surpassed_brand_flag(customer_data_collection_df)

    # TODO: this is a crucial dataset so we also need to publish some key metrics to monitoring service
    # that will go here
    spark_s3_overwrite(output_path, customer_data_collection_df)
    return customer_data_collection_df


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare processed data for Coupon at till in baseline pipeline.")
    parser.add_argument(
        "--youtube-data",
        type=str,
        required=True,
        help="The S3 path for the youtube data."
    )
    parser.add_argument(
        "--dv360-data",
        type=str,
        required=True,
        help="The S3 path for the DV360 customer data."
    )
    parser.add_argument(
        "--citrus-data",
        type=str,
        required=True,
        help="The S3 path for the citrus data."
    )
    parser.add_argument(
        "--instore-data",
        type=str,
        required=True,
        help="The S3 path for the instore data."
    )
    parser.add_argument(
        "--meta-data",
        type=str,
        required=True,
        help="The S3 path for the meta customer data."
    )
    parser.add_argument(
        "--magazine-data",
        type=str,
        required=True,
        help="The S3 path for the magazine customer data."
    )
    parser.add_argument(
        "--ecoupon-data",
        type=str,
        required=True,
        help="The S3 path for the ecoupon customer data."
    )
    parser.add_argument(
        "--coupon-at-till-data",
        type=str,
        required=True,
        help="The S3 path for the coupon at till data."
    )
    parser.add_argument(
        "--measurement-campaign-execution-path",
        type=str,
        required=True,
        help="S3 path for measurement campaign execution data."
    )
    parser.add_argument(
        "--measurement-marketing-channel-hierarchy-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for measurement marketing channel hierarchy data (required for Pollen pipeline only)."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="The S3 path for the output data."
    )
    parser.add_argument(
        "--run-type",
        type=str,
        required=True,
        help="Pipeline run type: Pollen or DTP."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD format."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Unique identifier for the DAG run."
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN of the Slack topic for notifications."
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    prepare_customer_data_collection(
        spark=spark,
        youtube_data=known_args.youtube_data,
        dv360_data=known_args.dv360_data,
        citrus_data=known_args.citrus_data,
        instore_data=known_args.instore_data,
        meta_data=known_args.meta_data,
        magazine_data=known_args.magazine_data,
        ecoupon_data=known_args.ecoupon_data,
        coupon_at_till_data=known_args.coupon_at_till_data,
        measurement_campaign_execution_path=known_args.measurement_campaign_execution_path,
        output_path=known_args.output_path,
        run_date=known_args.run_date,
        slack_topic_arn=known_args.slack_topic_arn,
        correlation_id=known_args.correlation_id,
        run_type=known_args.run_type,
        measurement_marketing_channel_hierarchy_path=known_args.measurement_marketing_channel_hierarchy_path,
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("CustomerDataCollection").getOrCreate())



