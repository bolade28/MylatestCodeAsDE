from pyspark.sql import functions as F, types as T, DataFrame
from pyspark.sql.window import Window
from typing import Optional
import json
from pyspark.sql import SparkSession
from spark_pipeline.common.variables import CampaignDurations, PipelineRunType, MarketingTypes, ProductType, DTP_OFFSITE_CHANNELS, META_AA_EFFECTIVE_DATE, META_STATIC_RECALIBRATION_FACTOR, MODELLING_WEIGHT_ZERO_TOLERANCE, EventName
from spark_pipeline.sku_level_attribution.slack_notification import SKUAttributionValidationNotifier
from spark_pipeline.schemas.sku_level_attribution import SkuLevelAttributedSalesAndUnits
from spark_pipeline.utils.stdout_logger import StdOutLogger

logger = StdOutLogger()

"""
Objective:
This script computes SKU-level attributed sales and units for marketing campaigns,
with specialized recalibration for off-site channels. The system integrates attribution
model results by mapping transaction keys to attribution weights, enabling precise
measurement of campaign impact at the individual product level.

Core Functionality:
• Calculates attributed sales and units directly linked to marketing campaigns
• Applies recalibration factors for off-site channels to align attributed metrics
  with actual DTP (Data Transfer Platform) sales
• Addresses measurement challenges in channels like Meta where exact audience
  exposure is unknown, preventing attribution inflation
• Stores processed results in downstream tables for analytics and reporting

Technical Approach:
The script leverages transaction-level mapping to apply attribution weights from
the model results table to SKU-level purchase data. For off-site channels, it
implements a recalibration methodology that scales attributed sales back to
observed DTP performance, ensuring measurement accuracy despite incomplete
audience visibility.

Key Performance Indicators (KPIs):
• Attributed Sales: Revenue directly linked to marketing campaign exposure
• Attributed Units: Product quantities directly linked to marketing campaign exposure
• Recalibrated Sales: Revenue figures adjusted using DTP-based scaling factors
• Recalibrated Units: Unit quantities adjusted using DTP-based scaling factors

Dependencies - Staging Functions:
• calculate_aggregated_sales(): Aggregates transaction data at SKU level
• calculate_recalibrated_sales(): Applies channel-specific recalibration logic
• get_campaign_start_end_date(): Retrieves campaign temporal boundaries

Confluence Link:
https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/852531012/SKU+Level+Attributed+Sales+and+Attributed+Units+Calculations

"""


def check_zero_modelling_weight(df):
    """
    Raises value error when modelling weight value is close to zero.
    """
    tolerance = MODELLING_WEIGHT_ZERO_TOLERANCE
    invalid_df = df.filter(F.abs(F.col("modelling_weight")) < tolerance)
    if not invalid_df.isEmpty():
        invalid_count = invalid_df.agg(F.count("*").alias("cnt")).first()[0]
        raise ValueError(
            f"Data quality check failed: {invalid_count} rows have modelling_weight close to zero."
        )
    return df


def get_subchannels_from_hierarchy(
        channel_hierarchy_code_df: Optional[DataFrame],
        output_column: str,
        offsite_only: bool = False,
        subchannel_hierarchy_json: Optional[str] = None,
        hierarchy_codes_key: Optional[str] = None) -> Optional[DataFrame]:
    """Resolves hierarchy subchannels with optional offsite and code-based filters.

    Args:
        channel_hierarchy_code_df: Hierarchy reference data.
        output_column: Name of the output subchannel column.
        offsite_only: When True, keep only offsite channel_type rows.
        subchannel_hierarchy_json: Optional JSON code map (e.g. {"meta": [1,2]}).
        hierarchy_codes_key: Optional JSON key to extract hierarchy codes from.

    Returns:
        Optional[DataFrame]: Distinct lowercase subchannels in output_column.
            Returns None when hierarchy DataFrame is missing or when a requested
            hierarchy_codes_key has no codes.
    """
    if channel_hierarchy_code_df is None:
        return None

    hierarchy_df = channel_hierarchy_code_df

    if offsite_only:
        hierarchy_df = hierarchy_df.filter(
            F.lower(F.col('channel_type')) == F.lit(MarketingTypes.OFFSITE)
        )

    if hierarchy_codes_key is not None:
        if not subchannel_hierarchy_json:
            return None
        subchannel_codes = json.loads(subchannel_hierarchy_json)
        hierarchy_codes = subchannel_codes.get(hierarchy_codes_key, [])
        if not hierarchy_codes:
            return None
        hierarchy_codes = hierarchy_codes if isinstance(hierarchy_codes, list) else [hierarchy_codes]
        hierarchy_df = hierarchy_df.filter(F.col('marketing_hierarchy_cd').isin(hierarchy_codes))

    return (
        hierarchy_df
        .select(F.lower(F.col('marketing_subchannel')).alias(output_column))
        .filter(F.col(output_column).isNotNull())
        .distinct()
    )


def add_offsite_channel_flag(
        df: DataFrame,
        offsite_subchannel_df: DataFrame,
        source_column: str) -> DataFrame:
    """Adds a boolean offsite flag using a broadcast left join."""
    return (
        df
        .join(
            F.broadcast(offsite_subchannel_df),
            F.lower(F.col(source_column)) == F.lower(F.col('offsite_key')),
            how='left',
        )
        .withColumn('is_offsite_channel', F.col('offsite_key').isNotNull())
        .drop('offsite_key')
    )


def get_campaign_start_end_date(measurement_campaign_execution_df: DataFrame):
    """
    Retrieves the start and end dates of a campaign based on the booking ID.
    """
    window_spec = Window.partitionBy('channel_name', 'booking_id', 'campaign_duration')

    unified_campaign_df = (
        measurement_campaign_execution_df
        .withColumn('campaign_start_dt', F.min('campaign_start_dt').over(window_spec))
        .withColumn('campaign_end_dt', F.max('campaign_end_dt').over(window_spec))
        .select(
            'campaign_start_dt',
            'campaign_end_dt',
            'channel_name',
            'campaign_duration',
            'booking_id',
            'campaign_id'
        )
        .distinct()
    )

    unified_campaign_df = (
        unified_campaign_df
        .withColumn(
            'campaign_week_start_date',
            F.date_format(F.date_trunc('week', F.min('campaign_start_dt').over(window_spec)), 'yyyy-MM-dd')
        )
        .withColumn(
            'campaign_week_end_date',
            F.date_format(F.date_trunc('week', F.max('campaign_end_dt').over(window_spec)), 'yyyy-MM-dd')
        )
    )
    return unified_campaign_df


def _build_meta_booking_eligibility(
    camp_execution_df: DataFrame,
    channel_hierarchy_code_df: DataFrame,
    subchannel_hierarchy_codes: Optional[str],
) -> Optional[DataFrame]:
    """Builds Meta AA eligibility from Meta campaign starts per booking."""
    meta_subchannels_df = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df,
        output_column='meta_subchannel_name',
        subchannel_hierarchy_json=subchannel_hierarchy_codes,
        hierarchy_codes_key='meta',
    )

    if meta_subchannels_df is None:
        return None

    meta_subchannels_df = (
        meta_subchannels_df
        .select(
            F.lower(F.trim(F.col('meta_subchannel_name')))
            .alias('meta_subchannel_name')
        )
        .distinct()
    )

    return (
        camp_execution_df
        .withColumn(
            'meta_subchannel_name',
            F.lower(F.trim(F.col('subchannel_name'))),
        )
        .join(
            F.broadcast(meta_subchannels_df),
            on='meta_subchannel_name',
            how='inner',
        )
        .groupBy('booking_id')
        .agg(F.min('campaign_start_dt').alias('meta_booking_start_dt'))
        .withColumn(
            'is_meta_aa_eligible',
            F.col('meta_booking_start_dt') >= F.lit(META_AA_EFFECTIVE_DATE),
        )
        .select('booking_id', 'is_meta_aa_eligible')
    )


def build_transaction_payload(
    transaction_df: DataFrame,
    include_campaign_window: bool = False,
) -> DataFrame:
    """
    Returns the minimal transaction projection used when joining with attribution.

    Args:
        transaction_df: Enriched transaction DataFrame from filter_transaction_to_sku.
        include_campaign_window: Whether to include campaign week window columns.

    Returns:
        DataFrame projected to only the columns required by downstream joins.
    """
    transaction_cols = SkuLevelAttributedSalesAndUnits.transaction_schema.fieldNames()

    if include_campaign_window:
        transaction_cols = transaction_cols + SkuLevelAttributedSalesAndUnits.transaction_window_schema.fieldNames()

    return transaction_df.select(*transaction_cols)


def with_offsite_flag(df: DataFrame, offsite_subchannels_df: DataFrame) -> DataFrame:
    """Adds is_offsite_subchannel to a DataFrame by joining on lowercase subchannel_name.

    Args:
        df: DataFrame to enrich with the offsite flag.
        offsite_subchannels_df: DataFrame containing offsite subchannel keys.

    Returns:
        Input DataFrame enriched with is_offsite_subchannel.
    """
    base_df = df.drop('is_offsite_subchannel') if 'is_offsite_subchannel' in df.columns else df
    offsite = offsite_subchannels_df.withColumn('is_offsite_subchannel', F.lit(True))
    return (
        base_df
        .join(
            F.broadcast(offsite),
            F.lower(base_df['subchannel_name']) == offsite['subchannel_name'],
            how='left',
        )
        .drop(offsite['subchannel_name'])
    )


def get_channel_condition(is_dtp: bool, channel_col: str = 'channel_name'):
    """Returns the standard channel condition for DTP vs Pollen branches.

    Args:
        is_dtp: Whether the pipeline run is DTP.
        channel_col: Column name to use for channel filtering in DTP mode.

    Returns:
        Column expression representing the branch-specific channel condition.
    """
    if is_dtp:
        return F.lower(F.col(channel_col)).isin(['meta', 'youtube', 'dv360'])
    return F.coalesce(F.col('is_offsite_subchannel'), F.lit(False))


def build_sku_level_results(
    attribution_df: DataFrame,
    transactions_cols: DataFrame,
    include_campaign_window: bool = False,
) -> DataFrame:
    """Builds the unified attribution + transaction SKU-level result projection."""
    select_cols = SkuLevelAttributedSalesAndUnits.sku_result_schema.fieldNames()

    if include_campaign_window:
        select_cols = select_cols + SkuLevelAttributedSalesAndUnits.sku_result_window_schema.fieldNames()

    joined = (
        attribution_df
        .join(transactions_cols, on=['transaction_key', 'campaign_id'], how='inner')
    )
    return (
        joined
        .select(*select_cols)
        .distinct()
    )


def _setup_offsite_recalibrated(
        sku_level_results: DataFrame,
        offsite_subchannel_df: DataFrame,
        is_dtp: bool) -> tuple:
    """
    Prepares offsite channel context for recalibration.

    Args:
        sku_level_results: SKU-level DataFrame
        offsite_subchannel_df: Offsite lookup DataFrame
        is_dtp: Whether this is DTP pipeline

    Returns:
        tuple: (source_column, offsite_subchannel_df with normalized keys, flagged sku_level_results)
    """
    if is_dtp:
        source_column = 'channel_name'
    else:
        source_column = 'subchannel_name'
        offsite_subchannel_df = offsite_subchannel_df.select(
            F.lower(F.col('offsite_key')).alias('offsite_key')
        ).distinct()

    sku_level_results = add_offsite_channel_flag(
        sku_level_results,
        offsite_subchannel_df,
        source_column,
    )

    return source_column, offsite_subchannel_df, sku_level_results


def _compute_average_factor_recalibrated(
        factor: DataFrame,
        dtp_attr_join: DataFrame,
        is_dtp: bool,
        offsite_subchannel_df: DataFrame) -> DataFrame:
    """
    Computes average factor by campaign for offsite channels.

    Args:
        factor: DataFrame containing attribution factors
        dtp_attr_join: SKU-level results joined with factors
        is_dtp: Whether this is DTP pipeline
        offsite_subchannel_df: Offsite lookup DataFrame

    Returns:
        DataFrame with avg_factor by campaign_id
    """
    if is_dtp:
        average_factor_source = add_offsite_channel_flag(factor, offsite_subchannel_df, 'channel_name')
    else:
        average_factor_source = dtp_attr_join.select('campaign_id', 'factor', 'is_offsite_channel').distinct()

    average_factor = (
        average_factor_source
        .filter(F.col('is_offsite_channel') == F.lit(True))
        .groupBy('campaign_id')
        .agg(F.avg('factor').alias('avg_factor'))
    )
    logger.info("average_factor computed for recalibrated sales calculation")

    return average_factor


def _apply_recalibration_columns(dtp_attr_join: DataFrame) -> DataFrame:
    """
    Applies base recalibration columns: attributed sales/units and initial recalibrated amounts.

    Args:
        dtp_attr_join: DataFrame with factor and channel flag columns

    Returns:
        DataFrame with attributed and attributed_recalibrated columns
    """
    underscore_count_col = (
        F.length('regression_variable') -
        F.length(F.regexp_replace('regression_variable', '_', ''))
    )

    return (
        dtp_attr_join
        .withColumn('attributed_sales_amt', F.col('normalized_weights') * F.col('net_sales_amt'))
        .withColumn('attributed_units_qty', F.col('normalized_weights') * F.col('units_qty'))
        .withColumn(
            'attributed_recalibrated_sales_amt',
            F.when(F.col('is_offsite_channel') == F.lit(True), F.col('attributed_sales_amt') * F.col('factor'))
             .otherwise(F.col('attributed_sales_amt'))
        )
        .withColumn(
            'attributed_recalibrated_units_qty',
            F.when(F.col('is_offsite_channel') == F.lit(True), F.col('attributed_units_qty') * F.col('factor'))
             .otherwise(F.col('attributed_units_qty'))
        )
        .withColumn('underscore_count', underscore_count_col)
    )


def _compute_offsite_factor_adjustment(dtp_attr_join: DataFrame) -> DataFrame:
    """
    Computes distinct average factor per user journey for offsite-specific logic.

    Args:
        dtp_attr_join: DataFrame with factor and channel columns

    Returns:
        DataFrame with userjourney_id and avg_factor_offsite
    """
    w = Window.partitionBy('userjourney_id').orderBy(F.col('avg_factor'))

    return (
        dtp_attr_join
        .filter(F.col('is_offsite_channel') == F.lit(True))
        .select('userjourney_id', 'avg_factor')
        .distinct()
        .withColumn('rnk', F.rank().over(w))
        .filter(F.col('rnk') == 1)
        .select(
            F.col('userjourney_id'),
            F.col('avg_factor').alias('avg_factor_offsite')
        )
    )


def _apply_offsite_factor_logic(dtp_attr_join: DataFrame, distinct_avg: DataFrame) -> DataFrame:
    """
    Applies offsite-specific factor adjustments for regression variables containing 'offsite'.

    Args:
        dtp_attr_join: DataFrame with base recalibration values
        distinct_avg: DataFrame mapping userjourney_id to avg_factor_offsite

    Returns:
        DataFrame with final recalibrated sales and units for offsite campaigns
    """
    offsite_exp = 'lower(regression_variable) like "%offsite%"'

    return (
        dtp_attr_join
        .join(distinct_avg, on='userjourney_id', how='left')
        .select(
            'campaign_id',
            'userjourney_id',
            'loyalty_id',
            'booking_id',
            'customer_journey_type',
            'journey_type',
            'isconversion',
            'regression_variable',
            'normalized_weights',
            'campaign_duration',
            'channel_name',
            'subchannel_name',
            'marketing_type',
            'event_dt',
            'item_cd',
            'net_sales_amt',
            'units_qty',
            'unique_brand_name',
            'week_start_dt',
            'factor',
            'attributed_sales_amt',
            'attributed_units_qty',
            'attributed_recalibrated_sales_amt',
            'attributed_recalibrated_units_qty',
            'underscore_count',
            'avg_factor_offsite',
            'is_offsite_channel',
        )
        .withColumn(
            'factor',
            F.when(
                (F.lower(F.col('campaign_id')) == 'na') & F.expr(offsite_exp),
                F.col('avg_factor_offsite')
            ).otherwise(F.col('factor'))
        )
        .drop('avg_factor_offsite', 'is_offsite_channel')
        .withColumn(
            'attributed_recalibrated_units_qty',
            F.when(
                (F.lower(F.col('campaign_id')) == 'na') & F.expr(offsite_exp),
                ((F.col('attributed_recalibrated_units_qty') /
                  (F.col('underscore_count') + F.lit(1))) * F.col('factor')) +
                (F.col('attributed_recalibrated_units_qty') /
                 (F.col('underscore_count') + F.lit(1)))
            ).otherwise(F.col('attributed_recalibrated_units_qty'))
        )
        .withColumn(
            'attributed_recalibrated_sales_amt',
            F.when(
                (F.lower(F.col('campaign_id')) == 'na') & F.expr(offsite_exp),
                ((F.col('attributed_recalibrated_sales_amt') /
                  (F.col('underscore_count') + F.lit(1))) * F.col('factor')) +
                (F.col('attributed_recalibrated_sales_amt') /
                 (F.col('underscore_count') + F.lit(1)))
            ).otherwise(F.col('attributed_recalibrated_sales_amt'))
        )
    )


def calculate_recalibrated_sales(
        factor: DataFrame,
        sku_level_results: DataFrame,
        pipeline_run_type: str = PipelineRunType.pollen_run_type,
        offsite_subchannel_df: DataFrame = None):
    """
    Calculates recalibrated sales and units based on attribution factors.

    Objective:
    This function recalibrates attributed sales and units by applying attribution factors
    to SKU-level results. It ensures accurate adjustments for channel-specific platforms
    like Meta, YouTube, and DV360, while also handling regression variables and offsite
    campaign recalibrations. The recalibration process accounts for normalized weights,
    regression variable complexity, and campaign-specific factors to produce refined
    sales and unit metrics.

    Used in:
        This function is called within the model sku_level_attributed_sales_and_units_offer/brand/aisle.

    Args:
        factor (DataFrame): DataFrame containing attribution factors.
        sku_level_results (DataFrame): DataFrame containing SKU-level results.
        pipeline_run_type (str): Type of pipeline run ('pollen' or 'dtp').
        offsite_subchannel_df (DataFrame): Offsite subchannel lookup DataFrame.

    Returns:
        DataFrame: Updated DataFrame with recalibrated sales and units.
    """
    is_dtp = pipeline_run_type.lower() == PipelineRunType.dtp_run_type.lower()
    if offsite_subchannel_df is None:
        raise ValueError("offsite_subchannel_df is required for DTP and Pollen pipeline but was not provided")

    source_column, offsite_subchannel_df, sku_level_results = _setup_offsite_recalibrated(
        sku_level_results, offsite_subchannel_df, is_dtp
    )

    factor_cols = factor.select('channel_name', 'campaign_id', 'factor')

    dtp_attr_join = (
        sku_level_results
        .join(factor_cols, on=['channel_name', 'campaign_id'], how='left')
        .select(*SkuLevelAttributedSalesAndUnits.recalibrated_base_schema.fieldNames())
    )

    average_factor = _compute_average_factor_recalibrated(factor, dtp_attr_join, is_dtp, offsite_subchannel_df)

    dtp_attr_join = _apply_recalibration_columns(dtp_attr_join)

    dtp_attr_join = (
        dtp_attr_join
        .join(average_factor, on=['campaign_id'], how='left')
        .select(*SkuLevelAttributedSalesAndUnits.recalibrated_enriched_schema.fieldNames())
    )
    distinct_avg = _compute_offsite_factor_adjustment(dtp_attr_join)

    return _apply_offsite_factor_logic(dtp_attr_join, distinct_avg)


def calculate_aggregated_sales(
        dtp_sales_df: DataFrame,
        attribution_df: DataFrame,
        total_sales_or_campaign_metrics: DataFrame,
        pipeline_run_type: str = PipelineRunType.pollen_run_type,
        offsite_subchannel_df: DataFrame = None):
    """
    Aggregates sales data and calculates recalibrated sales based on channel overlap.

    Objective:
    This function aims to aggregate sales data and calculate recalibrated sales by
    considering channel-specific overlaps and normalized weights. It ensures accurate
    distribution of sales across channels, accounting for platform-specific adjustments
    and overlap scenarios. The recalibration process refines sales attribution metrics
    for better decision-making.

    Used in:
        This function is called within the model sku_level_attributed_sales_and_units_offer/brand/aisle.

    Args:
        dtp_sales_df: DataFrame containing sales data.
        attribution_df: DataFrame containing attribution data.
        total_sales_or_campaign_metrics: For Pollen: total_sales (float), For DTP: campaign_metrics (DataFrame)
        pipeline_run_type: Type of pipeline run ('pollen' or 'dtp').
        offsite_subchannel_df: offsite subchannel lookup DataFrame.

    Returns:
        DataFrame: DataFrame with aggregated and recalibrated sales data.
    """
    is_dtp = pipeline_run_type.lower() == PipelineRunType.dtp_run_type.lower()
    if offsite_subchannel_df is None:
        raise ValueError("offsite_subchannel_df is required for DTP and Pollen pipeline but was not provided")
    if is_dtp:
        channel_source_column = 'channel_name'

    else:
        channel_source_column = 'subchannel_name'
        offsite_subchannel_df = offsite_subchannel_df.select(
            F.lower(F.col('offsite_key')).alias('offsite_key')
        ).distinct()

    offsite_sales = dtp_sales_df.select('booking_id', 'channel_name', 'campaign_id', 'sum_sales_amt').distinct()
    dtp_attr_join = attribution_df.join(
        offsite_sales,
        on=['booking_id', 'channel_name', 'campaign_id'],
        how='left')

    dtp_attr_join = add_offsite_channel_flag(
        dtp_attr_join,
        offsite_subchannel_df,
        channel_source_column,
    )

    dtp_attr_join = dtp_attr_join.select(
        'booking_id',
        'channel_name',
        'subchannel_name',
        'marketing_type',
        'campaign_id',
        'sum_sales_amt',
        'is_offsite_channel',
        'normalized_weights'
    )

    dtp_attr_join_recalibrated = dtp_attr_join.groupBy(
        'booking_id', 'channel_name', 'subchannel_name', 'marketing_type',
        'campaign_id', 'sum_sales_amt', 'is_offsite_channel').agg(
            F.sum('normalized_weights').alias('sum_normalized_weights'))

    win_channel = Window.partitionBy('booking_id', 'channel_name', 'campaign_id')

    campaign_total_weights = (
        dtp_attr_join_recalibrated.groupBy('booking_id').agg(
            F.sum('sum_normalized_weights').alias('total_weights_per_campaign'))
    )

    campaign_metrics = total_sales_or_campaign_metrics

    dtp_attr_join_recalibrated = (
        dtp_attr_join_recalibrated
        .join(campaign_total_weights, on='booking_id', how='left')
        .join(campaign_metrics, on='booking_id', how='left')
        .withColumn(
            'weights_percentage',
            F.col('sum_normalized_weights') / F.col('total_weights_per_campaign')
        )
        .withColumn(
            'attributed_sales_amt',
            F.col('weights_percentage') * F.col('total_sales')
        )
        .withColumn(
            'channel_weights',
            F.sum('sum_normalized_weights').over(win_channel)
        )
        .withColumn(
            'adjusted_sum_normalized_weights',
            F.when(
                F.col('channel_overlap_proportion') == 0,
                F.when(
                    F.col('is_offsite_channel') == F.lit(True),
                    F.col('sum_normalized_weights') / F.col('channel_weights')
                ).otherwise(F.col('sum_normalized_weights'))
            ).otherwise(F.col('sum_normalized_weights'))
        )
        .withColumn(
            'attributed_recalibrated_sales_amt',
            F.when(
                F.col('channel_overlap_proportion') == 0,
                F.when(
                    F.col('is_offsite_channel') == F.lit(True),
                    F.col('adjusted_sum_normalized_weights') * F.col('sum_sales_amt')
                ).otherwise(F.col('attributed_sales_amt'))
            ).otherwise(
                F.when(
                    F.col('is_offsite_channel') == F.lit(True),
                    F.col('weights_percentage') * F.col('sum_sales_amt')
                ).otherwise(F.col('attributed_sales_amt'))
            )
        )
        .withColumn(
            'weights_percentage',
            F.when(F.col('channel_overlap_proportion') == 0, F.col('adjusted_sum_normalized_weights'))
             .otherwise(F.col('weights_percentage'))
        )
        .withColumn(
            'sum_attributed_recalibrated_sales_amt',
            F.sum('attributed_recalibrated_sales_amt').over(win_channel)
        )
        .withColumn(
            'sum_attributed_sales_amt',
            F.sum('attributed_sales_amt').over(win_channel)
        )
        .withColumn(
            'factor',
            F.col('sum_attributed_recalibrated_sales_amt') / F.col('sum_attributed_sales_amt')
        )
    )

    factor = dtp_attr_join_recalibrated.select(
        'booking_id', 'channel_name', 'campaign_id', 'factor'
    ).distinct()

    return factor


def process_offer_attribution_multi_campaign(
        reach_engagement_df: DataFrame,
        attribution_pre_req_df: DataFrame,
        all_campaigns_df: DataFrame,
        attribution_df: DataFrame,
        transaction_df: DataFrame,
        pipeline_run_type: str = PipelineRunType.dtp_run_type,
        offsite_subchannel_df: DataFrame = None):
    """
    Processes offer attribution for multiple campaigns simultaneously.

    This function handles reach & engagement data, calculates channel overlap metrics,
    and computes recalibration factors for offsite channels (Meta, YouTube, DV360).

    Args:
        reach_engagement_df (DataFrame): Reach engagement data (pre-read, pre-selected)
        attribution_pre_req_df (DataFrame): Attribution prerequisite data (pre-read, pre-selected)
        all_campaigns_df (DataFrame): DataFrame with all campaigns (booking_id, campaign_duration, is_post_campaign)
        attribution_df (DataFrame): Attribution model results
        transaction_df (DataFrame): Transaction data
        pipeline_run_type (str): Type of pipeline run ('pollen' or 'dtp')
        offsite_subchannel_df (DataFrame): Offsite subchannel lookup DataFrame.

    Returns:
        tuple: (factor DataFrame, sku_level_results_final DataFrame)
    """
    is_dtp = pipeline_run_type.lower() == PipelineRunType.dtp_run_type.lower()

    if offsite_subchannel_df is None:
        raise ValueError("offsite_subchannel_df is required for both DTP and Pollen pipeline but was not provided")
    if is_dtp:
        channel_source_column = 'channel_name'
    else:
        channel_source_column = 'subchannel_name'
        offsite_subchannel_df = offsite_subchannel_df.select(
            F.lower(F.col('offsite_key')).alias('offsite_key')
        ).distinct()

    win = Window.partitionBy('booking_id', 'channel_name', 'campaign_id')

    dtp_sales_df = (
        reach_engagement_df
        .join(all_campaigns_df.select('booking_id').distinct(), on='booking_id', how='inner')
        .join(
            F.broadcast(offsite_subchannel_df),
            F.lower(F.col(channel_source_column)) == F.col('offsite_key'),
            how='left_semi',
        )
        .select('booking_id', 'channel_name', 'campaign_id', 'sales_amt')
        .withColumn('sum_sales_amt', F.sum('sales_amt').over(win))
    )

    distinct_channels = (
        attribution_df
        .groupBy('booking_id', 'userjourney_id')
        .agg(F.countDistinct(F.col('channel_name')).alias('distinct_channel'))
    )

    campaign_overlap_metrics = (
        distinct_channels
        .groupBy('booking_id')
        .agg(
            F.count(F.when(F.col('distinct_channel') > 1, 1)).alias('num_user_journeys'),
            F.countDistinct('userjourney_id').alias('total_journeys')
        )
        .withColumn(
            'channel_overlap_proportion',
            F.coalesce(F.col('num_user_journeys') / F.col('total_journeys'), F.lit(0))
        )
    )

    attribution_pre_req = (
        attribution_pre_req_df
        .join(
            all_campaigns_df.select('booking_id', 'campaign_duration', 'is_post_campaign').distinct(),
            on=['booking_id', 'campaign_duration'],
            how='inner',
        )
    )

    total_sales_per_campaign = (
        attribution_pre_req.filter(
            (F.lower(F.col('journey_type')) == 'offer') &
            (F.lower(F.col('regression_variable')) == EventName.TRANSACTION.value.lower()) &
            (
                (~F.col('is_post_campaign')) |
                (
                    (F.col('is_post_campaign')) &
                    (F.lower(F.col('campaign_duration')) == CampaignDurations.CAMPAIGN_DURATION_POST.lower())
                )
            )
        )
        .groupBy('booking_id')
        .agg(F.sum('net_sales_amt').alias('total_sales'))
    )

    campaign_metrics = (
        campaign_overlap_metrics
        .join(total_sales_per_campaign, on='booking_id', how='left')
    )

    factor = calculate_aggregated_sales(
        dtp_sales_df,
        attribution_df,
        campaign_metrics,
        pipeline_run_type,
        offsite_subchannel_df,
    )

    transactions_cols = build_transaction_payload(transaction_df)

    if not is_dtp:
        # Pollen: join on transaction_key only (not campaign_id) because:
        # 1. attribution_df has campaign_id = NA on purchase rows (after dedup_purchases_across_campaigns)
        # 2. transactions_cols fans out per channel via campaign_bounds — joining on campaign_id would
        #    multiply each item row by N_channels, causing over-attribution.
        # Select only item-level columns so .distinct() collapses channel duplicates.
        sku_items = (
            transactions_cols
            .select(
                'transaction_key', 'event_dt', 'item_cd', 'net_sales_amt',
                'units_qty', 'unique_brand_name', 'week_start_dt',
            )
            .distinct()
        )
        sku_level_results = (
            attribution_df
            .join(sku_items, on='transaction_key', how='left')
            .withColumn('campaign_start_dt', F.lit(None).cast(T.DateType()))
            .withColumn('campaign_end_dt', F.lit(None).cast(T.DateType()))
            .select(*SkuLevelAttributedSalesAndUnits.sku_result_schema.fieldNames())
        )
    else:
        sku_level_results = build_sku_level_results(attribution_df, transactions_cols)

    sku_level_results_final = calculate_recalibrated_sales(
        factor,
        sku_level_results,
        pipeline_run_type,
        offsite_subchannel_df
    )

    return factor, sku_level_results_final


def deduplicate_keep_first_item_cd(df: DataFrame):
    """
    De-duplicates a DataFrame by keeping only the first occurrence of records
    that are identical across all columns except 'item_cd'.

    This function is particularly useful when 'item_cd' varies across otherwise
    identical rows, and a single representative record is required for
    downstream aggregation.

    Args:
        df (pyspark.sql.DataFrame): The input Spark DataFrame containing
            potential duplicates.

    Returns:
        pyspark.sql.DataFrame: A DataFrame where uniqueness is enforced based
            on all columns except 'item_cd'. The row with the 'first'
            (alphabetically or numerically lowest) 'item_cd' is preserved.

    Example:
        If three rows have the same CampaignID and Date but different ItemCDs,
        this will return only the row with the lowest ItemCD value.
    """
    columns_to_check = [col for col in df.columns if col != 'item_cd']
    window_spec = Window.partitionBy(columns_to_check).orderBy('item_cd')

    return (
        df
        .withColumn('row_num', F.row_number().over(window_spec))
        .filter(F.col('row_num') == 1)
        .drop('row_num')
    )


def load_campaign_reporting_during(
    measurement_campaign_reporting_df: DataFrame,
    camp_execution_df: DataFrame,
) -> DataFrame:
    """
    Loads the During-phase campaign reporting snapshot used to recalibrate
    Post-phase results.

    Joins to camp_execution_df to scope to in-scope bookings, takes only
    the latest load_ts partition per booking, then validates that no
    modelling_weight values are zero (which would produce division-by-zero
    errors downstream).

    Args:
        measurement_campaign_reporting_df: Pre-read, pre-selected During-phase
                                           campaign reporting DataFrame.
        camp_execution_df:                 Campaign execution DataFrame used to
                                           scope to in-scope booking IDs.

    Returns:
        Validated DataFrame scoped to the latest snapshot for in-scope bookings.

    Raises:
        ValueError: If any row contains a modelling_weight close to zero.
    """
    df = (
        measurement_campaign_reporting_df
        .join(
            camp_execution_df.select('booking_id').distinct(),
            on='booking_id',
            how='inner',
        )
    )

    df = (
        df
        .join(
            df.groupBy('booking_id').agg(F.max('load_ts').alias('max_load_ts')),
            on='booking_id',
        )
        .filter(F.col('load_ts') == F.col('max_load_ts'))
        .drop('max_load_ts')
    )
    return check_zero_modelling_weight(df)


def apply_campaign_duration_identifier_flag(camp_execution_df: DataFrame) -> DataFrame:
    """
    Derives the canonical campaign manifest used by subsequent joins.

    Adds a boolean is_post_campaign column that is True for any
    campaign_duration value containing the word "post".

    Args:
        camp_execution_df: Campaign execution DataFrame.

    Returns:
        Distinct (booking_id, campaign_duration, is_post_campaign) DataFrame.
    """
    return (
        camp_execution_df
        .select('booking_id', 'campaign_duration')
        .distinct()
        .withColumn(
            'is_post_campaign',
            F.when(
                F.lower(F.col('campaign_duration')).contains(
                    CampaignDurations.CAMPAIGN_DURATION_POST.lower()
                ),
                F.lit(True),
            ).otherwise(F.lit(False)),
        )
    )


# TODO:: attention - changed the logic to booking window rather than campaign window here
def filter_transaction_to_sku(
    transaction_data: DataFrame,
    camp_execution_df: DataFrame,
    weekly_campaign_duration_df: DataFrame,
    product_type: str,
) -> DataFrame:
    """
    Narrows the full transaction dataset to the SKU-level rows that are
    relevant for attribution.

    Steps performed:
    1. Inner-join to camp_execution_df to restrict to in-scope bookings.
    2. Filter to event_name == 'transaction' and the requested product_type.
    3. Derive week_start_dt from event_dt.
     4. Keep only weeks that fall within the booking-level campaign window,
         then fan out to booking campaigns.

    Args:
        transaction_data:            Raw transaction DataFrame.
        camp_execution_df:           Campaign execution DataFrame.
        weekly_campaign_duration_df: Output of get_campaign_start_end_date().
        product_type:                One of 'offer', 'aisle', 'brand'.

    Returns:
        Distinct DataFrame keyed by (campaign_id, booking_id, transaction_key)
        with week_start_dt, campaign boundary dates, and sales amounts.
    """
    # Booking-window mode: keep transactions inside booking-level week bounds,
    # then fan out to booking campaigns for downstream campaign matching.
    transaction_df = (
        transaction_data
        .join(camp_execution_df.select('booking_id').distinct(), on='booking_id', how='inner')
        .filter(
            (F.col('event_name') == EventName.TRANSACTION.value) &
            (F.lower(F.col('product_type')) == product_type)
        )
        .select(
            'booking_id',
            'transaction_key',
            'event_dt',
            'item_cd',
            'net_sales_amt',
            'units_qty',
            'unique_brand_name',
        )
        .distinct()
        .withColumn(
            'week_start_dt',
            F.date_format(F.date_trunc('week', F.col('event_dt')), 'yyyy-MM-dd'),
        )
    )

    campaign_bounds = weekly_campaign_duration_df.select(
        'booking_id',
        'campaign_id',
        'channel_name',
        'campaign_duration',
        'campaign_start_dt',
        'campaign_end_dt',
        'campaign_week_start_date',
        'campaign_week_end_date',
    )

    booking_window = (
        campaign_bounds
        .groupBy('booking_id')
        .agg(
            F.min('campaign_week_start_date').alias('booking_week_start_date'),
            F.max('campaign_week_end_date').alias('booking_week_end_date'),
        )
    )

    transaction_df = (
        transaction_df
        .join(booking_window, on='booking_id', how='inner')
        .filter(
            (F.col('week_start_dt') >= F.col('booking_week_start_date')) &
            (F.col('week_start_dt') <= F.col('booking_week_end_date'))
        )
        .drop('booking_week_start_date', 'booking_week_end_date')
        .join(campaign_bounds, on='booking_id', how='inner')
        .select(
            'campaign_id',
            'booking_id',
            'transaction_key',
            'event_dt',
            'item_cd',
            'net_sales_amt',
            'units_qty',
            'unique_brand_name',
            'week_start_dt',
            'campaign_start_dt',
            'campaign_end_dt',
            'channel_name',
            'campaign_duration',
            'campaign_week_start_date',
            'campaign_week_end_date',
        )
        .distinct()
    )

    return transaction_df


def _has_multiple_customer_journey_types(sku_level_df: DataFrame) -> bool:
    """Returns True when there is more than one distinct customer_journey_type.

    Args:
        sku_level_df: SKU-level attribution DataFrame.

    Returns:
        True when more than one customer_journey_type exists, otherwise False.
    """
    return (
        sku_level_df
        .select('customer_journey_type')
        .distinct()
        .select(F.count(F.lit(1)).alias('cnt'))
        .filter(F.col('cnt') > 1)
        .isEmpty() is False
    )


def _apply_recalibration_factor_lookup(
    sku_level_df: DataFrame,
    recalibration_lookup_df: DataFrame,
) -> DataFrame:
    """Left-joins recalibration lookup and updates recalibration_factor where available.

    Args:
        sku_level_df: SKU-level attribution DataFrame to update.
        recalibration_lookup_df: Lookup DataFrame containing new_recalibration_factor.

    Returns:
        DataFrame with recalibration_factor updated where lookup values exist.
    """
    join_keys = ['marketing_type', 'campaign_id', 'channel_name', 'subchannel_name']
    return (
        sku_level_df
        .join(recalibration_lookup_df, on=join_keys, how='left')
        .withColumn(
            'recalibration_factor',
            F.coalesce(F.col('new_recalibration_factor'), F.col('recalibration_factor')),
        )
        .drop('new_recalibration_factor')
    )


def _build_multi_touch_recalibration_lookup(
    sku_level_df: DataFrame,
    sku_during: DataFrame,
) -> DataFrame:
    """Builds recalibration factors for multi-touch offsite rows.

    Args:
        sku_level_df: Post-campaign SKU-level attribution DataFrame.
        sku_during: During-phase offsite reporting DataFrame.

    Returns:
        Lookup DataFrame keyed by marketing/channel dimensions with new_recalibration_factor.
    """
    join_keys = ['marketing_type', 'campaign_id', 'channel_name', 'subchannel_name']

    sku_post = (
        sku_level_df
        .filter(F.lower(F.col('marketing_type')) == MarketingTypes.OFFSITE)
        .groupBy(*join_keys)
        .agg(F.sum('normalized_weights').alias('total_weights'))
    )

    during_weights = sku_during.select(*join_keys, 'modelling_weight').distinct()

    during_recalibration = (
        sku_during
        .select(*join_keys, F.col('recalibration_factor').alias('recal_during'))
        .distinct()
    )

    return (
        sku_post
        .join(during_weights, on=join_keys, how='inner')
        .withColumn(
            'pct_diff',
            (F.col('total_weights') - F.col('modelling_weight')) / F.col('modelling_weight'),
        )
        .join(during_recalibration, on=join_keys, how='left')
        .withColumn('new_recalibration_factor', F.col('recal_during') * (1 + F.col('pct_diff')))
        .select(*join_keys, 'new_recalibration_factor')
    )


def _build_single_touch_recalibration_lookup(sku_during: DataFrame) -> DataFrame:
    """Builds recalibration factors for single-touch offsite rows.

    Args:
        sku_during: During-phase offsite reporting DataFrame.

    Returns:
        Lookup DataFrame keyed by marketing/channel dimensions with new_recalibration_factor.
    """
    return sku_during.select(
        'marketing_type',
        'campaign_id',
        'channel_name',
        'subchannel_name',
        F.col('recalibration_factor').alias('new_recalibration_factor'),
    )


def _apply_post_campaign_recalibration(
        sku_level_df: DataFrame,
        measurement_campaign_reporting_during: DataFrame) -> DataFrame:
    """
    Applies post-campaign offsite recalibration using during-phase reporting.

    For offsite rows, this function computes recalibration updates by comparing
    post-period modeled weights with during-period modeled weights and then
    updates `recalibration_factor` accordingly.

    Args:
        sku_level_df: SKU-level attribution DataFrame prior to post-campaign recalibration.
        measurement_campaign_reporting_during: During-phase campaign reporting DataFrame
            used as the calibration reference.

    Returns:
        DataFrame with updated `recalibration_factor` for applicable offsite rows.
    """
    offsite_flag = not (
        sku_level_df
        .filter(F.lower(F.col('marketing_type')) == MarketingTypes.OFFSITE)
        .isEmpty()
    )

    product = sku_level_df.select('journey_type').distinct().first()[0]

    # Check if there is more than one distinct customer_journey_type value.
    multi_touch = _has_multiple_customer_journey_types(sku_level_df)

    sku_during = measurement_campaign_reporting_during.filter(
        (F.lower(F.col('marketing_type')) == MarketingTypes.OFFSITE) &
        (F.lower(F.col('journey_type')) == product)
    )

    if multi_touch and offsite_flag:
        recalibration_lookup = _build_multi_touch_recalibration_lookup(sku_level_df, sku_during)
        return _apply_recalibration_factor_lookup(sku_level_df, recalibration_lookup).drop_duplicates()

    if not multi_touch and offsite_flag:
        recalibration_lookup = _build_single_touch_recalibration_lookup(sku_during)
        return _apply_recalibration_factor_lookup(sku_level_df, recalibration_lookup)

    return sku_level_df


def _recalculate_post_offsite_amounts(sku_level_df: DataFrame) -> DataFrame:
    """Recalculates Pollen Post offsite amounts using the finalized factors."""
    is_offsite = (
        F.lower(F.col('marketing_type')) == F.lit(MarketingTypes.OFFSITE)
    )

    return (
        sku_level_df
        .withColumn(
            'attributed_recalibrated_sales_amt',
            F.when(
                is_offsite,
                F.col('attributed_sales_amt') * F.col('recalibration_factor'),
            ).otherwise(F.col('attributed_recalibrated_sales_amt')),
        )
        .withColumn(
            'attributed_recalibrated_units_qty',
            F.when(
                is_offsite,
                F.col('attributed_units_qty') * F.col('recalibration_factor'),
            ).otherwise(F.col('attributed_recalibrated_units_qty')),
        )
    )


def _apply_meta_recalibration_for_pollen(
        sku_level_df: DataFrame,
        channel_hierarchy_code_df: DataFrame,
        subchannel_hierarchy_codes: Optional[str]) -> DataFrame:
    """Applies the legacy static Meta factor to pre-AA Pollen bookings."""
    meta_subchannels_df = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df,
        output_column='subchannel_name',
        subchannel_hierarchy_json=subchannel_hierarchy_codes,
        hierarchy_codes_key='meta',
    )

    if meta_subchannels_df is None:
        return sku_level_df

    meta_mapping_df = (
        meta_subchannels_df
        .withColumnRenamed('subchannel_name', 'meta_subchannel_name')
        .withColumn('is_meta_subchannel', F.lit(True))
    )

    sku_level_df = (
        sku_level_df
        .join(
            F.broadcast(meta_mapping_df),
            F.lower(F.col('subchannel_name')) == F.col('meta_subchannel_name'),
            how='left',
        )
    )

    is_meta_aa_eligible = (
        F.coalesce(F.col('is_meta_aa_eligible'), F.lit(False))
        if 'is_meta_aa_eligible' in sku_level_df.columns
        else F.lit(False)
    )
    is_legacy_meta_channel = (
        F.coalesce(F.col('is_meta_subchannel'), F.lit(False)) &
        ~is_meta_aa_eligible
    )
    return (
        sku_level_df
        .withColumn(
            'recalibration_factor',
            F.when(
                is_legacy_meta_channel,
                F.lit(META_STATIC_RECALIBRATION_FACTOR),
            ).otherwise(F.col('recalibration_factor')),
        )
        .withColumn(
            'attributed_recalibrated_sales_amt',
            F.when(
                is_legacy_meta_channel,
                F.col('attributed_sales_amt') * F.col('recalibration_factor'),
            ).otherwise(F.col('attributed_recalibrated_sales_amt')),
        )
        .withColumn(
            'attributed_recalibrated_units_qty',
            F.when(
                is_legacy_meta_channel,
                F.col('attributed_units_qty') * F.col('recalibration_factor'),
            ).otherwise(F.col('attributed_recalibrated_units_qty')),
        )
        .drop('meta_subchannel_name', 'is_meta_subchannel')
    )


def apply_recalibration(
    sku_level_df: DataFrame,
    campaign_duration: str,
    measurement_campaign_reporting_during: DataFrame,
    is_dtp: bool,
    channel_hierarchy_code_df: DataFrame,
    subchannel_hierarchy_codes: Optional[str],
    product_type: str = ProductType.OFFER.value,
) -> DataFrame:
    """
    Orchestrates Post recalibration and the Pollen Meta legacy fallback.

    Post factor updates run for DTP and Pollen Offer rows. Pollen Brand rows
    retain the factor supplied by the Offer output. Pollen Post offsite amounts
    are refreshed using the final factor. The legacy Meta fallback applies only
    to bookings starting before the AA effective date.

    Args:
        sku_level_df: SKU-level attribution DataFrame.
        campaign_duration: Campaign duration value controlling post recalibration.
        measurement_campaign_reporting_during: During-phase reporting DataFrame.
        is_dtp: Whether current run type is DTP.
        channel_hierarchy_code_df: Channel hierarchy reference DataFrame.
        subchannel_hierarchy_codes: JSON string containing hierarchy code mappings.
        product_type: Product type being processed; controls Pollen Post factor updates.

    Returns:
        DataFrame with all applicable recalibration logic applied.
    """
    is_post = campaign_duration == CampaignDurations.CAMPAIGN_DURATION_POST
    if is_post and (
        is_dtp or product_type.lower() == ProductType.OFFER.value.lower()
    ):
        sku_level_df = _apply_post_campaign_recalibration(
            sku_level_df,
            measurement_campaign_reporting_during,
        )

    if is_post and not is_dtp:
        sku_level_df = _recalculate_post_offsite_amounts(sku_level_df)

    if not is_dtp:
        sku_level_df = _apply_meta_recalibration_for_pollen(
            sku_level_df,
            channel_hierarchy_code_df,
            subchannel_hierarchy_codes,
        )

    return sku_level_df


def calculate_sku_level_attribution(
        spark: SparkSession,
        attribution_data_df: DataFrame,
        transaction_raw_df: DataFrame,
        camp_execution_df: DataFrame,
        product_type: str,
        correlation_id: str,
        slack_topic_arn: str,
        run_date: str,
        campaign_duration: str,
        pipeline_run_type: str = PipelineRunType.pollen_run_type,
        reach_engagement_df: Optional[DataFrame] = None,
        attribution_pre_req_df: Optional[DataFrame] = None,
        channel_hierarchy_code_df: Optional[DataFrame] = None,
        subchannel_hierarchy_codes: Optional[str] = None,
        measurement_campaign_reporting_df: Optional[DataFrame] = None,
        sku_level_offer_df: Optional[DataFrame] = None,
) -> DataFrame:
    """
    This is the main function that calculates SKU-level attributed sales and units for aisle marketing campaigns.
    """

    is_dtp = pipeline_run_type.lower() == PipelineRunType.dtp_run_type.lower()
    validation_notifier = SKUAttributionValidationNotifier(
        slack_topic_arn=slack_topic_arn,
        correlation_id=correlation_id,
        product_type=product_type,
        pipeline_run_type=pipeline_run_type,
    )

    offsite_subchannel_df = None
    if is_dtp:
        offsite_subchannel_df = spark.createDataFrame(
            [(channel,) for channel in DTP_OFFSITE_CHANNELS],
            ['offsite_key'],
        )
        logger.info(f"DTP offsite channels: {DTP_OFFSITE_CHANNELS}")
    else:
        if channel_hierarchy_code_df is None:
            raise ValueError("channel_hierarchy_code_df is required for Pollen pipeline but was not provided")
        offsite_subchannel_df = get_subchannels_from_hierarchy(
            channel_hierarchy_code_df,
            output_column='offsite_key',
            offsite_only=True,
        )
        logger.info("Pollen offsite_subchannel_df from hierarchy")

    attribution_df = attribution_data_df.select(
        'userjourney_id',
        'loyalty_id',
        'transaction_key',
        'booking_id',
        'customer_journey_type',
        'journey_type',
        'isconversion',
        'regression_variable',
        'normalized_weights',
        'campaign_id',
        'campaign_duration',
        'load_ts',
        'channel_name',
        'subchannel_name',
        'marketing_type',
    )

    measurement_campaign_reporting_during = None
    if campaign_duration == CampaignDurations.CAMPAIGN_DURATION_POST:
        measurement_campaign_reporting_during = load_campaign_reporting_during(
            measurement_campaign_reporting_df, camp_execution_df
        )

    all_campaigns_df = apply_campaign_duration_identifier_flag(camp_execution_df)

    transaction_data = (
        transaction_raw_df
        .join(
            all_campaigns_df.select('booking_id'),
            on='booking_id',
            how='inner',
        )
        .select(
            'booking_id',
            'campaign_id',
            'transaction_key',
            'event_dt',
            'event_name',
            'item_cd',
            'net_sales_amt',
            'units_qty',
            'subchannel_name',
            'product_type',
            'unique_brand_name',
        )
    )

    if product_type in (ProductType.AISLE.value.lower(), ProductType.BRAND.value.lower()):
        sku_level_offer_latest = (
            sku_level_offer_df
            .join(
                all_campaigns_df.select('booking_id', 'campaign_duration', 'is_post_campaign'),
                on=['booking_id', 'campaign_duration'],
                how='inner',
            )
            .select(
                'booking_id',
                'campaign_duration',
                'campaign_id',
                'channel_name',
                'userjourney_id',
                'loyalty_id',
                'customer_journey_type',
                'journey_type',
                'isconversion',
                'normalized_weights',
                'event_dt',
                'item_cd',
                'net_sales_amt',
                'units_qty',
                'unique_brand_name',
                'week_start_dt',
                'regression_variable',
                'subchannel_name',
                'attributed_sales_amt',
                'attributed_units_qty',
                'attributed_recalibrated_sales_amt',
                'attributed_recalibrated_units_qty',
                'load_ts',
                'marketing_type',
                'recalibration_factor',
                'is_post_campaign',
            )
        )

        sku_level_offer_filtered = (
            sku_level_offer_latest
            .select('booking_id', 'channel_name', 'campaign_id', 'recalibration_factor')
            .withColumnRenamed('recalibration_factor', 'factor')
            .filter(F.col('factor') > 0)
            .distinct()
        )

    weekly_campaign_duration_df = get_campaign_start_end_date(camp_execution_df)

    transaction_df = filter_transaction_to_sku(
        transaction_data, camp_execution_df, weekly_campaign_duration_df, product_type
    )

    if product_type == ProductType.OFFER.value.lower():
        factor, sku_level_results_final = process_offer_attribution_multi_campaign(
            reach_engagement_df,
            attribution_pre_req_df,
            all_campaigns_df,
            attribution_df,
            transaction_df,
            pipeline_run_type,
            offsite_subchannel_df,
        )
    else:
        attribution_df = attribution_df.withColumn(
            'regression_variable', F.col('regression_variable').cast(T.StringType())
        )

        transactions_cols = build_transaction_payload(
            transaction_df,
            include_campaign_window=True,
        )

        sku_level_results = build_sku_level_results(
            attribution_df,
            transactions_cols,
            include_campaign_window=True,
        )

        sku_level_results_final = calculate_recalibrated_sales(
            sku_level_offer_filtered,
            sku_level_results,
            pipeline_run_type,
            offsite_subchannel_df,
        )

    sku_level_attributed_sales_and_units_level = (
        sku_level_results_final
        .drop(
            'avg_f1_score',
            'sum_attributed_sales',
            'sales_amt',
            'sum_recalibrated_attributed_sales',
            'sum_normalized_weights',
            'sum_sales_amt',
            'underscore_count',
        )
        .withColumnRenamed('factor', 'recalibration_factor')
        .withColumn('load_ts', F.lit(run_date))
        .withColumn('job_run_id', F.lit(correlation_id))
    )

    if not is_dtp:
        meta_aa_eligibility_df = _build_meta_booking_eligibility(
            camp_execution_df,
            channel_hierarchy_code_df,
            subchannel_hierarchy_codes,
        )
        if meta_aa_eligibility_df is not None:
            sku_level_attributed_sales_and_units_level = (
                sku_level_attributed_sales_and_units_level
                .join(
                    F.broadcast(meta_aa_eligibility_df),
                    on='booking_id',
                    how='left',
                )
            )

    sku_level_attributed_sales_and_units_level = apply_recalibration(
        sku_level_attributed_sales_and_units_level,
        campaign_duration,
        measurement_campaign_reporting_during,
        is_dtp,
        channel_hierarchy_code_df,
        subchannel_hierarchy_codes,
        product_type=product_type,
    )
    sku_level_attributed_sales_and_units_level = sku_level_attributed_sales_and_units_level.drop(
        'factor',
        'is_meta_aa_eligible',
    )
    if is_dtp:
        sku_level_attributed_sales_and_units_level = deduplicate_keep_first_item_cd(
            sku_level_attributed_sales_and_units_level
        )

    validation_notifier.send_final_validation_summary(
        sku_level_attributed_sales_and_units_level
    )

    return sku_level_attributed_sales_and_units_level
