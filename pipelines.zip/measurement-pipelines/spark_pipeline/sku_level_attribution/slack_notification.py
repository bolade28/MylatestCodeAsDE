import json
from typing import Optional

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from spark_pipeline.common.variables import MarketingTypes
from spark_pipeline.utils.slack_utils import SlackMessenger


class SKUAttributionValidationNotifier:
    """
    Handles Slack validation notifications for SKU-level attribution and
    baseline integration pipelines.
    """

    def __init__(
            self,
            slack_topic_arn: str,
            correlation_id: str,
            product_type: str,
            pipeline_run_type: str,
    ):
        """Initializes the notifier."""
        self.slack_messenger = SlackMessenger(
            topic_arn=slack_topic_arn,
            correlation_id=correlation_id,
        )
        self.correlation_id = correlation_id
        self.product_type = product_type
        self.pipeline_run_type = pipeline_run_type

    def validate_meta_static_recalibration_applied(
            self,
            sku_level_df: DataFrame,
            expected_factor: float,
            subchannel_hierarchy_codes: Optional[str],
    ) -> None:
        """
        Confirms the static Meta recalibration factor was applied to all Meta rows.
        """
        meta_codes = []
        try:
            codes = json.loads(subchannel_hierarchy_codes) if subchannel_hierarchy_codes else {}
            meta_codes = codes.get("meta", [])
        except (json.JSONDecodeError, TypeError):
            meta_codes = []

        if not meta_codes:
            self.slack_messenger.send_message(
                event_type="SKU Level Attribution Validation",
                text="[Validation] Meta static recalibration factor applied (Pollen)",
                data={
                    "expected_factor": expected_factor,
                    "meta_hierarchy_codes": [],
                    "status": "SKIP: no meta hierarchy codes resolved",
                },
            )
            return

        lower_codes = [str(code).lower() for code in meta_codes]

        meta_rows_total = (
            sku_level_df
            .filter(F.lower(F.col("subchannel_name")).isin(lower_codes))
            .select(F.count("*").alias("cnt"))
            .first()["cnt"]
        )

        meta_rows_correct = (
            sku_level_df
            .filter(
                F.lower(F.col("subchannel_name")).isin(lower_codes)
                & (F.abs(F.col("recalibration_factor") - expected_factor) < 1e-6)
            )
            .select(F.count("*").alias("cnt"))
            .first()["cnt"]
        )

        coverage_pct = (
            round(100 * meta_rows_correct / meta_rows_total, 2)
            if meta_rows_total > 0 else None
        )

        status = (
            "OK" if coverage_pct == 100.0
            else f"WARNING: only {coverage_pct}% of Meta rows have expected factor"
        )

        self.slack_messenger.send_message(
            event_type="SKU Level Attribution Validation",
            text="[Validation] Meta static recalibration factor applied (Pollen)",
            data={
                "expected_factor": expected_factor,
                "meta_hierarchy_codes": meta_codes,
                "meta_rows_total": meta_rows_total,
                "meta_rows_with_correct_factor": meta_rows_correct,
                "coverage_pct": coverage_pct,
                "status": status,
            },
        )

    def validate_negative_recalibrated_sales(self, sku_level_df: DataFrame) -> None:
        """Alerts when any attributed_recalibrated_sales_amt value is negative."""
        stats = sku_level_df.agg(
            F.count("*").alias("total_rows"),
            F.count(
                F.when(F.col("attributed_recalibrated_sales_amt") < 0, 1)
            ).alias("negative_rows"),
            F.min("attributed_recalibrated_sales_amt").alias("min_value"),
        ).first()

        total = stats["total_rows"] or 0
        negative_rows = stats["negative_rows"] or 0

        status = (
            f"WARNING: {negative_rows} rows with negative recalibrated sales"
            if negative_rows > 0 else "OK"
        )

        self.slack_messenger.send_message(
            event_type="SKU Level Attributed Sales and Units",
            text="[Validation] Recalibrated Sales Non-Negativity Check",
            data={
                "total_rows": total,
                "negative_recalibrated_sales_rows": negative_rows,
                "negative_recalibrated_sales_pct": round(100 * negative_rows / total, 2) if total > 0 else 0.0,
                "min_recalibrated_sales": round(stats["min_value"], 2) if stats["min_value"] is not None else None,
                "status": status,
            },
        )

    def send_final_validation_summary(self, sku_level_df: DataFrame) -> None:
        """Sends the final consolidated SKU-level validation summary."""
        stats = sku_level_df.agg(
            F.count("*").alias("total_rows"),
            F.count(
                F.when(F.col("attributed_recalibrated_sales_amt") < 0, 1)
            ).alias("negative_rows"),
            F.count(
                F.when(F.lower(F.col("marketing_type")) == MarketingTypes.OFFSITE, 1)
            ).alias("total_offsite_rows"),
            F.count(
                F.when(
                    (F.lower(F.col("marketing_type")) == MarketingTypes.OFFSITE)
                    & F.col("recalibration_factor").isNull(),
                    1,
                )
            ).alias("null_factor_rows"),
        ).first()

        total_rows = stats["total_rows"] or 0
        negative_rows = stats["negative_rows"] or 0
        total_offsite_rows = stats["total_offsite_rows"] or 0
        null_factor_rows = stats["null_factor_rows"] or 0

        self.slack_messenger.send_message(
            event_type="SKU Level Attributed Sales and Units",
            text="SKU Level Attribution Summary",
            data={
                "Total Recalibrated Sales": total_rows,
                "Negative Recalibrated Sales Rows": negative_rows,
                "Negative Recalibrated Sales Percentage": round(100 * negative_rows / total_rows, 2) if total_rows > 0 else 0.0,
                "Total Offsite Rows": total_offsite_rows,
                "Offsite Rows with Null Recalibration Factor": null_factor_rows,
                f"Total SKU Level Attributed Sales and Units ({self.product_type.title()})": total_rows,
            },
        )

    def validate_null_recalibration_factor_offsite(self, sku_level_df: DataFrame) -> None:
        """Alerts when offsite rows have a null recalibration_factor."""
        offsite_df = sku_level_df.filter(
            F.lower(F.col("marketing_type")) == MarketingTypes.OFFSITE
        )

        stats = offsite_df.agg(
            F.count("*").alias("total_offsite_rows"),
            F.count(
                F.when(F.col("recalibration_factor").isNull(), 1)
            ).alias("null_factor_rows"),
        ).first()

        total_offsite = stats["total_offsite_rows"] or 0
        null_rows = stats["null_factor_rows"] or 0

        status = (
            f"WARNING: {null_rows} offsite rows have null recalibration factor"
            if null_rows > 0 else "OK"
        )

        self.slack_messenger.send_message(
            event_type="SKU Level Attributed Sales and Units",
            text="[Validation] Offsite Recalibration Factor Completeness Check",
            data={
                "total_offsite_rows": total_offsite,
                "null_factor_rows": null_rows,
                "null_factor_pct": round(100 * null_rows / total_offsite, 2) if total_offsite > 0 else 0.0,
                "status": status,
            },
        )

    def validate_zero_attributed_sales(self, baseline_df: DataFrame) -> None:
        """
        Alerts when attributed_sales_amt or attributed_recalibrated_sales_amt
        is zero or null in the baseline integration output.
        """
        stats = baseline_df.agg(
            F.count("*").alias("total_rows"),
            F.count(
                F.when(
                    F.col("attributed_sales_amt").isNull()
                    | (F.col("attributed_sales_amt") == 0),
                    1,
                )
            ).alias("zero_attributed_sales"),
            F.count(
                F.when(
                    F.col("attributed_recalibrated_sales_amt").isNull()
                    | (F.col("attributed_recalibrated_sales_amt") == 0),
                    1,
                )
            ).alias("zero_recalibrated_sales"),
        ).first()

        total = stats["total_rows"] or 0
        zero_base = stats["zero_attributed_sales"] or 0
        zero_recal = stats["zero_recalibrated_sales"] or 0

        status = (
            f"WARNING: {zero_base} zero base sales rows, {zero_recal} zero recalibrated sales rows"
            if zero_base > 0 or zero_recal > 0 else "OK"
        )

        self.slack_messenger.send_message(
            event_type="SKU Level Attribution Validation",
            text="[Validation] Zero attributed sales - baseline integration",
            data={
                "pipeline_run_type": self.pipeline_run_type,
                "total_rows": total,
                "zero_attributed_sales_rows": zero_base,
                "zero_attributed_sales_pct": round(100 * zero_base / total, 2) if total > 0 else 0.0,
                "zero_recalibrated_sales_rows": zero_recal,
                "zero_recalibrated_sales_pct": round(100 * zero_recal / total, 2) if total > 0 else 0.0,
                "status": status,
            },
        )

    def validate_row_count_drop_vs_during(
            self,
            baseline_post_df: DataFrame,
            baseline_during_df: DataFrame,
            drop_threshold_pct: float = 20.0,
    ) -> None:
        """
        Alerts when the post-period baseline output has significantly fewer
        rows than the during-phase equivalent.
        """
        post_count = baseline_post_df.count()
        during_count = baseline_during_df.count()

        drop_pct = (
            round((during_count - post_count) / during_count * 100, 2)
            if during_count > 0 else None
        )

        status = (
            f"WARNING: post row count dropped {drop_pct}% vs during"
            if drop_pct is not None and drop_pct > drop_threshold_pct
            else "OK"
        )

        self.slack_messenger.send_message(
            event_type="SKU Level Attribution Validation",
            text="[Validation] Row count drop vs during phase - baseline integration",
            data={
                "post_row_count": post_count,
                "during_row_count": during_count,
                "drop_pct": drop_pct,
                "drop_threshold_pct": drop_threshold_pct,
                "status": status,
            },
        )
