from typing import List, Optional
from pyspark.sql import functions as F
from pyspark.sql import SparkSession
from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser
from spark_pipeline.common.variables import CampaignDurations, ProductType
from spark_pipeline.sku_level_attribution.sku_level_attribution_helper import calculate_sku_level_attribution
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def prepare_sku_level_attributed_sales_and_units(
        spark: SparkSession,
        measurement_campaign_execution_path: str,
        customer_data_collection_path: str,
        attribution_model_results_level_path: str,
        sku_level_attributed_sales_and_units_offer_path: str,
        reach_engagement_path: Optional[str],
        attribution_pre_requisite_offer_path: Optional[str],
        output_path: str,
        product_type: str,
        run_date: str,
        pipeline_run_type: str,
        campaign_duration: str,
        correlation_id: str,
        slack_topic_arn: str,
        previous_measurement_campaign_reporting: Optional[str],
        measurement_marketing_channel_hierarchy_path: Optional[str],
        subchannel_hierarchy_codes: Optional[str]
) -> None:
    """Loads dependencies, runs SKU attribution, sends Slack summary, and writes output.

    Args:
        spark: Active SparkSession.
        measurement_campaign_execution_path: Path to campaign execution data.
        customer_data_collection_path: Path to customer transaction data.
        attribution_model_results_level_path: Path to attribution model result data.
        sku_level_attributed_sales_and_units_offer_path: Path to offer-level SKU output used by aisle/brand runs.
        reach_engagement_path: Path to reach and engagement data for offer runs.
        attribution_pre_requisite_offer_path: Path to attribution prerequisite data for offer runs.
        output_path: Destination path for output parquet.
        product_type: Product type being processed.
        run_date: Pipeline run date.
        pipeline_run_type: Pipeline branch, typically Pollen or DTP.
        campaign_duration: Campaign duration, typically During or Post.
        correlation_id: Correlation ID for traceability and Slack.
        slack_topic_arn: SNS topic ARN used for Slack notifications.
        previous_measurement_campaign_reporting: Path to previous measurement campaign reporting for post runs.
        measurement_marketing_channel_hierarchy_path: Path to channel hierarchy data for Pollen runs.
        subchannel_hierarchy_codes: JSON mapping of hierarchy codes used for Meta recalibration.

    Returns:
        None. Writes output parquet and emits a Slack summary message.
    """
    attribution_data_df = (
        spark
        .read
        .parquet(attribution_model_results_level_path)
        .select(
            'userjourney_id',
            'loyalty_id',
            'transaction_key',
            'booking_id',
            'customer_journey_type',
            'journey_type',
            'isconversion',
            'regression_variable',
            'normalized_weights',
            'campaign_id',
            'campaign_duration',
            'load_ts',
            'channel_name',
            'subchannel_name',
            'marketing_type',
        )
    )

    transaction_raw_df = (
        spark
        .read
        .parquet(customer_data_collection_path)
        .select(
            'booking_id',
            'campaign_id',
            'transaction_key',
            F.to_date(F.col('event_ts')).alias('event_dt'),
            'event_name',
            'item_cd',
            'net_sales_amt',
            'units_qty',
            'subchannel_name',
            'product_type',
            'unique_brand_name',
        )
    )

    camp_execution_df = (
        spark
        .read
        .parquet(measurement_campaign_execution_path)
        .select(
            'booking_id',
            'campaign_duration',
            'campaign_start_dt',
            'campaign_end_dt',
            'channel_name',
            'subchannel_name',
            'campaign_id',
        )
        .distinct()
    )

    # Hierarchical channel mapping is only required for Pollen
    channel_hierarchy_df = (
        spark
        .read
        .parquet(measurement_marketing_channel_hierarchy_path)
        .select(
            'marketing_subchannel',
            'channel_type',
            'marketing_hierarchy_cd',
        )
    ) if measurement_marketing_channel_hierarchy_path else None

    # Offer-level SKU results only required for aisle/brand product types.
    sku_level_offer_df = (
        spark
        .read
        .parquet(sku_level_attributed_sales_and_units_offer_path)
        .select(
            'campaign_id',
            'channel_name',
            'userjourney_id',
            'loyalty_id',
            'booking_id',
            'customer_journey_type',
            'journey_type',
            'isconversion',
            'normalized_weights',
            'campaign_duration',
            'event_dt',
            'item_cd',
            'net_sales_amt',
            'units_qty',
            'unique_brand_name',
            'week_start_dt',
            'regression_variable',
            'subchannel_name',
            'attributed_sales_amt',
            'attributed_units_qty',
            'attributed_recalibrated_sales_amt',
            'attributed_recalibrated_units_qty',
            'load_ts',
            'marketing_type',
            'recalibration_factor',
        )
    ) if product_type.lower() == ProductType.BRAND.value.lower() else None

    # Reach/engagement and attribution pre-req only required for offer product type.
    reach_engagement_df = (
        spark
        .read
        .parquet(reach_engagement_path)
        .select(
            'campaign_id',
            'channel_name',
            'reach_cnt',
            'clicks_cnt',
            'impressions_cnt',
            'sales_amt',
            'conversions_cnt',
            'booking_id',
            'load_ts',
            'marketing_type',
            'subchannel_name',
            'media_spend_amt',
            'engagement_ctr_pct',
        )
    ) if product_type.lower() == ProductType.OFFER.value.lower() else None

    attribution_pre_req_df = (
        spark
        .read
        .parquet(attribution_pre_requisite_offer_path)
        .select(
            'loyalty_id',
            'channel_name',
            'subchannel_name',
            'event_ts',
            'event_name',
            'net_sales_amt',
            'journey_type',
            'transaction_key',
            'campaign_id',
            'booking_id',
            'position',
            'campaign_duration',
            'load_ts',
            'userjourney_id',
            'regression_variable',
            'customer_journey_type',
            'isconversion',
            'marketing_type',
        )
    ) if product_type.lower() == ProductType.OFFER.value.lower() else None

    # Previous-MCR is needed for post duration runs only.
    measurement_campaign_reporting_df = (
        spark
        .read
        .parquet(previous_measurement_campaign_reporting)
        .select(
            'campaign_id',
            'booking_id',
            'campaign_duration',
            'journey_type',
            'marketing_type',
            'channel_name',
            'subchannel_name',
            'sub_category_name',
            'attributed_recalibrated_sales_amt',
            'recalibration_factor',
            'job_bag_number',
            'modelling_weight',
            'load_ts',
        )
    ) if campaign_duration == CampaignDurations.CAMPAIGN_DURATION_POST else None

    sku_level_attributed_sales_and_unit = calculate_sku_level_attribution(
        spark=spark,
        attribution_data_df=attribution_data_df,
        transaction_raw_df=transaction_raw_df,
        camp_execution_df=camp_execution_df,
        product_type=product_type,
        correlation_id=correlation_id,
        slack_topic_arn=slack_topic_arn,
        run_date=run_date,
        campaign_duration=campaign_duration,
        pipeline_run_type=pipeline_run_type,
        reach_engagement_df=reach_engagement_df,
        attribution_pre_req_df=attribution_pre_req_df,
        channel_hierarchy_code_df=channel_hierarchy_df,
        subchannel_hierarchy_codes=subchannel_hierarchy_codes,
        measurement_campaign_reporting_df=measurement_campaign_reporting_df,
        sku_level_offer_df=sku_level_offer_df,
    )

    # Use custom method to write to s3 destination output
    spark_s3_overwrite(output_path, sku_level_attributed_sales_and_unit)


def entrypoint(
        spark: SparkSession,
        command_line_args: Optional[List[str]] = None
) -> None:
    """Parses CLI arguments and executes the SKU attribution preparation flow.

    Args:
        spark: Active SparkSession.
        command_line_args: Optional override list of CLI arguments.

    Returns:
        None.
    """
    parser = ThrowingArgumentParser(
        description="Prepare SKU Level Attributed Sales and Units."
    )

    parser.add_argument(
        "--measurement-campaign-execution-path",
        type=str,
        required=True,
        help="S3 path for measurement campaign execution data."
    )
    parser.add_argument(
        "--customer-data-collection-path",
        type=str,
        required=True,
        help="S3 path for customer data collection data."
    )
    parser.add_argument(
        "--attribution-model-results-level-path",
        type=str,
        required=True,
        help="S3 path for attribution model results level (brand/aisle/offer)."
    )
    parser.add_argument(
        "--sku-level-attributed-sales-and-units-offer-path",
        type=str,
        required=True,
        help="S3 path for SKU‐level recalibration factors (always from offer)."
    )
    parser.add_argument(
        "--reach-engagement-path",
        type=str,
        required=False,
        help="S3 path for reach engagement (only for offer)."
    )
    parser.add_argument(
        "--attribution-pre-requisite-offer-path",
        type=str,
        required=False,
        help="S3 path for attribution pre‐req offer (only for offer)."
    )
    parser.add_argument(
        "--output-path",
        type=str,
        required=True,
        help="S3 path for the output parquet."
    )
    parser.add_argument(
        "--product-type",
        type=str,
        required=True,
        choices=["brand", "aisle", "offer"],
        help="Product type: brand | aisle | offer."
    )
    parser.add_argument(
        "--run-date",
        type=str,
        required=True,
        help="Pipeline run date in YYYY-MM-DD."
    )
    parser.add_argument(
        "--pipeline-run-type",
        type=str,
        required=True,
        help="Pipeline run type."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="Correlation ID for traceability."
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="ARN of the Slack topic for notifications."
    )
    parser.add_argument(
        "--measurement-marketing-channel-hierarchy-path",
        type=str,
        required=False,
        help="S3 path for measurement marketing channel hierarchy data (Pollen only)."
    )
    parser.add_argument(
        "--subchannel-hierarchy-codes",
        type=str,
        required=False,
        help="JSON string of subchannel hierarchy codes mapping."
    )
    parser.add_argument(
        "--campaign-duration",
        type=str,
        required=True,
        choices=[CampaignDurations.CAMPAIGN_DURATION_DURING, CampaignDurations.CAMPAIGN_DURATION_POST],
        help=(
            f"Campaign duration for campaign processing "
            f"({', '.join([CampaignDurations.CAMPAIGN_DURATION_DURING, CampaignDurations.CAMPAIGN_DURATION_POST])})."
        ),
    )
    parser.add_argument(
        "--previous-measurement-campaign-reporting",
        type=str,
        required=False,
        default=None,
        help="S3 path for previous measurement campaign reporting (During period)"
    )
    args, _ = parser.parse_known_args(command_line_args)

    prepare_sku_level_attributed_sales_and_units(
        spark=spark,
        measurement_campaign_execution_path=args.measurement_campaign_execution_path,
        customer_data_collection_path=args.customer_data_collection_path,
        attribution_model_results_level_path=args.attribution_model_results_level_path,
        sku_level_attributed_sales_and_units_offer_path=args.sku_level_attributed_sales_and_units_offer_path,
        reach_engagement_path=args.reach_engagement_path,
        attribution_pre_requisite_offer_path=args.attribution_pre_requisite_offer_path,
        output_path=args.output_path,
        product_type=args.product_type,
        run_date=args.run_date,
        pipeline_run_type=args.pipeline_run_type,
        campaign_duration=args.campaign_duration,
        correlation_id=args.correlation_id,
        slack_topic_arn=args.slack_topic_arn,
        measurement_marketing_channel_hierarchy_path=args.measurement_marketing_channel_hierarchy_path,
        subchannel_hierarchy_codes=args.subchannel_hierarchy_codes,
        previous_measurement_campaign_reporting=args.previous_measurement_campaign_reporting
    )


if __name__ == "__main__":
    entrypoint(
        spark=SparkSession.builder
        .appName("SKULevelAttribution")
        .getOrCreate()
    )
