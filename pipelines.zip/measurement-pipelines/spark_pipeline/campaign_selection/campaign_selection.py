from typing import List, Optional

from pyspark.sql import DataFrame, functions as F, SparkSession

from spark_pipeline.common.throwing_argument_parser import ThrowingArgumentParser, str_to_bool
from spark_pipeline.common.variables import CampaignSelectionConfig
from spark_pipeline.utils.campaign_selection.new_launch_helpers import filter_campaigns
from spark_pipeline.campaign_selection.campaign_utils import publish_manually_selected_campaigns, publish_brand_modelling_status
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.schemas.previous_sku_cluster_mapping import PreviousSkuClusterMapping
from spark_pipeline.schemas.previous_baseline_modelling_output import PreviousBaselineModellingOutput
from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


def aggregate_media_spend(
    unified_campaign_df: DataFrame,
    campaign_type_column: str = "booking_id",
    config: Optional[CampaignSelectionConfig] = None,
) -> DataFrame:
    """
    Enrich campaign rows with campaign-level media spend aggregates.

    Aggregation is performed at:
      super_category_name, unique_brand_name, campaign_type_column

    Source-specific spend buckets are derived from marketing hierarchy codes using
    CampaignSelectionConfig.campaign_source_mapping.

    Args:
        unified_campaign_df: Unified campaign input with spend and hierarchy columns.
        campaign_type_column: Campaign identifier column to aggregate on
            (for example, booking_id or job_bag_number).
        config: Optional CampaignSelectionConfig. A default config is used when omitted.

    Returns:
        DataFrame containing original campaign rows enriched with:
        min_campaign_start_dt, max_campaign_end_dt, total_media_spend,
        media_spend_by_source, marketing_types, channel_name, subchannel_name.
    """
    if config is None:
        config = CampaignSelectionConfig()

    campaign_source_mapping = config.campaign_source_mapping
    coupon_at_till_codes = campaign_source_mapping["coupon-at-till"]
    ecoupon_codes = campaign_source_mapping["ecoupon"]

    campaign_source_expr = (
        F.when(
            F.col("marketing_hierarchy_cd").isin(coupon_at_till_codes),
            F.lit("coupon-at-till"),
        )
        .when(
            F.col("marketing_hierarchy_cd").isin(ecoupon_codes),
            F.lit("ecoupon"),
        )
        .otherwise(F.col("marketing_type"))
    )

    campaign_with_source_df = unified_campaign_df.withColumn("campaign_source", campaign_source_expr)

    media_spend_buckets = (
        campaign_with_source_df
        .groupBy(
            "super_category_name",
            "unique_brand_name",
            campaign_type_column,
            "campaign_source",
        )
        .agg(F.sum("media_spend_amt").alias("total_media_spend"))
    )

    media_spend_by_source = (
        media_spend_buckets
        .groupBy("super_category_name", "unique_brand_name", campaign_type_column)
        .agg(
            F.map_from_entries(
                F.collect_list(
                    F.struct(F.col("campaign_source"), F.col("total_media_spend"))
                )
            ).alias("media_spend_by_source")
        )
    )

    campaign_level_spend = (
        campaign_with_source_df
        .groupBy("super_category_name", "unique_brand_name", campaign_type_column)
        .agg(
            F.min("campaign_start_dt").alias("min_campaign_start_dt"),
            F.max("campaign_end_dt").alias("max_campaign_end_dt"),
            F.max("post_campaign_dt").alias("max_post_campaign_dt"),
            F.sum("media_spend_amt").alias("total_media_spend"),
            F.collect_set(
                F.when(
                    F.col("marketing_hierarchy_cd").isin(coupon_at_till_codes),
                    config.coupon_at_till_marketing_type,
                ).otherwise(F.col("marketing_type"))
            ).alias("marketing_types"),
            F.array_sort(F.collect_set("channel_name")).alias("channel_name"),
            F.array_sort(F.collect_set("subchannel_name")).alias("subchannel_name"),
        )
    )

    media_spend_df = (
        campaign_level_spend
        .join(
            media_spend_by_source,
            on=["super_category_name", "unique_brand_name", campaign_type_column],
            how="inner",
        )
        .select(
            "super_category_name",
            "unique_brand_name",
            "min_campaign_start_dt",
            "max_campaign_end_dt",
            "max_post_campaign_dt",
            "total_media_spend",
            "media_spend_by_source",
            "marketing_types",
            "channel_name",
            "subchannel_name",
        )
    )

    return (
        unified_campaign_df
        .drop("channel_name", "subchannel_name")
        .join(
            media_spend_df,
            on=["super_category_name", "unique_brand_name"],
            how="left",
        )
    )


def create_empty_previous_sku_cluster_mapping_df(spark: SparkSession):
    """Create an empty DataFrame with previous SKU cluster mapping schema."""
    return spark.createDataFrame([], PreviousSkuClusterMapping.schema)


def create_empty_previous_baseline_modelling_output_df(spark: SparkSession):
    """Create an empty DataFrame with previous baseline modelling output schema."""
    return spark.createDataFrame([], PreviousBaselineModellingOutput.schema)


def prepare_campaign_selection(
    spark: SparkSession,
    unified_campaign_path: str,
    item_brand_hist_path: str,
    measurement_marketing_channel_hierarchy_path: str,
    output_path_campaign_selection: str,
    manual_run_flag: bool,
    manual_campaign_list: List[str],
    slack_topic_arn: str,
    correlation_id: str,
    campaign_identifier: str
) -> None:
    """
    Determines the appropriate modeling stream (Clustering, Refactoring, or New Launch) for each Brand x Super Category
    targeted in campaigns, and outputs both campaign selection results and proxy brand mappings.

    This function orchestrates campaign routing logic based on sales, modeling history, and campaign metadata.
    It classifies Brand x Super Category combinations using binary flags and decision rules, and identifies proxy brands
    for new launches to support downstream baseline estimation.

    Flags Logic:
    ------------------------
    - FLAG: 1 if no UCM run in the last 90 days for the Brand x Super Category, else 0.
    - NEW_LAUNCH_FLAG: 1 if the Brand x Super Category qualifies as a new launch, else 0.
    - REFACTOR_SKU_FLAG: 1 if at least one SKU in the Brand x Super Category is not in the clustering table, else 0.

    Modeling Stream Assignment Logic:
    ---------------------------------
    - 'NEW_LAUNCH': NEW_LAUNCH_FLAG = 1, i.e. SKU has sales in either first or last 52 weeks of a 104-week modeling period.
    - 'REFACTORING': LOAD_TS is not null, FLAG = 0, REFACTOR_SKU_FLAG = 1, and NEW_LAUNCH_FLAG = 0.
    - 'CLUSTERING': All other cases not classified as above.

    Confluence: https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/834307869/Campaign+Selection+Python

    :param spark: The SparkSession object.
    :param unified_campaign_path: The S3 path for the unified_campaign table.
    :param item_brand_hist_path: The S3 path for the item_brand_hist table (item_cd to brand/category mapping).
    :param measurement_marketing_channel_hierarchy_path: The S3 path with hierarchy codes with in_scope_flag = true AND measurement_campaign_ready = true
    :param output_path_campaign_selection: The S3 path where the campaign selection output will be saved.
    :param manual_run_flag: Boolean flag to indicate manual execution with specific campaigns.
    :param manual_campaign_list: List of campaign IDs to include when manual_run_flag is True.
    :param slack_topic_arn: The ARN of the Slack topic for notifications.
    :param correlation_id: Unique identifier for the pipeline run, used for logging.
    :param campaign_identifier: Either "JOB_BAG_NUMBER" or "BOOKING_ID".
    :return: None
    """
    print("manual_campaign_list: ", manual_campaign_list)

    # Determine which path to take
    campaign_identifier = campaign_identifier.upper()

    # Read input data from S3 paths
    unified_campaign_df = (
        spark
        .read
        .parquet(unified_campaign_path)
        .select(
            "campaign_id",
            "job_bag_number",
            "booking_id",
            "marketing_type",
            "marketing_hierarchy_cd",
            "campaign_status",
            "load_ts",
            "media_spend_amt",
            "channel_name",
            "subchannel_name",
            "super_category_name",
            "sub_category_name",
            "unique_brand_name",
            "item_cd_list",
            "campaign_start_dt",
            "campaign_end_dt",
            "post_campaign_dt"
        )
    )

    # unique_brand_name, super_category_name and sub_category_name are resolved per item_cd from
    # item_brand_hist, so no dependency on unified_product/campaign_product_type is needed
    item_brand_hist_df = (
        spark
        .read
        .parquet(item_brand_hist_path)
        .select(
            F.col("item_cd").cast("string").alias("item_cd"),
            "unique_brand_name",
            F.col("super_cat_name").alias("super_category_name"),
            F.col("sub_cat_name").alias("sub_category_name"),
        )
        .dropDuplicates(["item_cd", "unique_brand_name", "super_category_name", "sub_category_name"])
    )

    if campaign_identifier == 'JOB_BAG_NUMBER':
        unified_campaign_df = filter_campaigns(
            unified_campaign_df, manual_run_flag, manual_campaign_list, "JOB_BAG_NUMBER"
        )
        # Enrich the unified campaign with aggregated campaign details
        unified_campaign_df = aggregate_media_spend(unified_campaign_df, "job_bag_number")

    else:
        unified_campaign_df = filter_campaigns(
            unified_campaign_df, manual_run_flag, manual_campaign_list, "BOOKING_ID"
        )
        measurement_marketing_channel_hierarchy = (
            spark
            .read
            .parquet(measurement_marketing_channel_hierarchy_path)
            .select(
                "in_scope_flag",
                "measurement_campaign_ready",
                "marketing_hierarchy_cd"
            )
            .filter(
                F.col("in_scope_flag") & F.col("measurement_campaign_ready")
            )
            .select("marketing_hierarchy_cd")
            .distinct()
        )

        unified_campaign_df = unified_campaign_df.join(
            measurement_marketing_channel_hierarchy,
            on=["marketing_hierarchy_cd"],
            how="inner"
        )

        # Enrich the unified campaign with aggregated campaign details
        unified_campaign_df = aggregate_media_spend(unified_campaign_df, "booking_id")

    if unified_campaign_df.count() == 0:
        raise ValueError("Error: no campaigns found to execute!")

    unified_campaign_df = (
        unified_campaign_df
        .select(
            "item_cd_list",
            "min_campaign_start_dt",
            "max_campaign_end_dt",
            "max_post_campaign_dt",
            "total_media_spend",
            "media_spend_by_source",
            "marketing_types",
            "channel_name",
            "subchannel_name",
        )
    )

    # unique_brand_name, super_category_name and sub_category_name are resolved per SKU by
    # exploding item_cd_list and joining to item_brand_hist, rather than trusting the
    # pre-aggregated (and independently deduped/sorted) comma lists on unified_campaign
    campaign_selection_output_df = (
        unified_campaign_df
        .withColumn("item_cd", F.explode_outer(F.split(F.col("item_cd_list"), ",")))
        # trim + drop blank tokens, matching campaign_product_type.sql's handling of the same field
        .withColumn("item_cd", F.trim(F.col("item_cd")))
        .filter(F.col("item_cd") != "")
        .join(item_brand_hist_df, on="item_cd", how="inner")
        .select(
            "unique_brand_name",
            "super_category_name",
            "sub_category_name",
            F.lit("CLUSTERING").alias("final_status"),
            # TODO We might need need to include product type downstream, review dependency and delete if not needed
            F.lit("offer").alias("product_type"),
            "min_campaign_start_dt",
            "max_campaign_end_dt",
            "max_post_campaign_dt",
            "total_media_spend",
            "media_spend_by_source",
            "marketing_types",
            "channel_name",
            "subchannel_name",
        )
        .dropDuplicates([
            "unique_brand_name",
            "super_category_name",
            "sub_category_name",
            "final_status",
            "product_type",
            "min_campaign_start_dt",
            "max_campaign_end_dt",
            "max_post_campaign_dt",
            "total_media_spend",
            "channel_name",
            "subchannel_name",
        ])
    )

    spark_s3_overwrite(output_path_campaign_selection, campaign_selection_output_df)

    slack_messenger = SlackMessenger(
        topic_arn=slack_topic_arn,
        correlation_id=correlation_id
    )

    if manual_run_flag:
        publish_manually_selected_campaigns(
            spark=spark,
            unified_campaign_path=unified_campaign_path,
            manual_campaign_list=manual_campaign_list,
            slack_messenger=slack_messenger,
            campaign_list_type=campaign_identifier
        )
    publish_brand_modelling_status(
        campaign_selection_output_df=campaign_selection_output_df,
        slack_messenger=slack_messenger,
    )


def entrypoint(spark: SparkSession, command_line_args: Optional[List[str]] = None) -> None:
    parser = ThrowingArgumentParser(description="Prepare Campaign Selection for baseline pipeline.")
    parser.add_argument(
        "--unified-campaign-path",
        type=str,
        required=True,
        help="S3 path for unified_campaign table."
    )
    parser.add_argument(
        "--item-brand-hist-path",
        type=str,
        required=True,
        help="S3 path for item_brand_hist table."
    )
    parser.add_argument(
        "--measurement-marketing-channel-hierarchy-path",
        type=str,
        required=False,
        default=None,
        help="S3 path for measurement marketing channel hierarchy data (required for Pollen pipeline only)."
    )
    parser.add_argument(
        "--output-path-campaign-selection",
        type=str,
        required=True,
        help="S3 path for campaign selection output."
    )
    parser.add_argument(
        "--manual-run-flag",
        type=str,
        required=True,
        default="No",
        help="Flag to indicate manual execution."
    )
    parser.add_argument(
        "--manual-campaign-list",
        type=str,
        default="",
        help="Comma-separated list of campaign IDs for manual run."
    )
    parser.add_argument(
        "--slack-topic-arn",
        type=str,
        required=True,
        help="The ARN of the Slack topic for notifications."
    )
    parser.add_argument(
        "--correlation-id",
        type=str,
        required=True,
        help="The correlation ID for the pipeline run."
    )
    parser.add_argument(
        "--campaign-identifier",
        type=str,
        required=True,
        choices=['JOB_BAG_NUMBER', 'BOOKING_ID'],
        help="Campaign identifier type (JOB_BAG_NUMBER or BOOKING_ID)"
    )

    known_args, _ = parser.parse_known_args(command_line_args)

    campaign_list = [x.strip() for x in known_args.manual_campaign_list.split(",") if x.strip()]

    prepare_campaign_selection(
        spark=spark,
        unified_campaign_path=known_args.unified_campaign_path,
        item_brand_hist_path=known_args.item_brand_hist_path,
        measurement_marketing_channel_hierarchy_path=known_args.measurement_marketing_channel_hierarchy_path,
        output_path_campaign_selection=known_args.output_path_campaign_selection,
        manual_run_flag=str_to_bool(known_args.manual_run_flag),
        manual_campaign_list=campaign_list,
        correlation_id=known_args.correlation_id,
        slack_topic_arn=known_args.slack_topic_arn,
        campaign_identifier=known_args.campaign_identifier
    )


if __name__ == "__main__":
    entrypoint(spark=SparkSession.builder.appName("CampaignSelection").getOrCreate())
