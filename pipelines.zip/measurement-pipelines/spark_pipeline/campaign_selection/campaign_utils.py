from typing import List

from prettytable import PrettyTable
from pyspark.sql import functions as F, SparkSession, DataFrame
from spark_pipeline.utils.slack_utils import SlackMessenger
from spark_pipeline.common.variables import EventType
from spark_pipeline.utils.campaign_selection.constants import POLLEN_CAMPAIGN_TYPE, DTP_CAMPAIGN_TYPE


def truncate_id_smart(id_value: str, start_chars: int = 8, end_chars: int = 4) -> str:
    """Truncate ID showing first N and last M characters for better identification."""
    if id_value and len(id_value) > (start_chars + end_chars + 3):
        return f"{id_value[:start_chars]}...{id_value[-end_chars:]}"
    return id_value


def truncate_text_smart(text_value: str, max_chars: int = 15) -> str:
    """Truncate long text values to keep Slack table payload compact."""
    if not text_value:
        return text_value

    if len(text_value) > max_chars:
        return f"{text_value[:max_chars]}..."
    return text_value


def publish_manually_selected_campaigns(
        spark: SparkSession,
        unified_campaign_path: str,
        manual_campaign_list: List[str],
        slack_messenger: SlackMessenger,
        campaign_list_type: str = POLLEN_CAMPAIGN_TYPE
) -> None:
    """
    Publishes the manually selected campaigns to slack for this run.
    """
    unified_campaign_df = (
        spark
        .read
        .parquet(unified_campaign_path)
        .select(
            "job_bag_number",
            "booking_id",
            "campaign_id",
            "subchannel_name",
            "item_cd_list",
            "channel_name",
            "campaign_name",
            "marketing_type",
            "unique_brand_name"
        )
    )

    if campaign_list_type == DTP_CAMPAIGN_TYPE:
        manually_provided_campaigns = (
            unified_campaign_df
            .filter(F.col('job_bag_number').isin(manual_campaign_list))
            .select(
                "job_bag_number",
                "campaign_id",
                "campaign_name",
                "channel_name",
                "subchannel_name",
                "unique_brand_name",
                "item_cd_list",
                "marketing_type"
            )
        )

        manually_provided_campaigns = (
            manually_provided_campaigns
            .withColumn("brand", F.split(F.col("unique_brand_name"), "\\|").getItem(1))
            .select(
                "job_bag_number",
                "campaign_id",
                "campaign_name",
                "channel_name",
                "subchannel_name",
                "brand",
                "item_cd_list",
                "marketing_type"
            )
            .dropDuplicates()
            .collect()
        )

        table = PrettyTable()
        table.field_names = [
            "job_bag_number",
            "campaign_id",
            "campaign_name",
            "channel_name",
            "subchannel_name",
            "brand",
            "item_cd_list",
            "marketing_type"
        ]
        for row in manually_provided_campaigns:
            table.add_row([
                truncate_id_smart(row.job_bag_number),
                truncate_id_smart(row.campaign_id),
                truncate_text_smart(row.campaign_name),
                row.channel_name,
                row.subchannel_name,
                row.brand,
                truncate_text_smart(row.item_cd_list),
                row.marketing_type
            ])

    else:  # BOOKING_ID
        manually_provided_campaigns = (
            unified_campaign_df
            .filter(F.col('booking_id').isin(manual_campaign_list))
            .select(
                "booking_id",
                "campaign_id",
                "campaign_name",
                "channel_name",
                "subchannel_name",
                "unique_brand_name",
                "item_cd_list",
                "marketing_type"
            )
        )

        manually_provided_campaigns = (
            manually_provided_campaigns
            .withColumn("brand", F.split(F.col("unique_brand_name"), "\\|").getItem(1))
            .select(
                "booking_id",
                "campaign_id",
                "campaign_name",
                "channel_name",
                "subchannel_name",
                "brand",
                "item_cd_list",
                "marketing_type"
            )
            .dropDuplicates()
            .collect()
        )

        table = PrettyTable()
        table.field_names = [
            "booking_id",
            "campaign_id",
            "campaign_name",
            "channel_name",
            "subchannel_name",
            "brand",
            "item_cd_list",
            "marketing_type"
        ]

        for row in manually_provided_campaigns:
            table.add_row([
                truncate_id_smart(row.booking_id),
                truncate_id_smart(row.campaign_id),
                truncate_text_smart(row.campaign_name),
                row.channel_name,
                row.subchannel_name,
                row.brand,
                truncate_text_smart(row.item_cd_list),
                row.marketing_type
            ])

    slack_messenger.send_message(
        event_type=EventType.campaign_selection,
        text=f"For this run {len(manual_campaign_list)} campaign(s) have been selected manually.",
        data={"Here are the details of selected campaigns": f"```\n{table}\n```"},
    )


def publish_brand_modelling_status(
    campaign_selection_output_df: DataFrame,
    slack_messenger: SlackMessenger
) -> None:
    """ Publishes the brand modelling status to slack for this run.
    Args:
        campaign_selection_output_df (DataFrame): DataFrame containing the campaign selection output.
        slack_messenger (SlackMessenger): The Slack messenger instance for sending notifications.
    """

    brand_modelling_status = (
        campaign_selection_output_df
        .groupBy('final_status')
        .agg(F.countDistinct('unique_brand_name').alias('unique_brand_count'))
        .withColumnRenamed('final_status', 'modelling_status')
        .select(
            F.col('modelling_status'),
            F.col('unique_brand_count')
        )
        .dropDuplicates()
    )

    table = PrettyTable()
    table.field_names = [
        "modelling_status",
        "unique_brand_count",
    ]

    for row in brand_modelling_status.collect():
        table.add_row([
            row.modelling_status,
            row.unique_brand_count
        ])
    slack_messenger.send_message(
        event_type=EventType.campaign_selection,
        text="Modelling status for distinct brand for this run is as follows.",
        data={"Modelling status and distinct brands": f"```\n{table}\n```"},
    )
