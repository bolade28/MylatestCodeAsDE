---
name: measurement-initiative-sizing
description: >
  Investigate and size initiatives for the Measurement area using repository,
  Jira and Confluence evidence. Produces separate Engineering and Data Science
  assessments, an overall delivery estimate, confidence level and the evidence
  behind the estimate.
context: fork
---

# Measurement Initiative Sizing

Estimate proposed work for the Measurement area.

This Skill is based on the Core Pollen domain initiative sizing approach, but
Measurement has additional characteristics that must be reflected in the estimate:

- behaviour depends on both code and the data flowing through the pipeline
- changes can have downstream effects across a connected pipeline
- implementation effort is often smaller than the effort required to validate
  and explain the resulting measurements
- new capability frequently requires iteration using real campaign data
- Engineering and Data Science work may be separate but interdependent
- uncertainty is meaningful and must be represented explicitly rather than
  hidden inside a larger estimate

The goal is not to produce artificial precision.

The goal is to produce the best evidence-based estimate possible, explain what
drives it, identify what is knowable versus unknowable, and show what additional
information would materially increase confidence.

---

# Invocation

This Skill may be invoked repeatedly by an orchestration agent.

Each invocation must treat the supplied initiative independently and return a
complete self-contained estimate suitable for direct publication to Confluence.

---

# Sizing scale

## Step 1: estimate the Engineering build in engineer-sprints

Always estimate Engineering effort first in **engineer-sprints**: the total
effort of all engineering work added together, regardless of how many people
do it or how long it takes on the calendar.

Start with the **build estimate**: the planned work identified in the
Engineering investigation, including the planned iteration, validation and
monitoring described under "Methodology readiness and the discovery loop".
Under Low confidence, apply the asymmetric-risk skew (see Confidence) to this
build range.

## Step 2: add the integration and validation allowance

Measurement work almost never goes to plan once it meets real data end to end.
Even when every component works on its own, the team routinely has to:

- investigate and work around data gaps (missing days, late or partial
  upstream loads, booking types with thin or inconsistent data)
- go back and forth with Data Science, upstream teams or stakeholders when
  outputs look wrong or assumptions turn out not to hold
- reconcile end-to-end results that do not add up even though each stage
  passes its own tests (totals that don't match source, double counting
  across channels, mismatched grains or date boundaries)
- rerun, backfill and re-validate after each fix

This rework is a recurring, expected part of Measurement delivery, not a
sign of missing information. It is rarely visible in the planned work, so
add it as a **separate, named allowance** on top of the build estimate.

Size the allowance from the item's confidence level:

| Confidence | Allowance on top of build | Minimum |
|------------|---------------------------|---------|
| High | +10–15% | none |
| Medium | +25–35% | 1 engineer-sprint |
| Low | +40–50% | 2 engineer-sprints |

Adjust within the band using the evidence. Move to the upper end where the
item:

- joins data across several channels, sources or booking types
- depends on upstream data with known quality issues
- needs historical backfill
- produces outputs that must reconcile with existing reported figures

Move to the lower end where the item reads a single, well-understood source
into an existing, proven output path.

If historical Jira evidence shows how far similar items overran, prefer that
evidence over the default percentages and say so.

**Total engineer-sprints = build estimate + allowance.** The total is the
anchor for every Engineering size. The t-shirt size, squad-sprints and
elapsed time are all derived from it. Always report the build, the allowance
and the total separately so the reader can see what the allowance adds.

## Step 3: convert to squad-sprints

**1 squad-sprint = 2 engineer-sprints.**

Measurement work is mostly serial: one step usually has to finish before the
next can start. One engineer typically works on an item at a time, and two at
most when the work can genuinely be split. The divisor of 2 reflects that
realistic working group, not the total headcount of the team.

## Step 4: read the size from the bands

| Size | Engineer-sprints (total effort) | Squad-sprints (engineer-sprints ÷ 2) | Elapsed sprints, 1 engineer (default) | Elapsed sprints, 2 engineers (if parallelisable) |
|------|------|------|------|------|
| XS | up to 3 | up to 1.5 | up to 3 | up to 2 |
| S | 3–6 | 1.5–3 | 3–6 | 2–3 |
| M | 6–10 | 3–5 | 6–10 | 3–5 |
| L | 10–14 | 5–7 | 10–14 | 5–7 |
| XL | more than 14 | more than 7 | more than 14 ⚠️ | more than 7 |

⚠️ An XL item run by a single engineer would take more than about seven months
of calendar time. Always flag XL items as candidates for splitting into smaller
pieces that can be delivered and validated separately. Do not force an XL item
into L.

Where an estimate range straddles two bands, report both (for example "L–XL")
and explain which end is more likely.

## Worked example (calibration anchor)

**Creative and Audience Segment Split Reporting (with CausalML-light)**

- Engineering effort: 16–24 engineer-sprints in total (build plus allowance)
- Squad-sprints: 16–24 ÷ 2 = 8–12
- Size: **XL**
- Elapsed: 16–24 sprints with one engineer; 8–12 sprints with two

Use this as a reference point for the scale of a large, methodology-dependent
Measurement initiative.

## Rules

- Size never changes with headcount. Two engineers finish sooner, but the item
  is the same size.
- Assume one engineer on an item unless there is specific evidence the work can
  be split. State the assumption.
- Do not automatically convert elapsed calendar time into effort.
- Engineering and Data Science may work concurrently.
- Data Science is sized on the same squad-sprint bands. State the DS effort
  behind the size.

Always distinguish:

1. total effort
2. elapsed delivery time
3. external/dependency wait time

---

# Methodology readiness and the discovery loop

Assume every item is NEW by default (no validated measurement method exists
yet), unless the item is clearly stated to be otherwise. Only downgrade the
readiness if there is explicit evidence, for example an existing validated
method that already produces results.

Readiness levels, for reference:

| Readiness | Meaning |
|-----------|---------|
| Not required | No methodology involved; data is read and surfaced as is |
| Established | A validated method already exists and has produced results |
| Extension | An existing validated method is adapted to a new case |
| New (default) | No validated method exists yet |

Because items default to New, apply the following unless told otherwise:

- The engineering build sprints are a PLACEHOLDER at Low confidence, not a firm
  estimate. A real build estimate is only possible once Data Science has a
  validated method.
- Add 2–4 engineering SUPPORT sprints for the discovery phase: data
  availability checks and supplying real data at the grain Data Science needs,
  across all booking types, so they can validate the approach everywhere.
- The engineering figure must include real-data iteration, validation and
  post-live monitoring, not only the initial build. These are usually the
  largest part of Measurement effort and are commonly under-counted.
- Discovery is timeboxed to two cycles; after that the item returns to
  leadership to continue, rescope, pause or drop.
- Support work is spread out, not continuous: it moves at Data Science's pace,
  so elapsed time is much longer than the sprint figure suggests.

If the engineer-sprint estimate does not include iteration, validation and
monitoring, it is under-scoped. Raise it and explain which activities were
added.

---

# Required output

Produce:

## Executive assessment

**Engineering:** <XS / S / M / L / XL> — <total engineer-sprints> (<squad-sprints>); build <x> + allowance <y>  
**Data Science:** <XS / S / M / L / XL / N/A>  
**Overall effort:** <XS / S / M / L / XL>  
**Likely elapsed delivery:** <estimate or range, stating 1 or 2 engineers assumed>  
**Confidence:** <High / Medium / Low>

**Summary:**  
<2-4 sentences explaining the assessment and dominant sizing factors>

---

## Delivery topology

Classify the work before sizing it.

Examples:

- refactoring / operational improvement
- isolated pipeline change
- new data source
- new channel integration
- measurement methodology change
- data model/schema change
- cross-pipeline change
- infrastructure/platform change
- investigation / discovery
- mixed Engineering + Data Science capability

State:

- where the change enters the system
- which pipeline stages it touches
- what consumes its output
- whether pipeline behaviour changes
- whether expected output is known in advance
- whether real-data iteration is required

---

# Measurement estimation principles

## 1. Size impact, not lines of code

A small code change may create significant Measurement effort.

Determine:

- which pipeline components change
- downstream components affected
- data contracts affected
- metrics affected
- validation required
- consumers affected

Do not use file count, PR size or apparent code complexity as the primary
sizing signal.

---

## 2. Determine whether expected output is known

This is one of the strongest sizing signals.

### Known output

Examples:

- refactoring
- dependency upgrades with identical behaviour
- operational improvements
- readability/maintainability improvements
- infrastructure changes intended to preserve outputs

Expected result:

> outputs should remain equivalent to the current system

These items can generally be estimated with higher confidence.

### Unknown output

Examples:

- new channel
- new data source
- new measurement capability
- model or methodology changes
- changes that may affect incrementality results

Expected result:

> behaviour cannot be fully established until real data passes through the system

These require explicit allowance for investigation and iteration.

---

## 3. Investigate the iteration loop

For changes where output behaviour is not known upfront, identify the likely
iteration cycle.

A typical cycle may involve:

1. implement or configure the change
2. run real campaign/data through the pipeline
3. inspect resulting metrics
4. determine whether unexpected behaviour comes from:
   - upstream data
   - code/transformation logic
   - model behaviour
   - non-determinism or instability
   - genuine real-world effects
5. involve Data Science where appropriate
6. adjust
7. rerun
8. revalidate

Do not pretend the exact number of iterations is knowable where evidence says
otherwise.

Instead state the assumption used, for example:

> Estimate assumes 1-2 investigation/iteration cycles.

or:

> Iteration count is currently unknowable; this is the dominant reason for Low
> confidence.

---

# Evidence gathering

Use evidence rather than intuition wherever possible.

Investigate the following sources.

## GitHub

Use the GitHub MCP.

Start with repositories known to contain Measurement implementation:

- `sainsburys-tech/measurement-pipelines`
- `sainsburys-tech/measurement-dags`
- `sainsburys-tech/measurement-terraform`

Also inspect other repositories when the initiative crosses a boundary.

Do not assume the initial repository list is exhaustive.

Search for:

- implementation of the affected feature
- neighbouring pipeline components
- upstream/downstream integrations
- schemas and contracts
- orchestration/DAGs
- infrastructure
- tests
- monitoring/alerting
- configuration
- similar historical changes
- PRs linked to relevant Jira items
- ownership patterns

Prefer evidence from code and merged PRs over assumptions.

---

## DAG dependencies (`measurement-dags`)

Always inspect https://github.com/sainsburys-tech/measurement-dags to size
orchestration and dependency work, even when the main change is in
`measurement-pipelines`.

### Data ingestion

All source data enters Measurement through the SQL templates in
https://github.com/sainsburys-tech/measurement-dags/tree/main/dags/templates/sql.

For every initiative, check whether it:

- needs a new SQL template or a change to an existing one (new source, columns,
  filters, joins or grain)
- changes the Snowflake tables read or the S3 stage/path written
- touches templates shared by baseline and MTA, which widens validation scope
- depends on upstream Snowflake tables owned by another team
- needs a Pollen or production-emulation variant of the template

### DAG wiring

Trace the affected SQL templates to the tasks that run them:

- `dags/task_groups/` - task groups and their upstream/downstream order
- `dags/steps/` - EMR steps that pass S3 paths and arguments to Spark jobs
- `dags/helpers/paths.py` and `dags/helpers/tables.py` - shared S3 paths and
  table names
- top-level DAGs that run the task group (for example `baseline_mta_dag.py`,
  `daily_etl_dag.py`)
- `tests/` - DAG, step and SQL-template tests, including expected SQL output

Record:

- which SQL templates, DAGs and task groups change
- new or changed task dependencies and any changes to run order
- downstream tasks and Spark jobs that consume the changed output
- schedule or cadence differences (daily ETL vs pipeline runs)
- DAG, step and SQL-template tests to add or update

Size ingestion and DAG work as part of the Engineering build estimate.

---

## Jira

Use the Atlassian MCP.

Investigate:

- the initiative / epic being estimated
- its parent and children
- linked tickets
- historical tickets touching the same components
- previous implementations of similar capabilities
- bugs or incidents associated with the relevant pipeline
- investigation/spike tickets
- Engineering work
- Data Science work
- analytics or validation work
- dependencies on other teams

Do not infer effort from historic Jira duration alone.

Measurement work is often non-repeating and historical items may have very
different investigation loops.

Use history primarily to understand:

- work involved
- hidden activities
- dependencies
- recurring implementation patterns
- validation requirements

rather than simply calculating an average duration.

---

## Confluence

Use the Atlassian MCP.

Start exploration from:

https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/1922663655/Table+of+Contents

Follow links relevant to the initiative.

Look particularly for:

- Measurement architecture
- pipeline/data-flow documentation
- methodology documentation
- data sources
- output metrics
- operational processes
- validation approaches
- previous designs
- known limitations
- team ownership
- dependencies
- estimation/elaboration guidance

Do not recursively read unrelated areas.

---

# Engineering investigation

Assess Engineering effort across the areas below and express it as a build
estimate in engineer-sprints. Then add the integration and validation
allowance (see Sizing scale, Step 2) before converting to a size.

These areas describe the PLANNED work. Unplanned rework from data gaps,
back-and-forth and end-to-end reconciliation belongs in the allowance, not
here, so that it is visible and counted once.

### Pipeline implementation

- ingestion
- transformation
- orchestration
- storage
- output/publishing
- interfaces/contracts

### Data impact

- input schema changes
- output schema changes
- transformations
- joins
- assumptions about shape/quality
- historical data/backfills
- downstream compatibility

### Operational work

- monitoring
- alerting
- logging
- failure handling
- retries
- data-quality controls
- deterministic behaviour
- production support

### Testing and validation

- automated tests
- integration tests
- pipeline validation
- comparison against existing outputs
- production/real-data validation

### Infrastructure

- Terraform/cloud resources
- permissions
- secrets
- scheduling
- environments
- deployment

---

# Data Science investigation

Determine whether Data Science is:

- not required
- providing review/sign-off
- performing investigation
- modifying models/methodology
- validating statistical behaviour
- analysing campaign results
- supporting multiple iteration cycles

Assess:

### Methodology impact

Does the change affect:

- incrementality
- controls
- attribution/measurement methodology
- modelling assumptions
- statistical interpretation
- confidence or explainability of results?

### Validation

What evidence is needed before the team can stand behind the resulting metrics?

Look for:

- historical comparisons
- campaign-level analysis
- statistical validation
- investigation of unexpected movement
- model behaviour
- stability/determinism
- peer review

### Iteration

Estimate the Data Science effort associated with each likely iteration rather
than counting only the final review.

---

# Dependencies

Explicitly identify work dependent on:

- Data Science capacity
- upstream data teams
- Analytics
- external providers
- Core Pollen
- platform/infrastructure teams
- stakeholder/client sign-off

For each dependency distinguish:

**Effort** — work Measurement must perform

from

**Elapsed dependency time** — time spent waiting on another party.

Do not include elapsed dependency wait time in squad-equivalent effort. Count only Measurement work performed during the wait as effort, and report wait time separately when estimating elapsed delivery, accounting for any overlap.

---

# Historical comparison

Find historical examples where they genuinely help.

For each useful analogue record:

- Jira / PR
- why it is comparable
- important differences
- Engineering work involved
- Data Science work involved
- investigation/iteration involved
- elapsed time if reliable

Never say:

> Ticket X took 4 weeks therefore this is 4 weeks.

Instead say:

> Ticket X demonstrates that this type of change involved ingestion,
> downstream transformation and two rounds of DS validation. Those activities
> are also present here.

Historical evidence should explain the shape of the work, not create false
precision.

---

# Avoid double-counting

A component appearing in several perspectives does not create several pieces
of work.

For example:

- a schema change
- downstream transformation work
- validation of that transformed data

may describe one connected delivery path.

Explain the implementation areas, then size the actual work once.

Also distinguish team ownership from implementation effort.

Do not count the same rework twice. Planned validation and iteration belong in
the build estimate; unplanned rework (data gaps, back-and-forth, end-to-end
results that don't reconcile) belongs in the integration and validation
allowance. If a specific rework risk is already sized as named build work,
take the allowance from the lower end of its band and say why.

A component owned by another team is not automatically effort for Measurement.

---

# Confidence

Every estimate must include confidence.

## High

Use where:

- implementation path is understood
- affected components are known
- expected output is known
- dependencies are understood
- little or no open-ended real-data iteration exists

## Medium

Use where:

- broad implementation is understood
- some pipeline/data impact remains uncertain
- iteration is likely but reasonably bounded
- one or more dependencies could alter the estimate

## Low

Use where:

- expected behaviour cannot be known until real data is processed
- affected pipeline scope is unclear
- methodology impact is unresolved
- number of investigation loops is highly uncertain
- important external dependencies are unresolved

Low confidence is directional.

It generally means:

> there is greater risk of the initiative taking longer than the central
> estimate, rather than an equal chance of it taking less time.

## Low confidence and the estimate (asymmetric risk)

When confidence is Low, the range of outcomes is not symmetric. Uncertain
Measurement work is far more likely to run longer than the naive mid-point
than to come in shorter, because of iteration loops, real-data surprises and
unresolved methodology.

Therefore, under Low confidence:

- Report the engineer-sprint estimate as a range.
- Place the central figure towards the UPPER end of that range, not the
  middle, because the risk is directional (more likely to overrun).
- Do NOT inflate the size to compensate for missing information. The skew
  reflects genuine asymmetric risk, not padding. If the size is only large
  because information is missing, say so under "What would increase
  confidence" instead.

State the skew explicitly, for example:

> Plausible range 16–24 engineer-sprints. Given Low confidence and asymmetric
> risk, the central estimate is taken at ~22 rather than the mid-point.

---

# Missing information

When evidence is insufficient, do not silently compensate by increasing the
size.

The integration and validation allowance is not compensation for missing
information. It covers rework that happens on Measurement items even when the
scope is well understood, and it is always shown as its own figure. Gaps in
evidence still go under "What would increase confidence".

Produce:

## What would increase confidence

List only questions whose answers could materially change:

- Engineering size
- Data Science size
- overall size
- delivery topology
- iteration assumption

For each question state why it matters.

Example:

> **Will historical data require backfilling?**  
> If yes, this introduces additional pipeline execution, validation and
> potentially DS analysis and could move Engineering from S to M.

---

# Final response format

## Measurement initiative: <name>

## Executive assessment

| | Assessment |
|---|---|
| Engineering | **<size> — <total engineer-sprints> (<squad-sprints>)**; build <range> + allowance <range>; central ~<n> |
| Data Science | **<size> — <DS squad-sprints>** |
| Overall effort | **<size> — <squad-sprints>** |
| Likely elapsed delivery | **<range> (<1 or 2> engineers, DS concurrent or not)** |
| Confidence | **<High / Medium / Low>** |

Every value in this table must be derived from this item's own evidence. Do
not reuse figures from the worked example or from previous runs.

Overall effort sums Engineering and Data Science effort; parallel work affects elapsed delivery, not total effort.

**Summary:**

<short explanation>

### Delivery topology

<what kind of change this is and where it travels through the system>

### Engineering work

**Build (planned work):**

- ...
- ...
- ...

**Integration and validation allowance:** <percentage applied, resulting
engineer-sprints, and the item-specific reasons it sits at the lower or upper
end of the band: data gaps, upstream dependencies, cross-channel joins,
backfill, reconciliation with existing figures>

### Data Science work

- ...
- ...
- ...

### Iteration assumption

<expected real-data validation / investigation loops and why>

### Dependencies

- ...

### Evidence

#### GitHub
- <repo / code / PR evidence>

#### Jira
- <issues / historical analogues>

#### Confluence
- <relevant architecture/design/methodology material>

### Main uncertainties

- ...

### What would increase confidence

1. ...
2. ...

### Sizing rationale

Show the calculation: build engineer-sprints + integration and validation
allowance = total engineer-sprints → squad-sprints (÷ 2) → size band. State whether one or two engineers were assumed for elapsed time.

Explain why this belongs in the selected size band and what would move it
up or down. If the item is XL, say whether and how it could be split.

Do not manufacture precision beyond the available evidence.
