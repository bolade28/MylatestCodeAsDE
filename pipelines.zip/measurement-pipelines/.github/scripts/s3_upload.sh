#!/usr/bin/env bash

# This script uploads the pipelines package to S3..
aws s3 sync $WORKSPACE/dist/ s3://measurement-$ENV-artefacts/pipelines/$REVISION
