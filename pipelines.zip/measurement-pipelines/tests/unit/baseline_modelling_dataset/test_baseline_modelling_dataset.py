import os
from datetime import datetime
from unittest import mock

from typing import List
from chispa.dataframe_comparer import assert_df_equality
from pyspark.sql import Row, SparkSession

from spark_pipeline.baseline_modelling_dataset.baseline_modelling_dataset import (
    prepare_baseline_modelling_dataset,
    entrypoint,
    apply_post_period_clamping,
)
from spark_pipeline.common.variables import CampaignDurations
from spark_pipeline.schemas.baseline_modelling_dataset import BaselineModellingDataset

from pyspark.sql.types import StructType

from unittest.mock import patch

# TODO:: replace this with chispa in future


def compare_schemas(df_schema: StructType, expected_schema: StructType) -> List[str]:
    mismatches = []

    df_fields = {field.name: field for field in df_schema.fields}
    expected_fields = {field.name: field for field in expected_schema.fields}

    # Check for missing or mismatched fields
    for name, expected_field in expected_fields.items():
        if name not in df_fields:
            mismatches.append(f"Missing field in DataFrame: {name}")
        else:
            actual_field = df_fields[name]
            if actual_field.dataType != expected_field.dataType:
                mismatches.append(
                    f"Data type mismatch for '{name}': expected {expected_field.dataType}, got {actual_field.dataType}"
                )
            if actual_field.nullable != expected_field.nullable:
                mismatches.append(
                    f"Nullability mismatch for '{name}': expected nullable={expected_field.nullable}, got nullable={actual_field.nullable}"
                )

    # Check for extra fields in df that are not in expected schema
    for name in df_fields:
        if name not in expected_fields:
            mismatches.append(f"Unexpected extra field in DataFrame: {name}")

    return mismatches


def test_prepare_sales_process_data(spark_session: SparkSession, tmpdir: str):
    weekly_dates_path = os.path.join(tmpdir, "weekly_dates.parquet")
    channel_processed_data_path = os.path.join(tmpdir, "channel_processed_data.parquet")
    three_letter_coding_path = os.path.join(tmpdir, "three_letter_coding.parquet")
    campaign_selection_path = os.path.join(tmpdir, "campaign_selection.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")
    run_date = "2024-01-01"
    correlation_id = "corr-123"

    # test data
    # weekly_dates_df
    spark_session.createDataFrame([
        Row(week_start_dt="2024-01-01"),
        Row(week_start_dt="2024-01-08"),
    ]).write.parquet(weekly_dates_path)
    # 2. channel_processed_data_df
    ts = datetime.now()
    spark_session.createDataFrame([
        Row(
            week_start_dt="2023-12-25",
            metric_value=123.45,
            super_category_name="Snacks",
            unique_brand_name="BrandX",
            cluster_num="C1",
            marketing_type_name="Digital",
            marketing_channel_name="Social",
            marketing_sub_channel_name="Instagram",
            metric_name="Impressions",
            job_run_id="job-001",
            load_ts=ts
        ),
        Row(
            week_start_dt="2024-01-08",
            metric_value=678.90,
            super_category_name="Beverages",
            unique_brand_name="BrandY",
            cluster_num="C2",
            marketing_type_name="TV",
            marketing_channel_name="Broadcast",
            marketing_sub_channel_name="PrimeTime",
            metric_name="Reach",
            job_run_id="job-002",
            load_ts=ts
        )
    ]).write.mode("overwrite").parquet(channel_processed_data_path)

    # 3. three_letter_coding_df
    spark_session.createDataFrame([
        Row(column_name="SUPER_CATEGORY_NAME", original_column_value="Snacks", final_code="SNC"),
        Row(column_name="UNIQUE_BRAND_NAME", original_column_value="BrandX", final_code="BRX"),
        Row(column_name="CLUSTER_NUM", original_column_value="C1", final_code="CL1"),
        Row(column_name="MARKETING_TYPE_NAME", original_column_value="Digital", final_code="DGT"),
        Row(column_name="MARKETING_CHANNEL_NAME", original_column_value="Social", final_code="SOC"),
        Row(column_name="MARKETING_SUB_CHANNEL_NAME", original_column_value="Instagram", final_code="IGM"),
        Row(column_name="METRIC_NAME", original_column_value="Impressions", final_code="IMP")
    ]).write.mode("overwrite").parquet(three_letter_coding_path)

    # 4. campaign_selection_df
    spark_session.createDataFrame([
        Row(
            unique_brand_name="BrandX",
            super_category_name="Snacks",
            max_campaign_end_dt="2024-01-03",
            marketing_types=["Digital"],
        )
    ]).write.mode("overwrite").parquet(campaign_selection_path)

    with patch(
        "spark_pipeline.baseline_modelling_dataset.baseline_modelling_dataset.spark_s3_overwrite"
    ) as mock_s3_write:

        def fake_s3_write(path, df):
            df.write.mode("overwrite").parquet(path)

        mock_s3_write.side_effect = fake_s3_write
        prepare_baseline_modelling_dataset(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            channel_processed_data_path=channel_processed_data_path,
            three_letter_coding_path=three_letter_coding_path,
            output_path=output_path,
            campaign_selection_path=campaign_selection_path,
            run_date=run_date,
            correlation_id=correlation_id,
            campaign_period=CampaignDurations.CAMPAIGN_DURATION_DURING,
        )

    actual_df = spark_session.read.parquet(output_path)
    assert actual_df.count() > 0
    assert compare_schemas(actual_df.schema, BaselineModellingDataset.baseline_modelling_dataset_final_schema) == []


def test_entrypoint(monkeypatch):
    mock_spark = mock.Mock()

    args = [
        "--weekly-dates-path", "weekly_dates_path",
        "--channel-processed-data-path", "channel_processed_data_path",
        "--three-letter-coding-path", "three_letter_coding_path",
        "--output-path", "output_path",
        "--campaign-selection-path", "campaign_selection_path",
        "--run-date", "2024-01-01",
        "--correlation-id", "corr-123",
        "--campaign-period", CampaignDurations.CAMPAIGN_DURATION_DURING,
    ]

    with mock.patch(
            "spark_pipeline.baseline_modelling_dataset.baseline_modelling_dataset.prepare_baseline_modelling_dataset") as mock_func:
        entrypoint(spark=mock_spark, command_line_args=args)

        mock_func.assert_called_once_with(
            spark=mock_spark,
            weekly_dates_path="weekly_dates_path",
            channel_processed_data_path="channel_processed_data_path",
            three_letter_coding_path="three_letter_coding_path",
            output_path="output_path",
            campaign_selection_path="campaign_selection_path",
            run_date="2024-01-01",
            correlation_id="corr-123",
            campaign_period=CampaignDurations.CAMPAIGN_DURATION_DURING,
        )


def test_apply_post_period_clamping_sets_metric_value_to_zero_after_cutoff(spark_session: SparkSession, tmpdir: str):
    campaign_selection_path = os.path.join(tmpdir, "campaign_selection.parquet")

    baseline_input_df = spark_session.createDataFrame([
        Row(
            week_start_dt="2024-01-08",
            metric_value=10.0,
            unique_brand_name="BrandA",
            super_category_name="CatA",
            marketing_type_name="Digital",
        ),
        Row(
            week_start_dt="2024-01-15",
            metric_value=20.0,
            unique_brand_name="BrandA",
            super_category_name="CatA",
            marketing_type_name="Digital",
        ),
        Row(
            week_start_dt="2024-01-15",
            metric_value=30.0,
            unique_brand_name="BrandA",
            super_category_name="CatA",
            marketing_type_name="TV",
        ),
    ])

    spark_session.createDataFrame([
        Row(
            unique_brand_name="BrandA",
            super_category_name="CatA",
            max_campaign_end_dt="2024-01-10",
            marketing_types=["Digital"],
        )
    ]).write.mode("overwrite").parquet(campaign_selection_path)

    with patch(
        "spark_pipeline.baseline_modelling_dataset.baseline_modelling_dataset.BaselineModellingDataSetConfig"
    ) as mock_config:
        mock_config.return_value.post_period_clamped_marketing_types = ["Digital"]
        mock_config.return_value.post_period_clamped_marketing_type_names = ["Digital"]

        actual_df = apply_post_period_clamping(
            spark=spark_session,
            baseline_modelling_dataset_df=baseline_input_df,
            campaign_selection_path=campaign_selection_path,
        )
        expected_df = spark_session.createDataFrame(
            [
                ("2024-01-08", 10.0, "BrandA", "CatA", "Digital"),
                ("2024-01-15", 0.0, "BrandA", "CatA", "Digital"),
                ("2024-01-15", 30.0, "BrandA", "CatA", "TV"),
            ],
            schema=baseline_input_df.schema,
        )
        assert_df_equality(
            actual_df.select("week_start_dt", "marketing_type_name", "metric_value", "unique_brand_name", "super_category_name"),
            expected_df,
            ignore_row_order=True,
            ignore_column_order=True,
        )
