import os
import json
from unittest import mock
from datetime import date
from pyspark.sql import Row, SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType, DateType
from spark_pipeline.youtube_normalise.youtube_normalise_pollen import (
    youtube_normalize_pipeline,
)


def test_youtube_normalize_pipeline_basic(spark_session: SparkSession, tmpdir: str):
    """Test basic functionality of YouTube normalize pipeline"""
    # Setup file paths
    source_table_path = os.path.join(tmpdir, "source_table.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")
    spark_session.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")

    # Test constants
    booking_id = "BK001"
    campaign_id = "CP001"
    item_cd_1 = "ITEM001"
    item_cd_2 = "ITEM002"
    correlation_id = "test-corr-id"

    # Create source data with valid YouTube campaigns
    source_data = [
        Row(
            booking_id=booking_id,
            campaign_id=campaign_id,
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": item_cd_1}, {"skuId": item_cd_2}])
        ),
        Row(
            booking_id="BK002",
            campaign_id="CP002",
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 5),
            booking_media_live_end_dt=date(2024, 1, 10),
            item_cd_list=json.dumps([{"skuId": "ITEM003"}])
        )
    ]

    spark_session.createDataFrame(source_data).write.mode("overwrite").parquet(source_table_path)

    # Run the function
    youtube_normalize_pipeline(
        spark=spark_session,
        source_table_path=source_table_path,
        output_path=output_path,
        correlation_id=correlation_id
    )

    # Verify the output
    actual_df = spark_session.read.parquet(output_path)

    # Basic validations
    assert actual_df.count() > 0, "Output should not be empty"

    # Check that we have the expected columns
    expected_columns = {
        "campaign_id", "start_dt", "end_dt", "item_cd",
        "booking_id", "jobbagid", "channel", "CAST(test-corr-id AS STRING)", "load_ts"
    }
    assert set(actual_df.columns) == expected_columns, f"Column mismatch. Expected: {expected_columns}, Got: {set(actual_df.columns)}"

    # Check that we have records for all SKUs
    item_codes = {row.item_cd for row in actual_df.select("item_cd").collect()}
    expected_item_codes = {item_cd_1, item_cd_2, "ITEM003"}
    assert item_codes == expected_item_codes, f"Item codes mismatch. Expected: {expected_item_codes}, Got: {item_codes}"

    # Check that channel is set correctly
    channels = {row.channel for row in actual_df.select("channel").distinct().collect()}
    assert channels == {"Youtube"}, f"Channel should be 'Youtube', got: {channels}"

    # Check correlation ID
    correlation_ids = {getattr(row, "CAST(test-corr-id AS STRING)") for row in actual_df.select("CAST(test-corr-id AS STRING)").distinct().collect()}
    assert correlation_ids == {correlation_id}, f"Correlation ID mismatch. Expected: {correlation_id}, Got: {correlation_ids}"

    # Check that jobbagid is set to "NA"
    jobbagids = {row.jobbagid for row in actual_df.select("jobbagid").distinct().collect()}
    assert jobbagids == {"NA"}, f"jobbagid should be 'NA', got: {jobbagids}"

    # Check that load_ts is populated
    assert actual_df.filter(col("load_ts").isNull()).count() == 0, "load_ts should not be null"

    # Check that no duplicates exist
    unique_count = actual_df.distinct().count()
    total_count = actual_df.count()
    assert unique_count == total_count, f"Duplicates found. Unique: {unique_count}, Total: {total_count}"

    print(f"Basic test passed! Generated {actual_df.count()} rows")


def test_youtube_normalize_pipeline_filtering(spark_session: SparkSession, tmpdir: str):
    """Test that filtering works correctly - only valid campaigns are included"""
    # Setup file paths
    source_table_path = os.path.join(tmpdir, "source_table.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")
    spark_session.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")

    # Create source data with both valid and invalid campaigns
    source_data = [
        # Valid campaign
        Row(
            booking_id="BK001",
            campaign_id="CP001",
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": "ITEM001"}])
        ),
        # Invalid: wrong channel_type
        Row(
            booking_id="BK002",
            campaign_id="CP002",
            channel_type="ONSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": "ITEM002"}])
        ),
        # Invalid: wrong media_provider
        Row(
            booking_id="BK003",
            campaign_id="CP003",
            channel_type="OFFSITE",
            media_provider="FACEBOOK",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": "ITEM003"}])
        ),
        # Invalid: wrong booking_status
        Row(
            booking_id="BK004",
            campaign_id="CP004",
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="PENDING",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": "ITEM004"}])
        ),
        # Invalid: wrong business group
        Row(
            booking_id="BK005",
            campaign_id="CP005",
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="TESCO",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": "ITEM005"}])
        ),
        # Invalid: empty item_cd_list
        Row(
            booking_id="BK006",
            campaign_id="CP006",
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list="[]"
        ),
        # Invalid: null item_cd_list
        Row(
            booking_id="BK007",
            campaign_id="CP007",
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=None
        )
    ]

    spark_session.createDataFrame(source_data).write.mode("overwrite").parquet(source_table_path)

    # Run the function
    youtube_normalize_pipeline(
        spark=spark_session,
        source_table_path=source_table_path,
        output_path=output_path,
        correlation_id="test-corr-id"
    )

    # Verify the output
    actual_df = spark_session.read.parquet(output_path)

    # Should only have 1 valid campaign
    assert actual_df.count() == 1, f"Expected 1 row, got {actual_df.count()}"

    # Check that only the valid campaign made it through
    campaign_ids = {row.campaign_id for row in actual_df.select("campaign_id").collect()}
    assert campaign_ids == {"CP001"}, f"Expected only CP001, got: {campaign_ids}"

    item_codes = {row.item_cd for row in actual_df.select("item_cd").collect()}
    assert item_codes == {"ITEM001"}, f"Expected only ITEM001, got: {item_codes}"

    print("Filtering test passed!")


def test_youtube_normalize_pipeline_multiple_skus_same_campaign(spark_session: SparkSession, tmpdir: str):
    """Test that campaigns with multiple SKUs are properly exploded"""
    # Setup file paths
    source_table_path = os.path.join(tmpdir, "source_table.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")
    spark_session.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")

    # Create source data with campaign having multiple SKUs
    source_data = [
        Row(
            booking_id="BK001",
            campaign_id="CP001",
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([
                {"skuId": "ITEM001"},
                {"skuId": "ITEM002"},
                {"skuId": "ITEM003"}
            ])
        )
    ]

    spark_session.createDataFrame(source_data).write.mode("overwrite").parquet(source_table_path)

    # Suppress the print outputs by mocking
    with mock.patch('builtins.print'):
        # Run the function
        youtube_normalize_pipeline(
            spark=spark_session,
            source_table_path=source_table_path,
            output_path=output_path,
            correlation_id="test-corr-id"
        )

    # Verify the output
    actual_df = spark_session.read.parquet(output_path)

    # Should have 3 rows (one per SKU)
    assert actual_df.count() == 3, f"Expected 3 rows, got {actual_df.count()}"

    # Check that all SKUs are present
    item_codes = {row.item_cd for row in actual_df.select("item_cd").collect()}
    expected_item_codes = {"ITEM001", "ITEM002", "ITEM003"}
    assert item_codes == expected_item_codes, f"Item codes mismatch. Expected: {expected_item_codes}, Got: {item_codes}"

    # Check that all rows have the same campaign_id and booking_id
    campaign_ids = {row.campaign_id for row in actual_df.select("campaign_id").distinct().collect()}
    booking_ids = {row.booking_id for row in actual_df.select("booking_id").distinct().collect()}
    assert campaign_ids == {"CP001"}, f"Expected only CP001, got: {campaign_ids}"
    assert booking_ids == {"BK001"}, f"Expected only BK001, got: {booking_ids}"

    print("Multiple SKUs test passed!")


def test_youtube_normalize_pipeline_grouping_and_deduplication(spark_session: SparkSession, tmpdir: str):
    """Test that grouping by booking_id, campaign_id, item_cd works correctly"""
    # Setup file paths
    source_table_path = os.path.join(tmpdir, "source_table.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")
    spark_session.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")

    # Create source data with duplicate campaigns (same booking_id, campaign_id, item_cd)
    source_data = [
        # First instance
        Row(
            booking_id="BK001",
            campaign_id="CP001",
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": "ITEM001"}])
        ),
        # Duplicate with different start_dt (should take max)
        Row(
            booking_id="BK001",
            campaign_id="CP001",
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS",
            booking_media_live_start_dt=date(2024, 1, 3),  # Later date
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": "ITEM001"}])
        )
    ]

    spark_session.createDataFrame(source_data).write.mode("overwrite").parquet(source_table_path)

    # Run the function
    youtube_normalize_pipeline(
        spark=spark_session,
        source_table_path=source_table_path,
        output_path=output_path,
        correlation_id="test-corr-id"
    )

    # Verify the output
    actual_df = spark_session.read.parquet(output_path)

    # Should have only 1 row after deduplication
    assert actual_df.count() == 1, f"Expected 1 row after deduplication, got {actual_df.count()}"

    # Check that the max start_dt was selected
    start_dt = actual_df.select("start_dt").collect()[0].start_dt
    assert start_dt == "2024-01-03", f"Expected max start_dt 2024-01-03, got: {start_dt}"

    print("Grouping and deduplication test passed!")


def test_youtube_normalize_pipeline_empty_input(spark_session: SparkSession, tmpdir: str):
    """Test behavior with empty input data"""
    # Setup file paths
    source_table_path = os.path.join(tmpdir, "source_table.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")
    spark_session.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")

    # Create empty source data with correct schema
    schema = StructType([
        StructField("booking_id", StringType(), True),
        StructField("campaign_id", StringType(), True),
        StructField("channel_type", StringType(), True),
        StructField("media_provider", StringType(), True),
        StructField("booking_status", StringType(), True),
        StructField("media_business_group", StringType(), True),
        StructField("booking_media_live_start_dt", DateType(), True),
        StructField("booking_media_live_end_dt", DateType(), True),
        StructField("item_cd_list", StringType(), True)
    ])

    empty_df = spark_session.createDataFrame([], schema)
    empty_df.write.mode("overwrite").parquet(source_table_path)

    # Run the function
    youtube_normalize_pipeline(
        spark=spark_session,
        source_table_path=source_table_path,
        output_path=output_path,
        correlation_id="test-corr-id"
    )

    # Verify the output
    actual_df = spark_session.read.parquet(output_path)

    # Should be empty
    assert actual_df.count() == 0, f"Expected empty output, got {actual_df.count()} rows"

    # Should still have the correct schema
    expected_columns = {
        "campaign_id", "start_dt", "end_dt", "item_cd",
        "booking_id", "jobbagid", "channel", "CAST(test-corr-id AS STRING)", "load_ts"
    }
    assert set(actual_df.columns) == expected_columns, f"Column mismatch. Expected: {expected_columns}, Got: {set(actual_df.columns)}"

    print("Empty input test passed!")


def test_youtube_normalize_pipeline_case_insensitive_filtering(spark_session: SparkSession, tmpdir: str):
    """Test that filtering is case-insensitive"""
    # Setup file paths
    source_table_path = os.path.join(tmpdir, "source_table.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")
    spark_session.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")

    # Create source data with different cases
    source_data = [
        # lowercase
        Row(
            booking_id="BK001",
            campaign_id="CP001",
            channel_type="offsite",
            media_provider="youtube",
            booking_status="completed",
            media_business_group="sainsburys",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": "ITEM001"}])
        ),
        # mixed case
        Row(
            booking_id="BK002",
            campaign_id="CP002",
            channel_type="OffSite",
            media_provider="YouTube",
            booking_status="Completed",
            media_business_group="Sainsbury Group",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": "ITEM002"}])
        ),
        # uppercase
        Row(
            booking_id="BK003",
            campaign_id="CP003",
            channel_type="OFFSITE",
            media_provider="YOUTUBE",
            booking_status="COMPLETED",
            media_business_group="SAINSBURYS UK",
            booking_media_live_start_dt=date(2024, 1, 1),
            booking_media_live_end_dt=date(2024, 1, 7),
            item_cd_list=json.dumps([{"skuId": "ITEM003"}])
        )
    ]

    spark_session.createDataFrame(source_data).write.mode("overwrite").parquet(source_table_path)

    # Run the function
    youtube_normalize_pipeline(
        spark=spark_session,
        source_table_path=source_table_path,
        output_path=output_path,
        correlation_id="test-corr-id"
    )

    # Verify the output
    actual_df = spark_session.read.parquet(output_path)

    # All should pass the case-insensitive filtering
    assert actual_df.count() == 3, f"Expected 3 rows, got {actual_df.count()}"

    # Check that all campaigns made it through
    item_codes = {row.item_cd for row in actual_df.select("item_cd").collect()}
    expected_item_codes = {"ITEM001", "ITEM002", "ITEM003"}
    assert item_codes == expected_item_codes, f"Item codes mismatch. Expected: {expected_item_codes}, Got: {item_codes}"

    print("Case-insensitive filtering test passed!")
