from datetime import date, datetime
from decimal import Decimal
import pytest
from chispa.dataframe_comparer import assert_df_equality
from mockito import when, ANY
from pyspark.sql import Row, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

from spark_pipeline.user_journey import user_journey_utils
from spark_pipeline.user_journey.user_journey_helper import build_user_journey_pollen
from spark_pipeline.common.variables import EventName
from spark_pipeline.schemas.user_journey import UserJourney

"""
Additional invariants for Pollen pipeline run type:
  - sub_path is always 1 (single journey per loyalty_id)
  - userjourney_id = loyalty_id + "_1"
  - Post-conversion events are trimmed inside build_user_journey_pollen (not in CDC rebuild)
  CDC — Customer Data Collection: one row per customer event (touchpoints and purchases)
  MCE — Measurement Campaign Execution: one row per active campaign booking.
"""

# Default values used in tests
BOOKING_ID = "booking-001"
CAMPAIGN_ID = "campaign-001"
LOYALTY_ID = "loyalty_abc"
PRODUCT_TYPE = "Offer"
TOUCHPOINT = EventName.TOUCHPOINT.value
PURCHASE = EventName.TRANSACTION.value
LOAD_TS = datetime(2026, 1, 24, 0, 0, 0)


# Reusable schema for the common (isconversion, sub_path, userjourney_id) invariant check.
def cdc_row(**kwargs):
    defaults = dict(
        loyalty_id=LOYALTY_ID,
        transaction_key="tp-key",
        event_ts=datetime(2026, 1, 23, 10, 0, 0),
        channel_name="Fins - Main Estate",
        subchannel_name="Main Estate",
        campaign_name="test-campaign",
        campaign_id=CAMPAIGN_ID,
        event_name=TOUCHPOINT,
        booking_id=BOOKING_ID,
        item_cd="item-001",
        product_type=PRODUCT_TYPE,
        net_sales_amt=Decimal("0.0000"),
        units_qty=Decimal("0.0000"),
        unique_brand_name="test-brand",
        marketing_type="default marketing type",
        load_ts=LOAD_TS,
        purchase_type="",
    )
    defaults.update(kwargs)

    # CDC contract: transaction events carry blank campaign/channel/marketing fields.
    if defaults.get("event_name") == PURCHASE:
        defaults["campaign_id"] = ""
        defaults["channel_name"] = ""
        defaults["subchannel_name"] = ""
        defaults["marketing_type"] = ""
        defaults["purchase_type"] = "in-store"

    return Row(**defaults)


def mce_row(**kwargs):
    defaults = dict(
        booking_id=BOOKING_ID,
        campaign_id=CAMPAIGN_ID,
        channel_name="Fins - Main Estate",
        subchannel_name="Main Estate",
        campaign_duration="During",
        job_status="in-progress",
    )
    defaults.update(kwargs)
    return Row(**defaults)


def _run(spark, cdc_rows, mce_rows=None, product_type=PRODUCT_TYPE):
    """Build input DataFrames and call build_user_journey_pollen."""
    when(user_journey_utils).publish_user_journey_metrics(ANY, ANY, ANY).thenReturn(None)
    if mce_rows is None:
        mce_rows = [mce_row()]
    cdc_df = spark.createDataFrame(cdc_rows, UserJourney.CDC_SCHEMA)
    mce_df = spark.createDataFrame(mce_rows, UserJourney.MCE_SCHEMA)

    print("CDC input:")
    cdc_df.show(truncate=False)
    print("McE input:")
    mce_df.show(truncate=False)

    return build_user_journey_pollen(
        measurement_campaign_execution_df=mce_df,
        customer_data_collection_df=cdc_df,
        product_type=product_type,
        journey_type=product_type,
        correlation_id="test-run-id",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:test-topic",
    )


def test_converted_customer_all_rows_have_isconversion_1(
        spark_session: SparkSession, stub_messenger):
    """
    Scenario: customer has a touchpoint and a Purchase Transaction.
    All rows should have isconversion=1.
    """
    cdc_rows = [
        cdc_row(event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT),
        cdc_row(transaction_key="txn-001",
                event_ts=datetime(2026, 1, 23, 11, 0, 0), event_name=PURCHASE),
    ]

    result = _run(spark_session, cdc_rows)
    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # TP at 10:00 → rank 1 → Initiator
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 23, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # PURCHASE at 11:00 → rank 2 → Convertor
            (
                LOYALTY_ID, "txn-001", datetime(2026, 1, 23, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 2, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_converted_customer_with_pre_conversion_touchpoints_has_isconversion_1(
    spark_session: SparkSession, stub_messenger
):
    """
    Scenario: multiple touchpoints leading up to a Purchase Transaction.
    All rows (including the pre-conversion touchpoints) must have isconversion=1.
    """
    cdc_rows = [
        cdc_row(event_ts=datetime(2026, 1, 25, 8, 0, 0), event_name=TOUCHPOINT,
                channel_name="Entrance Gates - Main Estate", subchannel_name="Entrance Gates - Main Estate"),
        cdc_row(event_ts=datetime(2026, 1, 25, 8, 1, 0), event_name=TOUCHPOINT,
                channel_name="Fins - Main Estate"),
        cdc_row(event_ts=datetime(2026, 2, 15, 9, 0, 0), event_name=TOUCHPOINT,
                channel_name="Coupon At Till - Main Estate", subchannel_name="Coupon At Till - Main Estate"),
        cdc_row(transaction_key="txn-001",
                event_ts=datetime(2026, 2, 23, 10, 0, 0),
                event_name=PURCHASE),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # TP at Jan 25 08:00 → rank 1 → Initiator
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 25, 8, 0, 0), "Entrance Gates - Main Estate", "Entrance Gates - Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # TP at Jan 25 08:01 → rank 2 → Assistor
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 25, 8, 1, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 2, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # TP at Feb 15 09:00 → rank 3 → Assistor
            (
                LOYALTY_ID, "NA", datetime(2026, 2, 15, 9, 0, 0), "Coupon At Till - Main Estate", "Coupon At Till - Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 3, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # PURCHASE at Feb 23 10:00 → rank 4 → Convertor
            (
                LOYALTY_ID, "txn-001", datetime(2026, 2, 23, 10, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 4, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_customer_with_multiple_conversions_has_isconversion_1(
    spark_session: SparkSession, stub_messenger
):
    """
    Scenario : customer converts twice (Jan 26, Feb 13) with touchpoints between.
    All rows should have isconversion=1.
    """
    cdc_rows = [
        cdc_row(event_ts=datetime(2026, 1, 21, 8, 0, 0), event_name=TOUCHPOINT),
        cdc_row(transaction_key="txn-1",
                event_ts=datetime(2026, 1, 26, 9, 0, 0),
                event_name=TOUCHPOINT),
        cdc_row(transaction_key="txn-1",
                event_ts=datetime(2026, 1, 26, 10, 0, 0),
                event_name=PURCHASE),
        cdc_row(event_ts=datetime(2026, 1, 31, 8, 0, 0),
                event_name=TOUCHPOINT),
        cdc_row(event_ts=datetime(2026, 2, 6, 8, 0, 0),
                event_name=TOUCHPOINT),
        cdc_row(transaction_key="txn-2",
                event_ts=datetime(2026, 2, 13, 10, 0, 0),
                event_name=PURCHASE),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # TP at Jan 21 → rank 1 → Initiator
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 21, 8, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # TP at Jan 26 09:00 → rank 2 → Assistor
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 26, 9, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 2, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # PURCHASE at Jan 26 10:00 → rank 3 → Convertor
            (
                LOYALTY_ID, "txn-1", datetime(2026, 1, 26, 10, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 3, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "in-store",
            ),
            # TP at Jan 31 → rank 4 → Assistor
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 31, 8, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 4, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # TP at Feb 6 → rank 5 → Assistor
            (
                LOYALTY_ID, "NA", datetime(2026, 2, 6, 8, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 5, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # PURCHASE at Feb 13 → rank 6 → Convertor
            (
                LOYALTY_ID, "txn-2", datetime(2026, 2, 13, 10, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 6, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_customer_after_cdc_trim_has_isconversion_1(spark_session: SparkSession, stub_messenger):
    """
    Scenario:
    Post-conversion trailing events already dropped by CDC.
    Journey ends at the Purchase Transaction → isconversion=1.
    """
    cdc_rows = [
        cdc_row(event_ts=datetime(2026, 1, 22, 9, 0, 0),
                event_name=TOUCHPOINT),
        cdc_row(event_ts=datetime(2026, 1, 26, 9, 0, 0),
                event_name=TOUCHPOINT),
        cdc_row(transaction_key="txn-001",
                event_ts=datetime(2026, 1, 26, 10, 0, 0),
                event_name=PURCHASE),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # TP at Jan 22 → rank 1 → Initiator
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 22, 9, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # TP at Jan 26 09:00 → rank 2 → Assistor
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 26, 9, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 2, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # PURCHASE at Jan 26 10:00 → rank 3 → Convertor
            (
                LOYALTY_ID, "txn-001", datetime(2026, 1, 26, 10, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 3, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_non_converted_customer_all_rows_have_isconversion_0(
    spark_session: SparkSession, stub_messenger
):
    """
    Scenario : no Purchase Transaction. All rows should have isconversion=0.
    """
    cdc_rows = [
        cdc_row(transaction_key="NA",
                event_ts=datetime(2026, 1, 22, 9, 0, 0),
                event_name=TOUCHPOINT),
        cdc_row(transaction_key="NA",
                event_ts=datetime(2026, 1, 24, 9, 0, 0),
                event_name=TOUCHPOINT),
        cdc_row(transaction_key="NA",
                event_ts=datetime(2026, 2, 2, 10, 0, 0),
                event_name=TOUCHPOINT),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # TP at Jan 22 09:00 → rank 1 → Initiator, isconversion=0
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 22, 9, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 0, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # TP at Jan 24 09:00 → rank 2 → Assistor, isconversion=0
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 24, 9, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 2, "Assistor", 0, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # TP at Feb 2 10:00 → rank 3 → Assistor, isconversion=0
            (
                LOYALTY_ID, "NA", datetime(2026, 2, 2, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 3, "Assistor", 0, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


# ---------------------------------------------------------------------------
# Data quality invariant: every converted customer must have at least one
# Touchpoint. A purchase with no preceding touchpoint indicates a CDC defect.
# This should never happen in production but is pinned here so any regression
# in the upstream data surfaced immediately.
# ---------------------------------------------------------------------------

def test_every_converted_customer_has_at_least_one_touchpoint(
    spark_session: SparkSession, stub_messenger
):
    """
    Normal CDC always contains at least one Touchpoint before a purchase.
    After build_user_journey_pollen runs, every loyalty_id with isconversion=1
    must have at least one Touchpoint row in the output.
    A purchase-only journey (zero touchpoints) is a source data defect.
    """
    cdc_rows = [
        # customer A — has a touchpoint before purchase (normal)
        cdc_row(loyalty_id="customer_A",
                event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT),
        cdc_row(loyalty_id="customer_A", transaction_key="txn-A",
                event_ts=datetime(2026, 1, 23, 11, 0, 0), event_name=PURCHASE),
        # customer B — also has a touchpoint before purchase (normal)
        cdc_row(loyalty_id="customer_B",
                event_ts=datetime(2026, 1, 24, 9, 0, 0), event_name=TOUCHPOINT),
        cdc_row(loyalty_id="customer_B", transaction_key="txn-B",
                event_ts=datetime(2026, 1, 24, 11, 0, 0), event_name=PURCHASE),
    ]

    result = _run(spark_session, cdc_rows)

    # Every converted customer must have at least one touchpoint row.
    # We verify by asserting the touchpoint-per-converted-customer join is non-empty,
    # using a count aggregation compared via assert_df_equality.
    touchpoints_per_customer = (
        result
        .filter((F.col("isconversion") == 1) & (F.col("event_name") == TOUCHPOINT))
        .groupBy("loyalty_id")
        .agg(F.count("*").alias("tp_count"))
    )
    assert_df_equality(
        touchpoints_per_customer.select("loyalty_id"),
        spark_session.createDataFrame(
            [("customer_A",), ("customer_B",)],
            T.StructType([T.StructField("loyalty_id", T.StringType())]),
        ),
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_converted_customer_without_touchpoint_raises_data_quality_error(
    spark_session: SparkSession, stub_messenger
):
    """
        A purchase-only converted journey is a CDC defect and must fail fast.
        raise an error if we have a transaction event with no preceding touchpoint for the same loyalty_id.
    """
    cdc_rows = [
        cdc_row(
            loyalty_id="customer_defect",
            transaction_key="txn-defect",
            event_ts=datetime(2026, 1, 24, 11, 0, 0),
            event_name=PURCHASE,
        ),
    ]

    with pytest.raises(
        ValueError,
        match="converted customers with no touchpoint",
    ):
        _run(spark_session, cdc_rows)


def test_converted_and_non_converted_customers_are_independent(
    spark_session: SparkSession, stub_messenger
):
    """
    Two customers in the same DataFrame:
      - customer A: converts → isconversion=1
      - customer B: no conversion → isconversion=0
    """
    cdc_rows = [
        # Customer A — converted
        cdc_row(loyalty_id="customer_A",
                event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT),
        cdc_row(loyalty_id="customer_A", transaction_key="txn-A",
                event_ts=datetime(2026, 1, 23, 11, 0, 0), event_name=PURCHASE),
        # Customer B — non-converted
        cdc_row(loyalty_id="customer_B", transaction_key="NA",
                event_ts=datetime(2026, 1, 22, 9, 0, 0),
                event_name=TOUCHPOINT),
        cdc_row(loyalty_id="customer_B", transaction_key="NA",
                event_ts=datetime(2026, 1, 24, 9, 0, 0),
                event_name=TOUCHPOINT),
    ]

    result = _run(spark_session, cdc_rows)

    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = result.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # customer_A touchpoint at Jan 23 10:00 -> rank 1 -> Initiator, isconversion=1
            (
                "customer_A", "NA", datetime(2026, 1, 23, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, "customer_A_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # customer_A purchase at Jan 23 11:00 -> rank 2 -> Convertor, isconversion=1
            (
                "customer_A", "txn-A", datetime(2026, 1, 23, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, "customer_A_1", 2, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "in-store",
            ),
            # customer_B touchpoint at Jan 22 09:00 -> rank 1 -> Initiator, isconversion=0
            (
                "customer_B", "NA", datetime(2026, 1, 22, 9, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, "customer_B_1", 1, "Initiator", 0, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # customer_B touchpoint at Jan 24 09:00 -> rank 2 -> Assistor, isconversion=0
            (
                "customer_B", "NA", datetime(2026, 1, 24, 9, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, "customer_B_1", 2, "Assistor", 0, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_sub_path_is_always_1(spark_session: SparkSession, stub_messenger):
    """ Pollen produces a single journey per loyalty_id; sub_path must be 1 for all rows. """
    cdc_rows = [
        cdc_row(event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT),
        cdc_row(transaction_key="txn-001",
                event_ts=datetime(2026, 1, 23, 11, 0, 0), event_name=PURCHASE),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # TP at 10:00 → rank 1 → Initiator
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 23, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # PURCHASE at 11:00 → rank 2 → Convertor
            (
                LOYALTY_ID, "txn-001", datetime(2026, 1, 23, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 2, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_userjourney_id_is_loyalty_id_underscore_1(spark_session: SparkSession, stub_messenger):
    """userjourney_id must be <loyalty_id>_1 for every row."""
    cdc_rows = [
        cdc_row(event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT),
        cdc_row(transaction_key="txn-001",
                event_ts=datetime(2026, 1, 23, 11, 0, 0), event_name=PURCHASE),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # TP at 10:00 → rank 1 → Initiator
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 23, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # PURCHASE at 11:00 → rank 2 → Convertor
            (
                LOYALTY_ID, "txn-001", datetime(2026, 1, 23, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 2, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_keeps_purchase_when_touchpoint_has_newer_load_ts(
    spark_session: SparkSession, stub_messenger
):
    """
    Current behavior: with max load_ts selected per product_type, a newer
    touchpoint batch can drop an older purchase batch for the same booking.
    This test documents that behavior.
    """
    newer_load_ts = datetime(2026, 2, 8, 0, 0, 0)
    older_load_ts = datetime(2026, 2, 7, 0, 0, 0)

    cdc_rows = [
        cdc_row(
            transaction_key="txn-2",
            event_ts=datetime(2026, 2, 7, 14, 15, 0),
            event_name=TOUCHPOINT,
            channel_name="Fins - Main Estate",
            subchannel_name="Fins - Main Estate",
            net_sales_amt=Decimal("0.0000"),
            units_qty=Decimal("0.0000"),
            load_ts=newer_load_ts,
        ),
        cdc_row(
            transaction_key="txn-2",
            event_ts=datetime(2026, 2, 7, 14, 15, 0),
            event_name=PURCHASE,
            channel_name="In-store",
            subchannel_name="",
            net_sales_amt=Decimal("1.5000"),
            units_qty=Decimal("1.0000"),
            load_ts=older_load_ts,
        ),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # Only the touchpoint from the latest batch is retained.
            (
                LOYALTY_ID, "NA", datetime(2026, 2, 7, 14, 15, 0), "Fins - Main Estate", "Fins - Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 0, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_real_world_two_conversions_with_duplicate_purchase_row(
    spark_session: SparkSession, stub_messenger
):
    """
    One customer with:
    - txn-1 (Jan 27): 1 touchpoint + 2 identical purchase rows (duplicate in CDC) → deduped to 1
    - NA (Jan 31, Feb 3, Feb 6): 3 standalone touchpoints (no conversion)
    - txn-2 (Feb 7): 1 touchpoint + 1 purchase

    Running for Offer (product_type="Offer").
    item_cd 7872133 is in the Offer store list → product_type=Offer → kept.
    item_cd 2023755 is NOT in the store list → product_type=Brand → filtered out.

    Expected output:
    - 6 rows (txn-2 Brand purchase filtered; duplicate txn-1 purchase deduped)
    - isconversion = 1 for all rows (txn-1 Offer purchase present)
    - sub_path = 1 for all rows (Pollen single journey)
    - purchase for txn-1 has net_sales_amt = 1.25
    - txn-2 purchase (Brand) is absent from Offer journey output
    """
    CUST = "e0bdc754df1eac01c_test"
    TXN_1 = "80c54223-6386-4c2-test"
    TXN_2 = "5cbe5a1f-382d-494-test"
    CAM = "69a1af0cebf092589_test"

    cdc_rows = [
        # txn-1: touchpoint
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN_1, campaign_id=CAM,
            event_ts=datetime(2026, 1, 27, 10, 48, 0),
            channel_name="Fins - Main Estate", subchannel_name="Fins - Main Estate",
            event_name=TOUCHPOINT, item_cd="0",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        # txn-1: purchase row 1 (duplicate)
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN_1, campaign_id=CAM,
            event_ts=datetime(2026, 1, 27, 10, 48, 0),
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, item_cd="7872133",
            net_sales_amt=Decimal("1.2500"), units_qty=Decimal("1.0000"),
        ),
        # txn-1: purchase row 2 — exact duplicate, must be deduped away
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN_1, campaign_id=CAM,
            event_ts=datetime(2026, 1, 27, 10, 48, 0),
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, item_cd="7872133",
            net_sales_amt=Decimal("1.2500"), units_qty=Decimal("1.0000"),
        ),
        # NA touchpoints — customer seen but no purchase on these days
        cdc_row(
            loyalty_id=CUST, transaction_key="NA", campaign_id=CAM,
            event_ts=datetime(2026, 1, 31, 19, 6, 0),
            channel_name="Fins - Main Estate", subchannel_name="Fins - Main Estate",
            event_name=TOUCHPOINT, item_cd="0",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key="NA", campaign_id=CAM,
            event_ts=datetime(2026, 2, 3, 10, 39, 0),
            channel_name="Fins - Main Estate", subchannel_name="Fins - Main Estate",
            event_name=TOUCHPOINT, item_cd="0",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key="NA", campaign_id=CAM,
            event_ts=datetime(2026, 2, 6, 13, 8, 0),
            channel_name="Fins - Main Estate", subchannel_name="Fins - Main Estate",
            event_name=TOUCHPOINT, item_cd="0",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        # txn-2: touchpoint
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN_2, campaign_id=CAM,
            event_ts=datetime(2026, 2, 7, 14, 15, 0),
            channel_name="Fins - Main Estate", subchannel_name="Fins - Main Estate",
            event_name=TOUCHPOINT, item_cd="0",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        # txn-2: purchase — item 2023755 is NOT in Offer store list → Brand
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN_2, campaign_id=CAM,
            event_ts=datetime(2026, 2, 7, 14, 15, 0),
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, item_cd="2023755", product_type="Brand",
            net_sales_amt=Decimal("1.5000"), units_qty=Decimal("1.0000"),
        ),
    ]
    mce_rows = [mce_row(campaign_id=CAM)]

    result = _run(spark_session, cdc_rows, mce_rows)

    rows = result.filter(F.col("loyalty_id") == CUST)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # txn-1 purchase retained (Offer), ranked first due to tie-breaking rules.
            (
                CUST, TXN_1, datetime(2026, 1, 27, 10, 48, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{CUST}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("1.2500"), Decimal("1.0000"),
                PRODUCT_TYPE, "in-store",
            ),
            # txn-1 touchpoint retained with transaction_key normalised to NA.
            (
                CUST, "NA", datetime(2026, 1, 27, 10, 48, 0), "Fins - Main Estate", "Fins - Main Estate",
                TOUCHPOINT, BOOKING_ID, CAM, 1, f"{CUST}_1", 2, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_same_purchase_attributed_to_two_campaigns(
    spark_session: SparkSession, stub_messenger
):
    """
    One customer, one transaction key, same event_ts for all rows.
    Two campaign_ids are involved (e.g. Trolley and Fins campaigns running concurrently).

    Running for Offer (product_type="Offer").
    item_cd 2023786 is NOT in the Offer store list → product_type=Brand → both purchases filtered.

    CDC rows:
    - Touchpoint on Trolley, campaign A
    - Touchpoint on Fins,    campaign B
    - Purchase on In-store,  campaign B   ← Brand item, filtered for Offer run
    - Purchase on In-store,  campaign A   ← Brand item, filtered for Offer run

    Expected user journey (Offer run):
    - 2 rows (only touchpoints; both Brand purchases excluded)
    - isconversion = 0 (no Offer purchases present)
    - sub_path = 1 (Pollen single journey)
    """
    CUST = "4269529965ca866ce_test"
    TXN = "a6b9cf66-f84d-4be-test"
    CAM_A = "69a1af2aebf092589_test"   # Trolley campaign
    CAM_B = "69a1af0cebf092589_test"   # Fins campaign
    EVENT_TS = datetime(2026, 1, 23, 13, 18, 0)

    cdc_rows = [
        # Touchpoint — Trolley, campaign A
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_A,
            event_ts=EVENT_TS,
            channel_name="Trolley - Main Estate", subchannel_name="Trolley - Main Estate",
            event_name=TOUCHPOINT, item_cd="0",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        # Touchpoint — Fins, campaign B
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_B,
            event_ts=EVENT_TS,
            channel_name="Fins - Main Estate", subchannel_name="Fins - Main Estate",
            event_name=TOUCHPOINT, item_cd="0",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        # Purchase — In-store, campaign B (item 2023786 NOT in Offer store list → Brand)
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_B,
            event_ts=EVENT_TS,
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, item_cd="2023786", product_type="Brand",
            net_sales_amt=Decimal("1.5000"), units_qty=Decimal("1.0000"),
        ),
        # Purchase — In-store, campaign A (item 2023786 NOT in Offer store list → Brand)
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_A,
            event_ts=EVENT_TS,
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, item_cd="2023786", product_type="Brand",
            net_sales_amt=Decimal("1.5000"), units_qty=Decimal("1.0000"),
        ),
    ]
    mce_rows = [
        mce_row(campaign_id=CAM_A, channel_name="Trolley - Main Estate", subchannel_name="Trolley - Main Estate"),
        mce_row(campaign_id=CAM_B, channel_name="Fins - Main Estate", subchannel_name="Fins - Main Estate"),
    ]

    result = _run(spark_session, cdc_rows, mce_rows)

    rows = result.filter(F.col("loyalty_id") == CUST)

    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # campaign B touchpoint is ranked first (same timestamp, lower campaign_id).
            (
                CUST, "NA", EVENT_TS, "Fins - Main Estate", "Fins - Main Estate",
                TOUCHPOINT, BOOKING_ID, CAM_B, 1, f"{CUST}_1", 1, "Initiator", 0, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # campaign A touchpoint remains and is ranked second.
            (
                CUST, "NA", EVENT_TS, "Trolley - Main Estate", "Trolley - Main Estate",
                TOUCHPOINT, BOOKING_ID, CAM_A, 1, f"{CUST}_1", 2, "Assistor", 0, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_multi_campaign_single_conversion_with_na_touchpoints(
    spark_session: SparkSession, stub_messenger
):
    """
    One customer touched by four concurrent campaigns (Social, Sampling, Digital Screens, Fins).
    The same purchase (item 2023786) is attributed to all four campaign_ids.

    product_type is Brand for all CDC rows.

    CDC rows:
    - Jan 21:  1 touchpoint (Social, txn key present)
    - Jan 25:  3 touchpoints (Sampling, Digital Screens, Fins — all transaction_key=NA)
    - Jan 26:  3 touchpoints (Fins, Sampling, Digital Screens — all transaction_key=NA)
    - Jan 31:  1 touchpoint  (Fins — transaction_key=NA)
    - Feb 01 16:21:35: 3 touchpoints (Sampling, Digital Screens, Fins — txn key present)
    - Feb 01 16:21:36: 4 purchase rows (one per campaign_id, same item/amount)

    Expected output:
    - 12 rows total (4 duplicate purchase rows retain transaction data with blank campaign_id)
    - isconversion = 1 for all rows
    - sub_path = 1 (Pollen single journey)
    - purchase rows carry campaign_id='' with net_sales_amt = 1.50
    """
    CUST = "0be052a66fef7e5fbd6b08b45c20cfd246cfdb231a5a848841274362724da1aa"
    TXN = "773272a5-d5cf-4c88-b787-3fa0c031b298"
    CAM_SOCIAL = "120237935859890543"
    CAM_SAMPLING = "69a1af1cebf0925898e57527"
    CAM_DIGITAL = "69a1aedbebf0925898e57524"
    CAM_FINS = "69a1af0cebf0925898e57526"

    cdc_rows = [
        # Jan 21 — Social touchpoint (transaction_key present but no purchase yet)
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_SOCIAL,
            event_ts=datetime(2026, 1, 21, 0, 0, 0),
            channel_name="Social", subchannel_name="Social - Meta",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        # Jan 25 — three simultaneous touchpoints across channels (no transaction)
        cdc_row(
            loyalty_id=CUST, transaction_key="NA", campaign_id=CAM_SAMPLING,
            event_ts=datetime(2026, 1, 25, 16, 22, 24, 193000),
            channel_name="Sampling - Main Estate",
            subchannel_name="Sampling - Main Estate - Power Aisle - Standard",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key="NA", campaign_id=CAM_DIGITAL,
            event_ts=datetime(2026, 1, 25, 16, 22, 24, 193000),
            channel_name="Digital Screens - Main Estate",
            subchannel_name="Digital Screens - Main Estate - In Store",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key="NA", campaign_id=CAM_FINS,
            event_ts=datetime(2026, 1, 25, 16, 22, 24, 193000),
            channel_name="Fins - Main Estate",
            subchannel_name="Fins - Main Estate - Fully Branded",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        # Jan 26 — three simultaneous touchpoints (no transaction)
        cdc_row(
            loyalty_id=CUST, transaction_key="NA", campaign_id=CAM_FINS,
            event_ts=datetime(2026, 1, 26, 14, 56, 7, 792000),
            channel_name="Fins - Main Estate",
            subchannel_name="Fins - Main Estate - Fully Branded",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key="NA", campaign_id=CAM_SAMPLING,
            event_ts=datetime(2026, 1, 26, 14, 56, 7, 792000),
            channel_name="Sampling - Main Estate",
            subchannel_name="Sampling - Main Estate - Power Aisle - Standard",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key="NA", campaign_id=CAM_DIGITAL,
            event_ts=datetime(2026, 1, 26, 14, 56, 7, 792000),
            channel_name="Digital Screens - Main Estate",
            subchannel_name="Digital Screens - Main Estate - In Store",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        # Jan 31 — single Fins touchpoint (no transaction)
        cdc_row(
            loyalty_id=CUST, transaction_key="NA", campaign_id=CAM_FINS,
            event_ts=datetime(2026, 1, 31, 18, 18, 54, 270000),
            channel_name="Fins - Main Estate",
            subchannel_name="Fins - Main Estate - Fully Branded",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        # Feb 01 16:21:35 — three touchpoints just before purchase
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_SAMPLING,
            event_ts=datetime(2026, 2, 1, 16, 21, 35, 943000),
            channel_name="Sampling - Main Estate",
            subchannel_name="Sampling - Main Estate - Power Aisle - Standard",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_DIGITAL,
            event_ts=datetime(2026, 2, 1, 16, 21, 35, 943000),
            channel_name="Digital Screens - Main Estate",
            subchannel_name="Digital Screens - Main Estate - In Store",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_FINS,
            event_ts=datetime(2026, 2, 1, 16, 21, 35, 943000),
            channel_name="Fins - Main Estate",
            subchannel_name="Fins - Main Estate - Fully Branded",
            event_name=TOUCHPOINT, item_cd="0", product_type="Brand",
            net_sales_amt=Decimal("0.0000"), units_qty=Decimal("0.0000"),
        ),
        # Feb 01 16:21:36 — purchase attributed to all four campaigns
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_SAMPLING,
            event_ts=datetime(2026, 2, 1, 16, 21, 36, 43000),
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, item_cd="2023786", product_type="Brand",
            net_sales_amt=Decimal("1.5000"), units_qty=Decimal("1.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_DIGITAL,
            event_ts=datetime(2026, 2, 1, 16, 21, 36, 43000),
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, item_cd="2023786", product_type="Brand",
            net_sales_amt=Decimal("1.5000"), units_qty=Decimal("1.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_SOCIAL,
            event_ts=datetime(2026, 2, 1, 16, 21, 36, 43000),
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, item_cd="2023786", product_type="Brand",
            net_sales_amt=Decimal("1.5000"), units_qty=Decimal("1.0000"),
        ),
        cdc_row(
            loyalty_id=CUST, transaction_key=TXN, campaign_id=CAM_FINS,
            event_ts=datetime(2026, 2, 1, 16, 21, 36, 43000),
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, item_cd="2023786", product_type="Brand",
            net_sales_amt=Decimal("1.5000"), units_qty=Decimal("1.0000"),
        ),
    ]
    # One MCE row per campaign — all share the same booking_id and campaign_duration
    mce_rows = [
        mce_row(campaign_id=CAM_SOCIAL, channel_name="Social", subchannel_name="Social - Meta"),
        mce_row(campaign_id=CAM_SAMPLING, channel_name="Sampling - Main Estate", subchannel_name="Sampling - Main Estate - Power Aisle - Standard"),
        mce_row(campaign_id=CAM_DIGITAL, channel_name="Digital Screens - Main Estate", subchannel_name="Digital Screens - Main Estate - In Store"),
        mce_row(campaign_id=CAM_FINS, channel_name="Fins - Main Estate", subchannel_name="Fins - Main Estate - Fully Branded"),
    ]

    result = _run(spark_session, cdc_rows, mce_rows, product_type="Brand")

    rows = result.filter(F.col("loyalty_id") == CUST)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (
                CUST, "NA", datetime(2026, 1, 21, 0, 0, 0), "Social", "Social - Meta",
                TOUCHPOINT, BOOKING_ID, CAM_SOCIAL, 1, f"{CUST}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, "NA", datetime(2026, 1, 25, 16, 22, 24, 193000), "Digital Screens - Main Estate", "Digital Screens - Main Estate - In Store",
                TOUCHPOINT, BOOKING_ID, CAM_DIGITAL, 1, f"{CUST}_1", 2, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, "NA", datetime(2026, 1, 25, 16, 22, 24, 193000), "Fins - Main Estate", "Fins - Main Estate - Fully Branded",
                TOUCHPOINT, BOOKING_ID, CAM_FINS, 1, f"{CUST}_1", 3, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, "NA", datetime(2026, 1, 25, 16, 22, 24, 193000), "Sampling - Main Estate", "Sampling - Main Estate - Power Aisle - Standard",
                TOUCHPOINT, BOOKING_ID, CAM_SAMPLING, 1, f"{CUST}_1", 4, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, "NA", datetime(2026, 1, 26, 14, 56, 7, 792000), "Digital Screens - Main Estate", "Digital Screens - Main Estate - In Store",
                TOUCHPOINT, BOOKING_ID, CAM_DIGITAL, 1, f"{CUST}_1", 5, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, "NA", datetime(2026, 1, 26, 14, 56, 7, 792000), "Fins - Main Estate", "Fins - Main Estate - Fully Branded",
                TOUCHPOINT, BOOKING_ID, CAM_FINS, 1, f"{CUST}_1", 6, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, "NA", datetime(2026, 1, 26, 14, 56, 7, 792000), "Sampling - Main Estate", "Sampling - Main Estate - Power Aisle - Standard",
                TOUCHPOINT, BOOKING_ID, CAM_SAMPLING, 1, f"{CUST}_1", 7, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, "NA", datetime(2026, 1, 31, 18, 18, 54, 270000), "Fins - Main Estate", "Fins - Main Estate - Fully Branded",
                TOUCHPOINT, BOOKING_ID, CAM_FINS, 1, f"{CUST}_1", 8, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, "NA", datetime(2026, 2, 1, 16, 21, 35, 943000), "Digital Screens - Main Estate", "Digital Screens - Main Estate - In Store",
                TOUCHPOINT, BOOKING_ID, CAM_DIGITAL, 1, f"{CUST}_1", 9, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, "NA", datetime(2026, 2, 1, 16, 21, 35, 943000), "Fins - Main Estate", "Fins - Main Estate - Fully Branded",
                TOUCHPOINT, BOOKING_ID, CAM_FINS, 1, f"{CUST}_1", 10, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, "NA", datetime(2026, 2, 1, 16, 21, 35, 943000), "Sampling - Main Estate", "Sampling - Main Estate - Power Aisle - Standard",
                TOUCHPOINT, BOOKING_ID, CAM_SAMPLING, 1, f"{CUST}_1", 11, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                "Brand", "",
            ),
            (
                CUST, TXN, datetime(2026, 2, 1, 16, 21, 36, 43000), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{CUST}_1", 12, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("1.5000"), Decimal("1.0000"),
                "Brand", "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_purchase_attributed_to_multiple_campaigns_collapses_to_one_row(
    spark_session: SparkSession, stub_messenger
):
    """
    One customer, one purchase, two campaign_ids (two concurrent campaigns).
    The purchase should appear exactly once in the output with campaign_id=''.
    Touchpoints keep their original campaign_ids.
    """
    CAM_A = "campaign-001"
    CAM_B = "campaign-002"
    TXN = "txn-dup"
    EVENT_TS = datetime(2026, 1, 23, 11, 0, 0)

    cdc_rows = [
        cdc_row(campaign_id=CAM_A,
                event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT),
        cdc_row(campaign_id=CAM_B,
                event_ts=datetime(2026, 1, 23, 10, 30, 0), event_name=TOUCHPOINT),
        # Same purchase attributed to both campaigns
        cdc_row(transaction_key=TXN, campaign_id=CAM_A,
                event_ts=EVENT_TS, event_name=PURCHASE,
                channel_name="", subchannel_name="",
                net_sales_amt=Decimal("2.5000"), units_qty=Decimal("1.0000")),
        cdc_row(transaction_key=TXN, campaign_id=CAM_B,
                event_ts=EVENT_TS, event_name=PURCHASE,
                channel_name="", subchannel_name="",
                net_sales_amt=Decimal("2.5000"), units_qty=Decimal("1.0000")),
    ]
    mce_rows = [
        mce_row(campaign_id=CAM_A),
        mce_row(campaign_id=CAM_B, channel_name="Fins - Main Estate", subchannel_name="Fins - Main Estate"),
    ]

    result = _run(spark_session, cdc_rows, mce_rows)
    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)

    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # load_ts is generated at runtime; use the value produced in this test run.
    generated_load_ts = selected.select("load_ts").first()["load_ts"]
    expected = spark_session.createDataFrame(
        [
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 23, 10, 30, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAM_B, 1, f"{LOYALTY_ID}_1", 2, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE,
                "",
            ),
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 23, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAM_A, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE,
                "",
            ),
            (
                LOYALTY_ID, TXN, datetime(2026, 1, 23, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 3, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("2.5000"), Decimal("1.0000"),
                PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


# ---------------------------------------------------------------------------
# Purchase deduplication safety: two items in the same transaction with
# identical price and quantity must NOT be collapsed to one row.
# This guards against the case where item_cd is dropped before dedup,
# causing rows that differ only on item to look identical after .distinct().
# ---------------------------------------------------------------------------

def test_two_items_same_price_same_qty_in_same_transaction_both_kept(
    spark_session: SparkSession, stub_messenger
):
    """
    One transaction with two line items: item A and item B.
    Both have net_sales_amt=1.25, units_qty=1.0.
    Without item_cd in the dedup key they would be identical after campaign_id
    is neutralised — .distinct() would collapse them and lose £1.25 of sales.
    Both rows must survive in the output as separate Purchase Transaction events.
    """
    TXN = "txn-two-items"
    EVENT_TS = datetime(2026, 1, 27, 15, 0, 34)

    cdc_rows = [
        cdc_row(
            transaction_key=TXN,
            event_ts=EVENT_TS,
            channel_name="Fins - Main Estate",
            subchannel_name="Fins - Main Estate",
            event_name=TOUCHPOINT,
            item_cd="0",
            net_sales_amt=Decimal("0.0000"),
            units_qty=Decimal("0.0000"),
        ),
        cdc_row(
            transaction_key=TXN,
            event_ts=EVENT_TS,
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE,
            item_cd="item-A",
            net_sales_amt=Decimal("1.2500"), units_qty=Decimal("1.0000"),
        ),
        cdc_row(
            transaction_key=TXN,
            event_ts=EVENT_TS,
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE,
            item_cd="item-B",                          # different item, same price/qty
            net_sales_amt=Decimal("1.2500"), units_qty=Decimal("1.0000"),
        ),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # Purchase ranks first on timestamp tie (campaign_id='' and event_name='transaction').
            (
                LOYALTY_ID, TXN, EVENT_TS, "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("2.5000"), Decimal("2.0000"),
                PRODUCT_TYPE, "in-store",
            ),
            # Touchpoint remains with transaction_key normalised to NA.
            (
                LOYALTY_ID, "NA", EVENT_TS, "Fins - Main Estate", "Fins - Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 2, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_scenario_211a_post_conversion_touchpoint_is_dropped(
    spark_session: SparkSession, stub_messenger
):
    """
    TP Jan23 + Purchase Jan23 + TP Jan28 (post-conv) in CDC.
    Expected output: 2 rows (Jan28 TP absent), all isconversion=1, sub_path=1.
    Post-conversion touchpoint (Jan 28) must be dropped
    """
    LOYALTY = "00e2c2df03a2e46c9101b823562740a0a6ccd265a16630c550744d18e22a8e14"
    TXN = "txn-211a"

    cdc_rows = [
        cdc_row(
            loyalty_id=LOYALTY, transaction_key="NA",
            event_ts=datetime(2026, 1, 23, 10, 0, 0),
            channel_name="Fins - Main Estate", event_name=TOUCHPOINT,
        ),
        cdc_row(
            loyalty_id=LOYALTY, transaction_key=TXN,
            event_ts=datetime(2026, 1, 23, 11, 0, 0),
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, net_sales_amt=Decimal("5.0000"), units_qty=Decimal("1.0000"),
        ),
        # post-conversion touchpoint — must be dropped
        cdc_row(
            loyalty_id=LOYALTY, transaction_key="NA",
            event_ts=datetime(2026, 1, 28, 10, 0, 0),
            channel_name="Fins - Main Estate", event_name=TOUCHPOINT,
        ),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # Pre-conversion touchpoint remains.
            (
                LOYALTY, "NA", datetime(2026, 1, 23, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # Conversion remains; post-conversion touchpoint is dropped.
            (
                LOYALTY, TXN, datetime(2026, 1, 23, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY}_1", 2, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("5.0000"), Decimal("1.0000"),
                PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_scenario_211b_multiple_post_conversion_touchpoints_are_dropped(
    spark_session: SparkSession, stub_messenger
):
    """
    Social TP Jan21, Fins TP Jan24, Purchase Jan24, Fins TP Feb1 (post-conv), Fins TP Feb6 (post-conv).
    Expected output: 3 rows (Feb1 + Feb6 TPs absent), all isconversion=1, sub_path=1.
    Two post-conversion touchpoints (Feb 1, Feb 6) must be dropped
    """
    LOYALTY = "9306126059c783c86f7e86ff936986ca52d850ffb820d34eae6bea4ebce7fa5f"
    TXN = "txn-211b"

    cdc_rows = [
        cdc_row(
            loyalty_id=LOYALTY, transaction_key="NA",
            event_ts=datetime(2026, 1, 21, 9, 0, 0),
            channel_name="Social", event_name=TOUCHPOINT,
        ),
        cdc_row(
            loyalty_id=LOYALTY, transaction_key="NA",
            event_ts=datetime(2026, 1, 24, 9, 0, 0),
            channel_name="Fins - Main Estate", event_name=TOUCHPOINT,
        ),
        cdc_row(
            loyalty_id=LOYALTY, transaction_key=TXN,
            event_ts=datetime(2026, 1, 24, 11, 0, 0),
            channel_name="In-store", subchannel_name="TXN",
            event_name=PURCHASE, net_sales_amt=Decimal("3.0000"), units_qty=Decimal("1.0000"),
        ),
        # post-conversion touchpoints — must be dropped
        cdc_row(
            loyalty_id=LOYALTY, transaction_key="NA",
            event_ts=datetime(2026, 2, 1, 9, 0, 0),
            channel_name="Fins - Main Estate", event_name=TOUCHPOINT,
        ),
        cdc_row(
            loyalty_id=LOYALTY, transaction_key="NA",
            event_ts=datetime(2026, 2, 6, 9, 0, 0),
            channel_name="Fins - Main Estate", event_name=TOUCHPOINT,
        ),
    ]

    result = _run(spark_session, cdc_rows)
    rows = result.filter(F.col("loyalty_id") == LOYALTY)

    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    # Capture runtime-generated load_ts
    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            # Social touchpoint before conversion.
            (
                LOYALTY, "NA", datetime(2026, 1, 21, 9, 0, 0), "Social", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # Fins touchpoint before conversion.
            (
                LOYALTY, "NA", datetime(2026, 1, 24, 9, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 2, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"),
                PRODUCT_TYPE, "",
            ),
            # Purchase remains; post-conversion touchpoints are dropped.
            (
                LOYALTY, TXN, datetime(2026, 1, 24, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY}_1", 3, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("3.0000"), Decimal("1.0000"),
                PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_scenario_212_non_converted_then_converted_all_14_rows_kept(
    spark_session: SparkSession, stub_messenger
):
    """
    12 EG/Fins TPs (Jan25–Feb9) + Coupon TP Feb15 + Purchase Feb23.
    Expected output: 14 rows, all isconversion=1, all sub_path=1.
    12 touchpoints before conversion + Coupon TP + purchase = 14 rows all kept.
    """
    LOYALTY = "cd509395b22117a9dd3e07382f0b432c1955a52ec26b0cf3800ef2a71cf9a28f"
    TXN = "txn-212"

    cdc_rows = [
        # Jan 25
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 25, 9, 0, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 25, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Jan 26
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 26, 9, 0, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 26, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Feb 1
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 1, 9, 0, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 1, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Feb 5
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 5, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 5, 9, 1, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        # Feb 8
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 8, 9, 0, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 8, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Feb 9
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 9, 9, 0, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 9, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Feb 15
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 15, 9, 0, 0),
                channel_name="Coupon At Till - Main Estate", event_name=TOUCHPOINT),
        # Feb 23 — purchase (conversion)
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN,
                event_ts=datetime(2026, 2, 23, 11, 0, 0),
                channel_name="In-store", subchannel_name="TXN",
                event_name=PURCHASE, net_sales_amt=Decimal("10.0000"), units_qty=Decimal("2.0000")),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (LOYALTY, "NA", datetime(2026, 1, 25, 9, 0, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 1, "Initiator", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 25, 9, 1, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 2, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 26, 9, 0, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 3, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 26, 9, 1, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 4, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 1, 9, 0, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 5, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 1, 9, 1, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 6, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 5, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 7, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 5, 9, 1, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 8, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 8, 9, 0, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 9, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 8, 9, 1, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 10, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 9, 9, 0, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 11, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 9, 9, 1, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 12, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 15, 9, 0, 0), "Coupon At Till - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 13, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, TXN, datetime(2026, 2, 23, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 14, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("10.0000"), Decimal("2.0000"), PRODUCT_TYPE, "in-store"),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_scenario_213_two_conversions_with_touchpoints_between_9_rows(
    spark_session: SparkSession, stub_messenger
):
    """
    Social TP Jan21, DS/Fins/Purchase Jan26, Fins/DS TPs Jan31, DS/Fins TPs Feb6, Purchase Feb13.
    DTP would fan Social TP across two sub_paths; Pollen keeps it once.
    Expected output: 9 rows, all isconversion=1, sub_path=1.
    Two purchases (Jan 26, Feb 13) with touchpoints between them.
    """
    LOYALTY = "44e54bf5085dfb026c5c197e5cde2ccc53238b74b4bba7c2a13ba44caa0560b8"
    TXN_1 = "txn-213-001"
    TXN_2 = "txn-213-002"

    cdc_rows = [
        # Jan 21 — touchpoint before first conversion
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 21, 9, 0, 0),
                channel_name="Social", event_name=TOUCHPOINT),
        # Jan 26 — first conversion
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_1,
                event_ts=datetime(2026, 1, 26, 10, 0, 0),
                channel_name="Digital Screens - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_1,
                event_ts=datetime(2026, 1, 26, 10, 30, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_1,
                event_ts=datetime(2026, 1, 26, 11, 0, 0),
                channel_name="In-store", subchannel_name="TXN",
                event_name=PURCHASE, net_sales_amt=Decimal("5.0000"), units_qty=Decimal("1.0000")),
        # Jan 31 — between conversions
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 31, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 31, 9, 1, 0),
                channel_name="Digital Screens - Main Estate", event_name=TOUCHPOINT),
        # Feb 6 — between conversions
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 6, 9, 0, 0),
                channel_name="Digital Screens - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 6, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Feb 13 — second conversion
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_2,
                event_ts=datetime(2026, 2, 13, 11, 0, 0),
                channel_name="In-store", subchannel_name="TXN",
                event_name=PURCHASE, net_sales_amt=Decimal("8.0000"), units_qty=Decimal("1.0000")),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (LOYALTY, "NA", datetime(2026, 1, 21, 9, 0, 0), "Social", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 1, "Initiator", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 26, 10, 0, 0), "Digital Screens - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 2, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 26, 10, 30, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 3, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, TXN_1, datetime(2026, 1, 26, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 4, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("5.0000"), Decimal("1.0000"), PRODUCT_TYPE, "in-store"),
            (LOYALTY, "NA", datetime(2026, 1, 31, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 5, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 31, 9, 1, 0), "Digital Screens - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 6, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 6, 9, 0, 0), "Digital Screens - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 7, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 6, 9, 1, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 8, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, TXN_2, datetime(2026, 2, 13, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 9, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("8.0000"), Decimal("1.0000"), PRODUCT_TYPE, "in-store"),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_scenario_214_post_conversion_trailing_touchpoints_dropped(
    spark_session: SparkSession, stub_messenger
):
    """
    5 Fins TPs Jan22–26, Purchase Jan26, then 13 Fins TPs Jan27–Feb10 (post-conv).
    Expected output: 6 rows (post-conv TPs absent), all isconversion=1, sub_path=1.
    5 TPs Jan22–26 + Purchase Jan26 + 13 TPs Jan27–Feb10 (post-conversion).
    Post-conversion trailing TPs must be dropped.
    """
    LOYALTY = "94bedde37baf17d15e0577e3b5a8f43534c359effccd522be6e0166827479836"
    TXN = "txn-214"

    pre_conv_rows = [
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, d, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT)
        for d in [22, 23, 24, 25, 26]
    ]
    purchase_row = cdc_row(
        loyalty_id=LOYALTY, transaction_key=TXN,
        event_ts=datetime(2026, 1, 26, 11, 0, 0),
        channel_name="In-store", subchannel_name="TXN",
        event_name=PURCHASE, net_sales_amt=Decimal("7.0000"), units_qty=Decimal("1.0000"),
    )
    post_conv_dates = [
        date(2026, 1, 27), date(2026, 1, 28), date(2026, 1, 29), date(2026, 1, 30),
        date(2026, 1, 31), date(2026, 2, 2), date(2026, 2, 3), date(2026, 2, 5),
        date(2026, 2, 6), date(2026, 2, 7), date(2026, 2, 8), date(2026, 2, 9),
        date(2026, 2, 10),
    ]
    post_conv_rows = [
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(d.year, d.month, d.day, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT)
        for d in post_conv_dates
    ]
    cdc_rows = pre_conv_rows + [purchase_row] + post_conv_rows

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (LOYALTY, "NA", datetime(2026, 1, 22, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 1, "Initiator", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 23, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 2, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 24, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 3, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 25, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 4, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 26, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 5, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, TXN, datetime(2026, 1, 26, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 6, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("7.0000"), Decimal("1.0000"), PRODUCT_TYPE, "in-store"),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_scenario_215_three_purchases_with_touchpoints_5_rows(
    spark_session: SparkSession, stub_messenger
):
    """
    Social TP Jan21, Purchase Jan21, Purchase Jan29, Fins TP Feb4, Purchase Feb5.
    Expected output: 5 rows, all isconversion=1, sub_path=1.
    """
    LOYALTY = "4c387d452349d4a5d838b774358ffdae8479cff1772edbab419f197b4d8f3f7f"
    TXN_1 = "txn-215-001"
    TXN_2 = "txn-215-002"
    TXN_3 = "txn-215-003"

    cdc_rows = [
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 21, 9, 0, 0),
                channel_name="Social", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_1,
                event_ts=datetime(2026, 1, 21, 11, 0, 0),
                channel_name="Online", subchannel_name="Online",
                event_name=PURCHASE, net_sales_amt=Decimal("15.0000"), units_qty=Decimal("1.0000")),
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_2,
                event_ts=datetime(2026, 1, 29, 11, 0, 0),
                channel_name="Online", subchannel_name="Online",
                event_name=PURCHASE, net_sales_amt=Decimal("20.0000"), units_qty=Decimal("1.0000")),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 4, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_3,
                event_ts=datetime(2026, 2, 5, 11, 0, 0),
                channel_name="Online", subchannel_name="Online",
                event_name=PURCHASE, net_sales_amt=Decimal("25.0000"), units_qty=Decimal("1.0000")),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (LOYALTY, "NA", datetime(2026, 1, 21, 9, 0, 0), "Social", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 1, "Initiator", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, TXN_1, datetime(2026, 1, 21, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 2, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("15.0000"), Decimal("1.0000"), PRODUCT_TYPE, "in-store"),
            (LOYALTY, TXN_2, datetime(2026, 1, 29, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 3, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("20.0000"), Decimal("1.0000"), PRODUCT_TYPE, "in-store"),
            (LOYALTY, "NA", datetime(2026, 2, 4, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 4, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, TXN_3, datetime(2026, 2, 5, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 5, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("25.0000"), Decimal("1.0000"), PRODUCT_TYPE, "in-store"),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_scenario_216_non_conv_conv_non_conv_conv_12_rows(
    spark_session: SparkSession, stub_messenger
):
    """
    12 events from Jan21 to Feb18, two purchases (Jan24, Feb18).
    Expected output: 12 rows, all isconversion=1, sub_path=1.
    Social TP Jan21, EG/Fins TPs Jan22, Fins TP+Purchase Jan24,
    """
    LOYALTY = "dc077c0f3e8695af0c0df3d3b7cd2a13c8a0bd845a3ee41e6fed8d8a2a621b08"
    TXN_1 = "txn-216-001"
    TXN_2 = "txn-216-002"

    cdc_rows = [
        # Jan 21
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 21, 9, 0, 0),
                channel_name="Social", event_name=TOUCHPOINT),
        # Jan 22
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 22, 9, 0, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 22, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Jan 24 — first conversion
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 24, 10, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_1,
                event_ts=datetime(2026, 1, 24, 11, 0, 0),
                channel_name="In-store", subchannel_name="TXN",
                event_name=PURCHASE, net_sales_amt=Decimal("5.0000"), units_qty=Decimal("1.0000")),
        # Jan 25
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 25, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Jan 31
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 31, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Feb 5
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 5, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 5, 9, 1, 0),
                channel_name="Digital Screens - Main Estate", event_name=TOUCHPOINT),
        # Feb 8
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 8, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Feb 12
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 12, 9, 0, 0),
                channel_name="Coupon At Till - Main Estate", event_name=TOUCHPOINT),
        # Feb 18 — second conversion
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_2,
                event_ts=datetime(2026, 2, 18, 11, 0, 0),
                channel_name="In-store", subchannel_name="TXN",
                event_name=PURCHASE, net_sales_amt=Decimal("8.0000"), units_qty=Decimal("1.0000")),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (LOYALTY, "NA", datetime(2026, 1, 21, 9, 0, 0), "Social", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 1, "Initiator", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 22, 9, 0, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 2, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 22, 9, 1, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 3, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 24, 10, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 4, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, TXN_1, datetime(2026, 1, 24, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 5, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("5.0000"), Decimal("1.0000"), PRODUCT_TYPE, "in-store"),
            (LOYALTY, "NA", datetime(2026, 1, 25, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 6, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 31, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 7, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 5, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 8, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 5, 9, 1, 0), "Digital Screens - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 9, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 8, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 10, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 12, 9, 0, 0), "Coupon At Till - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 11, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, TXN_2, datetime(2026, 2, 18, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 12, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("8.0000"), Decimal("1.0000"), PRODUCT_TYPE, "in-store"),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_scenario_217_post_last_conversion_touchpoints_dropped(
    spark_session: SparkSession, stub_messenger
):
    """
        Two purchases (Jan27, Feb4); 4 post-conv TPs (Feb6-7) dropped.
        Expected output: 16 rows, all isconversion=1, sub_path=1; no events after Feb4.
        Last purchase Feb4; 4 post-conversion touchpoints (Feb6–7) must be dropped.
    """
    LOYALTY = "0791c7406fc77a83d1180e15808226dcfef3cfc96e30e1a54a7af6971629852c"
    TXN_1 = "txn-217-001"
    TXN_2 = "txn-217-002"

    cdc_rows = [
        # Jan 23
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 23, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 23, 9, 1, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        # Jan 24
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 24, 9, 0, 0),
                channel_name="Digital Screens - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 24, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Jan 27 — first conversion
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_1,
                event_ts=datetime(2026, 1, 27, 10, 0, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_1,
                event_ts=datetime(2026, 1, 27, 10, 30, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_1,
                event_ts=datetime(2026, 1, 27, 11, 0, 0),
                channel_name="In-store", subchannel_name="TXN",
                event_name=PURCHASE, net_sales_amt=Decimal("5.0000"), units_qty=Decimal("1.0000")),
        # Jan 29
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 29, 9, 0, 0),
                channel_name="Digital Screens - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 29, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Jan 30
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 30, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 30, 9, 1, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        # Feb 1
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 1, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 1, 9, 1, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        # Feb 4 — second (last) conversion
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_2,
                event_ts=datetime(2026, 2, 4, 10, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_2,
                event_ts=datetime(2026, 2, 4, 10, 30, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key=TXN_2,
                event_ts=datetime(2026, 2, 4, 11, 0, 0),
                channel_name="In-store", subchannel_name="TXN",
                event_name=PURCHASE, net_sales_amt=Decimal("8.0000"), units_qty=Decimal("1.0000")),
        # Feb 6 — post-conversion, must be dropped
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 6, 9, 0, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 6, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        # Feb 7 — post-conversion, must be dropped
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 7, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 7, 9, 1, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (LOYALTY, "NA", datetime(2026, 1, 23, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 1, "Initiator", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 23, 9, 1, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 2, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 24, 9, 0, 0), "Digital Screens - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 3, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 24, 9, 1, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 4, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 27, 10, 0, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 5, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 27, 10, 30, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 6, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, TXN_1, datetime(2026, 1, 27, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 7, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("5.0000"), Decimal("1.0000"), PRODUCT_TYPE, "in-store"),
            (LOYALTY, "NA", datetime(2026, 1, 29, 9, 0, 0), "Digital Screens - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 8, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 29, 9, 1, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 9, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 30, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 10, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 30, 9, 1, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 11, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 1, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 12, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 1, 9, 1, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 13, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 4, 10, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 14, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 4, 10, 30, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 15, "Assistor", 1, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, TXN_2, datetime(2026, 2, 4, 11, 0, 0), "", "", PURCHASE,
             BOOKING_ID, "", 1, f"{LOYALTY}_1", 16, "Convertor", 1, generated_load_ts, "During", "test-run-id",
             "", Decimal("8.0000"), Decimal("1.0000"), PRODUCT_TYPE, "in-store"),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_scenario_22_non_converted_6_touchpoints(
    spark_session: SparkSession, stub_messenger
):
    """
        6 touchpoints (Fins, EG, DS) across Jan22–Feb2, no purchase.
        Expected output: 6 rows, all isconversion=0, sub_path=1, userjourney_id=loyalty+"_1".
        loyalty_id = 5318ac59c8cdd6fd84c33442890032734975b02e0ed146f65724e377bde5b34a
        6 touchpoints, no Purchase Transaction.
    """
    LOYALTY = "5318ac59c8cdd6fd84c33442890032734975b02e0ed146f65724e377bde5b34a"

    cdc_rows = [
        # Jan 22
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 22, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 22, 9, 1, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        # Jan 24
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 24, 9, 0, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 1, 24, 9, 1, 0),
                channel_name="Digital Screens - Main Estate", event_name=TOUCHPOINT),
        # Feb 2
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 2, 9, 0, 0),
                channel_name="Entrance Gates - Main Estate", event_name=TOUCHPOINT),
        cdc_row(loyalty_id=LOYALTY, transaction_key="NA",
                event_ts=datetime(2026, 2, 2, 9, 1, 0),
                channel_name="Fins - Main Estate", event_name=TOUCHPOINT),
    ]

    result = _run(spark_session, cdc_rows)
    rows = result.filter(F.col("loyalty_id") == LOYALTY)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (LOYALTY, "NA", datetime(2026, 1, 22, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 1, "Initiator", 0, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 22, 9, 1, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 2, "Assistor", 0, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 24, 9, 0, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 3, "Assistor", 0, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 1, 24, 9, 1, 0), "Digital Screens - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 4, "Assistor", 0, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 2, 9, 0, 0), "Entrance Gates - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 5, "Assistor", 0, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
            (LOYALTY, "NA", datetime(2026, 2, 2, 9, 1, 0), "Fins - Main Estate", "Main Estate", TOUCHPOINT,
             BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY}_1", 6, "Assistor", 0, generated_load_ts, "During", "test-run-id",
             "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, ""),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


# ---------------------------------------------------------------------------
# Empty inputs
# ---------------------------------------------------------------------------

def test_empty_cdc_input_produces_empty_output(spark_session: SparkSession, stub_messenger):
    """
    When CDC is empty the output must be an empty DataFrame - not an error.
    The MCE inner join has nothing to match so the result is empty.
    """
    result = _run(spark_session, [])

    assert result.count() == 0


# ---------------------------------------------------------------------------
# Filtering: CDC booking_id not present in MCE
# CDC rows whose booking_id has no matching MCE campaign are silently excluded
# via the inner join in get_latest_campaign_customer_data.
# ---------------------------------------------------------------------------

def testcdc_rows_with_booking_id_not_in_mce_are_excluded(
    spark_session: SparkSession, stub_messenger
):
    """
    CDC has two customers:
      - customer_A: booking_id matches MCE   -> kept
      - customer_B: booking_id not in MCE    -> dropped by inner join

    Only customer_A's rows must appear in the output.
    """
    OTHER_BOOKING = "booking-999"

    cdc_rows = [
        cdc_row(loyalty_id="customer_A", booking_id=BOOKING_ID,
                event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT),
        cdc_row(loyalty_id="customer_A", transaction_key="txn-A", booking_id=BOOKING_ID,
                event_ts=datetime(2026, 1, 23, 11, 0, 0), event_name=PURCHASE),
        cdc_row(loyalty_id="customer_B", booking_id=OTHER_BOOKING,
                event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT),
        cdc_row(loyalty_id="customer_B", transaction_key="txn-B", booking_id=OTHER_BOOKING,
                event_ts=datetime(2026, 1, 23, 11, 0, 0), event_name=PURCHASE),
    ]
    mce_rows = [mce_row(booking_id=BOOKING_ID)]

    result = _run(spark_session, cdc_rows, mce_rows)

    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = result.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (
                "customer_A", "NA", datetime(2026, 1, 23, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, "customer_A_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, "",
            ),
            (
                "customer_A", "txn-A", datetime(2026, 1, 23, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, "customer_A_1", 2, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


# ---------------------------------------------------------------------------
# journey_type column is set from the journey_type parameter, independently
# of product_type.
# ---------------------------------------------------------------------------

def test_journey_type_column_reflects_journey_type_parameter(
    spark_session: SparkSession, stub_messenger
):
    """
    When journey_type='Aisle' and product_type='Offer', every output row must
    have journey_type='Aisle', not 'Offer'.
    """
    when(user_journey_utils).publish_user_journey_metrics(ANY, ANY, ANY).thenReturn(None)
    cdc_rows = [
        cdc_row(event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT),
        cdc_row(transaction_key="txn-001",
                event_ts=datetime(2026, 1, 23, 11, 0, 0), event_name=PURCHASE),
    ]
    cdc_df = spark_session.createDataFrame(cdc_rows, UserJourney.CDC_SCHEMA)
    mce_df = spark_session.createDataFrame([mce_row()], UserJourney.MCE_SCHEMA)

    result = build_user_journey_pollen(
        measurement_campaign_execution_df=mce_df,
        customer_data_collection_df=cdc_df,
        product_type=PRODUCT_TYPE,
        journey_type="Aisle",
        correlation_id="test-run-id",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:test-topic",
    )

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 23, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"), "Aisle", "",
            ),
            (
                LOYALTY_ID, "txn-001", datetime(2026, 1, 23, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 2, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"), "Aisle", "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


# ---------------------------------------------------------------------------
# transaction_key="NA" on a Purchase Transaction event
# ---------------------------------------------------------------------------

def test_purchase_with_transaction_key_na_is_treated_as_conversion(
    spark_session: SparkSession, stub_messenger
):
    """
    A Purchase Transaction row where transaction_key='NA' is unusual but valid.
    isconversion must be 1 because the event_name is the discriminator.
    """
    cdc_rows = [
        cdc_row(event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT,
                transaction_key="NA"),
        cdc_row(transaction_key='txn_1',
                event_ts=datetime(2026, 1, 23, 11, 0, 0), event_name=PURCHASE),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (
                LOYALTY_ID, "NA", datetime(2026, 1, 23, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, "",
            ),
            (
                LOYALTY_ID, 'txn_1', datetime(2026, 1, 23, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 2, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, "in-store",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


# ---------------------------------------------------------------------------
# Timestamp tie-breaking
# ---------------------------------------------------------------------------

def test_timestamp_tie_purchase_ranked_first_gets_initiator_position(
    spark_session: SparkSession, stub_messenger
):
    """
    Touchpoint and Purchase at exactly the same timestamp.
    With ORDER BY event_ts ASC, campaign_id ASC, event_name DESC:
      'transaction' > 'touchpoint' -> purchase rank=1 -> position='Initiator'
      touchpoint rank=2 -> position='Assistor'
    """
    TIE_TS = datetime(2026, 1, 23, 11, 0, 0)

    cdc_rows = [
        cdc_row(event_ts=TIE_TS, event_name=TOUCHPOINT, transaction_key="NA"),
        cdc_row(transaction_key="txn-001", event_ts=TIE_TS, event_name=PURCHASE),
    ]

    result = _run(spark_session, cdc_rows)

    rows = result.filter(F.col("loyalty_id") == LOYALTY_ID)
    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = rows.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (
                LOYALTY_ID, "txn-001", TIE_TS, "", "",
                PURCHASE, BOOKING_ID, "", 1, f"{LOYALTY_ID}_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, "in-store",
            ),
            (
                LOYALTY_ID, "NA", TIE_TS, "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, f"{LOYALTY_ID}_1", 2, "Assistor", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, "",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


# ---------------------------------------------------------------------------
# sub_path and userjourney_id for mixed converted / non-converted customers.
# ---------------------------------------------------------------------------

def test_mixed_customers_have_correct_sub_path_and_userjourney_id(
    spark_session: SparkSession, stub_messenger
):
    """
    Two customers - one converted, one not.
    Both must have sub_path=1 and userjourney_id=<loyalty_id>_1.
    """
    cdc_rows = [
        cdc_row(loyalty_id="customer_A",
                event_ts=datetime(2026, 1, 23, 10, 0, 0), event_name=TOUCHPOINT),
        cdc_row(loyalty_id="customer_A", transaction_key="txn-A",
                event_ts=datetime(2026, 1, 23, 11, 0, 0), event_name=PURCHASE),
        cdc_row(loyalty_id="customer_B", transaction_key="NA",
                event_ts=datetime(2026, 1, 22, 9, 0, 0), event_name=TOUCHPOINT),
        cdc_row(loyalty_id="customer_B", transaction_key="NA",
                event_ts=datetime(2026, 1, 24, 9, 0, 0), event_name=TOUCHPOINT),
    ]

    result = _run(spark_session, cdc_rows)

    selected_columns = UserJourney.UserJourneySchema.fieldNames()
    selected = result.select(*selected_columns)

    generated_load_ts = selected.select("load_ts").first()["load_ts"]

    expected = spark_session.createDataFrame(
        [
            (
                "customer_A", "NA", datetime(2026, 1, 23, 10, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, "customer_A_1", 1, "Initiator", 1, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, "",
            ),
            (
                "customer_A", "txn-A", datetime(2026, 1, 23, 11, 0, 0), "", "",
                PURCHASE, BOOKING_ID, "", 1, "customer_A_1", 2, "Convertor", 1, generated_load_ts, "During",
                "test-run-id", "", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, "in-store",
            ),
            (
                "customer_B", "NA", datetime(2026, 1, 22, 9, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, "customer_B_1", 1, "Initiator", 0, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, "",
            ),
            (
                "customer_B", "NA", datetime(2026, 1, 24, 9, 0, 0), "Fins - Main Estate", "Main Estate",
                TOUCHPOINT, BOOKING_ID, CAMPAIGN_ID, 1, "customer_B_1", 2, "Assistor", 0, generated_load_ts, "During",
                "test-run-id", "default marketing type", Decimal("0.0000"), Decimal("0.0000"), PRODUCT_TYPE, "",
            ),
        ],
        selected.schema,
    )

    assert_df_equality(
        selected,
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )
