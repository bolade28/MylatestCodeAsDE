import os
from decimal import Decimal
from unittest import mock
from datetime import datetime

import pytest
from pyspark.sql import Row, SparkSession

from spark_pipeline.user_journey.user_journey import (
    prepare_user_journey,
    entrypoint,
)
from tests.unit.baseline_processed_data.utils import (
    local_spark_s3_overwrite
)


def test_prepare_user_journey(spark_session: SparkSession, tmpdir: str):

    measurement_campaign_execution_path = os.path.join(tmpdir, "measurement_campaign_execution.parquet")
    campaign_product_type_path = os.path.join(tmpdir, "campaign_product_type.parquet")
    customer_data_collection_path = os.path.join(tmpdir, "customer_data_collection.parquet")
    output_path = os.path.join(tmpdir, "output_path.parquet")
    run_date = "2024-01-01"
    correlation_id = "corr-123"

    (spark_session.createDataFrame([
        Row(item_cd="2934945", product_type="aisle", channel_name="Coupon At Till",
            subchannel_name="CaT Smart Counts 7p", booking_id="df65d6f6-e07a-4dd3-8e2b-123456789abc",
            campaign_id="380139", unique_brand_name="Dairy|General"),])
     .write.mode("overwrite").parquet(campaign_product_type_path))

    (spark_session.createDataFrame([
        Row(loyalty_id="5abcc910e5ff20d02abc123456789def", transaction_key="22c48ed3-ac94-421a-8b1c-def123456789",
            event_ts=datetime(2024, 5, 16, 6, 48, 30),
            channel_name="Coupon At Till", subchannel_name="CaT Smart Counts 7p", campaign_name="Aisle Campaign",
            campaign_id="380139", event_name="transaction",
            booking_id="df65d6f6-e07a-4dd3-8e2b-123456789abc", item_cd="2934945",
            product_type="aisle", net_sales_amt=Decimal("1.2500"), units_qty=Decimal("1.0000"),
            unique_brand_name="Dairy|General", marketing_type="NA",
            load_ts=datetime(2025, 3, 29, 12, 12, 0), purchase_type=""),])
     .write.mode("overwrite").parquet(customer_data_collection_path))

    spark_session.createDataFrame([
        Row(booking_id="df65d6f6-e07a-4dd3-8e2b-123456789abc", campaign_id="380139",
            channel_name="Coupon At Till", subchannel_name="CaT Smart Counts 7p",
            campaign_duration="During", job_status="in-progress"),
    ]).write.mode("overwrite").parquet(measurement_campaign_execution_path)

    with mock.patch(
        "spark_pipeline.user_journey.user_journey.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_user_journey(
            spark=spark_session,
            measurement_campaign_execution_path=measurement_campaign_execution_path,
            campaign_product_type_path=campaign_product_type_path,
            customer_data_collection_path=customer_data_collection_path,
            output_path=output_path,
            product_type="aisle",
            journey_type="Aisle",
            run_date=run_date,
            correlation_id=correlation_id,
            slack_topic_arn="some_topic_arn",
            pipeline_run_type="DTP",
        )

        actual_df = spark_session.read.parquet(output_path)
        assert "loyalty_id" in actual_df.columns


def test_entrypoint(monkeypatch):
    mock_spark = mock.Mock()

    args = [
        "--measurement-campaign-execution-path", "measurement_campaign_execution",
        "--campaign-product-type-path", "campaign_product_type",
        "--customer-data-collection-path", "customer_data_collection",
        "--output-path", "output_path",
        "--product-type", "Aisle",
        "--journey-type", "Aisle",
        "--run-date", "2024-01-01",
        "--correlation-id", "corr-123",
        "--slack-topic-arn", "some_topic_arn",
        "--pipeline-run-type", "DTP",
    ]

    with mock.patch(
            "spark_pipeline.user_journey.user_journey.prepare_user_journey") as mock_func:
        entrypoint(spark=mock_spark, command_line_args=args)

        mock_func.assert_called_once_with(
            spark=mock_spark,
            measurement_campaign_execution_path="measurement_campaign_execution",
            campaign_product_type_path="campaign_product_type",
            customer_data_collection_path="customer_data_collection",
            output_path="output_path",
            product_type="Aisle",
            journey_type="Aisle",
            run_date="2024-01-01",
            slack_topic_arn="some_topic_arn",
            correlation_id="corr-123",
            pipeline_run_type="DTP",
        )


def test_prepare_user_journey_rejects_unknown_pipeline_run_type():
    with pytest.raises(ValueError, match="Unknown pipeline_run_type"):
        prepare_user_journey(
            spark=mock.Mock(),
            measurement_campaign_execution_path="measurement_campaign_execution",
            campaign_product_type_path=None,
            customer_data_collection_path="customer_data_collection",
            output_path="output_path",
            product_type="Aisle",
            journey_type="Aisle",
            run_date="2024-01-01",
            correlation_id="corr-123",
            slack_topic_arn="some_topic_arn",
            pipeline_run_type="invalid",
        )
