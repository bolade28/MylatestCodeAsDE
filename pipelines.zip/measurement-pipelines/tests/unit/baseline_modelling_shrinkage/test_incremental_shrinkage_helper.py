"""
Unit tests for baseline_modelling_shrinkage.incremental_shrinkage_helper

Tests focus on PR feedback requirements:
1. Shift/ln safety with negative uplift values
2. Histogram-based mode selection vs median/mean
3. Negative raw incrementality being zeroed for calibration
"""

import numpy as np
import pytest
from chispa.dataframe_comparer import assert_df_equality
from dataclasses import replace
from unittest.mock import Mock
from datetime import date
from pyspark.sql import types as T, functions as F, Row

from spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage_helper import (
    interval_mode,
    get_median,
    calibrate,
    get_log_normal_params,
    draw_samples,
    outlier_filter,
    get_channel_distribution,
    get_incrementality,
    get_bypass_incrementality,
    check_bypass_channels,
    collect_channel_data,
    get_dynamic_campaign_sample,
    sample_channel_distributions,
    filter_revenue_similarity,
    get_channel_data,
    get_aggregate_prior,
    build_incremental_shrinkage_audit_df,
    normalise_brand_name,
    attach_product_hierarchy,
    aggregate_campaigns_to_brand_grain,
    add_unscaled_incrementality,
)
from tests.unit.baseline_modelling_shrinkage.test_baseline_modelling_shrinkage_mock_data import (
    BaselineModellingShrinkageMockData,
)
from spark_pipeline.common.variables import BaselineModellingShrinkageConfig, CampaignDurations

# Reuse schemas already defined in the mock data class — single source of truth
_BASE_SCHEMAS = BaselineModellingShrinkageMockData.get_base_schemas()

# Maximum spend-window cap used by get_dynamic_campaign_sample (200%).
# Defined here as a named constant so tests don't scatter the magic literal.
_MAX_PERCENTAGE_WINDOW = 2.0


@pytest.fixture
def config():
    """Fixture providing a test configuration."""
    return BaselineModellingShrinkageConfig(
        scaling_exponential_coeff=0.5,
        random_seed=1409,
        alpha=0.5,
    )


class TestIntervalMode:
    """Test the interval_mode function for modal distribution computation."""

    def test_interval_mode_identifies_modal_interval(self, config):
        """Test that interval_mode correctly identifies the highest frequency bin."""
        # Create bimodal distribution with clear peaks
        rng = np.random.default_rng(config.random_seed)
        data = np.concatenate([
            rng.normal(5, 0.3, 8000),   # Large peak at 5
            rng.normal(15, 0.5, 100),   # Smaller tail at 15
        ])

        mode_interval, mode_value, counts, bin_edges = interval_mode(data, bins='auto')

        # Mode should be in the larger peak around 5
        assert 4.5 < mode_value < 5.5, f"Mode {mode_value} should be near primary peak at 5"
        assert mode_interval[0] < mode_value < mode_interval[1]

    def test_interval_mode_vs_mean(self):
        """Test that modal value is not equal to mean for skewed distributions."""
        # Right-skewed: cluster at left, tail at right
        data = np.concatenate([
            np.linspace(1, 3, 100),    # Cluster at left
            np.linspace(50, 100, 10),  # Tail at right
        ])

        mode_interval, mode_value, counts, bin_edges = interval_mode(data, bins='auto')
        mean_value = np.mean(data)

        # Mode should be in dense region, mean pulled up by tail
        assert mode_value < mean_value, \
            f"Mode {mode_value} should be less than mean {mean_value} for right-skewed data"
        assert mode_value < 5

    def test_interval_mode_vs_median(self):
        """Test that modal value differs from median for non-uniform distributions."""
        # Multimodal: strong peaks at 1 and 2, median near 2
        data = np.array([1] * 50 + [2] * 50 + [100])

        mode_interval, mode_value, counts, bin_edges = interval_mode(data, bins='auto')
        median_value = np.median(data)

        # Mode should be distinct from median
        assert 0 < mode_value <= 2.5
        assert 1 <= median_value <= 2.5

    def test_interval_mode_returns_valid_tuple(self, config):
        """Test that interval_mode returns correct structure."""
        data = np.random.default_rng(config.random_seed).normal(5, 2, 1000)

        mode_interval, mode_value, counts, bin_edges = interval_mode(data)

        assert isinstance(mode_interval, tuple)
        assert len(mode_interval) == 2
        assert mode_interval[0] < mode_interval[1]
        assert mode_interval[0] <= mode_value <= mode_interval[1]
        assert len(counts) > 0
        assert len(bin_edges) == len(counts) + 1


class TestGetMedian:
    """Test the get_median helper for median computation and clamping behavior."""

    def test_get_median_returns_standard_median_for_positive_values(self):
        """Median is returned unchanged when values are non-negative."""
        data = np.array([1.0, 3.0, 2.0, 9.0, 5.0])

        median_value = get_median(data)

        assert median_value == 3.0

    def test_get_median_returns_average_for_even_length_input(self):
        """Even-length input should return midpoint of the two middle values."""
        data = [2.0, 4.0, 6.0, 8.0]

        median_value = get_median(data)

        assert median_value == 5.0

    def test_get_median_clamps_negative_result_to_zero(self):
        """Negative medians are clamped to zero for calibration safety."""
        data = np.array([-10.0, -7.0, -4.0, -1.0, -0.5])

        median_value = get_median(data)

        assert median_value == 0


class TestShiftParameterSafety:
    """Test shift parameter ensures log-normal safety with negative uplift."""

    def test_get_log_normal_params_handles_negative_uplift(self, spark_session, config):
        """Test that shift parameter makes all values safe for log (PR requirement #1)."""
        schema = T.StructType([
            T.StructField("campaign_id", T.StringType()),
            T.StructField("uplift", T.DoubleType()),
        ])

        # Data with both negative and positive uplifts
        data = [
            ("camp1", -0.5),   # Negative
            ("camp2", 0.1),    # Small positive
            ("camp3", 0.3),    # Positive
            ("camp4", -0.2),   # Negative
            ("camp5", 0.2),    # Positive
        ]

        df = spark_session.createDataFrame(data, schema=schema)

        # Shift must be >= abs(min_uplift) to ensure all shifted values are positive
        shift_parameter = 0.6  # abs(-0.5) + buffer

        result_df, channel_prior = get_log_normal_params(df, shift_parameter)

        # Verify all shifted values are positive (safe for ln)
        shifted_rows = result_df.select("uplift_shifted", "uplift_log_shifted").collect()
        for row in shifted_rows:
            shifted_val = row["uplift_shifted"]
            log_val = row["uplift_log_shifted"]

            assert shifted_val > 0, \
                f"Shifted uplift {shifted_val} must be positive for log"
            assert not np.isnan(log_val), \
                f"Log value is NaN for shifted uplift {shifted_val}"
            assert not np.isinf(log_val), \
                f"Log value is inf for shifted uplift {shifted_val}"

    def test_insufficient_shift_parameter_fails_safety(self, spark_session):
        """Test that insufficient shift allows non-positive values (proves shift necessity)."""
        schema = T.StructType([
            T.StructField("campaign_id", T.StringType()),
            T.StructField("uplift", T.DoubleType()),
        ])

        data = [("camp1", -1.0), ("camp2", 0.5)]
        df = spark_session.createDataFrame(data, schema=schema)

        # Insufficient shift (doesn't cover -1.0)
        insufficient_shift = 0.5

        result_df, _ = get_log_normal_params(df, insufficient_shift)

        # Should have at least one non-positive shifted value
        non_positive_count = result_df.filter(F.col("uplift_shifted") <= 0).count()
        has_non_positive = non_positive_count > 0

        assert has_non_positive, "Insufficient shift should allow non-positive values"

    def test_shift_with_realistic_negative_scenario(self, spark_session):
        """Test shift safety with realistic negative uplift scenario."""
        mock_data = BaselineModellingShrinkageMockData.get_negative_uplift_scenario(spark_session)
        channel_data = mock_data["historical_campaigns"]

        # Calculate min uplift and appropriate shift
        min_uplift = float(channel_data.agg(F.min("uplift")).collect()[0][0])
        shift_parameter = abs(min_uplift) + 0.1

        # Apply log-normal params
        result_df, channel_prior = get_log_normal_params(channel_data, shift_parameter)

        # Verify no NaN/inf in log values
        nan_count = result_df.filter(
            F.isnan(F.col("uplift_log_shifted")) |
            F.col("uplift_log_shifted").isin(float("inf"), float("-inf"))
        ).count()

        assert nan_count == 0, f"Found {nan_count} NaN/inf values in log-shifted uplifts"


class TestModeSelectionVsMedianMean:
    """Test that calibration uses modal value (PR requirement #2)."""

    def test_calibrate_uses_mode_not_mean(self, config):
        """Test that calibrate() blends with mode, not mean of samples."""
        # Create distribution: large peak at 5.0, tail pushing mean higher
        rng = np.random.default_rng(config.random_seed)
        prior_samples = np.concatenate([
            rng.normal(5.0, 0.3, 8000),   # Primary peak
            np.linspace(50, 100, 100),   # Tail
        ])

        ucm_value = 5.5
        calibrated, audit = calibrate(ucm_value, prior_samples, config)

        # Verify all three measures are computed
        assert "sample_mean" in audit
        assert "sample_median" in audit
        assert "sample_mode" in audit

        mean = audit["sample_mean"]
        mode = audit["sample_mode"]

        # Mean should be pulled higher by tail
        assert mean > mode, \
            f"Mean {mean} should be > mode {mode} due to tail"

        # Mode should be near the peak
        assert 4.8 < mode < 5.2, \
            f"Mode {mode} should be near primary peak at 5.0"

        # Calibrated should be blend of UCM and mode (not mean)
        assert min(ucm_value, mode) <= calibrated <= max(ucm_value, mode), \
            f"Calibrated {calibrated} should be between UCM {ucm_value} and mode {mode}"

    def test_calibrate_audit_contains_mode(self, config):
        """Test that calibrate audit explicitly includes sample_mode."""
        prior_samples = np.random.default_rng(config.random_seed).normal(10.0, 2.0, 5000)
        ucm_value = 12.0

        _, audit = calibrate(ucm_value, prior_samples, config)

        assert "sample_mode" in audit, "Audit must include sample_mode"
        assert isinstance(audit["sample_mode"], (int, float, np.number))
        assert 8 < audit["sample_mode"] < 12, "Mode should be reasonable"

    def test_multimodal_distribution_mode_selection(self, spark_session):
        """Test mode selection with realistic multimodal scenario."""
        mock_data = BaselineModellingShrinkageMockData.get_multimodal_scenario(spark_session)
        uplifts = [
            row["uplift"] for row in
            mock_data["historical_campaigns"].select("uplift").collect()
        ]
        uplift_array = np.array(uplifts)

        mode_interval, mode_value, _, _ = interval_mode(uplift_array)

        # Should identify the larger cluster (3-4%)
        assert 2.8 < mode_value < 4.2, \
            f"Mode {mode_value} should be in primary cluster at ~3.5%"


class TestNegativeIncrementalityZeroing:
    """Test that negative raw incrementality is zeroed before calibration (PR requirement #3)."""

    def test_calibrate_with_zero_input(self, config):
        """Test calibrate behavior when incrementality is zero (post-zeroing)."""
        prior_samples = np.random.default_rng(config.random_seed).normal(10000, 2000, 5000)
        ucm_value = 0.0  # Zeroed negative value

        calibrated, audit = calibrate(ucm_value, prior_samples, config)

        # Should return valid result
        assert not np.isnan(calibrated)
        assert not np.isinf(calibrated)

        # Should be pulled toward prior mode (positive)
        assert calibrated > ucm_value, \
            f"Calibrated {calibrated} should be > 0 UCM"
        assert calibrated > 0, \
            f"Calibrated {calibrated} should be positive when UCM is 0"

    def test_negative_incrementality_scenario_integration(self, spark_session, config):
        """Test full pipeline behavior with negative incrementality data."""
        mock_data = BaselineModellingShrinkageMockData.get_negative_incrementality_scenario(
            spark_session
        )

        baseline_output = mock_data["baseline_modelling_output"]

        # Sum incrementality (will be negative)
        total_incr = float(
            baseline_output.filter(
                F.col("metric_name") == "TOTAL_INCREMENTAL_AMT"
            ).agg(
                F.sum("metric_value")
            ).collect()[0][0]
        )

        assert total_incr < 0, \
            f"Test data should have negative total incrementality, got {total_incr}"

        # Simulate what incremental_shrinkage.py does
        raw_incrementality = total_incr
        if raw_incrementality < 0:
            incrementality_for_calibration = 0.0
        else:
            incrementality_for_calibration = raw_incrementality

        # Verify raw value is preserved but calibration input is 0
        assert raw_incrementality < 0, "Raw should still be negative"
        assert incrementality_for_calibration == 0.0, "Calibration input should be 0"

    def test_calibrate_with_extreme_negative(self, config):
        """Test calibrate with large negative value (edge case)."""
        prior_samples = np.random.default_rng(config.random_seed).normal(15000, 3000, 5000)
        ucm_value = -10000.0  # Large negative

        calibrated, audit = calibrate(ucm_value, prior_samples, config)

        # Should still return valid result
        assert not np.isnan(calibrated)

        # z_score should reflect extreme position
        assert audit["z_score"] > 0.5, \
            "z_score should be high for extreme negative UCM"

        # Should be heavily pulled toward prior
        assert calibrated > ucm_value


class TestDrawSamples:
    """Test draw_samples function for shift parameter application."""

    def test_draw_samples_with_shift_prevents_negative_uplift(self, config):
        """Test that draw_samples respects shift parameter."""
        # Mock channel_prior
        channel_prior = Mock()
        mu = 1.0
        sigma = 0.5

        def mock_select_collect(col_expr):
            mock_result = Mock()
            if "mean" in str(col_expr):
                mock_result.collect.return_value = [Mock(__getitem__=Mock(return_value=mu))]
            else:
                mock_result.collect.return_value = [Mock(__getitem__=Mock(return_value=sigma))]
            return mock_result

        channel_prior.select = mock_select_collect

        shift_parameter = 0.5
        y_samples, incrementality_samples = draw_samples(
            channel_prior,
            media_spend=50000.0,
            median_historical_spend=40000.0,
            alpha=0.5,
            shift_parameter=shift_parameter,
            n_samples=1000,
            random_seed=config.random_seed,
        )

        # Incrementality samples should not go below -shift_parameter
        min_sample = np.min(incrementality_samples)
        assert min_sample >= -shift_parameter, \
            f"Min sample {min_sample} should be >= {-shift_parameter}"

    def test_draw_samples_requires_shift_parameter(self):
        """Test that draw_samples raises error without shift_parameter."""
        channel_prior = Mock()
        channel_prior.select.return_value = Mock(
            collect=Mock(return_value=[Mock(__getitem__=Mock(return_value=1.0))])
        )

        with pytest.raises(ValueError, match="Shift constant must be provided"):
            draw_samples(
                channel_prior,
                50000.0,
                40000.0,
                shift_parameter=None,
                n_samples=1000,
            )

    def test_draw_samples_dampening_ratio_with_higher_spend(self, config):
        """Test that higher media spend increases incrementality samples via dampening."""
        channel_prior = Mock()
        mu = 1.0
        sigma = 0.5

        def mock_select_collect(col_expr):
            mock_result = Mock()
            if "mean" in str(col_expr):
                mock_result.collect.return_value = [Mock(__getitem__=Mock(return_value=mu))]
            else:
                mock_result.collect.return_value = [Mock(__getitem__=Mock(return_value=sigma))]
            return mock_result

        channel_prior.select = mock_select_collect

        median_spend = 40000.0
        shift_parameter = 0.5

        # Lower spend
        _, low_samples = draw_samples(
            channel_prior, 30000.0, median_spend,
            alpha=0.5, shift_parameter=shift_parameter,
            n_samples=1000, random_seed=config.random_seed
        )

        # Higher spend
        _, high_samples = draw_samples(
            channel_prior, 60000.0, median_spend,
            alpha=0.5, shift_parameter=shift_parameter,
            n_samples=1000, random_seed=config.random_seed
        )

        # Higher spend should produce higher mean samples
        assert np.mean(high_samples) > np.mean(low_samples), \
            "Higher spend should result in higher incrementality samples"


class TestCalibrateFunction:
    """Test calibrate function with various scenarios."""

    def test_calibrate_positive_ucm(self, config):
        """Test calibrate with normal positive UCM."""
        prior_samples = np.random.default_rng(config.random_seed).normal(10.0, 1.0, 5000)
        ucm_value = 12.0

        calibrated, audit = calibrate(ucm_value, prior_samples, config)

        assert isinstance(calibrated, (int, float, np.number))
        assert 9 < calibrated < 12
        assert 0 <= audit["z_score"] <= 2
        assert 0 <= audit["scaling_factor"] <= 1

    def test_calibrate_negative_ucm(self, config):
        """Test calibrate with negative UCM."""
        prior_samples = np.random.default_rng(config.random_seed).normal(10.0, 1.0, 5000)
        ucm_value = -5.0

        calibrated, audit = calibrate(ucm_value, prior_samples, config)

        assert isinstance(calibrated, (int, float, np.number))
        assert calibrated > ucm_value  # Pulled toward positive prior
        assert audit["z_score"] > 0.5  # Very few samples negative

    def test_calibrate_ucm_near_mode(self, config):
        """Test calibrate when UCM is near the mode."""
        prior_samples = np.random.default_rng(config.random_seed).normal(10.0, 2.0, 5000)
        ucm_value = 10.0

        calibrated, audit = calibrate(ucm_value, prior_samples, config)

        # z_score should be lower (many samples on both sides)
        assert audit["z_score"] < 0.2
        # With a high z_score and negative exponential coefficient, the calibration
        # should keep most of the UCM signal.
        assert audit["scaling_factor"] > 0.9

    def test_calibrate_ucm_extreme_outlier(self, config):
        """Test calibrate when UCM is extreme outlier."""
        prior_samples = np.random.default_rng(config.random_seed).normal(10.0, 1.0, 5000)
        ucm_value = 100.0

        calibrated, audit = calibrate(ucm_value, prior_samples, config)

        # z_score very high
        assert audit["z_score"] > 0.95
        # Strong scaling (pulled back toward prior)
        assert audit["scaling_factor"] < 0.3


class TestOutlierFilter:
    """Test outlier filtering with mock data."""

    def test_outlier_filter_removes_extreme_campaigns(self, spark_session, config):
        """Test that outlier_filter removes campaigns with extreme metrics."""
        mock_data = BaselineModellingShrinkageMockData.get_extreme_outlier_scenario(
            spark_session
        )
        historical_campaigns = mock_data["historical_campaigns"]

        initial_count = historical_campaigns.count()
        filtered = outlier_filter(historical_campaigns, config)
        filtered_count = filtered.count()

        # Should filter out some campaigns
        assert filtered_count < initial_count, \
            "Outlier filter should remove extreme campaigns"

        # Extreme uplifts should be gone
        max_uplift = float(
            filtered.agg(F.max("uplift")).collect()[0][0]
        )

        # config.pcnt_uplift_max_threshold is 500 (5x as %)
        # uplift of 50% would be (50-0)/0*100 >> threshold, so removed
        assert max_uplift < 30, \
            f"Max uplift {max_uplift} should be below extreme values"

    def test_outlier_filter_empty_input_returns_empty(self, spark_session, config):
        """Test that outlier_filter on an empty DataFrame returns an empty DataFrame."""
        empty_df = spark_session.createDataFrame([], _BASE_SCHEMAS["historical_campaigns"])

        filtered = outlier_filter(empty_df, config)

        assert filtered.count() == 0
        assert filtered.columns == empty_df.columns


class TestChannelDistribution:
    """Test get_channel_distribution integration."""

    def test_get_channel_distribution_returns_samples(self, spark_session, config):
        """Test that get_channel_distribution produces valid samples."""
        mock_data = BaselineModellingShrinkageMockData.get_base_scenario(spark_session)
        channel_data = mock_data["historical_campaigns"].filter(
            F.col("marketing_type") == "INSTORE"
        )

        # Setup
        shift_parameter = 0.0
        media_spend = 50000.0
        median_spend = 50000.0

        incrementality_samples, y_samples, channel_prior, result_df = (
            get_channel_distribution(
                channel_data,
                media_spend,
                median_spend,
                alpha=0.5,
                shift_parameter=shift_parameter,
                n_samples=1000,
                config=config,
            )
        )

        # Verify outputs
        assert len(incrementality_samples) == 1000
        assert len(y_samples) == 1000
        assert incrementality_samples is not None
        assert y_samples is not None

        # Samples should be reasonable (not all NaN/inf)
        assert not np.all(np.isnan(incrementality_samples))
        assert not np.all(np.isinf(incrementality_samples))


class TestBypassIncrementalityAndChannels:
    def test_get_incrementality_bypass_regex_is_case_insensitive(self, spark_session, config):
        campaign_facts = spark_session.createDataFrame(
            [("2026-01-01", "2026-01-31")],
            ["min_campaign_start_dt", "max_campaign_end_dt"]
        ).select(
            F.to_date("min_campaign_start_dt").alias("min_campaign_start_dt"),
            F.to_date("max_campaign_end_dt").alias("max_campaign_end_dt")
        )

        baseline_output = spark_session.createDataFrame(
            [("2026-01-05", "ons_ons_feature", 10.0), ("2026-01-12", "OTHER_METRIC", 5.0)],
            ["week_start_dt", "metric_name", "metric_value"]
        ).select(
            F.to_date("week_start_dt").alias("week_start_dt"),
            "metric_name",
            "metric_value"
        )

        result = get_incrementality(
            campaign_facts,
            baseline_output,
            "bypass-only",
            {"ONSITE": "ons_ons_"},
            config,
        )

        assert result.first()["incrementality"] == 10.0

    def test_get_bypass_incrementality_filters_best_iterations(self, spark_session, config, tmp_path):
        ucm_base_data_path = str(tmp_path / "ucm_base_data.parquet")
        spark_session.createDataFrame(
            [
                ("2026-01-05", "cluster_1", "iter_a", "ons_ons_feature", 10.0),
                ("2026-01-05", "cluster_1", "iter_b", "ons_ons_feature", 100.0),
            ],
            ["wdate", "modelling_cluster", "iteration", "variable", "value"],
        ).select(
            F.to_date("wdate").alias("wdate"),
            "modelling_cluster",
            "iteration",
            "variable",
            "value",
        ).write.mode("overwrite").parquet(ucm_base_data_path)

        campaign_facts = spark_session.createDataFrame(
            [("2026-01-01", "2026-01-31")],
            ["min_campaign_start_dt", "max_campaign_end_dt"],
        ).select(
            F.to_date("min_campaign_start_dt").alias("min_campaign_start_dt"),
            F.to_date("max_campaign_end_dt").alias("max_campaign_end_dt"),
        )

        result = get_bypass_incrementality(
            spark=spark_session,
            ucm_base_data=ucm_base_data_path,
            best_iterations=["iter_a"],
            campaign_facts=campaign_facts,
            bypass_incrementality_filter=config.incrementality_filter_bypass,
            bypass_marketing_types={"ONSITE": "ons_ons_"},
            config=config,
        )

        assert result == 10.0

    def test_check_bypass_channels_by_campaign_duration(self, spark_session, config):
        campaign_facts = spark_session.createDataFrame(
            [("ONSITE",), ("ECOUPON",), ("INSTORE",)],
            ["marketing_type"]
        )

        flag_post, types_post = check_bypass_channels(
            campaign_facts, CampaignDurations.CAMPAIGN_DURATION_POST, config
        )
        assert flag_post is True
        assert set(types_post.keys()) == {"ONSITE", "ECOUPON"}

        flag_during, types_during = check_bypass_channels(
            campaign_facts, CampaignDurations.CAMPAIGN_DURATION_DURING, config
        )
        assert flag_during is True
        assert set(types_during.keys()) == {"ONSITE"}

        flag_unknown, types_unknown = check_bypass_channels(campaign_facts, "UNKNOWN", config)
        assert flag_unknown is False
        assert types_unknown == {}


# ---- normalise_brand_name tests ----


def test_normalise_brand_name_strips_accented_characters(spark_session):
    """Core NUP-25376 case: accented chars should be removed."""
    df = spark_session.createDataFrame([("NESCAFÉ | NESTLÉ",)], ["brand"])
    result = df.select(normalise_brand_name(F.col("brand")).alias("norm")).collect()
    assert result[0]["norm"] == "NESCAF | NESTL"


def test_normalise_brand_name_already_ascii_unchanged(spark_session):
    """Already-stripped brand names should remain identical after normalisation."""
    df = spark_session.createDataFrame([("NESCAF | NESTL",)], ["brand"])
    result = df.select(normalise_brand_name(F.col("brand")).alias("norm")).collect()
    assert result[0]["norm"] == "NESCAF | NESTL"


def test_normalise_brand_name_uppercases_and_trims(spark_session):
    """normalise_brand_name should upper-case and trim whitespace."""
    df = spark_session.createDataFrame([("  nescafé  ",)], ["brand"])
    result = df.select(normalise_brand_name(F.col("brand")).alias("norm")).collect()
    assert result[0]["norm"] == "NESCAF"


def test_add_unscaled_incrementality_reverses_positive_spend_weight(spark_session):
    df = spark_session.createDataFrame(
        [(100.0, 0.5), (100.0, None), (100.0, 0.0), (100.0, 2.0)],
        ["incremental_sales_amt_exposed", "SPEND_WEIGHT"],
    )

    actual = [
        row.unscaled_incrementality
        for row in add_unscaled_incrementality(df).select("unscaled_incrementality").collect()
    ]

    assert actual == [200.0, 100.0, 100.0, 50.0]


def test_add_unscaled_incrementality_without_spend_weight(spark_session):
    df = spark_session.createDataFrame(
        [(100.0,)], ["incremental_sales_amt_exposed"]
    )

    actual = add_unscaled_incrementality(df).first().unscaled_incrementality

    assert actual == 100.0


def test_normalise_brand_name_standard_ascii_unchanged(spark_session):
    """Plain ASCII brand names (e.g. WALKERS) pass through unchanged."""
    df = spark_session.createDataFrame([("WALKERS",)], ["brand"])
    result = df.select(normalise_brand_name(F.col("brand")).alias("norm")).collect()
    assert result[0]["norm"] == "WALKERS"


def test_normalise_brand_name_both_sides_match(spark_session):
    """Stripped and accented variants normalise identically — proving the join fix works."""
    df = spark_session.createDataFrame(
        [("NESCAFÉ | NESTLÉ", "NESCAF | NESTL")], ["accented", "stripped"]
    )
    result = df.select(
        normalise_brand_name(F.col("accented")).alias("norm_accented"),
        normalise_brand_name(F.col("stripped")).alias("norm_stripped"),
    ).collect()[0]
    assert result["norm_accented"] == result["norm_stripped"]


def test_aggregate_campaigns_to_brand_grain_preserves_campaign_metrics(spark_session):
    """Campaign metrics are not double-counted when restoring the legacy brand grain."""
    # Arrange: create item-level campaign input and product hierarchy.
    legacy_source = spark_session.createDataFrame(
        [
            ("campaign-1", "item-1", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 100.0, 90.0, 0.1, 50.0),
            ("campaign-1", "item-2", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 100.0, 90.0, 0.1, 50.0),
            ("campaign-1", "item-3", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 100.0, 90.0, 0.1, 50.0),
        ],
        "campaign_id string, item_cd string, campaign_source string, period string, campaign_start_date date, campaign_end_date date, test double, control double, uplift double, media_cost double",
    )
    brand_data = spark_session.createDataFrame(
        [
            ("item-1", "GROCERY", "SNACKS", "BRAND A"),
            ("item-2", "GROCERY", "SNACKS", "BRAND A"),
            ("item-3", "GROCERY", "DRINKS", "BRAND B"),
        ],
        "item_cd string, super_category_name string, sub_category_name string, unique_brand_name string",
    )

    # Act: aggregate the item-level campaign rows to the legacy brand grain.
    legacy_campaigns = aggregate_campaigns_to_brand_grain(legacy_source, brand_data)

    # Assert: preserve campaign metrics while aggregating the product hierarchy.
    legacy_row = legacy_campaigns.collect()[0]
    assert legacy_row["test"] == 100.0
    assert legacy_row["media_cost"] == 50.0
    assert legacy_row["sub_category_name_list"] == "DRINKS, SNACKS"
    assert legacy_row["unique_brand_name_list"] == "BRAND A, BRAND B"
    assert legacy_row["num_unique_subcats"] == 2
    assert legacy_row["num_unique_brands"] == 2


def test_aggregate_campaigns_to_brand_grain_drops_unmapped_items(spark_session):
    """Campaign rows without product hierarchy mappings should be excluded by the inner join."""
    # Arrange: create campaign data whose items are missing from the product hierarchy.
    legacy_source = spark_session.createDataFrame(
        [
            ("campaign-1", "missing-item", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 100.0, 90.0, 0.1, 50.0),
        ],
        "campaign_id string, item_cd string, campaign_source string, period string, campaign_start_date date, campaign_end_date date, test double, control double, uplift double, media_cost double",
    )
    brand_data = spark_session.createDataFrame(
        [
            ("item-1", "GROCERY", "SNACKS", "BRAND A"),
        ],
        "item_cd string, super_category_name string, sub_category_name string, unique_brand_name string",
    )

    # Act: aggregate to campaign/brand grain using a hierarchy that does not match.
    legacy_campaigns = aggregate_campaigns_to_brand_grain(legacy_source, brand_data)

    # Assert: no rows remain because the helper intentionally performs an inner join.
    assert legacy_campaigns.count() == 0


def test_to_attach_product_hierarchy_aggregates_weekly_spend_by_brand(spark_session):
    """Weekly spend is attached to the product hierarchy and averaged by week and brand."""
    # Arrange: create item-level weekly spend input and product hierarchy.
    weekly_spend_source = spark_session.createDataFrame(
        [
            ("item-1", 2023, "SC", "SUB", "2023-01-02", 10.0, 100.0, 110.0),
            ("item-1", 2023, "SC", "SUB", "2023-01-09", 10.0, 120.0, 132.0),
            ("item-2", 2023, "SC", "SUB", "2023-01-02", 10.0, 200.0, 220.0),
            ("item-2", 2023, "SC", "SUB", "2023-01-09", 10.0, 220.0, 242.0),
            ("item-3", 2023, "SC", "OTHER", "2023-01-02", 10.0, 300.0, 330.0),
            ("item-3", 2023, "SC", "OTHER", "2023-01-09", 10.0, 360.0, 396.0),
        ],
        "item_cd string, year int, super_cat_cd string, sub_cat_cd string, week string, inflation_ratio double, avg_weekly_spend double, avg_weekly_spend_inf_adj double",
    )
    brand_data = spark_session.createDataFrame(
        [
            ("item-1", "GROCERY", "SNACKS", "BRAND A"),
            ("item-2", "GROCERY", "SNACKS", "BRAND A"),
            ("item-3", "GROCERY", "DRINKS", "BRAND B"),
        ],
        "item_cd string, super_category_name string, sub_category_name string, unique_brand_name string",
    )

    # Act: attach the hierarchy and aggregate spend to the legacy brand grain.
    weekly_spend = attach_product_hierarchy(weekly_spend_source, brand_data)

    # Assert: spend is averaged across weeks for each brand hierarchy key.
    spend_by_brand = {
        row["unique_brand_name"]: row["avg_weekly_spend"]
        for row in weekly_spend.select("unique_brand_name", "avg_weekly_spend").collect()
    }
    assert spend_by_brand == {"BRAND A": 320.0, "BRAND B": 330.0}


def test_to_attach_product_hierarchy_drops_unmapped_spend_rows(spark_session):
    """Spend rows without a hierarchy mapping should be excluded by the inner join."""
    # Arrange: create spend data where one item has no product hierarchy mapping.
    weekly_spend_source = spark_session.createDataFrame(
        [
            ("item-1", 2023, "SC", "SUB", "2023-01-02", 10.0, 100.0, 110.0),
            ("missing-item", 2023, "SC", "SUB", "2023-01-02", 10.0, 999.0, 1098.9),
        ],
        "item_cd string, year int, super_cat_cd string, sub_cat_cd string, week string, inflation_ratio double, avg_weekly_spend double, avg_weekly_spend_inf_adj double",
    )
    brand_data = spark_session.createDataFrame(
        [
            ("item-1", "GROCERY", "SNACKS", "BRAND A"),
        ],
        "item_cd string, super_category_name string, sub_category_name string, unique_brand_name string",
    )

    # Act: attach the hierarchy and aggregate the spend data.
    weekly_spend = attach_product_hierarchy(weekly_spend_source, brand_data)

    # Assert: only mapped spend remains in the aggregated output.
    rows = weekly_spend.collect()
    assert len(rows) == 1
    assert rows[0]["unique_brand_name"] == "BRAND A"
    assert rows[0]["avg_weekly_spend"] == 100.0


# filter_revenue_similarity brand-encoding tests ----


def test_filter_revenue_similarity_succeeds_with_accent_stripped_brand(spark_session, config):
    """campaign_selection data has accent-stripped brand
    ('NESCAF | NESTL') while benchmark_spend_data has the original accented brand
    ('NESCAFÉ | NESTLÉ').  Before the fix this raised:
      TypeError: float() argument must be a string or a real number, not 'NoneType'
    After the fix the join resolves correctly and a valid result is returned.
    """
    schemas = BaselineModellingShrinkageMockData.get_base_schemas()

    # campaign_selection upstream strips non-ASCII -> 'NESCAF | NESTL'
    campaign_metadata = spark_session.createDataFrame(
        [("BEVERAGES", "COFFEE", "NESCAF | NESTL", 2026)],
        schemas["campaign_metadata"],
    )
    # benchmark_spend_data retains the original accented brand
    benchmark_spend_data = spark_session.createDataFrame(
        [(2026, "BEVERAGES", "COFFEE", "NESCAFÉ | NESTLÉ", 60000.0)],
        schemas["benchmark_spend_data"],
    )
    # Empty historical campaigns — search_df will be empty, which is acceptable;
    # we only care that target_spend resolves without error.
    historical_campaigns = spark_session.createDataFrame([], schemas["historical_campaigns"])

    subset, rev_p = filter_revenue_similarity(
        historical_campaigns,
        benchmark_spend_data,
        campaign_metadata,
        config,
        "INSTORE",
        1,
    )

    assert subset is not None
    assert isinstance(rev_p, float)


def test_filter_revenue_similarity_raises_value_error_for_unknown_brand(spark_session, config):
    """When the brand is genuinely absent from benchmark_spend_data (not just an encoding
    mismatch), filter_revenue_similarity should raise a descriptive ValueError — not the
    cryptic TypeError that leaked from get_dynamic_campaign_sample before the None guard
    was tightened.
    """
    schemas = BaselineModellingShrinkageMockData.get_base_schemas()

    campaign_metadata = spark_session.createDataFrame(
        [("BEVERAGES", "COFFEE", "COMPLETELY UNKNOWN BRAND", 2026)],
        schemas["campaign_metadata"],
    )
    benchmark_spend_data = spark_session.createDataFrame(
        [(2026, "BEVERAGES", "COFFEE", "NESCAFÉ | NESTLÉ", 60000.0)],
        schemas["benchmark_spend_data"],
    )
    historical_campaigns = spark_session.createDataFrame([], schemas["historical_campaigns"])

    with pytest.raises(ValueError, match="No target spend found for"):
        filter_revenue_similarity(
            historical_campaigns,
            benchmark_spend_data,
            campaign_metadata,
            config,
            "INSTORE",
            1,
        )


class TestGetDynamicCampaignSample:
    """Test get_dynamic_campaign_sample with edge cases and error conditions."""

    def test_get_dynamic_campaign_sample_finds_sample_within_initial_window(
        self, spark_session, config
    ):
        """Test happy path where sufficient campaigns found in initial narrow window."""
        # === ARRANGE: Set up test data with campaigns tightly clustered around target spend
        schema = T.StructType([
            T.StructField("avg_weekly_spend", T.DoubleType()),
            T.StructField("campaign_id", T.StringType()),
        ])
        target_spend = 50000.0
        data = [Row(avg_weekly_spend=49000.0 + i * 10, campaign_id=f"c{i}")
                for i in range(60)]
        benchmark_spends = spark_session.createDataFrame(data, schema=schema)

        # === ACT: Call get_dynamic_campaign_sample to find matching campaigns
        subset, window = get_dynamic_campaign_sample(
            benchmark_spends,
            target_spend,
            channel="INSTORE",
            config=config,
            filter_pass_no=1
        )

        # === ASSERT: Verify all campaigns found within initial narrow window
        assert subset.count() == 60, "Should find all campaigns in tight cluster"
        assert window == config.initial_percentage_window, "Window should not expand for sufficient pass-1 data"

    def test_get_dynamic_campaign_sample_expands_window_iteratively(
        self, spark_session, config
    ):
        """Test that window expands when insufficient data in narrow range."""
        # === ARRANGE: Set up sparse data with few campaigns near target, many far away
        schema = T.StructType([
            T.StructField("avg_weekly_spend", T.DoubleType()),
            T.StructField("campaign_id", T.StringType()),
        ])
        target_spend = 50000.0
        data = (
            [Row(avg_weekly_spend=48000.0 + i * 100, campaign_id=f"near_{i}")
             for i in range(2)]  # Only 2 near target
            + [Row(avg_weekly_spend=20000.0 + i * 1000, campaign_id=f"far_{i}")
               for i in range(25)]  # Many far away
        )
        benchmark_spends = spark_session.createDataFrame(data, schema=schema)

        # === ACT: Call function which should iteratively expand window to find data
        subset, window = get_dynamic_campaign_sample(
            benchmark_spends,
            target_spend,
            channel="INSTORE",
            config=config,
            filter_pass_no=1
        )

        # === ASSERT: Verify enough campaigns found after window expansion
        assert window > config.initial_percentage_window, "Window should expand when initial range is insufficient"
        assert window >= _MAX_PERCENTAGE_WINDOW, "Should reach max window when pass-1 minimum is unattainable"
        assert subset.count() == len(data), "Should return all input campaigns when max window captures full range"

    def test_get_dynamic_campaign_sample_insufficient_data_returns_best_effort(
        self, spark_session, config
    ):
        """Test edge case: insufficient campaigns even at max window.
        Note: Although get_dynamic_campaign_sample returns a value for single campaign, there is already a failsafe implemented to prevent building prior with less campaigns "overall=20".
              This test is just to check that the function returns what it can and does not error out."""
        # === ARRANGE: Set up single campaign far from target (extreme data scarcity)
        schema = T.StructType([
            T.StructField("avg_weekly_spend", T.DoubleType()),
            T.StructField("campaign_id", T.StringType()),
        ])
        target_spend = 50000.0
        data = [Row(avg_weekly_spend=10000.0, campaign_id="c1")]
        benchmark_spends = spark_session.createDataFrame(data, schema=schema)

        # === ACT: Call function with insufficient data to meet minimum requirements
        subset, window = get_dynamic_campaign_sample(
            benchmark_spends,
            target_spend,
            channel="INSTORE",
            config=config,
            filter_pass_no=1
        )

        # === ASSERT: Verify window reaches max and returns best effort result
        assert window >= _MAX_PERCENTAGE_WINDOW, "Should reach maximum configured window when data insufficient"
        assert subset.count() <= len(data), "Should return at most the available input campaigns"

    def test_get_dynamic_campaign_sample_exact_boundary_match(
        self, spark_session, config
    ):
        """Test campaigns at exact boundary of acceptance window."""
        # === ARRANGE: Create campaigns positioned exactly at window boundaries and center
        schema = T.StructType([
            T.StructField("avg_weekly_spend", T.DoubleType()),
            T.StructField("campaign_id", T.StringType()),
        ])
        target_spend = 50000.0
        window = config.initial_percentage_window
        lower_bound = target_spend * (1 - window)
        upper_bound = target_spend * (1 + window)
        data = [
            Row(avg_weekly_spend=lower_bound, campaign_id="lower"),
            Row(avg_weekly_spend=upper_bound, campaign_id="upper"),
            Row(avg_weekly_spend=target_spend, campaign_id="center"),
        ] + [
            Row(avg_weekly_spend=49900.0 + i * 2, campaign_id=f"in_{i}")
            for i in range(57)
        ]
        benchmark_spends = spark_session.createDataFrame(data, schema=schema)

        # === ACT: Call function with boundary-aligned campaigns
        subset, returned_window = get_dynamic_campaign_sample(
            benchmark_spends,
            target_spend,
            channel="INSTORE",
            config=config,
            filter_pass_no=1
        )

        # === ASSERT: Verify all boundary campaigns are included at initial window
        assert subset.count() == 60, "All campaigns including boundaries should be included"
        assert returned_window == config.initial_percentage_window, "Window should not expand"

    def test_get_dynamic_campaign_sample_decimal_target_spend(
        self, spark_session, config
    ):
        """Test with Decimal type target spend (edge case)."""
        # === ARRANGE: Set up data with Decimal type target spend (financial precision edge case)
        from decimal import Decimal
        schema = T.StructType([
            T.StructField("avg_weekly_spend", T.DoubleType()),
            T.StructField("campaign_id", T.StringType()),
        ])
        target_spend = Decimal("50000.50")
        data = [Row(avg_weekly_spend=50000.0 + i * 100, campaign_id=f"c{i}")
                for i in range(5)]
        benchmark_spends = spark_session.createDataFrame(data, schema=schema)

        # === ACT: Call function with Decimal type (should convert to float internally)
        subset, window = get_dynamic_campaign_sample(
            benchmark_spends,
            target_spend,
            channel="INSTORE",
            config=config,
            filter_pass_no=1
        )

        # === ASSERT: Verify function handles Decimal type without errors
        # 5 campaigns < min_n['pass_1']['INSTORE']=50, so window expands to the max cap.
        # At that cap, bounds are wide enough to capture all input campaigns.
        assert window >= _MAX_PERCENTAGE_WINDOW, "Window should expand to max when campaigns < min_n"
        assert subset.count() == len(data), "All input campaigns should be captured at max window"
        assert isinstance(window, float), "Window should be float after Decimal conversion"


class TestFilterRevenueSimilarity:
    """Test filter_revenue_similarity with edge cases."""

    def test_search_df_both_near_and_far_campaigns_survive_join(
        self, spark_session,
    ):
        """Proves that the search_df inner join does NOT drop the 'far' campaign due to
        sub_category mismatch.

        The join is on [year, sub_category_name, unique_brand_name] against benchmark_spend_data
        (not campaign_metadata), so each historical campaign only needs a matching row in the
        benchmark for its own sub_category/brand — not the target campaign's sub_category.

        Both campaigns survive with their own benchmark spend:
          - near_0 (WALKERS/CRISPS) → avg_weekly_spend=50,000
          - far    (PRINGLES/CHIPS) → avg_weekly_spend=1,000

        The 'far' campaign is excluded only afterwards in get_dynamic_campaign_sample,
        because 1,000 falls outside the spend window around target_spend=50,000.
        """
        benchmark_spend_data = spark_session.createDataFrame(
            [
                Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                    unique_brand_name="WALKERS", avg_weekly_spend=50000.0),
                Row(year=2023, super_category_name="CRISPS", sub_category_name="CHIPS",
                    unique_brand_name="PRINGLES", avg_weekly_spend=1000.0),
            ],
            _BASE_SCHEMAS["benchmark_spend_data"],
        )
        historical_campaigns = spark_session.createDataFrame(
            [
                Row(
                    campaign_id="near_0", campaign_source="src", period="DURING",
                    campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                    marketing_type="INSTORE", super_category_name="CRISPS",
                    sub_category_name_list="CRISPS", unique_brand_name_list="WALKERS",
                    test=400000.0, control=375000.0, uplift=0.05, iroas=8.5, media_cost=49000.0,
                ),
                Row(
                    campaign_id="far", campaign_source="src", period="DURING",
                    campaign_start_date=date(2023, 2, 1), campaign_end_date=date(2023, 2, 28),
                    marketing_type="INSTORE", super_category_name="CRISPS",
                    sub_category_name_list="CHIPS", unique_brand_name_list="PRINGLES",
                    test=420000.0, control=395000.0, uplift=0.06, iroas=9.0, media_cost=1000.0,
                ),
            ],
            _BASE_SCHEMAS["historical_campaigns"],
        )

        # Replicate the search_df construction from filter_revenue_similarity
        search_df = (
            historical_campaigns
            .withColumn("sub_category_name", F.explode(F.split("sub_category_name_list", ", ")))
            .withColumn("unique_brand_name", F.explode(F.split("unique_brand_name_list", ", ")))
            .withColumn("year", F.year("campaign_start_date"))
            .join(benchmark_spend_data, ["year", "sub_category_name", "unique_brand_name"], "inner")
            .groupBy("campaign_id", "campaign_source")
            .agg(
                F.avg("uplift").alias("uplift"),
                F.sum("avg_weekly_spend").alias("avg_weekly_spend"),
            )
        )

        rows = {r["campaign_id"]: r for r in search_df.collect()}
        print(f"\nsearch_df campaigns after join: {list(rows.keys())}")
        for cid, r in rows.items():
            print(f"  {cid}: avg_weekly_spend={r['avg_weekly_spend']}")

        # Both campaigns must survive the join
        assert "near_0" in rows, "near_0 (WALKERS/CRISPS) must survive the join"
        assert "far" in rows, "far (PRINGLES/CHIPS) must survive the join — CHIPS matches the PRINGLES benchmark entry"

        # Each receives the spend from its OWN benchmark entry, not the target's
        assert rows["near_0"]["avg_weekly_spend"] == 50000.0, \
            "near_0 should get avg_weekly_spend=50000 from WALKERS/CRISPS benchmark"
        assert rows["far"]["avg_weekly_spend"] == 1000.0, \
            "far should get avg_weekly_spend=1000 from PRINGLES/CHIPS benchmark"

    def test_filter_revenue_similarity_excludes_campaigns_outside_spend_window(
        self, spark_session, config,
    ):
        """Test that campaigns with dissimilar spend to the target are excluded."""
        # === ARRANGE: One campaign near target spend, one far away
        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )
        # Target spend = 50000 (from WALKERS/CRISPS/2023 benchmark entry)
        benchmark_spend_data = spark_session.createDataFrame(
            [
                Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                    unique_brand_name="WALKERS", avg_weekly_spend=50000.0),
                # Separate benchmark entry for the "far" campaign at a very different spend
                Row(year=2023, super_category_name="CRISPS", sub_category_name="CHIPS",
                    unique_brand_name="PRINGLES", avg_weekly_spend=1000.0),
            ],
            _BASE_SCHEMAS["benchmark_spend_data"]
        )
        historical_campaigns = spark_session.createDataFrame([
            # 50 campaigns joined to WALKERS benchmark (avg_weekly_spend=50000) — within 10% window
            *[
                Row(
                    campaign_id=f"near_{i}", campaign_source="src", period="DURING",
                    campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                    marketing_type="INSTORE", super_category_name="CRISPS",
                    sub_category_name_list="CRISPS", unique_brand_name_list="WALKERS",
                    test=400000.0, control=375000.0, uplift=0.05, iroas=8.5,
                    media_cost=49000.0 + i * 10,
                )
                for i in range(50)
            ],
            # "far" campaign joined to PRINGLES benchmark (avg_weekly_spend=1000) — outside 10% window
            Row(
                campaign_id="far", campaign_source="src", period="DURING",
                campaign_start_date=date(2023, 2, 1), campaign_end_date=date(2023, 2, 28),
                marketing_type="INSTORE", super_category_name="CRISPS",
                sub_category_name_list="CHIPS", unique_brand_name_list="PRINGLES",
                test=420000.0, control=395000.0, uplift=0.06, iroas=9.0,
                media_cost=1000.0,
            ),
        ], _BASE_SCHEMAS["historical_campaigns"])

        # === ACT: Filter by revenue similarity against target spend
        filtered, _ = filter_revenue_similarity(
            historical_campaigns,
            benchmark_spend_data,
            campaign_metadata,
            config,
            channel="INSTORE",
            filter_pass_no=1,
        )

        # === ASSERT: All 50 near-spend campaigns retained; far campaign excluded
        expected_ids = spark_session.createDataFrame(
            [Row(campaign_id=f"near_{i}") for i in range(50)]
        )
        assert_df_equality(
            filtered.select("campaign_id").orderBy("campaign_id"),
            expected_ids.orderBy("campaign_id"),
            ignore_nullable=True,
        )

    def test_filter_revenue_similarity_retains_all_campaigns_within_window(
        self, spark_session, config,
    ):
        """Happy path: all campaigns within spend window, none excluded."""
        # === ARRANGE: All campaigns close to target spend — all should survive
        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )
        benchmark_spend_data = spark_session.createDataFrame(
            [Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", avg_weekly_spend=50000.0)],
            _BASE_SCHEMAS["benchmark_spend_data"]
        )
        historical_campaigns = spark_session.createDataFrame([
            Row(
                campaign_id=f"c{i}", campaign_source="src", period="DURING",
                campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                marketing_type="INSTORE", super_category_name="CRISPS",
                sub_category_name_list="CRISPS", unique_brand_name_list="WALKERS",
                test=400000.0, control=375000.0, uplift=0.05, iroas=8.5,
                media_cost=49000.0 + i * 10,
            )
            for i in range(50)
        ], _BASE_SCHEMAS["historical_campaigns"])

        # === ACT
        filtered, _ = filter_revenue_similarity(
            historical_campaigns,
            benchmark_spend_data,
            campaign_metadata,
            config,
            channel="INSTORE",
            filter_pass_no=1,
        )

        # === ASSERT: All 50 campaigns within window are retained
        assert_df_equality(
            filtered.select("campaign_id").orderBy("campaign_id"),
            historical_campaigns.select("campaign_id").orderBy("campaign_id"),
            ignore_nullable=True,
        )

    def test_filter_revenue_similarity_excludes_all_campaigns_outside_window(
        self, spark_session, config,
    ):
        """Negative case: all campaigns far from target spend → empty result.

        filter_revenue_similarity filters by avg_weekly_spend (from the benchmark join),
        not by media_cost.  For campaigns to be excluded even at the maximum 200% window,
        their benchmark avg_weekly_spend must lie outside
        [target*(1-2.0), target*(1+2.0)] = [-50000, 150000].
        Here target=50000 (WALKERS), and the historical campaigns use PRINGLES whose
        benchmark spend is 200,000 — always above the 150,000 upper bound.
        """
        # === ARRANGE: Target campaign = WALKERS @ 50000; historical pool = PRINGLES @ 200000
        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )
        benchmark_spend_data = spark_session.createDataFrame(
            [
                Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                    unique_brand_name="WALKERS", avg_weekly_spend=50000.0),
                # PRINGLES spend=200,000 is 4x the target (50,000), above the 200%-window ceiling of 150,000
                Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                    unique_brand_name="PRINGLES", avg_weekly_spend=200000.0),
            ],
            _BASE_SCHEMAS["benchmark_spend_data"]
        )
        # All historical campaigns are PRINGLES → avg_weekly_spend=200000 after join,
        # which is above the 200%-window ceiling of 150000 → all excluded at every window.
        historical_campaigns = spark_session.createDataFrame([
            Row(
                campaign_id=f"far_{i}", campaign_source="src", period="DURING",
                campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                marketing_type="INSTORE", super_category_name="CRISPS",
                sub_category_name_list="CRISPS", unique_brand_name_list="PRINGLES",
                test=400000.0, control=375000.0, uplift=0.05, iroas=8.5,
                media_cost=900.0 + i * 5,
            )
            for i in range(50)
        ], _BASE_SCHEMAS["historical_campaigns"])

        # === ACT
        filtered, _ = filter_revenue_similarity(
            historical_campaigns,
            benchmark_spend_data,
            campaign_metadata,
            config,
            channel="INSTORE",
            filter_pass_no=1,
        )

        # === ASSERT: All campaigns excluded as they are far from target spend
        empty_expected = spark_session.createDataFrame(
            [], T.StructType([T.StructField("campaign_id", T.StringType())])
        )
        assert_df_equality(
            filtered.select("campaign_id"),
            empty_expected,
            ignore_nullable=True,
        )

    def test_filter_revenue_similarity_excludes_campaigns_below_min_avg_weekly_spend(
        self, spark_session, config,
    ):
        """Test that a historical campaign is dropped by config.min_avg_weekly_spend even
        when its spend is proportionally close enough to the target to otherwise pass the
        revenue-similarity window.

        Target spend = 1050 (WALKERS/CRISPS). 'low_spend' joins to PRINGLES/CHIPS with
        avg_weekly_spend=999, only ~4.9% below target — well within the 10% initial window —
        yet it must still be excluded because 999 < config.min_avg_weekly_spend (1000).
        """
        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )
        benchmark_spend_data = spark_session.createDataFrame(
            [
                Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                    unique_brand_name="WALKERS", avg_weekly_spend=1050.0),
                # Below config.min_avg_weekly_spend (1000) despite being close to the target.
                Row(year=2023, super_category_name="CRISPS", sub_category_name="CHIPS",
                    unique_brand_name="PRINGLES", avg_weekly_spend=999.0),
            ],
            _BASE_SCHEMAS["benchmark_spend_data"]
        )
        historical_campaigns = spark_session.createDataFrame([
            # 50 campaigns joined to WALKERS benchmark (avg_weekly_spend=1050) — satisfies min_n
            *[
                Row(
                    campaign_id=f"elig_{i}", campaign_source="src", period="DURING",
                    campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                    marketing_type="INSTORE", super_category_name="CRISPS",
                    sub_category_name_list="CRISPS", unique_brand_name_list="WALKERS",
                    test=400000.0, control=375000.0, uplift=0.05, iroas=8.5,
                    media_cost=49000.0 + i * 10,
                )
                for i in range(50)
            ],
            # Joined to PRINGLES benchmark (avg_weekly_spend=999) — below min_avg_weekly_spend
            Row(
                campaign_id="low_spend", campaign_source="src", period="DURING",
                campaign_start_date=date(2023, 2, 1), campaign_end_date=date(2023, 2, 28),
                marketing_type="INSTORE", super_category_name="CRISPS",
                sub_category_name_list="CHIPS", unique_brand_name_list="PRINGLES",
                test=420000.0, control=395000.0, uplift=0.06, iroas=9.0,
                media_cost=1000.0,
            ),
        ], _BASE_SCHEMAS["historical_campaigns"])

        # === ACT
        filtered, _ = filter_revenue_similarity(
            historical_campaigns,
            benchmark_spend_data,
            campaign_metadata,
            config,
            channel="INSTORE",
            filter_pass_no=1,
        )

        # === ASSERT: low_spend excluded despite proximity; all 50 eligible campaigns retained
        actual_ids = {row["campaign_id"] for row in filtered.select("campaign_id").collect()}
        assert "low_spend" not in actual_ids, "Campaign below config.min_avg_weekly_spend should be excluded"
        assert actual_ids == {f"elig_{i}" for i in range(50)}, (
            f"Expected only the 50 eligible campaigns, got {actual_ids}"
        )

    def test_filter_revenue_similarity_retains_campaign_at_min_avg_weekly_spend_boundary(
        self, spark_session, config,
    ):
        """Boundary test: a campaign with avg_weekly_spend exactly equal to
        config.min_avg_weekly_spend should be retained (filter uses >=, not >).
        """
        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )
        benchmark_spend_data = spark_session.createDataFrame(
            [Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", avg_weekly_spend=float(config.min_avg_weekly_spend))],
            _BASE_SCHEMAS["benchmark_spend_data"]
        )
        historical_campaigns = spark_session.createDataFrame([
            Row(
                campaign_id=f"c{i}", campaign_source="src", period="DURING",
                campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                marketing_type="INSTORE", super_category_name="CRISPS",
                sub_category_name_list="CRISPS", unique_brand_name_list="WALKERS",
                test=400000.0, control=375000.0, uplift=0.05, iroas=8.5,
                media_cost=49000.0 + i * 10,
            )
            for i in range(50)
        ], _BASE_SCHEMAS["historical_campaigns"])

        # === ACT
        filtered, _ = filter_revenue_similarity(
            historical_campaigns,
            benchmark_spend_data,
            campaign_metadata,
            config,
            channel="INSTORE",
            filter_pass_no=1,
        )

        # === ASSERT: campaigns exactly at the min_avg_weekly_spend boundary are retained
        assert_df_equality(
            filtered.select("campaign_id").orderBy("campaign_id"),
            historical_campaigns.select("campaign_id").orderBy("campaign_id"),
            ignore_nullable=True,
        )


class TestGetChannelData:
    """Test get_channel_data with edge cases."""

    def test_get_channel_data_empty_channel_after_filter(
        self, spark_session, config,
    ):
        """Test when no campaigns exist for the channel."""
        # === ARRANGE: Create campaigns only for OFFSITE, request INSTORE channel (mismatch)
        historical_campaigns = spark_session.createDataFrame(
            [Row(
                campaign_id="c1", campaign_source="src", period="DURING",
                campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                marketing_type="OFFSITE",  # Only OFFSITE channel, no INSTORE
                super_category_name="CRISPS", sub_category_name_list="CRISPS",
                unique_brand_name_list="WALKERS", test=400000.0, control=375000.0,
                uplift=0.05, iroas=8.5, media_cost=50000.0
            )],
            _BASE_SCHEMAS["historical_campaigns"]
        )

        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )

        benchmark_spend_data = spark_session.createDataFrame(
            [Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", avg_weekly_spend=50000.0)],
            _BASE_SCHEMAS["benchmark_spend_data"]
        )

        # === ACT: Request non-existent channel
        channel_data, _ = get_channel_data(
            "INSTORE",
            campaign_metadata,
            historical_campaigns,
            benchmark_spend_data,
            config,
            filter_pass_no=1
        )

        # === ASSERT: Verify returns empty result for missing channel
        assert channel_data.count() == 0, "Should return empty DataFrame for missing channel"


class TestAggregatePriorAndAudit:
    """Tests for aggregate prior generation and audit dataframe assembly."""

    def test_get_aggregate_prior_with_negative_min_uplift_uses_shift(
        self, spark_session, config, monkeypatch
    ):
        """Ensure shift constant is applied when minimum uplift is negative."""
        # === ARRANGE: Build minimal inputs and mock internals to isolate function flow
        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS", sub_category_name="CRISPS", unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"],
        )

        sample_channel_df = spark_session.createDataFrame(
            [Row(campaign_id="c1", uplift=-0.2)],
            T.StructType([
                T.StructField("campaign_id", T.StringType()),
                T.StructField("uplift", T.DoubleType()),
            ]),
        )

        def mock_collect_channel_data(*args, **kwargs):
            return ({"INSTORE": sample_channel_df}, {"INSTORE": 0.1}, ["OFFSITE"], -0.2)

        def mock_sample_channel_distributions(
            _channels, _channel_data_collection, _rev_similarity_thresholds, _campaign_channel, shift_constant, _cfg
        ):
            assert shift_constant == 0.2, "Shift should be abs(min_uplift) for negative minima"
            return (
                {"INSTORE": sample_channel_df},
                {"INSTORE": spark_session.createDataFrame([
                    Row(
                        mean_log_uplift=0.1,
                        var_log_uplift=0.01,
                        count_campaigns=1,
                        distribution_type="log_normal",
                        shift_parameter=shift_constant,
                        rev_similarity_percentile=0.1,
                        bypass_flag=False,
                    )
                ])},
                {"INSTORE": np.array([1.0, 2.0, 3.0])},
                {"INSTORE": np.array([0.1, 0.2, 0.3])},
            )

        monkeypatch.setattr(
            "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage_helper.collect_channel_data",
            mock_collect_channel_data,
        )
        monkeypatch.setattr(
            "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage_helper.sample_channel_distributions",
            mock_sample_channel_distributions,
        )

        campaign_channel = {"INSTORE": {"channel_spend": 50000.0}, "OFFSITE": {"channel_spend": 45000.0}}

        # === ACT: Build aggregate prior from mocked channel sampling pipeline
        prior_dist, channel_samples, failed_channels, channel_data_collection = get_aggregate_prior(
            channels=["INSTORE", "OFFSITE"],
            campaign_metadata=campaign_metadata,
            campaign_channel=campaign_channel,
            historical_campaigns=sample_channel_df,
            benchmark_spend_data=sample_channel_df,
            config=config,
        )

        # === ASSERT: Verify aggregate distribution and channel bookkeeping are correct
        assert np.array_equal(prior_dist, np.array([1.0, 2.0, 3.0]))
        assert failed_channels == ["OFFSITE"]
        assert "INSTORE" in channel_samples["incrementality_samples"]
        assert "INSTORE" in channel_data_collection

    def test_build_incremental_shrinkage_audit_df_no_priors(
        self, spark_session
    ):
        """Return a single failure row when no priors are available."""
        # === ARRANGE: Create campaign facts and calibration audit with failed channels only
        campaign_facts = spark_session.createDataFrame(
            [Row(unique_brand_name="WALKERS", super_category_name="CRISPS", sub_category_name="CRISPS")]
        )
        calibration_audit = {"failed_channels": ["INSTORE", "OFFSITE"]}

        # === ACT: Build audit dataframe without priors
        audit_df = build_incremental_shrinkage_audit_df(
            campaign_facts=campaign_facts,
            channel_priors={},
            calibration_audit=calibration_audit,
            run_date="2026-07-01",
            correlation_id="corr-1",
        )

        # === ASSERT: Verify single fallback row with failure metadata
        rows = audit_df.collect()
        assert len(rows) == 1
        assert rows[0]["channel_prior_failures"] == "INSTORE,OFFSITE"
        assert rows[0]["run_date"].strftime("%Y-%m-%d") == "2026-07-01"

    def test_build_incremental_shrinkage_audit_df_with_priors(
        self, spark_session
    ):
        """Expand priors by channel and campaign keys with calibration audit metrics."""
        # === ARRANGE: Create campaign keys and channel prior with expected audit fields
        campaign_facts = spark_session.createDataFrame(
            [Row(unique_brand_name="WALKERS", super_category_name="CRISPS", sub_category_name="CRISPS")]
        )
        channel_priors = {
            "INSTORE": spark_session.createDataFrame([
                Row(
                    mean_log_uplift=0.12,
                    var_log_uplift=0.02,
                    count_campaigns=15,
                    distribution_type="log_normal",
                    shift_parameter=0.2,
                    rev_similarity_percentile=0.1,
                    bypass_flag=False,
                )
            ])
        }
        calibration_audit = {
            "scaling_factor": 0.7,
            "sample_median": 1.5,
            "sample_mode": 1.4,
            "z_score": 0.3,
            "failed_channels": ["OFFSITE"],
        }

        # === ACT: Build audit dataframe from priors and calibration metrics
        audit_df = build_incremental_shrinkage_audit_df(
            campaign_facts=campaign_facts,
            channel_priors=channel_priors,
            calibration_audit=calibration_audit,
            run_date="2026-07-01",
            correlation_id="corr-2",
        )

        # === ASSERT: Verify channel-level audit metrics are present and correctly populated
        row = audit_df.collect()[0]
        assert row["marketing_type"] == "INSTORE"
        assert abs(row["scaling_factor"] - 0.7) < 1e-9
        assert abs(row["sample_mode"] - 1.4) < 1e-9
        assert row["channel_prior_failures"] == "OFFSITE"

    def test_get_channel_data_instore_split_category_special_handling(
        self, spark_session, config,
    ):
        """Test special handling for instore channel in split categories."""
        # === ARRANGE: Set up config and campaigns for instore channel with split category handling
        local_config = replace(
            config,
            instore_split_cats=["CRISPS & SNACKS"],
            instore_channel="INSTORE",
        )

        historical_campaigns = spark_session.createDataFrame([
            Row(
                campaign_id=f"c{i}", campaign_source="INSTORE", period="DURING",
                campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                marketing_type="INSTORE", super_category_name="CRISPS & SNACKS",
                sub_category_name_list="CRISPS", unique_brand_name_list="WALKERS",
                test=400000.0 + i * 10000, control=375000.0 + i * 9000,
                uplift=0.055, iroas=8.5, media_cost=50000.0 + i * 5000
            )
            for i in range(10)
        ], _BASE_SCHEMAS["historical_campaigns"])

        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS & SNACKS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )

        benchmark_spend_data = spark_session.createDataFrame(
            [Row(year=2023, super_category_name="CRISPS & SNACKS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", avg_weekly_spend=50000.0)],
            _BASE_SCHEMAS["benchmark_spend_data"]
        )

        # === ACT: Call get_channel_data with split category channel and pass 1
        channel_data, _ = get_channel_data(
            "INSTORE",
            campaign_metadata,
            historical_campaigns,
            benchmark_spend_data,
            local_config,
            filter_pass_no=1
        )

        # === ASSERT: Verify special filtering applied and data found
        assert channel_data.count() > 0, "Should find campaigns after split category filter"


class TestSampleChannelDistributions:
    """Test sample_channel_distributions with edge cases."""

    def test_sample_channel_distributions_multiple_channels(
        self, spark_session, config
    ):
        """Test sampling across multiple channels."""
        # === ARRANGE: Set up channel data for multiple channels with revenue thresholds
        mock_data = BaselineModellingShrinkageMockData.get_base_scenario(spark_session)
        channels = ["INSTORE", "OFFSITE"]
        channel_data_collection = {}
        for ch in channels:
            channel_data_collection[ch] = mock_data["historical_campaigns"].filter(
                F.col("marketing_type") == ch
            )

        campaign_channel = {
            "INSTORE": {"channel_spend": 50000.0},
            "OFFSITE": {"channel_spend": 45000.0},
        }
        rev_similarity_thresholds = {
            "INSTORE": 0.1,
            "OFFSITE": 0.1,
        }

        # === ACT: Sample distributions for all channels
        channel_data_samples, channel_priors, _, _ = (
            sample_channel_distributions(
                channels,
                channel_data_collection,
                rev_similarity_thresholds,
                campaign_channel,
                shift_constant=0.0,
                config=config,
            )
        )

        # === ASSERT: Verify all channels processed with correct structure and flags
        assert len(channel_data_samples) == len(channels), "Should return data for all channels"
        assert len(channel_priors) == len(channels), "Should return priors for all channels"
        for ch in channels:
            prior_rows = channel_priors[ch].filter(
                ~F.col("bypass_flag")
            ).count()
            assert prior_rows > 0, f"Channel {ch} should have bypass_flag=False"


class TestCollectChannelData:
    """Test collect_channel_data with comprehensive edge cases."""

    def test_collect_channel_data_all_channels_succeed_pass_1(
        self, spark_session, config
    ):
        """Happy path: sufficient data on first pass for all channels."""
        # === ARRANGE: Set up base scenario with sufficient campaigns for all channels
        mock_data = BaselineModellingShrinkageMockData.get_base_scenario(spark_session)

        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS & SNACKS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )

        # === ACT: Collect channel data for multiple channels
        channel_data_collection, _, failed_channels, min_uplift = (
            collect_channel_data(
                channels=["INSTORE", "OFFSITE"],
                campaign_metadata=campaign_metadata,
                historical_campaigns=mock_data["historical_campaigns"],
                benchmark_spend_data=mock_data["benchmark_spend_data"],
                config=config,
            )
        )

        # === ASSERT: Both channels should succeed on pass 1.
        # get_base_scenario provides 60 INSTORE campaigns (>= min_n pass_1=50)
        # and 50 OFFSITE campaigns (>= min_n pass_1=35), so neither should fail.
        assert len(channel_data_collection) == 2, "Both INSTORE and OFFSITE should succeed on pass 1"
        assert len(failed_channels) == 0, "No channels should fail with sufficient data"
        assert min_uplift != float("inf"), "Should compute minimum uplift across channels"

    def test_collect_channel_data_all_channels_fail_insufficient_data(
        self, spark_session, config,
    ):
        """Negative case: all channels have insufficient data."""
        # === ARRANGE: Create minimal campaigns (only 1 per channel, far below minimum threshold)
        historical_campaigns = spark_session.createDataFrame([
            Row(
                campaign_id="c1", campaign_source="INSTORE", period="DURING",
                campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                marketing_type="INSTORE", super_category_name="CRISPS",
                sub_category_name_list="CRISPS", unique_brand_name_list="WALKERS",
                test=400000.0, control=375000.0, uplift=0.05, iroas=8.5, media_cost=50000.0
            ),
            Row(
                campaign_id="c2", campaign_source="OFFSITE", period="DURING",
                campaign_start_date=date(2023, 2, 1), campaign_end_date=date(2023, 2, 28),
                marketing_type="OFFSITE", super_category_name="CRISPS",
                sub_category_name_list="CRISPS", unique_brand_name_list="BRAND",
                test=420000.0, control=395000.0, uplift=0.06, iroas=9.0, media_cost=45000.0
            ),
        ], _BASE_SCHEMAS["historical_campaigns"])

        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )

        benchmark_spend_data = spark_session.createDataFrame(
            [Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", avg_weekly_spend=50000.0)],
            _BASE_SCHEMAS["benchmark_spend_data"]
        )

        # === ACT: Collect channel data with insufficient campaigns
        channel_data_collection, _, failed_channels, min_uplift = (
            collect_channel_data(
                channels=["INSTORE", "OFFSITE"],
                campaign_metadata=campaign_metadata,
                historical_campaigns=historical_campaigns,
                benchmark_spend_data=benchmark_spend_data,
                config=config,
            )
        )

        # === ASSERT: Verify channels marked as failed and min_uplift reflects failure
        assert len(failed_channels) > 0, "Should have failed channels with insufficient data"
        if len(channel_data_collection) == 0:
            assert min_uplift == float("inf"), "Min uplift should be inf when all channels fail"

    def test_collect_channel_data_max_passes_exceeded(
        self, spark_session, config,
    ):
        """Test behavior when max passes reached without sufficient data."""
        # === ARRANGE: Create very sparse data (3 campaigns) with low max_passes config
        historical_campaigns = spark_session.createDataFrame([
            Row(
                campaign_id=f"c{i}", campaign_source="INSTORE", period="DURING",
                campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                marketing_type="INSTORE", super_category_name="CRISPS",
                sub_category_name_list="CRISPS", unique_brand_name_list="WALKERS",
                test=400000.0 + i * 10000, control=375000.0 + i * 9000,
                uplift=0.05, iroas=8.5, media_cost=50000.0 + i * 1000
            )
            for i in range(3)  # Only 3 campaigns
        ], _BASE_SCHEMAS["historical_campaigns"])

        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )

        benchmark_spend_data = spark_session.createDataFrame(
            [Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", avg_weekly_spend=50000.0)],
            _BASE_SCHEMAS["benchmark_spend_data"]
        )

        local_config = replace(config, max_passes=2)  # Limit passes to trigger exhaustion

        # === ACT: Collect channel data with loop termination by max_passes
        _, rev_thresholds, failed_channels, _ = (
            collect_channel_data(
                channels=["INSTORE"],
                campaign_metadata=campaign_metadata,
                historical_campaigns=historical_campaigns,
                benchmark_spend_data=benchmark_spend_data,
                config=local_config,
            )
        )

        # === ASSERT: Verify loop terminated and INSTORE is marked as failed
        # 3 campaigns is far below min_n thresholds (50 pass-1, 20 pass-4), so
        # INSTORE must be in failed_channels regardless of how many passes ran.
        assert "INSTORE" in failed_channels, "INSTORE should be failed with only 3 campaigns"
        assert len(failed_channels) == 1, "Only INSTORE was requested, so exactly 1 failure"
        assert isinstance(rev_thresholds, dict), "Should return dict of rev similarity thresholds"

    def test_collect_channel_data_min_uplift_calculation(
        self, spark_session, config,
    ):
        """Test correct computation of minimum uplift across channels."""
        # === ARRANGE: Create data with known minimum uplift values per channel
        # INSTORE: min uplift = 0.025, OFFSITE: min uplift = 0.020 (global min)
        historical_campaigns = spark_session.createDataFrame([
            Row(
                campaign_id="c1", campaign_source="INSTORE", period="DURING",
                campaign_start_date=date(2023, 1, 1), campaign_end_date=date(2023, 1, 31),
                marketing_type="INSTORE", super_category_name="CRISPS",
                sub_category_name_list="CRISPS", unique_brand_name_list="WALKERS",
                test=410000.0, control=400000.0, uplift=0.025, iroas=8.5, media_cost=50000.0
            ),
            Row(
                campaign_id="c2", campaign_source="INSTORE", period="DURING",
                campaign_start_date=date(2023, 2, 1), campaign_end_date=date(2023, 2, 28),
                marketing_type="INSTORE", super_category_name="CRISPS",
                sub_category_name_list="CRISPS", unique_brand_name_list="WALKERS",
                test=415000.0, control=400000.0, uplift=0.037, iroas=8.5, media_cost=52000.0
            ),
            Row(
                campaign_id="c3", campaign_source="OFFSITE", period="DURING",
                campaign_start_date=date(2023, 3, 1), campaign_end_date=date(2023, 3, 31),
                marketing_type="OFFSITE", super_category_name="CRISPS",
                sub_category_name_list="CRISPS", unique_brand_name_list="BRAND",
                test=408000.0, control=400000.0, uplift=0.020, iroas=9.0, media_cost=45000.0
            ),
            Row(
                campaign_id="c4", campaign_source="OFFSITE", period="DURING",
                campaign_start_date=date(2023, 4, 1), campaign_end_date=date(2023, 4, 30),
                marketing_type="OFFSITE", super_category_name="CRISPS",
                sub_category_name_list="CRISPS", unique_brand_name_list="BRAND",
                test=420000.0, control=400000.0, uplift=0.05, iroas=9.0, media_cost=47000.0
            ),
        ], _BASE_SCHEMAS["historical_campaigns"])

        campaign_metadata = spark_session.createDataFrame(
            [Row(super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", campaign_year=2023)],
            _BASE_SCHEMAS["campaign_metadata"]
        )

        benchmark_spend_data = spark_session.createDataFrame(
            [Row(year=2023, super_category_name="CRISPS", sub_category_name="CRISPS",
                 unique_brand_name="WALKERS", avg_weekly_spend=50000.0)],
            _BASE_SCHEMAS["benchmark_spend_data"]
        )

        # === ACT: Collect channel data and compute minimum uplift
        _, _, _, min_uplift = collect_channel_data(
            channels=["INSTORE", "OFFSITE"],
            campaign_metadata=campaign_metadata,
            historical_campaigns=historical_campaigns,
            benchmark_spend_data=benchmark_spend_data,
            config=config,
        )

        # === ASSERT: Verify min_uplift correctly reflects minimum across all channels
        if min_uplift != float("inf"):
            assert min_uplift <= 0.037, "Min uplift should be <= largest value in successful channels"
