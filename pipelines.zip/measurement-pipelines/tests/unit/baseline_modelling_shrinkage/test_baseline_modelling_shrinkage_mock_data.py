"""
Mock data generators for baseline_modelling_shrinkage tests.

Provides flexible mock DataFrames for different test scenarios:
- Base scenarios: realistic data, edge cases
- Specific scenarios: negative uplift, extreme outliers, multi-channel, etc.
"""

from datetime import date, timedelta
from typing import Dict
from pyspark.sql import DataFrame, Row, SparkSession, types as T


class BaselineModellingShrinkageMockData:
    """Factory for generating mock DataFrames for shrinkage pipeline tests."""

    @staticmethod
    def get_base_schemas() -> Dict[str, T.StructType]:
        """Return all required schemas."""
        return {
            "campaign_facts": T.StructType([
                T.StructField("campaign_id", T.StringType(), True),
                T.StructField("marketing_type", T.StringType(), True),
                T.StructField("min_campaign_start_dt", T.DateType(), True),
                T.StructField("max_campaign_end_dt", T.DateType(), True),
                T.StructField("max_post_campaign_dt", T.DateType(), True),
            ]),
            "baseline_modelling_output": T.StructType([
                T.StructField("week_start_dt", T.DateType(), True),
                T.StructField("super_category_name", T.StringType(), True),
                T.StructField("unique_brand_name", T.StringType(), True),
                T.StructField("metric_name", T.StringType(), True),
                T.StructField("metric_value", T.DoubleType(), True),
            ]),
            "historical_campaigns": T.StructType([
                T.StructField("campaign_id", T.StringType(), True),
                T.StructField("campaign_source", T.StringType(), True),
                T.StructField("period", T.StringType(), True),
                T.StructField("campaign_start_date", T.DateType(), True),
                T.StructField("campaign_end_date", T.DateType(), True),
                T.StructField("marketing_type", T.StringType(), True),
                T.StructField("super_category_name", T.StringType(), True),
                T.StructField("sub_category_name_list", T.StringType(), True),
                T.StructField("unique_brand_name_list", T.StringType(), True),
                T.StructField("test", T.DoubleType(), True),
                T.StructField("control", T.DoubleType(), True),
                T.StructField("uplift", T.DoubleType(), True),
                T.StructField("iroas", T.DoubleType(), True),
                T.StructField("media_cost", T.DoubleType(), True),
            ]),
            "benchmark_spend_data": T.StructType([
                T.StructField("year", T.IntegerType(), True),
                T.StructField("super_category_name", T.StringType(), True),
                T.StructField("sub_category_name", T.StringType(), True),
                T.StructField("unique_brand_name", T.StringType(), True),
                T.StructField("avg_weekly_spend", T.DoubleType(), True),
            ]),
            "campaign_metadata": T.StructType([
                T.StructField("super_category_name", T.StringType(), True),
                T.StructField("sub_category_name", T.StringType(), True),
                T.StructField("unique_brand_name", T.StringType(), True),
                T.StructField("campaign_year", T.IntegerType(), True),
            ]),
        }

    @staticmethod
    def get_base_scenario(spark: SparkSession) -> Dict[str, DataFrame]:
        """
        Get realistic baseline scenario with normal distributions and multiple channels.
        Suitable for integration tests and general functionality checks.
        """
        schemas = BaselineModellingShrinkageMockData.get_base_schemas()

        # Current campaign
        campaign_facts = [
            Row(
                campaign_id="EVAL_CAMP_2026_001",
                marketing_type="INSTORE",
                min_campaign_start_dt=date(2026, 1, 1),
                max_campaign_end_dt=date(2026, 3, 31),
                max_post_campaign_dt=date(2026, 6, 30),
            ),
        ]

        # Historical campaigns - realistic uplift distribution centered around 5-6%
        historical_campaigns = [
            Row(
                campaign_id=f"hist_{i}",
                campaign_source="INSTORE",
                period="DURING",
                campaign_start_date=date(2023, 1, 1) + timedelta(weeks=i * 4),
                campaign_end_date=date(2023, 1, 28) + timedelta(weeks=i * 4),
                marketing_type="INSTORE",
                super_category_name="CRISPS & SNACKS",
                sub_category_name_list="CRISPS",
                unique_brand_name_list="WALKERS",
                test=400000.0 + i * 10000,
                control=375000.0 + i * 9000,
                uplift=5.5 + (i % 3) * 0.5,  # 5.5%, 6.0%, 6.5% range
                iroas=8.5 + (i % 2) * 1.0,
                media_cost=50000.0 + i * 5000,
            )
            for i in range(60)
        ]

        # Add OFFSITE channel campaigns
        historical_campaigns.extend([
            Row(
                campaign_id=f"hist_offsite_{i}",
                campaign_source="OFFSITE",
                period="DURING",
                campaign_start_date=date(2023, 1, 15) + timedelta(weeks=i * 4),
                campaign_end_date=date(2023, 2, 11) + timedelta(weeks=i * 4),
                marketing_type="OFFSITE",
                super_category_name="CRISPS & SNACKS",
                sub_category_name_list="POPCORN",
                unique_brand_name_list="PROPERCORN",
                test=420000.0 + i * 12000,
                control=395000.0 + i * 11000,
                uplift=6.0 + (i % 3) * 0.4,  # 6.0% to 6.8% range
                iroas=9.0 + (i % 2) * 1.2,
                media_cost=45000.0 + i * 6000,
            )
            for i in range(50)
        ])

        # Baseline modelling output - incrementality by week
        baseline_output = []
        week_start = date(2026, 1, 2)
        for week_offset in range(12):  # 12 weeks
            baseline_output.append(Row(
                week_start_dt=week_start + timedelta(weeks=week_offset),
                super_category_name="CRISPS & SNACKS",
                unique_brand_name="WALKERS",
                metric_name="TOTAL_INCREMENTAL_AMT",
                metric_value=5000.0 + (week_offset * 200),
            ))

        # Benchmark spend data
        benchmark_spend = []
        for year in [2023, 2024, 2026]:
            benchmark_spend.extend([
                Row(year=year, super_category_name="CRISPS & SNACKS",
                    sub_category_name="CRISPS", unique_brand_name="WALKERS",
                    avg_weekly_spend=50000.0),
                Row(year=year, super_category_name="CRISPS & SNACKS",
                    sub_category_name="POPCORN", unique_brand_name="PROPERCORN",
                    avg_weekly_spend=45000.0),
            ])

        # Campaign metadata for current evaluation
        campaign_metadata = [
            Row(
                super_category_name="CRISPS & SNACKS",
                sub_category_name="CRISPS",
                unique_brand_name="WALKERS",
                campaign_year=2026,
            ),
        ]

        return {
            "campaign_facts": spark.createDataFrame(campaign_facts, schema=schemas["campaign_facts"]),
            "baseline_modelling_output": spark.createDataFrame(baseline_output, schema=schemas["baseline_modelling_output"]),
            "historical_campaigns": spark.createDataFrame(historical_campaigns, schema=schemas["historical_campaigns"]),
            "benchmark_spend_data": spark.createDataFrame(benchmark_spend, schema=schemas["benchmark_spend_data"]),
            "campaign_metadata": spark.createDataFrame(campaign_metadata, schema=schemas["campaign_metadata"]),
        }

    @staticmethod
    def get_negative_uplift_scenario(spark: SparkSession) -> Dict[str, DataFrame]:
        """
        Scenario with negative uplift values to test shift parameter safety.
        Includes a mix of negative, near-zero, and positive uplifts.
        """
        schemas = BaselineModellingShrinkageMockData.get_base_schemas()

        campaign_facts = [
            Row(
                campaign_id="EVAL_CAMP_NEG_001",
                marketing_type="INSTORE",
                min_campaign_start_dt=date(2026, 1, 1),
                max_campaign_end_dt=date(2026, 1, 31),
                max_post_campaign_dt=date(2026, 3, 31)
            ),
        ]

        # Historical campaigns with negative uplifts
        historical_campaigns = [
            Row(
                campaign_id=f"neg_hist_{i}",
                campaign_source="INSTORE",
                period="DURING",
                campaign_start_date=date(2023, 1, 1) + timedelta(weeks=i),
                campaign_end_date=date(2023, 1, 28) + timedelta(weeks=i),
                marketing_type="INSTORE",
                super_category_name="CRISPS & SNACKS",
                sub_category_name_list="CRISPS",
                unique_brand_name_list="WALKERS",
                test=400000.0 - i * 5000,
                control=375000.0 - i * 6000,
                uplift=(-0.5 + (i * 0.1)),  # Range: -0.5% to +3.5%
                iroas=8.0 if i % 2 == 0 else -2.0,  # Some negative IROAS
                media_cost=50000.0 + i * 1000,
            )
            for i in range(50)
        ]

        baseline_output = [
            Row(
                week_start_dt=date(2026, 1, 2),
                super_category_name="CRISPS & SNACKS",
                unique_brand_name="WALKERS",
                metric_name="TOTAL_INCREMENTAL_AMT",
                metric_value=2000.0,
            )
        ]

        benchmark_spend = [
            Row(year=2026, super_category_name="CRISPS & SNACKS",
                sub_category_name="CRISPS", unique_brand_name="WALKERS",
                avg_weekly_spend=50000.0),
        ]

        campaign_metadata = [
            Row(
                super_category_name="CRISPS & SNACKS",
                sub_category_name="CRISPS",
                unique_brand_name="WALKERS",
                campaign_year=2026,
            ),
        ]

        return {
            "campaign_facts": spark.createDataFrame(campaign_facts, schema=schemas["campaign_facts"]),
            "baseline_modelling_output": spark.createDataFrame(baseline_output, schema=schemas["baseline_modelling_output"]),
            "historical_campaigns": spark.createDataFrame(historical_campaigns, schema=schemas["historical_campaigns"]),
            "benchmark_spend_data": spark.createDataFrame(benchmark_spend, schema=schemas["benchmark_spend_data"]),
            "campaign_metadata": spark.createDataFrame(campaign_metadata, schema=schemas["campaign_metadata"]),
        }

    @staticmethod
    def get_extreme_outlier_scenario(spark: SparkSession) -> Dict[str, DataFrame]:
        """
        Scenario with extreme outliers and edge cases.
        Tests calibration behavior with outlier UCM values.
        """
        schemas = BaselineModellingShrinkageMockData.get_base_schemas()

        campaign_facts = [
            Row(
                campaign_id="EVAL_CAMP_OUTLIER_001",
                marketing_type="INSTORE",
                min_campaign_start_dt=date(2026, 1, 1),
                max_campaign_end_dt=date(2026, 2, 28),
                max_post_campaign_dt=date(2026, 4, 28),
            ),
        ]

        # Historical campaigns with mostly normal distribution
        historical_campaigns = [
            Row(
                campaign_id=f"out_hist_{i}",
                campaign_source="INSTORE",
                period="DURING",
                campaign_start_date=date(2023, 1, 1) + timedelta(weeks=i),
                campaign_end_date=date(2023, 1, 28) + timedelta(weeks=i),
                marketing_type="INSTORE",
                super_category_name="CRISPS & SNACKS",
                sub_category_name_list="CRISPS",
                unique_brand_name_list="WALKERS",
                test=400000.0 + (i - 30) * 5000,
                control=375000.0 + (i - 30) * 4500,
                uplift=5.5 + ((i - 30) * 0.1),  # Range: 2.5% to 8.5%
                iroas=8.5 + ((i - 30) * 0.2),
                media_cost=50000.0 + i * 500,
            )
            for i in range(70)
        ]

        # Add extreme outliers (high uplift)
        historical_campaigns.extend([
            Row(
                campaign_id=f"out_extreme_{i}",
                campaign_source="INSTORE",
                period="DURING",
                campaign_start_date=date(2024, 1, 1) + timedelta(weeks=i),
                campaign_end_date=date(2024, 1, 28) + timedelta(weeks=i),
                marketing_type="INSTORE",
                super_category_name="CRISPS & SNACKS",
                sub_category_name_list="CRISPS",
                unique_brand_name_list="WALKERS",
                test=500000.0 + i * 50000,  # Very high test
                control=100000.0 + i * 10000,
                uplift=50.0 + (i * 5),  # Extreme uplift (50%+)
                iroas=100.0 + i * 10,  # Extreme IROAS
                media_cost=200000.0 + i * 50000,
            )
            for i in range(5)
        ])

        baseline_output = [
            Row(
                week_start_dt=date(2026, 1, 2),
                super_category_name="CRISPS & SNACKS",
                unique_brand_name="WALKERS",
                metric_name="TOTAL_INCREMENTAL_AMT",
                metric_value=100000.0,  # Extreme incrementality
            )
        ]

        benchmark_spend = [
            Row(year=2026, super_category_name="CRISPS & SNACKS",
                sub_category_name="CRISPS", unique_brand_name="WALKERS",
                avg_weekly_spend=50000.0),
        ]

        campaign_metadata = [
            Row(
                super_category_name="CRISPS & SNACKS",
                sub_category_name="CRISPS",
                unique_brand_name="WALKERS",
                campaign_year=2026,
            ),
        ]

        return {
            "campaign_facts": spark.createDataFrame(campaign_facts, schema=schemas["campaign_facts"]),
            "baseline_modelling_output": spark.createDataFrame(baseline_output, schema=schemas["baseline_modelling_output"]),
            "historical_campaigns": spark.createDataFrame(historical_campaigns, schema=schemas["historical_campaigns"]),
            "benchmark_spend_data": spark.createDataFrame(benchmark_spend, schema=schemas["benchmark_spend_data"]),
            "campaign_metadata": spark.createDataFrame(campaign_metadata, schema=schemas["campaign_metadata"]),
        }

    @staticmethod
    def get_multimodal_scenario(spark: SparkSession) -> Dict[str, DataFrame]:
        """
        Scenario with multimodal uplift distribution.
        Tests that mode selection correctly identifies the primary cluster.
        """
        schemas = BaselineModellingShrinkageMockData.get_base_schemas()

        campaign_facts = [
            Row(
                campaign_id="EVAL_CAMP_MULTIMODAL_001",
                marketing_type="INSTORE",
                min_campaign_start_dt=date(2026, 1, 1),
                max_campaign_end_dt=date(2026, 1, 31),
                max_post_campaign_dt=date(2026, 3, 31)
            ),
        ]

        historical_campaigns = []

        # Cluster 1: Low uplift (3-4%)
        historical_campaigns.extend([
            Row(
                campaign_id=f"multi_low_{i}",
                campaign_source="INSTORE",
                period="DURING",
                campaign_start_date=date(2023, 1, 1) + timedelta(weeks=i),
                campaign_end_date=date(2023, 1, 28) + timedelta(weeks=i),
                marketing_type="INSTORE",
                super_category_name="CRISPS & SNACKS",
                sub_category_name_list="CRISPS",
                unique_brand_name_list="WALKERS",
                test=380000.0 + i * 2000,
                control=370000.0 + i * 1800,
                uplift=3.0 + (i % 3) * 0.3,  # 3.0-3.9% cluster
                iroas=7.0 + (i % 2) * 0.5,
                media_cost=40000.0 + i * 500,
            )
            for i in range(50)
        ])

        # Cluster 2: Higher uplift (7-8%) - smaller cluster
        historical_campaigns.extend([
            Row(
                campaign_id=f"multi_high_{i}",
                campaign_source="INSTORE",
                period="DURING",
                campaign_start_date=date(2023, 6, 1) + timedelta(weeks=i),
                campaign_end_date=date(2023, 6, 28) + timedelta(weeks=i),
                marketing_type="INSTORE",
                super_category_name="CRISPS & SNACKS",
                sub_category_name_list="CRISPS",
                unique_brand_name_list="WALKERS",
                test=430000.0 + i * 3000,
                control=400000.0 + i * 2800,
                uplift=7.5 + (i % 3) * 0.3,  # 7.5-8.4% cluster
                iroas=11.0 + (i % 2) * 1.0,
                media_cost=60000.0 + i * 1000,
            )
            for i in range(15)
        ])

        baseline_output = [
            Row(
                week_start_dt=date(2026, 1, 2),
                super_category_name="CRISPS & SNACKS",
                unique_brand_name="WALKERS",
                metric_name="TOTAL_INCREMENTAL_AMT",
                metric_value=4000.0,
            )
        ]

        benchmark_spend = [
            Row(year=2026, super_category_name="CRISPS & SNACKS",
                sub_category_name="CRISPS", unique_brand_name="WALKERS",
                avg_weekly_spend=50000.0),
        ]

        campaign_metadata = [
            Row(
                super_category_name="CRISPS & SNACKS",
                sub_category_name="CRISPS",
                unique_brand_name="WALKERS",
                campaign_year=2026,
            ),
        ]

        return {
            "campaign_facts": spark.createDataFrame(campaign_facts, schema=schemas["campaign_facts"]),
            "baseline_modelling_output": spark.createDataFrame(baseline_output, schema=schemas["baseline_modelling_output"]),
            "historical_campaigns": spark.createDataFrame(historical_campaigns, schema=schemas["historical_campaigns"]),
            "benchmark_spend_data": spark.createDataFrame(benchmark_spend, schema=schemas["benchmark_spend_data"]),
            "campaign_metadata": spark.createDataFrame(campaign_metadata, schema=schemas["campaign_metadata"]),
        }

    @staticmethod
    def get_negative_incrementality_scenario(spark: SparkSession) -> Dict[str, DataFrame]:
        """
        Scenario with negative total incrementality from baseline model.
        Tests that negative incrementality is handled (zeroed) before calibration.
        """
        schemas = BaselineModellingShrinkageMockData.get_base_schemas()

        campaign_facts = [
            Row(
                campaign_id="EVAL_CAMP_NEG_INCR_001",
                marketing_type="INSTORE",
                min_campaign_start_dt=date(2026, 1, 1),
                max_campaign_end_dt=date(2026, 1, 31),
                max_post_campaign_dt=date(2026, 3, 31)
            ),
        ]

        # Historical campaigns with reasonable uplifts
        historical_campaigns = [
            Row(
                campaign_id=f"neg_incr_hist_{i}",
                campaign_source="INSTORE",
                period="DURING",
                campaign_start_date=date(2023, 1, 1) + timedelta(weeks=i),
                campaign_end_date=date(2023, 1, 28) + timedelta(weeks=i),
                marketing_type="INSTORE",
                super_category_name="CRISPS & SNACKS",
                sub_category_name_list="CRISPS",
                unique_brand_name_list="WALKERS",
                test=400000.0 + i * 5000,
                control=375000.0 + i * 4500,
                uplift=5.5 + (i % 3) * 0.5,
                iroas=8.5 + (i % 2) * 1.0,
                media_cost=50000.0 + i * 1000,
            )
            for i in range(60)
        ]

        # Baseline output with NEGATIVE total incrementality
        baseline_output = [
            Row(
                week_start_dt=date(2026, 1, 2),
                super_category_name="CRISPS & SNACKS",
                unique_brand_name="WALKERS",
                metric_name="TOTAL_INCREMENTAL_AMT",
                metric_value=-1500.0,  # Negative!
            ),
            Row(
                week_start_dt=date(2026, 1, 9),
                super_category_name="CRISPS & SNACKS",
                unique_brand_name="WALKERS",
                metric_name="TOTAL_INCREMENTAL_AMT",
                metric_value=-800.0,  # Negative!
            ),
        ]

        benchmark_spend = [
            Row(year=2026, super_category_name="CRISPS & SNACKS",
                sub_category_name="CRISPS", unique_brand_name="WALKERS",
                avg_weekly_spend=50000.0),
        ]

        campaign_metadata = [
            Row(
                super_category_name="CRISPS & SNACKS",
                sub_category_name="CRISPS",
                unique_brand_name="WALKERS",
                campaign_year=2026,
            ),
        ]

        return {
            "campaign_facts": spark.createDataFrame(campaign_facts, schema=schemas["campaign_facts"]),
            "baseline_modelling_output": spark.createDataFrame(baseline_output, schema=schemas["baseline_modelling_output"]),
            "historical_campaigns": spark.createDataFrame(historical_campaigns, schema=schemas["historical_campaigns"]),
            "benchmark_spend_data": spark.createDataFrame(benchmark_spend, schema=schemas["benchmark_spend_data"]),
            "campaign_metadata": spark.createDataFrame(campaign_metadata, schema=schemas["campaign_metadata"]),
        }
