import pytest
from dataclasses import replace
from datetime import date
from unittest import mock

from pyspark.sql import SparkSession, functions as F, types as T
from chispa.dataframe_comparer import assert_df_equality, assert_approx_df_equality

import os

from spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage import (
    prepare_incremental_shrinkage,
    run_incremental_shrinkage,
    entrypoint,
)
from spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage_helper import (
    normalise_marketing_type,
)
from spark_pipeline.common.variables import BaselineModellingShrinkageConfig, CampaignDurations
from spark_pipeline.schemas.baseline_modelling_shrinkage import BaselineModellingShrinkage


@pytest.fixture
def parquet_paths(tmpdir):
    """Parquet file path stubs for prepare_incremental_shrinkage tests, all rooted in tmpdir."""
    from types import SimpleNamespace
    return SimpleNamespace(
        baseline_output_path=os.path.join(str(tmpdir), "baseline_output.parquet"),
        avg_weekly_spend_data=os.path.join(str(tmpdir), "avg_weekly_spend_data.parquet"),
        measurement_legacy_campaign_performance=os.path.join(str(tmpdir), "measurement_legacy_campaign_performance.parquet"),
        brand_data_path=os.path.join(str(tmpdir), "brand_data.parquet"),
        campaign_selection_path=os.path.join(str(tmpdir), "campaign_selection_path.parquet"),
        output_path=os.path.join(str(tmpdir), "output.parquet"),
        output_path_audit=os.path.join(str(tmpdir), "output_audit.parquet"),
        ucm_base_data_path=os.path.join(str(tmpdir), "ucm_base_data.parquet"),
        previous_measurement_campaign_reporting=os.path.join(str(tmpdir), "previous_measurement_campaign_reporting.parquet"),
    )


@pytest.fixture(autouse=True)
def write_brand_data(spark_session: SparkSession, get_mock_data, parquet_paths):
    """Materialise the hierarchy used to enrich all item-level shrinkage inputs."""
    spark_session.createDataFrame(
        get_mock_data["data"]["unified_products"],
        schema=get_mock_data["schema"]["unified_products"],
    ).write.parquet(parquet_paths.brand_data_path)


def test_prepare_incremental_shrinkage(spark_session: SparkSession, get_mock_data, parquet_paths):
    """Test that prepare_incremental_shrinkage correctly processes input data and writes output parquet files."""
    # Arrange input datasets: baseline output, weekly spend averages, legacy campaign performance, and campaign selection.
    baseline_output_path = parquet_paths.baseline_output_path
    avg_weekly_spend_data = parquet_paths.avg_weekly_spend_data
    measurement_legacy_campaign_performance = parquet_paths.measurement_legacy_campaign_performance
    campaign_selection_path = parquet_paths.campaign_selection_path
    output_path = parquet_paths.output_path
    output_path_audit = parquet_paths.output_path_audit

    run_date = "2024-06-01"
    correlation_id = "test-correlation-id"
    campaign_duration = CampaignDurations.CAMPAIGN_DURATION_DURING
    schemas = get_mock_data["schema"]
    mock_data = get_mock_data["data"]

    spark_session.createDataFrame(
        mock_data["measurement_legacy_campaign_performance"],
        schema=schemas["measurement_legacy_campaign_performance"],
    ).write.parquet(measurement_legacy_campaign_performance)

    spark_session.createDataFrame(
        mock_data["baseline_output"], schema=schemas["baseline_output"]
    ).write.parquet(baseline_output_path)

    spark_session.createDataFrame(
        mock_data["avg_weekly_spend_data"], schema=schemas["avg_weekly_spend_data"]
    ).write.parquet(avg_weekly_spend_data)

    spark_session.createDataFrame(
        mock_data["campaign_selection"], schema=schemas["campaign_selection"]
    ).write.parquet(campaign_selection_path)

    # Act: call prepare_incremental_shrinkage with mocked S3 writes and incremental shrinkage computation.
    with mock.patch('spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.spark_s3_overwrite',
                    side_effect=lambda path, df: df.write.mode("overwrite").parquet(path)):
        with mock.patch(
            "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.run_incremental_shrinkage",
            return_value=(123.0, 95.0, {"status": "ok"}, {}),
        ):
            prepare_incremental_shrinkage(
                spark_session,
                baseline_output_path,
                avg_weekly_spend_data,
                measurement_legacy_campaign_performance,
                campaign_selection_path,
                output_path,
                output_path_audit,
                campaign_duration,
                run_date,
                correlation_id,
                brand_data_path=parquet_paths.brand_data_path,
            )

    # Assert: verify output parquet contains the expected metric values from the mocked return (123.0, 95.0).
    # adjusted_calibrated_incrementality = calibrated_ucm (95.0) + during_incrementality (0) + bypass_incrementality (0)
    actual_df = spark_session.read.parquet(output_path)

    actual_metrics_df = (
        actual_df
        .filter(F.col("metric_name").isin(["ucm_incrementality", "adjusted_calibrated_incrementality"]))
        .select("metric_name", "metric_value")
        .orderBy("metric_name")
    )
    expected_metrics_df = spark_session.createDataFrame(
        [
            ("adjusted_calibrated_incrementality", 95.0),
            ("ucm_incrementality", 123.0),
        ],
        "metric_name string, metric_value float",
    )
    assert_df_equality(actual_metrics_df, expected_metrics_df, ignore_nullable=True)
    assert actual_df.filter(F.col("metric_name") == "calibrated_incrementality").count() > 0, \
        "calibrated_incrementality metric should exist in output"


def test_run_incremental_shrinkage_handles_null_incrementality(
    spark_session: SparkSession,
):
    """Test that run_incremental_shrinkage correctly handles null incrementality values by returning 0.0 and marking channels as failed."""
    # Arrange: set up campaign facts, spend data, and legacy performance with null total incrementality.
    campaign_facts = spark_session.createDataFrame(
        [("WALKERS", "CRISPS", "CRISPS", date(2026, 1, 1), date(2026, 1, 28), 100.0, "OFFSITE", False)],
        "unique_brand_name string, super_category_name string, sub_category_name string, min_campaign_start_dt date, max_campaign_end_dt date, channel_spend double, marketing_type string, bypass_flag boolean",
    )
    avg_weekly_spend_data = spark_session.createDataFrame(
        [(2026, "CRISPS", "CRISPS", "WALKERS", 1000.0)],
        "year int, super_category_name string, sub_category_name string, unique_brand_name string, avg_weekly_spend double",
    )
    legacy_campaign_data = spark_session.createDataFrame(
        [("cmp-null-001", "CRISPS", "OFFSITE", 1000.0, 100.0, 90.0, 1.0)],
        "campaign_id string, super_category_name string, marketing_type string, media_cost double, test double, control double, iroas double",
    )
    total_incrementality = spark_session.createDataFrame([(None,)], "incrementality double")

    # Act: invoke run_incremental_shrinkage with a null incrementality value and mocked aggregate prior.
    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.get_aggregate_prior",
        return_value=([], {"priors": {}}, ["OFFSITE"], {}),
    ):
        ucm_incrementality, calibrated_ucm, audit, priors = run_incremental_shrinkage(
            spark=spark_session,
            campaign_facts=campaign_facts,
            avg_weekly_spend_data=avg_weekly_spend_data,
            legacy_campaign_data=legacy_campaign_data,
            total_incrementality=total_incrementality,
            bypass_incrementality=0.0,
            config=BaselineModellingShrinkageConfig(),
        )

    # Assert: verify that null incrementality is converted to 0.0, no calibration is applied, and the channel is marked as failed.
    assert ucm_incrementality == 0.0
    assert calibrated_ucm is None
    assert audit == {"failed_channels": ["OFFSITE"]}
    assert priors == {}


def test_run_incremental_shrinkage_clamps_negative_incrementality_to_zero_before_calibration(
    spark_session: SparkSession,
):
    """Test that run_incremental_shrinkage clamps negative UCM incrementality to 0.0 before
    passing it to calibrate, while still returning the raw negative value as ucm_incrementality.

    Business rule: a campaign cannot cause negative sales. When UCM returns a negative value
    it is treated as model noise — calibration runs against 0.0 (no uplift) rather than a
    negative uplift, so the prior can pull the result toward the historical typical.
    Note: we are not testing the actual calibration logic here, just that the negative value is clamped to 0.0 before calling calibrate.
    """
    campaign_facts = spark_session.createDataFrame(
        [("WALKERS", "CRISPS & SNACKS", "CRISPS", date(2023, 1, 1), date(2023, 1, 28), 52000.0, "INSTORE", False)],
        "unique_brand_name string, super_category_name string, sub_category_name string, min_campaign_start_dt date, max_campaign_end_dt date, channel_spend double, marketing_type string, bypass_flag boolean",
    )
    avg_weekly_spend_data = spark_session.createDataFrame(
        [(2023, "CRISPS & SNACKS", "CRISPS", "WALKERS", 5000.0)],
        "year int, super_category_name string, sub_category_name string, unique_brand_name string, avg_weekly_spend double",
    )
    legacy_campaign_data = spark_session.createDataFrame(
        [("cmp-clamp-001", "CRISPS & SNACKS", "INSTORE", 52000.0, 5000.0, 4500.0, 1.0)],
        "campaign_id string, super_category_name string, marketing_type string, media_cost double, test double, control double, iroas double",
    )
    # Negative UCM incrementality
    total_incrementality = spark_session.createDataFrame([(-5000.0,)], "incrementality double")

    calibrate_received = {}

    def capture_calibrate(incrementality, prior, config):
        calibrate_received["incrementality"] = incrementality
        return (3000.0, {"status": "ok"})

    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.get_aggregate_prior",
        return_value=([], {}, [], {}),
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.generate_bypass_metadata",
        return_value={},
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.calibrate",
        side_effect=capture_calibrate,
    ):
        ucm_incrementality, calibrated_ucm, audit, _ = run_incremental_shrinkage(
            spark=spark_session,
            campaign_facts=campaign_facts,
            avg_weekly_spend_data=avg_weekly_spend_data,
            legacy_campaign_data=legacy_campaign_data,
            total_incrementality=total_incrementality,
            bypass_incrementality=0.0,
            config=BaselineModellingShrinkageConfig(),
        )

    # Build actual results DataFrame combining all three values under test.
    actual_df = spark_session.createDataFrame(
        [(ucm_incrementality, calibrate_received["incrementality"], calibrated_ucm)],
        "ucm_incrementality double, calibrate_input double, calibrated_ucm double",
    )

    # Expected:
    # - ucm_incrementality = -5000.0  (raw negative returned unchanged for transparency)
    # - calibrate_input    =     0.0  (negative clamped to 0 before calibration)
    # - calibrated_ucm     =  3000.0  (value returned by mocked calibrate)
    expected_df = spark_session.createDataFrame(
        [(-5000.0, 0.0, 3000.0)],
        "ucm_incrementality double, calibrate_input double, calibrated_ucm double",
    )

    assert_df_equality(actual_df, expected_df, ignore_nullable=True)


def test_allowed_super_cat_count_filters_multi_super_category_campaigns(
    spark_session: SparkSession,
):
    """Test that run_incremental_shrinkage drops legacy campaigns whose rows span more
    distinct super_category_name values than config.allowed_super_cat_count before priors
    are built.

    Business rule: a legacy campaign_id spanning multiple super categories is considered
    unreliable for single-category shrinkage priors, so it is excluded via the
    num_super_categories == config.allowed_super_cat_count check in run_incremental_shrinkage.
    """
    campaign_facts = spark_session.createDataFrame(
        [("WALKERS", "CRISPS & SNACKS", "CRISPS", date(2023, 1, 1), date(2023, 1, 28), 52000.0, "INSTORE", False)],
        "unique_brand_name string, super_category_name string, sub_category_name string, min_campaign_start_dt date, max_campaign_end_dt date, channel_spend double, marketing_type string, bypass_flag boolean",
    )
    avg_weekly_spend_data = spark_session.createDataFrame(
        [(2023, "CRISPS & SNACKS", "CRISPS", "WALKERS", 5000.0)],
        "year int, super_category_name string, sub_category_name string, unique_brand_name string, avg_weekly_spend double",
    )
    legacy_campaign_data = spark_session.createDataFrame(
        [
            # Single super_category_name -> retained (1 distinct value == default allowed_super_cat_count)
            ("cmp-single", "CRISPS & SNACKS", "INSTORE", 52000.0, 5000.0, 4500.0, 1.0),
            # Same campaign_id split across two super categories -> excluded (2 distinct values)
            ("cmp-multi", "CRISPS & SNACKS", "INSTORE", 52000.0, 5000.0, 4500.0, 1.0),
            ("cmp-multi", "BEVERAGES", "INSTORE", 52000.0, 5000.0, 4500.0, 1.0),
        ],
        "campaign_id string, super_category_name string, marketing_type string, media_cost double, test double, control double, iroas double",
    )
    total_incrementality = spark_session.createDataFrame([(100.0,)], "incrementality double")

    captured = {}

    def capture_legacy_and_return(channels, campaign_metadata, campaign_channel, legacy_campaign_data_filtered, avg_weekly_spend_data, config):
        captured["legacy"] = legacy_campaign_data_filtered
        return ([], {}, [], {})

    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.get_aggregate_prior",
        side_effect=capture_legacy_and_return,
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.generate_bypass_metadata",
        return_value={},
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.calibrate",
        return_value=(95.0, {"status": "ok"}),
    ):
        run_incremental_shrinkage(
            spark=spark_session,
            campaign_facts=campaign_facts,
            avg_weekly_spend_data=avg_weekly_spend_data,
            legacy_campaign_data=legacy_campaign_data,
            total_incrementality=total_incrementality,
            bypass_incrementality=0.0,
            config=BaselineModellingShrinkageConfig(),
        )

    actual_campaign_ids = {row["campaign_id"] for row in captured["legacy"].collect()}
    assert actual_campaign_ids == {"cmp-single"}, (
        f"Expected only single-super-category campaigns to survive the allowed_super_cat_count filter, got {actual_campaign_ids}"
    )


def test_allowed_super_cat_count_configurable_threshold_retains_multi_category_campaigns(
    spark_session: SparkSession,
):
    """Test that raising config.allowed_super_cat_count retains campaigns spanning that many
    distinct super categories, proving the guardrail is driven by config and not hardcoded.
    """
    campaign_facts = spark_session.createDataFrame(
        [("WALKERS", "CRISPS & SNACKS", "CRISPS", date(2023, 1, 1), date(2023, 1, 28), 52000.0, "INSTORE", False)],
        "unique_brand_name string, super_category_name string, sub_category_name string, min_campaign_start_dt date, max_campaign_end_dt date, channel_spend double, marketing_type string, bypass_flag boolean",
    )
    avg_weekly_spend_data = spark_session.createDataFrame(
        [(2023, "CRISPS & SNACKS", "CRISPS", "WALKERS", 5000.0)],
        "year int, super_category_name string, sub_category_name string, unique_brand_name string, avg_weekly_spend double",
    )
    legacy_campaign_data = spark_session.createDataFrame(
        [
            ("cmp-multi", "CRISPS & SNACKS", "INSTORE", 52000.0, 5000.0, 4500.0, 1.0),
            ("cmp-multi", "BEVERAGES", "INSTORE", 52000.0, 5000.0, 4500.0, 1.0),
        ],
        "campaign_id string, super_category_name string, marketing_type string, media_cost double, test double, control double, iroas double",
    )
    total_incrementality = spark_session.createDataFrame([(100.0,)], "incrementality double")

    captured = {}

    def capture_legacy_and_return(channels, campaign_metadata, campaign_channel, legacy_campaign_data_filtered, avg_weekly_spend_data, config):
        captured["legacy"] = legacy_campaign_data_filtered
        return ([], {}, [], {})

    config_with_higher_threshold = replace(BaselineModellingShrinkageConfig(), allowed_super_cat_count=2)

    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.get_aggregate_prior",
        side_effect=capture_legacy_and_return,
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.generate_bypass_metadata",
        return_value={},
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.calibrate",
        return_value=(95.0, {"status": "ok"}),
    ):
        run_incremental_shrinkage(
            spark=spark_session,
            campaign_facts=campaign_facts,
            avg_weekly_spend_data=avg_weekly_spend_data,
            legacy_campaign_data=legacy_campaign_data,
            total_incrementality=total_incrementality,
            bypass_incrementality=0.0,
            config=config_with_higher_threshold,
        )

    actual_campaign_ids = {row["campaign_id"] for row in captured["legacy"].collect()}
    assert actual_campaign_ids == {"cmp-multi"}, (
        f"Expected multi-category campaign to survive when allowed_super_cat_count=2, got {actual_campaign_ids}"
    )


def test_prepare_incremental_shrinkage_passes_best_iterations_to_bypass(spark_session: SparkSession, get_mock_data, parquet_paths):
    """Test that prepare_incremental_shrinkage correctly extracts and passes best iteration values to get_bypass_incrementality."""
    # Arrange: create baseline output with best iterations and UCM base data containing iteration specifications.
    baseline_output_path = parquet_paths.baseline_output_path
    avg_weekly_spend_data = parquet_paths.avg_weekly_spend_data
    measurement_legacy_campaign_performance = parquet_paths.measurement_legacy_campaign_performance
    campaign_selection_path = parquet_paths.campaign_selection_path
    ucm_base_data_path = parquet_paths.ucm_base_data_path
    output_path = parquet_paths.output_path
    output_path_audit = parquet_paths.output_path_audit

    run_date = "2024-06-01"
    correlation_id = "test-correlation-id"
    campaign_duration = CampaignDurations.CAMPAIGN_DURATION_DURING
    schemas = get_mock_data["schema"]
    mock_data = get_mock_data["data"]

    spark_session.createDataFrame(
        mock_data["measurement_legacy_campaign_performance"],
        schema=schemas["measurement_legacy_campaign_performance"],
    ).write.parquet(measurement_legacy_campaign_performance)

    spark_session.createDataFrame(
        mock_data["baseline_output"], schema=schemas["baseline_output"]
    ).write.parquet(baseline_output_path)

    spark_session.createDataFrame(
        mock_data["avg_weekly_spend_data"], schema=schemas["avg_weekly_spend_data"]
    ).write.parquet(avg_weekly_spend_data)

    spark_session.createDataFrame(
        [(
            "WALKERS", "CRISPS & SNACKS", "CRISPS", date(2026, 1, 1), date(2026, 1, 28), date(2026, 2, 28), 50000.0,
            "ONSITE", {"ONSITE": 50000.0}
        )],
        schema=schemas["campaign_selection"],
    ).write.parquet(campaign_selection_path)

    spark_session.createDataFrame(
        [("2026-01-05", "cluster_1", "level_var:0.50 | cycle:True[26, 104]_set_2", "ons_ons_feature", 10.0)],
        "wdate string, modelling_cluster string, iteration string, variable string, value double",
    ).write.parquet(ucm_base_data_path)

    # Act: call prepare_incremental_shrinkage and capture the bypass mock to verify best_iterations argument.
    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.spark_s3_overwrite",
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.run_incremental_shrinkage",
        return_value=(123.0, 95.0, {"status": "ok"}, {}),
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.get_bypass_incrementality",
        return_value=10.0,
    ) as bypass_mock:
        prepare_incremental_shrinkage(
            spark_session,
            baseline_output_path,
            avg_weekly_spend_data,
            measurement_legacy_campaign_performance,
            campaign_selection_path,
            output_path,
            output_path_audit,
            campaign_duration,
            run_date,
            correlation_id,
            ucm_base_data=ucm_base_data_path,
            brand_data_path=parquet_paths.brand_data_path,
        )

    # Assert: verify that the best iteration from baseline output was correctly passed to get_bypass_incrementality.
    assert bypass_mock.call_args.kwargs["best_iterations"] == ["level_var:0.50 | cycle:True[26, 104]_set_2"]


def test_prepare_incremental_shrinkage_post_campaign_date_logic(spark_session: SparkSession, get_mock_data, parquet_paths):
    """Test that prepare_incremental_shrinkage correctly calculates post-campaign date range.

    Verifies:
    - Finds which week the campaign ended in
    - Moves to the first day of the following week (next Monday)
    - Uses that as the start date for post-campaign period data (min_campaign_start_dt in campaign_facts)

    Campaign ends on 2026-01-28 (Wednesday):
      date_trunc("week", 2026-01-28) → 2026-01-26 (Monday of that week)
      + 7 days                       → 2026-02-02 (following Monday)  ← expected min_campaign_start_dt
      max_post_campaign_dt           → 2026-02-28                      ← expected max_campaign_end_dt
    Business rule: helps with avoiding partial weeks in post-campaign analysis, and ensures that post-campaign period starts after the campaign has fully ended.
    """
    baseline_output_path = parquet_paths.baseline_output_path
    avg_weekly_spend_data_path = parquet_paths.avg_weekly_spend_data
    measurement_legacy_campaign_performance = parquet_paths.measurement_legacy_campaign_performance
    campaign_selection_path = parquet_paths.campaign_selection_path
    output_path = parquet_paths.output_path
    output_path_audit = parquet_paths.output_path_audit

    run_date = "2026-02-15"
    correlation_id = "test-correlation-id-post"
    campaign_duration = CampaignDurations.CAMPAIGN_DURATION_POST
    schemas = get_mock_data["schema"]
    mock_data = get_mock_data["data"]

    spark_session.createDataFrame(
        mock_data["measurement_legacy_campaign_performance_post"],
        schema=schemas["measurement_legacy_campaign_performance"],
    ).write.parquet(measurement_legacy_campaign_performance)

    spark_session.createDataFrame(
        mock_data["baseline_output"], schema=schemas["baseline_output"]
    ).write.parquet(baseline_output_path)

    spark_session.createDataFrame(
        mock_data["avg_weekly_spend_data"], schema=schemas["avg_weekly_spend_data"]
    ).write.parquet(avg_weekly_spend_data_path)

    spark_session.createDataFrame(
        [("WALKERS", "CRISPS & SNACKS", "CRISPS", date(2026, 1, 1), date(2026, 1, 28), date(2026, 2, 28), 50000.0, "INSTORE", {"INSTORE": 50000.0})],
        schema=schemas["campaign_selection"],
    ).write.parquet(campaign_selection_path)

    # Act: capture campaign_facts as passed to run_incremental_shrinkage.
    captured_campaign_facts = {}

    def capture_and_return(spark, campaign_facts, avg_weekly_spend_data, legacy_campaign_data, total_incrementality, bypass_incrementality, config):
        captured_campaign_facts["df"] = campaign_facts.collect()
        return (50.0, 45.0, {"status": "ok"}, {})

    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.spark_s3_overwrite",
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.run_incremental_shrinkage",
        side_effect=capture_and_return,
    ):
        prepare_incremental_shrinkage(
            spark_session,
            baseline_output_path,
            avg_weekly_spend_data_path,
            measurement_legacy_campaign_performance,
            campaign_selection_path,
            output_path,
            output_path_audit,
            campaign_duration,
            run_date,
            correlation_id,
            previous_measurement_campaign_reporting=None,
            brand_data_path=parquet_paths.brand_data_path,
        )

    # Assert: campaign_facts date window uses the Monday after the campaign-end week as start,
    # and max_post_campaign_dt as end.
    rows = captured_campaign_facts["df"]
    assert len(rows) > 0, "campaign_facts should contain at least one row"

    actual_start_dates = {row["min_campaign_start_dt"] for row in rows}
    actual_end_dates = {row["max_campaign_end_dt"] for row in rows}

    assert actual_start_dates == {date(2026, 2, 2)}, (
        f"Expected min_campaign_start_dt=2026-02-02 (next Monday after campaign end week), got {actual_start_dates}"
    )
    assert actual_end_dates == {date(2026, 2, 28)}, (
        f"Expected max_campaign_end_dt=2026-02-28 (max_post_campaign_dt), got {actual_end_dates}"
    )


def test_invalid_campaign_duration_raises_error(spark_session: SparkSession, get_mock_data, parquet_paths):
    """Test that prepare_incremental_shrinkage raises ValueError for invalid campaign_duration.

    The ValueError fires in the start_col/end_col branch, which is reached after reading
    baseline_output, avg_weekly_spend_data, measurement_legacy_campaign_performance, and
    campaign_selection — but before spark_s3_overwrite is ever called.
    """
    baseline_output_path = parquet_paths.baseline_output_path
    avg_weekly_spend_data = parquet_paths.avg_weekly_spend_data
    measurement_legacy_campaign_performance = parquet_paths.measurement_legacy_campaign_performance
    campaign_selection_path = parquet_paths.campaign_selection_path
    output_path = parquet_paths.output_path
    output_path_audit = parquet_paths.output_path_audit

    run_date = "2024-06-01"
    correlation_id = "test-correlation-id"
    invalid_campaign_duration = "INVALID_DURATION"
    schemas = get_mock_data["schema"]
    mock_data = get_mock_data["data"]

    spark_session.createDataFrame(
        mock_data["measurement_legacy_campaign_performance"],
        schema=schemas["measurement_legacy_campaign_performance"],
    ).write.parquet(measurement_legacy_campaign_performance)

    spark_session.createDataFrame(
        mock_data["baseline_output"], schema=schemas["baseline_output"]
    ).write.parquet(baseline_output_path)

    spark_session.createDataFrame(
        mock_data["avg_weekly_spend_data"], schema=schemas["avg_weekly_spend_data"]
    ).write.parquet(avg_weekly_spend_data)

    spark_session.createDataFrame(
        mock_data["campaign_selection"], schema=schemas["campaign_selection"]
    ).write.parquet(campaign_selection_path)

    # Act & Assert: spark_s3_overwrite is never reached so a bare mock is sufficient.
    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.spark_s3_overwrite",
    ), pytest.raises(ValueError, match="Invalid campaign_duration"):
        prepare_incremental_shrinkage(
            spark_session,
            baseline_output_path,
            avg_weekly_spend_data,
            measurement_legacy_campaign_performance,
            campaign_selection_path,
            output_path,
            output_path_audit,
            invalid_campaign_duration,
            run_date,
            correlation_id,
            brand_data_path=parquet_paths.brand_data_path,
        )


def test_post_campaign_without_previous_reporting(spark_session: SparkSession, get_mock_data, parquet_paths):
    """Test that post-campaign with no previous_measurement_campaign_reporting sets during_incrementality to 0."""
    baseline_output_path = parquet_paths.baseline_output_path
    avg_weekly_spend_data = parquet_paths.avg_weekly_spend_data
    measurement_legacy_campaign_performance = parquet_paths.measurement_legacy_campaign_performance
    campaign_selection_path = parquet_paths.campaign_selection_path
    output_path = parquet_paths.output_path
    output_path_audit = parquet_paths.output_path_audit

    run_date = "2026-02-15"
    correlation_id = "test-correlation-post-no-prior"
    campaign_duration = CampaignDurations.CAMPAIGN_DURATION_POST
    schemas = get_mock_data["schema"]
    mock_data = get_mock_data["data"]

    spark_session.createDataFrame(
        mock_data["measurement_legacy_campaign_performance_post"],
        schema=schemas["measurement_legacy_campaign_performance"],
    ).write.parquet(measurement_legacy_campaign_performance)

    spark_session.createDataFrame(
        mock_data["baseline_output"], schema=schemas["baseline_output"]
    ).write.parquet(baseline_output_path)

    spark_session.createDataFrame(
        mock_data["avg_weekly_spend_data"], schema=schemas["avg_weekly_spend_data"]
    ).write.parquet(avg_weekly_spend_data)

    spark_session.createDataFrame(
        [("WALKERS", "CRISPS & SNACKS", "CRISPS", date(2026, 1, 1), date(2026, 1, 28), date(2026, 2, 28), 50000.0, "INSTORE", {"INSTORE": 50000.0})],
        schema=schemas["campaign_selection"],
    ).write.parquet(campaign_selection_path)

    # Act: call prepare_incremental_shrinkage WITHOUT previous_measurement_campaign_reporting
    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.spark_s3_overwrite",
        side_effect=lambda path, df: df.write.mode("overwrite").parquet(path),
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.run_incremental_shrinkage",
        return_value=(50.0, 45.0, {"status": "ok"}, {}),
    ):
        prepare_incremental_shrinkage(
            spark_session,
            baseline_output_path,
            avg_weekly_spend_data,
            measurement_legacy_campaign_performance,
            campaign_selection_path,
            output_path,
            output_path_audit,
            campaign_duration,
            run_date,
            correlation_id,
            previous_measurement_campaign_reporting=None,  # Explicitly None
            brand_data_path=parquet_paths.brand_data_path,
        )

    # Assert: verify output has during_incrementality = 0.0 (not 100.0 from prior data)
    actual_df = spark_session.read.parquet(output_path)

    actual_during_df = (
        actual_df
        .filter(F.col("metric_name") == "during_incrementality")
        .select("metric_name", "metric_value")
    )
    expected_during_df = spark_session.createDataFrame(
        [("during_incrementality", 0.0)],
        "metric_name string, metric_value float",
    )
    assert_df_equality(actual_during_df, expected_during_df, ignore_nullable=True)


def test_post_campaign_uses_unscaled_previous_reporting_incrementality(
    spark_session: SparkSession,
    get_mock_data,
    parquet_paths,
):
    """Test that Post runs reverse the previous reporting spend weight before aggregation."""
    baseline_output_path = parquet_paths.baseline_output_path
    avg_weekly_spend_data = parquet_paths.avg_weekly_spend_data
    measurement_legacy_campaign_performance = parquet_paths.measurement_legacy_campaign_performance
    campaign_selection_path = parquet_paths.campaign_selection_path
    output_path = parquet_paths.output_path
    output_path_audit = parquet_paths.output_path_audit
    previous_reporting_path = parquet_paths.previous_measurement_campaign_reporting

    schemas = get_mock_data["schema"]
    mock_data = get_mock_data["data"]

    spark_session.createDataFrame(
        mock_data["measurement_legacy_campaign_performance_post"],
        schema=schemas["measurement_legacy_campaign_performance"],
    ).write.parquet(measurement_legacy_campaign_performance)
    spark_session.createDataFrame(
        mock_data["baseline_output"], schema=schemas["baseline_output"]
    ).write.parquet(baseline_output_path)
    spark_session.createDataFrame(
        mock_data["avg_weekly_spend_data"], schema=schemas["avg_weekly_spend_data"]
    ).write.parquet(avg_weekly_spend_data)
    spark_session.createDataFrame(
        [
            (
                "WALKERS",
                "CRISPS & SNACKS",
                "CRISPS",
                date(2026, 1, 1),
                date(2026, 1, 28),
                date(2026, 2, 28),
                50000.0,
                "INSTORE",
                {"INSTORE": 50000.0},
            )
        ],
        schema=schemas["campaign_selection"],
    ).write.parquet(campaign_selection_path)

    spark_session.createDataFrame(
        [(100.0, 0.5)],
        "incremental_sales_amt_exposed double, spend_weight double",
    ).write.parquet(previous_reporting_path)

    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.spark_s3_overwrite",
        side_effect=lambda path, df: df.write.mode("overwrite").parquet(path),
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.run_incremental_shrinkage",
        return_value=(50.0, 45.0, {"status": "ok"}, {}),
    ):
        prepare_incremental_shrinkage(
            spark=spark_session,
            baseline_output_path=baseline_output_path,
            avg_weekly_spend_data_path=avg_weekly_spend_data,
            measurement_legacy_campaign_performance=measurement_legacy_campaign_performance,
            campaign_selection_path=campaign_selection_path,
            output_path=output_path,
            output_path_audit=output_path_audit,
            campaign_duration=CampaignDurations.CAMPAIGN_DURATION_POST,
            run_date="2026-02-15",
            correlation_id="test-correlation-post-with-prior",
            previous_measurement_campaign_reporting=previous_reporting_path,
            brand_data_path=parquet_paths.brand_data_path,
        )

    actual_df = spark_session.read.parquet(output_path)
    actual_metrics_df = (
        actual_df
        .filter(F.col("metric_name").isin([
            "during_incrementality",
            "adjusted_calibrated_incrementality",
        ]))
        .select("metric_name", "metric_value")
        .orderBy("metric_name")
    )
    expected_metrics_df = spark_session.createDataFrame(
        [
            ("adjusted_calibrated_incrementality", 245.0),
            ("during_incrementality", 200.0),
        ],
        "metric_name string, metric_value float",
    )

    assert_df_equality(actual_metrics_df, expected_metrics_df, ignore_nullable=True)


def test_calibrated_ucm_none_raises_error(spark_session: SparkSession, get_mock_data, parquet_paths):
    """Test that prepare_incremental_shrinkage raises ValueError when calibrated_ucm is None."""
    baseline_output_path = parquet_paths.baseline_output_path
    avg_weekly_spend_data = parquet_paths.avg_weekly_spend_data
    measurement_legacy_campaign_performance = parquet_paths.measurement_legacy_campaign_performance
    campaign_selection_path = parquet_paths.campaign_selection_path
    output_path = parquet_paths.output_path
    output_path_audit = parquet_paths.output_path_audit

    run_date = "2024-06-01"
    correlation_id = "test-correlation-id"
    campaign_duration = CampaignDurations.CAMPAIGN_DURATION_DURING
    schemas = get_mock_data["schema"]
    mock_data = get_mock_data["data"]

    spark_session.createDataFrame(
        mock_data["measurement_legacy_campaign_performance"],
        schema=schemas["measurement_legacy_campaign_performance"],
    ).write.parquet(measurement_legacy_campaign_performance)

    spark_session.createDataFrame(
        mock_data["baseline_output"], schema=schemas["baseline_output"]
    ).write.parquet(baseline_output_path)

    spark_session.createDataFrame(
        mock_data["avg_weekly_spend_data"], schema=schemas["avg_weekly_spend_data"]
    ).write.parquet(avg_weekly_spend_data)

    spark_session.createDataFrame(
        mock_data["campaign_selection"], schema=schemas["campaign_selection"]
    ).write.parquet(campaign_selection_path)

    # Act & Assert: mock run_incremental_shrinkage to return None for calibrated_ucm
    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.spark_s3_overwrite",
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.run_incremental_shrinkage",
        return_value=(123.0, None, {"status": "ok"}, {}),  # calibrated_ucm is None
    ), pytest.raises(ValueError, match="Calibration failed for all channels"):
        prepare_incremental_shrinkage(
            spark_session,
            baseline_output_path,
            avg_weekly_spend_data,
            measurement_legacy_campaign_performance,
            campaign_selection_path,
            output_path,
            output_path_audit,
            campaign_duration,
            run_date,
            correlation_id,
            brand_data_path=parquet_paths.brand_data_path,
        )


def test_negative_iroas_values(spark_session: SparkSession, get_mock_data, parquet_paths):
    """Test that prepare_incremental_shrinkage correctly computes negative IROAS from legacy
    campaign data where test < control, and that the computed iroas values flow through
    the real outlier_filter inside run_incremental_shrinkage unchanged.

    iroas = (test - control) / media_cost is computed in prepare_incremental_shrinkage.
    run_incremental_shrinkage is NOT mocked — outlier_filter runs for real.
    get_aggregate_prior is captured via side_effect to verify iroas < 0 on the filtered data.
    """
    baseline_output_path = parquet_paths.baseline_output_path
    avg_weekly_spend_data = parquet_paths.avg_weekly_spend_data
    measurement_legacy_campaign_performance = parquet_paths.measurement_legacy_campaign_performance
    campaign_selection_path = parquet_paths.campaign_selection_path
    output_path = parquet_paths.output_path
    output_path_audit = parquet_paths.output_path_audit

    run_date = "2024-06-01"
    correlation_id = "test-correlation-negative-iroas"
    campaign_duration = CampaignDurations.CAMPAIGN_DURATION_DURING
    schemas = get_mock_data["schema"]
    mock_data = get_mock_data["data"]

    # Legacy data with test < control: iroas = (test - control) / media_cost < 0.
    # Row 1: iroas = (498000 - 500000) / 100000 = -0.02
    # Row 2: iroas = (399500 - 400000) / 80000  = -0.00625
    legacy_data_negative_iroas = [
        ("cmp-iroas-001", "CAMPAIGN-cmp-001", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 498000.0, 500000.0, -2000.0, 100000.0),
        ("cmp-iroas-002", "CAMPAIGN-cmp-008", "OFFSITE", "DURING", date(2023, 3, 1), date(2023, 3, 28), 399500.0, 400000.0, -500.0, 80000.0),
    ]

    spark_session.createDataFrame(
        legacy_data_negative_iroas,
        schema=schemas["measurement_legacy_campaign_performance"],
    ).write.parquet(measurement_legacy_campaign_performance)

    spark_session.createDataFrame(
        mock_data["baseline_output"], schema=schemas["baseline_output"]
    ).write.parquet(baseline_output_path)

    spark_session.createDataFrame(
        mock_data["avg_weekly_spend_data"], schema=schemas["avg_weekly_spend_data"]
    ).write.parquet(avg_weekly_spend_data)

    spark_session.createDataFrame(
        mock_data["campaign_selection"], schema=schemas["campaign_selection"]
    ).write.parquet(campaign_selection_path)

    # Capture legacy_campaign_data_filtered (post-outlier_filter) passed to get_aggregate_prior.
    # run_incremental_shrinkage is NOT mocked — the real outlier_filter executes.
    # get_incrementality, get_aggregate_prior, calibrate and generate_bypass_metadata are mocked
    # to avoid the full Bayesian computation while keeping the IROAS transformation real.
    captured = {}

    def capture_legacy_and_return(channels, campaign_metadata, campaign_channel,
                                  legacy_campaign_data_filtered, avg_weekly_spend_data, config):
        captured["legacy"] = legacy_campaign_data_filtered
        return ([], {}, [], {})  # no priors, no failed channels

    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.spark_s3_overwrite",
        side_effect=lambda path, df: df.write.mode("overwrite").parquet(path),
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.get_incrementality",
        return_value=spark_session.createDataFrame([(-2000.0,)], "incrementality double"),
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.get_aggregate_prior",
        side_effect=capture_legacy_and_return,
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.calibrate",
        return_value=(-1800.0, {"status": "ok"}),
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.generate_bypass_metadata",
        return_value={},
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.build_incremental_shrinkage_audit_df",
        return_value=spark_session.createDataFrame([(1,)], "dummy int"),
    ):
        prepare_incremental_shrinkage(
            spark=spark_session,
            baseline_output_path=baseline_output_path,
            avg_weekly_spend_data_path=avg_weekly_spend_data,
            measurement_legacy_campaign_performance=measurement_legacy_campaign_performance,
            campaign_selection_path=campaign_selection_path,
            output_path=output_path,
            output_path_audit=output_path_audit,
            campaign_duration=campaign_duration,
            run_date=run_date,
            correlation_id=correlation_id,
            brand_data_path=parquet_paths.brand_data_path,
        )

    # Assert: verify iroas is negative for both campaigns after outlier_filter.
    # iroas = (test - control) / media_cost, computed in prepare_incremental_shrinkage.
    # Row 1: (498000 - 500000) / 100000 = -0.02
    # Row 2: (399500 - 400000) / 80000  = -0.00625
    expected_iroas_df = spark_session.createDataFrame(
        [
            ("INSTORE", -0.02),
            ("OFFSITE", -0.00625),
        ],
        "marketing_type string, iroas double",
    )

    actual_iroas_df = captured["legacy"].select("marketing_type", "iroas").orderBy("marketing_type")

    assert_approx_df_equality(
        actual_iroas_df,
        expected_iroas_df.orderBy("marketing_type"),
        precision=0.0001,
        ignore_nullable=True,
    )


def test_zero_media_cost_handling(spark_session: SparkSession, get_mock_data, parquet_paths):
    """Test that prepare_incremental_shrinkage filters out campaigns with zero media_cost.

    iroas = (test - control) / media_cost is computed in prepare_incremental_shrinkage.
    When media_cost == 0 the rows fall below the outlier filter threshold and are removed.
    run_incremental_shrinkage is NOT mocked — outlier_filter runs for real.
    get_aggregate_prior is captured via side_effect to verify the filtered dataframe is empty.
    """
    baseline_output_path = parquet_paths.baseline_output_path
    avg_weekly_spend_data = parquet_paths.avg_weekly_spend_data
    measurement_legacy_campaign_performance = parquet_paths.measurement_legacy_campaign_performance
    campaign_selection_path = parquet_paths.campaign_selection_path
    output_path = parquet_paths.output_path
    output_path_audit = parquet_paths.output_path_audit

    run_date = "2024-06-01"
    correlation_id = "test-correlation-zero-cost"
    campaign_duration = CampaignDurations.CAMPAIGN_DURATION_DURING
    schemas = get_mock_data["schema"]
    mock_data = get_mock_data["data"]

    # Legacy data with media_cost == 0 falls below outlier_filter's spend_min_threshold.
    # Both rows should be removed before prior estimation.
    legacy_data_zero_cost = [
        ("cmp-zero-001", "CAMPAIGN-cmp-001", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 375000.0, 355000.0, 5.63, 0.0),
        ("cmp-zero-002", "CAMPAIGN-cmp-008", "OFFSITE", "DURING", date(2023, 3, 1), date(2023, 3, 28), 386000.0, 364000.0, 6.04, 0.0),
    ]

    spark_session.createDataFrame(
        legacy_data_zero_cost,
        schema=schemas["measurement_legacy_campaign_performance"],
    ).write.parquet(measurement_legacy_campaign_performance)

    spark_session.createDataFrame(
        mock_data["baseline_output"], schema=schemas["baseline_output"]
    ).write.parquet(baseline_output_path)

    spark_session.createDataFrame(
        mock_data["avg_weekly_spend_data"], schema=schemas["avg_weekly_spend_data"]
    ).write.parquet(avg_weekly_spend_data)

    spark_session.createDataFrame(
        mock_data["campaign_selection"], schema=schemas["campaign_selection"]
    ).write.parquet(campaign_selection_path)

    # Capture legacy_campaign_data_filtered (post-outlier_filter) passed to get_aggregate_prior.
    # run_incremental_shrinkage is NOT mocked — the real outlier_filter executes.
    # get_incrementality, get_aggregate_prior, calibrate and generate_bypass_metadata are mocked
    # to avoid the full Bayesian computation while keeping the IROAS transformation real.
    captured = {}

    def capture_legacy_and_return(channels, campaign_metadata, campaign_channel,
                                  legacy_campaign_data_filtered, avg_weekly_spend_data, config):
        captured["legacy"] = legacy_campaign_data_filtered  # comes from outlier_filter()
        return ([], {}, [], {})  # no priors, no failed channels

    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.spark_s3_overwrite",
        side_effect=lambda path, df: df.write.mode("overwrite").parquet(path),
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.get_incrementality",
        return_value=spark_session.createDataFrame([(0.0,)], "incrementality double"),
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.get_aggregate_prior",
        side_effect=capture_legacy_and_return,
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.calibrate",
        return_value=(68.0, {"status": "ok"}),
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.generate_bypass_metadata",
        return_value={},
    ), mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.build_incremental_shrinkage_audit_df",
        return_value=spark_session.createDataFrame([(1,)], "dummy int"),
    ):
        prepare_incremental_shrinkage(
            spark=spark_session,
            baseline_output_path=baseline_output_path,
            avg_weekly_spend_data_path=avg_weekly_spend_data,
            measurement_legacy_campaign_performance=measurement_legacy_campaign_performance,
            campaign_selection_path=campaign_selection_path,
            output_path=output_path,
            output_path_audit=output_path_audit,
            campaign_duration=campaign_duration,
            run_date=run_date,
            correlation_id=correlation_id,
            brand_data_path=parquet_paths.brand_data_path,
        )

    actual_iroas_df = captured["legacy"].select("marketing_type", "iroas").orderBy("marketing_type")

    assert actual_iroas_df.count() == 0


def test_legacy_campaign_period_filtering(spark_session: SparkSession):
    """
    Test that legacy campaign data is correctly filtered by PERIOD column.
    When campaign_duration == "During", only rows with PERIOD == "DURING" should be retained.
    When campaign_duration == "Post", only rows with PERIOD == "POST" should be retained.
    """
    # Arrange: create mock legacy campaign data with mixed PERIOD values (DURING and POST).
    schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_source", T.StringType(), True),
        T.StructField("period", T.StringType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("test", T.DoubleType(), True),
        T.StructField("control", T.DoubleType(), True),
        T.StructField("uplift", T.DoubleType(), True),
        T.StructField("media_cost", T.DoubleType(), True),
    ])
    legacy_data = spark_session.createDataFrame(
        [
            ("cmp-001", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 375000.0, 355000.0, 5.63, 52000.0),
            ("cmp-002", "INSTORE", "POST", date(2023, 1, 1), date(2023, 1, 28), 412000.0, 388000.0, 6.19, 58000.0),
            ("cmp-003", "INSTORE", "DURING", date(2023, 5, 1), date(2023, 5, 28), 442000.0, 418000.0, 5.74, 60000.0),
            ("cmp-004", "OFFSITE", "POST", date(2023, 7, 1), date(2023, 7, 28), 458000.0, 432000.0, 6.02, 64000.0),
        ],
        schema=schema,
    )

    # Act: filter the data by period column for both DURING and POST periods.
    period_filter_during = CampaignDurations.CAMPAIGN_DURATION_DURING.upper()
    filtered_during = legacy_data.filter(F.col("period") == period_filter_during)

    period_filter_post = CampaignDurations.CAMPAIGN_DURATION_POST.upper()
    filtered_post = legacy_data.filter(F.col("period") == period_filter_post)

    # Assert: verify DURING and POST records match expected dataframes using chispa comparison.
    expected_during = spark_session.createDataFrame(
        [
            ("cmp-001", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 375000.0, 355000.0, 5.63, 52000.0),
            ("cmp-003", "INSTORE", "DURING", date(2023, 5, 1), date(2023, 5, 28), 442000.0, 418000.0, 5.74, 60000.0),
        ],
        schema=schema,
    )
    expected_post = spark_session.createDataFrame(
        [
            ("cmp-002", "INSTORE", "POST", date(2023, 1, 1), date(2023, 1, 28), 412000.0, 388000.0, 6.19, 58000.0),
            ("cmp-004", "OFFSITE", "POST", date(2023, 7, 1), date(2023, 7, 28), 458000.0, 432000.0, 6.02, 64000.0),
        ],
        schema=schema,
    )

    assert_df_equality(
        filtered_during.orderBy("campaign_id"),
        expected_during.orderBy("campaign_id"),
        ignore_nullable=True,
    )
    assert_df_equality(
        filtered_post.orderBy("campaign_id"),
        expected_post.orderBy("campaign_id"),
        ignore_nullable=True,
    )


def test_legacy_campaign_marketing_type_normalization(spark_session: SparkSession):
    """
    Test that marketing_type is correctly normalized from campaign_source.
    Normalization should:
    - Convert to uppercase
    - Remove spaces and special characters
    This ensures consistent grouping across legacy and current campaigns.
    """
    # Arrange: create legacy data with different case and spacing variations for INSTORE and OFFSITE channels.
    input_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_source", T.StringType(), True),
        T.StructField("period", T.StringType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("test", T.DoubleType(), True),
        T.StructField("control", T.DoubleType(), True),
        T.StructField("media_cost", T.DoubleType(), True),
    ])
    expected_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_source", T.StringType(), True),
        T.StructField("period", T.StringType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("test", T.DoubleType(), True),
        T.StructField("control", T.DoubleType(), True),
        T.StructField("media_cost", T.DoubleType(), True),
        T.StructField("marketing_type", T.StringType(), True),
    ])
    legacy_data = spark_session.createDataFrame(
        [
            ("cmp-001", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 375000.0, 355000.0, 52000.0),
            ("cmp-002", "In-Store", "DURING", date(2023, 1, 1), date(2023, 1, 28), 412000.0, 388000.0, 58000.0),
            ("cmp-003", "in store", "DURING", date(2023, 5, 1), date(2023, 5, 28), 442000.0, 418000.0, 60000.0),
            ("cmp-004", "Off-Site", "DURING", date(2023, 7, 1), date(2023, 7, 28), 458000.0, 432000.0, 64000.0),
            ("cmp-005", "offsite", "DURING", date(2023, 7, 1), date(2023, 7, 28), 458000.0, 432000.0, 64000.0),
        ],
        schema=input_schema,
    )

    # Act: apply marketing type normalization function to campaign_source column.
    actual = legacy_data.withColumn(
        "marketing_type",
        normalise_marketing_type(F.col("campaign_source")),
    )

    # Assert: all channel variants normalize to the expected values using chispa dataframe comparison.
    expected = spark_session.createDataFrame(
        [
            ("cmp-001", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 375000.0, 355000.0, 52000.0, "INSTORE"),
            ("cmp-002", "In-Store", "DURING", date(2023, 1, 1), date(2023, 1, 28), 412000.0, 388000.0, 58000.0, "INSTORE"),
            ("cmp-003", "in store", "DURING", date(2023, 5, 1), date(2023, 5, 28), 442000.0, 418000.0, 60000.0, "INSTORE"),
            ("cmp-004", "Off-Site", "DURING", date(2023, 7, 1), date(2023, 7, 28), 458000.0, 432000.0, 64000.0, "OFFSITE"),
            ("cmp-005", "offsite", "DURING", date(2023, 7, 1), date(2023, 7, 28), 458000.0, 432000.0, 64000.0, "OFFSITE"),
        ],
        schema=expected_schema,
    )

    assert_df_equality(
        actual.orderBy("campaign_id"),
        expected.orderBy("campaign_id"),
        ignore_nullable=True,
    )


def test_legacy_campaign_allowed_sources_filtering(spark_session: SparkSession):
    """
    Test that only campaigns from allowed_sources are retained.
    This ensures we only use relevant marketing channels for calibration.
    """
    # Arrange: create legacy data with allowed channels (INSTORE, OFFSITE) and disallowed channels (UNKNOWN_CHANNEL, DIGITAL).
    input_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_source", T.StringType(), True),
        T.StructField("period", T.StringType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("test", T.DoubleType(), True),
        T.StructField("control", T.DoubleType(), True),
        T.StructField("media_cost", T.DoubleType(), True),
    ])
    expected_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_source", T.StringType(), True),
        T.StructField("period", T.StringType(), True),
        T.StructField("campaign_start_date", T.DateType(), True),
        T.StructField("campaign_end_date", T.DateType(), True),
        T.StructField("test", T.DoubleType(), True),
        T.StructField("control", T.DoubleType(), True),
        T.StructField("media_cost", T.DoubleType(), True),
        T.StructField("marketing_type", T.StringType(), True),
    ])
    legacy_data = spark_session.createDataFrame(
        [
            ("cmp-001", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 375000.0, 355000.0, 52000.0),
            ("cmp-002", "OFFSITE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 412000.0, 388000.0, 58000.0),
            ("cmp-003", "UNKNOWN_CHANNEL", "DURING", date(2023, 5, 1), date(2023, 5, 28), 442000.0, 418000.0, 60000.0),
            ("cmp-004", "DIGITAL", "DURING", date(2023, 7, 1), date(2023, 7, 28), 458000.0, 432000.0, 64000.0),
        ],
        schema=input_schema,
    )

    # Act: normalize marketing_type and filter by allowed sources list.
    allowed_sources = BaselineModellingShrinkageConfig().allowed_sources_by_duration[
        CampaignDurations.CAMPAIGN_DURATION_DURING
    ]
    actual = (
        legacy_data
        .withColumn("marketing_type", normalise_marketing_type(F.col("campaign_source")))
        .filter(F.col("marketing_type").isin(allowed_sources))
    )

    # Assert: only allowed channels (INSTORE, OFFSITE) are retained using chispa dataframe comparison.
    expected = spark_session.createDataFrame(
        [
            ("cmp-001", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 375000.0, 355000.0, 52000.0, "INSTORE"),
            ("cmp-002", "OFFSITE", "DURING", date(2023, 1, 1), date(2023, 1, 28), 412000.0, 388000.0, 58000.0, "OFFSITE"),
        ],
        schema=expected_schema,
    )

    assert_df_equality(
        actual.orderBy("campaign_id"),
        expected.orderBy("campaign_id"),
        ignore_nullable=True,
    )


def test_legacy_campaign_complete_transformation_pipeline(spark_session: SparkSession):
    """
    Integration test that combines all transformation steps:
    1. Filter by PERIOD
    2. Normalize marketing_type
    3. Filter by allowed_sources
    4. Calculate IROAS

    This mirrors the actual code in prepare_incremental_shrinkage.
    """
    # Arrange: create legacy data with mixed PERIOD, marketing_type variants, allowed/disallowed channels, and varying media costs.
    input_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_source", T.StringType(), True),
        T.StructField("period", T.StringType(), True),
        T.StructField("test", T.DoubleType(), True),
        T.StructField("control", T.DoubleType(), True),
        T.StructField("media_cost", T.DoubleType(), True),
    ])
    expected_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_source", T.StringType(), True),
        T.StructField("period", T.StringType(), True),
        T.StructField("test", T.DoubleType(), True),
        T.StructField("control", T.DoubleType(), True),
        T.StructField("media_cost", T.DoubleType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("iroas", T.DoubleType(), True),
    ])
    legacy_data = spark_session.createDataFrame(
        [
            # cmp-001: DURING + allowed (In-Store→INSTORE), cmp-002: DURING + allowed (OFFSITE)
            # cmp-003: DURING but DIGITAL not allowed, cmp-004: POST period excluded
            ("cmp-001", "In-Store", "DURING", 375000.0, 355000.0, 52000.0),
            ("cmp-002", "OFFSITE", "DURING", 412000.0, 388000.0, 58000.0),
            ("cmp-003", "DIGITAL", "DURING", 442000.0, 418000.0, 60000.0),
            ("cmp-004", "INSTORE", "POST", 458000.0, 432000.0, 64000.0),
        ],
        schema=input_schema,
    )
    period_filter = CampaignDurations.CAMPAIGN_DURATION_DURING.upper()
    allowed_sources = BaselineModellingShrinkageConfig().allowed_sources_by_duration[
        CampaignDurations.CAMPAIGN_DURATION_DURING
    ]

    # Act: execute complete transformation pipeline including period filtering, normalization, allowed sources filtering, and IROAS calculation.
    actual = (
        legacy_data
        .filter(F.col("period") == period_filter)
        .withColumn("marketing_type", normalise_marketing_type(F.col("campaign_source")))
        .filter(F.col("marketing_type").isin(allowed_sources))
        .withColumn(
            "iroas",
            F.when(
                F.col("media_cost") != 0,
                (F.col("test") - F.col("control")) / F.col("media_cost"),
            ),
        )
    )

    # Assert: pipeline output (cmp-001 INSTORE, cmp-002 OFFSITE; cmp-003 DIGITAL and cmp-004 POST excluded)
    # using chispa approximate dataframe comparison.
    expected = spark_session.createDataFrame(
        [
            ("cmp-001", "In-Store", "DURING", 375000.0, 355000.0, 52000.0, "INSTORE", 0.38461538461538464),
            ("cmp-002", "OFFSITE", "DURING", 412000.0, 388000.0, 58000.0, "OFFSITE", 0.41379310344827586),
        ],
        schema=expected_schema,
    )

    assert_approx_df_equality(
        actual.orderBy("campaign_id"),
        expected.orderBy("campaign_id"),
        precision=0.001,
        ignore_nullable=True,
    )


def test_entrypoint_argument_parsing_and_invocation(spark_session: SparkSession):
    """Test CLI argument parsing and function invocation through entrypoint."""
    # Arrange: prepare CLI-style arguments matching the entrypoint contract
    args = [
        "--baseline-output-path", "s3://bucket/baseline-output",
        "--avg-weekly-spend-data-path", "s3://bucket/weekly-spend",
        "--measurement-legacy-campaign-performance", "s3://bucket/legacy-campaigns",
        "--campaign-selection-path", "s3://bucket/campaign-selection",
        "--brand-data-path", "s3://bucket/unified-products",
        "--output-path", "s3://bucket/output",
        "--output-path-audit", "s3://bucket/output-audit",
        "--campaign-duration", CampaignDurations.CAMPAIGN_DURATION_DURING,
        "--run-date", "2024-06-01",
        "--correlation-id", "test-entrypoint-correlation",
        "--previous-measurement-campaign-reporting", "s3://bucket/previous-reporting",
        "--ucm-base-data", "s3://bucket/ucm-base",
    ]

    # Act: call entrypoint with mocked prepare_incremental_shrinkage function
    with mock.patch(
        "spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage.prepare_incremental_shrinkage"
    ) as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: verify the orchestration function was called with correct parsed arguments
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        baseline_output_path="s3://bucket/baseline-output",
        avg_weekly_spend_data_path="s3://bucket/weekly-spend",
        measurement_legacy_campaign_performance="s3://bucket/legacy-campaigns",
        campaign_selection_path="s3://bucket/campaign-selection",
        brand_data_path="s3://bucket/unified-products",
        output_path="s3://bucket/output",
        output_path_audit="s3://bucket/output-audit",
        campaign_duration=CampaignDurations.CAMPAIGN_DURATION_DURING,
        run_date="2024-06-01",
        correlation_id="test-entrypoint-correlation",
        previous_measurement_campaign_reporting="s3://bucket/previous-reporting",
        ucm_base_data="s3://bucket/ucm-base",
    )


# fmt: off
@pytest.fixture
def get_mock_data():
    mock_data = {}
    mock_data["data"] = {}
    mock_data["schema"] = {}

    mock_data["schema"]["measurement_legacy_campaign_performance"] = BaselineModellingShrinkage.legacy_campaign_performance

    # Columns: campaign_id, campaign_source, campaign_start_date, campaign_end_date, super_category_name,
    #          sub_category_name_list, unique_brand_name_list, test, control, uplift, media_cost,
    #          num_unique_subcats, num_unique_brands
    mock_data["data"]["measurement_legacy_campaign_performance"] = [
        # Snacks / Crisps — single brand/subcat campaigns
        ("cmp-001", "INSTORE", "DURING", date(2023, 1, 1), date(2023, 1, 28), "CRISPS & SNACKS", "CRISPS", "WALKERS", 375000.0, 355000.0, 5.63, 52000.0, 1, 1, False),
        ("cmp-002", "INSTORE", "DURING", date(2023, 3, 1), date(2023, 3, 28), "CRISPS & SNACKS", "CRISPS", "PRINGLES", 412000.0, 388000.0, 6.19, 58000.0, 1, 1, False),
        ("cmp-003", "INSTORE", "DURING", date(2023, 5, 1), date(2023, 5, 28), "CRISPS & SNACKS", "CRISPS", "MCCOY'S", 442000.0, 418000.0, 5.74, 60000.0, 1, 1, False),
        ("cmp-004", "INSTORE", "DURING", date(2023, 7, 1), date(2023, 7, 28), "CRISPS & SNACKS", "CRISPS", "TYRRELLS", 458000.0, 432000.0, 6.02, 64000.0, 1, 1, False),
        # Multi-brand, single subcat (Crisps portfolio campaign)
        ("cmp-005", "INSTORE", "DURING", date(2023, 9, 1), date(2023, 9, 28), "CRISPS & SNACKS", "CRISPS", "WALKERS, LAY'S", 474000.0, 446000.0, 6.28, 68000.0, 1, 2, True),
        # Multi-subcat, multi-brand (cross-category snacks campaign)
        ("cmp-006", "INSTORE", "DURING", date(2023, 11, 1), date(2023, 11, 28), "CRISPS & SNACKS", "CRISPS, POPCORN", "LAY'S, BUTTERKIST", 500000.0, 470000.0, 6.38, 72000.0, 2, 2, True),
        ("cmp-007", "INSTORE", "DURING", date(2024, 1, 1), date(2024, 1, 28), "CRISPS & SNACKS", "CRISPS", "DORITOS", 548000.0, 512000.0, 7.03, 80000.0, 1, 1, False),
        # Snacks / Popcorn — single brand/subcat campaigns
        ("cmp-008", "OFFSITE", "DURING", date(2023, 1, 15), date(2023, 2, 11), "CRISPS & SNACKS", "POPCORN", "PROPERCORN", 386000.0, 364000.0, 6.04, 54000.0, 1, 1, False),
        ("cmp-009", "OFFSITE", "DURING", date(2023, 3, 15), date(2023, 4, 11), "CRISPS & SNACKS", "POPCORN", "METCALFE'S", 422000.0, 398000.0, 6.03, 58000.0, 1, 1, False),
        ("cmp-010", "OFFSITE", "DURING", date(2023, 5, 15), date(2023, 6, 11), "CRISPS & SNACKS", "POPCORN", "JOE & SEPH'S", 448000.0, 422000.0, 6.16, 62000.0, 1, 1, False),
        # Multi-brand, single subcat (Popcorn portfolio campaign)
        ("cmp-011", "OFFSITE", "DURING", date(2023, 7, 15), date(2023, 8, 11), "CRISPS & SNACKS", "POPCORN", "PIPERS, SKINNYPOP", 463000.0, 437000.0, 5.95, 65000.0, 1, 2, True),
        ("cmp-012", "OFFSITE", "DURING", date(2023, 9, 15), date(2023, 10, 11), "CRISPS & SNACKS", "POPCORN", "BUTTERKIST", 484000.0, 456000.0, 6.14, 68000.0, 1, 1, False),
        ("cmp-013", "OFFSITE", "DURING", date(2023, 11, 15), date(2023, 12, 11), "CRISPS & SNACKS", "POPCORN", "SKINNYPOP", 512000.0, 478000.0, 7.11, 74000.0, 1, 1, False),
        # Multi-subcat, multi-brand (cross-category snacks campaign)
        ("cmp-014", "OFFSITE", "DURING", date(2024, 1, 15), date(2024, 2, 11), "CRISPS & SNACKS", "CRISPS, POPCORN", "DORITOS, PIPERS CORN", 558000.0, 522000.0, 6.90, 82000.0, 2, 2, True),
    ]

    mock_data["data"]["measurement_legacy_campaign_performance_post"] = [
        ("cmp-001", "INSTORE", "POST", date(2023, 1, 1), date(2023, 1, 28), "CRISPS & SNACKS", "CRISPS", "WALKERS", 375000.0, 355000.0, 5.63, 52000.0, 1, 1, False),
        ("cmp-002", "INSTORE", "POST", date(2023, 3, 1), date(2023, 3, 28), "CRISPS & SNACKS", "CRISPS", "PRINGLES", 412000.0, 388000.0, 6.19, 58000.0, 1, 1, False),
    ]

    mock_data["schema"]["baseline_output"] = BaselineModellingShrinkage.baseline_output_input

    mock_data["data"]["baseline_output"] = [
        (date(2026, 1, 2), "CRISPS & SNACKS", "WALKERS", "TOTAL_INCREMENTAL_AMT", 5250.0, "level_var:0.50 | cycle:True[26, 104]_set_2", "Y"),
        (date(2026, 1, 9), "CRISPS & SNACKS", "WALKERS", "TOTAL_INCREMENTAL_AMT", 5100.0, "level_var:0.50 | cycle:True[26, 104]_set_2", "Y"),
        (date(2026, 1, 16), "CRISPS & SNACKS", "WALKERS", "TOTAL_INCREMENTAL_AMT", 5400.0, "level_var:0.50 | cycle:True[26, 104]_set_2", "Y"),
        (date(2026, 1, 23), "CRISPS & SNACKS", "WALKERS", "TOTAL_INCREMENTAL_AMT", 5050.0, "level_var:0.50 | cycle:True[26, 104]_set_2", "Y"),
        (date(2026, 1, 2), "CRISPS & SNACKS", "WALKERS", "TOTAL_INCREMENTAL_AMT", 4000.0, "level_var:0.50 | cycle:True[26, 104]_set_2", "N"),
    ]

    mock_data["schema"]["avg_weekly_spend_data"] = BaselineModellingShrinkage.avg_weekly_spend

    # Columns: year, super_cat_cd, super_cat_name, sub_cat_cd, sub_cat_name, unique_brand_name,
    #          inflation_ratio, avg_weekly_spend, avg_weekly_spend_inf_adj
    # Years align with F.year("campaign_start_date") from legacy campaigns (2023/2024)
    # Plus 2026 for the current campaign_selection (WALKERS)
    mock_data["data"]["avg_weekly_spend_data"] = [
        # 2023 — CRISPS brands (matching legacy cmp-001 to cmp-005)
        (2023, "SN", "CRISPS & SNACKS", "CR", "CRISPS", "WALKERS", 1.02, 48000.0, 48960.0),
        (2023, "SN", "CRISPS & SNACKS", "CR", "CRISPS", "PRINGLES", 1.02, 54000.0, 55080.0),
        (2023, "SN", "CRISPS & SNACKS", "CR", "CRISPS", "MCCOY'S", 1.02, 50000.0, 51000.0),
        (2023, "SN", "CRISPS & SNACKS", "CR", "CRISPS", "TYRRELLS", 1.02, 52000.0, 53040.0),
        (2023, "SN", "CRISPS & SNACKS", "CR", "CRISPS", "LAY'S", 1.02, 46000.0, 46920.0),
        # 2023 — POPCORN brands (matching legacy cmp-008 to cmp-013)
        (2023, "SN", "CRISPS & SNACKS", "PC", "POPCORN", "PROPERCORN", 1.02, 40000.0, 40800.0),
        (2023, "SN", "CRISPS & SNACKS", "PC", "POPCORN", "METCALFE'S", 1.02, 38000.0, 38760.0),
        (2023, "SN", "CRISPS & SNACKS", "PC", "POPCORN", "JOE & SEPH'S", 1.02, 36000.0, 36720.0),
        (2023, "SN", "CRISPS & SNACKS", "PC", "POPCORN", "PIPERS", 1.02, 35000.0, 35700.0),
        (2023, "SN", "CRISPS & SNACKS", "PC", "POPCORN", "SKINNYPOP", 1.02, 37000.0, 37740.0),
        (2023, "SN", "CRISPS & SNACKS", "PC", "POPCORN", "BUTTERKIST", 1.02, 42000.0, 42840.0),
        # 2024 — matching legacy cmp-007 and cmp-014
        (2024, "SN", "CRISPS & SNACKS", "CR", "CRISPS", "DORITOS", 1.05, 75000.0, 78750.0),
        (2024, "SN", "CRISPS & SNACKS", "PC", "POPCORN", "PIPERS CORN", 1.05, 35000.0, 36750.0),
        # 2026 — matching current campaign_selection (WALKERS)
        (2026, "SN", "CRISPS & SNACKS", "CR", "CRISPS", "WALKERS", 1.08, 550000.0, 59400.0),
    ]

    legacy_rows = (
        mock_data["data"]["measurement_legacy_campaign_performance"]
        + mock_data["data"]["measurement_legacy_campaign_performance_post"]
    )
    weekly_spend_rows = mock_data["data"]["avg_weekly_spend_data"]

    def hierarchy_pairs(row):
        return zip(row[6].split(", "), row[7].split(", "))

    def item_for_campaign(row, hierarchy_index):
        item_id = f"CAMPAIGN-{row[0]}"
        return item_id if hierarchy_index == 0 else f"{item_id}-{hierarchy_index}"

    def item_for_spend(row):
        return f"SPEND-{row[0]}-{row[3]}-{row[5]}"

    # The new source emits one row per item. Preserve every legacy hierarchy pair
    # so multi-brand and multi-subcategory campaigns exercise the restored grain.
    def to_item_level_campaign_rows(rows):
        return [
            (
                row[0], item_for_campaign(row, hierarchy_index), row[1], row[2], row[3], row[4],
                row[8], row[9], row[10], row[11],
            )
            for row in rows
            for hierarchy_index, _ in enumerate(hierarchy_pairs(row))
        ]

    mock_data["data"]["measurement_legacy_campaign_performance"] = (
        to_item_level_campaign_rows(mock_data["data"]["measurement_legacy_campaign_performance"])
    )
    mock_data["data"]["measurement_legacy_campaign_performance_post"] = (
        to_item_level_campaign_rows(mock_data["data"]["measurement_legacy_campaign_performance_post"])
    )
    mock_data["data"]["avg_weekly_spend_data"] = [
        (item_for_spend(row), date(row[0], 1, 1), row[0], row[1], row[2], row[3], row[4], row[6], row[7], row[8])
        for row in weekly_spend_rows
    ]
    mock_data["schema"]["unified_products"] = BaselineModellingShrinkage.unified_products
    mock_data["data"]["unified_products"] = list({
        (
            item_for_campaign(row, hierarchy_index), row[5], sub_category_name,
            unique_brand_name,
        )
        for row in legacy_rows
        for hierarchy_index, (sub_category_name, unique_brand_name) in enumerate(hierarchy_pairs(row))
    } | {
        (item_for_spend(row), row[2], row[4], row[5])
        for row in weekly_spend_rows
    })

    mock_data["schema"]["campaign_selection"] = BaselineModellingShrinkage.campaign_selection_input

    mock_data["data"]["campaign_selection"] = [
        ("WALKERS", "CRISPS & SNACKS", "CRISPS", date(2026, 1, 1), date(2026, 1, 28), date(2026, 2, 28), 50000.0, "INSTORE", {"INSTORE": 50000.0}),
        ("WALKERS", "CRISPS & SNACKS", "CRISPS", date(2026, 1, 1), date(2026, 3, 28), date(2026, 4, 28), 20000.0, "OFFSITE", {"OFFSITE": 20000.0}),
    ]

    return mock_data

# fmt: on
