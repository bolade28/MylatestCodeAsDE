import os
from datetime import date

import pytest
from unittest.mock import Mock, MagicMock, patch
from pyspark.sql import Row, functions as F, types as T
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

from spark_pipeline.utils.pipeline_utils import (
    get_model_dates,
    load_parquet_dataset,
    safe_div,
    validate_pipeline_run_type,
    write_parquet_dataset, json_safe, collect_distinct_values
)


def test_safe_div_normal_division(spark_session):
    """Test safe_div with normal division."""
    df = spark_session.createDataFrame([(10.0, 2.0)], ["numerator", "denominator"])
    result = df.select(safe_div(F.col("numerator"), F.col("denominator")).alias("result"))

    assert result.first()["result"] == 5.0


def test_safe_div_zero_denominator(spark_session):
    """Test safe_div handles zero denominator."""
    df = spark_session.createDataFrame([(10.0, 0.0)], ["numerator", "denominator"])
    result = df.select(safe_div(F.col("numerator"), F.col("denominator")).alias("result"))

    assert result.first()["result"] == 0.0


def test_safe_div_null_numerator(spark_session):
    """Test safe_div handles null numerator."""
    df = spark_session.createDataFrame([(None, 2.0)], T.StructType([
        T.StructField("numerator", T.DoubleType()),
        T.StructField("denominator", T.DoubleType())
    ]))
    result = df.select(safe_div(F.col("numerator"), F.col("denominator")).alias("result"))

    assert result.first()["result"] == 0.0


def test_safe_div_null_denominator(spark_session):
    """Test safe_div handles null denominator."""
    df = spark_session.createDataFrame([(10.0, None)], T.StructType([
        T.StructField("numerator", T.DoubleType()),
        T.StructField("denominator", T.DoubleType())
    ]))
    result = df.select(safe_div(F.col("numerator"), F.col("denominator")).alias("result"))

    assert result.first()["result"] == 0.0


@pytest.mark.parametrize(
    "value, expected",
    [
        (date(2024, 1, 15), "2024-01-15"),
        (None, None),
        ("hello", "hello"),
        (123, 123),
    ],
)
def test_json_safe_returns_expected_value(value, expected):
    # Act
    result = json_safe(value)

    # Assert
    assert result == expected


@pytest.mark.parametrize(
    "rows, column_name, expected",
    [
        (
            [{"brand": "B"}, {"brand": "A"}, {"brand": "B"}, {"brand": None}],
            "brand",
            ["A", "B"],
        ),
        (
            [{"brand": None}, {"brand": None}],
            "brand",
            [],
        ),
        (
            [{"brand": "A"}, {"brand": "B"}],
            "missing_column",
            [],
        ),
        (
            [{"brand": "single"}],
            "brand",
            ["single"],
        ),
    ],
)
def test_collect_distinct_values_returns_sorted_non_null_values(
    spark_session,
    rows,
    column_name,
    expected,
):
    # Arrange
    df = spark_session.createDataFrame(
        rows,
        schema=StructType([
            StructField("brand", StringType(), True),
        ]),
    )

    # Act
    result = collect_distinct_values(df, column_name)

    # Assert
    assert result == expected


def test_weekly_dates_utils(spark_session):
    data = [
        Row(week_start_date="2023-07-10"), Row(week_start_date="2023-07-17"),
        Row(week_start_date="2023-07-24"), Row(week_start_date="2023-07-31"),
        Row(week_start_date="2023-08-07"), Row(week_start_date="2023-08-14"),
        Row(week_start_date="2023-08-21"), Row(week_start_date="2023-08-28"),
        Row(week_start_date="2023-09-04"), Row(week_start_date="2023-09-11"),
        Row(week_start_date="2023-09-18"), Row(week_start_date="2023-09-25"),
        Row(week_start_date="2023-10-02"), Row(week_start_date="2023-10-09"),
        Row(week_start_date="2023-10-16"), Row(week_start_date="2023-10-23"),
        Row(week_start_date="2023-10-30"), Row(week_start_date="2023-11-06"),
        Row(week_start_date="2023-11-13"), Row(week_start_date="2023-11-20"),
    ]

    df = spark_session.createDataFrame(data)

    min_date, max_date = get_model_dates(df)

    assert min_date == "2023-07-10"
    assert max_date == "2023-11-20"


class TestLoadParquetDataset:
    """Tests for load_parquet_dataset utility."""

    _schema = StructType([
        StructField("id", StringType(), True),
        StructField("value", IntegerType(), True),
        StructField("extra", StringType(), True),
    ])

    def _write(self, spark_session, tmp_path):
        data = [Row(id="a", value=1, extra="x"), Row(id="b", value=2, extra="y")]
        spark_session.createDataFrame(data, self._schema).write.mode("overwrite").parquet(tmp_path)
        return tmp_path

    def test_reads_all_columns_when_none_passed(self, spark_session, tmp_dir):
        path = self._write(spark_session, os.path.join(tmp_dir, "data.parquet"))
        notifier = Mock()
        df = load_parquet_dataset(spark_session, path, "test", notifier)
        assert set(df.columns) == {"id", "value", "extra"}
        assert df.count() == 2

    def test_selects_specified_columns(self, spark_session, tmp_dir):
        path = self._write(spark_session, os.path.join(tmp_dir, "data.parquet"))
        notifier = Mock()
        df = load_parquet_dataset(spark_session, path, "test", notifier, columns=["id", "value"])
        assert df.columns == ["id", "value"]
        assert df.count() == 2

    def test_raises_on_missing_columns(self, spark_session, tmp_dir):
        path = self._write(spark_session, os.path.join(tmp_dir, "data.parquet"))
        notifier = Mock()
        with pytest.raises(RuntimeError, match="missing_col"):
            load_parquet_dataset(spark_session, path, "test", notifier, columns=["id", "missing_col"])

    def test_fallback_schema_on_bad_path(self, spark_session, tmp_dir):
        notifier = Mock()
        fallback = StructType([StructField("id", StringType(), True)])
        df = load_parquet_dataset(
            spark_session, "/nonexistent/path", "test", notifier, fallback_schema=fallback
        )
        assert df.count() == 0
        assert df.columns == ["id"]
        notifier.send_data_loading_error.assert_not_called()

    def test_sends_slack_and_raises_without_fallback(self, spark_session):
        notifier = Mock()
        with pytest.raises(RuntimeError):
            load_parquet_dataset(spark_session, "/nonexistent/path", "test_ds", notifier)
        notifier.send_data_loading_error.assert_called_once()
        call_args = notifier.send_data_loading_error.call_args[0]
        assert "test_ds" in call_args[0]
        assert call_args[1] == "test_ds_loading"

    def test_normalises_column_casing_before_select(self, spark_session, tmp_dir):
        path = self._write(spark_session, os.path.join(tmp_dir, "data.parquet"))
        notifier = Mock()
        # Pass mixed-case column names that differ from the lowercased parquet columns
        df = load_parquet_dataset(spark_session, path, "test", notifier, columns=["ID", "Value"])
        assert df.columns == ["id", "value"]
        assert df.count() == 2


class TestValidatePipelineRunType:

    def test_accepts_pollen(self):
        assert validate_pipeline_run_type("Pollen") == "Pollen"

    def test_accepts_dtp(self):
        assert validate_pipeline_run_type("DTP") == "DTP"

    def test_raises_on_unknown_value(self):
        with pytest.raises(ValueError, match="Unknown pipeline_run_type 'invalid'"):
            validate_pipeline_run_type("invalid")

    def test_raises_on_empty_string(self):
        with pytest.raises(ValueError, match="Unknown pipeline_run_type ''"):
            validate_pipeline_run_type("")

    def test_raises_on_lowercase_pollen(self):
        # Values are case-sensitive — "pollen" is not the same as "Pollen"
        with pytest.raises(ValueError, match="Unknown pipeline_run_type 'pollen'"):
            validate_pipeline_run_type("pollen")

    def test_raises_on_lowercase_dtp(self):
        with pytest.raises(ValueError, match="Unknown pipeline_run_type 'dtp'"):
            validate_pipeline_run_type("dtp")


# Path to patch (IMPORTANT: patch where it's USED, not where it's defined)
_PATCH_PATH = "spark_pipeline.utils.pipeline_utils.spark_s3_overwrite"


@pytest.fixture
def df(spark_session):
    return spark_session.createDataFrame(
        [{"id": 1, "value": "test"}]
    )


@pytest.fixture
def slack_notifier():
    return MagicMock()


# ─────────────────────────────────────────────────────────────
# 1. Happy path
# ─────────────────────────────────────────────────────────────

def test_write_parquet_dataset_success(df, slack_notifier):
    with patch(_PATCH_PATH) as mock_write:
        write_parquet_dataset(
            df=df,
            path="s3://bucket/test-path",
            slack_notifier=slack_notifier,
        )

        # Assert write was called correctly
        mock_write.assert_called_once_with("s3://bucket/test-path", df)

        # Slack should NOT be called
        slack_notifier.send_data_loading_error.assert_not_called()


# ─────────────────────────────────────────────────────────────
# 2. Failure path — exception handling
# ─────────────────────────────────────────────────────────────

def test_write_parquet_dataset_failure_raises_runtime_error(df, slack_notifier):
    with patch(_PATCH_PATH, side_effect=Exception("S3 write failed")):
        with pytest.raises(RuntimeError) as exc_info:
            write_parquet_dataset(
                df=df,
                path="s3://bucket/test-path",
                slack_notifier=slack_notifier,
            )

        # Assert error message is wrapped correctly
        assert "Failed to write s3://bucket/test-path" in str(exc_info.value)
        assert "S3 write failed" in str(exc_info.value)


# ─────────────────────────────────────────────────────────────
# 3. Slack notification triggered on failure
# ─────────────────────────────────────────────────────────────

def test_write_parquet_dataset_failure_sends_slack_notification(df, slack_notifier):
    with patch(_PATCH_PATH, side_effect=Exception("boom")):
        with pytest.raises(RuntimeError):
            write_parquet_dataset(
                df=df,
                path="s3://bucket/test-path",
                slack_notifier=slack_notifier,
            )

        slack_notifier.send_data_loading_error.assert_called_once()

        args, kwargs = slack_notifier.send_data_loading_error.call_args

        # Validate message content
        assert "Failed to write s3://bucket/test-path" in args[0]
        assert args[1] == "s3://bucket/test-path_writing"


# ─────────────────────────────────────────────────────────────
# 4. Original exception is chained
# ─────────────────────────────────────────────────────────────

def test_write_parquet_dataset_exception_chaining(df, slack_notifier):
    original_exception = Exception("root cause")

    with patch(_PATCH_PATH, side_effect=original_exception):
        with pytest.raises(RuntimeError) as exc_info:
            write_parquet_dataset(
                df=df,
                path="s3://bucket/test-path",
                slack_notifier=slack_notifier,
            )

        # Ensure exception chaining is preserved
        assert exc_info.value.__cause__ is original_exception
