import boto3
from unittest.mock import Mock, patch
from moto import mock_aws
import pytest
from pyspark.sql import DataFrame

from spark_pipeline.utils.spark_s3_safe_write import spark_s3_overwrite


@pytest.fixture
def sample_df(spark_session):
    data = [
        ("A", 1),
        ("B", 2),
    ]
    return spark_session.createDataFrame(data, ["col1", "col2"])


@pytest.fixture(scope="function")
def aws_credentials():
    """Mocked AWS Credentials for moto."""
    import os
    os.environ["AWS_ACCESS_KEY_ID"] = "testing"
    os.environ["AWS_SECRET_ACCESS_KEY"] = "testing"
    os.environ["AWS_SECURITY_TOKEN"] = "testing"
    os.environ["AWS_SESSION_TOKEN"] = "testing"
    os.environ["AWS_DEFAULT_REGION"] = "us-east-1"


@pytest.fixture(scope="function")
def s3_client(aws_credentials):
    """Create a mocked S3 client using moto."""
    with mock_aws():
        yield boto3.client("s3", region_name="us-east-1")


@pytest.fixture
def mock_dataframe():
    """Creates a mocked PySpark DataFrame."""
    mock_df = Mock(spec=DataFrame)
    # Build the fluent API chain: df.write.mode().parquet()
    mock_write = Mock()
    mock_mode = Mock()
    mock_df.write = mock_write
    mock_write.mode.return_value = mock_mode
    # We will attach the mock for .parquet() in the tests as needed
    return mock_df


@pytest.fixture(scope="function")
def s3_bucket(s3_client):
    """Create a test S3 bucket."""
    bucket_name = "test-bucket"
    s3_client.create_bucket(Bucket=bucket_name)
    return bucket_name


def populate_s3_with_files(s3_client, bucket, prefix, num_files=5):
    """Helper function to populate S3 with test files."""
    keys = []
    for i in range(num_files):
        key = f"{prefix}part-{i:05d}.parquet"
        s3_client.put_object(
            Bucket=bucket,
            Key=key,
            Body=b"test data"
        )
        keys.append(key)
    return keys


def list_s3_objects(s3_client, bucket, prefix):
    """Helper function to list all objects under a prefix."""
    paginator = s3_client.get_paginator("list_objects_v2")
    keys = []
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        if "Contents" in page:
            keys.extend([obj["Key"] for obj in page["Contents"]])
    return keys

# --------------------------------------------------------------------
# Test 1: parse_s3_uri function
# --------------------------------------------------------------------

# @mock_aws
# @patch('spark_pipeline.utils.spark_s3_safe_write.s3')
# def test_parse_s3_uri_valid(mock_global_s3):


@mock_aws
def test_valid_s3_uri_with_trailing_slash(aws_credentials, s3_bucket, mock_dataframe):
    """Test successful execution with valid S3 URI ending in slash"""
    # Patch the module's s3 client to use moto
    with patch('spark_pipeline.utils.spark_s3_safe_write.s3', boto3.client("s3", region_name="us-east-1")):
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=s3_bucket)

        s3_uri = f"s3://{s3_bucket}/data/output/"
        spark_s3_overwrite(s3_uri, mock_dataframe)

        # Verify Spark write was called
        mock_dataframe.write.mode.assert_called_once_with("overwrite")
        mock_dataframe.write.mode.return_value.parquet.assert_called_once_with(s3_uri)


def test_parse_s3_uri_invalid_scheme():
    """Test parsing fails on non-S3 schemes."""
    mock_df = Mock(spec=DataFrame)
    with pytest.raises(ValueError) as context:
        spark_s3_overwrite("http://example.com/data", mock_df)
    assert "Invalid S3 URI" in str(context.value)

    with pytest.raises(ValueError) as context:
        spark_s3_overwrite("/local/path/to/file", mock_df)
    assert "Invalid S3 URI" in str(context.value)

# --------------------------------------------------------------------
# Test 2: delete_all_objects_in_s3_uri function (requires moto)
# --------------------------------------------------------------------


@mock_aws
@patch('spark_pipeline.utils.spark_s3_safe_write.s3')
def test_delete_all_objects_single_page(mock_global_s3):
    """
    Test deletion when all objects are in a single list_objects page.
    This test patches the global s3 client to ensure moto functionality is used.
    """

    # Create a fresh, moto-aware client instance to use for setup
    region_name = "eu-west-1"
    moto_s3_client = boto3.client("s3", region_name=region_name)
    bucket_name = "test-delete-bucket"
    prefix = "data/temp/"

    # Configure the global s3 mock to point to the moto-aware client
    # This ensures that when delete_all_objects_in_s3_uri uses the global
    # s3, it hits the mocked environment.
    mock_global_s3.get_paginator = moto_s3_client.get_paginator
    mock_global_s3.delete_objects = moto_s3_client.delete_objects

    moto_s3_client.create_bucket(
        Bucket=bucket_name,
        CreateBucketConfiguration={'LocationConstraint': region_name}
    )

    keys_to_delete = [
        f"{prefix}file1.txt",
        f"{prefix}file2.csv",
        f"{prefix}other/file3.parquet"
    ]

    for key in keys_to_delete:
        moto_s3_client.put_object(Bucket=bucket_name, Key=key, Body=b"test data")

    # Pre-check: Verify objects exist using the moto client
    assert len(moto_s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix).get("Contents", [])) == 3


@mock_aws
@patch('spark_pipeline.utils.spark_s3_safe_write.s3')
def test_safety_check_prevents_bucket_root_deletion(mock_s3, mock_dataframe):
    """Test that the function prevents deletion at the bucket root."""
    dangerous_uris = ["s3://my-bucket/", "s3://my-bucket"]
    for uri in dangerous_uris:
        with pytest.raises(ValueError, match="DANGER"):
            spark_s3_overwrite(uri, mock_dataframe)


def test_invalid_scheme_raises_error(mock_dataframe):
    """Test that non-S3 URIs raise ValueError"""
    invalid_uris = [
        "hdfs://bucket/path",
        "file:///local/path",
        "http://bucket/path",
        "gs://bucket/path",
        "/absolute/path"
    ]

    for uri in invalid_uris:
        with pytest.raises(ValueError, match="Invalid S3 URI"):
            spark_s3_overwrite(uri, mock_dataframe)


def test_bucket_root_without_prefix_raises_error(mock_dataframe):
    """Test that bucket root URIs are rejected for safety"""
    dangerous_uris = [
        "s3://my-bucket",
        "s3://my-bucket/",
    ]

    for uri in dangerous_uris:
        with pytest.raises(ValueError, match="DANGER.*entire bucket"):
            spark_s3_overwrite(uri, mock_dataframe)


@mock_aws
def test_deeply_nested_prefix(aws_credentials, s3_bucket, mock_dataframe):
    """Test handling of deeply nested S3 paths"""
    with patch('spark_pipeline.utils.spark_s3_safe_write.s3', boto3.client("s3", region_name="us-east-1")):
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=s3_bucket)

        s3_uri = f"s3://{s3_bucket}/level1/level2/level3/level4/data/"
        spark_s3_overwrite(s3_uri, mock_dataframe)

        mock_dataframe.write.mode.return_value.parquet.assert_called_once()


# =====================================================
# S3 Deletion Tests with Real Moto Operations
# =====================================================

@mock_aws
def test_delete_existing_objects(aws_credentials, s3_bucket, mock_dataframe):
    """Test deletion of existing objects in S3"""
    with patch('spark_pipeline.utils.spark_s3_safe_write.s3', boto3.client("s3", region_name="us-east-1")):
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=s3_bucket)

        prefix = "data/output/"
        # Create test files
        _ = populate_s3_with_files(s3, s3_bucket, prefix, num_files=5)

        # Verify files exist
        existing_keys = list_s3_objects(s3, s3_bucket, prefix)
        assert len(existing_keys) == 5

        # Run the overwrite function
        s3_uri = f"s3://{s3_bucket}/{prefix}"
        spark_s3_overwrite(s3_uri, mock_dataframe)

        # Verify all files were deleted
        remaining_keys = list_s3_objects(s3, s3_bucket, prefix)
        assert len(remaining_keys) == 0

        # Verify Spark write was called
        mock_dataframe.write.mode.return_value.parquet.assert_called_once()


@mock_aws
def test_delete_large_number_of_objects(aws_credentials, s3_bucket, mock_dataframe):
    """Test deletion of many objects (tests pagination)"""
    with patch('spark_pipeline.utils.spark_s3_safe_write.s3', boto3.client("s3", region_name="us-east-1")):
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=s3_bucket)

        prefix = "data/large/"
        # Create 150 files (more than typical page size)
        _ = populate_s3_with_files(s3, s3_bucket, prefix, num_files=150)

        # Verify files exist
        existing_keys = list_s3_objects(s3, s3_bucket, prefix)
        assert len(existing_keys) == 150

        # Run the overwrite function
        s3_uri = f"s3://{s3_bucket}/{prefix}"
        spark_s3_overwrite(s3_uri, mock_dataframe)

        # Verify all files were deleted
        remaining_keys = list_s3_objects(s3, s3_bucket, prefix)
        assert len(remaining_keys) == 0


@mock_aws
def test_no_objects_to_delete(aws_credentials, s3_bucket, mock_dataframe):
    """Test behavior when S3 prefix is empty"""
    with patch('spark_pipeline.utils.spark_s3_safe_write.s3', boto3.client("s3", region_name="us-east-1")):
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=s3_bucket)

        # Don't create any files
        s3_uri = f"s3://{s3_bucket}/empty-prefix/"
        spark_s3_overwrite(s3_uri, mock_dataframe)

        # Verify Spark write still happens
        mock_dataframe.write.mode.return_value.parquet.assert_called_once()


@mock_aws
def test_delete_only_files_under_prefix(aws_credentials, s3_bucket, mock_dataframe):
    """Test that only files under the specific prefix are deleted"""
    with patch('spark_pipeline.utils.spark_s3_safe_write.s3', boto3.client("s3", region_name="us-east-1")):
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=s3_bucket)

        # Create files in target prefix
        target_prefix = "data/target/"
        populate_s3_with_files(s3, s3_bucket, target_prefix, num_files=5)

        # Create files in other prefixes
        other_prefix = "data/other/"
        populate_s3_with_files(s3, s3_bucket, other_prefix, num_files=3)

        root_prefix = "different/"
        populate_s3_with_files(s3, s3_bucket, root_prefix, num_files=2)

        # Run overwrite on target prefix only
        s3_uri = f"s3://{s3_bucket}/{target_prefix}"
        spark_s3_overwrite(s3_uri, mock_dataframe)

        # Verify target files were deleted
        target_keys = list_s3_objects(s3, s3_bucket, target_prefix)
        assert len(target_keys) == 0

        # Verify other files remain
        other_keys = list_s3_objects(s3, s3_bucket, other_prefix)
        assert len(other_keys) == 3

        root_keys = list_s3_objects(s3, s3_bucket, root_prefix)
        assert len(root_keys) == 2


@mock_aws
def test_delete_nested_objects(aws_credentials, s3_bucket, mock_dataframe):
    """Test deletion of nested directory structures"""
    with patch('spark_pipeline.utils.spark_s3_safe_write.s3', boto3.client("s3", region_name="us-east-1")):
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=s3_bucket)

        # Create nested structure
        base_prefix = "data/partitioned/"
        nested_keys = [
            f"{base_prefix}year=2024/month=01/file1.parquet",
            f"{base_prefix}year=2024/month=01/file2.parquet",
            f"{base_prefix}year=2024/month=02/file1.parquet",
            f"{base_prefix}year=2024/month=02/file2.parquet",
            f"{base_prefix}_SUCCESS"
        ]

        for key in nested_keys:
            s3.put_object(Bucket=s3_bucket, Key=key, Body=b"data")

        # Verify files exist
        existing_keys = list_s3_objects(s3, s3_bucket, base_prefix)
        assert len(existing_keys) == 5

        # Run overwrite
        s3_uri = f"s3://{s3_bucket}/{base_prefix}"
        spark_s3_overwrite(s3_uri, mock_dataframe)

        # Verify all nested files were deleted
        remaining_keys = list_s3_objects(s3, s3_bucket, base_prefix)
        assert len(remaining_keys) == 0

# =====================================================
# URI Validation Tests
# =====================================================


@mock_aws
def test_valid_s3_uri_without_trailing_slash(aws_credentials, s3_bucket, mock_dataframe):
    """Test that trailing slash is added when missing"""
    with patch('spark_pipeline.utils.spark_s3_safe_write.s3', boto3.client("s3", region_name="us-east-1")):
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=s3_bucket)

        s3_uri = f"s3://{s3_bucket}/data/output"
        spark_s3_overwrite(s3_uri, mock_dataframe)

        mock_dataframe.write.mode.return_value.parquet.assert_called_once()


@mock_aws
def test_spark_write_error_after_deletion(aws_credentials, s3_bucket, mock_dataframe):
    """Test that S3 deletion completes even if Spark write fails"""
    with patch('spark_pipeline.utils.spark_s3_safe_write.s3', boto3.client("s3", region_name="us-east-1")):
        s3 = boto3.client("s3", region_name="us-east-1")
        s3.create_bucket(Bucket=s3_bucket)

        prefix = "data/output/"
        populate_s3_with_files(s3, s3_bucket, prefix, num_files=3)

        # Mock Spark write to fail
        mock_dataframe.write.mode.return_value.parquet.side_effect = Exception(
            "Spark write failed"
        )

        s3_uri = f"s3://{s3_bucket}/{prefix}"

        with pytest.raises(Exception, match="Spark write failed"):
            spark_s3_overwrite(s3_uri, mock_dataframe)

        # Verify files were still deleted before the error
        remaining_keys = list_s3_objects(s3, s3_bucket, prefix)
        assert len(remaining_keys) == 0
