import json
from unittest.mock import MagicMock

import boto3
import pytest
from mockito import when, unstub

from spark_pipeline.utils.slack_utils import SlackMessenger


@pytest.fixture(scope="function")
def stub_client():
    mock_client = MagicMock()
    when(boto3).client('sns', region_name='eu-west-1').thenReturn(mock_client)
    yield mock_client
    mock_client.reset_mock()
    unstub()


def test_with_all_params_sends_correct_message(stub_client):
    arn = "arn:134565"
    correlation_id = "correlation-id"
    text = "Hello this is some text"
    event_type = "A type of event"
    data = {"first": 100, "second": 34}

    courier = SlackMessenger(topic_arn=arn, correlation_id=correlation_id)
    courier.send_message(text=text, event_type=event_type, data=data)

    stub_client.publish.assert_called_once_with(
        Message=json.dumps({
            "default": json.dumps({
                "text": text,
                "eventType": event_type,
                "data": data,
                "correlation_id": correlation_id
            })
        }),
        MessageStructure='json',
        Subject='Slack Messenger event',
        TopicArn=arn
    )


def test_with_no_data_sends_correct_message(stub_client):
    arn = "arn:13460"
    correlation_id = "an id of some sort"
    text = "Another piece of text"
    event_type = "The type of event"

    courier = SlackMessenger(topic_arn=arn, correlation_id=correlation_id)
    courier.send_message(text=text, event_type=event_type)

    stub_client.publish.assert_called_once_with(
        Message=json.dumps({
            "default": json.dumps({
                "text": text,
                "eventType": event_type,
                "correlation_id": correlation_id
            })
        }),
        MessageStructure='json',
        Subject='Slack Messenger event',
        TopicArn=arn
    )


def test_with_no_correlation_id_sends_correct_message(stub_client):
    arn = "arn:13460"
    text = "Another piece of text"
    event_type = "The type of event"
    data = {"first": 145}

    courier = SlackMessenger(topic_arn=arn)
    courier.send_message(text=text, event_type=event_type, data=data)

    stub_client.publish.assert_called_once_with(
        Message=json.dumps({
            "default": json.dumps({
                "text": text,
                "eventType": event_type,
                "data": data
            })
        }),
        MessageStructure='json',
        Subject='Slack Messenger event',
        TopicArn=arn
    )


def test_with_no_text_sends_correct_message(stub_client):
    arn = "arn:12345"
    event_type = "The type of event"
    data = {"first": 145}
    correlation_id = "an id of some sort"

    courier = SlackMessenger(topic_arn=arn, correlation_id=correlation_id)
    courier.send_message(event_type=event_type, data=data)

    stub_client.publish.assert_called_once_with(
        Message=json.dumps({"default": json.dumps({
            "eventType": event_type,
            "data": data,
            "correlation_id": correlation_id,
        })}),
        MessageStructure='json',
        Subject='Slack Messenger event',
        TopicArn=arn
    )
