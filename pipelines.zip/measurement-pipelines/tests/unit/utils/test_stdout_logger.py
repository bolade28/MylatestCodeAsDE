import logging
import time
from datetime import timedelta
from time import perf_counter

import pytest
from mockito import when, unstub

from spark_pipeline.utils.stdout_logger import StdOutLogger


@pytest.mark.skip("This test is flaky, doesn't pass in CircleCI")
def test_warning_and_error_logs_works_as_expected(capsys):
    warning_message = "Oh dear, something happened and I must warn everyone!"
    logger = StdOutLogger()

    logger.warning(warning_message)

    captured = capsys.readouterr()

    assert "WARNING" in captured.out
    assert warning_message in captured.out

    assert captured.err == ""

    error_message = "This is an error"
    logger = StdOutLogger()

    logger.error(error_message)
    for output_stream in capsys.readouterr():
        assert "ERROR" in output_stream
        assert error_message in output_stream


def test_subtask_start_caches_start_time():
    logger = StdOutLogger()

    time_0 = perf_counter()
    logger.log_start_event("Test 1")
    time_1 = perf_counter()

    assert time_0 < logger.timings["Test 1"]
    assert time_1 > logger.timings["Test 1"]


@pytest.mark.skip("This test is flaky, doesn't pass in CircleCI")
def test_subtask_end_writes_time_for_function_correctly(caplog):
    subtask_name = "Test 2"
    seconds_to_complete = 23
    start_time = perf_counter()
    end_time = start_time + seconds_to_complete

    logger = StdOutLogger()
    logger.timings[subtask_name] = start_time

    with caplog.at_level(logging.INFO):
        when(time).perf_counter().thenReturn(end_time)
        logger.log_end_event(subtask_name)

    assert str(timedelta(seconds=seconds_to_complete)) in caplog.text


def test_multiple_loggers_work_independently(caplog):
    logger_1 = StdOutLogger()
    logger_2 = StdOutLogger()

    t_0 = perf_counter()
    logger_1.log_start_event("Task")
    t_1 = perf_counter()

    with caplog.at_level(logging.INFO):
        logger_2.log_start_event("Task")
        t_2 = perf_counter()

    assert "WARNING" not in caplog.text
    assert "start" in caplog.text

    assert t_0 < logger_1.timings["Task"] < t_1
    assert t_1 < logger_2.timings["Task"] < t_2


def test_warning_raised_if_same_task_started_twice(caplog):
    task_name = "A task"
    logger = StdOutLogger()

    logger.log_start_event(task_name)

    with caplog.at_level(logging.WARNING):
        logger.log_start_event(task_name)

    assert "WARNING" in caplog.text


def test_warning_raised_if_task_finished_before_starting(caplog):
    task_name = "A task"
    logger = StdOutLogger()

    with caplog.at_level(logging.WARNING):
        logger.log_end_event(task_name)

    assert "WARNING" in caplog.text


def teardown_function(function):
    unstub()
