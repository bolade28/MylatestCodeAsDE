from unittest import mock
from unittest.mock import Mock, patch

import pytest
from chispa.dataframe_comparer import assert_df_equality
from freezegun import freeze_time
from pyspark.sql import SparkSession

from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.schemas.sku_cluster_mapping import SkuClusterMapping
from spark_pipeline.sku_cluster_mapping.sku_cluster_mapping import (
    _parse_manual_campaign_list,
    entrypoint,
    get_brand_skus,
    run_assignment,
)


def _assert_spark_df_equal(actual_df, expected_df):
    assert_df_equality(
        actual_df,
        expected_df,
        ignore_nullable=True,
        ignore_row_order=True,
        ignore_column_order=False,
    )


def _create_sales_filter_df(spark_session: SparkSession, rows):
    return spark_session.createDataFrame(rows, schema=SkuClusterMapping.sales_data_input_schema)


@pytest.mark.parametrize(
    ("manual_run_flag", "manual_campaign_list", "expected"),
    [
        (True, "JB1, JB2 ,, JB3", ["JB1", "JB2", "JB3"]),
        (False, "JB1, JB2", None),
        (True, "", None),
        (True, None, None),
    ],
)
def test_parse_manual_campaign_list(manual_run_flag, manual_campaign_list, expected):
    assert _parse_manual_campaign_list(manual_run_flag, manual_campaign_list) == expected


def test_get_brand_skus_filters_to_selected_brand_product_type(spark_session: SparkSession):
    campaign_product_type_df = spark_session.createDataFrame(
        [
            ("campaign-1", "sku-1", "Brand", "BrandA", "SNACKS"),
            ("campaign-1", "sku-2", "Offer", "BrandA", "SNACKS"),
            ("campaign-1", "sku-3", "Brand", "BrandA", "SNACKS"),
            ("campaign-2", "sku-4", "Brand", "BrandA", "SNACKS"),
            ("campaign-3", "sku-5", "Brand", "BrandB", "SNACKS"),
        ],
        schema=SkuClusterMapping.campaign_product_type_schema,
    )
    unified_campaign_df = spark_session.createDataFrame(
        [
            ("JB1", "campaign-1"),
            ("JB2", "campaign-2"),
        ],
        schema=SkuClusterMapping.unified_campaign_input_schema,
    )
    selected_campaigns_df = spark_session.createDataFrame(
        [
            ("BrandA", "CRISPS & SNACKS", "SNACKS"),
        ],
        schema=SkuClusterMapping.campaign_selection_input_schema,
    )
    sales_filter_df = _create_sales_filter_df(
        spark_session,
        [
            ("sku-1",),
            ("sku-3",),
            ("sku-4",),
        ],
    )

    actual_df = get_brand_skus(
        campaign_product_type_df,
        unified_campaign_df,
        selected_campaigns_df,
        sales_filter_df,
    )

    expected_df = spark_session.createDataFrame(
        [
            ("JB1", "CRISPS & SNACKS", "SNACKS", "BrandA", "sku-1"),
            ("JB1", "CRISPS & SNACKS", "SNACKS", "BrandA", "sku-3"),
            ("JB2", "CRISPS & SNACKS", "SNACKS", "BrandA", "sku-4"),
        ],
        schema=SkuClusterMapping.brand_skus_schema,
    )

    _assert_spark_df_equal(actual_df, expected_df)


def test_get_brand_skus_with_manual_campaign_list(spark_session: SparkSession):
    campaign_product_type_df = spark_session.createDataFrame(
        [
            ("campaign-1", "sku-1", "Brand", "BrandA", "SNACKS"),
            ("campaign-2", "sku-2", "Brand", "BrandA", "DRINKS"),
        ],
        schema=SkuClusterMapping.campaign_product_type_schema,
    )
    unified_campaign_df = spark_session.createDataFrame(
        [("JB1", "campaign-1"), ("JB2", "campaign-2")],
        schema=SkuClusterMapping.unified_campaign_input_schema,
    )
    selected_campaigns_df = spark_session.createDataFrame(
        [
            ("BrandA", "WINE", "DRINKS"),
        ],
        schema=SkuClusterMapping.campaign_selection_input_schema,
    )
    sales_filter_df = _create_sales_filter_df(
        spark_session,
        [
            ("sku-1",),
            ("sku-2",),
        ],
    )

    actual_df = get_brand_skus(
        campaign_product_type_df,
        unified_campaign_df,
        selected_campaigns_df,
        sales_filter_df,
        manual_booking_list=["JB2"],
    )

    expected_df = spark_session.createDataFrame(
        [("JB2", "WINE", "DRINKS", "BrandA", "sku-2")],
        schema=SkuClusterMapping.brand_skus_schema,
    )

    _assert_spark_df_equal(actual_df, expected_df)


def test_get_brand_skus_returns_empty_when_no_rows_match_filters(spark_session: SparkSession):
    campaign_product_type_df = spark_session.createDataFrame(
        [("campaign-1", "sku-1", "Offer", "BrandA", "SNACKS")],
        schema=SkuClusterMapping.campaign_product_type_schema,
    )
    unified_campaign_df = spark_session.createDataFrame(
        [("JB1", "campaign-1")],
        schema=SkuClusterMapping.unified_campaign_input_schema,
    )
    selected_campaigns_df = spark_session.createDataFrame(
        [("BrandA", "CRISPS & SNACKS", "SNACKS")],
        schema=SkuClusterMapping.campaign_selection_input_schema,
    )
    sales_filter_df = _create_sales_filter_df(
        spark_session,
        [("sku-1",)],
    )

    actual_df = get_brand_skus(
        campaign_product_type_df,
        unified_campaign_df,
        selected_campaigns_df,
        sales_filter_df,
    )
    expected_df = spark_session.createDataFrame([], schema=SkuClusterMapping.brand_skus_schema)

    _assert_spark_df_equal(actual_df, expected_df)


def test_get_brand_skus_excludes_skus_without_sales(spark_session: SparkSession):
    campaign_product_type_df = spark_session.createDataFrame(
        [
            ("campaign-1", "sku-1", "Brand", "BrandA", "SNACKS"),
            ("campaign-1", "sku-2", "Brand", "BrandA", "SNACKS"),
        ],
        schema=SkuClusterMapping.campaign_product_type_schema,
    )
    unified_campaign_df = spark_session.createDataFrame(
        [("JB1", "campaign-1")],
        schema=SkuClusterMapping.unified_campaign_input_schema,
    )
    selected_campaigns_df = spark_session.createDataFrame(
        [("BrandA", "CRISPS & SNACKS", "SNACKS")],
        schema=SkuClusterMapping.campaign_selection_input_schema,
    )
    sales_filter_df = _create_sales_filter_df(
        spark_session,
        [("sku-1",)],
    )

    actual_df = get_brand_skus(
        campaign_product_type_df,
        unified_campaign_df,
        selected_campaigns_df,
        sales_filter_df,
    )

    expected_df = spark_session.createDataFrame(
        [("JB1", "CRISPS & SNACKS", "SNACKS", "BrandA", "sku-1")],
        schema=SkuClusterMapping.brand_skus_schema,
    )

    _assert_spark_df_equal(actual_df, expected_df)


def test_get_brand_skus_uses_campaign_brand_and_category(spark_session: SparkSession):
    campaign_product_type_df = spark_session.createDataFrame(
        [("campaign-1", "sku-1", "Brand", "BrandA", "SNACKS")],
        schema=SkuClusterMapping.campaign_product_type_schema,
    )
    unified_campaign_df = spark_session.createDataFrame(
        [("JB1", "campaign-1")],
        schema=SkuClusterMapping.unified_campaign_input_schema,
    )
    selected_campaigns_df = spark_session.createDataFrame(
        [("BrandA", "CRISPS & SNACKS", "SNACKS")],
        schema=SkuClusterMapping.campaign_selection_input_schema,
    )
    sales_filter_df = _create_sales_filter_df(spark_session, [("sku-1",)])

    actual_df = get_brand_skus(
        campaign_product_type_df,
        unified_campaign_df,
        selected_campaigns_df,
        sales_filter_df,
    )

    expected_df = spark_session.createDataFrame(
        [("JB1", "CRISPS & SNACKS", "SNACKS", "BrandA", "sku-1")],
        schema=SkuClusterMapping.brand_skus_schema,
    )

    _assert_spark_df_equal(actual_df, expected_df)


@freeze_time("2026-04-20 10:11:12")
def test_run_assignment_writes_expected_cluster_mapping(spark_session: SparkSession, tmp_path):
    campaign_selection_input_path = str(tmp_path / "campaign_selection")
    unified_campaign_input_path = str(tmp_path / "unified_campaign")
    campaign_product_type_input_path = str(tmp_path / "campaign_product_type")
    sales_data_input_path = str(tmp_path / "sales_data")
    final_output_path = str(tmp_path / "final_output")

    spark_session.createDataFrame(
        [("BrandA", "CatA", "SNACKS")],
        schema=SkuClusterMapping.campaign_selection_input_schema,
    ).write.mode("overwrite").parquet(campaign_selection_input_path)

    spark_session.createDataFrame(
        [("JB1", "campaign-1"), ("JB2", "campaign-2")],
        schema=SkuClusterMapping.unified_campaign_input_schema,
    ).write.mode("overwrite").parquet(unified_campaign_input_path)

    spark_session.createDataFrame(
        [
            ("campaign-1", "sku-1", "Brand", "BrandA", "SNACKS"),
            ("campaign-1", "sku-2", "Offer", "BrandA", "SNACKS"),
            ("campaign-2", "sku-3", "Brand", "BrandB", "SNACKS"),
        ],
        schema=SkuClusterMapping.campaign_product_type_input_schema,
    ).write.mode("overwrite").parquet(campaign_product_type_input_path)

    spark_session.createDataFrame(
        [("sku-1",), ("sku-999",)],
        schema=SkuClusterMapping.sales_data_input_schema,
    ).write.mode("overwrite").parquet(sales_data_input_path)

    with mock.patch('spark_pipeline.sku_cluster_mapping.sku_cluster_mapping.spark_s3_overwrite',
                    side_effect=lambda path, df: df.write.mode("overwrite").parquet(path)):
        run_assignment(
            spark=spark_session,
            correlation_id="corr-123",
            sales_data_input_path=sales_data_input_path,
            campaign_selection_input_path=campaign_selection_input_path,
            unified_campaign_input_path=unified_campaign_input_path,
            campaign_product_type_input_path=campaign_product_type_input_path,
            final_output_path=final_output_path,
        )

    actual_df = spark_session.read.parquet(final_output_path)
    expected_df = spark_session.createDataFrame(
        [
            (
                "JB1",
                "CatA",
                "SNACKS",
                "BrandA",
                "sku-1",
                BaselineProcessedData.sku_cluster_modelling_type,
                "corr-123",
                "2026-04-20 10:11:12",
            )
        ],
        schema=SkuClusterMapping.final_output_schema,
    )

    _assert_spark_df_equal(actual_df, expected_df)


@freeze_time("2026-04-20 10:11:12")
def test_run_assignment_writes_empty_output_when_manual_campaigns_do_not_match(
    spark_session: SparkSession,
    tmp_path,
):
    campaign_selection_input_path = str(tmp_path / "campaign_selection")
    unified_campaign_input_path = str(tmp_path / "unified_campaign")
    campaign_product_type_input_path = str(tmp_path / "campaign_product_type")
    sales_data_input_path = str(tmp_path / "sales_data")
    final_output_path = str(tmp_path / "final_output")

    spark_session.createDataFrame(
        [("BrandA", "CatA", "SNACKS")],
        schema=SkuClusterMapping.campaign_selection_input_schema,
    ).write.mode("overwrite").parquet(campaign_selection_input_path)

    spark_session.createDataFrame(
        [("JB1", "campaign-1")],
        schema=SkuClusterMapping.unified_campaign_input_schema,
    ).write.mode("overwrite").parquet(unified_campaign_input_path)

    spark_session.createDataFrame(
        [("campaign-1", "sku-1", "Brand", "BrandA", "SNACKS")],
        schema=SkuClusterMapping.campaign_product_type_input_schema,
    ).write.mode("overwrite").parquet(campaign_product_type_input_path)

    spark_session.createDataFrame(
        [("sku-1",)],
        schema=SkuClusterMapping.sales_data_input_schema,
    ).write.mode("overwrite").parquet(sales_data_input_path)

    with mock.patch('spark_pipeline.sku_cluster_mapping.sku_cluster_mapping.spark_s3_overwrite',
                    side_effect=lambda path, df: df.write.mode("overwrite").parquet(path)):
        run_assignment(
            spark=spark_session,
            correlation_id="corr-123",
            sales_data_input_path=sales_data_input_path,
            campaign_selection_input_path=campaign_selection_input_path,
            unified_campaign_input_path=unified_campaign_input_path,
            campaign_product_type_input_path=campaign_product_type_input_path,
            final_output_path=final_output_path,
            manual_run_flag=True,
            manual_campaign_list="JB999",
        )

    actual_df = spark_session.read.parquet(final_output_path)
    expected_df = spark_session.createDataFrame([], schema=SkuClusterMapping.final_output_schema)

    _assert_spark_df_equal(actual_df, expected_df)


def test_entrypoint_calls_run_assignment_with_parsed_arguments():
    mock_spark = Mock()
    args = [
        "--correlation-id", "corr-123",
        "--sales-data-input-path", "s3://sales-data",
        "--campaign-selection-input-path", "s3://campaign-selection",
        "--unified-campaign-path", "s3://unified-campaign",
        "--campaign-product-type-path", "s3://campaign-product-type",
        "--final-output-path", "s3://final-output",
        "--manual-run-flag", "true",
        "--manual-campaign-list", "JB1,JB2",
        "--slack-topic-arn", "arn:aws:sns:eu-west-1:123456789012:test",
    ]

    with patch("spark_pipeline.sku_cluster_mapping.sku_cluster_mapping.run_assignment") as mock_run_assignment:
        entrypoint(spark=mock_spark, command_line_args=args)

    mock_run_assignment.assert_called_once_with(
        mock_spark,
        "corr-123",
        "s3://sales-data",
        "s3://campaign-selection",
        "s3://unified-campaign",
        "s3://campaign-product-type",
        "s3://final-output",
        True,
        "JB1,JB2",
    )
