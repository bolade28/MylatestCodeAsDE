from unittest import mock
from spark_pipeline.common.variables import CampaignDurations
from spark_pipeline.sku_level_attribution.sku_level_attribution import (
    entrypoint,
    prepare_sku_level_attributed_sales_and_units,
)
from tests.unit.baseline_processed_data.utils import (
    local_spark_s3_overwrite
)


def _mock_selected_dataframe(*, first_row=None):
    dataframe = mock.MagicMock()
    dataframe.distinct.return_value = dataframe
    dataframe.select.return_value = dataframe
    if first_row is not None:
        dataframe.first.return_value = first_row
    return dataframe


def _mock_read_dataframe(*, selected_df=None):
    source_df = mock.MagicMock()
    selected_df = selected_df or _mock_selected_dataframe()
    source_df.select.return_value = selected_df
    return source_df, selected_df


def _base_args(product_type):
    return [
        "--measurement-campaign-execution-path", "measurement_campaign_execution",
        "--customer-data-collection-path", "customer_data_collection",
        "--attribution-model-results-level-path", f"attribution_model_results_{product_type}",
        "--sku-level-attributed-sales-and-units-offer-path", "sku_level_offer",
        "--output-path", "output_path",
        "--product-type", product_type,
        "--run-date", "2025-08-12",
        "--campaign-duration", "During",
        "--pipeline-run-type", "dtp",
        "--correlation-id", "corr-id",
        "--slack-topic-arn", "arn:slack",
    ]


@mock.patch(
    "spark_pipeline.sku_level_attribution.sku_level_attribution.F.to_date"
)
@mock.patch(
    "spark_pipeline.sku_level_attribution.sku_level_attribution.F.col"
)
@mock.patch(
    "spark_pipeline.sku_level_attribution.sku_level_attribution.calculate_sku_level_attribution"
)
def test_prepare_offer_reads_optional_inputs_and_writes_output(mock_model, mock_col, mock_to_date):
    spark = mock.MagicMock()
    event_dt_expr = mock.sentinel.event_dt_expr
    mock_col.return_value = mock.sentinel.event_ts_col
    mock_to_date.return_value.alias.return_value = event_dt_expr

    attribution_source_df, attribution_selected_df = _mock_read_dataframe()
    transaction_source_df, transaction_selected_df = _mock_read_dataframe()
    campaign_selected_df = _mock_selected_dataframe(first_row=(CampaignDurations.CAMPAIGN_DURATION_DURING,))
    campaign_source_df, _ = _mock_read_dataframe(selected_df=campaign_selected_df)
    hierarchy_source_df, hierarchy_selected_df = _mock_read_dataframe()
    reach_source_df, reach_selected_df = _mock_read_dataframe()
    attribution_pre_req_source_df, attribution_pre_req_selected_df = _mock_read_dataframe()

    parquet_map = {
        "attribution_model_results": attribution_source_df,
        "customer_data_collection": transaction_source_df,
        "measurement_campaign_execution": campaign_source_df,
        "marketing_channel_hierarchy": hierarchy_source_df,
        "reach_engagement": reach_source_df,
        "attribution_pre_req": attribution_pre_req_source_df,
    }
    spark.read.parquet.side_effect = lambda path: parquet_map[path]

    model_output_df = mock.MagicMock()
    model_output_df.count.return_value = 17
    model_output_df.write.mode.return_value = model_output_df.write
    mock_model.return_value = model_output_df

    with mock.patch(
        "spark_pipeline.sku_level_attribution.sku_level_attribution.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_sku_level_attributed_sales_and_units(
            spark=spark,
            measurement_campaign_execution_path="measurement_campaign_execution",
            customer_data_collection_path="customer_data_collection",
            attribution_model_results_level_path="attribution_model_results",
            sku_level_attributed_sales_and_units_offer_path="sku_level_offer",
            reach_engagement_path="reach_engagement",
            attribution_pre_requisite_offer_path="attribution_pre_req",
            output_path="output_path",
            product_type="offer",
            run_date="2025-08-12",
            campaign_duration="During",
            pipeline_run_type="dtp",
            correlation_id="corr-id",
            slack_topic_arn="arn:slack",
            previous_measurement_campaign_reporting="previous_reporting",
            measurement_marketing_channel_hierarchy_path="marketing_channel_hierarchy",
            subchannel_hierarchy_codes='{"meta": [1]}',
        )

        assert spark.read.parquet.call_args_list == [
            mock.call("attribution_model_results"),
            mock.call("customer_data_collection"),
            mock.call("measurement_campaign_execution"),
            mock.call("marketing_channel_hierarchy"),
            mock.call("reach_engagement"),
            mock.call("attribution_pre_req"),
        ]

    attribution_source_df.select.assert_called_once_with(
        "userjourney_id",
        "loyalty_id",
        "transaction_key",
        "booking_id",
        "customer_journey_type",
        "journey_type",
        "isconversion",
        "regression_variable",
        "normalized_weights",
        "campaign_id",
        "campaign_duration",
        "load_ts",
        "channel_name",
        "subchannel_name",
        "marketing_type",
    )
    transaction_source_df.select.assert_called_once_with(
        "booking_id",
        "campaign_id",
        "transaction_key",
        event_dt_expr,
        "event_name",
        "item_cd",
        "net_sales_amt",
        "units_qty",
        "subchannel_name",
        "product_type",
        "unique_brand_name",
    )
    campaign_source_df.select.assert_called_once_with(
        "booking_id",
        "campaign_duration",
        "campaign_start_dt",
        "campaign_end_dt",
        "channel_name",
        "subchannel_name",
        "campaign_id",
    )
    hierarchy_source_df.select.assert_called_once_with(
        "marketing_subchannel",
        "channel_type",
        "marketing_hierarchy_cd",
    )
    reach_source_df.select.assert_called_once_with(
        "campaign_id",
        "channel_name",
        "reach_cnt",
        "clicks_cnt",
        "impressions_cnt",
        "sales_amt",
        "conversions_cnt",
        "booking_id",
        "load_ts",
        "marketing_type",
        "subchannel_name",
        "media_spend_amt",
        "engagement_ctr_pct",
    )
    attribution_pre_req_source_df.select.assert_called_once_with(
        "loyalty_id",
        "channel_name",
        "subchannel_name",
        "event_ts",
        "event_name",
        "net_sales_amt",
        "journey_type",
        "transaction_key",
        "campaign_id",
        "booking_id",
        "position",
        "campaign_duration",
        "load_ts",
        "userjourney_id",
        "regression_variable",
        "customer_journey_type",
        "isconversion",
        "marketing_type",
    )

    mock_model.assert_called_once_with(
        spark=spark,
        attribution_data_df=attribution_selected_df,
        transaction_raw_df=transaction_selected_df,
        camp_execution_df=campaign_selected_df,
        product_type="offer",
        correlation_id="corr-id",
        slack_topic_arn="arn:slack",
        run_date="2025-08-12",
        campaign_duration="During",
        pipeline_run_type="dtp",
        reach_engagement_df=reach_selected_df,
        attribution_pre_req_df=attribution_pre_req_selected_df,
        channel_hierarchy_code_df=hierarchy_selected_df,
        subchannel_hierarchy_codes='{"meta": [1]}',
        measurement_campaign_reporting_df=None,
        sku_level_offer_df=None,
    )

    model_output_df.write.mode.assert_called_once_with("overwrite")
    model_output_df.write.parquet.assert_called_once_with("output_path")


@mock.patch(
    "spark_pipeline.sku_level_attribution.sku_level_attribution.F.to_date"
)
@mock.patch(
    "spark_pipeline.sku_level_attribution.sku_level_attribution.F.col"
)
@mock.patch(
    "spark_pipeline.sku_level_attribution.sku_level_attribution.calculate_sku_level_attribution"
)
def test_prepare_brand_loads_offer_and_previous_reporting_for_post_campaign(mock_model, mock_col, mock_to_date):
    spark = mock.MagicMock()
    event_dt_expr = mock.sentinel.event_dt_expr
    mock_col.return_value = mock.sentinel.event_ts_col
    mock_to_date.return_value.alias.return_value = event_dt_expr

    attribution_source_df, attribution_selected_df = _mock_read_dataframe()
    transaction_source_df, transaction_selected_df = _mock_read_dataframe()
    campaign_selected_df = _mock_selected_dataframe(first_row=(CampaignDurations.CAMPAIGN_DURATION_POST,))
    campaign_source_df, _ = _mock_read_dataframe(selected_df=campaign_selected_df)
    sku_offer_source_df, sku_offer_selected_df = _mock_read_dataframe()
    previous_reporting_source_df, previous_reporting_selected_df = _mock_read_dataframe()

    parquet_map = {
        "attribution_model_results": attribution_source_df,
        "customer_data_collection": transaction_source_df,
        "measurement_campaign_execution": campaign_source_df,
        "sku_level_offer": sku_offer_source_df,
        "previous_reporting": previous_reporting_source_df,
    }
    spark.read.parquet.side_effect = lambda path: parquet_map[path]

    model_output_df = mock.MagicMock()
    model_output_df.count.return_value = 9
    model_output_df.write.mode.return_value = model_output_df.write
    mock_model.return_value = model_output_df

    with mock.patch(
        "spark_pipeline.sku_level_attribution.sku_level_attribution.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_sku_level_attributed_sales_and_units(
            spark=spark,
            measurement_campaign_execution_path="measurement_campaign_execution",
            customer_data_collection_path="customer_data_collection",
            attribution_model_results_level_path="attribution_model_results",
            sku_level_attributed_sales_and_units_offer_path="sku_level_offer",
            reach_engagement_path=None,
            attribution_pre_requisite_offer_path=None,
            output_path="output_path",
            product_type="brand",
            run_date="2025-08-12",
            campaign_duration="Post",
            pipeline_run_type="dtp",
            correlation_id="corr-id",
            slack_topic_arn="arn:slack",
            previous_measurement_campaign_reporting="previous_reporting",
            measurement_marketing_channel_hierarchy_path=None,
            subchannel_hierarchy_codes=None,
        )

        assert spark.read.parquet.call_args_list == [
            mock.call("attribution_model_results"),
            mock.call("customer_data_collection"),
            mock.call("measurement_campaign_execution"),
            mock.call("sku_level_offer"),
            mock.call("previous_reporting"),
        ]

    transaction_source_df.select.assert_called_once_with(
        "booking_id",
        "campaign_id",
        "transaction_key",
        event_dt_expr,
        "event_name",
        "item_cd",
        "net_sales_amt",
        "units_qty",
        "subchannel_name",
        "product_type",
        "unique_brand_name",
    )

    sku_offer_source_df.select.assert_called_once_with(
        "campaign_id",
        "channel_name",
        "userjourney_id",
        "loyalty_id",
        "booking_id",
        "customer_journey_type",
        "journey_type",
        "isconversion",
        "normalized_weights",
        "campaign_duration",
        "event_dt",
        "item_cd",
        "net_sales_amt",
        "units_qty",
        "unique_brand_name",
        "week_start_dt",
        "regression_variable",
        "subchannel_name",
        "attributed_sales_amt",
        "attributed_units_qty",
        "attributed_recalibrated_sales_amt",
        "attributed_recalibrated_units_qty",
        "load_ts",
        "marketing_type",
        "recalibration_factor",
    )
    previous_reporting_source_df.select.assert_called_once_with(
        "campaign_id",
        "booking_id",
        "campaign_duration",
        "journey_type",
        "marketing_type",
        "channel_name",
        "subchannel_name",
        "sub_category_name",
        "attributed_recalibrated_sales_amt",
        "recalibration_factor",
        "job_bag_number",
        "modelling_weight",
        "load_ts",
    )

    mock_model.assert_called_once_with(
        spark=spark,
        attribution_data_df=attribution_selected_df,
        transaction_raw_df=transaction_selected_df,
        camp_execution_df=campaign_selected_df,
        product_type="brand",
        correlation_id="corr-id",
        slack_topic_arn="arn:slack",
        run_date="2025-08-12",
        campaign_duration="Post",
        pipeline_run_type="dtp",
        reach_engagement_df=None,
        attribution_pre_req_df=None,
        channel_hierarchy_code_df=None,
        subchannel_hierarchy_codes=None,
        measurement_campaign_reporting_df=previous_reporting_selected_df,
        sku_level_offer_df=sku_offer_selected_df,
    )

    model_output_df.write.parquet.assert_called_once_with("output_path")


@mock.patch(
    "spark_pipeline.sku_level_attribution.sku_level_attribution.prepare_sku_level_attributed_sales_and_units"
)
def test_entrypoint_passes_brand_defaults(mock_prepare):
    spark = mock.MagicMock()

    entrypoint(spark=spark, command_line_args=_base_args("brand"))

    mock_prepare.assert_called_once_with(
        spark=spark,
        measurement_campaign_execution_path="measurement_campaign_execution",
        customer_data_collection_path="customer_data_collection",
        attribution_model_results_level_path="attribution_model_results_brand",
        sku_level_attributed_sales_and_units_offer_path="sku_level_offer",
        reach_engagement_path=None,
        attribution_pre_requisite_offer_path=None,
        output_path="output_path",
        product_type="brand",
        run_date="2025-08-12",
        campaign_duration="During",
        pipeline_run_type="dtp",
        correlation_id="corr-id",
        slack_topic_arn="arn:slack",
        measurement_marketing_channel_hierarchy_path=None,
        subchannel_hierarchy_codes=None,
        previous_measurement_campaign_reporting=None,
    )


@mock.patch(
    "spark_pipeline.sku_level_attribution.sku_level_attribution.prepare_sku_level_attributed_sales_and_units"
)
def test_entrypoint_passes_offer_required_and_optional_arguments(mock_prepare):
    spark = mock.MagicMock()
    args = _base_args("offer") + [
        "--reach-engagement-path", "reach_engagement",
        "--attribution-pre-requisite-offer-path", "attribution_pre_req",
        "--measurement-marketing-channel-hierarchy-path", "marketing_channel_hierarchy",
        "--subchannel-hierarchy-codes", '{"meta": [1]}',
        "--previous-measurement-campaign-reporting", "previous_reporting",
    ]

    entrypoint(spark=spark, command_line_args=args)

    mock_prepare.assert_called_once_with(
        spark=spark,
        measurement_campaign_execution_path="measurement_campaign_execution",
        customer_data_collection_path="customer_data_collection",
        attribution_model_results_level_path="attribution_model_results_offer",
        sku_level_attributed_sales_and_units_offer_path="sku_level_offer",
        reach_engagement_path="reach_engagement",
        attribution_pre_requisite_offer_path="attribution_pre_req",
        output_path="output_path",
        product_type="offer",
        run_date="2025-08-12",
        campaign_duration="During",
        pipeline_run_type="dtp",
        correlation_id="corr-id",
        slack_topic_arn="arn:slack",
        measurement_marketing_channel_hierarchy_path="marketing_channel_hierarchy",
        subchannel_hierarchy_codes='{"meta": [1]}',
        previous_measurement_campaign_reporting="previous_reporting",
    )


@mock.patch(
    "spark_pipeline.sku_level_attribution.sku_level_attribution.prepare_sku_level_attributed_sales_and_units"
)
def test_entrypoint_offer_without_optional_args_passes_none(mock_prepare):
    spark = mock.MagicMock()

    entrypoint(spark=spark, command_line_args=_base_args("offer"))

    mock_prepare.assert_called_once_with(
        spark=spark,
        measurement_campaign_execution_path="measurement_campaign_execution",
        customer_data_collection_path="customer_data_collection",
        attribution_model_results_level_path="attribution_model_results_offer",
        sku_level_attributed_sales_and_units_offer_path="sku_level_offer",
        reach_engagement_path=None,
        attribution_pre_requisite_offer_path=None,
        output_path="output_path",
        product_type="offer",
        run_date="2025-08-12",
        campaign_duration="During",
        pipeline_run_type="dtp",
        correlation_id="corr-id",
        slack_topic_arn="arn:slack",
        measurement_marketing_channel_hierarchy_path=None,
        subchannel_hierarchy_codes=None,
        previous_measurement_campaign_reporting=None,
    )
