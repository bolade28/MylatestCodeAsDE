import os
import json
from datetime import datetime, date
from unittest import mock
from pyspark import Row
from pyspark.sql import functions as F
from chispa import assert_df_equality
import pytest

from spark_pipeline.common.variables import META_AA_EFFECTIVE_DATE, PipelineRunType, CampaignDurations
from spark_pipeline.sku_level_attribution.sku_level_attribution_helper import (
    _build_meta_booking_eligibility,
    get_campaign_start_end_date,
    build_transaction_payload,
    build_sku_level_results,
    _setup_offsite_recalibrated,
    _compute_average_factor_recalibrated,
    _apply_recalibration_columns,
    _compute_offsite_factor_adjustment,
    _apply_offsite_factor_logic,
    calculate_recalibrated_sales,
    calculate_aggregated_sales,
    deduplicate_keep_first_item_cd,
    load_campaign_reporting_during,
    apply_campaign_duration_identifier_flag,
    filter_transaction_to_sku,
    _apply_post_campaign_recalibration,
    _recalculate_post_offsite_amounts,
    _apply_meta_recalibration_for_pollen,
    _has_multiple_customer_journey_types,
    _apply_recalibration_factor_lookup,
    _build_multi_touch_recalibration_lookup,
    _build_single_touch_recalibration_lookup,
    apply_recalibration,
    add_offsite_channel_flag,
    get_subchannels_from_hierarchy,
    with_offsite_flag,
    process_offer_attribution_multi_campaign,
    calculate_sku_level_attribution,
)
from spark_pipeline.schemas.sku_level_attribution import SkuLevelAttributedSalesAndUnits


def test_get_campaign_start_end_date(spark_session):
    input_data = spark_session.createDataFrame([
        ("ch1", "b1", "During", "c1", "2023-10-03", "2023-10-05"),
        ("ch1", "b1", "During", "c1", "2023-10-04", "2023-10-06"),
        ("ch2", "b2", "Post", "c2", "2023-10-10", "2023-10-12"),
    ], ["channel_name", "booking_id", "campaign_duration", "campaign_id", "campaign_start_dt", "campaign_end_dt"])

    expected_df = spark_session.createDataFrame([
        ("2023-10-03", "2023-10-06", "ch1", "During", "b1", "c1", "2023-10-02", "2023-10-02"),
        ("2023-10-10", "2023-10-12", "ch2", "Post", "b2", "c2", "2023-10-09", "2023-10-09"),
    ], ["campaign_start_dt", "campaign_end_dt", "channel_name", "campaign_duration",
        "booking_id", "campaign_id", "campaign_week_start_date", "campaign_week_end_date"])

    actual_df = get_campaign_start_end_date(input_data)

    assert_df_equality(actual_df, expected_df, ignore_row_order=True)


def test_build_meta_booking_eligibility_uses_earliest_campaign_start(spark_session):
    campaign_execution_df = spark_session.createDataFrame([
        Row(
            booking_id='booking-1',
            campaign_id='instore-before-cutoff',
            channel_name='Barkers - Main Estate',
            subchannel_name='Barkers - Main Estate - Fully Branded',
            campaign_start_dt=date(2026, 7, 20),
        ),
        Row(
            booking_id='booking-1',
            campaign_id='meta-after-cutoff',
            channel_name='Social',
            subchannel_name='Social - Meta',
            campaign_start_dt=date(2026, 8, 12),
        ),
        Row(
            booking_id='booking-1',
            campaign_id='meta-later-campaign',
            channel_name='Social',
            subchannel_name='Social - Meta',
            campaign_start_dt=date(2026, 8, 20),
        ),
        Row(
            booking_id='booking-2',
            campaign_id='meta-before-cutoff',
            channel_name='Social',
            subchannel_name='Social - Meta',
            campaign_start_dt=date(2026, 7, 20),
        ),
        Row(
            booking_id='booking-2',
            campaign_id='youtube-after-cutoff',
            channel_name='YouTube',
            subchannel_name='YouTube - Invideo',
            campaign_start_dt=date(2026, 8, 12),
        ),
        Row(
            booking_id='booking-3',
            campaign_id='meta-on-cutoff',
            channel_name='Social',
            subchannel_name='Social - Meta',
            campaign_start_dt=META_AA_EFFECTIVE_DATE,
        ),
    ])

    hierarchy_df = spark_session.createDataFrame([
        Row(
            marketing_subchannel='Social - Meta',
            channel_type='offsite',
            marketing_hierarchy_cd=3009,
        ),
        Row(
            marketing_subchannel='Barkers - Main Estate - Fully Branded',
            channel_type='instore',
            marketing_hierarchy_cd=2011,
        ),
    ])

    actual_df = _build_meta_booking_eligibility(
        campaign_execution_df,
        hierarchy_df,
        json.dumps({'meta': [3009]}),
    )
    expected_df = spark_session.createDataFrame([
        Row(
            booking_id='booking-1',
            is_meta_aa_eligible=True,
        ),
        Row(
            booking_id='booking-2',
            is_meta_aa_eligible=False,
        ),
        Row(
            booking_id='booking-3',
            is_meta_aa_eligible=True,
        ),
    ])

    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_nullable=True)


def test_setup_offsite_recalibrated_normalizes_lookup_and_flags_rows(spark_session):
    sku_level_results = spark_session.createDataFrame([
        ("meta - social", 1),
        ("search", 2),
    ], ["subchannel_name", "value"])

    offsite_subchannel_df = spark_session.createDataFrame([
        ("META - SOCIAL",),
    ], ["offsite_key"])

    source_column, normalized_lookup, actual_df = _setup_offsite_recalibrated(
        sku_level_results,
        offsite_subchannel_df,
        is_dtp=False,
    )

    expected_df = spark_session.createDataFrame([
        ("meta - social", 1, True),
        ("search", 2, False),
    ], ["subchannel_name", "value", "is_offsite_channel"])

    assert source_column == 'subchannel_name'
    assert normalized_lookup.collect()[0]['offsite_key'] == 'meta - social'
    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_nullable=True)


def test_compute_average_factor_recalibrated_uses_only_offsite_channels_for_dtp(spark_session):
    factor_df = spark_session.createDataFrame([
        ("meta", "camp1", 0.2),
        ("youtube", "camp1", 0.4),
        ("search", "camp1", 0.9),
    ], ["channel_name", "campaign_id", "factor"])

    dtp_attr_join = spark_session.createDataFrame([
        ("camp1", 0.0, True),
    ], ["campaign_id", "factor", "is_offsite_channel"])

    offsite_subchannel_df = spark_session.createDataFrame([
        ("meta",),
        ("youtube",),
    ], ["offsite_key"])

    actual_df = _compute_average_factor_recalibrated(
        factor_df,
        dtp_attr_join,
        is_dtp=True,
        offsite_subchannel_df=offsite_subchannel_df,
    )

    rows = actual_df.collect()
    assert len(rows) == 1
    assert rows[0]["campaign_id"] == "camp1"
    assert rows[0]["avg_factor"] == pytest.approx(0.3)


def test_apply_recalibration_columns_only_updates_offsite_rows(spark_session):
    dtp_attr_join = spark_session.createDataFrame([
        (0.5, 100.0, 10.0, 0.2, True, "meta_offsite"),
        (0.5, 100.0, 10.0, 0.2, False, "search_google"),
    ], [
        'normalized_weights',
        'net_sales_amt',
        'units_qty',
        'factor',
        'is_offsite_channel',
        'regression_variable',
    ])

    actual_df = _apply_recalibration_columns(dtp_attr_join)

    expected_df = spark_session.createDataFrame([
        (50.0, 5.0, 10.0, 1.0, 1),
        (50.0, 5.0, 50.0, 5.0, 1),
    ], [
        'attributed_sales_amt',
        'attributed_units_qty',
        'attributed_recalibrated_sales_amt',
        'attributed_recalibrated_units_qty',
        'underscore_count',
    ])

    assert_df_equality(
        actual_df.select(*expected_df.columns).withColumn(
            'underscore_count', F.col('underscore_count').cast('long')
        ),
        expected_df,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_compute_offsite_factor_adjustment_selects_lowest_avg_factor(spark_session):
    dtp_attr_join = spark_session.createDataFrame([
        ("journey1", 0.6, True),
        ("journey1", 0.4, True),
        ("journey2", 0.9, False),
    ], ["userjourney_id", "avg_factor", "is_offsite_channel"])

    actual_df = _compute_offsite_factor_adjustment(dtp_attr_join)

    expected_df = spark_session.createDataFrame([
        ("journey1", 0.4),
    ], ["userjourney_id", "avg_factor_offsite"])

    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_nullable=True)


def test_apply_offsite_factor_logic_updates_na_offsite_rows_only(spark_session):
    dtp_attr_join = spark_session.createDataFrame([
        ("journey1", "na", "loyal1", "txn1", "book1", "Direct", "offer", True, "foo_offsite_bar", 0.5,
         "During", "meta", "social", "Offsite", date(2024, 1, 1), "sku1", 100.0, 10.0, "BrandA",
         "2024-01-01", 0.2, 50.0, 5.0, 30.0, 6.0, 1, True),
        ("journey2", "camp1", "loyal2", "txn2", "book1", "Direct", "offer", True, "foo_search_bar", 0.5,
         "During", "search", "search", "Onsite", date(2024, 1, 1), "sku2", 100.0, 10.0, "BrandB",
         "2024-01-01", 0.2, 50.0, 5.0, 30.0, 6.0, 1, False),
    ], [
        'userjourney_id', 'campaign_id', 'loyalty_id', 'transaction_key', 'booking_id', 'customer_journey_type',
        'journey_type', 'isconversion', 'regression_variable', 'normalized_weights', 'campaign_duration',
        'channel_name', 'subchannel_name', 'marketing_type', 'event_dt', 'item_cd', 'net_sales_amt',
        'units_qty', 'unique_brand_name', 'week_start_dt', 'factor', 'attributed_sales_amt',
        'attributed_units_qty', 'attributed_recalibrated_sales_amt', 'attributed_recalibrated_units_qty',
        'underscore_count', 'is_offsite_channel',
    ])

    distinct_avg = spark_session.createDataFrame([
        ("journey1", 2.0),
        ("journey2", 9.0),
    ], ["userjourney_id", "avg_factor_offsite"])

    actual_df = _apply_offsite_factor_logic(dtp_attr_join, distinct_avg)

    expected_df = spark_session.createDataFrame([
        ("journey1", 2.0, 45.0, 9.0),
        ("journey2", 0.2, 30.0, 6.0),
    ], ['userjourney_id', 'factor', 'attributed_recalibrated_sales_amt', 'attributed_recalibrated_units_qty'])

    assert_df_equality(
        actual_df.select(*expected_df.columns),
        expected_df,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_build_sku_level_results_and_transaction_payload(spark_session):
    attribution_df = spark_session.createDataFrame([
        ("u1", "l1", "t1", "b1", "Direct", "offer", True, "txn_meta", 0.5, "c1", "During", "2024-01-01", "meta", "Social", "Offsite"),
    ], [
        'userjourney_id', 'loyalty_id', 'transaction_key', 'booking_id', 'customer_journey_type',
        'journey_type', 'isconversion', 'regression_variable', 'normalized_weights', 'campaign_id',
        'campaign_duration', 'load_ts', 'channel_name', 'subchannel_name', 'marketing_type',
    ])

    transaction_df = spark_session.createDataFrame([
        ("t1", "c1", date(2024, 1, 15), "SKU001", 100.0, 5.0, "BrandA", "2024-01-15", date(2024, 1, 10), date(2024, 1, 20), "2024-01-08", "2024-01-15"),
    ], [
        'transaction_key', 'campaign_id', 'event_dt', 'item_cd', 'net_sales_amt', 'units_qty',
        'unique_brand_name', 'week_start_dt', 'campaign_start_dt', 'campaign_end_dt',
        'campaign_week_start_date', 'campaign_week_end_date',
    ])

    payload = build_transaction_payload(transaction_df, include_campaign_window=True)
    actual_df = build_sku_level_results(attribution_df, payload, include_campaign_window=True)

    assert actual_df.count() == 1
    assert 'campaign_week_start_date' in actual_df.columns
    assert 'campaign_week_end_date' in actual_df.columns


def test_calculate_recalibrated_sales(spark_session):
    factor_data = [
        ('meta', 'camp1', 0.16),
        ('google', 'camp1', 1.0),
    ]

    factor_df = spark_session.createDataFrame(factor_data, ['channel_name', 'campaign_id', 'factor'])

    sku_data = [
        ('journey1', 'loyal1', 'txn1', 'book1', 'Direct', 'offer', True, 'Meta_camp1', 0.5, 0.85, 'During', 'job1',
         datetime(2024, 1, 1), 'meta', 'NA', 'Offsite', 0.82, datetime(2024, 1, 15), 'SKU001', 100.0, 5,
         'BrandA', datetime(2024, 1, 15), datetime(2024, 1, 10), datetime(2024, 1, 20), 'camp1'),
        ('journey2', 'loyal2', 'txn2', 'book1', 'Direct', 'offer', True, 'Google_Search_camp1', 0.4, 0.95, 'During', 'job1',
         datetime(2024, 1, 1), 'google', 'Search', 'Onsite', 0.92, datetime(2024, 1, 18), 'SKU004', 300.0, 15,
         'BrandD', datetime(2024, 1, 15), datetime(2024, 1, 10), datetime(2024, 1, 20), 'camp1'),
    ]

    sku_level_results_df = spark_session.createDataFrame(sku_data, SkuLevelAttributedSalesAndUnits.sku_schema)

    offsite_subchannel_df = spark_session.createDataFrame([('meta',), ('google',)], ['offsite_key'])

    actual_df = calculate_recalibrated_sales(factor_df, sku_level_results_df, PipelineRunType.dtp_run_type, offsite_subchannel_df)

    expected_data = [
        ('camp1', 'journey1', 'loyal1', 'book1', 'meta', 0.16, 50.0, 2.5, 8.0, 0.4, 1),
        ('camp1', 'journey2', 'loyal2', 'book1', 'google', 1.0, 120.0, 6.0, 120.0, 6.0, 2),
    ]

    expected_df = spark_session.createDataFrame(expected_data, [
        'campaign_id', 'userjourney_id', 'loyalty_id', 'booking_id', 'channel_name', 'factor',
        'attributed_sales_amt', 'attributed_units_qty',
        'attributed_recalibrated_sales_amt', 'attributed_recalibrated_units_qty', 'underscore_count',
    ]).withColumn('underscore_count', F.col('underscore_count').cast('int'))

    actual_df = actual_df.select(
        'campaign_id', 'userjourney_id', 'loyalty_id', 'booking_id', 'channel_name', 'factor',
        'attributed_sales_amt', 'attributed_units_qty',
        'attributed_recalibrated_sales_amt', 'attributed_recalibrated_units_qty', 'underscore_count',
    )

    assert_df_equality(actual_df, expected_df, ignore_row_order=True)


def test_calculate_aggregated_sales(spark_session):
    dtp_sales_data = [
        ('book1', 'meta', 'camp1', 1000.0, 'During'),
        ('book1', 'youtube', 'camp1', 800.0, 'During'),
        ('book1', 'google', 'camp1', 600.0, 'During'),
        ('book2', 'dv360', 'camp2', 1200.0, 'Post'),
    ]

    dtp_sales_df = spark_session.createDataFrame(dtp_sales_data, [
        'booking_id', 'channel_name', 'campaign_id', 'sum_sales_amt', 'campaign_duration',
    ])

    attribution_data = [
        ('book1', 'meta', 'Social', 'Offsite', 'camp1', 0.5),
        ('book1', 'youtube', 'Video', 'Offsite', 'camp1', 0.3),
        ('book1', 'google', 'Search', 'Onsite', 'camp1', 0.2),
        ('book2', 'dv360', 'Display', 'Offsite', 'camp2', 0.8),
    ]

    attribution_df = spark_session.createDataFrame(attribution_data, [
        'booking_id', 'channel_name', 'subchannel_name', 'marketing_type', 'campaign_id', 'normalized_weights',
    ])

    campaign_metrics_data = [
        ('book1', 2400.0, 0),
        ('book2', 1200.0, 1),
    ]

    campaign_metrics = spark_session.createDataFrame(campaign_metrics_data, [
        'booking_id', 'total_sales', 'channel_overlap_proportion',
    ])

    offsite_subchannel_df = spark_session.createDataFrame([('meta',), ('youtube',), ('dv360',)], ['offsite_key'])

    actual_df = calculate_aggregated_sales(dtp_sales_df, attribution_df, campaign_metrics, PipelineRunType.dtp_run_type, offsite_subchannel_df)

    expected_data = [
        ('book1', 'google', 'camp1', 1.0),
        ('book1', 'meta', 'camp1', 0.8333333333333334),
        ('book1', 'youtube', 'camp1', 1.1111111111111112),
        ('book2', 'dv360', 'camp2', 1.0),
    ]

    expected_df = spark_session.createDataFrame(expected_data, [
        'booking_id', 'channel_name', 'campaign_id', 'factor',
    ])

    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_nullable=True)


def test_deduplicate_keep_first_item_cd(spark_session):
    input_data = [
        ("Knorr_01", "Social", "2024-01-01", "SKU_B", 10.0),
        ("Knorr_01", "Social", "2024-01-01", "SKU_A", 10.0),
        ("Knorr_02", "Social", "2024-01-01", "SKU_C", 20.0),
        ("Knorr_03", "Search", "2024-01-01", "SKU_D", 30.0),
        ("Knorr_03", "Search", "2024-01-01", "SKU_D", 30.0),
    ]

    expected_data = [
        ("Knorr_01", "Social", "2024-01-01", "SKU_A", 10.0),
        ("Knorr_02", "Social", "2024-01-01", "SKU_C", 20.0),
        ("Knorr_03", "Search", "2024-01-01", "SKU_D", 30.0),
    ]

    input_df = spark_session.createDataFrame(input_data, schema=SkuLevelAttributedSalesAndUnits.dedup_based_on_item_cd)
    expected_df = spark_session.createDataFrame(expected_data, schema=SkuLevelAttributedSalesAndUnits.dedup_based_on_item_cd)

    actual_df = deduplicate_keep_first_item_cd(input_df)

    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_nullable=True, ignore_column_order=True)


def test_load_campaign_reporting_during_filters_to_latest(spark_session, tmpdir):
    path = os.path.join(tmpdir, "camp_reporting.parquet")

    spark_session.createDataFrame([
        Row(campaign_id="c1", booking_id="b1", campaign_duration="During",
            journey_type="offer", marketing_type="Offsite", channel_name="meta",
            subchannel_name="Social", sub_category_name="sub1", recalibration_factor=0.8,
            job_bag_number="jb1", modelling_weight=0.5, load_ts=datetime(2024, 1, 1)),
        Row(campaign_id="c1", booking_id="b1", campaign_duration="During",
            journey_type="offer", marketing_type="Offsite", channel_name="meta",
            subchannel_name="Social", sub_category_name="sub1", recalibration_factor=0.8,
            job_bag_number="jb1", modelling_weight=0.5, load_ts=datetime(2024, 1, 2)),
        Row(campaign_id="c1", booking_id="b2", campaign_duration="During",
            journey_type="offer", marketing_type="Offsite", channel_name="meta",
            subchannel_name="Social", sub_category_name="sub1", recalibration_factor=0.8,
            job_bag_number="jb1", modelling_weight=0.5, load_ts=datetime(2024, 1, 1)),
    ]).write.mode("overwrite").parquet(path)

    camp_execution_df = spark_session.createDataFrame([
        Row(booking_id="b1", campaign_duration="During"),
    ])

    actual_df = load_campaign_reporting_during(
        spark_session.read.parquet(path),
        camp_execution_df,
    )

    assert actual_df.count() == 1
    assert actual_df.collect()[0]["load_ts"] == datetime(2024, 1, 2)


def test_load_campaign_reporting_during_raises_on_zero_modelling_weight(spark_session, tmpdir):
    path = os.path.join(tmpdir, "camp_reporting_zero.parquet")

    spark_session.createDataFrame([
        Row(campaign_id="c1", booking_id="b1", campaign_duration="During",
            journey_type="offer", marketing_type="Offsite", channel_name="meta",
            subchannel_name="Social", sub_category_name="sub1", recalibration_factor=0.8,
            job_bag_number="jb1", modelling_weight=0.0, load_ts=datetime(2024, 1, 1)),
    ]).write.mode("overwrite").parquet(path)

    camp_execution_df = spark_session.createDataFrame([
        Row(booking_id="b1", campaign_duration="During"),
    ])

    with pytest.raises(ValueError, match="modelling_weight close to zero"):
        load_campaign_reporting_during(
            spark_session.read.parquet(path),
            camp_execution_df,
        )


def test_apply_campaign_duration_identifier_flag(spark_session):
    camp_execution_df = spark_session.createDataFrame([
        Row(booking_id="b1", campaign_duration="During", campaign_start_dt=date(2024, 1, 1),
            campaign_end_dt=date(2024, 1, 20), channel_name="meta", campaign_id="c1"),
        Row(booking_id="b1", campaign_duration="During", campaign_start_dt=date(2024, 1, 1),
            campaign_end_dt=date(2024, 1, 20), channel_name="youtube", campaign_id="c1"),
        Row(booking_id="b2", campaign_duration="Post", campaign_start_dt=date(2024, 2, 1),
            campaign_end_dt=date(2024, 2, 20), channel_name="meta", campaign_id="c2"),
    ])

    actual_df = apply_campaign_duration_identifier_flag(camp_execution_df)

    expected_df = spark_session.createDataFrame([
        Row(booking_id="b1", campaign_duration="During", is_post_campaign=False),
        Row(booking_id="b2", campaign_duration="Post", is_post_campaign=True),
    ])

    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_nullable=True)


def test_filter_transaction_to_sku(spark_session):
    transaction_data = spark_session.createDataFrame([
        Row(booking_id="b1", campaign_id="c1", transaction_key="t1",
            event_dt=date(2024, 1, 15), item_cd="SKU001", net_sales_amt=100.0,
            units_qty=5, unique_brand_name="BrandA", subchannel_name="txn",
            product_type="offer", channel_name="meta", subchannel_name_raw="txn",
            campaign_duration="During", is_post_campaign=False,
            marketing_type="Offsite", load_ts=datetime(2024, 1, 15),
            campaign_name="Test", event_name="transaction", event_ts=datetime(2024, 1, 15),
            loyalty_id="l1"),
        # Should be filtered out - wrong product_type
        Row(booking_id="b1", campaign_id="c1", transaction_key="t2",
            event_dt=date(2024, 1, 15), item_cd="SKU002", net_sales_amt=200.0,
            units_qty=10, unique_brand_name="BrandB", subchannel_name="txn",
            product_type="brand", channel_name="meta", subchannel_name_raw="txn",
            campaign_duration="During", is_post_campaign=False,
            marketing_type="Offsite", load_ts=datetime(2024, 1, 15),
            campaign_name="Test", event_name="transaction", event_ts=datetime(2024, 1, 15),
            loyalty_id="l2"),
        # Should be filtered out - outside campaign week
        Row(booking_id="b1", campaign_id="c1", transaction_key="t3",
            event_dt=date(2024, 2, 15), item_cd="SKU003", net_sales_amt=300.0,
            units_qty=15, unique_brand_name="BrandC", subchannel_name="txn",
            product_type="offer", channel_name="meta", subchannel_name_raw="txn",
            campaign_duration="During", is_post_campaign=False,
            marketing_type="Offsite", load_ts=datetime(2024, 1, 15),
            campaign_name="Test", event_name="transaction", event_ts=datetime(2024, 1, 15),
            loyalty_id="l3"),
    ])

    camp_execution_df = spark_session.createDataFrame([
        Row(booking_id="b1", campaign_duration="During", campaign_start_dt=date(2024, 1, 10),
            campaign_end_dt=date(2024, 1, 20), channel_name="meta", campaign_id="c1"),
    ])

    weekly_campaign_duration_df = spark_session.createDataFrame([
        Row(campaign_id="c1", channel_name="meta", campaign_duration="During",
            booking_id="b1", campaign_start_dt=date(2024, 1, 10),
            campaign_end_dt=date(2024, 1, 20),
            campaign_week_start_date="2024-01-08", campaign_week_end_date="2024-01-15"),
    ])

    actual_df = filter_transaction_to_sku(
        transaction_data, camp_execution_df, weekly_campaign_duration_df, "offer"
    )

    assert actual_df.count() == 1
    assert actual_df.collect()[0]["transaction_key"] == "t1"


def test_apply_recalibration_passthrough_for_non_post(spark_session):
    sku_df = spark_session.createDataFrame([
        Row(campaign_id="c1", channel_name="meta", subchannel_name="Social",
            marketing_type="Offsite", recalibration_factor=0.5,
            normalized_weights=0.5, customer_journey_type="Direct", journey_type="offer"),
    ])

    result = apply_recalibration(
        sku_df, "During", None, is_dtp=True,
        channel_hierarchy_code_df=None,
        subchannel_hierarchy_codes=None,
    )

    expected_df = spark_session.createDataFrame([
        Row(campaign_id="c1", channel_name="meta", subchannel_name="Social",
            marketing_type="Offsite", recalibration_factor=0.5,
            normalized_weights=0.5, customer_journey_type="Direct", journey_type="offer"),
    ])

    assert_df_equality(result, expected_df, ignore_row_order=True, ignore_nullable=True)


def test_apply_post_campaign_recalibration_updates_multi_touch_offsite_rows(spark_session):
    sku_df = spark_session.createDataFrame([
        Row(campaign_id="c1", channel_name="meta", subchannel_name="Social",
            marketing_type="offsite", recalibration_factor=0.5,
            normalized_weights=0.6, customer_journey_type="Direct", journey_type="offer"),
        Row(campaign_id="c1", channel_name="meta", subchannel_name="Social",
            marketing_type="offsite", recalibration_factor=0.5,
            normalized_weights=0.4, customer_journey_type="Multi", journey_type="offer"),
        Row(campaign_id="c1", channel_name="search", subchannel_name="Search",
            marketing_type="onsite", recalibration_factor=1.0,
            normalized_weights=0.2, customer_journey_type="Direct", journey_type="offer"),
    ])

    during_df = spark_session.createDataFrame([
        Row(campaign_id="c1", channel_name="meta", subchannel_name="Social",
            marketing_type="offsite", journey_type="offer",
            recalibration_factor=0.5, modelling_weight=0.8),
    ])

    result = _apply_post_campaign_recalibration(sku_df, during_df)

    rows = {(row["channel_name"], row["customer_journey_type"]): row for row in result.collect()}
    assert abs(rows[("meta", "Direct")]["recalibration_factor"] - 0.625) < 1e-6
    assert abs(rows[("meta", "Multi")]["recalibration_factor"] - 0.625) < 1e-6
    assert rows[("search", "Direct")]["recalibration_factor"] == 1.0


def test_recalculate_post_offsite_amounts_uses_final_factor_and_preserves_onsite(spark_session):
    sku_df = spark_session.createDataFrame([
        Row(
            campaign_id="c1",
            marketing_type="offsite",
            recalibration_factor=0.25,
            attributed_sales_amt=100.0,
            attributed_units_qty=5.0,
            attributed_recalibrated_sales_amt=20.0,
            attributed_recalibrated_units_qty=1.0,
        ),
        Row(
            campaign_id="na",
            marketing_type="offsite",
            recalibration_factor=0.30,
            attributed_sales_amt=100.0,
            attributed_units_qty=5.0,
            attributed_recalibrated_sales_amt=26.0,
            attributed_recalibrated_units_qty=1.3,
        ),
        Row(
            campaign_id="c2",
            marketing_type="onsite",
            recalibration_factor=1.0,
            attributed_sales_amt=200.0,
            attributed_units_qty=10.0,
            attributed_recalibrated_sales_amt=180.0,
            attributed_recalibrated_units_qty=9.0,
        ),
    ])

    result = _recalculate_post_offsite_amounts(sku_df)
    rows = {row["campaign_id"]: row for row in result.collect()}

    assert rows["c1"]["attributed_recalibrated_sales_amt"] == 25.0
    assert rows["c1"]["attributed_recalibrated_units_qty"] == 1.25
    assert rows["na"]["attributed_recalibrated_sales_amt"] == 30.0
    assert rows["na"]["attributed_recalibrated_units_qty"] == 1.5
    assert rows["c2"]["attributed_recalibrated_sales_amt"] == 180.0
    assert rows["c2"]["attributed_recalibrated_units_qty"] == 9.0


def test_apply_recalibration_post_refreshes_eligible_and_preserves_legacy_meta(spark_session):
    sku_rows = []
    during_rows = []
    for booking_id, campaign_id, is_meta_aa_eligible in [
        ("booking-eligible", "campaign-eligible", True),
        ("booking-legacy", "campaign-legacy", False),
    ]:
        for journey_type in ("Direct", "Multi"):
            sku_rows.append(Row(
                booking_id=booking_id,
                campaign_id=campaign_id,
                channel_name="meta",
                subchannel_name="meta - social",
                marketing_type="offsite",
                journey_type="offer",
                customer_journey_type=journey_type,
                normalized_weights=0.3,
                recalibration_factor=0.1,
                attributed_sales_amt=100.0,
                attributed_units_qty=5.0,
                attributed_recalibrated_sales_amt=10.0,
                attributed_recalibrated_units_qty=0.5,
                is_meta_aa_eligible=is_meta_aa_eligible,
            ))
        during_rows.append(Row(
            campaign_id=campaign_id,
            channel_name="meta",
            subchannel_name="meta - social",
            marketing_type="offsite",
            journey_type="offer",
            recalibration_factor=0.2,
            modelling_weight=0.4,
        ))

    sku_df = spark_session.createDataFrame(sku_rows)
    during_df = spark_session.createDataFrame(during_rows)
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="meta - social", channel_type="offsite", marketing_hierarchy_cd=1),
    ])

    result = apply_recalibration(
        sku_df,
        CampaignDurations.CAMPAIGN_DURATION_POST,
        during_df,
        is_dtp=False,
        channel_hierarchy_code_df=hierarchy_df,
        subchannel_hierarchy_codes=json.dumps({"meta": [1]}),
    )
    rows = {
        (row["booking_id"], row["customer_journey_type"]): row
        for row in result.collect()
    }

    for journey_type in ("Direct", "Multi"):
        eligible_row = rows[("booking-eligible", journey_type)]
        assert eligible_row["recalibration_factor"] == pytest.approx(0.3)
        assert eligible_row["attributed_recalibrated_sales_amt"] == pytest.approx(30.0)
        assert eligible_row["attributed_recalibrated_units_qty"] == pytest.approx(1.5)

        legacy_row = rows[("booking-legacy", journey_type)]
        assert legacy_row["recalibration_factor"] == pytest.approx(0.16)
        assert legacy_row["attributed_recalibrated_sales_amt"] == pytest.approx(16.0)
        assert legacy_row["attributed_recalibrated_units_qty"] == pytest.approx(0.8)


def test_apply_recalibration_post_brand_reuses_offer_factors_for_offsite_channels(spark_session):
    sku_rows = []
    for channel_name, subchannel_name, recalibration_factor, sales_amt, units_qty in [
        ("meta", "meta - social", 0.25, 100.0, 5.0),
        ("youtube", "youtube", 0.35, 200.0, 10.0),
    ]:
        for customer_journey_type in ("Direct", "Non-direct"):
            sku_rows.append(Row(
                booking_id="booking-eligible",
                campaign_id="campaign-eligible",
                channel_name=channel_name,
                subchannel_name=subchannel_name,
                marketing_type="offsite",
                journey_type="offer",
                customer_journey_type=customer_journey_type,
                normalized_weights=0.3,
                recalibration_factor=recalibration_factor,
                attributed_sales_amt=sales_amt,
                attributed_units_qty=units_qty,
                attributed_recalibrated_sales_amt=10.0,
                attributed_recalibrated_units_qty=0.5,
                is_meta_aa_eligible=True,
            ))

    sku_df = spark_session.createDataFrame(sku_rows)
    during_df = spark_session.createDataFrame([
        Row(
            campaign_id="campaign-eligible",
            channel_name="meta",
            subchannel_name="meta - social",
            marketing_type="offsite",
            journey_type="offer",
            recalibration_factor=0.2,
            modelling_weight=0.4,
        ),
        Row(
            campaign_id="campaign-eligible",
            channel_name="youtube",
            subchannel_name="youtube",
            marketing_type="offsite",
            journey_type="offer",
            recalibration_factor=0.4,
            modelling_weight=0.6,
        ),
    ])
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="meta - social", channel_type="offsite", marketing_hierarchy_cd=1),
    ])

    result = apply_recalibration(
        sku_df,
        CampaignDurations.CAMPAIGN_DURATION_POST,
        during_df,
        is_dtp=False,
        channel_hierarchy_code_df=hierarchy_df,
        subchannel_hierarchy_codes=json.dumps({"meta": [1]}),
        product_type="brand",
    )

    rows = {
        (row["channel_name"], row["customer_journey_type"]): row
        for row in result.collect()
    }
    assert len(rows) == 4
    for row in rows:
        channel_name, _ = row
        expected_factor = 0.25 if channel_name == "meta" else 0.35
        expected_sales = 25.0 if channel_name == "meta" else 70.0
        expected_units = 1.25 if channel_name == "meta" else 3.5
        assert rows[row]["recalibration_factor"] == pytest.approx(expected_factor)
        assert rows[row]["attributed_recalibrated_sales_amt"] == pytest.approx(expected_sales)
        assert rows[row]["attributed_recalibrated_units_qty"] == pytest.approx(expected_units)


def test_apply_recalibration_post_dtp_brand_still_updates_factor(spark_session):
    sku_df = spark_session.createDataFrame([
        Row(
            booking_id="booking-dtp",
            campaign_id="campaign-dtp",
            channel_name="meta",
            subchannel_name="meta - social",
            marketing_type="offsite",
            journey_type="offer",
            customer_journey_type=customer_journey_type,
            normalized_weights=0.3,
            recalibration_factor=0.25,
            attributed_sales_amt=100.0,
            attributed_units_qty=5.0,
            attributed_recalibrated_sales_amt=10.0,
            attributed_recalibrated_units_qty=0.5,
        )
        for customer_journey_type in ("Direct", "Non-direct")
    ])
    during_df = spark_session.createDataFrame([
        Row(
            campaign_id="campaign-dtp",
            channel_name="meta",
            subchannel_name="meta - social",
            marketing_type="offsite",
            journey_type="offer",
            recalibration_factor=0.2,
            modelling_weight=0.4,
        ),
    ])

    result = apply_recalibration(
        sku_df,
        CampaignDurations.CAMPAIGN_DURATION_POST,
        during_df,
        is_dtp=True,
        channel_hierarchy_code_df=None,
        subchannel_hierarchy_codes=None,
        product_type="brand",
    )

    for row in result.collect():
        assert row["recalibration_factor"] == pytest.approx(0.3)
        assert row["attributed_recalibrated_sales_amt"] == pytest.approx(10.0)
        assert row["attributed_recalibrated_units_qty"] == pytest.approx(0.5)


def test_apply_recalibration_multi_touch(spark_session):
    sku_df = spark_session.createDataFrame([
        Row(campaign_id="c1", channel_name="meta", subchannel_name="Social",
            marketing_type="offsite", recalibration_factor=0.5,
            normalized_weights=0.6, customer_journey_type="Direct", journey_type="offer"),
        Row(campaign_id="c1", channel_name="meta", subchannel_name="Social",
            marketing_type="offsite", recalibration_factor=0.5,
            normalized_weights=0.4, customer_journey_type="Multi", journey_type="offer"),
    ])

    during_df = spark_session.createDataFrame([
        Row(campaign_id="c1", channel_name="meta", subchannel_name="Social",
            marketing_type="offsite", journey_type="offer",
            recalibration_factor=0.5, modelling_weight=0.8),
    ])

    result = apply_recalibration(
        sku_df, CampaignDurations.CAMPAIGN_DURATION_POST, during_df,
        is_dtp=True, channel_hierarchy_code_df=None,
        subchannel_hierarchy_codes=None,
    )

    assert result.count() == 2
    factors = {row["recalibration_factor"] for row in result.collect()}
    assert all(abs(f - 0.625) < 1e-6 for f in factors)


def test_apply_recalibration_single_touch(spark_session):
    sku_df = spark_session.createDataFrame([
        Row(campaign_id="c1", channel_name="meta", subchannel_name="Social",
            marketing_type="offsite", recalibration_factor=0.5,
            normalized_weights=0.5, customer_journey_type="Direct", journey_type="offer"),
    ])

    during_df = spark_session.createDataFrame([
        Row(campaign_id="c1", channel_name="meta", subchannel_name="Social",
            marketing_type="offsite", journey_type="offer",
            recalibration_factor=0.3, modelling_weight=0.5),
    ])

    result = apply_recalibration(
        sku_df, CampaignDurations.CAMPAIGN_DURATION_POST, during_df,
        is_dtp=True, channel_hierarchy_code_df=None,
        subchannel_hierarchy_codes=None,
    )

    assert result.count() == 1
    assert result.collect()[0]["recalibration_factor"] == 0.3


def test_apply_meta_recalibration_for_pollen_returns_input_when_mapping_missing(spark_session):
    sku_df = spark_session.createDataFrame([
        Row(subchannel_name="meta - social", recalibration_factor=0.8,
            attributed_sales_amt=100.0, attributed_units_qty=5.0,
            attributed_recalibrated_sales_amt=80.0, attributed_recalibrated_units_qty=4.0),
    ])

    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="meta - social", channel_type="offsite", marketing_hierarchy_cd=1),
    ])

    result = _apply_meta_recalibration_for_pollen(sku_df, hierarchy_df, None)

    assert_df_equality(result, sku_df, ignore_row_order=True, ignore_nullable=True)


def test_apply_recalibration_static_meta(spark_session):
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="meta - social", channel_type="offsite", marketing_hierarchy_cd=1),
        Row(marketing_subchannel="search", channel_type="onsite", marketing_hierarchy_cd=2),
    ])
    sku_df = spark_session.createDataFrame([
        Row(subchannel_name="meta - social", recalibration_factor=0.8,
            attributed_sales_amt=100.0, attributed_units_qty=5.0,
            attributed_recalibrated_sales_amt=80.0, attributed_recalibrated_units_qty=4.0),
        Row(subchannel_name="search", recalibration_factor=1.0,
            attributed_sales_amt=200.0, attributed_units_qty=10.0,
            attributed_recalibrated_sales_amt=200.0, attributed_recalibrated_units_qty=10.0),
    ])

    import json
    subchannel_codes = json.dumps({"meta": [1]})

    result = apply_recalibration(
        sku_df, "During", None, is_dtp=False,
        channel_hierarchy_code_df=hierarchy_df,
        subchannel_hierarchy_codes=subchannel_codes,
    )

    rows = {row["subchannel_name"]: row for row in result.collect()}

    assert rows["meta - social"]["recalibration_factor"] == 0.16
    assert abs(rows["meta - social"]["attributed_recalibrated_sales_amt"] - 16.0) < 1e-6
    assert abs(rows["meta - social"]["attributed_recalibrated_units_qty"] - 0.8) < 1e-6
    assert rows["search"]["recalibration_factor"] == 1.0
    assert rows["search"]["attributed_recalibrated_sales_amt"] == 200.0


def test_apply_recalibration_preserves_dynamic_meta_factor_for_eligible_booking(spark_session):
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="meta - social", channel_type="offsite", marketing_hierarchy_cd=1),
    ])
    sku_df = spark_session.createDataFrame([
        Row(
            booking_id="booking-eligible",
            subchannel_name="meta - social",
            recalibration_factor=0.23,
            attributed_sales_amt=100.0,
            attributed_units_qty=5.0,
            attributed_recalibrated_sales_amt=23.0,
            attributed_recalibrated_units_qty=1.15,
            is_meta_aa_eligible=True,
        ),
    ])

    result = apply_recalibration(
        sku_df, "During", None, is_dtp=False,
        channel_hierarchy_code_df=hierarchy_df,
        subchannel_hierarchy_codes=json.dumps({"meta": [1]}),
    )

    row = result.first()
    assert row["recalibration_factor"] == 0.23
    assert row["attributed_recalibrated_sales_amt"] == 23.0
    assert row["attributed_recalibrated_units_qty"] == 1.15


def test_add_offsite_channel_flag(spark_session):
    input_df = spark_session.createDataFrame([
        Row(booking_id='b1', subchannel_name='meta - social', val=1),
        Row(booking_id='b1', subchannel_name='video', val=4),
        Row(booking_id='b1', subchannel_name='search', val=5),
    ])

    offsite_subchannel_df = spark_session.createDataFrame([
        ('meta - social',),
        ('video',),
    ], ['offsite_key']).select(
        F.lower(F.col('offsite_key')).alias('offsite_key')
    ).distinct()

    actual_df = add_offsite_channel_flag(
        input_df,
        offsite_subchannel_df,
        'subchannel_name'
    )

    expected_df = spark_session.createDataFrame([
        Row(booking_id='b1', subchannel_name='meta - social', val=1, is_offsite_channel=True),
        Row(booking_id='b1', subchannel_name='video', val=4, is_offsite_channel=True),
        Row(booking_id='b1', subchannel_name='search', val=5, is_offsite_channel=False),
    ])

    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_nullable=True)


def test_with_offsite_flag_recomputes_flag_with_or_without_existing_column(spark_session):
    input_df = spark_session.createDataFrame([
        Row(subchannel_name='META - SOCIAL', value=1),
        Row(subchannel_name='Instore', value=2),
    ])
    offsite_subchannels_df = spark_session.createDataFrame([
        Row(subchannel_name='meta - social'),
    ])

    result_without_existing_flag = with_offsite_flag(input_df, offsite_subchannels_df)
    rows_without_existing_flag = {
        row['subchannel_name']: row
        for row in result_without_existing_flag.collect()
    }

    assert rows_without_existing_flag['META - SOCIAL']['is_offsite_subchannel'] is True
    assert rows_without_existing_flag['Instore']['is_offsite_subchannel'] is None

    input_with_existing_flag = input_df.withColumn(
        'is_offsite_subchannel',
        F.when(F.col('subchannel_name') == 'Instore', F.lit(True)).otherwise(F.lit(False)),
    )
    result_with_existing_flag = with_offsite_flag(
        input_with_existing_flag,
        offsite_subchannels_df,
    )
    rows_with_existing_flag = {
        row['subchannel_name']: row
        for row in result_with_existing_flag.collect()
    }

    assert rows_with_existing_flag['META - SOCIAL']['is_offsite_subchannel'] is True
    assert rows_with_existing_flag['Instore']['is_offsite_subchannel'] is None
    assert result_with_existing_flag.columns.count('is_offsite_subchannel') == 1


def test_get_subchannels_from_hierarchy_returns_none_when_hierarchy_missing(spark_session):
    """None hierarchy DataFrame should return None."""
    result = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df=None,
        output_column='test_col',
    )
    assert result is None


def test_get_subchannels_from_hierarchy_offsite_only_filtering(spark_session):
    """Offsite-only mode filters by channel_type and returns subchannels."""
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="Meta - Social", channel_type="OFFSITE", marketing_hierarchy_cd=1),
        Row(marketing_subchannel="Video", channel_type="OFFSITE", marketing_hierarchy_cd=2),
        Row(marketing_subchannel="Search", channel_type="ONSITE", marketing_hierarchy_cd=3),
        Row(marketing_subchannel="Display", channel_type="OFFSITE", marketing_hierarchy_cd=4),
    ])

    result = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df=hierarchy_df,
        output_column='offsite_key',
        offsite_only=True,
    )

    expected_df = spark_session.createDataFrame([
        ('meta - social',),
        ('video',),
        ('display',),
    ], ['offsite_key'])

    assert_df_equality(result, expected_df, ignore_row_order=True)


def test_get_subchannels_from_hierarchy_meta_code_extraction(spark_session):
    """Meta code extraction filters by marketing_hierarchy_cd and extracts subchannels."""
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="Meta - Social", channel_type="OFFSITE", marketing_hierarchy_cd=1),
        Row(marketing_subchannel="Meta - Search", channel_type="OFFSITE", marketing_hierarchy_cd=2),
        Row(marketing_subchannel="Search", channel_type="ONSITE", marketing_hierarchy_cd=3),
    ])

    subchannel_codes = json.dumps({"meta": [1, 2]})

    result = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df=hierarchy_df,
        output_column='subchannel_name',
        subchannel_hierarchy_json=subchannel_codes,
        hierarchy_codes_key='meta',
    )

    expected_df = spark_session.createDataFrame([
        ('meta - social',),
        ('meta - search',),
    ], ['subchannel_name'])

    assert_df_equality(result, expected_df, ignore_row_order=True)


def test_get_subchannels_from_hierarchy_returns_none_when_codes_key_missing_in_json(spark_session):
    """When hierarchy_codes_key is not found in JSON, should return None."""
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="Meta - Social", channel_type="OFFSITE", marketing_hierarchy_cd=1),
    ])

    subchannel_codes = json.dumps({"meta": [1]})

    result = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df=hierarchy_df,
        output_column='subchannel_name',
        subchannel_hierarchy_json=subchannel_codes,
        hierarchy_codes_key='missing_key',  # This key doesn't exist in JSON
    )

    assert result is None


def test_get_subchannels_from_hierarchy_returns_none_when_json_not_provided(spark_session):
    """When hierarchy_codes_key is set but JSON is not provided, should return None."""
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="Meta - Social", channel_type="OFFSITE", marketing_hierarchy_cd=1),
    ])

    result = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df=hierarchy_df,
        output_column='subchannel_name',
        subchannel_hierarchy_json=None,  # Missing JSON
        hierarchy_codes_key='meta',
    )

    assert result is None


def test_get_subchannels_from_hierarchy_filters_null_subchannels(spark_session):
    """Null subchannels should be filtered out."""
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="Meta - Social", channel_type="OFFSITE", marketing_hierarchy_cd=1),
        Row(marketing_subchannel=None, channel_type="OFFSITE", marketing_hierarchy_cd=2),
        Row(marketing_subchannel="Video", channel_type="OFFSITE", marketing_hierarchy_cd=3),
    ])

    result = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df=hierarchy_df,
        output_column='offsite_key',
        offsite_only=True,
    )

    expected_df = spark_session.createDataFrame([
        ('meta - social',),
        ('video',),
    ], ['offsite_key'])

    assert_df_equality(result, expected_df, ignore_row_order=True)


def test_get_subchannels_from_hierarchy_returns_distinct_values(spark_session):
    """Duplicate subchannels should be deduplicated."""
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="Meta - Social", channel_type="OFFSITE", marketing_hierarchy_cd=1),
        Row(marketing_subchannel="Meta - Social", channel_type="OFFSITE", marketing_hierarchy_cd=1),
        Row(marketing_subchannel="Video", channel_type="OFFSITE", marketing_hierarchy_cd=2),
    ])

    result = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df=hierarchy_df,
        output_column='offsite_key',
        offsite_only=True,
    )

    assert result.count() == 2
    subchannels = [row['offsite_key'] for row in result.collect()]
    assert set(subchannels) == {'meta - social', 'video'}


def test_get_subchannels_from_hierarchy_combined_filters(spark_session):
    """Both offsite_only and code filtering can be combined."""
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="Meta - Social", channel_type="OFFSITE", marketing_hierarchy_cd=1),
        Row(marketing_subchannel="Video", channel_type="OFFSITE", marketing_hierarchy_cd=2),
        Row(marketing_subchannel="Meta - Search", channel_type="OFFSITE", marketing_hierarchy_cd=3),
    ])

    subchannel_codes = json.dumps({"meta": [1]})

    result = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df=hierarchy_df,
        output_column='subchannel_name',
        offsite_only=True,
        subchannel_hierarchy_json=subchannel_codes,
        hierarchy_codes_key='meta',
    )

    expected_df = spark_session.createDataFrame([
        ('meta - social',),
    ], ['subchannel_name'])

    assert_df_equality(result, expected_df, ignore_row_order=True)


def test_get_subchannels_from_hierarchy_returns_empty_when_no_matches(spark_session):
    """When no rows match the filters, should return empty DataFrame with correct schema."""
    hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel="Meta - Social", channel_type="OFFSITE", marketing_hierarchy_cd=1),
    ])

    subchannel_codes = json.dumps({"meta": [999]})  # Code that doesn't exist in hierarchy

    result = get_subchannels_from_hierarchy(
        channel_hierarchy_code_df=hierarchy_df,
        output_column='subchannel_name',
        subchannel_hierarchy_json=subchannel_codes,
        hierarchy_codes_key='meta',
    )

    # When codes are provided but don't match any rows, returns empty DataFrame
    assert result.count() == 0
    assert result.columns == ['subchannel_name']


def test_channel_hierarchy_with_all_null_values(spark_session):
    """Hierarchy rows exist but marketing_subchannel and marketing_hierarchy_cd are null — should passthrough."""
    sku_df = spark_session.createDataFrame([
        Row(subchannel_name="meta - social", recalibration_factor=0.8,
            attributed_sales_amt=100.0, attributed_units_qty=5.0,
            attributed_recalibrated_sales_amt=80.0, attributed_recalibrated_units_qty=4.0),
    ])

    null_hierarchy_df = spark_session.createDataFrame([
        Row(marketing_subchannel=None, channel_type=None, marketing_hierarchy_cd=None),
    ], schema=SkuLevelAttributedSalesAndUnits.channel_hierarchy_schema)

    import json
    subchannel_codes = json.dumps({"meta": [1]})

    result = apply_recalibration(
        sku_df, "During", None, is_dtp=False,
        channel_hierarchy_code_df=null_hierarchy_df,
        subchannel_hierarchy_codes=subchannel_codes,
    )
    assert_df_equality(result, sku_df, ignore_row_order=True, ignore_nullable=True)


def test_apply_recalibration_with_empty_hierarchy_df(spark_session):
    """Pollen run with a hierarchy DF that exists but has no rows"""
    sku_df = spark_session.createDataFrame([
        Row(subchannel_name="meta - social", recalibration_factor=0.8,
            attributed_sales_amt=100.0, attributed_units_qty=5.0,
            attributed_recalibrated_sales_amt=80.0, attributed_recalibrated_units_qty=4.0),
    ])

    empty_hierarchy_df = spark_session.createDataFrame(
        [],
        schema="marketing_subchannel STRING, channel_type STRING, marketing_hierarchy_cd INT"
    )

    import json
    subchannel_codes = json.dumps({"meta": [1]})

    result = apply_recalibration(
        sku_df, "During", None, is_dtp=False,
        channel_hierarchy_code_df=empty_hierarchy_df,
        subchannel_hierarchy_codes=subchannel_codes,
    )

    # No matching codes in hierarchy → passthrough, recalibration_factor unchanged
    assert_df_equality(result, sku_df, ignore_row_order=True, ignore_nullable=True)


def test_has_multiple_customer_journey_types_returns_expected_boolean(spark_session):
    multi_touch_df = spark_session.createDataFrame([
        ("Direct",),
        ("Multi",),
    ], ["customer_journey_type"])

    single_touch_df = spark_session.createDataFrame([
        ("Direct",),
        ("Direct",),
    ], ["customer_journey_type"])

    assert _has_multiple_customer_journey_types(multi_touch_df) is True
    assert _has_multiple_customer_journey_types(single_touch_df) is False


def test_apply_recalibration_factor_lookup_updates_only_matching_rows(spark_session):
    sku_level_df = spark_session.createDataFrame([
        ("offsite", "c1", "meta", "social", 0.5),
        ("offsite", "c2", "youtube", "video", 0.7),
    ], ["marketing_type", "campaign_id", "channel_name", "subchannel_name", "recalibration_factor"])

    lookup_df = spark_session.createDataFrame([
        ("offsite", "c1", "meta", "social", 1.2),
    ], ["marketing_type", "campaign_id", "channel_name", "subchannel_name", "new_recalibration_factor"])

    actual = _apply_recalibration_factor_lookup(sku_level_df, lookup_df)

    expected = spark_session.createDataFrame([
        ("offsite", "c1", "meta", "social", 1.2),
        ("offsite", "c2", "youtube", "video", 0.7),
    ], ["marketing_type", "campaign_id", "channel_name", "subchannel_name", "recalibration_factor"])

    assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)


def test_build_multi_touch_recalibration_lookup_computes_expected_factor(spark_session):
    sku_level_df = spark_session.createDataFrame([
        ("offsite", "c1", "meta", "social", 0.6),
        ("offsite", "c1", "meta", "social", 0.4),
        ("onsite", "c1", "search", "search", 0.9),
    ], ["marketing_type", "campaign_id", "channel_name", "subchannel_name", "normalized_weights"])

    sku_during = spark_session.createDataFrame([
        ("offsite", "c1", "meta", "social", 0.5, 0.8),
    ], ["marketing_type", "campaign_id", "channel_name", "subchannel_name", "modelling_weight", "recalibration_factor"])

    actual = _build_multi_touch_recalibration_lookup(sku_level_df, sku_during)

    expected = spark_session.createDataFrame([
        ("offsite", "c1", "meta", "social", 1.6),
    ], ["marketing_type", "campaign_id", "channel_name", "subchannel_name", "new_recalibration_factor"])

    assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)


def test_build_single_touch_recalibration_lookup_shapes_expected_columns(spark_session):
    sku_during = spark_session.createDataFrame([
        ("offsite", "c1", "meta", "social", 0.8),
    ], ["marketing_type", "campaign_id", "channel_name", "subchannel_name", "recalibration_factor"])

    actual = _build_single_touch_recalibration_lookup(sku_during)

    expected = spark_session.createDataFrame([
        ("offsite", "c1", "meta", "social", 0.8),
    ], ["marketing_type", "campaign_id", "channel_name", "subchannel_name", "new_recalibration_factor"])

    assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)


def test_calculate_aggregated_sales_pollen_multiple_purchase_journeys(spark_session):
    """
    Pollen run with two journeys hitting the same offsite subchannel (meta - social)
    — representing a booking where multiple customers purchased via the same channel.

    Expected factor derivation:
      - Offsite (Social / meta - social): weights 0.5 + 0.3 = 0.8
        total_weights_per_campaign = 1.0
        attributed_sales_amt  = 0.8 / 1.0 * 1000  = 800
        channel_weights (window on Social) = 0.8
        adjusted_weight (overlap=0, offsite) = 0.8 / 0.8 = 1.0
        recalibrated_sales_amt = 1.0 * 600 = 600
        factor = 600 / 800 = 0.75

      - Onsite (Search / search): weight 0.2
        attributed_sales_amt  = 0.2 / 1.0 * 1000 = 200
        recalibrated_sales_amt = 200  (no DTP adjustment for onsite)
        factor = 200 / 200 = 1.0
    """
    # Pollen: offsite key matches against subchannel_name
    offsite_subchannel_df = spark_session.createDataFrame(
        [("meta - social",)], ["offsite_key"]
    )

    dtp_sales_df = spark_session.createDataFrame([
        ("b1", "Social", "c1", 600.0),
    ], schema="booking_id string, channel_name string, campaign_id string, sum_sales_amt double")

    attribution_df = spark_session.createDataFrame([
        # Two journeys, same offsite channel — simulates two purchase journeys in campaign
        ("b1", "Social", "meta - social", "offsite", "c1", 0.5),
        ("b1", "Social", "meta - social", "offsite", "c1", 0.3),
        # One onsite journey
        ("b1", "Search", "search", "onsite", "c1", 0.2),
    ], schema="booking_id string, channel_name string, subchannel_name string, marketing_type string, campaign_id string, normalized_weights double")

    campaign_metrics = spark_session.createDataFrame([
        ("b1", 1000.0, 0.0),
    ], schema="booking_id string, total_sales double, channel_overlap_proportion double")

    actual = calculate_aggregated_sales(
        dtp_sales_df,
        attribution_df,
        campaign_metrics,
        PipelineRunType.pollen_run_type,
        offsite_subchannel_df,
    )

    expected = spark_session.createDataFrame([
        ("b1", "Social", "c1", 0.75),
        ("b1", "Search", "c1", 1.0),
    ], schema="booking_id string, channel_name string, campaign_id string, factor double")

    assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)


def test_calculate_aggregated_sales_sum_attributed_recalibrated_sums_across_subchannels(spark_session):
    """
    Validates that sum_attributed_recalibrated_sales_amt is computed as a window
    sum over (booking_id, channel_name, campaign_id), not per individual subchannel.

    Setup: two offsite subchannels (meta - social, meta - video) share the same
    channel_name 'Social', channel_overlap_proportion = 0.

    Step-by-step derivation
    -------------------------
    After groupBy, two rows exist for Social:
      meta - social: sum_normalized_weights = 0.6
      meta - video:  sum_normalized_weights = 0.4

    total_weights_per_campaign (booking b1) = 1.0

    weights_percentage:
      meta - social: 0.6 / 1.0 = 0.6
      meta - video:  0.4 / 1.0 = 0.4

    attributed_sales_amt:
      meta - social: 0.6 * 1000 = 600
      meta - video:  0.4 * 1000 = 400

    channel_weights (window sum of weights over Social): 0.6 + 0.4 = 1.0

    adjusted_sum_normalized_weights (overlap=0, is_offsite=True):
      meta - social: 0.6 / 1.0 = 0.6
      meta - video:  0.4 / 1.0 = 0.4

    attributed_recalibrated_sales_amt (overlap=0, is_offsite=True):
      meta - social: 0.6 * 500 = 300
      meta - video:  0.4 * 500 = 200

    sum_attributed_recalibrated_sales_amt (window): 300 + 200 = 500
    sum_attributed_sales_amt (window):              600 + 400 = 1000

    factor = 500 / 1000 = 0.5  (same for both rows → 1 row after distinct)
    """
    offsite_subchannel_df = spark_session.createDataFrame(
        [("meta - social",), ("meta - video",)], ["offsite_key"]
    )

    dtp_sales_df = spark_session.createDataFrame([
        ("b1", "Social", "c1", 500.0),
    ], schema="booking_id string, channel_name string, campaign_id string, sum_sales_amt double")

    attribution_df = spark_session.createDataFrame([
        ("b1", "Social", "meta - social", "offsite", "c1", 0.6),
        ("b1", "Social", "meta - video", "offsite", "c1", 0.4),
    ], schema="booking_id string, channel_name string, subchannel_name string, marketing_type string, campaign_id string, normalized_weights double")

    campaign_metrics = spark_session.createDataFrame([
        ("b1", 1000.0, 0.0),
    ], schema="booking_id string, total_sales double, channel_overlap_proportion double")

    actual = calculate_aggregated_sales(
        dtp_sales_df,
        attribution_df,
        campaign_metrics,
        PipelineRunType.pollen_run_type,
        offsite_subchannel_df,
    )

    # Both subchannels collapse to one factor row after .distinct() on (booking_id, channel_name, campaign_id).
    # factor = sum_attributed_recalibrated (500) / sum_attributed (1000) = 0.5
    expected = spark_session.createDataFrame([
        ("b1", "Social", "c1", 0.5),
    ], schema="booking_id string, channel_name string, campaign_id string, factor double")

    assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)


def test_calculate_sku_level_attribution_dtp_offer_attributed_and_recalibrated_sales(spark_session):
    """
    End-to-end test for calculate_sku_level_attribution: DTP Offer During-campaign run.

    Setup: one journey (j1) with offsite channel 'meta', normalized_weight=0.5.
    One purchase transaction: net_sales_amt=100.0.  DTP actual sales (reach engagement): 80.0.

    Factor derivation (calculate_aggregated_sales):
      total_weights_per_campaign    = 0.5
      weights_percentage            = 0.5 / 0.5 = 1.0
      attributed_sales_amt          = 1.0 * 100.0 = 100.0
      channel_overlap_proportion    = 0  (j1 touches only 1 channel)
      adjusted_normalized_weights   = 0.5 / 0.5 = 1.0
      attributed_recalibrated_sales = 1.0 * 80.0 = 80.0
      factor                        = 80.0 / 100.0 = 0.8

    SKU-level attributed sales (calculate_recalibrated_sales):
      attributed_sales_amt              = 0.5 * 100.0 = 50.0
      attributed_recalibrated_sales_amt = 50.0 * 0.8  = 40.0

    Also verifies:
    - transaction_key is dropped from the final output
    - load_ts is set to run_date
    - job_run_id is set to correlation_id
    """
    run_date = "2025-01-29"
    correlation_id = "test-corr-id"
    campaign_start = date(2025, 1, 6)   # Monday
    campaign_end = date(2025, 1, 28)
    txn_date = date(2025, 1, 15)       # within campaign window

    camp_execution_df = spark_session.createDataFrame([
        ("b1", "During", "meta", "c1", campaign_start, campaign_end),
    ], schema="booking_id string, campaign_duration string, channel_name string, campaign_id string, campaign_start_dt date, campaign_end_dt date")

    attribution_data_df = spark_session.createDataFrame([
        ("j1", "l1", "txn-001", "b1", "single", "offer", True,
         "txn_c1", 0.5, "c1", "During", datetime(2025, 1, 1), "meta", "meta - social", "offsite"),
    ], schema=(
        "userjourney_id string, loyalty_id string, transaction_key string, "
        "booking_id string, customer_journey_type string, journey_type string, "
        "isconversion boolean, regression_variable string, normalized_weights double, "
        "campaign_id string, campaign_duration string, load_ts timestamp, "
        "channel_name string, subchannel_name string, marketing_type string"
    ))

    transaction_raw_df = spark_session.createDataFrame([
        ("b1", "c1", "txn-001", txn_date, "transaction", "SKU1", 100.0, 2, "txn", "offer", "TestBrand"),
    ], schema=(
        "booking_id string, campaign_id string, transaction_key string, "
        "event_dt date, event_name string, item_cd string, net_sales_amt double, units_qty int, "
        "subchannel_name string, product_type string, unique_brand_name string"
    ))

    # DTP actual offsite sales used to derive the recalibration factor
    reach_engagement_df = spark_session.createDataFrame([
        ("b1", "meta", "c1", 80.0),
    ], schema="booking_id string, channel_name string, campaign_id string, sales_amt double")

    # Used to compute total_sales_per_campaign (sum of net_sales_amt for offer/txn rows)
    attribution_pre_req_df = spark_session.createDataFrame([
        ("b1", "During", "offer", "txn_c1", 100.0),
    ], schema="booking_id string, campaign_duration string, journey_type string, regression_variable string, net_sales_amt double")

    with mock.patch(
        "spark_pipeline.sku_level_attribution.sku_level_attribution_helper.SKUAttributionValidationNotifier"
    ) as mock_notifier_cls:
        mock_notifier_cls.return_value.send_final_validation_summary.return_value = None

        actual = calculate_sku_level_attribution(
            spark=spark_session,
            attribution_data_df=attribution_data_df,
            transaction_raw_df=transaction_raw_df,
            camp_execution_df=camp_execution_df,
            product_type="offer",
            correlation_id=correlation_id,
            slack_topic_arn=None,
            run_date=run_date,
            campaign_duration=CampaignDurations.CAMPAIGN_DURATION_DURING,
            pipeline_run_type=PipelineRunType.dtp_run_type,
            reach_engagement_df=reach_engagement_df,
            attribution_pre_req_df=attribution_pre_req_df,
        )

    assert "transaction_key" not in actual.columns

    actual_selected = actual.select(
        "booking_id",
        "userjourney_id",
        "item_cd",
        "attributed_sales_amt",
        "attributed_recalibrated_sales_amt",
        "recalibration_factor",
        "load_ts",
        "job_run_id",
    )

    expected = spark_session.createDataFrame([
        ("b1", "j1", "SKU1", 50.0, None, None, "2025-01-29", "test-corr-id"),
    ], schema=(
        "booking_id string, userjourney_id string, item_cd string, "
        "attributed_sales_amt double, attributed_recalibrated_sales_amt double, "
        "recalibration_factor double, load_ts string, job_run_id string"
    ))

    assert_df_equality(actual_selected, expected, ignore_row_order=True, ignore_nullable=True)


def test_calculate_sku_level_attribution_pollen_joins_meta_eligibility(spark_session):
    campaign_start = date(2026, 7, 28)
    campaign_end = date(2026, 8, 3)
    txn_date = date(2026, 7, 30)

    camp_execution_df = spark_session.createDataFrame([
        ("b1", "During", "meta", "c1", campaign_start, campaign_end, "meta - social"),
    ], schema=(
        "booking_id string, campaign_duration string, channel_name string, campaign_id string, "
        "campaign_start_dt date, campaign_end_dt date, subchannel_name string"
    ))
    attribution_data_df = spark_session.createDataFrame([
        ("j1", "l1", "txn-001", "b1", "single", "offer", True,
         "txn_c1", 0.5, "c1", "During", datetime(2026, 7, 28), "meta", "meta - social", "offsite"),
    ], schema=(
        "userjourney_id string, loyalty_id string, transaction_key string, "
        "booking_id string, customer_journey_type string, journey_type string, "
        "isconversion boolean, regression_variable string, normalized_weights double, "
        "campaign_id string, campaign_duration string, load_ts timestamp, "
        "channel_name string, subchannel_name string, marketing_type string"
    ))
    transaction_raw_df = spark_session.createDataFrame([
        ("b1", "c1", "txn-001", txn_date, "transaction", "SKU1", 100.0, 2, "txn", "offer", "TestBrand"),
    ], schema=(
        "booking_id string, campaign_id string, transaction_key string, "
        "event_dt date, event_name string, item_cd string, net_sales_amt double, units_qty int, "
        "subchannel_name string, product_type string, unique_brand_name string"
    ))
    channel_hierarchy_code_df = spark_session.createDataFrame([
        ("meta - social", "offsite", 1),
    ], schema="marketing_subchannel string, channel_type string, marketing_hierarchy_cd int")
    sku_level_results_final = spark_session.createDataFrame([
        Row(
            booking_id="b1",
            channel_name="meta",
            subchannel_name="meta - social",
            marketing_type="offsite",
            factor=0.3,
            attributed_sales_amt=100.0,
            attributed_units_qty=5.0,
            attributed_recalibrated_sales_amt=30.0,
            attributed_recalibrated_units_qty=1.5,
        ),
    ])

    with mock.patch(
        "spark_pipeline.sku_level_attribution.sku_level_attribution_helper.SKUAttributionValidationNotifier"
    ), mock.patch(
        "spark_pipeline.sku_level_attribution.sku_level_attribution_helper.process_offer_attribution_multi_campaign",
        return_value=(None, sku_level_results_final),
    ):
        actual = calculate_sku_level_attribution(
            spark=spark_session,
            attribution_data_df=attribution_data_df,
            transaction_raw_df=transaction_raw_df,
            camp_execution_df=camp_execution_df,
            product_type="offer",
            correlation_id="test-pollen-meta-eligibility",
            slack_topic_arn=None,
            run_date="2026-08-04",
            campaign_duration=CampaignDurations.CAMPAIGN_DURATION_DURING,
            pipeline_run_type=PipelineRunType.pollen_run_type,
            channel_hierarchy_code_df=channel_hierarchy_code_df,
            subchannel_hierarchy_codes=json.dumps({"meta": [1]}),
        )

    result = actual.first()
    assert result["recalibration_factor"] == pytest.approx(0.3)
    assert result["attributed_recalibrated_sales_amt"] == pytest.approx(30.0)
    assert "is_meta_aa_eligible" not in actual.columns


def test_calculate_sku_level_attribution_pollen_post_brand_reuses_offer_factor(spark_session):
    campaign_start = date(2026, 7, 28)
    campaign_end = date(2026, 8, 3)

    camp_execution_df = spark_session.createDataFrame([
        ("b1", "Post", "meta", "c1", campaign_start, campaign_end, "meta - social"),
    ], schema=(
        "booking_id string, campaign_duration string, channel_name string, campaign_id string, "
        "campaign_start_dt date, campaign_end_dt date, subchannel_name string"
    ))
    attribution_data_df = spark_session.createDataFrame([
        ("j1", "l1", "txn-001", "b1", "Direct", "offer", True,
         "txn_c1", 0.3, "c1", "Post", datetime(2026, 7, 30), "meta", "meta - social", "offsite"),
        ("j2", "l2", "txn-002", "b1", "Non-direct", "offer", True,
         "txn_c1", 0.3, "c1", "Post", datetime(2026, 7, 30), "meta", "meta - social", "offsite"),
    ], schema=(
        "userjourney_id string, loyalty_id string, transaction_key string, "
        "booking_id string, customer_journey_type string, journey_type string, "
        "isconversion boolean, regression_variable string, normalized_weights double, "
        "campaign_id string, campaign_duration string, load_ts timestamp, "
        "channel_name string, subchannel_name string, marketing_type string"
    ))
    transaction_raw_df = spark_session.createDataFrame([
        ("b1", "c1", "txn-001", date(2026, 7, 30), "transaction", "SKU1", 100.0, 5, "txn", "brand", "TestBrand"),
        ("b1", "c1", "txn-002", date(2026, 7, 30), "transaction", "SKU1", 100.0, 5, "txn", "brand", "TestBrand"),
    ], schema=(
        "booking_id string, campaign_id string, transaction_key string, "
        "event_dt date, event_name string, item_cd string, net_sales_amt double, units_qty int, "
        "subchannel_name string, product_type string, unique_brand_name string"
    ))
    channel_hierarchy_code_df = spark_session.createDataFrame([
        ("meta - social", "offsite", 1),
    ], schema="marketing_subchannel string, channel_type string, marketing_hierarchy_cd int")
    sku_level_offer_df = spark_session.createDataFrame([
        Row(
            booking_id="b1",
            campaign_duration="Post",
            campaign_id="c1",
            channel_name="meta",
            userjourney_id="j1",
            loyalty_id="l1",
            customer_journey_type="Direct",
            journey_type="offer",
            isconversion=True,
            normalized_weights=0.3,
            event_dt=date(2026, 7, 30),
            item_cd="SKU1",
            net_sales_amt=100.0,
            units_qty=5,
            unique_brand_name="TestBrand",
            week_start_dt="2026-07-27",
            regression_variable="txn_c1",
            subchannel_name="meta - social",
            attributed_sales_amt=30.0,
            attributed_units_qty=1.5,
            attributed_recalibrated_sales_amt=7.5,
            attributed_recalibrated_units_qty=0.375,
            load_ts=datetime(2026, 8, 4),
            marketing_type="offsite",
            recalibration_factor=0.25,
        ),
    ])
    during_reporting_df = spark_session.createDataFrame([
        Row(
            booking_id="b1",
            campaign_duration="During",
            campaign_id="c1",
            journey_type="offer",
            marketing_type="offsite",
            channel_name="meta",
            subchannel_name="meta - social",
            recalibration_factor=0.2,
            modelling_weight=0.4,
            load_ts=datetime(2026, 8, 4),
        ),
    ])

    with mock.patch(
        "spark_pipeline.sku_level_attribution.sku_level_attribution_helper.SKUAttributionValidationNotifier"
    ) as mock_notifier_cls:
        mock_notifier_cls.return_value.send_final_validation_summary.return_value = None
        actual = calculate_sku_level_attribution(
            spark=spark_session,
            attribution_data_df=attribution_data_df,
            transaction_raw_df=transaction_raw_df,
            camp_execution_df=camp_execution_df,
            product_type="brand",
            correlation_id="test-pollen-post-brand-offer-factor",
            slack_topic_arn=None,
            run_date="2026-08-05",
            campaign_duration=CampaignDurations.CAMPAIGN_DURATION_POST,
            pipeline_run_type=PipelineRunType.pollen_run_type,
            channel_hierarchy_code_df=channel_hierarchy_code_df,
            subchannel_hierarchy_codes=json.dumps({"meta": [1]}),
            measurement_campaign_reporting_df=during_reporting_df,
            sku_level_offer_df=sku_level_offer_df,
        )

    rows = actual.collect()
    assert len(rows) == 2
    for row in rows:
        assert row["recalibration_factor"] == pytest.approx(0.25)
        assert row["attributed_sales_amt"] == pytest.approx(30.0)
        assert row["attributed_recalibrated_sales_amt"] == pytest.approx(7.5)
        assert row["attributed_recalibrated_units_qty"] == pytest.approx(0.375)


def test_pollen_single_txn_shared_across_two_campaigns_attributed_independently(spark_session):
    """
    Pollen run: one journey (j1) has one purchase transaction (txn-001) containing
    two SKUs (SKU_A at £2.50/2 units and SKU_B at £1.25/1 unit) attributed to two
    campaigns. customer_data_collection (transaction_df) has rows for each
    campaign × SKU, carrying real item_cd, net_sales_amt and units_qty.

    The Pollen branch selects SKU columns (dropping campaign_id), deduplicates to
    one row per (transaction_key, item_cd), then joins attribution_df on
    transaction_key so every attributed campaign gets one row per SKU.

    Expected: 4 rows (2 campaigns × 2 SKUs) with real item_cd and units_qty:
      c1 (weight=0.6): SKU_A → 1.50, SKU_B → 0.75
      c2 (weight=0.4): SKU_A → 1.00, SKU_B → 0.50
    """
    campaign_start = date(2026, 1, 6)
    campaign_end = date(2026, 1, 28)
    txn_date = date(2026, 1, 21)
    week_dt = date(2026, 1, 19)

    camp_execution_df = spark_session.createDataFrame([
        ("b1", "During", "Instore", "c1", campaign_start, campaign_end),
        ("b1", "During", "Fins - Main Estate", "c2", campaign_start, campaign_end),
    ], schema=(
        "booking_id string, campaign_duration string, channel_name string, "
        "campaign_id string, campaign_start_dt date, campaign_end_dt date"
    ))

    attribution_df = spark_session.createDataFrame([
        ("j1", "l1", "txn-001", "b1", "single", "offer", True,
         "txn_c1", 0.6, "c1", "During", datetime(2026, 1, 1),
         "Instore", "TXN", "instore"),
        ("j1", "l1", "txn-001", "b1", "single", "offer", True,
         "txn_c1", 0.4, "c2", "During", datetime(2026, 1, 1),
         "Fins - Main Estate", "Fins - Main Estate - Fully Branded", "instore"),
    ], schema=(
        "userjourney_id string, loyalty_id string, transaction_key string, "
        "booking_id string, customer_journey_type string, journey_type string, "
        "isconversion boolean, regression_variable string, normalized_weights double, "
        "campaign_id string, campaign_duration string, load_ts timestamp, "
        "channel_name string, subchannel_name string, marketing_type string"
    ))

    # customer_data_collection has per-SKU purchase rows for each attributed campaign.
    transaction_df = spark_session.createDataFrame([
        ("txn-001", "c1", txn_date, "SKU_A", 2.50, 2, "Brand_A", week_dt, campaign_start, campaign_end),
        ("txn-001", "c1", txn_date, "SKU_B", 1.25, 1, "Brand_B", week_dt, campaign_start, campaign_end),
        ("txn-001", "c2", txn_date, "SKU_A", 2.50, 2, "Brand_A", week_dt, campaign_start, campaign_end),
        ("txn-001", "c2", txn_date, "SKU_B", 1.25, 1, "Brand_B", week_dt, campaign_start, campaign_end),
    ], schema=(
        "transaction_key string, campaign_id string, event_dt date, "
        "item_cd string, net_sales_amt double, units_qty int, unique_brand_name string, "
        "week_start_dt date, campaign_start_dt date, campaign_end_dt date"
    ))

    # attribution_pre_req_df is still needed for total_sales_per_campaign calculation.
    # Purchase Transaction rows have campaign_id='NA'; touchpoints have real campaign_ids.
    attribution_pre_req_df = spark_session.createDataFrame([
        ("b1", "During", "offer", "txn_c1", 2.50, "j1", "NA", "txn-001", "Transaction"),
        ("b1", "During", "offer", "txn_c1", 1.25, "j1", "NA", "txn-001", "Transaction"),
        ("b1", "During", "offer", "txn_c1", 0.0, "j1", "c1", "NA", "Touchpoint"),
        ("b1", "During", "offer", "txn_c1", 0.0, "j1", "c2", "NA", "Touchpoint"),
    ], schema=(
        "booking_id string, campaign_duration string, journey_type string, "
        "regression_variable string, net_sales_amt double, "
        "userjourney_id string, campaign_id string, transaction_key string, event_name string"
    ))

    reach_engagement_df = spark_session.createDataFrame(
        [], schema="booking_id string, channel_name string, subchannel_name string, campaign_id string, sales_amt double"
    )
    offsite_subchannel_df = spark_session.createDataFrame([], schema="offsite_key string")

    all_campaigns_df = apply_campaign_duration_identifier_flag(camp_execution_df)

    _, sku_level_results_final = process_offer_attribution_multi_campaign(
        reach_engagement_df=reach_engagement_df,
        attribution_pre_req_df=attribution_pre_req_df,
        all_campaigns_df=all_campaigns_df,
        attribution_df=attribution_df,
        transaction_df=transaction_df,
        pipeline_run_type=PipelineRunType.pollen_run_type,
        offsite_subchannel_df=offsite_subchannel_df,
    )

    actual = sku_level_results_final.select(
        "campaign_id",
        "userjourney_id",
        "item_cd",
        "net_sales_amt",
        "units_qty",
        "unique_brand_name",
        "attributed_sales_amt",
        "attributed_recalibrated_sales_amt",
    )

    expected = spark_session.createDataFrame([
        ("c1", "j1", "SKU_A", 2.50, 2, "Brand_A", 1.50, 1.50),
        ("c1", "j1", "SKU_B", 1.25, 1, "Brand_B", 0.75, 0.75),
        ("c2", "j1", "SKU_A", 2.50, 2, "Brand_A", 1.00, 1.00),
        ("c2", "j1", "SKU_B", 1.25, 1, "Brand_B", 0.50, 0.50),
    ], schema=(
        "campaign_id string, userjourney_id string, item_cd string, "
        "net_sales_amt double, units_qty int, unique_brand_name string, "
        "attributed_sales_amt double, attributed_recalibrated_sales_amt double"
    ))

    assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)


def test_pollen_sku_details_populated_from_transaction_data(spark_session):
    """
    Pollen run: three campaigns share one journey with one transaction (txn-001)
    containing two SKUs. customer_data_collection has per-SKU purchase rows for
    each attributed campaign carrying real item_cd, units_qty and unique_brand_name.

    Verifies that the output has non-NULL item_cd, units_qty and unique_brand_name
    for all 6 rows (3 campaigns × 2 SKUs), matching the production data shape where
    item_cd=6853424 (£2.50, 2 units) and item_cd=6853415 (£1.25, 1 unit) appear
    in customer_data_collection with each attributed campaign's id.
    """
    campaign_start = date(2026, 1, 6)
    campaign_end = date(2026, 1, 28)
    txn_date = date(2026, 1, 21)
    week_dt = date(2026, 1, 19)

    camp_execution_df = spark_session.createDataFrame([
        ("b1", "During", "Social", "c_meta", campaign_start, campaign_end),
        ("b1", "During", "Digital Screens", "c_dscreen", campaign_start, campaign_end),
        ("b1", "During", "Fins - Main Estate", "c_fins", campaign_start, campaign_end),
    ], schema=(
        "booking_id string, campaign_duration string, channel_name string, "
        "campaign_id string, campaign_start_dt date, campaign_end_dt date"
    ))

    attribution_df = spark_session.createDataFrame([
        ("j1", "l1", "txn-001", "b1", "single", "offer", True,
         "OFFSITE_SOCIAL_txn", 0.25, "c_meta", "During", datetime(2026, 1, 1),
         "Social", "Social - Meta", "offsite"),
        ("j1", "l1", "txn-001", "b1", "single", "offer", True,
         "INSTORE_DSCREEN_txn", 0.25, "c_dscreen", "During", datetime(2026, 1, 1),
         "Digital Screens", "Digital Screens - InStore", "instore"),
        ("j1", "l1", "txn-001", "b1", "single", "offer", True,
         "INSTORE_FINS_txn", 0.50, "c_fins", "During", datetime(2026, 1, 1),
         "Fins - Main Estate", "Fins - Main Estate - Fully Branded", "instore"),
    ], schema=(
        "userjourney_id string, loyalty_id string, transaction_key string, "
        "booking_id string, customer_journey_type string, journey_type string, "
        "isconversion boolean, regression_variable string, normalized_weights double, "
        "campaign_id string, campaign_duration string, load_ts timestamp, "
        "channel_name string, subchannel_name string, marketing_type string"
    ))

    # customer_data_collection has per-SKU purchase rows for each attributed campaign.
    # SKU_A: £2.50 / 2 units, SKU_B: £1.25 / 1 unit.
    transaction_df = spark_session.createDataFrame([
        ("txn-001", "c_meta", txn_date, "SKU_A", 2.50, 2, "Brand_X", week_dt, campaign_start, campaign_end),
        ("txn-001", "c_meta", txn_date, "SKU_B", 1.25, 1, "Brand_Y", week_dt, campaign_start, campaign_end),
        ("txn-001", "c_dscreen", txn_date, "SKU_A", 2.50, 2, "Brand_X", week_dt, campaign_start, campaign_end),
        ("txn-001", "c_dscreen", txn_date, "SKU_B", 1.25, 1, "Brand_Y", week_dt, campaign_start, campaign_end),
        ("txn-001", "c_fins", txn_date, "SKU_A", 2.50, 2, "Brand_X", week_dt, campaign_start, campaign_end),
        ("txn-001", "c_fins", txn_date, "SKU_B", 1.25, 1, "Brand_Y", week_dt, campaign_start, campaign_end),
    ], schema=(
        "transaction_key string, campaign_id string, event_dt date, "
        "item_cd string, net_sales_amt double, units_qty int, unique_brand_name string, "
        "week_start_dt date, campaign_start_dt date, campaign_end_dt date"
    ))

    attribution_pre_req_df = spark_session.createDataFrame([
        ("b1", "During", "offer", "OFFSITE_SOCIAL_txn", 2.50, "j1", "NA", "txn-001", "Transaction"),
        ("b1", "During", "offer", "OFFSITE_SOCIAL_txn", 1.25, "j1", "NA", "txn-001", "Transaction"),
        ("b1", "During", "offer", "OFFSITE_SOCIAL_txn", 0.0, "j1", "c_meta", "NA", "Touchpoint"),
        ("b1", "During", "offer", "INSTORE_DSCREEN_txn", 0.0, "j1", "c_dscreen", "NA", "Touchpoint"),
        ("b1", "During", "offer", "INSTORE_FINS_txn", 0.0, "j1", "c_fins", "NA", "Touchpoint"),
    ], schema=(
        "booking_id string, campaign_duration string, journey_type string, "
        "regression_variable string, net_sales_amt double, "
        "userjourney_id string, campaign_id string, transaction_key string, event_name string"
    ))

    reach_engagement_df = spark_session.createDataFrame(
        [], schema="booking_id string, channel_name string, subchannel_name string, campaign_id string, sales_amt double"
    )
    offsite_subchannel_df = spark_session.createDataFrame([], schema="offsite_key string")

    all_campaigns_df = apply_campaign_duration_identifier_flag(camp_execution_df)

    _, sku_level_results_final = process_offer_attribution_multi_campaign(
        reach_engagement_df=reach_engagement_df,
        attribution_pre_req_df=attribution_pre_req_df,
        all_campaigns_df=all_campaigns_df,
        attribution_df=attribution_df,
        transaction_df=transaction_df,
        pipeline_run_type=PipelineRunType.pollen_run_type,
        offsite_subchannel_df=offsite_subchannel_df,
    )

    actual = sku_level_results_final.select(
        "campaign_id",
        "userjourney_id",
        "item_cd",
        "net_sales_amt",
        "units_qty",
        "unique_brand_name",
        "attributed_sales_amt",
        "attributed_recalibrated_sales_amt",
    )

    # 6 rows: 3 campaigns × 2 SKUs. All must have non-NULL item_cd, units_qty,
    # unique_brand_name. Weights: c_meta=0.25, c_dscreen=0.25, c_fins=0.50.
    expected = spark_session.createDataFrame([
        ("c_meta", "j1", "SKU_A", 2.50, 2, "Brand_X", 0.625, 0.625),
        ("c_meta", "j1", "SKU_B", 1.25, 1, "Brand_Y", 0.3125, 0.3125),
        ("c_dscreen", "j1", "SKU_A", 2.50, 2, "Brand_X", 0.625, 0.625),
        ("c_dscreen", "j1", "SKU_B", 1.25, 1, "Brand_Y", 0.3125, 0.3125),
        ("c_fins", "j1", "SKU_A", 2.50, 2, "Brand_X", 1.25, 1.25),
        ("c_fins", "j1", "SKU_B", 1.25, 1, "Brand_Y", 0.625, 0.625),
    ], schema=(
        "campaign_id string, userjourney_id string, item_cd string, "
        "net_sales_amt double, units_qty int, unique_brand_name string, "
        "attributed_sales_amt double, attributed_recalibrated_sales_amt double"
    ))

    assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)


def test_pollen_same_txn_key_same_journey_different_item_cd(spark_session):
    """
    Pollen run: same transaction_key and same userjourney_id, but two different
    item_cds in the basket.

    customer_data_collection carries per-(campaign_id, item_cd) rows, so for
    2 campaigns x 2 item_cds there are 4 rows in transaction_df. After the Pollen
    branch drops campaign_id and calls .distinct(), those collapse to 2 rows —
    one per item_cd. Joining attribution_df (2 campaigns) on transaction_key then
    fans each campaign back out to both item_cds.

    The key property being tested: both item_cds appear in every campaign's output,
    each with the correct net_sales_amt, units_qty and unique_brand_name.

    transaction_df (customer_data_collection shape):
      txn-001 / c1 / ITEM_X  ->  5.00, 3 units, "Brand_X"
      txn-001 / c1 / ITEM_Y  ->  2.00, 1 unit, "Brand_Y"
      txn-001 / c2 / ITEM_X  ->  5.00, 3 units, "Brand_X"
      txn-001 / c2 / ITEM_Y  ->  2.00, 1 unit, "Brand_Y"

    After drop(campaign_id).distinct():
      txn-001 / ITEM_X  ->  5.00, 3 units, "Brand_X"
      txn-001 / ITEM_Y  ->  2.00, 1 unit, "Brand_Y"

    Expected output (4 rows: 2 campaigns x 2 item_cds):
      c1 (weight=0.7): ITEM_X -> 3.50, ITEM_Y -> 1.40
      c2 (weight=0.3): ITEM_X -> 1.50, ITEM_Y -> 0.60
    """
    campaign_start = date(2026, 1, 6)
    campaign_end = date(2026, 1, 28)
    txn_date = date(2026, 1, 21)
    week_dt = date(2026, 1, 19)

    camp_execution_df = spark_session.createDataFrame([
        ("b1", "During", "Instore", "c1", campaign_start, campaign_end),
        ("b1", "During", "Fins - Main Estate", "c2", campaign_start, campaign_end),
    ], schema=(
        "booking_id string, campaign_duration string, channel_name string, "
        "campaign_id string, campaign_start_dt date, campaign_end_dt date"
    ))

    attribution_df = spark_session.createDataFrame([
        ("j1", "l1", "txn-001", "b1", "single", "offer", True,
         "INSTORE_TXN", 0.7, "c1", "During", datetime(2026, 1, 1),
         "Instore", "TXN", "instore"),
        ("j1", "l1", "txn-001", "b1", "single", "offer", True,
         "INSTORE_FINS_TXN", 0.3, "c2", "During", datetime(2026, 1, 1),
         "Fins - Main Estate", "Fins - Main Estate - Fully Branded", "instore"),
    ], schema=(
        "userjourney_id string, loyalty_id string, transaction_key string, "
        "booking_id string, customer_journey_type string, journey_type string, "
        "isconversion boolean, regression_variable string, normalized_weights double, "
        "campaign_id string, campaign_duration string, load_ts timestamp, "
        "channel_name string, subchannel_name string, marketing_type string"
    ))

    # Same transaction_key, same journey — two different item_cds.
    # Each item_cd appears once per attributed campaign in customer_data_collection.
    # After drop(campaign_id).distinct() these collapse to 2 rows (one per item_cd).
    transaction_df = spark_session.createDataFrame([
        ("txn-001", "c1", txn_date, "ITEM_X", 5.00, 3, "Brand_X", week_dt, campaign_start, campaign_end),
        ("txn-001", "c1", txn_date, "ITEM_Y", 2.00, 1, "Brand_Y", week_dt, campaign_start, campaign_end),
        ("txn-001", "c2", txn_date, "ITEM_X", 5.00, 3, "Brand_X", week_dt, campaign_start, campaign_end),
        ("txn-001", "c2", txn_date, "ITEM_Y", 2.00, 1, "Brand_Y", week_dt, campaign_start, campaign_end),
    ], schema=(
        "transaction_key string, campaign_id string, event_dt date, "
        "item_cd string, net_sales_amt double, units_qty int, unique_brand_name string, "
        "week_start_dt date, campaign_start_dt date, campaign_end_dt date"
    ))

    attribution_pre_req_df = spark_session.createDataFrame([
        ("b1", "During", "offer", "INSTORE_TXN", 5.00, "j1", "NA", "txn-001", "Transaction"),
        ("b1", "During", "offer", "INSTORE_TXN", 2.00, "j1", "NA", "txn-001", "Transaction"),
        ("b1", "During", "offer", "INSTORE_TXN", 0.0, "j1", "c1", "NA", "Touchpoint"),
        ("b1", "During", "offer", "INSTORE_FINS_TXN", 0.0, "j1", "c2", "NA", "Touchpoint"),
    ], schema=(
        "booking_id string, campaign_duration string, journey_type string, "
        "regression_variable string, net_sales_amt double, "
        "userjourney_id string, campaign_id string, transaction_key string, event_name string"
    ))

    reach_engagement_df = spark_session.createDataFrame(
        [], schema="booking_id string, channel_name string, subchannel_name string, campaign_id string, sales_amt double"
    )
    offsite_subchannel_df = spark_session.createDataFrame([], schema="offsite_key string")

    all_campaigns_df = apply_campaign_duration_identifier_flag(camp_execution_df)

    _, sku_level_results_final = process_offer_attribution_multi_campaign(
        reach_engagement_df=reach_engagement_df,
        attribution_pre_req_df=attribution_pre_req_df,
        all_campaigns_df=all_campaigns_df,
        attribution_df=attribution_df,
        transaction_df=transaction_df,
        pipeline_run_type=PipelineRunType.pollen_run_type,
        offsite_subchannel_df=offsite_subchannel_df,
    )

    actual = sku_level_results_final.select(
        "campaign_id",
        "userjourney_id",
        "item_cd",
        "net_sales_amt",
        "units_qty",
        "unique_brand_name",
        "attributed_sales_amt",
        "attributed_recalibrated_sales_amt",
    )

    expected = spark_session.createDataFrame([
        ("c1", "j1", "ITEM_X", 5.00, 3, "Brand_X", 3.50, 3.50),
        ("c1", "j1", "ITEM_Y", 2.00, 1, "Brand_Y", 1.40, 1.40),
        ("c2", "j1", "ITEM_X", 5.00, 3, "Brand_X", 1.50, 1.50),
        ("c2", "j1", "ITEM_Y", 2.00, 1, "Brand_Y", 0.60, 0.60),
    ], schema=(
        "campaign_id string, userjourney_id string, item_cd string, "
        "net_sales_amt double, units_qty int, unique_brand_name string, "
        "attributed_sales_amt double, attributed_recalibrated_sales_amt double"
    ))

    assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)
