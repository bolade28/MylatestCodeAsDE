from unittest import mock
import pytest
from pyspark.sql import SparkSession, Row
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

from spark_pipeline.sku_level_attribution.slack_notification import SKUAttributionValidationNotifier
from spark_pipeline.common.variables import MarketingTypes, PipelineRunType


@pytest.fixture
def spark():
    """Create a Spark session for testing."""
    return SparkSession.builder.master("local[1]").appName("test").getOrCreate()


@pytest.fixture
def mock_slack_messenger():
    """Create a mock SlackMessenger."""
    with mock.patch("spark_pipeline.sku_level_attribution.slack_notification.SlackMessenger") as mock_messenger:
        yield mock_messenger


@pytest.fixture
def notifier(mock_slack_messenger):
    """Create a SKUAttributionValidationNotifier with mocked SlackMessenger."""
    mock_instance = mock.MagicMock()
    mock_slack_messenger.return_value = mock_instance

    notifier = SKUAttributionValidationNotifier(
        slack_topic_arn="arn:aws:sns:region:account:topic",
        correlation_id="test-corr-id",
        product_type="aisle",
        pipeline_run_type=PipelineRunType.dtp_run_type,
    )
    notifier.slack_messenger = mock_instance
    return notifier


class TestValidateNegativeRecalibratedSales:
    """Tests for validate_negative_recalibrated_sales() method."""

    def test_no_negative_sales_sends_ok_status(self, spark, notifier):
        """When no negative values exist, should emit OK status."""
        df = spark.createDataFrame([
            Row(attributed_recalibrated_sales_amt=100.0),
            Row(attributed_recalibrated_sales_amt=250.5),
            Row(attributed_recalibrated_sales_amt=0.0),
        ], StructType([StructField("attributed_recalibrated_sales_amt", DoubleType())]))

        notifier.validate_negative_recalibrated_sales(df)

        notifier.slack_messenger.send_message.assert_called_once()
        call_args = notifier.slack_messenger.send_message.call_args

        assert call_args[1]["event_type"] == "SKU Level Attributed Sales and Units"
        assert call_args[1]["text"] == "[Validation] Recalibrated Sales Non-Negativity Check"
        assert call_args[1]["data"]["total_rows"] == 3
        assert call_args[1]["data"]["negative_recalibrated_sales_rows"] == 0
        assert call_args[1]["data"]["negative_recalibrated_sales_pct"] == 0.0
        assert call_args[1]["data"]["status"] == "OK"

    def test_with_negative_sales_sends_warning(self, spark, notifier):
        """When negative values exist, should emit WARNING status with count."""
        df = spark.createDataFrame([
            Row(attributed_recalibrated_sales_amt=100.0),
            Row(attributed_recalibrated_sales_amt=-50.0),
            Row(attributed_recalibrated_sales_amt=-25.5),
            Row(attributed_recalibrated_sales_amt=0.0),
        ], StructType([StructField("attributed_recalibrated_sales_amt", DoubleType())]))

        notifier.validate_negative_recalibrated_sales(df)

        call_args = notifier.slack_messenger.send_message.call_args
        data = call_args[1]["data"]

        assert data["total_rows"] == 4
        assert data["negative_recalibrated_sales_rows"] == 2
        assert data["negative_recalibrated_sales_pct"] == 50.0
        assert data["min_recalibrated_sales"] == -50.0
        assert "2 rows with negative recalibrated sales" in data["status"]

    def test_percentage_calculation_is_correct(self, spark, notifier):
        """Verify percentage calculation accuracy."""
        df = spark.createDataFrame([
            Row(attributed_recalibrated_sales_amt=float(i)) if i >= 0 else Row(attributed_recalibrated_sales_amt=float(i))
            for i in range(-3, 10)
        ], StructType([StructField("attributed_recalibrated_sales_amt", DoubleType())]))

        notifier.validate_negative_recalibrated_sales(df)

        call_args = notifier.slack_messenger.send_message.call_args
        data = call_args[1]["data"]

        # -3, -2, -1 are negative (3 rows), total 13 rows
        assert data["negative_recalibrated_sales_rows"] == 3
        assert data["total_rows"] == 13
        assert abs(data["negative_recalibrated_sales_pct"] - 23.08) < 0.01


class TestValidateNullRecalibrationFactorOffsite:
    """Tests for validate_null_recalibration_factor_offsite() method."""

    def test_no_offsite_rows_sends_ok(self, spark, notifier):
        """When no offsite rows exist, should emit OK status."""
        df = spark.createDataFrame([
            Row(marketing_type=MarketingTypes.ONSITE, recalibration_factor=1.5),
            Row(marketing_type=MarketingTypes.ONSITE, recalibration_factor=2.0),
        ], StructType([
            StructField("marketing_type", StringType()),
            StructField("recalibration_factor", DoubleType()),
        ]))

        notifier.validate_null_recalibration_factor_offsite(df)

        call_args = notifier.slack_messenger.send_message.call_args
        data = call_args[1]["data"]

        assert data["total_offsite_rows"] == 0
        assert data["null_factor_rows"] == 0
        assert data["status"] == "OK"

    def test_offsite_with_all_valid_factors_sends_ok(self, spark, notifier):
        """When all offsite rows have valid factors, should emit OK status."""
        df = spark.createDataFrame([
            Row(marketing_type=MarketingTypes.OFFSITE, recalibration_factor=1.5),
            Row(marketing_type=MarketingTypes.OFFSITE, recalibration_factor=2.0),
            Row(marketing_type=MarketingTypes.ONSITE, recalibration_factor=1.0),
        ], StructType([
            StructField("marketing_type", StringType()),
            StructField("recalibration_factor", DoubleType()),
        ]))

        notifier.validate_null_recalibration_factor_offsite(df)

        call_args = notifier.slack_messenger.send_message.call_args
        data = call_args[1]["data"]

        assert data["total_offsite_rows"] == 2
        assert data["null_factor_rows"] == 0
        assert data["status"] == "OK"

    def test_offsite_with_null_factors_sends_warning(self, spark, notifier):
        """When offsite rows have null factors, should emit WARNING status."""
        df = spark.createDataFrame([
            Row(marketing_type=MarketingTypes.OFFSITE, recalibration_factor=1.5),
            Row(marketing_type=MarketingTypes.OFFSITE, recalibration_factor=None),
            Row(marketing_type=MarketingTypes.OFFSITE, recalibration_factor=None),
            Row(marketing_type=MarketingTypes.ONSITE, recalibration_factor=1.0),
        ], StructType([
            StructField("marketing_type", StringType()),
            StructField("recalibration_factor", DoubleType()),
        ]))

        notifier.validate_null_recalibration_factor_offsite(df)

        call_args = notifier.slack_messenger.send_message.call_args
        data = call_args[1]["data"]

        assert data["total_offsite_rows"] == 3
        assert data["null_factor_rows"] == 2
        assert abs(data["null_factor_pct"] - 66.67) < 0.01
        assert "2 offsite rows have null recalibration factor" in data["status"]


class TestSendFinalValidationSummary:
    """Tests for send_final_validation_summary() method."""

    def test_healthy_data_sends_single_message(self, spark, notifier):
        """With healthy data, should send exactly one consolidated message."""
        df = spark.createDataFrame([
            Row(marketing_type=MarketingTypes.ONSITE, attributed_recalibrated_sales_amt=100.0, recalibration_factor=1.0),
            Row(marketing_type=MarketingTypes.OFFSITE, attributed_recalibrated_sales_amt=200.0, recalibration_factor=2.0),
            Row(marketing_type=MarketingTypes.OFFSITE, attributed_recalibrated_sales_amt=300.0, recalibration_factor=1.5),
        ], StructType([
            StructField("marketing_type", StringType()),
            StructField("attributed_recalibrated_sales_amt", DoubleType()),
            StructField("recalibration_factor", DoubleType()),
        ]))

        notifier.send_final_validation_summary(df)

        notifier.slack_messenger.send_message.assert_called_once()
        call_args = notifier.slack_messenger.send_message.call_args

        assert call_args[1]["event_type"] == "SKU Level Attributed Sales and Units"
        assert call_args[1]["text"] == "SKU Level Attribution Summary"

    def test_negative_and_null_factor_aggregations_correct(self, spark, notifier):
        """Verify aggregation calculations for negative sales and null factors."""
        df = spark.createDataFrame([
            Row(marketing_type=MarketingTypes.ONSITE, attributed_recalibrated_sales_amt=100.0, recalibration_factor=1.0),
            Row(marketing_type=MarketingTypes.ONSITE, attributed_recalibrated_sales_amt=-10.0, recalibration_factor=1.0),
            Row(marketing_type=MarketingTypes.ONSITE, attributed_recalibrated_sales_amt=-5.0, recalibration_factor=1.0),
            Row(marketing_type=MarketingTypes.OFFSITE, attributed_recalibrated_sales_amt=200.0, recalibration_factor=2.0),
            Row(marketing_type=MarketingTypes.OFFSITE, attributed_recalibrated_sales_amt=300.0, recalibration_factor=None),
            Row(marketing_type=MarketingTypes.OFFSITE, attributed_recalibrated_sales_amt=400.0, recalibration_factor=None),
        ], StructType([
            StructField("marketing_type", StringType()),
            StructField("attributed_recalibrated_sales_amt", DoubleType()),
            StructField("recalibration_factor", DoubleType()),
        ]))

        notifier.send_final_validation_summary(df)

        call_args = notifier.slack_messenger.send_message.call_args
        data = call_args[1]["data"]

        # 2 negative rows out of 6 total = 33.33%
        assert data["Negative Recalibrated Sales Rows"] == 2
        assert abs(data["Negative Recalibrated Sales Percentage"] - 33.33) < 0.01

        # 3 offsite rows, 2 with null factors = 66.67%
        assert data["Total Offsite Rows"] == 3
        assert data["Offsite Rows with Null Recalibration Factor"] == 2

    def test_product_type_is_included_in_metric_label(self, spark, notifier):
        """Metric label should include the product type (title-cased)."""
        df = spark.createDataFrame([
            Row(marketing_type=MarketingTypes.ONSITE, attributed_recalibrated_sales_amt=100.0, recalibration_factor=1.0),
        ], StructType([
            StructField("marketing_type", StringType()),
            StructField("attributed_recalibrated_sales_amt", DoubleType()),
            StructField("recalibration_factor", DoubleType()),
        ]))

        notifier.send_final_validation_summary(df)

        call_args = notifier.slack_messenger.send_message.call_args
        data = call_args[1]["data"]

        # "aisle" product_type should become "Aisle" in the label
        assert "Total SKU Level Attributed Sales and Units (Aisle)" in data
        assert data["Total SKU Level Attributed Sales and Units (Aisle)"] == 1

    def test_empty_dataframe_handles_gracefully(self, spark, notifier):
        """Empty DataFrame should emit 0 for all metrics."""
        df = spark.createDataFrame(
            [],
            StructType([
                StructField("marketing_type", StringType()),
                StructField("attributed_recalibrated_sales_amt", DoubleType()),
                StructField("recalibration_factor", DoubleType()),
            ])
        )

        notifier.send_final_validation_summary(df)

        call_args = notifier.slack_messenger.send_message.call_args
        data = call_args[1]["data"]

        assert data["Total Recalibrated Sales"] == 0
        assert data["Negative Recalibrated Sales Rows"] == 0
        assert data["Negative Recalibrated Sales Percentage"] == 0.0
        assert data["Total Offsite Rows"] == 0
        assert data["Offsite Rows with Null Recalibration Factor"] == 0


class TestSlackMessageFormat:
    """Tests for proper Slack message formatting across all validators."""

    def test_event_type_consistency(self, spark, notifier):
        """All messages should use correct event_type constant."""
        df = spark.createDataFrame([
            Row(marketing_type=MarketingTypes.ONSITE, attributed_recalibrated_sales_amt=100.0, recalibration_factor=1.0),
            Row(marketing_type=MarketingTypes.OFFSITE, attributed_recalibrated_sales_amt=200.0, recalibration_factor=2.0),
        ], StructType([
            StructField("marketing_type", StringType()),
            StructField("attributed_recalibrated_sales_amt", DoubleType()),
            StructField("recalibration_factor", DoubleType()),
        ]))

        # Test negative recalibrated sales
        notifier.validate_negative_recalibrated_sales(df)
        assert notifier.slack_messenger.send_message.call_args[1]["event_type"] == "SKU Level Attributed Sales and Units"

        notifier.slack_messenger.reset_mock()

        # Test null recalibration factor
        notifier.validate_null_recalibration_factor_offsite(df)
        assert notifier.slack_messenger.send_message.call_args[1]["event_type"] == "SKU Level Attributed Sales and Units"

        notifier.slack_messenger.reset_mock()

        # Test final summary
        notifier.send_final_validation_summary(df)
        assert notifier.slack_messenger.send_message.call_args[1]["event_type"] == "SKU Level Attributed Sales and Units"

    def test_text_labels_are_professional(self, spark, notifier):
        """Message text labels should be professional and descriptive."""
        df = spark.createDataFrame([
            Row(marketing_type=MarketingTypes.ONSITE, attributed_recalibrated_sales_amt=100.0, recalibration_factor=1.0),
        ], StructType([
            StructField("marketing_type", StringType()),
            StructField("attributed_recalibrated_sales_amt", DoubleType()),
            StructField("recalibration_factor", DoubleType()),
        ]))

        notifier.send_final_validation_summary(df)

        call_args = notifier.slack_messenger.send_message.call_args
        text = call_args[1]["text"]

        # Should not contain internal naming patterns
        assert "sku_level_attributed_sales_and_unit" not in text
        assert "SKU Level Attribution Summary" in text or text.startswith("[Validation]")

    def test_numeric_values_are_rounded_appropriately(self, spark, notifier):
        """Numeric values in messages should be rounded to 2 decimal places."""
        df = spark.createDataFrame([
            Row(marketing_type=MarketingTypes.ONSITE, attributed_recalibrated_sales_amt=100.123456, recalibration_factor=1.0),
            Row(marketing_type=MarketingTypes.OFFSITE, attributed_recalibrated_sales_amt=-50.987654, recalibration_factor=None),
        ], StructType([
            StructField("marketing_type", StringType()),
            StructField("attributed_recalibrated_sales_amt", DoubleType()),
            StructField("recalibration_factor", DoubleType()),
        ]))

        notifier.validate_negative_recalibrated_sales(df)

        call_args = notifier.slack_messenger.send_message.call_args
        data = call_args[1]["data"]

        # min_recalibrated_sales should be rounded
        assert data["min_recalibrated_sales"] == -50.99
        # percentage should be rounded
        assert isinstance(data["negative_recalibrated_sales_pct"], float)
