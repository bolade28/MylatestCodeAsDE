import pytest
from pyspark.sql import Row, SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from chispa.dataframe_comparer import assert_df_equality
from unittest.mock import ANY, Mock, patch

from spark_pipeline.attribution_model_results.helper_functions import (
    build_campaign_params,
    compute_channel_stats,
    compute_normalised_weights,
    get_training_params,
    lift_mta_weights,
    process_offer_synergy,
    raise_booking_processing_error,
    reconstruct_from_nested_journeys,
    reshape_to_long,
    resolve_booking_scope,
    resolve_journey_type,
    run_multi_booking_attribution,
    run_synergy_if_applicable,
    split_pos_neg_class,
    validate_class_distribution,
    create_empty_synergy_file
)
from spark_pipeline.schemas.attribution_model_dataset import AttributionModelDatasetSchema
from spark_pipeline.common.variables import AttributionModelResultConfig, PipelineRunType


class TestSplitPosNegClass:
    def test_split_pos_neg_class_binary_labels(self, spark_session: SparkSession):
        """Single campaign: both classes present."""
        test_data = [
            Row(booking_id="bk_01", campaign_duration="2024-Q1", user_id="U1", isconversion=1, feature1=0.5),
            Row(booking_id="bk_01", campaign_duration="2024-Q1", user_id="U2", isconversion=0, feature1=0.3),
            Row(booking_id="bk_01", campaign_duration="2024-Q1", user_id="U3", isconversion=1, feature1=0.8),
            Row(booking_id="bk_01", campaign_duration="2024-Q1", user_id="U4", isconversion=0, feature1=0.2),
        ]

        df = spark_session.createDataFrame(test_data)
        df_pos, df_neg, excluded = split_pos_neg_class(df, "isconversion")

        assert df_pos.count() == 2
        assert df_neg.count() == 2
        assert excluded == []
        assert all(row["isconversion"] == 1 for row in df_pos.collect())
        assert all(row["isconversion"] == 0 for row in df_neg.collect())

    def test_split_pos_neg_class_all_positive(self, spark_session: SparkSession):
        """Single booking with no negative samples is excluded — both returned DataFrames are empty."""
        test_data = [
            Row(booking_id="bk_01", campaign_duration="2024-Q1", user_id="U1", isconversion=1, feature1=0.5),
            Row(booking_id="bk_01", campaign_duration="2024-Q1", user_id="U2", isconversion=1, feature1=0.3),
        ]

        df = spark_session.createDataFrame(test_data)
        df_pos, df_neg, excluded = split_pos_neg_class(df, "isconversion")

        assert df_pos.isEmpty()
        assert df_neg.isEmpty()
        assert len(excluded) == 1
        assert excluded[0]["booking_id"] == "bk_01"
        assert "No negative samples" in excluded[0]["skip_reason"]

    def test_split_pos_neg_class_multi_booking_all_valid(self, spark_session: SparkSession):
        """
        Multi-booking input where all campaigns have both classes.

        Input shape (6 rows, 3 campaigns):
        +---------+-----------------+--------------+------------+
        |booking_id|campaign_duration|userjourney_id|isconversion|
        +---------+-----------------+--------------+------------+
        | bk_01   | 2024-01_2024-01  | uj_001       | 1          |
        | bk_01   | 2024-01_2024-01  | uj_002       | 0          |
        | bk_01   | 2024-01_2024-01  | uj_004       | 0          |
        | bk_03   | 2024-03_2024-03  | uj_005       | 1          |
        | bk_03   | 2024-03_2024-03  | uj_006       | 0          |
        +---------+-----------------+--------------+------------+

        Expected: df_pos has bk_01/uj_001 + bk_03/uj_005, df_neg has the rest.
        """
        test_data = [
            Row(booking_id="bk_01", campaign_duration="2024-01_2024-01", userjourney_id="uj_001", isconversion=1),
            Row(booking_id="bk_01", campaign_duration="2024-01_2024-01", userjourney_id="uj_002", isconversion=0),
            Row(booking_id="bk_01", campaign_duration="2024-01_2024-01", userjourney_id="uj_004", isconversion=0),
            Row(booking_id="bk_03", campaign_duration="2024-03_2024-03", userjourney_id="uj_005", isconversion=1),
            Row(booking_id="bk_03", campaign_duration="2024-03_2024-03", userjourney_id="uj_006", isconversion=0),
        ]

        df = spark_session.createDataFrame(test_data)
        df_pos, df_neg, excluded = split_pos_neg_class(df, "isconversion")

        pos_journeys = sorted([r["userjourney_id"] for r in df_pos.collect()])
        neg_journeys = sorted([r["userjourney_id"] for r in df_neg.collect()])

        assert pos_journeys == ["uj_001", "uj_005"]
        assert neg_journeys == ["uj_002", "uj_004", "uj_006"]
        assert excluded == []

    def test_split_pos_neg_class_multi_booking_one_invalid(self, spark_session: SparkSession):
        """
        Multi-booking input where bk_02 has only one conversion and no non-conversions.

        Expected: bk_02 is excluded with a warning; bk_01 and bk_03 are returned.
        """
        test_data = [
            Row(booking_id="bk_01", campaign_duration="2024-01_2024-01", userjourney_id="uj_001", isconversion=1),
            Row(booking_id="bk_01", campaign_duration="2024-01_2024-01", userjourney_id="uj_002", isconversion=0),
            Row(booking_id="bk_02", campaign_duration="2024-02_2024-02", userjourney_id="uj_003", isconversion=1),
            Row(booking_id="bk_03", campaign_duration="2024-03_2024-03", userjourney_id="uj_005", isconversion=1),
            Row(booking_id="bk_03", campaign_duration="2024-03_2024-03", userjourney_id="uj_006", isconversion=0),
        ]

        df = spark_session.createDataFrame(test_data)
        df_pos, df_neg, excluded = split_pos_neg_class(df, "isconversion")

        pos_journeys = sorted([r["userjourney_id"] for r in df_pos.collect()])
        neg_journeys = sorted([r["userjourney_id"] for r in df_neg.collect()])

        assert pos_journeys == ["uj_001", "uj_005"]
        assert neg_journeys == ["uj_002", "uj_006"]
        assert not any(r["booking_id"] == "bk_02" for r in df_pos.collect())
        assert not any(r["booking_id"] == "bk_02" for r in df_neg.collect())
        assert len(excluded) == 1
        assert excluded[0]["booking_id"] == "bk_02"
        assert "No negative samples" in excluded[0]["skip_reason"]


class TestProcessOfferSynergy:
    def test_process_offer_synergy_insufficient_channels(self, spark_session: SparkSession):
        """Test synergy analysis with insufficient channels (< 2)"""
        flattened_data = [
            Row(userjourney_id="U1", isconversion=1, channel1_feature=1.0),
        ]

        flattened_path = spark_session.createDataFrame(flattened_data)

        result = process_offer_synergy(
            spark=spark_session,
            flattened_path=flattened_path,
            regression_variable_list=["CHANNEL", "MARKETING_TYPE", "FEATURE"],
            booking_id="B001",
            campaign_duration="30",
            job_run_id="job123",
            synergy_output_path=None
        )

        # Should return original dataframe when insufficient channels
        assert_df_equality(result, flattened_path, ignore_row_order=True)

    def test_process_offer_synergy_with_interactions(self, spark_session: SparkSession):
        """Test synergy analysis with multiple channels creating interactions"""
        flattened_data = [
            Row(userjourney_id="U1", loyalty_id="L1", transaction_key="T1", booking_id="B001",
                customer_journey_type="offer", journey_type="offer", campaign_duration="30",
                isconversion=1, meta_search_feature=1.0, google_search_feature=1.0),
            Row(userjourney_id="U2", loyalty_id="L2", transaction_key="T2", booking_id="B001",
                customer_journey_type="offer", journey_type="offer", campaign_duration="30",
                isconversion=0, meta_search_feature=0.0, google_search_feature=1.0),
        ]

        flattened_path = spark_session.createDataFrame(flattened_data)

        result = process_offer_synergy(
            spark=spark_session,
            flattened_path=flattened_path,
            regression_variable_list=["CHANNEL", "MARKETING_TYPE", "FEATURE"],
            booking_id="B001",
            campaign_duration="30",
            job_run_id="job123",
            synergy_output_path=None
        )

        # Should have additional interaction columns if significant
        assert result.count() == flattened_path.count()


class TestGetTrainingParams:
    def test_get_training_params_extraction(self):
        """Test extraction of training parameters from config object"""
        class MockConfig:
            regression_variable_list = ["channel", "marketing_type"]
            schema = "test_schema"
            max_executors = 4
            test_size = 0.2
            n_bags = 10
            bal_ratio = 0.5
            f1_score_limit = 0.7
            high_conversion_bal_ratio = 0.8
            minimum_conversion_lower_limit = 5
            minimum_conversion_upper_limit = 50
            balance_increment = 0.1
            balance_decrement_small = 0.05
            balance_decrement_large = 0.2
            balance_ratio_factor = 0.1
            random_state = 42
            solver = "lbfgs"
            max_iter = 100

        config = MockConfig()
        params = get_training_params(config)

        assert params.regression_variable_list == ["CHANNEL", "MARKETING_TYPE"]  # Should be uppercase
        assert params.schema == "test_schema"
        assert params.max_executors == 4
        assert params.test_size == 0.2
        assert params.n_bags == 10
        assert params.bal_ratio == 0.5
        assert params.f1_score_limit == 0.7
        assert params.random_state == 42
        assert params.solver == "lbfgs"
        assert params.max_iter == 100


class TestEdgeCasesAndErrorScenarios:
    def test_empty_dataframe_handling(self, spark_session: SparkSession):
        """Test functions with empty DataFrames"""
        empty_schema = StructType([
            StructField("booking_id", StringType(), True),
            StructField("campaign_duration", StringType(), True),
            StructField("userjourney_id", StringType(), True),
            StructField("isconversion", IntegerType(), True)
        ])
        empty_df = spark_session.createDataFrame([], schema=empty_schema)

        df_pos, df_neg, excluded = split_pos_neg_class(empty_df, "isconversion")
        assert df_pos.count() == 0
        assert df_neg.count() == 0

    def test_data_type_consistency(self, spark_session: SparkSession):
        """Test functions handle different data types correctly"""
        test_data = [
            Row(booking_id="bk_01", campaign_duration="2024-Q1", userjourney_id="U1", isconversion=1, feature_int=5, feature_double=1.5, feature_string="high"),
            Row(booking_id="bk_01", campaign_duration="2024-Q1", userjourney_id="U2", isconversion=0, feature_int=2, feature_double=0.8, feature_string="low"),
        ]

        df = spark_session.createDataFrame(test_data)
        df_pos, df_neg, excluded = split_pos_neg_class(df, "isconversion")

        assert df_pos.count() == 1
        assert df_neg.count() == 1

        pos_row = df_pos.collect()[0]
        assert isinstance(pos_row["feature_int"], int)
        assert isinstance(pos_row["feature_double"], float)
        assert isinstance(pos_row["feature_string"], str)

    def test_large_dataset_performance_indicators(self, spark_session: SparkSession):
        """Test performance characteristics with moderately large datasets"""
        import random
        random.seed(42)

        large_data = []
        for i in range(1000):
            large_data.append(Row(
                booking_id="bk_01",
                campaign_duration="2024-Q1",
                userjourney_id=f"U{i}",
                isconversion=random.choice([0, 1]),
                feature1=random.uniform(0, 1),
                feature2=random.uniform(0, 1),
            ))

        # Ensure both classes exist deterministically for the single booking.
        large_data[0] = Row(booking_id="bk_01", campaign_duration="2024-Q1", userjourney_id="U0", isconversion=1, feature1=0.1, feature2=0.2)
        large_data[1] = Row(booking_id="bk_01", campaign_duration="2024-Q1", userjourney_id="U1", isconversion=0, feature1=0.2, feature2=0.3)

        large_df = spark_session.createDataFrame(large_data)

        df_pos, df_neg, excluded = split_pos_neg_class(large_df, "isconversion")
        total_count = df_pos.count() + df_neg.count()
        assert total_count == 1000

    def test_null_value_handling(self, spark_session: SparkSession):
        """Test handling of null values in DataFrames"""
        test_data = [
            Row(booking_id="bk_01", campaign_duration="2024-Q1", userjourney_id="U1", isconversion=1, feature1=0.8, feature2=None),
            Row(booking_id="bk_01", campaign_duration="2024-Q1", userjourney_id="U2", isconversion=0, feature1=None, feature2=0.9),
            Row(booking_id="bk_01", campaign_duration="2024-Q1", userjourney_id=None, isconversion=1, feature1=0.6, feature2=0.4),
        ]

        df = spark_session.createDataFrame(test_data)
        df_pos, df_neg, excluded = split_pos_neg_class(df, "isconversion")

        assert df_pos.count() == 2
        assert df_neg.count() == 1


LIFT_ID_COLS = [
    "userjourney_id",
    "loyalty_id",
    "transaction_key",
    "booking_id",
    "customer_journey_type",
    "journey_type",
    "campaign_duration",
]


class TestLiftMTA:
    def test_lift_mta_weights_isolated_per_booking(self, spark_session: SparkSession):
        """
        Lift is computed independently per (booking_id, campaign_duration).

        booking_1 (4 journeys, 3 channels: meta, dv360, onsite_banner):
            u1: converts, meta only           → p(conv|meta)  = 2/2
            u2: converts, meta only           → p(conv|meta)  = 2/2
            u3: no convert, dv360 only        → p(conv|dv360) = 0/1
            u7: no convert, onsite_banner only → p(conv|onsite_banner) = 0/1
            P(overall) = 2/4 = 0.5
            lift(meta)         = (2/2) / 0.5 = 2.0  → u1, u2 get meta=1.0
            lift(dv360)        = (0/1) / 0.5 = 0.0
            lift(onsite_banner)= (0/1) / 0.5 = 0.0

        booking_2 (4 journeys, 3 channels: meta, dv360, onsite_banner):
            u4: converts, dv360 only           → p(conv|dv360) = 2/2
            u5: converts, dv360 only           → p(conv|dv360) = 2/2
            u6: no convert, meta only          → p(conv|meta)  = 0/1
            u8: no convert, onsite_banner only → p(conv|onsite_banner) = 0/1
            By symmetry: u4, u5 get dv360=1.0, meta=0.0, onsite_banner=0.0
        """
        test_data = [
            # booking_1 — conversions: meta only
            Row(userjourney_id="u1", loyalty_id="l1", transaction_key="t1", booking_id="booking_1", customer_journey_type="Non-direct", journey_type="Brand", campaign_duration="during", isconversion=1, meta=1.0, dv360=0.0, onsite_banner=0.0),
            Row(userjourney_id="u2", loyalty_id="l2", transaction_key="t2", booking_id="booking_1", customer_journey_type="Non-direct", journey_type="Brand", campaign_duration="during", isconversion=1, meta=1.0, dv360=0.0, onsite_banner=0.0),
            # booking_1 — non-conversions: one dv360, one onsite_banner
            Row(userjourney_id="u3", loyalty_id="l3", transaction_key="t3", booking_id="booking_1", customer_journey_type="Direct", journey_type="Brand", campaign_duration="during", isconversion=0, meta=0.0, dv360=1.0, onsite_banner=0.0),
            Row(userjourney_id="u7", loyalty_id="l7", transaction_key="t7", booking_id="booking_1", customer_journey_type="Direct", journey_type="Brand", campaign_duration="during", isconversion=0, meta=0.0, dv360=0.0, onsite_banner=1.0),
            # booking_2 — conversions: dv360 only
            Row(userjourney_id="u4", loyalty_id="l4", transaction_key="t4", booking_id="booking_2", customer_journey_type="Non-direct", journey_type="Brand", campaign_duration="during", isconversion=1, meta=0.0, dv360=1.0, onsite_banner=0.0),
            Row(userjourney_id="u5", loyalty_id="l5", transaction_key="t5", booking_id="booking_2", customer_journey_type="Non-direct", journey_type="Brand", campaign_duration="during", isconversion=1, meta=0.0, dv360=1.0, onsite_banner=0.0),
            # booking_2 — non-conversions: one meta, one onsite_banner
            Row(userjourney_id="u6", loyalty_id="l6", transaction_key="t6", booking_id="booking_2", customer_journey_type="Direct", journey_type="Brand", campaign_duration="during", isconversion=0, meta=1.0, dv360=0.0, onsite_banner=0.0),
            Row(userjourney_id="u8", loyalty_id="l8", transaction_key="t8", booking_id="booking_2", customer_journey_type="Direct", journey_type="Brand", campaign_duration="during", isconversion=0, meta=0.0, dv360=0.0, onsite_banner=1.0),
        ]
        df = spark_session.createDataFrame(test_data)

        result_df = lift_mta_weights(df, id_cols=LIFT_ID_COLS, target_col="isconversion")
        rows = {
            (row["userjourney_id"], row["regression_variable"]): row
            for row in result_df.collect()
        }

        # Only conversion journeys survive; 4 journeys × 3 channels = 12 rows
        assert {uid for uid, _ in rows.keys()} == {"u1", "u2", "u4", "u5"}

        # booking_1: both conversion journeys attribute entirely to meta
        for uid in ("u1", "u2"):
            assert rows[(uid, "meta")]["normalized_weights"] == pytest.approx(1.0, rel=1e-6), f"{uid}: meta"
            assert rows[(uid, "dv360")]["normalized_weights"] == pytest.approx(0.0, abs=1e-6), f"{uid}: dv360"
            assert rows[(uid, "onsite_banner")]["normalized_weights"] == pytest.approx(0.0, abs=1e-6), f"{uid}: onsite_banner"

        # booking_2: both conversion journeys attribute entirely to dv360
        for uid in ("u4", "u5"):
            assert rows[(uid, "dv360")]["normalized_weights"] == pytest.approx(1.0, rel=1e-6), f"{uid}: dv360"
            assert rows[(uid, "meta")]["normalized_weights"] == pytest.approx(0.0, abs=1e-6), f"{uid}: meta"
            assert rows[(uid, "onsite_banner")]["normalized_weights"] == pytest.approx(0.0, abs=1e-6), f"{uid}: onsite_banner"

    def test_lift_mta_weights_splits_weight_equally_between_channels_with_same_lift(self, spark_session: SparkSession):
        """
        When two channels have equal lift, a conversion journey exposed to both splits weight 50/50.

        Setup (single booking, 2 channels: meta, dv360):
            u1: converts, meta + dv360   ← the journey we test (2 channels)
            u2: no convert, meta only    ← makes lift(meta) = P(1/2) / P(1/3) = 1.5
            u3: no convert, dv360 only   ← makes lift(dv360) = P(1/2) / P(1/3) = 1.5

        P(overall)    = 1/3
        lift(meta)    = (1/2) / (1/3) = 1.5
        lift(dv360)   = (1/2) / (1/3) = 1.5

        For u1: raw(meta) = 1.5 * 1.0 = 1.5, raw(dv360) = 1.5 * 1.0 = 1.5, sum = 3.0
        → normalized: meta = 0.5, dv360 = 0.5
        """
        test_data = [
            Row(userjourney_id="u1", loyalty_id="l1", transaction_key="t1", booking_id="b1", customer_journey_type="Non-direct", journey_type="Brand", campaign_duration="during", isconversion=1, meta=1.0, dv360=1.0),
            Row(userjourney_id="u2", loyalty_id="l2", transaction_key="t2", booking_id="b1", customer_journey_type="Direct", journey_type="Brand", campaign_duration="during", isconversion=0, meta=1.0, dv360=0.0),
            Row(userjourney_id="u3", loyalty_id="l3", transaction_key="t3", booking_id="b1", customer_journey_type="Direct", journey_type="Brand", campaign_duration="during", isconversion=0, meta=0.0, dv360=1.0),
        ]
        df = spark_session.createDataFrame(test_data)

        result_df = lift_mta_weights(df, id_cols=LIFT_ID_COLS, target_col="isconversion")
        rows = {
            (row["userjourney_id"], row["regression_variable"]): row
            for row in result_df.collect()
        }

        assert {uid for uid, _ in rows.keys()} == {"u1"}
        assert rows[("u1", "meta")]["normalized_weights"] == pytest.approx(0.5, rel=1e-6)
        assert rows[("u1", "dv360")]["normalized_weights"] == pytest.approx(0.5, rel=1e-6)
        assert (
            rows[("u1", "meta")]["normalized_weights"] + rows[("u1", "dv360")]["normalized_weights"]
            == pytest.approx(1.0, rel=1e-6)
        )


NESTED_SCHEMA = AttributionModelDatasetSchema.attribution_model_dataset_schema


def _make_nested_row(loyalty_id, isconversion, booking_id, journeys):
    """Build a single nested Row matching attribution_model_dataset_schema."""
    return (loyalty_id, isconversion, booking_id, "Non-direct", "30-days", "Brand", journeys)


def _journey(userjourney_id, transaction_key, reg_vars):
    """Build a journey struct from a dict of {name: value}."""
    reg_var_list = [{"name": k, "value": float(v)} for k, v in reg_vars.items()]
    return {"userjourney_id": userjourney_id, "transaction_key": transaction_key, "regression_variables": reg_var_list}


class TestReconstructFromNestedJourneys:

    def test_reconstructs_one_row_per_journey(self, spark_session):
        journey_a = _journey("j001", "tx001", {"email_newsletter": 1.0, "dv360_banner": 0.0})
        journey_b = _journey("j002", "tx002", {"email_newsletter": 0.0, "dv360_banner": 1.0})
        data = [_make_nested_row("user_001", 1, "booking_123", [journey_a, journey_b])]
        nested_df = spark_session.createDataFrame(data, NESTED_SCHEMA)

        result = reconstruct_from_nested_journeys(nested_df, AttributionModelDatasetSchema.journey_schema)

        assert result.count() == 2

    def test_regression_variable_columns_are_pivoted(self, spark_session):
        journey = _journey("j001", "tx001", {"email_newsletter": 2.0, "dv360_banner": 3.0})
        data = [_make_nested_row("user_001", 1, "booking_123", [journey])]
        nested_df = spark_session.createDataFrame(data, NESTED_SCHEMA)

        result = reconstruct_from_nested_journeys(nested_df, AttributionModelDatasetSchema.journey_schema)

        assert "email_newsletter" in result.columns
        assert "dv360_banner" in result.columns
        row = result.collect()[0]
        assert row["email_newsletter"] == 2.0
        assert row["dv360_banner"] == 3.0

    def test_missing_variable_filled_with_zero(self, spark_session):
        journey_a = _journey("j001", "tx001", {"email_newsletter": 1.0})
        journey_b = _journey("j002", "tx002", {"dv360_banner": 1.0})
        data = [_make_nested_row("user_001", 1, "booking_123", [journey_a, journey_b])]
        nested_df = spark_session.createDataFrame(data, NESTED_SCHEMA)

        result = reconstruct_from_nested_journeys(nested_df, AttributionModelDatasetSchema.journey_schema)

        rows = {row["userjourney_id"]: row for row in result.collect()}
        assert rows["j001"]["dv360_banner"] == 0.0
        assert rows["j002"]["email_newsletter"] == 0.0

    def test_top_level_columns_preserved(self, spark_session):
        journey = _journey("j001", "tx001", {"email_newsletter": 1.0})
        data = [_make_nested_row("user_42", 1, "booking_999", [journey])]
        nested_df = spark_session.createDataFrame(data, NESTED_SCHEMA)

        result = reconstruct_from_nested_journeys(nested_df, AttributionModelDatasetSchema.journey_schema)

        row = result.collect()[0]
        assert row["loyalty_id"] == "user_42"
        assert row["booking_id"] == "booking_999"
        assert row["isconversion"] == 1
        assert row["customer_journey_type"] == "Non-direct"
        assert row["campaign_duration"] == "30-days"
        assert row["journey_type"] == "Brand"

    def test_multiple_loyalty_ids_produce_separate_rows(self, spark_session):
        data = [
            _make_nested_row("user_001", 1, "booking_123", [_journey("j001", "tx001", {"ch_a": 1.0})]),
            _make_nested_row("user_002", 0, "booking_456", [_journey("j002", "tx002", {"ch_a": 0.5})]),
        ]
        nested_df = spark_session.createDataFrame(data, NESTED_SCHEMA)

        result = reconstruct_from_nested_journeys(nested_df, AttributionModelDatasetSchema.journey_schema)

        loyalty_ids = {row["loyalty_id"] for row in result.collect()}
        assert loyalty_ids == {"user_001", "user_002"}


class TestRunMultiBookingAttribution:

    def test_run_multi_booking_attribution_supports_multi_scope(self, spark_session: SparkSession):
        flattened_df = spark_session.createDataFrame([
            Row(userjourney_id="u1", loyalty_id="l1", transaction_key="t1", booking_id="b1", customer_journey_type="Non-direct", journey_type="Brand", campaign_duration="c1", isconversion=1, feature_a=1.0),
            Row(userjourney_id="u2", loyalty_id="l2", transaction_key="t2", booking_id="b1", customer_journey_type="Direct", journey_type="Brand", campaign_duration="c1", isconversion=0, feature_a=0.0),
            Row(userjourney_id="u3", loyalty_id="l3", transaction_key="t3", booking_id="b2", customer_journey_type="Non-direct", journey_type="Brand", campaign_duration="c2", isconversion=1, feature_a=1.0),
            Row(userjourney_id="u4", loyalty_id="l4", transaction_key="t4", booking_id="b2", customer_journey_type="Direct", journey_type="Brand", campaign_duration="c2", isconversion=0, feature_a=0.0),
        ])

        stats_df = spark_session.createDataFrame([
            Row(booking_id="b1", campaign_duration="c1", total_conversions=1, total_nonconversions=1, conversion_rate=50.0),
            Row(booking_id="b2", campaign_duration="c2", total_conversions=1, total_nonconversions=1, conversion_rate=50.0),
        ])

        journey_channel_metadata_df = spark_session.createDataFrame([
            Row(userjourney_id="u1", regression_variable="FEATURE_A", booking_id="b1", campaign_duration="c1", channel_name="na", subchannel_name="na", marketing_type="na", campaign_id="na"),
            Row(userjourney_id="u3", regression_variable="FEATURE_A", booking_id="b2", campaign_duration="c2", channel_name="na", subchannel_name="na", marketing_type="na", campaign_id="na"),
        ])

        mock_result_df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="c1", regression_variable="FEATURE_A", normalized_weights=1.0)
        ])

        params = AttributionModelResultConfig()
        slack_notifier = Mock()

        with patch("spark_pipeline.attribution_model_results.helper_functions.process_attribution_model_lift") as mock_process:
            mock_process.return_value = [mock_result_df]

            campaign_results, conversion_rate = run_multi_booking_attribution(
                spark=spark_session,
                attribution_model_dataset_flattened=flattened_df,
                booking_id="b1",
                campaign_duration="c1",
                is_dtp=False,
                journey_type="brand",
                synergy_output_path=None,
                params=params,
                stats_df=stats_df,
                journey_channel_metadata_df=journey_channel_metadata_df,
                run_type=PipelineRunType().pollen_run_type,
                slack_notifier=slack_notifier,
                job_run_id="job_1",
                non_train_cols=[
                    "userjourney_id",
                    "loyalty_id",
                    "transaction_key",
                    "booking_id",
                    "customer_journey_type",
                    "journey_type",
                    "campaign_duration",
                ],
                label_col="isconversion",
                booking_scope=[("b1", "c1"), ("b2", "c2")],
            )

        assert len(campaign_results) == 1
        assert conversion_rate == pytest.approx(50.0)
        assert mock_process.call_count == 1


RESHAPE_ID_COLS = ["userjourney_id", "booking_id", "campaign_duration"]


class TestReshapeToLong:
    def test_long_df_has_one_row_per_journey_per_channel(self, spark_session: SparkSession):
        """Two channels produce two long rows per journey."""
        df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="During", isconversion=1, meta=1.0, dv360=0.0),
        ])
        _, long_df, _ = reshape_to_long(df, RESHAPE_ID_COLS, "isconversion")

        assert long_df.count() == 2
        assert "channel_name" in long_df.columns
        assert "channel_value" in long_df.columns

    def test_base_df_subchannel_columns_cast_to_double(self, spark_session: SparkSession):
        """Integer subchannel column is cast to double in base_df."""
        df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="During", isconversion=1, meta=1),
        ])
        base_df, _, _ = reshape_to_long(df, RESHAPE_ID_COLS, "isconversion")

        assert dict(base_df.dtypes)["meta"] == "double"

    def test_raises_when_no_subchannel_columns(self, spark_session: SparkSession):
        """ValueError when every column is an id_col or target_col."""
        df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="During", isconversion=1),
        ])
        with pytest.raises(ValueError, match="No subchannel feature columns detected"):
            reshape_to_long(df, RESHAPE_ID_COLS, "isconversion")

    def test_id_cols_preserved_in_long_df(self, spark_session: SparkSession):
        """All id_cols appear in the long-format output."""
        df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="During", isconversion=1, meta=1.0),
        ])
        _, long_df, _ = reshape_to_long(df, RESHAPE_ID_COLS, "isconversion")

        for col in RESHAPE_ID_COLS:
            assert col in long_df.columns


class TestComputeChannelStats:
    def test_overall_stats_n_all_and_y_all(self, spark_session: SparkSession):
        """n_all = total journeys, y_all = total conversions per booking."""
        df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="During", isconversion=1, meta=1.0, dv360=0.0),
            Row(userjourney_id="u2", booking_id="b1", campaign_duration="During", isconversion=1, meta=0.0, dv360=1.0),
            Row(userjourney_id="u3", booking_id="b1", campaign_duration="During", isconversion=0, meta=1.0, dv360=0.0),
        ])
        base_df, long_df, target_col_double = reshape_to_long(df, RESHAPE_ID_COLS, "isconversion")

        overall_stats_df, _ = compute_channel_stats(base_df, long_df, target_col_double)

        row = overall_stats_df.collect()[0]
        assert row["n_all"] == 3
        assert row["y_all"] == pytest.approx(2.0)

    def test_subchannel_stats_n_c_and_y_c(self, spark_session: SparkSession):
        """n_c = journeys where channel present, y_c = converting journeys where channel present."""
        df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="During", isconversion=1, meta=1.0, dv360=0.0),
            Row(userjourney_id="u2", booking_id="b1", campaign_duration="During", isconversion=0, meta=1.0, dv360=0.0),
            Row(userjourney_id="u3", booking_id="b1", campaign_duration="During", isconversion=0, meta=0.0, dv360=1.0),
        ])
        base_df, long_df, target_col_double = reshape_to_long(df, RESHAPE_ID_COLS, "isconversion")

        _, subchannel_stats_df = compute_channel_stats(base_df, long_df, target_col_double)

        rows = {r["channel_name"]: r for r in subchannel_stats_df.collect()}
        assert rows["meta"]["n_c"] == pytest.approx(2.0)   # u1 + u2 both had meta
        assert rows["meta"]["y_c"] == pytest.approx(1.0)   # only u1 converted
        assert rows["dv360"]["n_c"] == pytest.approx(1.0)  # only u3 had dv360
        assert rows["dv360"]["y_c"] == pytest.approx(0.0)  # u3 did not convert

    def test_channel_with_no_exposure_gets_zero_stats(self, spark_session: SparkSession):
        """A channel never present in any journey gets n_c=0, y_c=0."""
        df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="During", isconversion=1, meta=1.0, dv360=0.0),
            Row(userjourney_id="u2", booking_id="b1", campaign_duration="During", isconversion=0, meta=1.0, dv360=0.0),
        ])
        base_df, long_df, target_col_double = reshape_to_long(df, RESHAPE_ID_COLS, "isconversion")

        _, subchannel_stats_df = compute_channel_stats(base_df, long_df, target_col_double)

        rows = {r["channel_name"]: r for r in subchannel_stats_df.collect()}
        assert rows["dv360"]["n_c"] == pytest.approx(0.0)
        assert rows["dv360"]["y_c"] == pytest.approx(0.0)


class TestComputeNormalisedWeights:
    def test_only_conversion_journeys_in_output(self, spark_session: SparkSession):
        """Non-converting journeys are filtered out."""
        df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="During", isconversion=1, meta=1.0, dv360=0.0),
            Row(userjourney_id="u2", booking_id="b1", campaign_duration="During", isconversion=0, meta=1.0, dv360=0.0),
        ])
        base_df, long_df, target_col_double = reshape_to_long(df, RESHAPE_ID_COLS, "isconversion")
        overall, subchannel = compute_channel_stats(base_df, long_df, target_col_double)

        result = compute_normalised_weights(long_df, overall, subchannel, RESHAPE_ID_COLS, "isconversion", target_col_double)

        journey_ids = {r["userjourney_id"] for r in result.collect()}
        assert journey_ids == {"u1"}

    def test_weights_sum_to_one_per_journey(self, spark_session: SparkSession):
        """normalized_weights for all channels of one journey sum to 1.0."""
        df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="During", isconversion=1, meta=1.0, dv360=1.0),
            Row(userjourney_id="u2", booking_id="b1", campaign_duration="During", isconversion=0, meta=1.0, dv360=0.0),
            Row(userjourney_id="u3", booking_id="b1", campaign_duration="During", isconversion=0, meta=0.0, dv360=1.0),
        ])
        base_df, long_df, target_col_double = reshape_to_long(df, RESHAPE_ID_COLS, "isconversion")
        overall, subchannel = compute_channel_stats(base_df, long_df, target_col_double)

        result = compute_normalised_weights(long_df, overall, subchannel, RESHAPE_ID_COLS, "isconversion", target_col_double)

        total = (
            result.filter(result.userjourney_id == "u1")
            .agg({"normalized_weights": "sum"})
            .collect()[0][0]
        )
        assert total == pytest.approx(1.0, rel=1e-6)

    def test_zero_lift_channel_gets_zero_weight(self, spark_session: SparkSession):
        """A channel that never co-occurs with a conversion gets weight 0."""
        df = spark_session.createDataFrame([
            Row(userjourney_id="u1", booking_id="b1", campaign_duration="During", isconversion=1, meta=1.0, dv360=0.0),
            Row(userjourney_id="u2", booking_id="b1", campaign_duration="During", isconversion=0, meta=0.0, dv360=1.0),
        ])
        base_df, long_df, target_col_double = reshape_to_long(df, RESHAPE_ID_COLS, "isconversion")
        overall, subchannel = compute_channel_stats(base_df, long_df, target_col_double)

        result = compute_normalised_weights(long_df, overall, subchannel, RESHAPE_ID_COLS, "isconversion", target_col_double)

        rows = {r["regression_variable"]: r for r in result.filter(result.userjourney_id == "u1").collect()}
        assert rows["dv360"]["normalized_weights"] == pytest.approx(0.0, abs=1e-9)
        assert rows["meta"]["normalized_weights"] == pytest.approx(1.0, rel=1e-6)


class TestResolveBookingScope:
    def test_single_booking_wraps_into_dataframe(self, spark_session: SparkSession):
        """No scope supplied — (booking_id, campaign_duration) is wrapped into a 1-row DF."""
        df, size = resolve_booking_scope(spark_session, "b1", "During", None, None, None)

        assert size == 1
        rows = df.collect()
        assert len(rows) == 1
        assert rows[0]["booking_id"] == "b1"
        assert rows[0]["campaign_duration"] == "During"

    def test_list_scope_creates_dataframe_with_correct_size(self, spark_session: SparkSession):
        """booking_scope list is converted to a DataFrame; size matches list length."""
        scope = [("b1", "During"), ("b2", "8W")]
        df, size = resolve_booking_scope(spark_session, "ignored", "ignored", scope, None, None)

        assert size == 2
        booking_ids = {r["booking_id"] for r in df.collect()}
        assert booking_ids == {"b1", "b2"}

    def test_pre_built_df_is_deduplicated(self, spark_session: SparkSession):
        """Duplicate rows in a pre-built scope DF are removed."""
        pre_df = spark_session.createDataFrame([
            Row(booking_id="b1", campaign_duration="During"),
            Row(booking_id="b1", campaign_duration="During"),
        ])
        df, size = resolve_booking_scope(spark_session, "x", "x", None, pre_df, 1)

        assert size == 1
        assert df.count() == 1

    def test_pre_computed_size_is_used_as_is(self, spark_session: SparkSession):
        """Pre-computed booking_scope_size avoids a .count() — value is returned unchanged."""
        scope = [("b1", "During"), ("b2", "8W")]
        _, size = resolve_booking_scope(spark_session, "b1", "During", scope, None, 99)

        assert size == 99


class TestRaiseBookingProcessingError:
    def test_always_raises_runtime_error_with_message(self):
        """RuntimeError is raised with the given error message."""
        with pytest.raises(RuntimeError, match="something went wrong"):
            raise_booking_processing_error("something went wrong", "code", Mock(), "b1", Mock())

    def test_sends_slack_notification_with_correct_args(self):
        """Slack is notified with the correct booking context, message, and error code."""
        slack_notifier = Mock()
        with pytest.raises(RuntimeError):
            raise_booking_processing_error("msg", "my_code", Mock(), "b1", slack_notifier)

        slack_notifier.send_campaign_specific_error.assert_called_once_with("b1", "msg", "my_code")

    def test_unpersists_model_data_before_raising(self):
        """model_data.unpersist() is called before the error is raised."""
        model_data = Mock()
        with pytest.raises(RuntimeError):
            raise_booking_processing_error("msg", "code", model_data, "b1", Mock())

        model_data.unpersist.assert_called_once()

    def test_chains_cause_exception(self):
        """When cause is provided, the RuntimeError is chained from it."""
        original = ValueError("root cause")
        with pytest.raises(RuntimeError) as exc_info:
            raise_booking_processing_error("wrapper", "code", Mock(), "b1", Mock(), cause=original)

        assert exc_info.value.__cause__ is original

    def test_no_cause_does_not_chain(self):
        """When cause is omitted, __cause__ is None."""
        with pytest.raises(RuntimeError) as exc_info:
            raise_booking_processing_error("msg", "code", Mock(), "b1", Mock())

        assert exc_info.value.__cause__ is None


class TestValidateClassDistribution:
    def test_passes_silently_when_both_classes_present(self, spark_session: SparkSession):
        """No exception raised and no Slack alert sent when both classes have rows."""
        slack_notifier = Mock()
        df_pos = spark_session.createDataFrame([Row(a=1)])
        df_neg = spark_session.createDataFrame([Row(a=0)])

        validate_class_distribution(df_pos, df_neg, Mock(), "b1", slack_notifier)

        slack_notifier.send_campaign_specific_error.assert_not_called()

    def test_raises_and_notifies_when_no_positives(self, spark_session: SparkSession):
        """RuntimeError raised with no_positive_samples code when df_pos is empty."""
        slack_notifier = Mock()
        empty = spark_session.createDataFrame([], "a INT")
        df_neg = spark_session.createDataFrame([Row(a=0)])

        with pytest.raises(RuntimeError, match="No positive samples"):
            validate_class_distribution(empty, df_neg, Mock(), "b1", slack_notifier)

        slack_notifier.send_campaign_specific_error.assert_called_once_with(
            "b1", ANY, "no_positive_samples"
        )

    def test_raises_and_notifies_when_no_negatives(self, spark_session: SparkSession):
        """RuntimeError raised with no_negative_samples code when df_neg is empty."""
        slack_notifier = Mock()
        df_pos = spark_session.createDataFrame([Row(a=1)])
        empty = spark_session.createDataFrame([], "a INT")

        with pytest.raises(RuntimeError, match="No negative samples"):
            validate_class_distribution(df_pos, empty, Mock(), "b1", slack_notifier)

        slack_notifier.send_campaign_specific_error.assert_called_once_with(
            "b1", ANY, "no_negative_samples"
        )

    def test_unpersists_model_data_on_failure(self, spark_session: SparkSession):
        """model_data is unpersisted before raising on either failure path."""
        model_data = Mock()
        empty = spark_session.createDataFrame([], "a INT")
        df_other = spark_session.createDataFrame([Row(a=1)])

        with pytest.raises(RuntimeError):
            validate_class_distribution(empty, df_other, model_data, "b1", Mock())

        model_data.unpersist.assert_called_once()


class TestResolveJourneyType:
    def test_pollen_returns_passed_journey_type(self, spark_session: SparkSession):
        """For Pollen (is_dtp=False), the caller-supplied value is returned unchanged."""
        df = spark_session.createDataFrame([Row(journey_type="standard")])
        result = resolve_journey_type(df, is_dtp=False, journey_type="pollen_value", booking_context="b1")

        assert result == "pollen_value"

    def test_dtp_reads_journey_type_from_data(self, spark_session: SparkSession):
        """For DTP with a single journey type, the value from data is returned."""
        df = spark_session.createDataFrame([
            Row(journey_type="offer"),
            Row(journey_type="offer"),
        ])
        result = resolve_journey_type(df, is_dtp=True, journey_type="ignored", booking_context="b1")

        assert result == "offer"

    def test_dtp_mixed_types_falls_back_to_passed_value(self, spark_session: SparkSession):
        """For DTP with multiple distinct journey types, the passed value is kept and a warning logged."""
        df = spark_session.createDataFrame([
            Row(journey_type="offer"),
            Row(journey_type="standard"),
        ])
        result = resolve_journey_type(df, is_dtp=True, journey_type="fallback", booking_context="b1")

        assert result == "fallback"

    def test_dtp_raises_when_no_journey_type_rows(self, spark_session: SparkSession):
        """For DTP with an empty DataFrame, RuntimeError is raised."""
        empty_df = spark_session.createDataFrame([], "journey_type STRING")

        with pytest.raises(RuntimeError, match="No journey type found"):
            resolve_journey_type(empty_df, is_dtp=True, journey_type="any", booking_context="b1")


class TestBuildCampaignParams:
    def test_conversion_rate_computed_correctly(self, spark_session: SparkSession):
        """conversion_rate = (conversions / total) * 100."""
        params = AttributionModelResultConfig()
        scope_df = spark_session.createDataFrame([Row(booking_id="b1", campaign_duration="During")])
        stats_df = spark_session.createDataFrame([
            Row(booking_id="b1", campaign_duration="During", total_conversions=25, total_nonconversions=75),
        ])

        _, conversion_rate = build_campaign_params(
            params, stats_df, scope_df,
            booking_id="b1", campaign_duration="During",
            booking_scope_size=1, booking_context="b1",
            journey_type_from_data="standard",
            job_run_id="run_1", label_col="isconversion",
        )

        assert conversion_rate == pytest.approx(25.0)

    def test_campaign_params_dict_contains_expected_keys(self, spark_session: SparkSession):
        """Returned dict includes all fields injected by build_campaign_params."""
        params = AttributionModelResultConfig()
        scope_df = spark_session.createDataFrame([Row(booking_id="b1", campaign_duration="During")])
        stats_df = spark_session.createDataFrame([
            Row(booking_id="b1", campaign_duration="During", total_conversions=10, total_nonconversions=10),
        ])

        campaign_params, _ = build_campaign_params(
            params, stats_df, scope_df,
            booking_id="b1", campaign_duration="During",
            booking_scope_size=1, booking_context="b1",
            journey_type_from_data="offer",
            job_run_id="run_1", label_col="isconversion",
        )

        assert campaign_params["booking_id"] == "b1"
        assert campaign_params["journey_type"] == "offer"
        assert campaign_params["job_run_id"] == "run_1_b1_During"
        assert campaign_params["label_col"] == "isconversion"
        assert campaign_params["pred_col"] == "predicted_conversion"

    def test_multi_booking_job_run_id_uses_batch_suffix(self, spark_session: SparkSession):
        """For multi-booking scopes, job_run_id ends with _multi_booking_batch."""
        params = AttributionModelResultConfig()
        scope_df = spark_session.createDataFrame([
            Row(booking_id="b1", campaign_duration="During"),
            Row(booking_id="b2", campaign_duration="During"),
        ])
        stats_df = spark_session.createDataFrame([
            Row(booking_id="b1", campaign_duration="During", total_conversions=5, total_nonconversions=5),
            Row(booking_id="b2", campaign_duration="During", total_conversions=5, total_nonconversions=5),
        ])

        campaign_params, _ = build_campaign_params(
            params, stats_df, scope_df,
            booking_id="b1", campaign_duration="During",
            booking_scope_size=2, booking_context="2 bookings",
            journey_type_from_data="standard",
            job_run_id="run_1", label_col="isconversion",
        )

        assert campaign_params["job_run_id"] == "run_1_multi_booking_batch"
        assert campaign_params["booking_id"] == "2 bookings"

    def test_zero_total_journeys_returns_zero_conversion_rate(self, spark_session: SparkSession):
        """If both totals are None/zero, conversion_rate is 0.0 (no division by zero)."""
        params = AttributionModelResultConfig()
        scope_df = spark_session.createDataFrame([Row(booking_id="b1", campaign_duration="During")])
        stats_schema = StructType([
            StructField("booking_id", StringType(), True),
            StructField("campaign_duration", StringType(), True),
            StructField("total_conversions", IntegerType(), True),
            StructField("total_nonconversions", IntegerType(), True),
        ])
        stats_df = spark_session.createDataFrame([
            Row(booking_id="b1", campaign_duration="During", total_conversions=None, total_nonconversions=None),
        ], schema=stats_schema)

        _, conversion_rate = build_campaign_params(
            params, stats_df, scope_df,
            booking_id="b1", campaign_duration="During",
            booking_scope_size=1, booking_context="b1",
            journey_type_from_data="standard",
            job_run_id="run_1", label_col="isconversion",
        )

        assert conversion_rate == pytest.approx(0.0)


class TestRunSynergyIfApplicable:
    def test_pollen_skips_synergy_and_returns_original_df(self, spark_session: SparkSession):
        """is_dtp=False always returns flattened_path unchanged."""
        flattened_path = spark_session.createDataFrame([Row(journey_type="offer", isconversion=1)])
        params = AttributionModelResultConfig()

        result = run_synergy_if_applicable(
            spark_session, flattened_path, params,
            booking_id="b1", campaign_duration="During",
            job_run_id="run_1", synergy_output_path=None,
            is_dtp=False, journey_type_from_data="offer",
            booking_scope_size=1, booking_context="b1",
        )

        assert result is flattened_path

    def test_dtp_non_offer_skips_synergy(self, spark_session: SparkSession):
        """DTP standard journey returns flattened_path unchanged."""
        flattened_path = spark_session.createDataFrame([Row(journey_type="standard", isconversion=1)])
        params = AttributionModelResultConfig()

        result = run_synergy_if_applicable(
            spark_session, flattened_path, params,
            booking_id="b1", campaign_duration="During",
            job_run_id="run_1", synergy_output_path=None,
            is_dtp=True, journey_type_from_data="standard",
            booking_scope_size=1, booking_context="b1",
        )

        assert result is flattened_path

    def test_dtp_multi_booking_skips_synergy(self, spark_session: SparkSession):
        """DTP offer with booking_scope_size > 1 returns flattened_path unchanged."""
        flattened_path = spark_session.createDataFrame([Row(journey_type="offer", isconversion=1)])
        params = AttributionModelResultConfig()

        result = run_synergy_if_applicable(
            spark_session, flattened_path, params,
            booking_id="b1", campaign_duration="During",
            job_run_id="run_1", synergy_output_path=None,
            is_dtp=True, journey_type_from_data="offer",
            booking_scope_size=3, booking_context="3 bookings",
        )

        assert result is flattened_path

    def test_dtp_offer_single_booking_calls_process_offer_synergy(self, spark_session: SparkSession):
        """DTP offer single-booking scope delegates to process_offer_synergy."""
        flattened_path = spark_session.createDataFrame([Row(journey_type="offer", isconversion=1)])
        synergy_result = spark_session.createDataFrame([Row(journey_type="offer", isconversion=1, interaction=1.0)])
        params = AttributionModelResultConfig()

        with patch("spark_pipeline.attribution_model_results.helper_functions.process_offer_synergy") as mock_synergy:
            mock_synergy.return_value = synergy_result

            result = run_synergy_if_applicable(
                spark_session, flattened_path, params,
                booking_id="b1", campaign_duration="During",
                job_run_id="run_1", synergy_output_path="/s3/path",
                is_dtp=True, journey_type_from_data="offer",
                booking_scope_size=1, booking_context="b1",
            )

        mock_synergy.assert_called_once()
        assert result is synergy_result

    def test_dtp_offer_synergy_failure_falls_back_to_original(self, spark_session: SparkSession):
        """When process_offer_synergy raises, flattened_path is returned as fallback."""
        flattened_path = spark_session.createDataFrame([Row(journey_type="offer", isconversion=1)])
        params = AttributionModelResultConfig()

        with patch("spark_pipeline.attribution_model_results.helper_functions.process_offer_synergy") as mock_synergy:
            mock_synergy.side_effect = RuntimeError("synergy failed")

            result = run_synergy_if_applicable(
                spark_session, flattened_path, params,
                booking_id="b1", campaign_duration="During",
                job_run_id="run_1", synergy_output_path="/s3/path",
                is_dtp=True, journey_type_from_data="offer",
                booking_scope_size=1, booking_context="b1",
            )

        assert result is flattened_path


class TestCreateEmptySynergyFile:

    def test_creates_empty_synergy_df_and_writes(self, spark_session):
        booking_id = "booking_123"
        campaign_duration = "30-days"
        job_run_id = "job_001"
        output_path = "s3://dummy/synergy"

        with patch(
            "spark_pipeline.attribution_model_results.helper_functions.spark_s3_overwrite"
        ) as mock_s3_write, patch(
            "spark_pipeline.attribution_model_results.helper_functions.logger"
        ) as mock_logger:

            captured_df = {}

            def capture_df(path, df):
                captured_df["df"] = df
                captured_df["path"] = path

            mock_s3_write.side_effect = capture_df

            create_empty_synergy_file(
                spark=spark_session,
                booking_id=booking_id,
                campaign_duration=campaign_duration,
                job_run_id=job_run_id,
                synergy_output_path=output_path,
            )

            # Assert write was called
            mock_s3_write.assert_called_once()
            assert captured_df["path"] == output_path

            df = captured_df["df"]

            # Assert schema columns exist
            expected_cols = {
                "channel_name",
                "chi_sq_p_val_num",
                "booking_id",
                "campaign_duration",
                "job_run_id",
                "load_ts",
            }

            assert set(df.columns) == expected_cols

            # Assert DataFrame is empty
            assert df.count() == 0

            # Validate metadata columns exist with correct types
            schema = dict((f.name, f.dataType.simpleString()) for f in df.schema.fields)

            assert schema["booking_id"] == "string"
            assert schema["campaign_duration"] == "string"
            assert schema["job_run_id"] == "string"
            assert schema["load_ts"] in ("timestamp",)

            # Logger called
            mock_logger.info.assert_called_once_with("Empty synergy file created")

    def test_logs_error_when_spark_s3_overwrite_fails(self, spark_session):
        """Test that error is logged when spark_s3_overwrite raises an exception."""
        output_path = "s3://bucket/synergy.parquet"
        booking_id = "booking_123"
        campaign_duration = "30-days"
        job_run_id = "job_456"
        error_message = "S3 connection timeout"

        with patch(
            "spark_pipeline.attribution_model_results.helper_functions.spark_s3_overwrite",
            side_effect=Exception(error_message)
        ) as mock_s3_overwrite, patch(
            "spark_pipeline.attribution_model_results.helper_functions.logger"
        ) as mock_logger:

            # Call the function - should not raise exception (it's caught)
            create_empty_synergy_file(
                spark=spark_session,
                booking_id=booking_id,
                campaign_duration=campaign_duration,
                job_run_id=job_run_id,
                synergy_output_path=output_path,
            )

            # Verify spark_s3_overwrite was called
            mock_s3_overwrite.assert_called_once()

            # Verify logger.error was called with correct message
            mock_logger.error.assert_called_once()
            error_arg = mock_logger.error.call_args[0][0]
            assert "Failed to save empty synergy file" in error_arg
            assert error_message in error_arg

            # Verify logger.info was not called
            mock_logger.info.assert_not_called()
