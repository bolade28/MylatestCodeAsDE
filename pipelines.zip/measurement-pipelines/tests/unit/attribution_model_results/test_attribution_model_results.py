import os
import pytest
from datetime import datetime
from unittest.mock import Mock, patch
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, TimestampType

from spark_pipeline.attribution_model_results.helper_functions import (
    process_attribution_model_lift,
)
from spark_pipeline.attribution_model_results.attribution_model_results import (
    process_multi_campaign_attribution,
    entrypoint,
    NON_TRAIN_COLS,
    OTHER_COLS,
)
from spark_pipeline.common.variables import PipelineRunType, AttributionModelResultConfig
from spark_pipeline.common.throwing_argument_parser import ArgumentParserError
from spark_pipeline.schemas.campaign_decay_rate import CampaignDecayType
from spark_pipeline.schemas.attribution_model_dataset import AttributionModelDatasetSchema

PIPELINE_RUN_TYPE = PipelineRunType()


class TestConstants:
    """Test module constants and configuration"""

    def test_label_col_constant(self):
        """Test LABEL_COL constant value"""
        assert AttributionModelResultConfig.label_col == "isconversion"

    def test_non_train_cols_constant(self):
        """Test NON_TRAIN_COLS constant value"""
        expected_cols = [
            "userjourney_id",
            "loyalty_id",
            "transaction_key",
            "booking_id",
            "customer_journey_type",
            "journey_type",
            "campaign_duration"
        ]
        assert NON_TRAIN_COLS == expected_cols

    def test_other_cols_constant(self):
        """Test OTHER_COLS constant composition"""
        expected_cols = NON_TRAIN_COLS + [AttributionModelResultConfig.label_col]
        assert OTHER_COLS == expected_cols


class TestHelperFunctions:
    """Test helper utility functions used by the refactored pipeline"""

    def test_get_decay_schema(self):
        """Test decay schema structure and field types"""
        schema = CampaignDecayType.campaign_decay_rate_dtp_schema

        expected_fields = [
            'marketing_type', 'channel_name', 'job_bag_number', 'reporting_dt',
            'impressions_cnt', 'cumulative_impressions_cnt', 'offsite_impressions_pct',
            'load_ts', 'job_run_id'
        ]

        actual_fields = [field.name for field in schema.fields]
        assert actual_fields == expected_fields

        field_types = {field.name: field.dataType for field in schema.fields}
        assert isinstance(field_types['marketing_type'], StringType)
        assert isinstance(field_types['impressions_cnt'], IntegerType)
        assert isinstance(field_types['offsite_impressions_pct'], DoubleType)
        assert isinstance(field_types['load_ts'], TimestampType)

    def test_process_attribution_model_lift_end_to_end(self, spark_session):
        """
        End-to-end test of process_attribution_model_lift using real lift computation.

        Setup (2 journeys, 2 channels: meta, dv360):
            journey_001: converts, meta=1.0, dv360=0.0
            journey_002: no convert, meta=0.0, dv360=1.0

        Lift math (booking_123 / 30-days):
            n_all=2, y_all=1  → P(overall) = 0.5
            P(conv | meta)  = 1/1 = 1.0  → lift(meta)  = 1.0 / 0.5 = 2.0
            P(conv | dv360) = 0/1 = 0.0  → lift(dv360) = 0.0

        For journey_001 (the only conversion):
            raw(meta) = 2.0 * 1.0 = 2.0, raw(dv360) = 0.0, sum = 2.0
            → normalized: meta = 1.0, dv360 = 0.0

        After filtering out zero-weight rows, only the meta row survives
        and joins to df_booking_id on regression_variable='meta'.
        """
        import pytest

        model_data = spark_session.createDataFrame([
            Row(userjourney_id='journey_001', loyalty_id='user_001', transaction_key='tx_001',
                booking_id='booking_123', customer_journey_type='Non-direct', journey_type='Brand',
                isconversion=1, campaign_duration='30-days', meta=1.0, dv360=0.0),
            Row(userjourney_id='journey_002', loyalty_id='user_002', transaction_key='tx_002',
                booking_id='booking_123', customer_journey_type='Non-direct', journey_type='Brand',
                isconversion=0, campaign_duration='30-days', meta=0.0, dv360=1.0),
        ])

        params = {
            'booking_id': 'booking_123',
            'job_run_id': 'test_job_123',
        }

        df_booking_id = spark_session.createDataFrame([
            Row(userjourney_id='journey_001', regression_variable='meta',
                booking_id='booking_123', campaign_duration='30-days',
                channel_name='social', subchannel_name='meta', marketing_type='paid_social',
                campaign_id='camp_001'),
            Row(userjourney_id='journey_001', regression_variable='dv360',
                booking_id='booking_123', campaign_duration='30-days',
                channel_name='display', subchannel_name='dv360', marketing_type='programmatic',
                campaign_id='camp_002'),
        ])

        results = process_attribution_model_lift(
            params, model_data, NON_TRAIN_COLS, df_booking_id,
            pipeline_run_type=PIPELINE_RUN_TYPE.pollen_run_type,
        )

        result_df = results

        # Only the meta row survives (dv360 weight = 0.0 is filtered out)
        rows = {row['regression_variable']: row for row in result_df.collect()}
        assert set(rows.keys()) == {'META'}  # Pollen uppercases regression_variable

        meta_row = rows['META']
        assert meta_row['normalized_weights'] == pytest.approx(1.0, rel=1e-6)
        assert meta_row['userjourney_id'] == 'journey_001'
        assert meta_row['booking_id'] == 'booking_123'
        assert meta_row['channel_name'] == 'social'
        assert meta_row['subchannel_name'] == 'meta'
        assert meta_row['marketing_type'] == 'paid_social'
        assert meta_row['campaign_id'] == 'camp_001'
        assert meta_row['job_run_id'] == 'test_job_123'
        assert meta_row['load_ts'] is not None

        expected_columns = [
            'loyalty_id', 'userjourney_id', 'transaction_key', 'booking_id',
            'customer_journey_type', 'journey_type', 'isconversion',
            'campaign_duration', 'regression_variable', 'normalized_weights',
            'channel_name', 'subchannel_name', 'marketing_type', 'campaign_id',
            'job_run_id', 'load_ts',
        ]
        for col in expected_columns:
            assert col in result_df.columns


class TestRunMultiCampaignAttribution:
    """Test main attribution processing function"""

    def test_successful_campaign_processing(self, spark_session, tmpdir):
        """Test successful processing with sufficient conversion data"""
        flattened_path = os.path.join(tmpdir, "flattened.parquet")
        channel_mapping_path = os.path.join(tmpdir, "channel_mapping.parquet")
        output_path = os.path.join(tmpdir, "output.parquet")

        flattened_data = [
            Row(loyalty_id=f'user_{i:03d}',
                userjourney_id=f'journey_{i:03d}',
                transaction_key=f'tx_{i:03d}',
                booking_id='booking_123',
                customer_journey_type='Non-direct',
                journey_type='Brand',
                campaign_duration='30-days',
                isconversion=1 if i < 60 else 0,
                regression_variable='email_marketing_email_newsletter_camp_001',
                normalized_weights=0.0,
                channel_name='email',
                subchannel_name='newsletter',
                marketing_type='email_marketing',
                campaign_id='camp_001',
                job_run_id='job_001',
                load_ts=datetime(2024, 1, 1, 12, 0, 0))
            for i in range(100)
        ]
        channel_mapping_data = [
            Row(userjourney_id=f'journey_{i:03d}',
                regression_variable='email_marketing_email_newsletter_camp_001',
                booking_id='booking_123',
                campaign_duration='30-days',
                channel_name='email',
                subchannel_name='newsletter',
                marketing_type='email_marketing',
                campaign_id='camp_001')
            for i in range(100)
        ]

        flat_df = spark_session.createDataFrame(flattened_data)
        channel_df = spark_session.createDataFrame(
            channel_mapping_data, AttributionModelDatasetSchema.journey_channel_metadata_schema
        )

        capture = {}

        def capture_write(df, path, notifier):
            capture['df'] = df
            capture['path'] = path

        with patch('spark_pipeline.attribution_model_results.attribution_model_results.run_multi_booking_attribution') as mock_process, \
                patch('spark_pipeline.attribution_model_results.attribution_model_results.get_training_params') as mock_get_params, \
                patch('spark_pipeline.attribution_model_results.attribution_model_results.get_all_campaigns_stats') as mock_stats, \
                patch('spark_pipeline.attribution_model_results.attribution_model_results.AttributionSlackNotifier') as mock_notifier, \
                patch('spark_pipeline.attribution_model_results.attribution_model_results.load_parquet_dataset') as mock_load, \
                patch('spark_pipeline.attribution_model_results.attribution_model_results.reconstruct_from_nested_journeys') as mock_reconstruct, \
                patch('spark_pipeline.attribution_model_results.attribution_model_results.write_parquet_dataset', side_effect=capture_write):

            def load_side_effect(spark, path, dataset_name, notifier, columns=None, fallback_schema=None):
                if path == flattened_path:
                    return flat_df
                return channel_df

            mock_load.side_effect = load_side_effect
            mock_reconstruct.return_value = flat_df

            mock_result_data = [
                Row(loyalty_id='user_001', userjourney_id='journey_001', transaction_key='tx_001',
                    booking_id='booking_123', customer_journey_type='Non-direct',
                    journey_type='Brand', campaign_duration='30-days', isconversion=1,
                    regression_variable='email_marketing_email_newsletter_camp_001',
                    normalized_weights=0.8, channel_name='email', subchannel_name='newsletter',
                    marketing_type='email_marketing', campaign_id='camp_001',
                    job_run_id='test_job_booking_123_30-days', load_ts=datetime(2024, 1, 15, 0, 0, 0))
            ]
            mock_result_df = spark_session.createDataFrame(mock_result_data)
            mock_process.return_value = (mock_result_df, 60.0)

            mock_config = AttributionModelResultConfig()
            mock_config.measurement_campaign_path = ""
            mock_config.attribution_prerequisite_path = ""
            mock_config.campaign_decay_path = ""
            mock_get_params.return_value = mock_config

            mock_stats.return_value = spark_session.createDataFrame(
                [Row(booking_id='booking_123', campaign_duration='30-days',
                     total_conversions=60, total_nonconversions=40, total_journeys=100,
                     conversion_rate=60.0)]
            )

            mock_notifier_instance = Mock()
            mock_notifier.return_value = mock_notifier_instance

            result = process_multi_campaign_attribution(
                spark=spark_session,
                attribution_model_dataset_flattened_path=flattened_path,
                journey_channel_metadata_path=channel_mapping_path,
                output_path=output_path,
                synergy_output_path=None,
                job_run_id='test_job',
                slack_topic_arn='test_arn',
                journey_type='brand',
                pipeline_run_type=PIPELINE_RUN_TYPE.pollen_run_type,
            )

            assert result['status'] == 'success'
            assert result['total_campaigns'] == 1
            assert result['campaign_errors'] == {}
            assert result['final_record_count'] > 0
            assert capture['df'].count() > 0


class TestEntrypoint:
    """Test entrypoint function and argument parsing"""

    def test_entrypoint_success(self):
        """Test successful entrypoint execution"""
        mock_spark = Mock()

        args = [
            "--attribution-model-dataset-flattened-path", "flattened_path",
            "--journey-channel-metadata-path", "channel_mapping_path",
            "--output-path", "output_path",
            "--journey-type", "brand",
            "--job-run-id", "test_job_123",
            "--slack-topic-arn", "test_arn",
            "--pipeline-run-type", PIPELINE_RUN_TYPE.dtp_run_type,
        ]

        mock_result = {
            'status': 'success',
            'total_campaigns': 5,
            'successful_campaigns': 4,
            'failed_campaigns': 1,
            'final_record_count': 1000
        }

        with patch('spark_pipeline.attribution_model_results.attribution_model_results.process_multi_campaign_attribution') as mock_run:
            mock_run.return_value = mock_result

            entrypoint(spark=mock_spark, command_line_args=args)

            mock_run.assert_called_once_with(
                spark=mock_spark,
                attribution_model_dataset_flattened_path="flattened_path",
                journey_channel_metadata_path="channel_mapping_path",
                output_path="output_path",
                synergy_output_path=None,
                job_run_id="test_job_123",
                slack_topic_arn="test_arn",
                journey_type="brand",
                pipeline_run_type=PIPELINE_RUN_TYPE.dtp_run_type,
            )

    def test_entrypoint_with_synergy_path(self):
        """Test entrypoint with synergy output path for DTP offer journey"""
        mock_spark = Mock()

        args = [
            "--attribution-model-dataset-flattened-path", "flattened_path",
            "--journey-channel-metadata-path", "channel_mapping_path",
            "--output-path", "output_path",
            "--synergy-output-path", "synergy_path",
            "--journey-type", "offer",
            "--job-run-id", "test_job_123",
            "--slack-topic-arn", "test_arn",
            "--pipeline-run-type", PIPELINE_RUN_TYPE.dtp_run_type,
        ]

        mock_result = {'status': 'success'}

        with patch('spark_pipeline.attribution_model_results.attribution_model_results.process_multi_campaign_attribution') as mock_run:
            mock_run.return_value = mock_result

            entrypoint(spark=mock_spark, command_line_args=args)

            mock_run.assert_called_once_with(
                spark=mock_spark,
                attribution_model_dataset_flattened_path="flattened_path",
                journey_channel_metadata_path="channel_mapping_path",
                output_path="output_path",
                synergy_output_path="synergy_path",
                job_run_id="test_job_123",
                slack_topic_arn="test_arn",
                journey_type="offer",
                pipeline_run_type=PIPELINE_RUN_TYPE.dtp_run_type,
            )

    def test_entrypoint_pollen_offer_without_synergy_path_succeeds(self):
        """Pollen offer runs skip synergy — --synergy-output-path must not be required."""
        mock_spark = Mock()

        args = [
            "--attribution-model-dataset-flattened-path", "flattened_path",
            "--journey-channel-metadata-path", "channel_mapping_path",
            "--output-path", "output_path",
            # intentionally omitting --synergy-output-path
            "--journey-type", "offer",
            "--job-run-id", "test_job_123",
            "--slack-topic-arn", "test_arn",
            "--pipeline-run-type", PIPELINE_RUN_TYPE.pollen_run_type,
        ]

        mock_result = {'status': 'success'}

        with patch('spark_pipeline.attribution_model_results.attribution_model_results.process_multi_campaign_attribution') as mock_run:
            mock_run.return_value = mock_result

            entrypoint(spark=mock_spark, command_line_args=args)

            mock_run.assert_called_once_with(
                spark=mock_spark,
                attribution_model_dataset_flattened_path="flattened_path",
                journey_channel_metadata_path="channel_mapping_path",
                output_path="output_path",
                synergy_output_path=None,
                job_run_id="test_job_123",
                slack_topic_arn="test_arn",
                journey_type="offer",
                pipeline_run_type=PIPELINE_RUN_TYPE.pollen_run_type,
            )

    def test_entrypoint_dtp_offer_without_synergy_path_raises(self):
        """DTP offer runs require --synergy-output-path; omitting it must fail argument parsing."""
        mock_spark = Mock()

        args = [
            "--attribution-model-dataset-flattened-path", "flattened_path",
            "--journey-channel-metadata-path", "channel_mapping_path",
            "--output-path", "output_path",
            # intentionally omitting --synergy-output-path
            "--journey-type", "offer",
            "--job-run-id", "test_job_123",
            "--slack-topic-arn", "test_arn",
            "--pipeline-run-type", PIPELINE_RUN_TYPE.dtp_run_type,
        ]

        with pytest.raises(ArgumentParserError, match="--synergy-output-path is required"):
            entrypoint(spark=mock_spark, command_line_args=args)

    def test_entrypoint_processing_failure(self):
        mock_spark = Mock()

        args = [
            "--attribution-model-dataset-flattened-path", "flattened_path",
            "--journey-channel-metadata-path", "channel_mapping_path",
            "--output-path", "output_path",
            "--journey-type", "brand",
            "--job-run-id", "test_job_123",
            "--slack-topic-arn", "test_arn",
            "--pipeline-run-type", PIPELINE_RUN_TYPE.dtp_run_type,
        ]

        mock_result = {
            'status': 'failed',
            'error': 'Processing failed due to insufficient data'
        }

        with patch('spark_pipeline.attribution_model_results.attribution_model_results.process_multi_campaign_attribution') as mock_run:
            mock_run.return_value = mock_result

            with pytest.raises(Exception, match="Processing failed: Processing failed due to insufficient data"):
                entrypoint(spark=mock_spark, command_line_args=args)


class TestEdgeCases:
    """Test edge cases and boundary conditions"""

    def test_constants_validation(self):
        """Validate all module constants are properly defined"""
        assert isinstance(AttributionModelResultConfig.label_col, str)
        assert isinstance(NON_TRAIN_COLS, list)
        assert isinstance(OTHER_COLS, list)

        for col in NON_TRAIN_COLS:
            assert isinstance(col, str)
            assert len(col) > 0

    def test_schema_consistency(self):
        """Test schema consistency across functions"""
        decay_schema = CampaignDecayType.campaign_decay_rate_dtp_schema

        assert len(decay_schema.fields) == 9

        field_names = [field.name for field in decay_schema.fields]
        assert len(field_names) == len(set(field_names))

    def test_empty_dataframe_handling(self, spark_session):
        """Test handling of various empty DataFrame scenarios"""
        empty_schema = StructType([
            StructField("test_col", StringType(), True)
        ])
        empty_df = spark_session.createDataFrame([], empty_schema)

        assert empty_df.count() == 0
        assert len(empty_df.columns) == 1
        assert empty_df.columns[0] == "test_col"

    def test_mock_validation(self):
        """Test that mock objects behave as expected"""
        test_mock = Mock()
        test_mock.some_method.return_value = "test_value"

        assert test_mock.some_method() == "test_value"
        test_mock.some_method.assert_called_once()

        test_mock_with_side_effect = Mock()
        test_mock_with_side_effect.side_effect = [1, 2, 3]

        assert test_mock_with_side_effect() == 1
        assert test_mock_with_side_effect() == 2
        assert test_mock_with_side_effect() == 3
