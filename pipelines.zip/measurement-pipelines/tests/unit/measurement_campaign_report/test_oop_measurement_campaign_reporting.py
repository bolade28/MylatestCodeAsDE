import pytest
from pyspark.sql import types as T
from chispa.dataframe_comparer import assert_df_equality
from unittest.mock import MagicMock
from datetime import datetime

from spark_pipeline.measurement_campaign_reporting.oop_measurement_campaign_reporting import BaseDataProcessor

# from spark_pipeline.schemas.measurement_campaign_reporting import (
#     MeasurementCampaignReporting,
# )


@pytest.fixture(scope="function")
def data_processor():
    """Fixture to provide an instance of a concrete BaseDataProcessor for testing."""
    class ConcreteDataProcessor(BaseDataProcessor):
        def dtp(self) -> bool:
            return True  # Or False, depending on the test case
    return ConcreteDataProcessor()


@pytest.fixture
def get_latest_data_dfs(spark_session):
    """Fixture to create input DataFrames for the get_latest_data method."""

    data = [
        ("booking_1", datetime(2025, 1, 1, 10, 0, 0), "A"),
        ("booking_1", datetime(2025, 1, 1, 11, 0, 0), "B"),
        ("booking_2", datetime(2025, 1, 1, 12, 0, 0), "C"),
        ("booking_3", datetime(2025, 1, 1, 13, 0, 0), "D"),
        ("booking_3", datetime(2025, 1, 1, 14, 0, 0), "E"),
    ]
    data_with_duration = [
        ("booking_1", "D1", datetime(2025, 1, 1, 10, 0, 0), "A"),
        ("booking_1", "D1", datetime(2025, 1, 1, 11, 0, 0), "B"),
        ("booking_2", "D2", datetime(2025, 1, 1, 12, 0, 0), "C"),
    ]

    filter_data = [("booking_1",), ("booking_2",)]
    filter_data_with_duration = [("booking_1", "D1"), ("booking_2", "D2")]

    schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("value", T.StringType(), True)
    ])

    schema_with_duration = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("value", T.StringType(), True)
    ])

    filter_schema = T.StructType([T.StructField("booking_id", T.StringType(), True)])
    filter_schema_with_duration = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True)
    ])

    data_df = spark_session.createDataFrame(data, schema)
    data_df_with_duration = spark_session.createDataFrame(data_with_duration, schema_with_duration)
    filter_df = spark_session.createDataFrame(filter_data, filter_schema)
    filter_df_with_duration = spark_session.createDataFrame(filter_data_with_duration, filter_schema_with_duration)

    return {
        "data_df": data_df,
        "data_df_with_duration": data_df_with_duration,
        "filter_df": filter_df,
        "filter_df_with_duration": filter_df_with_duration,
        "schema": schema,
        "schema_with_duration": schema_with_duration,
    }


@pytest.fixture
def process_nectar_data_df(spark_session):
    """Fixture to create a sample DataFrame for the process_nectar_data method."""
    schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType(), True),
        T.StructField("attributed_recalibrated_units_qty", T.DoubleType(), True),
        T.StructField("incremental_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("incremental_units_qty_exposed", T.DoubleType(), True),
        T.StructField("nectar_sales_amt", T.DoubleType(), True),
        T.StructField("non_nectar_sales_amt", T.DoubleType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
    ])
    data = [
        ("C1", 100.0, 50.0, 30.0, 15.0, 60.0, 40.0, "onsite-gol", "test"),
        ("C2", 200.0, 100.0, 70.0, 35.0, 120.0, 80.0, "in-store", "test"),
        ("C3", 300.0, 150.0, 100.0, 50.0, 180.0, 120.0, "online", "not-in-store"),
    ]
    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def process_booking_ids_dfs(spark_session):
    """Fixture to create input DataFrames for the process_booking_ids method."""
    schemas = {
        "baseline_offer": T.StructType([
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("campaign_duration", T.StringType(), True),
            T.StructField("journey_type", T.StringType(), True),
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("incremental_sales_amt_exposed", T.DoubleType(), True),
            T.StructField("attributed_recalibrated_sales_amt", T.DoubleType(), True),
            T.StructField("attributed_recalibrated_units_qty", T.DoubleType(), True),
            T.StructField("attributed_sales_amt", T.DoubleType(), True),
            T.StructField("attributed_units_qty", T.DoubleType(), True),
            T.StructField("incremental_units_qty_exposed", T.DoubleType(), True),
            T.StructField("nectar_sales_amt", T.DoubleType(), True),
            T.StructField("non_nectar_sales_amt", T.DoubleType(), True),
            T.StructField("customer_journey_type", T.StringType(), True)
        ]),
        "unified_campaign": T.StructType([
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("super_category_name", T.StringType(), True),
            T.StructField("sub_category_name", T.StringType(), True),
            T.StructField("campaign_name", T.StringType(), True),
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField("job_bag_number", T.StringType(), True)
        ]),
        "baseline_offer_with_factor": T.StructType([
            T.StructField("recalibration_factor", T.DoubleType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("campaign_id", T.StringType(), True),
        ]),
        "reach_engagement": T.StructType([
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("media_spend_amt", T.DoubleType(), True),
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("load_ts", T.TimestampType(), True),
        ]),
        "attribution_data": T.StructType([
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField("normalized_weights", T.DoubleType(), True),
        ]),
        "attribution_pre_requisite": T.StructType([
            T.StructField("userjourney_id", T.StringType(), True),
            T.StructField("isconversion", T.IntegerType(), True),
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("campaign_id", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("marketing_type", T.StringType(), True)
        ])
    }

    data = {
        "baseline_offer": [
            ("B1", "C1", "D1", "Direct", "digital", "meta", "facebook", 50.0, 150.0, 75.0, 100.0, 50.0, 25.0, 80.0, 70.0, "Single Channel"),
            ("B1", "C2", "D1", "Non-direct", "digital", "dv360", "video", 30.0, 100.0, 50.0, 80.0, 40.0, 15.0, 50.0, 50.0, "Non-direct"),
            ("B2", "C3", "D2", "Direct", "print", "in-store", "flyer", 20.0, 80.0, 40.0, 60.0, 30.0, 10.0, 40.0, 40.0, "Single Channel"),
        ],
        "unified_campaign": [
            ("C1", "meta", "facebook", "sup_cat_1", "sub_cat_1", "campaign_1", "digital", "JB1"),
            ("C2", "dv360", "video", "sup_cat_2", "sub_cat_2", "campaign_2", "digital", "JB2"),
            ("C3", "in-store", "flyer", "sup_cat_3", "sub_cat_3", "campaign_3", "print", "JB3")
        ],
        "baseline_offer_with_factor": [
            (1.5, "meta", "C1"),
            (1.2, "dv360", "C2")
        ],
        "reach_engagement": [
            ("C1", "meta", "facebook", 500.0, "digital", "B1", datetime.now()),
            ("C2", "dv360", "video", 300.0, "digital", "B1", datetime.now()),
            ("C3", "in-store", "flyer", 200.0, "print", "B2", datetime.now()),
        ],
        "attribution_data": [
            ("meta", "C1", "facebook", "digital", 0.7),
            ("dv360", "C2", "video", "digital", 0.3),
            ("in-store", "C3", "flyer", "print", 0.5),
        ],
        "attribution_pre_requisite": [
            ("UJ1", 1, "meta", "C1", "facebook", "digital"),
            ("UJ2", 0, "meta", "C1", "facebook", "digital"),
            ("UJ3", 1, "dv360", "C2", "video", "digital"),
            ("UJ4", 1, "dv360", "C2", "video", "digital"),
            ("UJ5", 0, "in-store", "C3", "flyer", "print"),
            ("UJ6", 1, "in-store", "C3", "flyer", "print"),
            ("UJ7", 0, "in-store", "C3", "flyer", "print"),
        ]
    }

    return {
        key: spark_session.createDataFrame(data[key], schemas[key])
        for key in data
    }

# --- Tests for get_latest_data ---


def test_get_latest_data_no_campaign_duration(spark_session, data_processor, get_latest_data_dfs):
    """Tests get_latest_data without the 'campaign_duration' key."""
    data_df = get_latest_data_dfs["data_df"]
    filter_df = get_latest_data_dfs["filter_df"]

    expected_data = [
        ("booking_1", datetime(2025, 1, 1, 11, 0, 0), "B"),
        ("booking_2", datetime(2025, 1, 1, 12, 0, 0), "C"),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema=get_latest_data_dfs["schema"])

    result_df = data_processor.get_latest_data(data_df, filter_df)

    assert_df_equality(result_df, expected_df)


def test_get_latest_data_with_campaign_duration(spark_session, data_processor, get_latest_data_dfs):
    """Tests get_latest_data when 'campaign_duration' is present."""
    data_df = get_latest_data_dfs["data_df_with_duration"]
    filter_df = get_latest_data_dfs["filter_df_with_duration"]

    expected_data = [
        ("booking_1", "D1", datetime(2025, 1, 1, 11, 0, 0), "B"),
        ("booking_2", "D2", datetime(2025, 1, 1, 12, 0, 0), "C"),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema=get_latest_data_dfs["schema_with_duration"])

    result_df = data_processor.get_latest_data(data_df, filter_df)

    assert_df_equality(result_df, expected_df)


def test_get_latest_data_empty_filter_df(spark_session, data_processor, get_latest_data_dfs):
    """Tests get_latest_data with an empty filter DataFrame."""
    data_df = get_latest_data_dfs["data_df"]
    empty_filter_df = spark_session.createDataFrame([], get_latest_data_dfs["filter_df"].schema)

    result_df = data_processor.get_latest_data(data_df, empty_filter_df)

    assert result_df.count() == 0

# --- Tests for process_nectar_data ---


def test_process_nectar_data(spark_session, data_processor, process_nectar_data_df):
    """Tests the process_nectar_data method with a sample DataFrame."""
    df = process_nectar_data_df

    # Expected total values

    result_df = data_processor.process_nectar_data(df)

    # Test nectar and non-nectar weights
    result_row1 = result_df.filter("campaign_id == 'C1'").collect()[0]
    assert result_row1["nectar_weights"] == pytest.approx(360.0 / 600.0)
    assert result_row1["non_nectar_weights"] == pytest.approx(240.0 / 600.0)

    # Test incremental sales and units
    assert result_row1["new_nectar_sales_amt"] == pytest.approx(200.0 * (360.0 / 600.0))
    assert result_row1["new_non_nectar_sales_amt"] == pytest.approx(200.0 * (240.0 / 600.0))
    assert result_row1["new_nectar_units_qty"] == pytest.approx(100.0 * (360.0 / 600.0))
    assert result_row1["new_non_nectar_units_qty"] == pytest.approx(100.0 * (240.0 / 600.0))

    # Test new nectar weights (sales and qty)
    assert result_row1["new_nectar_weight"] == pytest.approx(100.0 / 600.0)
    assert result_row1["new_nectar_qty_weight"] == pytest.approx(50.0 / 300.0)

    # Test total non-nectar weights calculation
    total_non_nectar_weights_expected = (100.0 / 600.0) + (200.0 / 600.0)

    # Test final calculated columns
    result_row1 = result_df.filter("campaign_id == 'C1'").collect()[0]
    assert result_row1["incremental_nectar_sales_amt"] == pytest.approx(result_row1["new_nectar_sales_amt"] * result_row1["new_nectar_weight"])
    assert result_row1["incremental_non_nectar_sales_amt"] == pytest.approx(result_row1["new_non_nectar_sales_amt"] * (result_row1["new_nectar_weight"] / total_non_nectar_weights_expected))
    assert result_row1["total_incremental_nectar_sales_amt"] == pytest.approx(result_row1["incremental_nectar_sales_amt"] + result_row1["incremental_non_nectar_sales_amt"])

# --- Tests for process_booking_ids ---


def test_process_booking_ids_dtp_version(spark_session, data_processor, process_booking_ids_dfs):
    """
    Tests the process_booking_ids method with DTP version (dtp() returns True).
    This is a high-level integration test of the main logic flow.
    """
    # Override dtp to ensure DTP logic is used
    data_processor.dtp = lambda: True

    results = data_processor.process_booking_ids(
        baseline_df=process_booking_ids_dfs["baseline_offer"],
        unified_campaign=process_booking_ids_dfs["unified_campaign"],
        baseline_offer_df=process_booking_ids_dfs["baseline_offer_with_factor"],
        reach_engagement=process_booking_ids_dfs["reach_engagement"],
        attribution_data_filtered=process_booking_ids_dfs["attribution_data"],
        attribution_pre_requisite_filtered=process_booking_ids_dfs["attribution_pre_requisite"],
    )

    assert len(results) == 1
    result_df = results[0]

    # Check for DTP-specific columns
    dtp_columns = ["job_bag_number", "num_user_journeys", "num_conversions"]
    for col in dtp_columns:
        assert col in result_df.columns

    # Check some key calculated values
    row1 = result_df.filter("booking_id == 'B1' AND campaign_id == 'C1'").collect()[0]

    # Test recalibration
    expected_recalibrated_conversions = process_booking_ids_dfs["attribution_data"].filter("campaign_id == 'C1'").collect()[0]["normalized_weights"] * 1.5
    assert row1["conversions_recalibrated"] == pytest.approx(expected_recalibrated_conversions)

    # Test IROAS
    assert row1["iroas_exposed"] == pytest.approx(row1["incremental_sales_amt_exposed"] / 500.0)

    # Test user journey metrics
    assert row1["num_user_journeys"] == 2
    assert row1["num_conversions"] == 1

    # Test conversion rate
    total_pre_req_conversions = process_booking_ids_dfs["attribution_pre_requisite"].filter("isconversion == 1").count()
    total_pre_req_user_journeys = process_booking_ids_dfs["attribution_pre_requisite"].select("userjourney_id").distinct().count()
    assert row1["conversion_rate"] == pytest.approx((total_pre_req_conversions / total_pre_req_user_journeys) * 100)


def test_process_booking_ids_code1_version(spark_session, data_processor, process_booking_ids_dfs):
    """
    Tests the process_booking_ids method with Code 1 version (dtp() returns False).
    """
    # Override dtp to ensure Code 1 logic is used
    data_processor.dtp = lambda: False

    results = data_processor.process_booking_ids(
        baseline_df=process_booking_ids_dfs["baseline_offer"],
        unified_campaign=process_booking_ids_dfs["unified_campaign"],
        baseline_offer_df=process_booking_ids_dfs["baseline_offer_with_factor"],
        reach_engagement=process_booking_ids_dfs["reach_engagement"],
        attribution_data_filtered=process_booking_ids_dfs["attribution_data"],
        attribution_pre_requisite_filtered=process_booking_ids_dfs["attribution_pre_requisite"],
    )

    assert len(results) == 1
    result_df = results[0]

    # Check that DTP-specific columns are NOT in the final DF
    dtp_columns = ["job_bag_number", "num_user_journeys", "num_conversions"]
    for col in dtp_columns:
        assert col not in result_df.columns

    data = [
        ("C1", "B1", "D1", "Direct", "digital", "meta", "facebook", "sub_cat_1", 0.7, 50.0, "sup_cat_1", "campaign_1", 150.0, 75.0, 25.0, 50.0, 100.0, 0.7, 1.5, 170.0, 160.0, 500.0, "Single Channel", 0.5151515151515151, 0.48484848484848486, 51.515151515151516, 48.484848484848484, 25.757575757575758, 24.242424242424242, 0.45454545454545453, 0.45454545454545453, 23.415977961432507, 0.0, 11.707988980716253, 0.0, 0.0, 23.415977961432507, 0.0, 11.707988980716253, 126.5840220385675, 0.3125, 0.1, 0.046831955922865015, 100.0, 0.32, 0.32, 0.15610651974288337, 0.15610651974288337, 57.14285714285714),
        ("C2", "B1", "D1", "Non-direct", "digital", "dv360", "video", "sub_cat_2", 0.3, 30.0, "sup_cat_2", "campaign_2", 100.0, 50.0, 15.0, 40.0, 80.0, 0.3, 1.2, 170.0, 160.0, 300.0, "Multi Channel", 0.5151515151515151, 0.48484848484848486, 51.515151515151516, 48.484848484848484, 25.757575757575758, 24.242424242424242, 0.30303030303030304, 0.30303030303030304, 15.610651974288338, 0.0, 7.805325987144169, 0.0, 0.0, 15.610651974288338, 0.0, 7.805325987144169, 84.38934802571166, 0.3125, 0.1, 0.05203550658096113, 70.0, 0.32, 0.32, 0.15610651974288337, 0.15610651974288337, 57.14285714285714),
        ("C3", "B2", "D2", "Direct", "print", "in-store", "flyer", "sub_cat_3", 0.5, 20.0, "sup_cat_3", "campaign_3", 80.0, 40.0, 10.0, 30.0, 60.0, 0.5, None, 170.0, 160.0, 200.0, "Single Channel", 0.5151515151515151, 0.48484848484848486, 51.515151515151516, 48.484848484848484, 25.757575757575758, 24.242424242424242, 0.24242424242424243, 0.24242424242424243, 12.488521579430671, 1.0, 6.2442607897153355, 1.0, 48.484848484848484, 60.97337006427915, 24.242424242424242, 30.486685032139576, 19.026629935720848, 0.4, 0.1, 0.30486685032139577, 60.0, 0.25, 0.25, 0.7621671258034894, 0.7621671258034894, 57.14285714285714),
    ]

    # Schema for the DataFrame, with appropriate data types for each column
    schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("journey_type", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("conversions", T.DoubleType(), True),
        T.StructField("incremental_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("campaign_name", T.StringType(), True),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType(), True),
        T.StructField("attributed_recalibrated_units_qty", T.DoubleType(), True),
        T.StructField("incremental_units_qty_exposed", T.DoubleType(), True),
        T.StructField("attributed_units_qty", T.DoubleType(), True),
        T.StructField("attributed_sales_amt", T.DoubleType(), True),
        T.StructField("conversions_recalibrated", T.DoubleType(), True),
        T.StructField("recalibration_factor", T.DoubleType(), True),
        T.StructField("nectar_sales_amt", T.DoubleType(), False),
        T.StructField("non_nectar_sales_amt", T.DoubleType(), False),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_type", T.StringType(), True),
        T.StructField("nectar_weights", T.DoubleType(), True),
        T.StructField("non_nectar_weights", T.DoubleType(), True),
        T.StructField("new_nectar_sales_amt", T.DoubleType(), True),
        T.StructField("new_non_nectar_sales_amt", T.DoubleType(), True),
        T.StructField("new_nectar_units_qty", T.DoubleType(), True),
        T.StructField("new_non_nectar_units_qty", T.DoubleType(), True),
        T.StructField("new_nectar_weight", T.DoubleType(), True),
        T.StructField("new_nectar_qty_weight", T.DoubleType(), True),
        T.StructField("incremental_nectar_sales_amt", T.DoubleType(), True),
        T.StructField("new_non_nectar_weights", T.DoubleType(), True),
        T.StructField("incremental_nectar_units_qty", T.DoubleType(), True),
        T.StructField("new_non_nectar_qty_weights", T.DoubleType(), True),
        T.StructField("incremental_non_nectar_sales_amt", T.DoubleType(), True),
        T.StructField("total_incremental_nectar_sales_amt", T.DoubleType(), True),
        T.StructField("incremental_non_nectar_units_qty", T.DoubleType(), True),
        T.StructField("total_incremental_nectar_units_qty", T.DoubleType(), True),
        T.StructField("base_sales_amt_nectar_exposed", T.DoubleType(), True),
        T.StructField("roas_exposed", T.DoubleType(), True),
        T.StructField("iroas_exposed", T.DoubleType(), True),
        T.StructField("iroas_exposed_nectar", T.DoubleType(), True),
        T.StructField("base_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("uplift_exposed_sales_amt", T.DoubleType(), True),
        T.StructField("uplift_exposed_units_qty", T.DoubleType(), True),
        T.StructField("uplift_exposed_nectar_sales_amt", T.DoubleType(), True),
        T.StructField("uplift_exposed_nectar_units_qty", T.DoubleType(), True),
        T.StructField("conversion_rate", T.DoubleType(), True),
    ])

    # Create the DataFrame
    expected_df = spark_session.createDataFrame(data, schema)

    assert_df_equality(result_df, expected_df)


# --- Tests for processor ---
def test_processor_with_aisle_skus(spark_session, data_processor):
    """
    Tests the main processor method with include_aisle_skus set to True.
    Uses MagicMock to simulate the DataFrames returned by get_latest_data and other helper methods.
    """
    # Mocking the `get_latest_data` and `process_booking_ids` methods
    data_processor.get_latest_data = MagicMock(return_value=spark_session.createDataFrame([(1,)], ["col1"]))
    data_processor.process_booking_ids = MagicMock(
        return_value=[spark_session.createDataFrame([("B1", 10.0, "C1", datetime.now(), "jb1")],
                                                    ["booking_id", "total_incremental_nectar_sales_amt", "campaign_id", "load_ts", "job_bag_number"])]
    )

    # Mocking the input DataFrames to satisfy the `processor` method's type hints
    dummy_df = spark_session.createDataFrame([], "campaign_id: string, booking_id: string, campaign_duration: string")

    # Mock the `dtp` method
    data_processor.dtp = lambda: True

    # Use pytest.raises() to assert that a ValueError is raised with the correct message
    with pytest.raises(ValueError, match="Error: no data found to execute the model!"):
        data_processor.processor(
            spark=spark_session,
            measurement_campaign_execution_df=dummy_df,
            unified_campaign_df=dummy_df,
            reach_engagement_df=dummy_df,
            attribution_model_result_offer_df=dummy_df,
            attribution_model_result_brand_df=dummy_df,
            attribution_model_result_aisle_df=dummy_df,
            attribution_pre_requisite_offer_df=dummy_df,
            attribution_pre_requisite_brand_df=dummy_df,
            attribution_pre_requisite_aisle_df=dummy_df,
            baseline_offer_df=dummy_df,
            baseline_brand_df=dummy_df,
            baseline_aisle_df=dummy_df,
            correlation_id="test-run",
            untargeted_channels_list=[],
            include_aisle_skus=True
        )


def test_processor_no_aisle_skus(spark_session, data_processor):
    """
    Tests the main processor method with include_aisle_skus set to False.
    """
    data_processor.get_latest_data = MagicMock(return_value=spark_session.createDataFrame([(1,)], ["col1"]))
    data_processor.process_booking_ids = MagicMock(
        return_value=[spark_session.createDataFrame([("B1", 10.0, "C1", datetime.now(), "jb1")],
                                                    ["booking_id", "total_incremental_nectar_sales_amt", "campaign_id", "load_ts", "job_bag_number"])]
    )

    data_processor.dtp = lambda: True

    campaign_execution_data = [
        ("C1", "B1", "Email", 'During'),
        ("C2", "B2", "In-Store", 'During'),
    ]

    # Define schemas for all input dataframes
    campaign_execution_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
    ])
    campaign_executed_df = spark_session.createDataFrame(campaign_execution_data, campaign_execution_schema)
    # Mocking the input DataFrames to satisfy the `processor` method's type hints
    dummy_df = spark_session.createDataFrame([], "campaign_id: string, booking_id: string, campaign_duration: string")

    result_df = data_processor.processor(
        spark=spark_session,
        measurement_campaign_execution_df=campaign_executed_df,
        unified_campaign_df=dummy_df,
        reach_engagement_df=dummy_df,
        attribution_model_result_offer_df=dummy_df,
        attribution_model_result_brand_df=dummy_df,
        attribution_model_result_aisle_df=dummy_df,
        attribution_pre_requisite_offer_df=dummy_df,
        attribution_pre_requisite_brand_df=dummy_df,
        attribution_pre_requisite_aisle_df=dummy_df,
        baseline_offer_df=dummy_df,
        baseline_brand_df=dummy_df,
        baseline_aisle_df=dummy_df,
        correlation_id="test-run",
        untargeted_channels_list=[],
        include_aisle_skus=False
    )

    # Check that `process_booking_ids` was called two times (for Offer and Brand)
    assert data_processor.process_booking_ids.call_count == 2
    assert "job_run_id" in result_df.columns
    assert result_df.filter("job_run_id == 'test-run'").count() > 0
