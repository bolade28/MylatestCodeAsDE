from chispa import assert_df_equality
import pytest
from unittest.mock import Mock, patch
from pyspark.sql import types as T, functions as F

from spark_pipeline.common.variables import CampaignDurations, FallbackTypes, IncrementalityFallbackConfig

from spark_pipeline.schemas.measurement_campaign_reporting import PublishedCampaignInput

from spark_pipeline.measurement_campaign_reporting.incrementality_fallback import (
    FALLBACK_ADJUSTED_COLUMNS,
    aggregate_reporting,
    apply_control_fallback,
    apply_control_fallback_factor,
    apply_fallback_ratio,
    apply_published_fallback,
    calculate_control_fallback_factor,
    check_if_incrementality_fallback_needed,
    apply_fallback,
    apply_period_fallback,
    compute_fallback_ratio,
    floor_post_incrementality,
    get_fallback_method,
    get_fallback_metadata,
    get_published_ratios,
    propagate_post_changes,
)

# Test-only value, so the tests prove control types are read from config rather than hard-coded.
CONTROL_TYPE = "TESTCONTROLTYPE"
CHANNEL_NAME_SCHEMA = T.StructType([T.StructField("channel_name", T.StringType())])


@pytest.fixture
def config():
    return IncrementalityFallbackConfig(
        control_lift_marketing_types=[CONTROL_TYPE],
        fallback_percentile=0.9,
        min_published_campaigns=1,
        max_fallback_ratio=1.0,
    )


def get_published_campaign_inputs(spark_session):
    """Helper function to provide sample published campaign inputs for testing."""

    campaign_input_data = [
        {"booking_id": 1, "incrementality_ratio": 0.1},
        {"booking_id": 2, "incrementality_ratio": 0.2},
        {"booking_id": 3, "incrementality_ratio": 0.3},
    ]
    return spark_session.createDataFrame(campaign_input_data, schema=PublishedCampaignInput().schema)


def test_get_published_campaign_inputs(spark_session):
    df = get_published_campaign_inputs(spark_session)
    assert df.count() == 3
    assert set(df.columns) == {"booking_id", "incrementality_ratio"}


def test_check_if_incrementality_fallback_needed(spark_session):

    # Test Case 1: Incrementality > Attributed Recalibrated Sales
    integration_output_data = [
        {"product_type": "BRAND", "incremental_sales_amt_exposed": 100,
            "attributed_recalibrated_sales_amt": 50},
        {"product_type": "OFFER", "incremental_sales_amt_exposed": 10,
            "attributed_recalibrated_sales_amt": 30},
    ]
    integration_output = spark_session.createDataFrame(integration_output_data)

    # Check if incrementality fallback is needed
    fallback_needed = check_if_incrementality_fallback_needed(integration_output)
    assert fallback_needed is True

    # Test Case 2: Incrementality == Attributed Recalibrated Sales
    integration_output_data = [
        {"product_type": "BRAND", "incremental_sales_amt_exposed": 100,
            "attributed_recalibrated_sales_amt": 100},
        {"product_type": "OFFER", "incremental_sales_amt_exposed": 10,
            "attributed_recalibrated_sales_amt": 30},
    ]
    integration_output = spark_session.createDataFrame(integration_output_data)

    # Check if incrementality fallback is needed
    fallback_needed = check_if_incrementality_fallback_needed(integration_output)
    assert fallback_needed is True

    # Test Case 3: Incrementality < Attributed Recalibrated Sales
    integration_output_data = [
        {"product_type": "BRAND", "incremental_sales_amt_exposed": 50,
            "attributed_recalibrated_sales_amt": 100},
        {"product_type": "OFFER", "incremental_sales_amt_exposed": 10,
            "attributed_recalibrated_sales_amt": 30},
    ]
    integration_output = spark_session.createDataFrame(integration_output_data)

    # Check if incrementality fallback is needed
    fallback_needed = check_if_incrementality_fallback_needed(integration_output)
    assert fallback_needed is False

    # Test Case 4: Attributed Sales and Incremental Sales are zero - fallback not needed

    integration_output_data = [
        {"product_type": "BRAND", "incremental_sales_amt_exposed": 0,
         "attributed_recalibrated_sales_amt": 0},
        {"product_type": "OFFER", "incremental_sales_amt_exposed": 0,
         "attributed_recalibrated_sales_amt": 0},
    ]
    integration_output = spark_session.createDataFrame(integration_output_data)

    # Check if incrementality fallback is needed
    fallback_needed = check_if_incrementality_fallback_needed(integration_output)
    assert fallback_needed is False

    # Aggregation of channels - Total Incrementality > Attributed Recalibrated Sales
    integration_output_data = [
        {"marketing_type": "Offsite",
         "product_type": "BRAND",
         "subchannel_name": "Social",
         "incremental_sales_amt_exposed": 30,
         "attributed_recalibrated_sales_amt": 40},
        {"marketing_type": "Instore",
         "product_type": "BRAND",
         "subchannel_name": "Trolley",
         "incremental_sales_amt_exposed": 70,
         "attributed_recalibrated_sales_amt": 50},
    ]
    integration_output = spark_session.createDataFrame(integration_output_data)

    # Check if incrementality fallback is needed
    fallback_needed = check_if_incrementality_fallback_needed(integration_output)
    assert fallback_needed is True


DURING = CampaignDurations.CAMPAIGN_DURATION_DURING
POST = CampaignDurations.CAMPAIGN_DURATION_POST


def fallback_method_for(spark_session, config, campaign_duration, *channel_names):
    integration_output = spark_session.createDataFrame([(t,) for t in channel_names], CHANNEL_NAME_SCHEMA)
    return get_fallback_method(config, campaign_duration, integration_output)


def test_single_control_type_during_uses_control_lift(spark_session, config):
    result = fallback_method_for(spark_session, config, DURING, CONTROL_TYPE, CONTROL_TYPE)
    assert result == FallbackTypes.FALLBACK_CONTROL


def test_single_control_type_post_uses_published_ratio(spark_session, config):
    result = fallback_method_for(spark_session, config, POST, CONTROL_TYPE, CONTROL_TYPE)
    assert result == FallbackTypes.FALLBACK_PUBLISHED


def test_mixed_marketing_types_use_published_ratio(spark_session, config):
    result = fallback_method_for(spark_session, config, DURING, CONTROL_TYPE, "INSTORE")
    assert result == FallbackTypes.FALLBACK_PUBLISHED


def test_single_non_control_type_uses_published_ratio(spark_session, config):
    result = fallback_method_for(spark_session, config, DURING, "INSTORE", "INSTORE")
    assert result == FallbackTypes.FALLBACK_PUBLISHED


def test_apply_control_fallback_valid(spark_session, config):

    integration_output_data = [
        {
            "job_bag_number": "job_bag_1",
            "campaign_id": "campaign_1",
            "marketing_type": CONTROL_TYPE,
            "channel_name": f"channel {CONTROL_TYPE}",
            "product_type": "Brand",
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": 100,
            "attributed_recalibrated_sales_amt": 50,
            "incremental_units_qty_exposed": 20,
            "attributed_recalibrated_units_qty": 25},
    ]

    legacy_lift_data = [
        {
            "campaign_id": "campaign_1",
            "campaign_source": CONTROL_TYPE,
            "period": DURING,
            "campaign_start_date": "2024-01-01",
            "campaign_end_date": "2024-01-31",
            "super_category_name": "Beverages",
            "sub_category_name": "Soft Drinks",
            "product_type": "Brand",
            "item_cd": "item_1",
            "test": 100,
            "control": 50,
            "uplift": 40,
            "media_cost": 20
        }
    ]

    unified_campaign_data = [
        {
            "campaign_id": "campaign_1",
            "job_bag_number": "job_bag_1"
        }
    ]

    brand_data = [
        {
            "item_cd": "item_1",
            "unique_brand_name": "Brand A",
        }
    ]

    fallback_expected = [
        {
            "job_bag_number": "job_bag_1",
            "campaign_id": "campaign_1",
            "marketing_type": CONTROL_TYPE,
            "channel_name": f"channel {CONTROL_TYPE}",
            "campaign_duration": DURING,
            "product_type": "Brand",
            "incremental_sales_amt_exposed": 40,
            "attributed_recalibrated_sales_amt": 50,
            "incremental_units_qty_exposed": 8,
            "attributed_recalibrated_units_qty": 25,
            "control_factor": 0.4
        },
    ]

    legacy_lift_data = spark_session.createDataFrame(legacy_lift_data)
    integration_output_data = spark_session.createDataFrame(integration_output_data)
    brand_data = spark_session.createDataFrame(brand_data)
    unified_campaign = spark_session.createDataFrame(unified_campaign_data)

    result = apply_control_fallback(config, integration_output_data, legacy_lift_data, brand_data, unified_campaign)

    expected_df = spark_session.createDataFrame(fallback_expected)
    expected_df = expected_df.withColumns({
        "incremental_sales_amt_exposed": F.col("incremental_sales_amt_exposed").cast(T.DoubleType()),
        "incremental_units_qty_exposed": F.col("incremental_units_qty_exposed").cast(T.DoubleType()),
    })

    assert_df_equality(result, expected_df, ignore_nullable=True, ignore_column_order=True)


def test_apply_control_fallback_scales_channels_to_control_uplift(spark_session, config):
    integration_output = spark_session.createDataFrame([
        {
            "job_bag_number": "job_bag_1",
            "campaign_id": "campaign_1",
            "correlation_id": "correlation_1",
            "marketing_type": CONTROL_TYPE,
            "channel_name": f"channel {CONTROL_TYPE}",
            "product_type": "Brand",
            "campaign_duration": DURING,
            "subchannel_name": "channel_1",
            "incremental_sales_amt_exposed": 60.0,
            "attributed_recalibrated_sales_amt": 30.0,
            "incremental_units_qty_exposed": 6.0,
        },
        {
            "job_bag_number": "job_bag_1",
            "campaign_id": "campaign_1",
            "correlation_id": "correlation_1",
            "marketing_type": CONTROL_TYPE,
            "channel_name": f"channel {CONTROL_TYPE}",
            "product_type": "Brand",
            "campaign_duration": DURING,
            "subchannel_name": "channel_2",
            "incremental_sales_amt_exposed": 40.0,
            "attributed_recalibrated_sales_amt": 20.0,
            "incremental_units_qty_exposed": 4.0,
        },
    ])

    legacy_lift = spark_session.createDataFrame([
        {
            "campaign_id": "campaign_1",
            "campaign_source": CONTROL_TYPE,
            "period": DURING,
            "campaign_start_date": "2024-01-01",
            "campaign_end_date": "2024-01-31",
            "super_category_name": "Beverages",
            "sub_category_name": "Soft Drinks",
            "item_cd": "item_1",
            "test": 100.0,
            "control": 50.0,
            "uplift": 40.0,
            "media_cost": 20.0,
        },
    ])
    brand_data = spark_session.createDataFrame([{"item_cd": "item_1", "unique_brand_name": "Brand A"}])
    unified_campaign = spark_session.createDataFrame([{"campaign_id": "campaign_1", "job_bag_number": "job_bag_1"}])

    result = apply_control_fallback(config, integration_output, legacy_lift, brand_data, unified_campaign)

    incrementality_by_channel = {
        row.subchannel_name: row.incremental_sales_amt_exposed for row in result.collect()
    }
    # Both channels are scaled by the same factor (40 / 100), so the split between them is preserved
    assert incrementality_by_channel == pytest.approx({"channel_1": 24.0, "channel_2": 16.0})
    # and the campaign total now equals the control uplift
    assert sum(incrementality_by_channel.values()) == pytest.approx(40.0)


def test_apply_control_fallback_handles_multiple_items(spark_session, config):
    integration_output = spark_session.createDataFrame([
        {
            "job_bag_number": "job_bag_1",
            "campaign_id": "campaign_1",
            "correlation_id": "correlation_1",
            "marketing_type": CONTROL_TYPE,
            "channel_name": f"channel {CONTROL_TYPE}",
            "product_type": "Brand",
            "campaign_duration": DURING,
            "subchannel_name": subchannel,
            "incremental_sales_amt_exposed": incremental_sales,
            "attributed_recalibrated_sales_amt": attributed_sales,
            "incremental_units_qty_exposed": 1.0,
        }
        for subchannel, incremental_sales, attributed_sales in [("channel_1", 60.0, 30.0), ("channel_2", 40.0, 20.0)]
    ])
    # One campaign with a control uplift in each of two super categories
    #
    legacy_lift = spark_session.createDataFrame([
        {
            "campaign_id": "campaign_1",
            "campaign_source": CONTROL_TYPE,
            "channel_name": f"channel {CONTROL_TYPE}",
            "period": DURING,
            "campaign_start_date": "2024-01-01",
            "campaign_end_date": "2024-01-31",
            "item_cd": item_cd,
            "test": 100.0,
            "control": 50.0,
            "uplift": uplift,
            "media_cost": 20.0,
        }
        for item_cd, uplift in [("item_1", 20.0), ("item_2", 20.0)]
    ])
    brand_data = spark_session.createDataFrame([
        {"item_cd": "item_1", "super_category_name": "Beverages",
            "sub_category_name": "Soft Drinks", "unique_brand_name": "Brand A"},
        {"item_cd": "item_2", "super_category_name": "Snacks",
            "sub_category_name": "Crisps", "unique_brand_name": "Brand A"},
    ])
    unified_campaign = spark_session.createDataFrame([{"campaign_id": "campaign_1", "job_bag_number": "job_bag_1"}])

    result = apply_control_fallback(config, integration_output, legacy_lift, brand_data, unified_campaign)

    incrementality_by_channel = {
        row.subchannel_name: row.incremental_sales_amt_exposed for row in result.collect()
    }
    # Uplift is first(20, 20) against 100 incremental, so the factor is 0.2 and no channel row is duplicated
    assert incrementality_by_channel == pytest.approx({"channel_1": 12.0, "channel_2": 8.0})


def control_factor_inputs(spark_session, attributed_sales, uplift):
    integration_output = spark_session.createDataFrame([
        {
            "job_bag_number": "job_bag_1",
            "correlation_id": "correlation_1",
            "marketing_type": CONTROL_TYPE,
            "product_type": "Brand",
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": 100.0,
            "attributed_recalibrated_sales_amt": attributed_sales,
        },
    ])
    control_campaign = spark_session.createDataFrame([
        {
            "job_bag_number": "job_bag_1",
            "period": DURING,
            "campaign_end_date": "2024-01-31",
            "uplift": uplift,
        },
    ])
    return integration_output, control_campaign


def test_calculate_control_fallback_factor_divides_uplift_by_incrementality(spark_session, config):
    integration_output, control_campaign = control_factor_inputs(spark_session, attributed_sales=50.0, uplift=40.0)

    result = calculate_control_fallback_factor(config, integration_output, control_campaign)

    assert result.first().control_factor == pytest.approx(0.4)


@pytest.mark.parametrize(
    "attributed_sales, uplift",
    [
        pytest.param(50.0, 50.0, id="uplift_equal_to_attributed"),
        pytest.param(50.0, 80.0, id="uplift_above_attributed"),
        pytest.param(0.0, -5.0, id="zero_attributed"),
    ],
)
def test_calculate_control_fallback_factor_returns_none_when_uplift_is_not_usable(
    spark_session, attributed_sales, uplift, config
):
    integration_output, control_campaign = control_factor_inputs(spark_session, attributed_sales, uplift)

    result = calculate_control_fallback_factor(config, integration_output, control_campaign)

    # Uplift must be strictly below attributed sales to bring incrementality back under attribution
    assert result is None


def test_calculate_control_fallback_factor_returns_none_when_no_control_campaign_matches(spark_session, config):
    integration_output, control_campaign = control_factor_inputs(spark_session, attributed_sales=50.0, uplift=40.0)
    other_campaign = control_campaign.withColumn("job_bag_number", F.lit("job_bag_2"))

    result = calculate_control_fallback_factor(config, integration_output, other_campaign)

    assert result is None


@pytest.mark.parametrize("missing_reason", ["no_control", "zero_attributed", "wrong_product_type"])
def test_calculate_control_fallback_factor_requires_all_input_keys(spark_session, config, missing_reason):
    integration_output, control_campaign = control_factor_inputs(spark_session, attributed_sales=50.0, uplift=40.0)
    second_input = integration_output.withColumn("job_bag_number", F.lit("job_bag_2"))
    if missing_reason == "zero_attributed":
        second_input = second_input.withColumn("attributed_recalibrated_sales_amt", F.lit(0.0))
    elif missing_reason == "wrong_product_type":
        second_input = second_input.withColumn("product_type", F.lit("Offer"))
    if missing_reason != "no_control":
        control_campaign = control_campaign.unionByName(
            control_campaign.withColumn("job_bag_number", F.lit("job_bag_2"))
        )

    result = calculate_control_fallback_factor(
        config, integration_output.unionByName(second_input), control_campaign
    )

    assert result is None


def test_calculate_control_fallback_factor_ignores_extra_legacy_periods(spark_session, config):
    integration_output, control_campaign = control_factor_inputs(spark_session, attributed_sales=50.0, uplift=40.0)
    control_campaign = control_campaign.unionByName(
        control_campaign.withColumn("period", F.lit(CampaignDurations.CAMPAIGN_DURATION_POST))
    )

    result = calculate_control_fallback_factor(config, integration_output, control_campaign)

    assert result.count() == 1
    assert result.first().control_factor == pytest.approx(0.4)


def test_apply_fallback_uses_published_ratio_when_no_control_campaign_exists(spark_session, config):
    control_type = config.control_lift_marketing_types[0]

    integration_output = spark_session.createDataFrame([
        {
            "job_bag_number": "job_bag_1",
            "campaign_id": "campaign_1",
            "correlation_id": "correlation_1",
            "marketing_type": control_type,
            "channel_name": f"channel {control_type}",
            "product_type": "Brand",
            "campaign_duration": DURING,
            "subchannel_name": "channel_1",
            "incremental_sales_amt_exposed": 10.0,
            "attributed_recalibrated_sales_amt": 15.0,
            "incremental_units_qty_exposed": 4.0,
            "attributed_recalibrated_units_qty": 6.0,
        },
    ])
    # Every published campaign has ratio 50 / 100, so the fallback ratio is 0.5 whatever the percentile
    published_campaign_reporting = spark_session.createDataFrame([
        {
            "job_bag_number": f"published_{i}",
            "correlation_id": f"published_correlation_{i}",
            "marketing_type": "INSTORE",
            "product_type": "Brand",
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": 50.0,
            "attributed_recalibrated_sales_amt": 100.0
        }
        for i in range(5)
    ])
    # The only legacy control campaign belongs to a different booking than the integration output
    legacy_lift = spark_session.createDataFrame([
        {
            "campaign_id": "unrelated_campaign",
            "campaign_source": control_type,
            "period": DURING,
            "campaign_start_date": "2024-01-01",
            "campaign_end_date": "2024-01-31",
            "super_category_name": "Beverages",
            "sub_category_name": "Soft Drinks",
            "item_cd": "item_1",
            "test": 100.0,
            "control": 50.0,
            "uplift": 5.0,
            "media_cost": 20.0
        },
    ])
    brand_data = spark_session.createDataFrame([{"item_cd": "item_1", "unique_brand_name": "Brand A"}])
    unified_campaign = spark_session.createDataFrame([
        {"campaign_id": "campaign_1", "job_bag_number": "job_bag_1"},
        {"campaign_id": "unrelated_campaign",
            "job_bag_number": "unrelated_job_bag"},
    ])

    result = apply_fallback(
        integration_output,
        DURING,
        published_campaign_reporting,
        legacy_measurement_campaign_reporting=legacy_lift,
        brand_data=brand_data,
        unified_campaign=unified_campaign,
    )

    # Attributed sales of 15.0 and units of 6.0 fall back to 7.5 and 3.0 under the 0.5 published ratio
    rows = result.collect()
    assert [row.incremental_sales_amt_exposed for row in rows] == pytest.approx([7.5])
    assert [row.incremental_units_qty_exposed for row in rows] == pytest.approx([3.0])
    assert rows[0].state == FallbackTypes.FALLBACK_PUBLISHED
    assert rows[0].ratio == pytest.approx(0.5)


def test_aggregate_reporting(spark_session):

    integration_data = [

        {
            "job_bag_number": "job_bag_1",
            "marketing_type": "INSTORE",
            "channel_name": f"channel {CONTROL_TYPE}",
            "subchannel_name": "subchannel_1",
            "campaign_duration": DURING,
            "product_type": "Brand",
            "incremental_sales_amt_exposed": 100,
            "attributed_recalibrated_sales_amt": 50,
        },
        {
            "job_bag_number": "job_bag_1",
            "marketing_type": "OFFSITE",
            "channel_name": f"channel {CONTROL_TYPE}",
            "subchannel_name": "subchannel_2",
            "campaign_duration": DURING,
            "product_type": "Brand",
            "incremental_sales_amt_exposed": 200,
            "attributed_recalibrated_sales_amt": 100
        },
    ]

    integration_data = spark_session.createDataFrame(integration_data)

    expected_result = [
        {
            "job_bag_number": "job_bag_1",
            "campaign_duration": DURING,
            "product_type": "Brand",
            "incremental_sales_amt_exposed": 300,
            "attributed_recalibrated_sales_amt": 150
        }
    ]
    expected_result = spark_session.createDataFrame(expected_result)

    result = aggregate_reporting(integration_data)

    assert_df_equality(result, expected_result, ignore_nullable=True, ignore_column_order=True)


def test_get_published_ratios_only_includes_brand_rows(spark_session, config):
    campaigns = spark_session.createDataFrame([
        ("eligible_brand", "BRAND", DURING, 20.0, 100.0),
        ("zero_incrementality_offer", "OFFER", DURING, 0.0, 100.0),
        ("positive_incrementality_offer", "OFFER", DURING, 80.0, 100.0),
        ("mixed_case_brand", "Brand", DURING, 20.0, 100.0),
        ("unknown_product_type", "UNKNOWN", DURING, 20.0, 100.0),
        ("null_product_type", None, DURING, 20.0, 100.0),
    ], (
        "campaign_id string, product_type string, campaign_duration string, "
        "incremental_sales_amt_exposed double, attributed_recalibrated_sales_amt double"
    ))

    result = get_published_ratios(config, DURING, campaigns)

    assert [row.asDict() for row in result.select("campaign_id", "product_type", "published_ratio").collect()] == [
        {"campaign_id": "eligible_brand", "product_type": "BRAND", "published_ratio": 0.2},
        {"campaign_id": "mixed_case_brand", "product_type": "Brand", "published_ratio": 0.2},
    ]


def test_get_published_ratios_excludes_invalid_sales(spark_session, config):
    campaigns = spark_session.createDataFrame([
        {
            "campaign_id": "eligible",
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": 20.0,
            "attributed_recalibrated_sales_amt": 100.0,
            "product_type": "BRAND"
        },
        {
            "campaign_id": "zero_attributed_sales",
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": 10.0,
            "attributed_recalibrated_sales_amt": 0.0,
            "product_type": "BRAND"
        },
        {
            "campaign_id": "null_attributed_sales",
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": 10.0,
            "attributed_recalibrated_sales_amt": None,
            "product_type": "BRAND"
        },
        {
            "campaign_id": "null_incremental_sales",
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": None,
            "attributed_recalibrated_sales_amt": 100.0,
            "product_type": "BRAND"
        },
    ], schema=T.StructType([
        T.StructField("campaign_id", T.StringType()),
        T.StructField("campaign_duration", T.StringType()),
        T.StructField("incremental_sales_amt_exposed", T.DoubleType()),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType()),
        T.StructField("product_type", T.StringType()),
    ]))

    result = get_published_ratios(config, DURING, campaigns)

    returned_ids = {row.campaign_id for row in result.select("campaign_id").collect()}
    assert returned_ids == {"eligible"}


def test_get_published_ratios_excludes_maximum_ratio(spark_session, config):
    campaigns = spark_session.createDataFrame([
        {
            "campaign_id": "eligible",
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": 50.0,
            "attributed_recalibrated_sales_amt": 100.0,
            "product_type": "BRAND"
        },
        {
            "campaign_id": "at_maximum",
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": 100.0,
            "attributed_recalibrated_sales_amt": 100.0,
            "product_type": "BRAND"
        },
        {
            "campaign_id": "above_maximum",
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": 150.0,
            "attributed_recalibrated_sales_amt": 100.0,
            "product_type": "BRAND"
        },
    ])

    result = get_published_ratios(config, DURING, campaigns)

    returned_ids = {row.campaign_id for row in result.select("campaign_id").collect()}
    assert returned_ids == {"eligible"}


def test_get_published_ratios_raises_when_no_eligible_campaign(spark_session, config):
    campaigns = spark_session.createDataFrame([
        {
            "campaign_duration": DURING,
            "incremental_sales_amt_exposed": 150.0,
            "attributed_recalibrated_sales_amt": 100.0,
            "product_type": "BRAND",
        },
    ])

    with pytest.raises(RuntimeError, match="Insufficient published campaigns for fallback"):
        get_published_ratios(config, DURING, campaigns)


def test_compute_fallback_ratio_aggregates_campaigns_before_percentile(spark_session):
    config = IncrementalityFallbackConfig(
        fallback_percentile=0.5,
        max_fallback_ratio=1.0,
    )
    published_campaign_reporting = spark_session.createDataFrame([
        {
            "job_bag_number": "split_campaign",
            "correlation_id": "correlation_1",
            "marketing_type": "OFFSITE",
            "product_type": "Brand",
            "campaign_duration": DURING,
            "subchannel_name": "channel_1",
            "incremental_sales_amt_exposed": 10.0,
            "attributed_recalibrated_sales_amt": 10.0,
        },
        {
            "job_bag_number": "split_campaign",
            "correlation_id": "correlation_1",
            "marketing_type": "INSTORE",
            "product_type": "Brand",
            "campaign_duration": DURING,
            "subchannel_name": "channel_2",
            "incremental_sales_amt_exposed": 20.0,
            "attributed_recalibrated_sales_amt": 90.0,
        },
        {
            "job_bag_number": "campaign_2",
            "correlation_id": "correlation_2",
            "marketing_type": "INSTORE",
            "product_type": "Brand",
            "campaign_duration": DURING,
            "subchannel_name": "channel_1",
            "incremental_sales_amt_exposed": 20.0,
            "attributed_recalibrated_sales_amt": 100.0,
        },
        {
            "job_bag_number": "campaign_3",
            "correlation_id": "correlation_3",
            "marketing_type": "INSTORE",
            "product_type": "Brand",
            "campaign_duration": DURING,
            "subchannel_name": "channel_1",
            "incremental_sales_amt_exposed": 40.0,
            "attributed_recalibrated_sales_amt": 100.0,
        },
    ])

    result = compute_fallback_ratio(config, DURING, published_campaign_reporting)

    # The split campaign's ratio is (10 + 20) / (10 + 90) = 0.3;
    # the median of campaign ratios 0.2, 0.3, and 0.4 is 0.3.
    assert result == pytest.approx(0.3)


def test_apply_published_fallback_scales_and_preserves_rows(spark_session):
    config = IncrementalityFallbackConfig(
        fallback_percentile=0.5,
        min_published_campaigns=1,
        max_fallback_ratio=1.0,
    )
    # Ratio = 40/100 = 0.4
    # Configured such that the fallback ratio applied to the integration output will be 0.4
    published_campaign_reporting = spark_session.createDataFrame([
        {
            "job_bag_number": "published_campaign",
            "correlation_id": "published_correlation",
            "marketing_type": "INSTORE",
            "campaign_duration": DURING,
            "product_type": "Brand",
            "incremental_sales_amt_exposed": 40.0,
            "attributed_recalibrated_sales_amt": 100.0,
        },
    ])

    integration_output = spark_session.createDataFrame([
        {
            "job_bag_number": "integration_campaign",
            "correlation_id": "integration_correlation",
            "marketing_type": "INSTORE",
            "campaign_duration": DURING,
            "subchannel_name": "channel_1",
            "product_type": "Brand",
            "incremental_sales_amt_exposed": 10.0,
            "attributed_recalibrated_sales_amt": 15.0,
            "incremental_units_qty_exposed": 4.0,
            "attributed_recalibrated_units_qty": 5.0,
        },
        {
            "job_bag_number": "integration_campaign",
            "correlation_id": "integration_correlation",
            "marketing_type": "INSTORE",
            "campaign_duration": DURING,
            "subchannel_name": "channel_2",
            "product_type": "Brand",
            "incremental_sales_amt_exposed": 25.0,
            "attributed_recalibrated_sales_amt": 30.0,
            "incremental_units_qty_exposed": 9.0,
            "attributed_recalibrated_units_qty": 10.0,
        },
    ])
    expected_output = spark_session.createDataFrame([
        {
            "job_bag_number": "integration_campaign",
            "correlation_id": "integration_correlation",
            "marketing_type": "INSTORE",
            "campaign_duration": DURING,
            "subchannel_name": "channel_1",
            "product_type": "Brand",
            "incremental_sales_amt_exposed": 6.0,  # 15.0 * 0.4
            "attributed_recalibrated_sales_amt": 15.0,
            "incremental_units_qty_exposed": 2.0,  # 5.0 * 0.4
            "attributed_recalibrated_units_qty": 5.0,
        },
        {
            "job_bag_number": "integration_campaign",
            "correlation_id": "integration_correlation",
            "marketing_type": "INSTORE",
            "campaign_duration": DURING,
            "subchannel_name": "channel_2",
            "product_type": "Brand",
            "incremental_sales_amt_exposed": 12.0,  # 30.0 * 0.4
            "attributed_recalibrated_sales_amt": 30.0,
            "incremental_units_qty_exposed": 4.0,  # 10.0 * 0.4
            "attributed_recalibrated_units_qty": 10.0,
        },
    ])

    result, fallback_ratio = apply_published_fallback(config, DURING, integration_output, published_campaign_reporting)

    assert fallback_ratio == 0.4

    assert_df_equality(result, expected_output, ignore_nullable=True, ignore_column_order=True)


def test_apply_fallback_ratio_scales_units(spark_session):
    integration_output = spark_session.createDataFrame(
        [(20.0, 40.0, 10.0, 20.0)],
        "attributed_recalibrated_sales_amt double, incremental_sales_amt_exposed double, "
        "attributed_recalibrated_units_qty double, incremental_units_qty_exposed double",
    )

    row = apply_fallback_ratio(integration_output, 0.3).first()

    assert row.incremental_sales_amt_exposed == pytest.approx(6.0)
    assert row.incremental_units_qty_exposed == pytest.approx(3.0)


def test_apply_control_fallback_factor_scales_units(spark_session):
    integration_output = spark_session.createDataFrame(
        [("job_bag_1", DURING, 30.0, 12.0)],
        "job_bag_number string, campaign_duration string, "
        "incremental_sales_amt_exposed double, incremental_units_qty_exposed double",
    )
    control_factor = spark_session.createDataFrame(
        [("job_bag_1", DURING, 0.5)], "job_bag_number string, campaign_duration string, control_factor double",
    )

    row = apply_control_fallback_factor(integration_output, control_factor).first()

    assert row.incremental_sales_amt_exposed == pytest.approx(15.0)
    assert row.incremental_units_qty_exposed == pytest.approx(6.0)


@pytest.mark.parametrize("needs_fallback", [True, False])
def test_get_fallback_metadata(spark_session, needs_fallback):
    actual = get_fallback_metadata(spark_session, "corr-123", needs_fallback)
    expected = spark_session.createDataFrame([
        ("corr-123", needs_fallback),
    ], ["correlation_id", "is_fallback"])

    assert_df_equality(actual, expected)


FALLBACK_MODULE = "spark_pipeline.measurement_campaign_reporting.incrementality_fallback"
PERIOD_SCHEMA = (
    "campaign_id string, booking_id string, marketing_type string, channel_name string, subchannel_name string, "
    "marketing_hierarchy_cd string, sub_category_name string, super_category_name string, job_bag_number string, "
    "journey_type string, campaign_type string, campaign_name string, product_type string, campaign_duration string, "
    "attributed_recalibrated_sales_amt double, incremental_sales_amt_exposed double, "
    "attributed_recalibrated_units_qty double, incremental_units_qty_exposed double, media_spend_amt double"
)
PRE_SCHEMA = "_pre_incremental_sales_amt_exposed double, _pre_incremental_units_qty_exposed double"


def period_row(campaign_duration, sales, incremental, units, incremental_units, **overrides):
    row = {
        "campaign_id": "cmp_001",
        "booking_id": "bk_001",
        "marketing_type": "OFFSITE",
        "channel_name": "meta",
        "subchannel_name": "social",
        "marketing_hierarchy_cd": "mh_001",
        "sub_category_name": "Sub Cat",
        "super_category_name": "Super Cat",
        "job_bag_number": "jb_001",
        "journey_type": "Direct",
        "campaign_type": "Single Channel",
        "campaign_name": "Campaign 1",
        "product_type": "BRAND",
        "campaign_duration": campaign_duration,
        "attributed_recalibrated_sales_amt": sales,
        "incremental_sales_amt_exposed": incremental,
        "attributed_recalibrated_units_qty": units,
        "incremental_units_qty_exposed": incremental_units,
        "media_spend_amt": 50.0,
    }
    return {**row, **overrides}


def during_plus_post_row(**overrides):
    """During+Post = 120/60 sales, 60/30 units (During = 100/20, 50/10)."""
    return period_row("During+Post", 120.0, 60.0, 60.0, 30.0, **overrides)


def post_row(**overrides):
    """Post = 20/40 sales, 10/20 units, so incremental >= attributed."""
    return period_row("Post", 20.0, 40.0, 10.0, 20.0, **overrides)


def fallen_back_post_row(**overrides):
    """The Post row after fallback at r = 0.3: incremental 6 and 3, pre-fallback 40 and 20."""
    return {
        **post_row(incremental_sales_amt_exposed=6.0, incremental_units_qty_exposed=3.0, **overrides),
        "_pre_incremental_sales_amt_exposed": 40.0,
        "_pre_incremental_units_qty_exposed": 20.0,
    }


def post_frame(spark_session, rows):
    return spark_session.createDataFrame(rows, f"{PERIOD_SCHEMA}, {PRE_SCHEMA}")


def during_plus_post_frame(spark_session, rows):
    return spark_session.createDataFrame(rows, PERIOD_SCHEMA)


def rows_by_period(df):
    return {(row["campaign_duration"], row["campaign_id"].lower()): row.asDict() for row in df.collect()}


def rows_by_campaign(df):
    return {row["campaign_id"].lower(): row.asDict() for row in df.collect()}


def test_apply_period_fallback_changes_brand_but_preserves_offer(spark_session):
    brand = period_row(DURING, 20.0, 20.0, 10.0, 10.0, product_type="BRAND")
    offer = period_row(
        DURING, 100.0, 0.0, 50.0, 0.0, product_type="OFFER",
        campaign_id="offer_campaign", booking_id="offer_booking",
    )
    df = spark_session.createDataFrame([brand, offer], PERIOD_SCHEMA)

    with patch(f"{FALLBACK_MODULE}.compute_fallback_ratio", return_value=0.3):
        result = apply_period_fallback(df, DURING, published_campaign_reporting=None)

    rows = {row["product_type"]: row.asDict() for row in result.collect()}
    assert rows["BRAND"]["incremental_sales_amt_exposed"] == pytest.approx(6.0)
    assert rows["BRAND"]["incremental_units_qty_exposed"] == pytest.approx(3.0)
    assert {column: rows["OFFER"][column] for column in offer} == offer
    assert rows["OFFER"]["state"] is None
    assert rows["OFFER"]["ratio"] is None
    assert rows["OFFER"]["control_factor"] is None
    assert len(rows) == 2


@pytest.mark.parametrize(
    "control_available, expected_state, expected_sales, expected_units",
    [
        (True, FallbackTypes.FALLBACK_CONTROL, 12.0, 6.0),
        (False, FallbackTypes.FALLBACK_PUBLISHED, 6.0, 3.0),
    ],
)
def test_apply_period_fallback_preserves_offer_for_control_paths(
    spark_session, control_available, expected_state, expected_sales, expected_units
):
    brand = period_row(
        DURING, 20.0, 30.0, 10.0, 15.0, product_type="BRAND",
        channel_name="channel coupon at till", marketing_type="COUPON AT TILL",
    )
    offer = period_row(
        DURING, 100.0, 0.0, 50.0, 0.0, product_type="OFFER",
        campaign_id="offer_campaign", booking_id="offer_booking",
        channel_name="channel coupon at till", marketing_type="COUPON AT TILL",
    )
    df = spark_session.createDataFrame([brand, offer], PERIOD_SCHEMA)

    def control_result(config, integration_output, *args):
        assert [row.product_type for row in integration_output.select("product_type").collect()] == ["BRAND"]
        if not control_available:
            return None
        return (
            integration_output
            .withColumn("incremental_sales_amt_exposed", F.lit(12.0))
            .withColumn("incremental_units_qty_exposed", F.lit(6.0))
            .withColumn("control_factor", F.lit(0.4))
        )

    with patch(f"{FALLBACK_MODULE}.apply_control_fallback", side_effect=control_result) as mock_control, \
            patch(f"{FALLBACK_MODULE}.compute_fallback_ratio", return_value=0.3):
        result = apply_period_fallback(df, DURING, published_campaign_reporting=None)

    mock_control.assert_called_once()
    rows = {row["product_type"]: row.asDict() for row in result.collect()}
    assert rows["BRAND"]["incremental_sales_amt_exposed"] == pytest.approx(expected_sales)
    assert rows["BRAND"]["incremental_units_qty_exposed"] == pytest.approx(expected_units)
    assert rows["BRAND"]["state"] == expected_state
    assert {column: rows["OFFER"][column] for column in offer} == offer
    assert rows["OFFER"]["state"] is None
    assert rows["OFFER"]["ratio"] is None
    assert rows["OFFER"]["control_factor"] is None


def test_apply_period_fallback_skips_offer_only_and_noncanonical_product_types(spark_session):
    rows = [
        period_row(DURING, 100.0, 120.0, 50.0, 60.0, product_type="OFFER"),
        period_row(DURING, 100.0, 120.0, 50.0, 60.0, product_type="UNKNOWN"),
        period_row(DURING, 100.0, 120.0, 50.0, 60.0, product_type=None),
    ]
    df = spark_session.createDataFrame(rows, PERIOD_SCHEMA)

    with patch(f"{FALLBACK_MODULE}.apply_fallback") as mock_fallback:
        result = apply_period_fallback(df, DURING, published_campaign_reporting=None)

    mock_fallback.assert_not_called()
    assert result is df
    assert result.count() == len(rows)


def test_apply_period_fallback_scales_post_rows_and_propagates_to_during_plus_post(spark_session):
    # During+Post totals (120/60) would not trigger fallback; Post on its own (20/40) does.
    df = spark_session.createDataFrame(
        [during_plus_post_row(), post_row()], PERIOD_SCHEMA
    )

    with patch(f"{FALLBACK_MODULE}.compute_fallback_ratio", return_value=0.3), \
            patch(f"{FALLBACK_MODULE}.apply_fallback", wraps=apply_fallback) as spy:
        result = apply_period_fallback(df, POST, published_campaign_reporting=None)

    assert [row["campaign_duration"] for row in spy.call_args.args[0].collect()] == ["Post"]
    assert not any(c.startswith("_pre_") for c in result.columns)
    rows = rows_by_period(result)
    post = rows[("Post", "cmp_001")]
    assert post["incremental_sales_amt_exposed"] == pytest.approx(6.0)  # 20 x 0.3
    assert post["incremental_units_qty_exposed"] == pytest.approx(3.0)  # 10 x 0.3
    # During+Post takes the Post change, not the ratio: 60 + (6 - 40), 30 + (3 - 20).
    during_plus_post = rows[("During+Post", "cmp_001")]
    assert during_plus_post["incremental_sales_amt_exposed"] == pytest.approx(26.0)
    assert during_plus_post["incremental_units_qty_exposed"] == pytest.approx(13.0)
    assert during_plus_post["state"] is None


def test_apply_period_fallback_propagates_post_brand_only(spark_session):
    brand_during_plus_post = during_plus_post_row(
        incremental_sales_amt_exposed=60.0, incremental_units_qty_exposed=30.0,
    )
    brand_post = post_row(incremental_sales_amt_exposed=40.0, incremental_units_qty_exposed=20.0)
    offer_during_plus_post = during_plus_post_row(
        product_type="OFFER", incremental_sales_amt_exposed=0.0, incremental_units_qty_exposed=0.0,
    )
    offer_post = post_row(
        product_type="OFFER", incremental_sales_amt_exposed=0.0, incremental_units_qty_exposed=0.0,
    )
    df = spark_session.createDataFrame(
        [brand_during_plus_post, brand_post, offer_during_plus_post, offer_post], PERIOD_SCHEMA
    )

    with patch(f"{FALLBACK_MODULE}.compute_fallback_ratio", return_value=0.3):
        result = apply_period_fallback(df, POST, published_campaign_reporting=None)

    rows = {(row["campaign_duration"], row["product_type"]): row.asDict() for row in result.collect()}
    assert rows[("Post", "BRAND")]["incremental_sales_amt_exposed"] == pytest.approx(6.0)
    assert rows[("Post", "BRAND")]["incremental_units_qty_exposed"] == pytest.approx(3.0)
    assert rows[("During+Post", "BRAND")]["incremental_sales_amt_exposed"] == pytest.approx(26.0)
    assert rows[("During+Post", "BRAND")]["incremental_units_qty_exposed"] == pytest.approx(13.0)
    for period, original in [("Post", offer_post), ("During+Post", offer_during_plus_post)]:
        assert {column: rows[(period, "OFFER")][column] for column in original} == original


@pytest.mark.parametrize("product_type", ["BRAND", "OFFER"])
def test_floor_post_incrementality_zeroes_negative_sales_and_propagates(spark_session, product_type):
    """Post -5/-5 is floored to 0/0 and During+Post 15/5 moves to the During value 20/10."""
    df = spark_session.createDataFrame([
        during_plus_post_row(product_type=product_type,
                             incremental_sales_amt_exposed=15.0, incremental_units_qty_exposed=5.0),
        post_row(product_type=product_type, incremental_sales_amt_exposed=-5.0, incremental_units_qty_exposed=-5.0),
    ], PERIOD_SCHEMA)
    slack_messenger = Mock()

    result, floored = floor_post_incrementality(df, slack_messenger)

    rows = rows_by_period(result)
    assert floored
    assert rows[("Post", "cmp_001")]["incremental_sales_amt_exposed"] == 0.0
    assert rows[("Post", "cmp_001")]["incremental_units_qty_exposed"] == 0.0
    assert rows[("During+Post", "cmp_001")]["incremental_sales_amt_exposed"] == pytest.approx(20.0)
    assert rows[("During+Post", "cmp_001")]["incremental_units_qty_exposed"] == pytest.approx(10.0)
    slack_messenger.send_message.assert_called_once()


@pytest.mark.parametrize(
    "incremental_sales, incremental_units",
    [pytest.param(0.0, 5.0, id="zero_sales"), pytest.param(5.0, -5.0, id="negative_units_only")],
)
def test_floor_post_incrementality_leaves_non_negative_sales(spark_session, incremental_sales, incremental_units):
    df = spark_session.createDataFrame([
        during_plus_post_row(),
        post_row(incremental_sales_amt_exposed=incremental_sales, incremental_units_qty_exposed=incremental_units),
    ], PERIOD_SCHEMA)
    slack_messenger = Mock()

    result, floored = floor_post_incrementality(df, slack_messenger)

    assert not floored
    assert result is df
    slack_messenger.send_message.assert_not_called()


def test_get_fallback_method_with_no_channels_uses_published_ratio(spark_session, config):
    assert fallback_method_for(spark_session, config, DURING) == FallbackTypes.FALLBACK_PUBLISHED


def test_propagate_only_changes_incremental_columns_on_changed_keys(spark_session):
    post_rows = post_frame(spark_session, [
        fallen_back_post_row(),
        {**post_row(campaign_id="cmp_002"),
         "_pre_incremental_sales_amt_exposed": 40.0, "_pre_incremental_units_qty_exposed": 20.0},
    ])
    during_plus_post_rows = during_plus_post_frame(
        spark_session, [during_plus_post_row(), during_plus_post_row(campaign_id="cmp_002")]
    )
    before = rows_by_campaign(during_plus_post_rows)

    after = rows_by_campaign(propagate_post_changes(post_rows, during_plus_post_rows))

    assert after["cmp_002"] == before["cmp_002"]
    changed = after["cmp_001"]
    assert changed["incremental_sales_amt_exposed"] == pytest.approx(26.0)  # 60 + (6 - 40)
    assert changed["incremental_units_qty_exposed"] == pytest.approx(13.0)  # 30 + (3 - 20)
    assert {c for c in changed if changed[c] != before["cmp_001"][c]} == set(FALLBACK_ADJUSTED_COLUMNS)


def test_propagate_matches_mixed_case_keys(spark_session):
    # Post rows carry separation's normalised keys and During's names; During+Post keeps its own casing.
    post_rows = post_frame(spark_session, [
        fallen_back_post_row(
            campaign_id="Cmp_001", booking_id="Bk_001", marketing_type="Offsite",
            marketing_hierarchy_cd="Mh_001", job_bag_number="Jb_001", campaign_name="Campaign 1",
        ),
    ])
    during_plus_post_rows = during_plus_post_frame(
        spark_session, [during_plus_post_row(campaign_name="CAMPAIGN 1", subchannel_name="Social")]
    )

    after = rows_by_campaign(propagate_post_changes(post_rows, during_plus_post_rows))

    assert after["cmp_001"]["incremental_sales_amt_exposed"] == pytest.approx(26.0)
    assert after["cmp_001"]["incremental_units_qty_exposed"] == pytest.approx(13.0)


def test_propagate_raises_for_duplicate_post_keys(spark_session):
    post_rows = post_frame(spark_session, [fallen_back_post_row(), fallen_back_post_row()])
    during_plus_post_rows = during_plus_post_frame(spark_session, [during_plus_post_row()])

    with pytest.raises(RuntimeError, match="Incrementality Fallback failure - Duplicate Post keys found"):
        propagate_post_changes(post_rows, during_plus_post_rows)


def test_propagate_raises_when_changed_post_key_has_no_during_plus_post_row(spark_session):
    post_rows = post_frame(spark_session, [fallen_back_post_row(campaign_id="cmp_003")])
    during_plus_post_rows = during_plus_post_frame(
        spark_session, [during_plus_post_row(), during_plus_post_row(campaign_id="cmp_002")]
    )

    with pytest.raises(RuntimeError, match="Incrementality Fallback failure - Unmatched Post keys found"):
        propagate_post_changes(post_rows, during_plus_post_rows)


def test_propagate_unmatched_during_plus_post_untouched(spark_session):
    post_rows = post_frame(spark_session, [fallen_back_post_row()])
    during_plus_post_rows = during_plus_post_frame(
        spark_session, [during_plus_post_row(), during_plus_post_row(campaign_id="cmp_002")]
    )
    before = rows_by_campaign(during_plus_post_rows)
    slack_messenger = Mock()

    after = rows_by_campaign(propagate_post_changes(post_rows, during_plus_post_rows))

    assert after["cmp_002"] == before["cmp_002"]
    assert after["cmp_001"]["incremental_sales_amt_exposed"] == pytest.approx(26.0)
    slack_messenger.send_message.assert_not_called()
