from datetime import datetime
from pyspark.sql import types as T

from spark_pipeline.measurement_campaign_reporting.validator import (
    null_validation_checker
)


def test_null_validation_with_nectar_flag_true(spark_session):
    spark = spark_session
    data = [
        ("A", None, "X"),
        (None, "B", "Y"),
        ("C", "D", None)
    ]
    cols = ["id", "nectar_score", "value"]
    df = spark.createDataFrame(data, cols)

    # By default any column containing nectar can be null
    result_df = null_validation_checker(df, other_null_cols=["value"], nectar_flag=True)

    # Should return DataFrame with same schema
    result_df.show()
    assert result_df.columns == ["failed_null_columns", "null_column_count"] + cols
    assert result_df.count() == 1


def test_null_validation_with_nectar_flag_false(spark_session):
    spark = spark_session
    data = [
        ("A", "B"),
        (None, "C"),
    ]
    cols = ["id", "name"]
    df = spark.createDataFrame(data, cols)
    # What this unit test is saying is that the only field which can contain null is the name field.
    result_df = null_validation_checker(df, other_null_cols=["name"], nectar_flag=False)

    assert result_df.columns == ["failed_null_columns", "null_column_count"] + cols
    result_df.show()
    assert result_df.count() == 1  # All rows kept since filter is inverted


def test_null_validation_with_no_other_null_cols(spark_session):
    spark = spark_session
    data = [(1, None), (2, 3)]
    df = spark.createDataFrame(data, ["id", "name"])

    # What we are saying is that any field can be null. If no other_nullable field
    # is provided, all values including is considered valid.

    result_df = null_validation_checker(df)
    assert result_df.count() == 1


def test_null_validation_measurement_report_pollen(spark_session):
    spark = spark_session
    data = [(
        "test_run_123", None, "B1", 7, "Non-direct", "Social", "Meta", "Instagram",
        11, 1.3, 50.0, 12, 13, 200.0, 50.0, 10.0, 30.0, 150.0, 1.3, 1.5,
        "NA", 150.0, 50.0, 245.90, "Multi Channel", 0.0, 0.0, 150.0, 0.25, 0.2, 2, 1,
        100.0, 200.0, 0.5, 50.0, datetime(2025, 11, 1, 23, 11, 58), "MH001"  # Add marketing_hierarchy_cd
    )]

    schema = T.StructType([
        T.StructField("correlation_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.IntegerType(), True),
        T.StructField("journey_type", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("attributed_conversions", T.DoubleType(), True),
        T.StructField("incremental_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("campaign_name", T.StringType(), True),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType(), True),
        T.StructField("attributed_recalibrated_units_qty", T.DoubleType(), True),
        T.StructField("incremental_units_qty_exposed", T.DoubleType(), True),
        T.StructField("attributed_units_qty", T.DoubleType(), True),
        T.StructField("attributed_sales_amt", T.DoubleType(), True),
        T.StructField("conversions_recalibrated", T.DoubleType(), True),
        T.StructField("recalibration_factor", T.DoubleType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("nectar_sales_amt", T.DoubleType(), True),
        T.StructField("non_nectar_sales_amt", T.DoubleType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_type", T.StringType(), True),
        T.StructField("roas_exposed", T.DoubleType(), True),
        T.StructField("iroas_exposed", T.DoubleType(), True),
        T.StructField("base_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("uplift_exposed_sales_amt", T.DoubleType(), True),
        T.StructField("uplift_exposed_units_qty", T.DoubleType(), True),
        T.StructField("num_user_journeys", T.IntegerType(), True),
        T.StructField("num_conversions", T.IntegerType(), True),
        T.StructField("attributed_recalibrated_sales_amt_per_uj", T.DoubleType(), True),
        T.StructField("attributed_recalibrated_sales_amt_per_conversion", T.DoubleType(), True),
        T.StructField("conversion_per_uj", T.DoubleType(), True),
        T.StructField("conversion_rate", T.DoubleType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True)  # Add this field
    ])

    df = spark.createDataFrame(data, schema)
    # other_null_cols defaults to None internally handled
    result_df = null_validation_checker(df, nectar_flag=False, other_null_cols=["campaign_id"])
    result_df.show(truncate=False, vertical=True)
    assert result_df.count() == 0


def test_no_null_allowed_single_validation(spark_session):
    spark = spark_session
    data = [(
        "test_run_123", None, "B1", 7, "Non-direct", "Social", "Meta", "Instagram",
        11, 1.3, 50.0, 12, 13, 200.0, 50.0, 10.0, 30.0, 150.0, 1.3, 1.5,
        "NA", 150.0, 50.0, 245.90, "Multi Channel", 0.0, 0.0, 150.0, 0.25, 0.2, 2, 1,
        100.0, 200.0, 0.5, None, datetime(2025, 11, 1, 23, 11, 23), "MH001"
    )]

    schema = T.StructType([
        T.StructField("correlation_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.IntegerType(), True),
        T.StructField("journey_type", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("attributed_conversions", T.DoubleType(), True),
        T.StructField("incremental_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("campaign_name", T.StringType(), True),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType(), True),
        T.StructField("attributed_recalibrated_units_qty", T.DoubleType(), True),
        T.StructField("incremental_units_qty_exposed", T.DoubleType(), True),
        T.StructField("attributed_units_qty", T.DoubleType(), True),
        T.StructField("attributed_sales_amt", T.DoubleType(), True),
        T.StructField("conversions_recalibrated", T.DoubleType(), True),
        T.StructField("recalibration_factor", T.DoubleType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("nectar_sales_amt", T.DoubleType(), True),
        T.StructField("non_nectar_sales_amt", T.DoubleType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_type", T.StringType(), True),
        T.StructField("roas_exposed", T.DoubleType(), True),
        T.StructField("iroas_exposed", T.DoubleType(), True),
        T.StructField("base_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("uplift_exposed_sales_amt", T.DoubleType(), True),
        T.StructField("uplift_exposed_units_qty", T.DoubleType(), True),
        T.StructField("num_user_journeys", T.IntegerType(), True),
        T.StructField("num_conversions", T.IntegerType(), True),
        T.StructField("attributed_recalibrated_sales_amt_per_uj", T.DoubleType(), True),
        T.StructField("attributed_recalibrated_sales_amt_per_conversion", T.DoubleType(), True),
        T.StructField("conversion_per_uj", T.DoubleType(), True),
        T.StructField("conversion_rate", T.DoubleType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True)
    ])

    df = spark.createDataFrame(data, schema)
    # When no other_null_cols is provided means all fields are mandatory
    result_df = null_validation_checker(df, nectar_flag=False)
    result_df.show(truncate=False, vertical=True)
    assert result_df.count() == 1


def test_no_null_allowed_validation_report_pollen(spark_session):
    spark = spark_session
    data = [(
        "test_run_123", None, "B1", 7, "Non-direct", "Social", "Meta", "Instagram",
        11, 1.3, 50.0, 12, 13, 200.0, 50.0, 10.0, 30.0, 150.0, 1.3, 1.5,
        "NA", 150.0, 50.0, 245.90, "Multi Channel", 0.0, 0.0, 150.0, 0.25, 0.2, 2, 1,
        100.0, 200.0, 0.5, 45.50, datetime(2025, 11, 1, 23, 11, 23), "MH001"
    ),
        (
        "test_run_456", None, "B1", 7, "Non-direct", "Social", "Meta", "Instagram",
        11, 1.3, 50.0, 12, 13, 200.0, 50.0, 10.0, 30.0, 150.0, 1.3, 1.5,
        "NA", 150.0, 50.0, 245.90, "Multi Channel", 0.0, 0.0, 150.0, 0.25, 0.2, 2, 1,
        100.0, 200.0, 0.5, 450.25, datetime(2025, 11, 1, 23, 11, 23), "MH001"
    ),
        (
        "test_run_789", None, None, 7, "Non-direct", "Social", "Meta", "Instagram",
        11, 1.3, 50.0, 12, 13, 200.0, 50.0, 10.0, 30.0, 150.0, 1.3, 1.5,
        "NA", 150.0, 50.0, 245.90, "Multi Channel", 0.0, 0.0, 150.0, 0.25, 0.2, 2, 1,
        100.0, 200.0, 0.5, 11.25, datetime(2025, 11, 1, 23, 11, 23), "MH001"
    ),
        (
        "test_run_101", None, "B1", 7, "Non-direct", "Social", "Meta", "Instagram",
        11, 1.3, 50.0, 12, 13, 200.0, 50.0, 10.0, 30.0, 150.0, 1.3, 1.5,
        "NA", 150.0, 50.0, None, "Multi Channel", 0.0, 0.0, 150.0, 0.25, 0.2, 2, 1,
        100.0, 200.0, 0.5, None, datetime(2025, 11, 1, 23, 11, 23), "MH001"
    ),
        (
        "test_run_202", None, "B1", 7, "Non-direct", "Social", "Meta", "Instagram",
        11, 1.3, 50.0, 12, 13, 200.0, 50.0, 10.0, 30.0, 150.0, 1.3, 1.5,
        "NA", 150.0, 50.0, 245.90, "Multi Channel", 0.0, 0.0, 150.0, 0.25, 0.2, 2, None,
        100.0, 200.0, None, None, datetime(2025, 11, 1, 23, 11, 23), "MH001"
    ),
        (
        "test_run_305", 'CAMP1', "B1", 7, "Non-direct", "Social", "Meta", "Instagram",
        11, 1.3, 50.0, 12, 13, 200.0, 50.0, 10.0, 30.0, 150.0, 1.3, 1.5,
        "NA", 150.0, 50.0, 245.90, "Multi Channel", 0.0, 0.0, 150.0, 0.25, 0.2, None, 1,
        100.0, 200.0, 0.5, 75.5, datetime(2025, 11, 1, 23, 11, 23), "MH001"
    ),
        (
        "test_run_305", 'CAMP12', "B1", 7, "Non-direct", "Social", "Meta", "Instagram",
        11, 1.3, 50.0, 12, 13, 200.0, 50.0, 10.0, 30.0, 150.0, 1.3, 1.5,
        "NA", 150.0, 50.0, 245.90, "Multi Channel", 0.0, 0.0, 150.0, 0.25, 0.2, 22, 1,
        100.0, 200.0, 0.5, 75.5, datetime(2025, 11, 1, 23, 11, 23), "MH001"
    )
    ]

    schema = T.StructType([
        T.StructField("correlation_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.IntegerType(), True),
        T.StructField("journey_type", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("attributed_conversions", T.DoubleType(), True),
        T.StructField("incremental_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("campaign_name", T.StringType(), True),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType(), True),
        T.StructField("attributed_recalibrated_units_qty", T.DoubleType(), True),
        T.StructField("incremental_units_qty_exposed", T.DoubleType(), True),
        T.StructField("attributed_units_qty", T.DoubleType(), True),
        T.StructField("attributed_sales_amt", T.DoubleType(), True),
        T.StructField("conversions_recalibrated", T.DoubleType(), True),
        T.StructField("recalibration_factor", T.DoubleType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("nectar_sales_amt", T.DoubleType(), True),
        T.StructField("non_nectar_sales_amt", T.DoubleType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_type", T.StringType(), True),
        T.StructField("roas_exposed", T.DoubleType(), True),
        T.StructField("iroas_exposed", T.DoubleType(), True),
        T.StructField("base_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("uplift_exposed_sales_amt", T.DoubleType(), True),
        T.StructField("uplift_exposed_units_qty", T.DoubleType(), True),
        T.StructField("num_user_journeys", T.IntegerType(), True),
        T.StructField("num_conversions", T.IntegerType(), True),
        T.StructField("attributed_recalibrated_sales_amt_per_uj", T.DoubleType(), True),
        T.StructField("attributed_recalibrated_sales_amt_per_conversion", T.DoubleType(), True),
        T.StructField("conversion_per_uj", T.DoubleType(), True),
        T.StructField("conversion_rate", T.DoubleType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True)  # Add this field
    ])

    df = spark.createDataFrame(data, schema)
    # other_null_cols defaults to None internally handled
    result_df = null_validation_checker(df, nectar_flag=False,
                                        other_null_cols=['campaign_id', 'booking_id'])
    result_df.show(truncate=False, vertical=True)
    assert result_df.count() == 3
