from datetime import datetime

import pytest
from pyspark.sql import types as T

from spark_pipeline.measurement_campaign_reporting.post_period_utils import calculate_post_period_metrics
from spark_pipeline.measurement_campaign_reporting.reporting_utils import add_derived_metrics
from spark_pipeline.schemas.measurement_campaign_reporting import MeasurementCampaignReportingPollen


@pytest.fixture
def measurement_reporting_schema():
    """Reporting schema as written before spend weighting, exercising the unweighted path."""
    return T.StructType([
        field for field in MeasurementCampaignReportingPollen.measures_schema.fields
        if field.name not in ("product_type", "spend_weight")
    ])


@pytest.fixture
def weighted_reporting_schema():
    """Full reporting schema, including the spend weight columns."""
    return MeasurementCampaignReportingPollen.measures_schema


@pytest.fixture
def reach_df_fixture(spark_session):
    """Empty reach DataFrame — used where conversion_rate is not under test."""
    schema = T.StructType([
        T.StructField("re_booking_id", T.StringType()),
        T.StructField("re_channel_name", T.StringType()),
        T.StructField("re_subchannel_name", T.StringType()),
        T.StructField("reach_cnt", T.LongType()),
    ])
    return spark_session.createDataFrame([], schema)


@pytest.fixture
def reach_df_with_data(spark_session):
    """Non-empty reach DataFrame with a matching row for conversion_rate tests."""
    schema = T.StructType([
        T.StructField("re_booking_id", T.StringType()),
        T.StructField("re_channel_name", T.StringType()),
        T.StructField("re_subchannel_name", T.StringType()),
        T.StructField("reach_cnt", T.LongType()),
    ])
    return spark_session.createDataFrame(
        [("Book_001", "meta", "social - meta", 500)],
        schema,
    )


_DERIVED_INPUT_SCHEMA = T.StructType([
    T.StructField(name, T.DoubleType()) for name in (
        "attributed_recalibrated_sales_amt",
        "attributed_recalibrated_units_qty",
        "incremental_sales_amt_exposed",
        "incremental_units_qty_exposed",
        "media_spend_amt",
        "num_user_journeys",
        "num_conversions",
    )
])


def test_add_derived_metrics_computes_every_ratio_from_volumes(spark_session):
    df = spark_session.createDataFrame([(1000.0, 100.0, 200.0, 20.0, 400.0, 500.0, 20.0)], _DERIVED_INPUT_SCHEMA)

    row = add_derived_metrics(df).first()

    assert row["base_sales_amt_exposed"] == 800.0
    assert row["uplift_exposed_sales_amt"] == pytest.approx(200.0 / 800.0)
    assert row["uplift_exposed_units_qty"] == pytest.approx(20.0 / 80.0)
    assert row["roas_exposed"] == 2.5
    assert row["iroas_exposed"] == 0.5
    assert row["attributed_recalibrated_sales_amt_per_uj"] == 2.0
    assert row["attributed_recalibrated_sales_amt_per_conversion"] == 50.0


def test_add_derived_metrics_zero_denominators(spark_session):
    """ROAS/iROAS stay NULL on zero spend so the ROAS validation skips them; other ratios fall back to 0.0."""
    df = spark_session.createDataFrame([(100.0, 10.0, 100.0, 10.0, 0.0, 0.0, 0.0)], _DERIVED_INPUT_SCHEMA)

    row = add_derived_metrics(df).first()

    assert row["roas_exposed"] is None
    assert row["iroas_exposed"] is None
    assert row["uplift_exposed_sales_amt"] == 0.0
    assert row["uplift_exposed_units_qty"] == 0.0
    assert row["attributed_recalibrated_sales_amt_per_uj"] == 0.0
    assert row["attributed_recalibrated_sales_amt_per_conversion"] == 0.0


def _weighted_row(campaign_duration, sales, units, journeys, conversions, media_spend, product_type,
                  spend_weight, conversion_per_uj=0.08, incremental=5000.0, base=5000.0):
    """Row shaped to the full reporting schema, with only the asserted metrics varying."""
    return (
        "corr_001", "brand_x", "camp_001", "book_001", campaign_duration, "Offer", "OFFSITE",
        "Meta", "Social - Meta", "Sub Cat A", 100.0, incremental, "Super Cat A",
        "Campaign A", sales, units, 150.0, 180.0, 9000.0, 80.0, 1.2,
        "NA", 3000.0, 7000.0, media_spend, "Multi Channel", 10.0, 5.0,
        base, 0.5, 0.75, journeys, conversions, 10.0, 125.0, conversion_per_uj, 8.0,
        datetime(2024, 12, 1, 12, 0, 0), 120.01, "MH001", "Pollen",
        datetime(2024, 12, 1, 12, 0, 0), False, product_type, spend_weight,
    )


@pytest.fixture
def post_spend_weights(spark_session):
    """The During weight differs from the stored one, to prove the stored value is the one reused."""
    return spark_session.createDataFrame(
        [
            ("book_001", "BRAND", "During", 0.9),
            ("book_001", "BRAND", "Post", 0.25),
        ],
        T.StructType([
            T.StructField("booking_id", T.StringType()),
            T.StructField("product_type", T.StringType()),
            T.StructField("weight_period", T.StringType()),
            T.StructField("spend_weight", T.DoubleType()),
        ]),
    )


def test_calculate_post_period_metrics_weights_each_component_separately(
    spark_session,
    weighted_reporting_schema,
    reach_df_fixture,
    post_spend_weights,
):
    """Post is weighted on the raw delta, and During+Post is rebuilt from the two weighted parts."""
    during_plus_post_df = spark_session.createDataFrame(
        [_weighted_row("During+Post", 10000.0, 200.0, 1000.0, 10.0, 1000.0, "BRAND", None)],
        weighted_reporting_schema,
    )
    # Stored at weight 0.5, so the raw During sales are 8000 and the raw Post delta is 2000.
    during_df = spark_session.createDataFrame(
        [_weighted_row("During", 4000.0, 80.0, 400.0, 4.0, 900.0, "BRAND", 0.5)],
        weighted_reporting_schema,
    )

    result_df = calculate_post_period_metrics(
        measurement_campaign_reporting_df=during_plus_post_df,
        measurement_campaign_reporting_during=during_df,
        reach_df=reach_df_fixture,
        spend_weights=post_spend_weights,
    )

    rows = {row["campaign_duration"]: row for row in result_df.collect()}
    assert set(rows) == {"Post", "During+Post"}

    post_row = rows["Post"]
    assert post_row["attributed_recalibrated_sales_amt"] == 500.0  # (10000 - 4000/0.5) * 0.25
    assert post_row["num_conversions"] == 1.0  # (10 - 4/0.5) * 0.25 = 0.5, rounded to a whole conversion
    assert post_row["num_user_journeys"] == 600.0  # unweighted: 1000 - 400
    assert post_row["media_spend_amt"] == 900.0  # taken from During, never scaled
    assert post_row["spend_weight"] == 0.25

    during_plus_post_row = rows["During+Post"]
    assert during_plus_post_row["attributed_recalibrated_sales_amt"] == 4500.0  # 4000 + 500
    assert during_plus_post_row["num_conversions"] == 5.0  # 4 + 0.5, rounded
    assert during_plus_post_row["num_user_journeys"] == 1000.0  # untouched
    assert during_plus_post_row["media_spend_amt"] == 1000.0  # its own, not the During value
    assert during_plus_post_row["roas_exposed"] == 4.5  # 4500 / 1000

    # The rebuilt During+Post total still equals its two reported components.
    assert during_plus_post_row["num_conversions"] == 4.0 + post_row["num_conversions"]


def test_calculate_post_period_metrics_rebuilds_conversion_per_uj_from_its_own_numerator(
    spark_session,
    weighted_reporting_schema,
    reach_df_fixture,
    post_spend_weights,
):
    """conversion_per_uj tracks converted journeys, not the loyalty-id count behind num_conversions."""
    during_plus_post_df = spark_session.createDataFrame(
        [_weighted_row("During+Post", 10000.0, 200.0, 1000.0, 10.0, 1000.0, "BRAND", None,
                       conversion_per_uj=1.0)],
        weighted_reporting_schema,
    )
    during_df = spark_session.createDataFrame(
        [_weighted_row("During", 4000.0, 80.0, 400.0, 4.0, 900.0, "BRAND", 0.5,
                       conversion_per_uj=0.5)],
        weighted_reporting_schema,
    )

    result_df = calculate_post_period_metrics(
        measurement_campaign_reporting_df=during_plus_post_df,
        measurement_campaign_reporting_during=during_df,
        reach_df=reach_df_fixture,
        spend_weights=post_spend_weights,
    )

    during_plus_post_row = [r for r in result_df.collect() if r["campaign_duration"] == "During+Post"][0]
    # Converted journeys: During 0.5 x 400 = 200, During+Post 1.0 x 1000 = 1000.
    # corrected = 200 + (1000 - 200/0.5) x 0.25 = 350, over the unchanged 1000 journeys.
    assert during_plus_post_row["conversion_per_uj"] == pytest.approx(0.35)
    # Scaling the rate by the num_conversions factor instead would have given 0.45.
    assert during_plus_post_row["num_conversions"] == 5.0

    # Post uses the same numerator: (1000 - 200/0.5) x 0.25 = 150, over 1000 - 400 journeys.
    post_row = [r for r in result_df.collect() if r["campaign_duration"] == "Post"][0]
    assert post_row["conversion_per_uj"] == pytest.approx(150.0 / 600.0)


def test_calculate_post_period_metrics_uplift_uses_base_denominator(
    spark_session,
    weighted_reporting_schema,
    reach_df_fixture,
    post_spend_weights,
):
    """Post uplift is incremental over base, matching the During rows it is compared against."""
    # Coherent decomposition: attributed = incremental + base on both sides.
    during_plus_post_df = spark_session.createDataFrame(
        [_weighted_row("During+Post", 40000.0, 200.0, 1000.0, 10.0, 1000.0, "BRAND", None,
                       incremental=6000.0, base=34000.0)],
        weighted_reporting_schema,
    )
    during_df = spark_session.createDataFrame(
        [_weighted_row("During", 4000.0, 80.0, 400.0, 4.0, 900.0, "BRAND", 0.5,
                       incremental=1000.0, base=3000.0)],
        weighted_reporting_schema,
    )

    result_df = calculate_post_period_metrics(
        measurement_campaign_reporting_df=during_plus_post_df,
        measurement_campaign_reporting_during=during_df,
        reach_df=reach_df_fixture,
        spend_weights=post_spend_weights,
    )

    post_row = [r for r in result_df.collect() if r["campaign_duration"] == "Post"][0]
    # incremental = (6000 - 1000/0.5) x 0.25 = 1000; base = (34000 - 3000/0.5) x 0.25 = 7000.
    assert post_row["incremental_sales_amt_exposed"] == pytest.approx(1000.0)
    assert post_row["base_sales_amt_exposed"] == pytest.approx(7000.0)
    assert post_row["uplift_exposed_sales_amt"] == pytest.approx(1000.0 / 7000.0)
    # The attributed denominator would have given 1000/8000.
    assert post_row["uplift_exposed_sales_amt"] != pytest.approx(1000.0 / 8000.0)


def test_calculate_post_period_metrics_without_matching_weight_leaves_component_unscaled(
    spark_session,
    weighted_reporting_schema,
    reach_df_fixture,
    post_spend_weights,
):
    """A booking absent from the weights table keeps its raw Post delta."""
    during_plus_post_df = spark_session.createDataFrame(
        [_weighted_row("During+Post", 10000.0, 200.0, 1000.0, 10.0, 1000.0, "OFFER", None)],
        weighted_reporting_schema,
    )
    during_df = spark_session.createDataFrame(
        [_weighted_row("During", 4000.0, 80.0, 400.0, 4.0, 900.0, "OFFER", 1.0)],
        weighted_reporting_schema,
    )

    result_df = calculate_post_period_metrics(
        measurement_campaign_reporting_df=during_plus_post_df,
        measurement_campaign_reporting_during=during_df,
        reach_df=reach_df_fixture,
        spend_weights=post_spend_weights,
    )

    post_row = [row for row in result_df.collect() if row["campaign_duration"] == "Post"][0]
    assert post_row["attributed_recalibrated_sales_amt"] == 6000.0
    assert post_row["spend_weight"] == 1.0


def test_calculate_post_period_metrics_success(spark_session, measurement_reporting_schema, reach_df_fixture):
    """Test successful calculation of Post period metrics."""

    # Create During+Post data (current run)
    during_plus_post_data = [
        (
            "corr_001", "brand_current", "camp_001", "book_001", "During+Post", "Offer", "OFFSITE",
            "Meta", "Social - Meta", "Sub Cat A", 100.0, 5000.0, "Super Cat A",
            "Campaign A", 10000.0, 200.0, 150.0, 180.0, 9000.0, 80.0, 1.2,
            "NA", 3000.0, 7000.0, 1000.0, "Multi Channel", 10.0, 5.0,
            5000.0, 0.5, 0.75, 1000.0, 80.0, 10.0, 125.0, 0.08, 8.0,
            datetime(2024, 12, 1, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]

    during_plus_post_df = spark_session.createDataFrame(
        during_plus_post_data,
        measurement_reporting_schema
    )

    # Create During data (historical baseline)
    during_data = [
        (
            "corr_000", "brand_old", "camp_001", "book_001", "During", "Offer", "OFFSITE",
            "Meta", "Social - Meta", "Sub Cat A", 40.0, 2000.0, "Super Cat A",
            "Campaign A", 4000.0, 80.0, 60.0, 70.0, 3500.0, 32.0, 1.2,
            "NA", 1200.0, 2800.0, 1000.0, "Multi Channel", 4.0, 2.0,
            2000.0, 0.5, 0.75, 400.0, 32.0, 4.0, 50.0, 0.08, 8.0,
            datetime(2024, 11, 15, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]

    during_df = spark_session.createDataFrame(during_data, measurement_reporting_schema)

    # Calculate Post period
    result_df = calculate_post_period_metrics(
        measurement_campaign_reporting_df=during_plus_post_df,
        measurement_campaign_reporting_during=during_df,
        reach_df=reach_df_fixture,
    )

    # Assertions
    assert result_df.count() == 1

    result_row = result_df.first()

    # Check campaign_duration is set to Post
    assert result_row["campaign_duration"] == "Post"

    # Check subtracted values (During+Post - During = Post)
    assert result_row["attributed_conversions"] == 60.0  # 100 - 40
    assert result_row["incremental_sales_amt_exposed"] == 3000.0  # 5000 - 2000
    assert result_row["attributed_recalibrated_sales_amt"] == 6000.0  # 10000 - 4000
    assert result_row["attributed_recalibrated_units_qty"] == 120.0  # 200 - 80
    assert result_row["conversions_recalibrated"] == 48.0  # 80 - 32
    assert result_row["num_user_journeys"] == 600.0  # 1000 - 400
    assert result_row["num_conversions"] == 48.0  # 80 - 32

    # Check media spend stays the same (from During period)
    assert result_row["media_spend_amt"] == 1000.0

    # Check derived metrics are recalculated
    assert result_row["roas_exposed"] == 6.0  # 6000 / 1000
    assert result_row["iroas_exposed"] == 3.0  # 3000 / 1000

    # Check correlation_id comes from During+Post
    assert result_row["correlation_id"] == "corr_001"
    # Post should carry the brand_id from the During-side row.
    assert result_row["brand_id"] == "brand_old"


def test_calculate_post_period_metrics_falls_back_to_during_brand_id(
    spark_session,
    measurement_reporting_schema,
    reach_df_fixture,
):
    """Test that Post uses During brand_id when During+Post brand_id is null."""

    during_plus_post_data = [
        (
            "corr_001", None, "camp_001", "book_001", "During+Post", "Offer", "OFFSITE",
            "Meta", "Social - Meta", "Sub Cat A", 100.0, 5000.0, "Super Cat A",
            "Campaign A", 10000.0, 200.0, 150.0, 180.0, 9000.0, 80.0, 1.2,
            "NA", 3000.0, 7000.0, 1000.0, "Multi Channel", 10.0, 5.0,
            5000.0, 0.5, 0.75, 1000.0, 80.0, 10.0, 125.0, 0.08, 8.0,
            datetime(2024, 12, 1, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]

    during_plus_post_df = spark_session.createDataFrame(
        during_plus_post_data,
        measurement_reporting_schema,
    )

    during_data = [
        (
            "corr_000", "brand_during", "camp_001", "book_001", "During", "Offer", "OFFSITE",
            "Meta", "Social - Meta", "Sub Cat A", 40.0, 2000.0, "Super Cat A",
            "Campaign A", 4000.0, 80.0, 60.0, 70.0, 3500.0, 32.0, 1.2,
            "NA", 1200.0, 2800.0, 1000.0, "Multi Channel", 4.0, 2.0,
            2000.0, 0.5, 0.75, 400.0, 32.0, 4.0, 50.0, 0.08, 8.0,
            datetime(2024, 11, 15, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]

    during_df = spark_session.createDataFrame(during_data, measurement_reporting_schema)

    result_df = calculate_post_period_metrics(
        measurement_campaign_reporting_df=during_plus_post_df,
        measurement_campaign_reporting_during=during_df,
        reach_df=reach_df_fixture,
    )

    result_row = result_df.first()
    assert result_row["brand_id"] == "brand_during"


def test_calculate_post_period_metrics_no_during_data(spark_session, measurement_reporting_schema):
    """Test error handling when no During data exists."""

    during_plus_post_data = [
        (
            "corr_001", None, "camp_001", "book_001", "During+Post", "Offer", "OFFSITE",
            "Meta", "Social - Meta", "Sub Cat A", 100.0, 5000.0, "Super Cat A",
            "Campaign A", 10000.0, 200.0, 150.0, 180.0, 9000.0, 80.0, 1.2,
            "NA", 3000.0, 7000.0, 1000.0, "Multi Channel", 10.0, 5.0,
            5000.0, 0.5, 0.75, 1000.0, 80.0, 10.0, 125.0, 0.08, 8.0,
            datetime(2024, 12, 1, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]

    during_plus_post_df = spark_session.createDataFrame(
        during_plus_post_data,
        measurement_reporting_schema
    )

    # Empty During data
    during_df = spark_session.createDataFrame([], measurement_reporting_schema)

    # Should raise ValueError
    with pytest.raises(ValueError, match=r"No During period data found for booking_ids: \['book_001'\]"):
        calculate_post_period_metrics(
            measurement_campaign_reporting_df=during_plus_post_df,
            measurement_campaign_reporting_during=during_df,
        )


def test_calculate_post_period_metrics_multiple_campaigns(spark_session, measurement_reporting_schema, reach_df_fixture):
    """Test Post calculation with multiple campaigns."""

    # During+Post data with 2 campaigns
    during_plus_post_data = [
        (
            "corr_001", None, "camp_001", "book_001", "During+Post", "Offer", "OFFSITE",
            "Meta", "Social - Meta", "Sub Cat A", 100.0, 5000.0, "Super Cat A",
            "Campaign A", 10000.0, 200.0, 150.0, 180.0, 9000.0, 80.0, 1.2,
            "NA", 3000.0, 7000.0, 1000.0, "Multi Channel", 10.0, 5.0,
            5000.0, 0.5, 0.75, 1000.0, 80.0, 10.0, 125.0, 0.08, 8.0,
            datetime(2024, 12, 1, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        ),
        (
            "corr_001", None, "camp_002", "book_001", "During+Post", "Offer", "OFFSITE",
            "DV360", "Display - DV360", "Sub Cat B", 150.0, 7000.0, "Super Cat B",
            "Campaign B", 15000.0, 300.0, 250.0, 280.0, 14000.0, 120.0, 1.3,
            "NA", 4500.0, 10500.0, 2000.0, "Multi Channel", 7.5, 3.5,
            8000.0, 0.466, 0.833, 1500.0, 120.0, 10.0, 125.0, 0.08, 8.0,
            datetime(2024, 12, 1, 12, 0, 0), 120.01, "MH002", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]

    during_plus_post_df = spark_session.createDataFrame(
        during_plus_post_data,
        measurement_reporting_schema
    )

    # During data with 2 campaigns
    during_data = [
        (
            "corr_000", None, "camp_001", "book_001", "During", "Offer", "OFFSITE",
            "Meta", "Social - Meta", "Sub Cat A", 40.0, 2000.0, "Super Cat A",
            "Campaign A", 4000.0, 80.0, 60.0, 70.0, 3500.0, 32.0, 1.2,
            "NA", 1200.0, 2800.0, 1000.0, "Multi Channel", 4.0, 2.0,
            2000.0, 0.5, 0.75, 400.0, 32.0, 4.0, 50.0, 0.08, 8.0,
            datetime(2024, 11, 15, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        ),
        (
            "corr_000", None, "camp_002", "book_001", "During", "Offer", "OFFSITE",
            "DV360", "Display - DV360", "Sub Cat B", 50.0, 3000.0, "Super Cat B",
            "Campaign B", 5000.0, 100.0, 80.0, 90.0, 4500.0, 40.0, 1.3,
            "NA", 1500.0, 3500.0, 2000.0, "Multi Channel", 2.5, 1.5,
            2000.0, 0.6, 0.8, 500.0, 40.0, 2.5, 62.5, 0.08, 8.0,
            datetime(2024, 11, 15, 12, 0, 0), 120.01, "MH002", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]

    during_df = spark_session.createDataFrame(during_data, measurement_reporting_schema)

    # Calculate Post period
    result_df = calculate_post_period_metrics(
        measurement_campaign_reporting_df=during_plus_post_df,
        measurement_campaign_reporting_during=during_df,
        reach_df=reach_df_fixture,
    )

    # Should have 2 rows (one for each campaign)
    assert result_df.count() == 2

    # Check both campaigns are present (after initcap transformation)
    campaign_ids = [row["campaign_id"] for row in result_df.collect()]
    assert "Camp_001" in campaign_ids  # Changed from "camp_001" to "Camp_001"
    assert "Camp_002" in campaign_ids  # Changed from "camp_002" to "Camp_002"

    # All rows should have campaign_duration = Post
    assert all(row["campaign_duration"] == "Post" for row in result_df.collect())


def test_calculate_post_period_metrics_case_sensitivity(spark_session, measurement_reporting_schema, reach_df_fixture):
    """Test that join handles case sensitivity correctly with trim and initcap."""

    # During+Post data with mixed case
    during_plus_post_data = [
        (
            "corr_001", None, "CAMP_001", "BOOK_001", "During+Post", "offer", "offsite",
            "meta", "social - meta", "sub cat a", 100.0, 5000.0, "super cat a",
            "campaign a", 10000.0, 200.0, 150.0, 180.0, 9000.0, 80.0, 1.2,
            "NA", 3000.0, 7000.0, 1000.0, "multi channel", 10.0, 5.0,
            5000.0, 0.5, 0.75, 1000.0, 80.0, 10.0, 125.0, 0.08, 8.0,
            datetime(2024, 12, 1, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]

    during_plus_post_df = spark_session.createDataFrame(
        during_plus_post_data,
        measurement_reporting_schema
    )

    # During data with different case
    during_data = [
        (
            "corr_000", None, "camp_001", "BOOK_001", "During", "Offer", "Offsite",
            "Meta", "Social - Meta", "Sub Cat A", 40.0, 2000.0, "Super Cat A",
            "Campaign A", 4000.0, 80.0, 60.0, 70.0, 3500.0, 32.0, 1.2,
            "NA", 1200.0, 2800.0, 1000.0, "Multi Channel", 4.0, 2.0,
            2000.0, 0.5, 0.75, 400.0, 32.0, 4.0, 50.0, 0.08, 8.0,
            datetime(2024, 11, 15, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]

    during_df = spark_session.createDataFrame(during_data, measurement_reporting_schema)

    # Should successfully match despite different cases
    result_df = calculate_post_period_metrics(
        measurement_campaign_reporting_df=during_plus_post_df,
        measurement_campaign_reporting_during=during_df,
        reach_df=reach_df_fixture,
    )

    assert result_df.count() == 1


def test_calculate_post_period_metrics_latest_load_ts(spark_session, measurement_reporting_schema, reach_df_fixture):
    """Test that only the latest During data is used."""

    during_plus_post_data = [
        (
            "corr_001", None, "camp_001", "book_001", "During+Post", "Offer", "OFFSITE",
            "Meta", "social - meta", "Sub Cat A", 100.0, 5000.0, "Super Cat A",
            "Campaign A", 10000.0, 200.0, 150.0, 180.0, 9000.0, 80.0, 1.2,
            "NA", 3000.0, 7000.0, 1000.0, "Multi Channel", 10.0, 5.0,
            5000.0, 0.5, 0.75, 1000.0, 80.0, 10.0, 125.0, 0.08, 8.0,
            datetime(2024, 12, 1, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]

    during_plus_post_df = spark_session.createDataFrame(
        during_plus_post_data,
        measurement_reporting_schema
    )

    # Multiple During records with different load_ts
    during_data = [
        # Older data
        (
            "corr_old", None, "camp_001", "book_001", "During", "Offer", "OFFSITE",
            "Meta", "Social - Meta", "Sub Cat A", 30.0, 1500.0, "Super Cat A",
            "Campaign A", 3000.0, 60.0, 45.0, 55.0, 2800.0, 24.0, 1.2,
            "NA", 900.0, 2100.0, 1000.0, "Multi Channel", 3.0, 1.5,
            1500.0, 0.5, 0.75, 300.0, 24.0, 3.0, 40.0, 0.08, 8.0,
            datetime(2024, 11, 1, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        ),
        # Latest data (should be used)
        (
            "corr_latest", None, "camp_001", "book_001", "During", "Offer", "OFFSITE",
            "Meta", "Social - meta", "Sub Cat A", 40.0, 2000.0, "Super Cat A",
            "Campaign A", 4000.0, 80.0, 60.0, 70.0, 3500.0, 32.0, 1.2,
            "NA", 1200.0, 2800.0, 1000.0, "Multi Channel", 4.0, 2.0,
            2000.0, 0.5, 0.75, 400.0, 32.0, 4.0, 50.0, 0.08, 8.0,
            datetime(2024, 11, 15, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]
    during_df = spark_session.createDataFrame(during_data, measurement_reporting_schema)

    result_df = calculate_post_period_metrics(
        measurement_campaign_reporting_df=during_plus_post_df,
        measurement_campaign_reporting_during=during_df,
        reach_df=reach_df_fixture,
    )

    result_row = result_df.first()

    # Should use latest During data (40, not 30)
    # Post = 100 - 40 = 60
    assert result_row["attributed_conversions"] == 60.0

    # Post sales = 10000 - 4000 = 6000 (not 10000 - 3000 = 7000)
    assert result_row["attributed_recalibrated_sales_amt"] == 6000.0

    # Confirm for Post we have exactly the same subchannel name as for During
    assert result_row["subchannel_name"] == "Social - meta"


def test_calculate_post_period_metrics_conversion_rate(spark_session, measurement_reporting_schema, reach_df_with_data):
    """
    conversion_rate for the Post period must equal:
        conversions_recalibrated_post / reach_cnt * 100

    During+Post conversions_recalibrated = 80, During = 32  →  Post = 48
    reach_cnt (from During run) = 500
    Expected conversion_rate = 48 / 500 * 100 = 9.6
    """
    during_plus_post_data = [
        (
            "corr_001", None, "camp_001", "book_001", "During+Post", "Offer", "OFFSITE",
            "Meta", "Social - Meta", "Sub Cat A", 100.0, 5000.0, "Super Cat A",
            "Campaign A", 10000.0, 200.0, 150.0, 180.0, 9000.0, 80.0, 1.2,
            "NA", 3000.0, 7000.0, 1000.0, "Multi Channel", 10.0, 5.0,
            5000.0, 0.5, 0.75, 1000.0, 80.0, 10.0, 125.0, 0.08, 8.0,
            datetime(2024, 12, 1, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]
    during_plus_post_df = spark_session.createDataFrame(
        during_plus_post_data, measurement_reporting_schema
    )

    during_data = [
        (
            "corr_000", None, "camp_001", "book_001", "During", "Offer", "OFFSITE",
            "Meta", "Social - Meta", "Sub Cat A", 40.0, 2000.0, "Super Cat A",
            "Campaign A", 4000.0, 80.0, 60.0, 70.0, 3500.0, 32.0, 1.2,
            "NA", 1200.0, 2800.0, 1000.0, "Multi Channel", 4.0, 2.0,
            2000.0, 0.5, 0.75, 400.0, 32.0, 4.0, 50.0, 0.08, 8.0,
            datetime(2024, 11, 15, 12, 0, 0), 120.01, "MH001", "Pollen",
            datetime(2024, 12, 1, 12, 0, 0), False
        )
    ]
    during_df = spark_session.createDataFrame(during_data, measurement_reporting_schema)

    result_df = calculate_post_period_metrics(
        measurement_campaign_reporting_df=during_plus_post_df,
        measurement_campaign_reporting_during=during_df,
        reach_df=reach_df_with_data,
    )

    assert result_df.count() == 1
    result_row = result_df.first()

    # Post conversions_recalibrated = 80 - 32 = 48, reach_cnt = 500
    assert result_row["conversions_recalibrated"] == 48.0
    assert result_row["conversion_rate"] == pytest.approx(48.0 / 500 * 100, rel=1e-6)
