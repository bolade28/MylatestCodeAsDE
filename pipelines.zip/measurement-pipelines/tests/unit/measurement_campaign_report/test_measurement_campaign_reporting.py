from datetime import datetime
from unittest.mock import Mock, patch

import pytest
from chispa.dataframe_comparer import assert_df_equality
from pyspark.sql import Row, functions as F, types as T

from spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting import (
    add_brand_id_to_integration_output,
    apply_spend_weights,
    combine_baseline_mta,
    entrypoint,
    get_brand_id_column,
    load_campaign_brand_id_mapping,
    load_spend_weights,
    prepare_baseline_mta_integration,
)
from spark_pipeline.schemas.measurement_campaign_reporting import MeasurementCampaignReportingPollen
from spark_pipeline.measurement_campaign_reporting.reporting_utils import (
    AUDIT_KEY_COLUMNS, add_fallback_audit, add_to_reporting_audit,
)
from tests.schemas.test_schema_measurement_campaign_reporting import (
    McrCombineBaselineMtaMockData,
)


PRE_MTA_SCHEMA = McrCombineBaselineMtaMockData.PRE_MTA
SLAS_SCHEMA = McrCombineBaselineMtaMockData.SLAS
CME_SCHEMA = McrCombineBaselineMtaMockData.CME
IC_SCHEMA = McrCombineBaselineMtaMockData.IC
BP_SCHEMA = McrCombineBaselineMtaMockData.BP
UC_POLLEN_SCHEMA = McrCombineBaselineMtaMockData.UC_POLLEN


def get_base_inputs(spark_session, run_type="Pollen"):
    """Return baseline input DataFrames for combine_baseline_mta tests."""
    pre_mta_brand = spark_session.createDataFrame(
        [
            Row(
                journey_type="Direct",
                userjourney_id="uj_001",
                loyalty_id="loy_001",
                booking_id="bk_001",
                marketing_type="OFFSITE",
                channel_name="meta",
                subchannel_name="social",
                campaign_id="cmp_001",
                campaign_duration="During",
                event_name="click",
                transaction_key="t_001",
                isconversion=1,
            )
        ],
        PRE_MTA_SCHEMA,
    )
    pre_mta_offer = spark_session.createDataFrame(
        [
            Row(
                journey_type="Direct",
                userjourney_id="uj_002",
                loyalty_id="loy_002",
                booking_id="bk_001",
                marketing_type="OFFSITE",
                channel_name="meta",
                subchannel_name="social",
                campaign_id="cmp_001",
                campaign_duration="During",
                event_name="click",
                transaction_key="t_002",
                isconversion=1,
            )
        ],
        PRE_MTA_SCHEMA,
    )
    slasb = spark_session.createDataFrame(
        [
            Row(
                journey_type="Direct",
                userjourney_id="uj_001",
                booking_id="bk_001",
                marketing_type="OFFSITE",
                channel_name="meta",
                subchannel_name="social",
                campaign_id="cmp_001",
                campaign_duration="During",
                recalibration_factor=1.0,
                attributed_recalibrated_units_qty=5.0,
                attributed_units_qty=4.0,
                attributed_recalibrated_sales_amt=100.0,
                attributed_sales_amt=80.0,
                isconversion=1,
                normalized_weights=1.0,
            )
        ],
        SLAS_SCHEMA,
    )
    slaso = spark_session.createDataFrame(
        [
            Row(
                journey_type="Direct",
                userjourney_id="uj_002",
                booking_id="bk_001",
                marketing_type="OFFSITE",
                channel_name="meta",
                subchannel_name="social",
                campaign_id="cmp_001",
                campaign_duration="During",
                recalibration_factor=1.0,
                attributed_recalibrated_units_qty=5.0,
                attributed_units_qty=4.0,
                attributed_recalibrated_sales_amt=100.0,
                attributed_sales_amt=80.0,
                isconversion=1,
                normalized_weights=1.0,
            )
        ],
        SLAS_SCHEMA,
    )
    cme = spark_session.createDataFrame(
        [
            Row(
                booking_id="bk_001",
                campaign_id="cmp_001",
                channel_name="meta",
                subchannel_name="social",
                campaign_start_dt=datetime(2025, 1, 1),
                campaign_end_dt=datetime(2025, 1, 31),
                overlapping_campaign_flag=False,
            )
        ],
        CME_SCHEMA,
    )
    ic = spark_session.createDataFrame(
        [
            Row(
                unique_brand_name="Brand A",
                super_category_name="Super Cat",
                sub_category_name="Sub Cat",
                metric_name="adjusted_calibrated_incrementality",
                metric_value=500.0,
            )
        ],
        IC_SCHEMA,
    )
    bp = spark_session.createDataFrame(
        [
            Row(
                week_start_dt=datetime(2025, 1, 6),
                metric_name="BASE_PRICE",
                metric_value=10.0,
            )
        ],
        BP_SCHEMA,
    )

    if run_type == "Pollen":
        uc = spark_session.createDataFrame(
            [
                Row(
                    booking_id="bk_001",
                    job_bag_number="jb_001",
                    campaign_id="cmp_001",
                    campaign_name="Campaign One",
                    channel_name="meta",
                    subchannel_name="social",
                    media_spend_amt=200.0,
                    super_category_name="Super Cat",
                    sub_category_name="Sub Cat",
                    is_multi_channel=False,
                    marketing_hierarchy_cd="mh_001",
                )
            ],
            UC_POLLEN_SCHEMA,
        )
    else:
        uc = spark_session.createDataFrame(
            [
                Row(
                    booking_id="bk_001",
                    job_bag_number="jb_001",
                    campaign_id="cmp_001",
                    campaign_name="Campaign One",
                    channel_name="meta",
                    subchannel_name="social",
                    media_spend_amt=200.0,
                    super_category_name="Super Cat",
                    sub_category_name="Sub Cat",
                    is_multi_channel=False,
                )
            ],
            McrCombineBaselineMtaMockData.UC_DTP,
        )

    return pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc


def _create_combine_output_df(spark_session):
    schema = T.StructType([
        T.StructField("unique_brand_name", T.StringType(), False),
        T.StructField("channel_name", T.StringType(), False),
        T.StructField("campaign_id", T.StringType(), False),
        T.StructField("booking_id", T.StringType(), False),
        T.StructField("campaign_duration", T.StringType(), False),
        T.StructField("journey_type", T.StringType(), False),
        T.StructField("marketing_type", T.StringType(), False),
        T.StructField("subchannel_name", T.StringType(), False),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True),
        T.StructField("sub_category_name", T.StringType(), True),
        T.StructField("attributed_conversions", T.DoubleType(), True),
        T.StructField("incremental_sales_amt_exposed", T.DoubleType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("campaign_name", T.StringType(), True),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType(), True),
        T.StructField("attributed_recalibrated_units_qty", T.DoubleType(), True),
        T.StructField("incremental_units_qty_exposed", T.DoubleType(), True),
        T.StructField("attributed_units_qty", T.DoubleType(), True),
        T.StructField("attributed_sales_amt", T.DoubleType(), True),
        T.StructField("conversions", T.DoubleType(), True),
        T.StructField("conversions_recalibrated", T.DoubleType(), True),
        T.StructField("recalibration_factor", T.DoubleType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_type", T.StringType(), True),
        T.StructField("roas_exposed", T.DoubleType(), True),
        T.StructField("iroas_exposed", T.DoubleType(), True),
        T.StructField("overlapping_campaign_flag", T.BooleanType(), True),
        T.StructField("modelling_weight", T.DoubleType(), True),
        T.StructField("num_user_journeys", T.LongType(), True),
        T.StructField("num_conversions", T.LongType(), True),
        T.StructField("product_type", T.StringType(), True),
    ])

    rows = [
        Row(
            unique_brand_name="Brand1",
            channel_name="Meta",
            campaign_id="cmp_001",
            booking_id="booking_001",
            campaign_duration="During",
            journey_type="Direct",
            marketing_type="OFFSITE",
            subchannel_name="Social",
            marketing_hierarchy_cd="mh_001",
            sub_category_name="Sub Cat",
            attributed_conversions=5.0,
            incremental_sales_amt_exposed=100.0,
            super_category_name="Super Cat",
            campaign_name="Campaign 1",
            attributed_recalibrated_sales_amt=500.0,
            attributed_recalibrated_units_qty=50.0,
            incremental_units_qty_exposed=10.0,
            attributed_units_qty=40.0,
            attributed_sales_amt=450.0,
            conversions=5.0,
            conversions_recalibrated=4.5,
            recalibration_factor=1.2,
            job_bag_number="JB001",
            media_spend_amt=200.0,
            campaign_type="Single Channel",
            roas_exposed=2.5,
            iroas_exposed=0.5,
            overlapping_campaign_flag=False,
            modelling_weight=1.0,
            num_user_journeys=100,
            num_conversions=5,
            product_type="BRAND",
        ),
        Row(
            unique_brand_name="Brand1",
            channel_name="OutOfScope",
            campaign_id="cmp_002",
            booking_id="booking_001",
            campaign_duration="During",
            journey_type="Direct",
            marketing_type="OFFSITE",
            subchannel_name="Display",
            marketing_hierarchy_cd="mh_002",
            sub_category_name="Sub Cat 2",
            attributed_conversions=2.0,
            incremental_sales_amt_exposed=50.0,
            super_category_name="Super Cat",
            campaign_name="Campaign 2",
            attributed_recalibrated_sales_amt=250.0,
            attributed_recalibrated_units_qty=25.0,
            incremental_units_qty_exposed=5.0,
            attributed_units_qty=20.0,
            attributed_sales_amt=220.0,
            conversions=2.0,
            conversions_recalibrated=2.0,
            recalibration_factor=1.0,
            job_bag_number="JB002",
            media_spend_amt=100.0,
            campaign_type="Single Channel",
            roas_exposed=2.2,
            iroas_exposed=0.5,
            overlapping_campaign_flag=False,
            modelling_weight=0.5,
            num_user_journeys=50,
            num_conversions=2,
            product_type="BRAND",
        ),
    ]

    return spark_session.createDataFrame(rows, schema)


@pytest.fixture
def integration_paths(tmp_path):
    return {
        "campaign_execution": str(tmp_path / "campaign_execution"),
        "unified_campaign": str(tmp_path / "unified_campaign"),
        "incremental_shrinkage": str(tmp_path / "incremental_shrinkage"),
        "slas_brand": str(tmp_path / "slas_brand"),
        "slas_offer": str(tmp_path / "slas_offer"),
        "pre_mta_brand": str(tmp_path / "pre_mta_brand"),
        "pre_mta_offer": str(tmp_path / "pre_mta_offer"),
        "base_price": str(tmp_path / "base_price"),
        "published_campaign_reporting": str(tmp_path / "published_campaign_reporting"),
        "reach_engagement": str(tmp_path / "reach_engagement"),
        "channel_hierarchy": str(tmp_path / "channel_hierarchy"),
        "output": str(tmp_path / "output"),
    }


def _write_minimum_parquet_inputs(spark_session, integration_paths):
    spark_session.createDataFrame(
        [
            Row(
                unique_brand_name="brand",
                super_category_name="Super Cat",
                sub_category_name="Sub Cat",
                metric_name="calibrated_incrementality",
                metric_value=100.0,
            )
        ],
        "unique_brand_name string, super_category_name string, sub_category_name string, metric_name string, metric_value double",
    ).write.mode("overwrite").parquet(integration_paths["incremental_shrinkage"])

    spark_session.createDataFrame(
        [
            Row(
                booking_id="bk_001",
                campaign_id="cmp_001",
                channel_name="meta",
                subchannel_name="social",
                campaign_start_dt=datetime(2025, 1, 1),
                campaign_end_dt=datetime(2025, 1, 31),
                overlapping_campaign_flag=False,
            ),
        ],
        "booking_id string, campaign_id string, channel_name string, subchannel_name string, campaign_start_dt timestamp, campaign_end_dt timestamp, overlapping_campaign_flag boolean",
    ).write.mode("overwrite").parquet(integration_paths["campaign_execution"])

    spark_session.createDataFrame(
        [
            Row(
                campaign_id="cmp_001",
                campaign_name="Campaign one",
                channel_name="meta",
                subchannel_name="social",
                marketing_hierarchy_cd="mh_001",
                booking_id="bk_001",
                job_bag_number="jb_001",
                media_spend_amt=100.0,
                super_category_name="Super Cat",
                sub_category_name="Sub Cat",
                is_multi_channel=False,
            )
        ],
        "campaign_id string, campaign_name string, channel_name string, subchannel_name string, marketing_hierarchy_cd string, booking_id string, job_bag_number string , media_spend_amt double, super_category_name string, sub_category_name string, is_multi_channel boolean",
    ).write.mode("overwrite").parquet(integration_paths["unified_campaign"])

    spark_session.createDataFrame(
        [
            (
                "Direct",
                "uj_001",
                "booking_001",
                "OFFSITE",
                "meta",
                "social",
                "cmp_001",
                "During",
                1.2,
                10.0,
                8.0,
                100.0,
                80.0,
                1,
                0.8,
            )
        ],
        "journey_type string, userjourney_id string, booking_id string, marketing_type string, channel_name string, subchannel_name string, campaign_id string, campaign_duration string, recalibration_factor double, attributed_recalibrated_units_qty double, attributed_units_qty double, attributed_recalibrated_sales_amt double, attributed_sales_amt double, isconversion int, normalized_weights double",
    ).write.mode("overwrite").parquet(integration_paths["slas_brand"])

    spark_session.createDataFrame(
        [
            (
                "Direct",
                "uj_001",
                "booking_001",
                "OFFSITE",
                "meta",
                "social",
                "cmp_001",
                "During",
                1.2,
                10.0,
                8.0,
                100.0,
                80.0,
                1,
                0.8,
            )
        ],
        "journey_type string, userjourney_id string, booking_id string, marketing_type string, channel_name string, subchannel_name string, campaign_id string, campaign_duration string, recalibration_factor double, attributed_recalibrated_units_qty double, attributed_units_qty double, attributed_recalibrated_sales_amt double, attributed_sales_amt double, isconversion int, normalized_weights double",
    ).write.mode("overwrite").parquet(integration_paths["slas_offer"])

    spark_session.createDataFrame(
        [
            (
                "Direct",
                "uj_001",
                "loy_001",
                "booking_001",
                "OFFSITE",
                "meta",
                "social",
                "cmp_001",
                "During",
                "transaction",
                "txn_001",
                1,
            )
        ],
        "journey_type string, userjourney_id string, loyalty_id string, booking_id string, marketing_type string, channel_name string, subchannel_name string, campaign_id string, campaign_duration string, event_name string, transaction_key string, isconversion int",
    ).write.mode("overwrite").parquet(integration_paths["pre_mta_brand"])

    spark_session.createDataFrame(
        [
            (
                "Direct",
                "uj_001",
                "loy_001",
                "booking_001",
                "OFFSITE",
                "meta",
                "social",
                "cmp_001",
                "During",
                "transaction",
                "txn_001",
                1,
            )
        ],
        "journey_type string, userjourney_id string, loyalty_id string, booking_id string, marketing_type string, channel_name string, subchannel_name string, campaign_id string, campaign_duration string, event_name string, transaction_key string, isconversion int",
    ).write.mode("overwrite").parquet(integration_paths["pre_mta_offer"])

    spark_session.createDataFrame(
        [Row(week_start_dt=datetime(2025, 1, 1), metric_name="BASE_PRICE", metric_value=10.0)],
        "week_start_dt timestamp, metric_name string, metric_value double",
    ).write.mode("overwrite").parquet(integration_paths["base_price"])

    spark_session.createDataFrame(
        [Row(booking_id="booking_001", channel_name="meta", subchannel_name="social", reach_cnt=100)],
        "booking_id string, channel_name string, subchannel_name string, reach_cnt long",
    ).write.mode("overwrite").parquet(integration_paths["reach_engagement"])

    spark_session.createDataFrame(
        [Row(marketing_channel="meta")],
        "marketing_channel string",
    ).write.mode("overwrite").parquet(integration_paths["channel_hierarchy"])

    spark_session.createDataFrame(
        [
            Row(job_bag_number="booking_001",
                correlation_id="corr_001",
                marketing_type="OFFSITE",
                campaign_duration="During",
                product_type="Brand",
                campaign_end_dt='2025-01-01',
                incremental_sales_amt_exposed=5.0,
                attributed_recalibrated_sales_amt=10.0)],
        "job_bag_number string, correlation_id string, marketing_type string, campaign_duration string, product_type string, campaign_end_dt string, incremental_sales_amt_exposed double, attributed_recalibrated_sales_amt double",
    ).write.mode("overwrite").parquet(integration_paths["published_campaign_reporting"])


class TestBrandIdAdditions:
    """Tests for the brand_id addition and multi-brand validation logic in add_brand_id_to_integration_output."""
    def test_load_campaign_brand_id_mapping_filters_nulls_and_aggregates(self, spark_session, tmp_path):
        mapping_path = str(tmp_path / "campaign_booking_media_channel")
        spark_session.createDataFrame(
            [
                Row(booking_id="bk_001", brand_id="101"),
                Row(booking_id="bk_001", brand_id="101"),
                Row(booking_id="bk_002", brand_id="201"),
                Row(booking_id="bk_002", brand_id="202"),
                Row(booking_id=None, brand_id="999"),
                Row(booking_id="bk_003", brand_id=None),
            ],
            "booking_id string, brand_id string",
        ).write.mode("overwrite").parquet(mapping_path)

        result = load_campaign_brand_id_mapping(spark_session, mapping_path)
        by_booking = {row["booking_id"]: row.asDict() for row in result.collect()}

        assert set(by_booking.keys()) == {"bk_001", "bk_002"}
        assert by_booking["bk_001"]["brand_id"] == "101"
        assert by_booking["bk_001"]["brand_count"] == 1
        assert by_booking["bk_001"]["brand_id_list"] == ["101"]
        assert by_booking["bk_002"]["brand_id"] is None
        assert by_booking["bk_002"]["brand_count"] == 2
        assert by_booking["bk_002"]["brand_id_list"] == ["201", "202"]

    def test_get_brand_id_column_backfills_when_missing(self, spark_session):
        previous_reporting = spark_session.createDataFrame(
            [Row(campaign_id="cmp_001")],
            "campaign_id string",
        )

        result = previous_reporting.select(get_brand_id_column(previous_reporting)).collect()

        assert len(result) == 1
        assert result[0]["brand_id"] is None

    def test_get_brand_id_column_uses_existing_brand_id_when_present(self, spark_session):
        previous_reporting = spark_session.createDataFrame(
            [Row(campaign_id="cmp_001", brand_id="brand_101")],
            "campaign_id string, brand_id string",
        )

        result = previous_reporting.select(get_brand_id_column(previous_reporting)).collect()

        assert len(result) == 1
        assert result[0]["brand_id"] == "brand_101"

    def test_get_brand_id_column_uses_uppercase_brand_id_when_present(self, spark_session):
        previous_reporting = spark_session.createDataFrame(
            [Row(CAMPAIGN_ID="cmp_001", BRAND_ID="brand_101")],
            "CAMPAIGN_ID string, BRAND_ID string",
        )

        result = previous_reporting.select(get_brand_id_column(previous_reporting)).collect()

        assert len(result) == 1
        assert result[0]["brand_id"] == "brand_101"

    def test_add_brand_id_to_integration_output_sets_null_when_path_missing(self, spark_session):
        integration_output_uplift = spark_session.createDataFrame(
            [Row(booking_id="bk_001", campaign_id="cmp_001")],
            "booking_id string, campaign_id string",
        )

        result = add_brand_id_to_integration_output(
            integration_output_uplift=integration_output_uplift,
            spark=spark_session,
            campaign_booking_media_channel_path=None,
        )

        rows = result.collect()
        assert len(rows) == 1
        assert rows[0]["brand_id"] is None

    @patch("spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.logger")
    def test_add_brand_id_to_integration_output_logs_multi_brand_validation(self, mock_logger, spark_session, tmp_path):
        mapping_path = str(tmp_path / "campaign_booking_media_channel")
        spark_session.createDataFrame(
            [
                Row(booking_id="bk_001", brand_id="101"),
                Row(booking_id="bk_001", brand_id="102"),
                Row(booking_id="bk_002", brand_id="201"),
            ],
            "booking_id string, brand_id string",
        ).write.mode("overwrite").parquet(mapping_path)

        integration_output_uplift = spark_session.createDataFrame(
            [
                Row(
                    unique_brand_name="Brand A",
                    channel_name="meta",
                    campaign_id="cmp_001",
                    booking_id="bk_001",
                    campaign_duration="During",
                    journey_type="Direct",
                    marketing_type="OFFSITE",
                    subchannel_name="social",
                    marketing_hierarchy_cd="mh_001",
                    sub_category_name="Sub Cat",
                    attributed_conversions=1.0,
                    incremental_sales_amt_exposed=10.0,
                    super_category_name="Super Cat",
                    campaign_name="Campaign 1",
                    attributed_recalibrated_sales_amt=50.0,
                    attributed_recalibrated_units_qty=5.0,
                    incremental_units_qty_exposed=1.0,
                    attributed_units_qty=4.0,
                    attributed_sales_amt=40.0,
                    conversions_recalibrated=1.0,
                    recalibration_factor=1.0,
                    job_bag_number="jb_001",
                    nectar_sales_amt=0.0,
                    non_nectar_sales_amt=0.0,
                    media_spend_amt=20.0,
                    campaign_type="Single Channel",
                    roas_exposed=2.0,
                    iroas_exposed=0.5,
                    base_sales_amt_exposed=40.0,
                    uplift_exposed_sales_amt=0.25,
                    uplift_exposed_units_qty=0.25,
                    num_user_journeys=10,
                    num_conversions=1,
                    attributed_recalibrated_sales_amt_per_uj=5.0,
                    attributed_recalibrated_sales_amt_per_conversion=50.0,
                    conversion_per_uj=0.1,
                    conversion_rate=1.0,
                    load_ts=datetime(2026, 1, 1),
                    run_type="DTP",
                    dag_run_ts=datetime(2026, 1, 1),
                    overlapping_campaign_flag=False,
                    modelling_weight=1.0,
                ),
                Row(
                    unique_brand_name="Brand B",
                    channel_name="meta",
                    campaign_id="cmp_002",
                    booking_id="bk_002",
                    campaign_duration="During",
                    journey_type="Direct",
                    marketing_type="OFFSITE",
                    subchannel_name="social",
                    marketing_hierarchy_cd="mh_002",
                    sub_category_name="Sub Cat",
                    attributed_conversions=1.0,
                    incremental_sales_amt_exposed=15.0,
                    super_category_name="Super Cat",
                    campaign_name="Campaign 2",
                    attributed_recalibrated_sales_amt=60.0,
                    attributed_recalibrated_units_qty=6.0,
                    incremental_units_qty_exposed=1.5,
                    attributed_units_qty=5.0,
                    attributed_sales_amt=45.0,
                    conversions_recalibrated=1.0,
                    recalibration_factor=1.0,
                    job_bag_number="jb_002",
                    nectar_sales_amt=0.0,
                    non_nectar_sales_amt=0.0,
                    media_spend_amt=30.0,
                    campaign_type="Single Channel",
                    roas_exposed=2.0,
                    iroas_exposed=0.5,
                    base_sales_amt_exposed=45.0,
                    uplift_exposed_sales_amt=0.33,
                    uplift_exposed_units_qty=0.30,
                    num_user_journeys=12,
                    num_conversions=1,
                    attributed_recalibrated_sales_amt_per_uj=5.0,
                    attributed_recalibrated_sales_amt_per_conversion=60.0,
                    conversion_per_uj=0.08,
                    conversion_rate=0.8,
                    load_ts=datetime(2026, 1, 1),
                    run_type="DTP",
                    dag_run_ts=datetime(2026, 1, 1),
                    overlapping_campaign_flag=False,
                    modelling_weight=1.0,
                ),
            ],
        )

        result = add_brand_id_to_integration_output(
            integration_output_uplift=integration_output_uplift,
            spark=spark_session,
            campaign_booking_media_channel_path=mapping_path,
        )

        by_booking = {row["booking_id"]: row["brand_id"] for row in result.select("booking_id", "brand_id").collect()}
        assert by_booking["bk_001"] is None
        assert by_booking["bk_002"] == "201"
        mock_logger.info.assert_called_with(
            "Multi-brand booking_id count in campaign booking mapping: %s",
            1,
        )


def test_combine_baseline_mta_invalid_product_type_raises():
    with pytest.raises(Exception, match="please pass `offer` or `brand`"):
        combine_baseline_mta(
            pre_mta_brand=None,
            pre_mta_offer=None,
            slaso=None,
            slasb=None,
            cme=None,
            bp=None,
            uc=None,
            ic=None,
            product_type="invalid",
            run_type="Pollen",
        )


def test_load_spend_weights_normalises_and_deduplicates(spark_session, tmp_path):
    weights_path = str(tmp_path / "overlapping_campaign_spend_weights")
    spark_session.createDataFrame(
        [
            Row(
                booking_id=123,
                product_type=" brand ",
                campaign_duration="during",
                spend_weight="0.625",
            ),
            Row(
                booking_id=123,
                product_type=" brand ",
                campaign_duration="during",
                spend_weight="0.625",
            ),
            Row(
                booking_id=456,
                product_type=" offer ",
                campaign_duration=" POST ",
                spend_weight="1.0",
            ),
        ],
        "booking_id int, product_type string, campaign_duration string, spend_weight string",
    ).write.mode("overwrite").parquet(weights_path)

    result = load_spend_weights(spark_session, weights_path)

    rows = [row.asDict() for row in result.orderBy("booking_id").collect()]

    assert rows == [
        {
            "booking_id": "123",
            "product_type": "BRAND",
            "weight_period": "During",
            "spend_weight": 0.625,
        },
        {
            "booking_id": "456",
            "product_type": "OFFER",
            "weight_period": "Post",
            "spend_weight": 1.0,
        },
    ]


def test_entrypoint_calls_prepare_baseline_mta_integration(spark_session):
    with patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.prepare_baseline_mta_integration"
    ) as mock_prepare:
        args = [
            "--campaign-execution-path", "s3a://input/campaign_execution",
            "--incremental-shrinkage-path", "s3a://input/incremental_shrinkage",
            "--campaign-booking-media-channel-path",
            "s3a://input/campaign_booking_media_channel",
            "--overlapping-campaign-spend-weights-path",
            "s3a://input/spend_weights",
            "--unified-campaign-path", "s3a://input/unified_campaign",
            "--sku-level-attributed-sales-units-brand-path", "s3a://input/slas_brand",
            "--sku-level-attributed-sales-units-offer-path", "s3a://input/slas_offer",
            "--pre-mta-brand-path", "s3a://input/pre_mta_brand",
            "--pre-mta-offer-path", "s3a://input/pre_mta_offer",
            "--base-price-path", "s3a://input/base_price",
            "--reach-engagement-path", "s3a://input/reach_engagement",
            "--measurement-marketing-channel-hierarchy-path", "s3a://input/channel_hierarchy",
            "--published-campaign-reporting-path", "s3a://input/published_campaign_reporting",
            "--measurement-legacy-campaign-performance", "s3a://input/legacy_mcr",
            "--brand-data-path", "s3a://input/brand_data",
            "--output-path", "s3a://output/measurement_campaign_reporting",
            "--run-date", "2026-03-06",
            "--correlation-id", "corr-123",
            "--slack-topic-arn", "arn:aws:sns:eu-west-1:123456789012:slack-topic",
            "--campaign-period", "Post",
            "--previous-measurement-campaign-reporting", "s3a://input/previous_mcr",
            "--measurement-campaign-reporting-audit-path",
            "s3a://output/mcr_audit",
            "--fallback-metadata-path",
            "s3a://output/fallback_metadata",
            "--post-audit-path",
            "s3a://output/post_audit",
        ]

        entrypoint(spark_session, command_line_args=args)

        mock_prepare.assert_called_once_with(
            spark=spark_session,
            incremental_shrinkage_path="s3a://input/incremental_shrinkage",
            campaign_execution_path="s3a://input/campaign_execution",
            campaign_booking_media_channel_path=(
                "s3a://input/campaign_booking_media_channel"
            ),
            overlapping_campaign_spend_weights_path=(
                "s3a://input/spend_weights"
            ),
            unified_campaign_path="s3a://input/unified_campaign",
            sku_level_attributed_sales_units_brand_path="s3a://input/slas_brand",
            sku_level_attributed_sales_units_offer_path="s3a://input/slas_offer",
            pre_mta_brand_path="s3a://input/pre_mta_brand",
            pre_mta_offer_path="s3a://input/pre_mta_offer",
            base_price_path="s3a://input/base_price",
            reach_engagement_path="s3a://input/reach_engagement",
            measurement_marketing_channel_hierarchy_path="s3a://input/channel_hierarchy",
            published_campaign_reporting_path="s3a://input/published_campaign_reporting",
            measurement_legacy_campaign_performance="s3a://input/legacy_mcr",
            brand_data_path="s3a://input/brand_data",
            output_path="s3a://output/measurement_campaign_reporting",
            run_date="2026-03-06",
            correlation_id="corr-123",
            slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
            campaign_period="Post",
            previous_measurement_campaign_reporting="s3a://input/previous_mcr",
            measurement_campaign_reporting_audit_path="s3a://output/mcr_audit",
            fallback_metadata_path="s3a://output/fallback_metadata",
            post_audit_path="s3a://output/post_audit",
        )


def _spend_weight_input(spark_session):
    return spark_session.createDataFrame(
        [
            Row(
                booking_id="book_001",
                product_type="BRAND",
                attributed_recalibrated_sales_amt=1000.0,
                incremental_sales_amt_exposed=200.0,
                attributed_units_qty=40.0,
                conversions=10.0,
                conversions_recalibrated=8.0,
                num_conversions=20.0,
                num_user_journeys=500.0,
                media_spend_amt=400.0,
                roas_exposed=2.5,
                iroas_exposed=0.5,
            ),
            Row(
                booking_id="book_001",
                product_type="OFFER",
                attributed_recalibrated_sales_amt=1000.0,
                incremental_sales_amt_exposed=200.0,
                attributed_units_qty=40.0,
                conversions=10.0,
                conversions_recalibrated=8.0,
                num_conversions=20.0,
                num_user_journeys=500.0,
                media_spend_amt=400.0,
                roas_exposed=2.5,
                iroas_exposed=0.5,
            ),
            Row(
                booking_id="book_no_overlap",
                product_type="BRAND",
                attributed_recalibrated_sales_amt=1000.0,
                incremental_sales_amt_exposed=200.0,
                attributed_units_qty=40.0,
                conversions=10.0,
                conversions_recalibrated=8.0,
                num_conversions=20.0,
                num_user_journeys=500.0,
                media_spend_amt=400.0,
                roas_exposed=2.5,
                iroas_exposed=0.5,
            ),
        ]
    )


def test_apply_spend_weights_scales_volume_metrics_per_product_type(spark_session):
    """Brand and offer rows take their own weight; spend and journeys stay unscaled."""
    weights = spark_session.createDataFrame(
        [
            Row(booking_id="book_001", product_type="BRAND", weight_period="During", spend_weight=0.5),
            Row(booking_id="book_001", product_type="OFFER", weight_period="During", spend_weight=0.25),
            Row(booking_id="book_001", product_type="BRAND", weight_period="Post", spend_weight=0.9),
        ]
    )

    result = {
        (row.booking_id, row.product_type): row
        for row in apply_spend_weights(_spend_weight_input(spark_session), weights, "During").collect()
    }

    brand = result[("book_001", "BRAND")]
    assert brand.spend_weight == 0.5
    assert brand.attributed_recalibrated_sales_amt == 500.0
    assert brand.incremental_sales_amt_exposed == 100.0
    assert brand.attributed_units_qty == 20.0
    assert brand.conversions == 5.0
    assert brand.conversions_recalibrated == 4.0
    assert brand.num_conversions == 10.0
    # Media spend and user journeys are deliberately left at full value.
    assert brand.media_spend_amt == 400.0
    assert brand.num_user_journeys == 500.0

    offer = result[("book_001", "OFFER")]
    assert offer.attributed_recalibrated_sales_amt == 250.0
    # 20 * 0.25 = 5.0 exactly; the fractional case is pinned below.
    assert offer.num_conversions == 5.0


def test_apply_spend_weights_rounds_conversions_to_whole_numbers(spark_session):
    weights = spark_session.createDataFrame(
        [Row(booking_id="book_001", product_type="BRAND", weight_period="During", spend_weight=0.31)]
    )

    brand = [
        row for row in apply_spend_weights(_spend_weight_input(spark_session), weights, "During").collect()
        if (row.booking_id, row.product_type) == ("book_001", "BRAND")
    ][0]

    # 20 * 0.31 = 6.2, reported as a whole conversion.
    assert brand.num_conversions == 6.0
    # Other scaled metrics keep their precision.
    assert brand.conversions_recalibrated == pytest.approx(2.48)


def test_apply_spend_weights_leaves_bookings_without_weights_unscaled(spark_session):
    weights = spark_session.createDataFrame(
        [Row(booking_id="book_001", product_type="BRAND", weight_period="During", spend_weight=0.5)]
    )

    result = {
        (row.booking_id, row.product_type): row
        for row in apply_spend_weights(_spend_weight_input(spark_session), weights, "During").collect()
    }

    unmatched = result[("book_no_overlap", "BRAND")]
    assert unmatched.spend_weight == 1.0
    assert unmatched.attributed_recalibrated_sales_amt == 1000.0
    assert unmatched.num_conversions == 20.0


def test_prepare_baseline_mta_integration_calls_combine_and_writes_filtered_output(
    spark_session,
    integration_paths,
):
    _write_minimum_parquet_inputs(spark_session, integration_paths)

    combine_output_df = _create_combine_output_df(spark_session)

    with patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.combine_baseline_mta",
        side_effect=[combine_output_df, combine_output_df],
    ) as mock_combine, patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.spark_s3_overwrite"
    ) as mock_write:
        prepare_baseline_mta_integration(
            spark=spark_session,
            incremental_shrinkage_path=integration_paths["incremental_shrinkage"],
            campaign_execution_path=integration_paths["campaign_execution"],
            unified_campaign_path=integration_paths["unified_campaign"],
            sku_level_attributed_sales_units_brand_path=integration_paths["slas_brand"],
            sku_level_attributed_sales_units_offer_path=integration_paths["slas_offer"],
            pre_mta_brand_path=integration_paths["pre_mta_brand"],
            pre_mta_offer_path=integration_paths["pre_mta_offer"],
            base_price_path=integration_paths["base_price"],
            reach_engagement_path=integration_paths["reach_engagement"],
            measurement_marketing_channel_hierarchy_path=integration_paths["channel_hierarchy"],
            published_campaign_reporting_path=integration_paths["published_campaign_reporting"],
            output_path=integration_paths["output"],
            run_date="2026-03-06",
            correlation_id="corr-456",
            slack_topic_arn="arn:topic",
        )

        assert mock_combine.call_count == 2
        assert mock_combine.call_args_list[0].args[8] == "offer"
        assert mock_combine.call_args_list[0].args[9] == "DTP"
        assert mock_combine.call_args_list[1].args[8] == "brand"
        assert mock_combine.call_args_list[1].args[9] == "DTP"

        mock_write.assert_called_once()
        written_path, written_df = mock_write.call_args.args
        assert written_path == integration_paths["output"]

        # With no weights configured, rows are reported at full value rather than an unknown weight.
        assert {row["spend_weight"] for row in written_df.select("spend_weight").collect()} == {1.0}

        rows = written_df.select("channel_name", "run_type", "correlation_id").collect()

        # The codebase historically only filters channel names for Pollen runs.
        # For DTP runs no marketing-channel filtering is applied and original casing is preserved.
        run_type_used = mock_combine.call_args_list[0].args[9]
        # TODO: For pollen runs we need a separate mock data and reflect in "assert rows[0]["run_type"]"
        if run_type_used == "Pollen":
            assert len(rows) == 1
            assert rows[0]["channel_name"] == "meta"
            assert rows[0]["run_type"] == "DTP"
            assert rows[0]["correlation_id"] == "corr-456"
        else:
            # DTP: expect both rows from combine output (no channel filtering)
            names = sorted([r["channel_name"] for r in rows])
            assert "Meta" in names
            assert "OutOfScope" in names


def test_prepare_baseline_mta_integration_post_requires_previous_reporting(
    spark_session,
    integration_paths,
):
    _write_minimum_parquet_inputs(spark_session, integration_paths)

    with pytest.raises(
        ValueError,
        match="previous_measurement_campaign_reporting is required when campaign_period is 'Post'",
    ):
        prepare_baseline_mta_integration(
            spark=spark_session,
            incremental_shrinkage_path=integration_paths["incremental_shrinkage"],
            campaign_execution_path=integration_paths["campaign_execution"],
            unified_campaign_path=integration_paths["unified_campaign"],
            sku_level_attributed_sales_units_brand_path=integration_paths["slas_brand"],
            sku_level_attributed_sales_units_offer_path=integration_paths["slas_offer"],
            pre_mta_brand_path=integration_paths["pre_mta_brand"],
            pre_mta_offer_path=integration_paths["pre_mta_offer"],
            base_price_path=integration_paths["base_price"],
            reach_engagement_path=integration_paths["reach_engagement"],
            measurement_marketing_channel_hierarchy_path=integration_paths["channel_hierarchy"],
            published_campaign_reporting_path=integration_paths["published_campaign_reporting"],
            output_path=integration_paths["output"],
            run_date="2026-03-06",
            correlation_id="corr-post-guard",
            campaign_period="Post",
            previous_measurement_campaign_reporting=None,
            slack_topic_arn="arn:topic",
        )


def test_prepare_baseline_mta_integration_post_flow_keeps_post_brand_id(
    spark_session,
    integration_paths,
    tmp_path,
):
    _write_minimum_parquet_inputs(spark_session, integration_paths)
    previous_reporting_path = str(tmp_path / "previous_measurement_campaign_reporting")

    previous_reporting_df = spark_session.createDataFrame(
        [
            {
                "correlation_id": "corr-during",
                "brand_id": "brand_during",
                "campaign_id": "cmp_001",
                "booking_id": "booking_001",
                "campaign_duration": "during",
                "journey_type": "Direct",
                "marketing_type": "OFFSITE",
                "channel_name": "meta",
                "subchannel_name": "social",
                "sub_category_name": "Sub Cat",
                "attributed_conversions": 5.0,
                "incremental_sales_amt_exposed": 100.0,
                "super_category_name": "Super Cat",
                "campaign_name": "Campaign 1",
                "attributed_recalibrated_sales_amt": 500.0,
                "attributed_recalibrated_units_qty": 50.0,
                "incremental_units_qty_exposed": 10.0,
                "attributed_units_qty": 40.0,
                "attributed_sales_amt": 450.0,
                "conversions_recalibrated": 4.5,
                "recalibration_factor": 1.2,
                "job_bag_number": "JB001",
                "nectar_sales_amt": 0.0,
                "non_nectar_sales_amt": 0.0,
                "media_spend_amt": 200.0,
                "campaign_type": "Single Channel",
                "roas_exposed": 2.5,
                "iroas_exposed": 0.5,
                "base_sales_amt_exposed": 400.0,
                "uplift_exposed_sales_amt": 0.25,
                "uplift_exposed_units_qty": 0.25,
                "num_user_journeys": 100.0,
                "num_conversions": 5.0,
                "attributed_recalibrated_sales_amt_per_uj": 5.0,
                "attributed_recalibrated_sales_amt_per_conversion": 100.0,
                "conversion_per_uj": 0.05,
                "conversion_rate": 0.05,
                "load_ts": datetime(2026, 3, 5),
                "modelling_weight": 1.0,
                "marketing_hierarchy_cd": "mh_001",
                "run_type": "Pollen",
                "dag_run_ts": datetime(2026, 3, 5),
                "overlapping_campaign_flag": False,
            },
        ],
        schema=MeasurementCampaignReportingPollen().measures_schema,
    )
    (
        previous_reporting_df
        .toDF(*[column_name.upper() for column_name in previous_reporting_df.columns])
        .write.mode("overwrite").parquet(previous_reporting_path)
    )

    combine_output_df = _create_combine_output_df(spark_session)
    mocked_post_df = spark_session.createDataFrame(
        [
            Row(
                campaign_duration="Post",
                booking_id="booking_001",
                campaign_id="cmp_001",
                channel_name="meta",
                subchannel_name="social",
                journey_type="Direct",
                marketing_type="OFFSITE",
                brand_id="brand_during",
                correlation_id="corr-post",
            )
        ],
        "campaign_duration string, booking_id string, campaign_id string, channel_name string, subchannel_name string, journey_type string, marketing_type string, brand_id string, correlation_id string",
    )

    with patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.combine_baseline_mta",
        side_effect=[combine_output_df, combine_output_df],
    ), patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.calculate_post_period_metrics",
        return_value=mocked_post_df,
    ) as mock_post_calc, patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.spark_s3_overwrite"
    ) as mock_write:
        prepare_baseline_mta_integration(
            spark=spark_session,
            incremental_shrinkage_path=integration_paths["incremental_shrinkage"],
            campaign_execution_path=integration_paths["campaign_execution"],
            unified_campaign_path=integration_paths["unified_campaign"],
            sku_level_attributed_sales_units_brand_path=integration_paths["slas_brand"],
            sku_level_attributed_sales_units_offer_path=integration_paths["slas_offer"],
            pre_mta_brand_path=integration_paths["pre_mta_brand"],
            pre_mta_offer_path=integration_paths["pre_mta_offer"],
            base_price_path=integration_paths["base_price"],
            reach_engagement_path=integration_paths["reach_engagement"],
            measurement_marketing_channel_hierarchy_path=integration_paths["channel_hierarchy"],
            published_campaign_reporting_path=integration_paths["published_campaign_reporting"],
            output_path=integration_paths["output"],
            run_date="2026-03-06",
            correlation_id="corr-post",
            campaign_period="Post",
            previous_measurement_campaign_reporting=previous_reporting_path,
            slack_topic_arn="arn:topic",
        )

        mock_post_calc.assert_called_once()
        _, written_df = mock_write.call_args.args
        during_plus_post_rows = (
            written_df
            .where("campaign_duration = 'During+Post'")
            .select("brand_id")
            .collect()
        )
        post_rows = (
            written_df
            .where("campaign_duration = 'Post'")
            .select("correlation_id", "brand_id")
            .collect()
        )
        assert len(during_plus_post_rows) > 0
        assert all(row["brand_id"] == "brand_during" for row in during_plus_post_rows)
        assert len(post_rows) == 1
        assert post_rows[0]["correlation_id"] == "corr-post"
        assert post_rows[0]["brand_id"] == "brand_during"

        # No weights configured, so every period is reported at full value, not an unknown weight.
        assert {row["spend_weight"] for row in written_df.select("spend_weight").collect()} == {1.0}


def test_prepare_baseline_mta_integration_post_prefers_non_null_previous_brand(
    spark_session,
    integration_paths,
    tmp_path,
):
    _write_minimum_parquet_inputs(spark_session, integration_paths)
    previous_reporting_path = str(tmp_path / "previous_measurement_campaign_reporting_non_null")

    spark_session.createDataFrame(
        [
            {
                "correlation_id": "corr-during",
                "brand_id": None,
                "campaign_id": "cmp_001",
                "booking_id": "booking_001",
                "campaign_duration": "during",
                "journey_type": "Direct",
                "marketing_type": "OFFSITE",
                "channel_name": "meta",
                "subchannel_name": "social",
                "sub_category_name": "Sub Cat",
                "attributed_conversions": 5.0,
                "incremental_sales_amt_exposed": 100.0,
                "super_category_name": "Super Cat",
                "campaign_name": "Campaign 1",
                "attributed_recalibrated_sales_amt": 500.0,
                "attributed_recalibrated_units_qty": 50.0,
                "incremental_units_qty_exposed": 10.0,
                "attributed_units_qty": 40.0,
                "attributed_sales_amt": 450.0,
                "conversions_recalibrated": 4.5,
                "recalibration_factor": 1.2,
                "job_bag_number": "JB001",
                "nectar_sales_amt": 0.0,
                "non_nectar_sales_amt": 0.0,
                "media_spend_amt": 200.0,
                "campaign_type": "Single Channel",
                "roas_exposed": 2.5,
                "iroas_exposed": 0.5,
                "base_sales_amt_exposed": 400.0,
                "uplift_exposed_sales_amt": 0.25,
                "uplift_exposed_units_qty": 0.25,
                "num_user_journeys": 100.0,
                "num_conversions": 5.0,
                "attributed_recalibrated_sales_amt_per_uj": 5.0,
                "attributed_recalibrated_sales_amt_per_conversion": 100.0,
                "conversion_per_uj": 0.05,
                "conversion_rate": 0.05,
                "load_ts": datetime(2026, 3, 5),
                "modelling_weight": 1.0,
                "marketing_hierarchy_cd": "mh_001",
                "run_type": "Pollen",
                "dag_run_ts": datetime(2026, 3, 5),
                "overlapping_campaign_flag": False,
            },
            {
                "correlation_id": "corr-during",
                "brand_id": "brand_during",
                "campaign_id": "cmp_001",
                "booking_id": "booking_001",
                "campaign_duration": "during",
                "journey_type": "Direct",
                "marketing_type": "OFFSITE",
                "channel_name": "meta",
                "subchannel_name": "social",
                "sub_category_name": "Sub Cat",
                "attributed_conversions": 5.0,
                "incremental_sales_amt_exposed": 100.0,
                "super_category_name": "Super Cat",
                "campaign_name": "Campaign 1",
                "attributed_recalibrated_sales_amt": 500.0,
                "attributed_recalibrated_units_qty": 50.0,
                "incremental_units_qty_exposed": 10.0,
                "attributed_units_qty": 40.0,
                "attributed_sales_amt": 450.0,
                "conversions_recalibrated": 4.5,
                "recalibration_factor": 1.2,
                "job_bag_number": "JB001",
                "nectar_sales_amt": 0.0,
                "non_nectar_sales_amt": 0.0,
                "media_spend_amt": 200.0,
                "campaign_type": "Single Channel",
                "roas_exposed": 2.5,
                "iroas_exposed": 0.5,
                "base_sales_amt_exposed": 400.0,
                "uplift_exposed_sales_amt": 0.25,
                "uplift_exposed_units_qty": 0.25,
                "num_user_journeys": 100.0,
                "num_conversions": 5.0,
                "attributed_recalibrated_sales_amt_per_uj": 5.0,
                "attributed_recalibrated_sales_amt_per_conversion": 100.0,
                "conversion_per_uj": 0.05,
                "conversion_rate": 0.05,
                "load_ts": datetime(2026, 3, 5),
                "modelling_weight": 1.0,
                "marketing_hierarchy_cd": "mh_001",
                "run_type": "Pollen",
                "dag_run_ts": datetime(2026, 3, 5),
                "overlapping_campaign_flag": False,
            },
        ],
        schema=MeasurementCampaignReportingPollen().measures_schema,
    ).write.mode("overwrite").parquet(previous_reporting_path)

    combine_output_df = _create_combine_output_df(spark_session)
    mocked_post_df = spark_session.createDataFrame(
        [
            Row(
                campaign_duration="Post",
                booking_id="booking_001",
                campaign_id="cmp_001",
                channel_name="meta",
                subchannel_name="social",
                journey_type="Direct",
                marketing_type="OFFSITE",
                brand_id="brand_post",
                correlation_id="corr-post-flow",
            )
        ],
        "campaign_duration string, booking_id string, campaign_id string, channel_name string, subchannel_name string, journey_type string, marketing_type string, brand_id string, correlation_id string",
    )

    with patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.combine_baseline_mta",
        side_effect=[combine_output_df, combine_output_df],
    ), patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.calculate_post_period_metrics",
        return_value=mocked_post_df,
    ), patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.spark_s3_overwrite"
    ) as mock_write:
        prepare_baseline_mta_integration(
            spark=spark_session,
            incremental_shrinkage_path=integration_paths["incremental_shrinkage"],
            campaign_execution_path=integration_paths["campaign_execution"],
            unified_campaign_path=integration_paths["unified_campaign"],
            sku_level_attributed_sales_units_brand_path=integration_paths["slas_brand"],
            sku_level_attributed_sales_units_offer_path=integration_paths["slas_offer"],
            pre_mta_brand_path=integration_paths["pre_mta_brand"],
            pre_mta_offer_path=integration_paths["pre_mta_offer"],
            base_price_path=integration_paths["base_price"],
            reach_engagement_path=integration_paths["reach_engagement"],
            measurement_marketing_channel_hierarchy_path=integration_paths["channel_hierarchy"],
            published_campaign_reporting_path=integration_paths["published_campaign_reporting"],
            output_path=integration_paths["output"],
            run_date="2026-03-06",
            correlation_id="corr-post-flow",
            campaign_period="Post",
            previous_measurement_campaign_reporting=previous_reporting_path,
            slack_topic_arn="arn:topic",
        )

        _, written_df = mock_write.call_args.args
        during_plus_post_rows = (
            written_df
            .where("campaign_duration = 'During+Post'")
            .select("brand_id")
            .collect()
        )

        assert len(during_plus_post_rows) > 0
        assert all(row["brand_id"] == "brand_during" for row in during_plus_post_rows)


def test_prepare_baseline_mta_integration_uses_pollen_run_type_when_path_contains_pollen(
    spark_session,
    integration_paths,
):
    _write_minimum_parquet_inputs(spark_session, integration_paths)

    pollen_unified_campaign_path = f"{integration_paths['unified_campaign']}_pollen"
    spark_session.read.parquet(integration_paths["unified_campaign"]).write.mode("overwrite").parquet(
        pollen_unified_campaign_path
    )

    combine_output_df = _create_combine_output_df(spark_session)

    with patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.combine_baseline_mta",
        side_effect=[combine_output_df, combine_output_df],
    ) as mock_combine, patch(
        "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting.spark_s3_overwrite"
    ):
        prepare_baseline_mta_integration(
            spark=spark_session,
            incremental_shrinkage_path=integration_paths["incremental_shrinkage"],
            campaign_execution_path=integration_paths["campaign_execution"],
            unified_campaign_path=pollen_unified_campaign_path,
            sku_level_attributed_sales_units_brand_path=integration_paths["slas_brand"],
            sku_level_attributed_sales_units_offer_path=integration_paths["slas_offer"],
            pre_mta_brand_path=integration_paths["pre_mta_brand"],
            pre_mta_offer_path=integration_paths["pre_mta_offer"],
            base_price_path=integration_paths["base_price"],
            reach_engagement_path=integration_paths["reach_engagement"],
            measurement_marketing_channel_hierarchy_path=integration_paths["channel_hierarchy"],
            published_campaign_reporting_path=integration_paths["published_campaign_reporting"],
            output_path=integration_paths["output"],
            run_date="2026-03-06",
            correlation_id="corr-789",
            slack_topic_arn="arn:topic",
        )

        assert mock_combine.call_args_list[0].args[9] == "Pollen"
        assert mock_combine.call_args_list[1].args[9] == "Pollen"


@pytest.fixture
def make_inputs(spark_session):
    """Factory fixture returning baseline combine_baseline_mta test inputs.

    Usage::

        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc = make_inputs()
        pre_mta_brand, ..., uc = make_inputs(run_type="DTP")
    """
    def _factory(run_type="Pollen"):
        return get_base_inputs(spark_session, run_type)
    return _factory


# ─── Tests ────────────────────────────────────────────────────────────────────


class TestCombineBaselineMtaInvalidInputs:
    """Guard-rail tests: wrong argument values must raise before any Spark action."""

    def test_invalid_product_type_raises(self):
        # Arrange / Act / Assert — product_type check fires first; no DataFrames needed
        with pytest.raises(Exception, match="please pass `offer` or `brand`"):
            combine_baseline_mta(
                pre_mta_brand=None, pre_mta_offer=None, slaso=None, slasb=None,
                cme=None, bp=None, uc=None, ic=None,
                product_type="invalid", run_type="Pollen",
            )

    def test_invalid_run_type_raises(self, spark_session):
        """Reject an invalid run type with Spark expressions available."""
        # Arrange
        ic_mock = Mock()
        ic_mock.filter.return_value.limit.return_value.count.return_value = 0
        df_mock = Mock()

        # Act / Assert
        with patch("pyspark.sql.functions.broadcast", side_effect=lambda x: x):
            with pytest.raises(Exception, match="please pass `run_type` as `Pollen` or `DTP`"):
                combine_baseline_mta(
                    df_mock, df_mock, df_mock, df_mock, df_mock,
                    ic_mock, df_mock, df_mock,
                    product_type="brand", run_type="INVALID",
                )


class TestCombineBaselineMtaRunTypeRouting:
    """Validate run_type routing behavior."""

    def test_dtp_sets_marketing_hierarchy_cd_to_null(self, make_inputs, spark_session):
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc = make_inputs(run_type="DTP")
        expected = spark_session.createDataFrame(
            [Row(marketing_hierarchy_cd=None)],
            T.StructType([T.StructField("marketing_hierarchy_cd", T.StringType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc, "brand", "DTP")

        # Assert
        assert_df_equality(
            result.select("marketing_hierarchy_cd"),
            expected,
            ignore_nullable=True,
        )

    def test_pollen_uses_marketing_hierarchy_cd_from_uc(self, make_inputs, spark_session):
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc = make_inputs(run_type="Pollen")
        expected = spark_session.createDataFrame(
            [Row(marketing_hierarchy_cd="mh_001")],
            T.StructType([T.StructField("marketing_hierarchy_cd", T.StringType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc, "brand", "Pollen")

        # Assert
        assert_df_equality(
            result.select("marketing_hierarchy_cd"),
            expected,
            ignore_nullable=True,
        )


class TestCombineBaselineMtaProductTypeRouting:
    """Verify product_type selects the correct SLAS/pre-MTA tables and zeroes offer incrementals."""

    def test_offer_zeros_all_incremental_fields(self, make_inputs, spark_session):
        """For offer campaigns the function replaces all incremental metrics with literal 0."""
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc = make_inputs()
        _incremental_cols = [
            "booking_incremental_sales", "booking_incremental_units", "incremental_pct",
            "incremental_sales_amt_exposed", "incremental_units_qty_exposed",
        ]
        expected = spark_session.createDataFrame(
            [
                Row(
                    booking_incremental_sales=0,
                    booking_incremental_units=0,
                    incremental_pct=0,
                    incremental_sales_amt_exposed=0,
                    incremental_units_qty_exposed=0,
                )
            ],
            T.StructType([T.StructField(c, T.IntegerType()) for c in _incremental_cols]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc, "offer", "Pollen")

        # Assert
        assert_df_equality(result.select(*_incremental_cols), expected, ignore_nullable=True)

    def test_offer_product_type_uses_slaso_not_slasb(self, spark_session):
        """product_type='offer' must source rows from slaso, not slasb.
        Distinct campaign_ids in each table let us confirm only the slaso campaign appears."""
        # === ARRANGE: slaso has cmp_offer, slasb has cmp_brand — only cmp_offer must appear
        pre_mta_offer = spark_session.createDataFrame(
            [Row(journey_type="Direct", userjourney_id="uj_offer", loyalty_id="loy_001",
                 booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                 subchannel_name="social", campaign_id="cmp_offer", campaign_duration="During",
                 event_name="click", transaction_key="t_001", isconversion=1)],
            PRE_MTA_SCHEMA,
        )
        pre_mta_brand = spark_session.createDataFrame(
            [Row(journey_type="Direct", userjourney_id="uj_brand", loyalty_id="loy_002",
                 booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                 subchannel_name="social", campaign_id="cmp_brand", campaign_duration="During",
                 event_name="click", transaction_key="t_002", isconversion=1)],
            PRE_MTA_SCHEMA,
        )
        slaso = spark_session.createDataFrame(
            [
                Row(
                    journey_type="Direct",
                    userjourney_id="uj_offer",
                    booking_id="bk_001",
                    marketing_type="OFFSITE",
                    channel_name="meta",
                    subchannel_name="social",
                    campaign_id="cmp_offer",
                    campaign_duration="During",
                    recalibration_factor=1.0,
                    attributed_recalibrated_units_qty=5.0,
                    attributed_units_qty=4.0,
                    attributed_recalibrated_sales_amt=100.0,
                    attributed_sales_amt=80.0,
                    isconversion=1,
                    normalized_weights=1.0,
                )
            ],
            SLAS_SCHEMA,
        )
        slasb = spark_session.createDataFrame(
            [
                Row(
                    journey_type="Direct",
                    userjourney_id="uj_brand",
                    booking_id="bk_001",
                    marketing_type="OFFSITE",
                    channel_name="meta",
                    subchannel_name="social",
                    campaign_id="cmp_brand",
                    campaign_duration="During",
                    recalibration_factor=1.0,
                    attributed_recalibrated_units_qty=5.0,
                    attributed_units_qty=4.0,
                    attributed_recalibrated_sales_amt=100.0,
                    attributed_sales_amt=80.0,
                    isconversion=1,
                    normalized_weights=1.0,
                )
            ],
            SLAS_SCHEMA,
        )
        # Both campaigns are in CME and UC so cmp_brand would appear in the output
        # if the function incorrectly sourced from slasb instead of slaso.
        cme = spark_session.createDataFrame(
            [
                Row(booking_id="bk_001", campaign_id="cmp_offer", channel_name="meta", subchannel_name="social", campaign_start_dt=datetime(2025, 1, 1), campaign_end_dt=datetime(2025, 1, 31), overlapping_campaign_flag=False),
                Row(booking_id="bk_001", campaign_id="cmp_brand", channel_name="meta", subchannel_name="social", campaign_start_dt=datetime(2025, 1, 1), campaign_end_dt=datetime(2025, 1, 31), overlapping_campaign_flag=False),
            ],
            CME_SCHEMA,
        )
        ic = spark_session.createDataFrame(
            [
                Row(
                    unique_brand_name="Brand A",
                    super_category_name="Super Cat",
                    sub_category_name="Sub Cat",
                    metric_name="adjusted_calibrated_incrementality",
                    metric_value=500.0,
                )
            ],
            IC_SCHEMA,
        )
        bp = spark_session.createDataFrame(
            [Row(week_start_dt=datetime(2025, 1, 6), metric_name="BASE_PRICE", metric_value=10.0)],
            BP_SCHEMA,
        )
        uc = spark_session.createDataFrame(
            [
                Row(booking_id="bk_001", job_bag_number="jb_001", campaign_id="cmp_offer",
                    campaign_name="Offer Campaign", channel_name="meta", subchannel_name="social",
                    media_spend_amt=200.0, super_category_name="Super Cat",
                    sub_category_name="Sub Cat", is_multi_channel=False,
                    marketing_hierarchy_cd="mh_001"),
                Row(booking_id="bk_001", job_bag_number="jb_002", campaign_id="cmp_brand",
                    campaign_name="Brand Campaign", channel_name="meta", subchannel_name="social",
                    media_spend_amt=200.0, super_category_name="Super Cat",
                    sub_category_name="Sub Cat", is_multi_channel=False,
                    marketing_hierarchy_cd="mh_002"),
            ],
            UC_POLLEN_SCHEMA,
        )

        # === ACT
        result = combine_baseline_mta(
            pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc, "offer", "Pollen"
        )

        # === ASSERT — cmp_offer (from slaso/pre_mta_offer) present; cmp_brand (slasb only) absent.
        # cmp_brand is in CME and UC so it would reach the output if slasb were used by mistake.
        campaign_ids = {r["campaign_id"] for r in result.select("campaign_id").distinct().collect()}
        assert "cmp_offer" in campaign_ids
        assert "cmp_brand" not in campaign_ids

    def test_brand_happy_path_validates_key_output_columns(self, make_inputs, spark_session):
        """
        Happy path: single brand campaign with all inputs present.

        Data contract (ic=500 / bp avg=10 / slas attributed=100 / uc spend=200)::

            booking_incremental_units     = 500 / 10 = 50.0
            incremental_sales_amt_exposed = 500      (incremental_pct == 1.0)
        """
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc = make_inputs()
        expected = spark_session.createDataFrame(
            [Row(unique_brand_name="Brand A", campaign_name="Campaign One", booking_incremental_units=50.0,
                 incremental_sales_amt_exposed=500.0, media_spend_amt=200.0)],
            T.StructType([
                T.StructField("unique_brand_name", T.StringType()),
                T.StructField("campaign_name", T.StringType()),
                T.StructField("booking_incremental_units", T.DoubleType()),
                T.StructField("incremental_sales_amt_exposed", T.DoubleType()),
                T.StructField("media_spend_amt", T.DoubleType()),
            ]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc, "brand", "Pollen")

        # Assert
        assert_df_equality(
            result.select("unique_brand_name", "campaign_name", "booking_incremental_units",
                          "incremental_sales_amt_exposed", "media_spend_amt"),
            expected,
            ignore_nullable=True,
        )


class TestCombineBaselineMtaIncrementalitySelection:
    """Validate incrementality metric selection and fallback."""

    def test_prefers_adjusted_calibrated_over_ucm(self, make_inputs, spark_session):
        """When both metrics exist, adjusted_calibrated_incrementality must take precedence."""
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, _, bp, uc = make_inputs()
        ic_both = spark_session.createDataFrame(
            [
                Row(unique_brand_name="Brand A", super_category_name="Super Cat", sub_category_name="Sub Cat", metric_name="adjusted_calibrated_incrementality", metric_value=500.0),
                Row(unique_brand_name="Brand A", super_category_name="Super Cat", sub_category_name="Sub Cat", metric_name="ucm_incrementality", metric_value=300.0),
            ],
            IC_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [Row(booking_incremental_sales=500.0)],
            T.StructType([T.StructField("booking_incremental_sales", T.DoubleType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic_both, bp, uc, "brand", "Pollen")

        # Assert
        assert_df_equality(
            result.select("booking_incremental_sales"),
            expected,
            ignore_nullable=True,
        )

    def test_falls_back_to_ucm_when_calibrated_absent(self, make_inputs, spark_session):
        """When no adjusted_calibrated_incrementality rows exist the function must use ucm_incrementality."""
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, _, bp, uc = make_inputs()
        ic_ucm_only = spark_session.createDataFrame(
            [
                Row(
                    unique_brand_name="Brand A",
                    super_category_name="Super Cat",
                    sub_category_name="Sub Cat",
                    metric_name="ucm_incrementality",
                    metric_value=300.0,
                )
            ],
            IC_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [Row(booking_incremental_sales=300.0)],
            T.StructType([T.StructField("booking_incremental_sales", T.DoubleType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic_ucm_only, bp, uc, "brand", "Pollen")

        assert_df_equality(
            result.select("booking_incremental_sales"),
            expected,
            ignore_nullable=True,
        )

    def test_falls_back_to_ucm_when_calibrated_is_all_null(self, make_inputs, spark_session):
        """Spark picks `ucm_incrementality` when calibrated metric rows exist but are all NULL.

        This guards against regressions where NULL calibrated rows are treated as usable values.
        """
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, _, bp, uc = make_inputs()
        ic_null_calibrated = spark_session.createDataFrame(
            [
                Row(unique_brand_name="Brand A", super_category_name="Super Cat", sub_category_name="Sub Cat", metric_name="adjusted_calibrated_incrementality", metric_value=None),
                Row(unique_brand_name="Brand A", super_category_name="Super Cat", sub_category_name="Sub Cat", metric_name="ucm_incrementality", metric_value=300.0),
            ],
            IC_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [Row(booking_incremental_sales=300.0)],
            T.StructType([T.StructField("booking_incremental_sales", T.DoubleType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic_null_calibrated, bp, uc, "brand", "Pollen")

        # Assert
        assert_df_equality(
            result.select("booking_incremental_sales"),
            expected,
            ignore_nullable=True,
        )

    def test_no_matching_incrementality_metric_produces_null_booking_incremental_sales(self, make_inputs, spark_session):
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, _, bp, uc = make_inputs()
        ic_irrelevant = spark_session.createDataFrame(
            [
                Row(
                    unique_brand_name="Brand A",
                    super_category_name="Super Cat",
                    sub_category_name="Sub Cat",
                    metric_name="some_other_metric",
                    metric_value=999.0,
                )
            ],
            IC_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [Row(booking_incremental_sales=None)],
            T.StructType([T.StructField("booking_incremental_sales", T.DoubleType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic_irrelevant, bp, uc, "brand", "Pollen")

        assert_df_equality(
            result.select("booking_incremental_sales"),
            expected,
            ignore_nullable=True,
        )

    def test_zero_metric_value_produces_zero_booking_incremental_sales(self, make_inputs, spark_session):
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, _, bp, uc = make_inputs()
        ic_zero = spark_session.createDataFrame(
            [
                Row(
                    unique_brand_name="Brand A",
                    super_category_name="Super Cat",
                    sub_category_name="Sub Cat",
                    metric_name="adjusted_calibrated_incrementality",
                    metric_value=0.0,
                )
            ],
            IC_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [Row(booking_incremental_sales=0.0)],
            T.StructType([T.StructField("booking_incremental_sales", T.DoubleType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic_zero, bp, uc, "brand", "Pollen")

        # Assert
        assert_df_equality(
            result.select("booking_incremental_sales"),
            expected,
            ignore_nullable=True,
        )


class TestCombineBaselineMtaIncrementalCalculations:
    """Validate arithmetic output behavior."""

    def test_negative_incremental_sales_floored_to_zero(self, make_inputs, spark_session):
        """Negative total incremental sales must not propagate: exposed amounts clamped at 0
        via F.greatest(F.lit(0), ...)."""
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, _, bp, uc = make_inputs()
        ic_negative = spark_session.createDataFrame(
            [
                Row(
                    unique_brand_name="Brand A",
                    super_category_name="Super Cat",
                    sub_category_name="Sub Cat",
                    metric_name="ucm_incrementality",
                    metric_value=-100.0,
                )
            ],
            IC_SCHEMA,
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic_negative, bp, uc, "brand", "Pollen")

        # Assert
        expected = spark_session.createDataFrame(
            [Row(incremental_sales_amt_exposed=0.0, incremental_units_qty_exposed=0.0)],
            T.StructType([
                T.StructField("incremental_sales_amt_exposed", T.DoubleType()),
                T.StructField("incremental_units_qty_exposed", T.DoubleType()),
            ]),
        )
        assert_df_equality(
            result.select("incremental_sales_amt_exposed", "incremental_units_qty_exposed"),
            expected,
            ignore_nullable=True,
        )

    def test_booking_incremental_units_derived_from_avg_base_price(self, make_inputs, spark_session):
        """booking_incremental_units = total_incremental_sales / avg(base_price).
        ic=600, two bp rows both at 20 → avg_price=20 → units=30.0."""
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, _, _, uc = make_inputs()
        ic_600 = spark_session.createDataFrame(
            [
                Row(
                    unique_brand_name="Brand A",
                    super_category_name="Super Cat",
                    sub_category_name="Sub Cat",
                    metric_name="adjusted_calibrated_incrementality",
                    metric_value=600.0,
                )
            ],
            IC_SCHEMA,
        )
        bp_avg20 = spark_session.createDataFrame(
            [
                (datetime(2025, 1, 6), "BASE_PRICE", 20.0),
                (datetime(2025, 1, 13), "BASE_PRICE", 20.0),
            ],
            BP_SCHEMA,
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic_600, bp_avg20, uc, "brand", "Pollen")

        # Assert
        expected = spark_session.createDataFrame(
            [Row(booking_incremental_units=30.0)],
            T.StructType([T.StructField("booking_incremental_units", T.DoubleType())]),
        )
        assert_df_equality(
            result.select("booking_incremental_units"),
            expected,
            ignore_nullable=True,
        )

    def test_incremental_pct_sums_to_one_across_channels(self, make_inputs, spark_session):
        """incremental_pct is the share of attributed_recalibrated_sales_amt per booking.
        Two channels at 300 and 200 → pcts 0.6 and 0.4."""
        # Arrange
        _, pre_mta_offer, slaso, _, _, ic, bp, _ = make_inputs()
        pre_mta_two_channels = spark_session.createDataFrame(
            [
                Row(journey_type="Direct", userjourney_id="uj_001", loyalty_id="loy_001",
                    booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                    subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                    event_name="click", transaction_key="t_001", isconversion=1),
                Row(journey_type="Direct", userjourney_id="uj_002", loyalty_id="loy_002",
                    booking_id="bk_001", marketing_type="OFFSITE", channel_name="dv360",
                    subchannel_name="display", campaign_id="cmp_001", campaign_duration="During",
                    event_name="click", transaction_key="t_002", isconversion=1),
            ],
            PRE_MTA_SCHEMA,
        )
        slasb_two_channels = spark_session.createDataFrame(
            [
                Row(journey_type="Direct", userjourney_id="uj_001", booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta", subchannel_name="social", campaign_id="cmp_001", campaign_duration="During", recalibration_factor=1.0, attributed_recalibrated_units_qty=5.0, attributed_units_qty=4.0, attributed_recalibrated_sales_amt=300.0, attributed_sales_amt=240.0, isconversion=1, normalized_weights=1.0),
                Row(journey_type="Direct", userjourney_id="uj_002", booking_id="bk_001", marketing_type="OFFSITE", channel_name="dv360", subchannel_name="display", campaign_id="cmp_001", campaign_duration="During", recalibration_factor=1.0, attributed_recalibrated_units_qty=5.0, attributed_units_qty=4.0, attributed_recalibrated_sales_amt=200.0, attributed_sales_amt=160.0, isconversion=1, normalized_weights=1.0),
            ],
            SLAS_SCHEMA,
        )
        cme_two_channels = spark_session.createDataFrame(
            [
                Row(booking_id="bk_001", campaign_id="cmp_001", channel_name="meta", subchannel_name="social", campaign_start_dt=datetime(2025, 1, 1), campaign_end_dt=datetime(2025, 1, 31), overlapping_campaign_flag=False),
                Row(booking_id="bk_001", campaign_id="cmp_001", channel_name="dv360", subchannel_name="display", campaign_start_dt=datetime(2025, 1, 1), campaign_end_dt=datetime(2025, 1, 31), overlapping_campaign_flag=False),
            ],
            CME_SCHEMA,
        )
        uc_two_channels = spark_session.createDataFrame(
            [
                Row(booking_id="bk_001", job_bag_number="jb_001", campaign_id="cmp_001",
                    campaign_name="Campaign One", channel_name="meta", subchannel_name="social",
                    media_spend_amt=100.0, super_category_name="Super Cat",
                    sub_category_name="Sub Cat", is_multi_channel=True,
                    marketing_hierarchy_cd="mh_001"),
                Row(booking_id="bk_001", job_bag_number="jb_001", campaign_id="cmp_001",
                    campaign_name="Campaign One", channel_name="dv360", subchannel_name="display",
                    media_spend_amt=100.0, super_category_name="Super Cat",
                    sub_category_name="Sub Cat", is_multi_channel=True,
                    marketing_hierarchy_cd="mh_001"),
            ],
            UC_POLLEN_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [
                Row(channel_name="meta", incremental_pct=0.6),
                Row(channel_name="dv360", incremental_pct=0.4),
            ],
            T.StructType([
                T.StructField("channel_name", T.StringType()),
                T.StructField("incremental_pct", T.DoubleType()),
            ]),
        )

        # Act
        result = combine_baseline_mta(
            pre_mta_two_channels, pre_mta_offer, slaso, slasb_two_channels,
            cme_two_channels, ic, bp, uc_two_channels, "brand", "Pollen",
        )

        # Assert
        assert_df_equality(
            result.select("channel_name", "incremental_pct"),
            expected,
            ignore_row_order=True,
            ignore_nullable=True,
        )

    def test_no_base_price_in_date_range_produces_null_booking_incremental_units(self, make_inputs, spark_session):
        """Spark `avg` over an empty filtered base-price set returns one row with NULL aggregate.

        Downstream division therefore yields NULL booking_incremental_units (not 0 and not no row).
        """
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, _, uc = make_inputs()
        bp_out_of_range = spark_session.createDataFrame(
            [Row(week_start_dt=datetime(2024, 1, 6), metric_name="BASE_PRICE", metric_value=10.0)],  # well before 2025-01-01 campaign start
            BP_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [Row(booking_incremental_units=None)],
            T.StructType([T.StructField("booking_incremental_units", T.DoubleType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp_out_of_range, uc, "brand", "Pollen")

        assert_df_equality(
            result.select("booking_incremental_units"),
            expected,
            ignore_nullable=True,
        )

    def test_incremental_pct_window_is_independent_per_booking(self, make_inputs, spark_session):
        """incremental_pct uses Window.partitionBy(booking_id). Two separate bookings must each
        have a single channel that covers 100 % of that booking's attributed sales (pct == 1.0),
        not share a cross-booking denominator."""
        # Arrange
        _, pre_mta_offer, slaso, _, _, ic, bp, _ = make_inputs()
        pre_mta_two_bookings = spark_session.createDataFrame(
            [
                Row(journey_type="Direct", userjourney_id="uj_001", loyalty_id="loy_001",
                    booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                    subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                    event_name="click", transaction_key="t_001", isconversion=1),
                Row(journey_type="Direct", userjourney_id="uj_002", loyalty_id="loy_002",
                    booking_id="bk_002", marketing_type="OFFSITE", channel_name="meta",
                    subchannel_name="social", campaign_id="cmp_002", campaign_duration="During",
                    event_name="click", transaction_key="t_002", isconversion=1),
            ],
            PRE_MTA_SCHEMA,
        )
        slasb_two_bookings = spark_session.createDataFrame(
            [
                Row(journey_type="Direct", userjourney_id="uj_001", booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta", subchannel_name="social", campaign_id="cmp_001", campaign_duration="During", recalibration_factor=1.0, attributed_recalibrated_units_qty=5.0, attributed_units_qty=4.0, attributed_recalibrated_sales_amt=300.0, attributed_sales_amt=240.0, isconversion=1, normalized_weights=1.0),
                Row(journey_type="Direct", userjourney_id="uj_002", booking_id="bk_002", marketing_type="OFFSITE", channel_name="meta", subchannel_name="social", campaign_id="cmp_002", campaign_duration="During", recalibration_factor=1.0, attributed_recalibrated_units_qty=5.0, attributed_units_qty=4.0, attributed_recalibrated_sales_amt=200.0, attributed_sales_amt=160.0, isconversion=1, normalized_weights=1.0),
            ],
            SLAS_SCHEMA,
        )
        cme_two_bookings = spark_session.createDataFrame(
            [
                Row(booking_id="bk_001", campaign_id="cmp_001", channel_name="meta", subchannel_name="social", campaign_start_dt=datetime(2025, 1, 1), campaign_end_dt=datetime(2025, 1, 31), overlapping_campaign_flag=False),
                Row(booking_id="bk_001", campaign_id="cmp_002", channel_name="meta", subchannel_name="social", campaign_start_dt=datetime(2025, 1, 1), campaign_end_dt=datetime(2025, 1, 31), overlapping_campaign_flag=False),
            ],
            CME_SCHEMA,
        )
        uc_two_bookings = spark_session.createDataFrame(
            [
                Row(booking_id="bk_001", job_bag_number="jb_001", campaign_id="cmp_001",
                    campaign_name="Campaign One", channel_name="meta", subchannel_name="social",
                    media_spend_amt=100.0, super_category_name="Super Cat",
                    sub_category_name="Sub Cat", is_multi_channel=False,
                    marketing_hierarchy_cd="mh_001"),
                Row(booking_id="bk_002", job_bag_number="jb_002", campaign_id="cmp_002",
                    campaign_name="Campaign Two", channel_name="meta", subchannel_name="social",
                    media_spend_amt=100.0, super_category_name="Super Cat",
                    sub_category_name="Sub Cat", is_multi_channel=False,
                    marketing_hierarchy_cd="mh_001"),
            ],
            UC_POLLEN_SCHEMA,
        )

        # Act
        result = combine_baseline_mta(
            pre_mta_two_bookings, pre_mta_offer, slaso, slasb_two_bookings,
            cme_two_bookings, ic, bp, uc_two_bookings, "brand", "Pollen",
        )

        # Assert — each booking's sole channel owns 100% of that booking's attributed sales
        expected = spark_session.createDataFrame(
            [
                Row(booking_id="bk_001", incremental_pct=1.0),
                Row(booking_id="bk_002", incremental_pct=1.0),
            ],
            T.StructType([
                T.StructField("booking_id", T.StringType()),
                T.StructField("incremental_pct", T.DoubleType()),
            ]),
        )
        assert_df_equality(
            result.select("booking_id", "incremental_pct"),
            expected,
            ignore_row_order=True,
            ignore_nullable=True,
        )


class TestCombineBaselineMtaConversionCounting:
    """Validate conversion-counting behavior."""

    def test_no_conversions_yields_zero_counts(self, make_inputs, spark_session):
        """When no user journeys convert (isconversion=0), conversion-count columns must be 0."""
        # Arrange
        _, pre_mta_offer, slaso, _, cme, ic, bp, uc = make_inputs()
        pre_mta_no_conv = spark_session.createDataFrame(
            [Row(journey_type="Direct", userjourney_id="uj_001", loyalty_id="loy_001",
                 booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                 subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                 event_name="click", transaction_key="t_001", isconversion=0)],
            PRE_MTA_SCHEMA,
        )
        slasb_no_conv = spark_session.createDataFrame(
            [
                Row(
                    journey_type="Direct",
                    userjourney_id="uj_001",
                    booking_id="bk_001",
                    marketing_type="OFFSITE",
                    channel_name="meta",
                    subchannel_name="social",
                    campaign_id="cmp_001",
                    campaign_duration="During",
                    recalibration_factor=1.0,
                    attributed_recalibrated_units_qty=5.0,
                    attributed_units_qty=4.0,
                    attributed_recalibrated_sales_amt=100.0,
                    attributed_sales_amt=80.0,
                    isconversion=0,
                    normalized_weights=1.0,
                )
            ],
            SLAS_SCHEMA,
        )

        # Act
        result = combine_baseline_mta(pre_mta_no_conv, pre_mta_offer, slaso, slasb_no_conv, cme, ic, bp, uc, "brand", "Pollen")

        # Assert: aggregation keeps the group row and yields numeric zeroes for conversion counters.
        row = result.first()
        assert row["num_conversions"] == 0
        assert row["converted_user_journeys"] == 0

    def test_counts_distinct_converted_journeys_not_touchpoints(self, make_inputs, spark_session):
        """Two touchpoints for the same journey count as one conversion, not two.
        A non-converting second journey must not be counted."""
        # Arrange
        _, pre_mta_offer, slaso, _, cme, ic, bp, uc = make_inputs()
        pre_mta_multi_uj = spark_session.createDataFrame(
            [
                # uj_001: 2 touchpoints, isconversion=1 → should count as 1 converted journey
                Row(journey_type="Direct", userjourney_id="uj_001", loyalty_id="loy_001",
                    booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                    subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                    event_name="click", transaction_key="t_001", isconversion=1),
                Row(journey_type="Direct", userjourney_id="uj_001", loyalty_id="loy_001",
                    booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                    subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                    event_name="click", transaction_key="t_002", isconversion=1),
                # uj_002: 1 touchpoint, isconversion=0 → not a conversion
                Row(journey_type="Direct", userjourney_id="uj_002", loyalty_id="loy_002",
                    booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                    subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                    event_name="click", transaction_key="t_003", isconversion=0),
            ],
            PRE_MTA_SCHEMA,
        )
        slasb_multi_uj = spark_session.createDataFrame(
            [
                Row(journey_type="Direct", userjourney_id="uj_001", booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta", subchannel_name="social", campaign_id="cmp_001", campaign_duration="During", recalibration_factor=1.0, attributed_recalibrated_units_qty=5.0, attributed_units_qty=4.0, attributed_recalibrated_sales_amt=100.0, attributed_sales_amt=80.0, isconversion=1, normalized_weights=0.6),
                Row(journey_type="Direct", userjourney_id="uj_002", booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta", subchannel_name="social", campaign_id="cmp_001", campaign_duration="During", recalibration_factor=1.0, attributed_recalibrated_units_qty=3.0, attributed_units_qty=2.0, attributed_recalibrated_sales_amt=50.0, attributed_sales_amt=40.0, isconversion=0, normalized_weights=0.4),
            ],
            SLAS_SCHEMA,
        )

        # Act
        result = combine_baseline_mta(pre_mta_multi_uj, pre_mta_offer, slaso, slasb_multi_uj, cme, ic, bp, uc, "brand", "Pollen")

        # Assert
        row = result.first()
        assert row["num_user_journeys"] == 2
        assert row["converted_user_journeys"] == 1

    def test_attributed_conversions_is_weighted_sum_of_converted_journeys(self, make_inputs, spark_session):
        """attributed_conversions = sum(normalized_weights × isconversion) per channel group.
        normalized_weights=0.6 on a converted journey → attributed_conversions == 0.6."""
        # Arrange
        _, pre_mta_offer, slaso, _, cme, ic, bp, uc = make_inputs()
        pre_mta_brand = spark_session.createDataFrame(
            [Row(journey_type="Direct", userjourney_id="uj_001", loyalty_id="loy_001",
                 booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                 subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                 event_name="click", transaction_key="t_001", isconversion=1)],
            PRE_MTA_SCHEMA,
        )
        slasb_weighted = spark_session.createDataFrame(
            [
                Row(
                    journey_type="Direct",
                    userjourney_id="uj_001",
                    booking_id="bk_001",
                    marketing_type="OFFSITE",
                    channel_name="meta",
                    subchannel_name="social",
                    campaign_id="cmp_001",
                    campaign_duration="During",
                    recalibration_factor=1.0,
                    attributed_recalibrated_units_qty=5.0,
                    attributed_units_qty=4.0,
                    attributed_recalibrated_sales_amt=100.0,
                    attributed_sales_amt=80.0,
                    isconversion=1,
                    normalized_weights=0.6,
                )
            ],
            SLAS_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [Row(attributed_conversions=0.6)],
            T.StructType([T.StructField("attributed_conversions", T.DoubleType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb_weighted, cme, ic, bp, uc, "brand", "Pollen")

        # Assert  — attributed_conversions = 0.6 × 1 = 0.6
        assert_df_equality(result.select("attributed_conversions"), expected, ignore_nullable=True)

    def test_modelling_weight_is_sum_of_normalized_weights_across_journeys(self, make_inputs, spark_session):
        """modelling_weight = sum(normalized_total_weights) across all user journeys in the group.
        Two journeys contribute 0.6 and 0.4 → modelling_weight == 1.0."""
        # Arrange
        _, pre_mta_offer, slaso, _, cme, ic, bp, uc = make_inputs()
        pre_mta_brand = spark_session.createDataFrame(
            [
                Row(journey_type="Direct", userjourney_id="uj_001", loyalty_id="loy_001",
                    booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                    subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                    event_name="click", transaction_key="t_001", isconversion=1),
                Row(journey_type="Direct", userjourney_id="uj_002", loyalty_id="loy_002",
                    booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                    subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                    event_name="click", transaction_key="t_002", isconversion=0),
            ],
            PRE_MTA_SCHEMA,
        )
        slasb_two_journeys = spark_session.createDataFrame(
            [
                Row(journey_type="Direct", userjourney_id="uj_001", booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta", subchannel_name="social", campaign_id="cmp_001", campaign_duration="During", recalibration_factor=1.0, attributed_recalibrated_units_qty=5.0, attributed_units_qty=4.0, attributed_recalibrated_sales_amt=100.0, attributed_sales_amt=80.0, isconversion=1, normalized_weights=0.6),
                Row(journey_type="Direct", userjourney_id="uj_002", booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta", subchannel_name="social", campaign_id="cmp_001", campaign_duration="During", recalibration_factor=1.0, attributed_recalibrated_units_qty=3.0, attributed_units_qty=2.0, attributed_recalibrated_sales_amt=50.0, attributed_sales_amt=40.0, isconversion=0, normalized_weights=0.4),
            ],
            SLAS_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [Row(modelling_weight=1.0)],
            T.StructType([T.StructField("modelling_weight", T.DoubleType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb_two_journeys, cme, ic, bp, uc, "brand", "Pollen")

        # Assert  — 0.6 + 0.4 = 1.0
        assert_df_equality(result.select("modelling_weight"), expected, ignore_nullable=True)

    def test_conversions_recalibrated_uses_recalibration_factor(self, make_inputs, spark_session):
        """conversions_recalibrated = sum(normalized_weights × isconversion × recalibration_factor).
        normalized_weights=0.8, isconversion=1, recalibration_factor=1.25 → 1.0."""
        # Arrange
        _, pre_mta_offer, slaso, _, cme, ic, bp, uc = make_inputs()
        pre_mta_brand = spark_session.createDataFrame(
            [Row(journey_type="Direct", userjourney_id="uj_001", loyalty_id="loy_001",
                 booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                 subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                 event_name="click", transaction_key="t_001", isconversion=1)],
            PRE_MTA_SCHEMA,
        )
        slasb_recal = spark_session.createDataFrame(
            [
                Row(
                    journey_type="Direct",
                    userjourney_id="uj_001",
                    booking_id="bk_001",
                    marketing_type="OFFSITE",
                    channel_name="meta",
                    subchannel_name="social",
                    campaign_id="cmp_001",
                    campaign_duration="During",
                    recalibration_factor=1.25,
                    attributed_recalibrated_units_qty=5.0,
                    attributed_units_qty=4.0,
                    attributed_recalibrated_sales_amt=100.0,
                    attributed_sales_amt=80.0,
                    isconversion=1,
                    normalized_weights=0.8,
                )
            ],
            SLAS_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [Row(conversions_recalibrated=1.0)],
            T.StructType([T.StructField("conversions_recalibrated", T.DoubleType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb_recal, cme, ic, bp, uc, "brand", "Pollen")

        # Assert  — 0.8 × 1 × 1.25 = 1.0
        assert_df_equality(result.select("conversions_recalibrated"), expected, ignore_nullable=True)

    def test_all_transaction_events_produces_empty_result(self, make_inputs, spark_session):
        """If every pre-MTA row is a transaction the user-journey aggregation is empty,
        causing the inner join to produce no output rows."""
        # Arrange
        _, pre_mta_offer, slaso, slasb, cme, ic, bp, uc = make_inputs()
        pre_mta_all_transactions = spark_session.createDataFrame(
            [Row(journey_type="Direct", userjourney_id="uj_001", loyalty_id="loy_001",
                 booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                 subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                 event_name="transaction", transaction_key="t_001", isconversion=1)],
            PRE_MTA_SCHEMA,
        )

        # Act
        result = combine_baseline_mta(pre_mta_all_transactions, pre_mta_offer, slaso, slasb, cme, ic, bp, uc, "brand", "Pollen")

        # Assert
        assert result.count() == 0

    def test_journey_type_normalized_to_initcap_for_join(self, make_inputs, spark_session):
        """journey_type goes through initcap in both aggregations: 'DIRECT' and 'direct'
        both normalise to 'Direct' and join successfully, producing one output row."""
        # Arrange
        _, pre_mta_offer, slaso, _, cme, ic, bp, uc = make_inputs()
        pre_mta_uppercase = spark_session.createDataFrame(
            [
                Row(
                    journey_type="DIRECT",
                    userjourney_id="uj_001",
                    loyalty_id="loy_001",
                    booking_id="bk_001",
                    marketing_type="OFFSITE",
                    channel_name="meta",
                    subchannel_name="social",
                    campaign_id="cmp_001",
                    campaign_duration="During",
                    event_name="click",
                    transaction_key="t_001",
                    isconversion=1,
                )
            ],
            PRE_MTA_SCHEMA,
        )
        slasb_lowercase = spark_session.createDataFrame(
            [
                Row(
                    journey_type="direct",
                    userjourney_id="uj_001",
                    booking_id="bk_001",
                    marketing_type="OFFSITE",
                    channel_name="meta",
                    subchannel_name="social",
                    campaign_id="cmp_001",
                    campaign_duration="During",
                    recalibration_factor=1.0,
                    attributed_recalibrated_units_qty=5.0,
                    attributed_units_qty=4.0,
                    attributed_recalibrated_sales_amt=100.0,
                    attributed_sales_amt=80.0,
                    isconversion=1,
                    normalized_weights=1.0,
                )
            ],
            SLAS_SCHEMA,
        )

        # Act
        result = combine_baseline_mta(pre_mta_uppercase, pre_mta_offer, slaso, slasb_lowercase, cme, ic, bp, uc, "brand", "Pollen")

        # Assert
        rows = result.select("journey_type").collect()
        assert len(rows) == 1
        assert rows[0]["journey_type"] == "Direct"


class TestCombineBaselineMtaCampaignMetadata:
    """Validate UC join behavior and campaign-type derivation."""

    def test_multi_channel_flag_sets_campaign_type(self, make_inputs, spark_session):
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, _ = make_inputs()
        uc_multi = spark_session.createDataFrame(
            [Row(booking_id="bk_001", job_bag_number="jb_001", campaign_id="cmp_001",
                 campaign_name="Campaign One", channel_name="meta", subchannel_name="social",
                 media_spend_amt=200.0, super_category_name="Super Cat",
                 sub_category_name="Sub Cat", is_multi_channel=True,
                 marketing_hierarchy_cd="mh_001")],
            UC_POLLEN_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [Row(campaign_type="Multi Channel")],
            T.StructType([T.StructField("campaign_type", T.StringType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc_multi, "brand", "Pollen")

        # Assert
        assert_df_equality(
            result.select("campaign_type"),
            expected,
            ignore_nullable=True,
        )

    def test_single_channel_flag_sets_campaign_type(self, make_inputs, spark_session):
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc = make_inputs()
        expected = spark_session.createDataFrame(
            [Row(campaign_type="Single Channel")],
            T.StructType([T.StructField("campaign_type", T.StringType())]),
        )

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc, "brand", "Pollen")

        # Assert
        assert_df_equality(
            result.select("campaign_type"),
            expected,
            ignore_nullable=True,
        )

    def test_campaign_absent_from_uc_yields_null_campaign_metadata(self, make_inputs, spark_session):
        """If the campaign exists in SLAS/pre-MTA but not in UC, the left join keeps
        MTA rows but produces NULL for UC-sourced columns (campaign_name, media_spend_amt)."""
        # Arrange
        pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, _ = make_inputs()
        uc_empty = spark_session.createDataFrame([], UC_POLLEN_SCHEMA)

        # Act
        result = combine_baseline_mta(pre_mta_brand, pre_mta_offer, slaso, slasb, cme, ic, bp, uc_empty, "brand", "Pollen")

        # Assert: final join is left-sided from MTA, so row survives even when UC side is missing.
        row = result.first()
        assert row is not None, "Left join must keep MTA rows even without a UC match"
        assert row["campaign_name"] is None
        assert row["media_spend_amt"] is None

    def test_campaign_in_uc_but_absent_from_cme_has_null_uc_metadata(self, make_inputs, spark_session):
        """A campaign present in UC but absent from CME is dropped by the UC×CME inner join
        inside uc_filtered. The MTA row is still retained via the final left join but
        UC-sourced columns (campaign_name, media_spend_amt) must be NULL."""
        # === ARRANGE: cmp_001 is in both CME and UC (normal); cmp_extra is in UC only
        pre_mta_brand, pre_mta_offer, slaso, _, _, ic, bp, _ = make_inputs()

        # Extend pre_mta_brand and slasb to include cmp_extra so it reaches mta_uj_combined
        pre_mta_with_extra = spark_session.createDataFrame(
            [
                Row(journey_type="Direct", userjourney_id="uj_001", loyalty_id="loy_001",
                    booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                    subchannel_name="social", campaign_id="cmp_001", campaign_duration="During",
                    event_name="click", transaction_key="t_001", isconversion=1),
                Row(journey_type="Direct", userjourney_id="uj_extra", loyalty_id="loy_003",
                    booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta",
                    subchannel_name="social", campaign_id="cmp_extra", campaign_duration="During",
                    event_name="click", transaction_key="t_003", isconversion=1),
            ],
            PRE_MTA_SCHEMA,
        )
        slasb_with_extra = spark_session.createDataFrame(
            [
                Row(journey_type="Direct", userjourney_id="uj_001", booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta", subchannel_name="social", campaign_id="cmp_001", campaign_duration="During", recalibration_factor=1.0, attributed_recalibrated_units_qty=5.0, attributed_units_qty=4.0, attributed_recalibrated_sales_amt=100.0, attributed_sales_amt=80.0, isconversion=1, normalized_weights=1.0),
                Row(journey_type="Direct", userjourney_id="uj_extra", booking_id="bk_001", marketing_type="OFFSITE", channel_name="meta", subchannel_name="social", campaign_id="cmp_extra", campaign_duration="During", recalibration_factor=1.0, attributed_recalibrated_units_qty=5.0, attributed_units_qty=4.0, attributed_recalibrated_sales_amt=100.0, attributed_sales_amt=80.0, isconversion=1, normalized_weights=1.0),
            ],
            SLAS_SCHEMA,
        )
        # cmp_001 is in CME; cmp_extra is intentionally absent
        cme_without_extra = spark_session.createDataFrame(
            [
                Row(
                    booking_id="bk_001",
                    campaign_id="cmp_001",
                    channel_name="meta",
                    subchannel_name="social",
                    campaign_start_dt=datetime(2025, 1, 1),
                    campaign_end_dt=datetime(2025, 1, 31),
                    overlapping_campaign_flag=False,
                )
            ],
            CME_SCHEMA,
        )
        # Both campaigns are in UC
        uc_with_extra = spark_session.createDataFrame(
            [
                Row(booking_id="bk_001", job_bag_number="jb_001", campaign_id="cmp_001",
                    campaign_name="Campaign One", channel_name="meta", subchannel_name="social",
                    media_spend_amt=200.0, super_category_name="Super Cat",
                    sub_category_name="Sub Cat", is_multi_channel=False,
                    marketing_hierarchy_cd="mh_001"),
                Row(booking_id="bk_001", job_bag_number="jb_002", campaign_id="cmp_extra",
                    campaign_name="Extra Campaign", channel_name="meta", subchannel_name="social",
                    media_spend_amt=500.0, super_category_name="Super Cat",
                    sub_category_name="Sub Cat", is_multi_channel=False,
                    marketing_hierarchy_cd="mh_002"),
            ],
            UC_POLLEN_SCHEMA,
        )

        # === ACT
        result = combine_baseline_mta(
            pre_mta_with_extra, pre_mta_offer, slaso, slasb_with_extra,
            cme_without_extra, ic, bp, uc_with_extra, "brand", "Pollen",
        )

        # === ASSERT — cmp_extra rows are present (left join retains them) but UC metadata is NULL.
        # Select only the columns under test to avoid materialising the full wide schema.
        result_rows = result.select("campaign_id", "campaign_name", "media_spend_amt").collect()

        cmp_extra_rows = [r for r in result_rows if r["campaign_id"] == "cmp_extra"]
        cmp_001_rows = [r for r in result_rows if r["campaign_id"] == "cmp_001"]

        assert len(cmp_extra_rows) > 0, "MTA row(s) for cmp_extra must survive the left join"
        assert all(r["campaign_name"] is None for r in cmp_extra_rows)
        assert all(r["media_spend_amt"] is None for r in cmp_extra_rows)
        # cmp_001 retains its UC metadata across all its rows
        assert len(cmp_001_rows) > 0
        assert all(r["campaign_name"] == "Campaign One" for r in cmp_001_rows)


# ─── Characterisation: full written output of prepare_baseline_mta_integration ─────────────

_MCR = "spark_pipeline.measurement_campaign_reporting.measurement_campaign_reporting"


def _char_integration_row(**overrides):
    row = {
        "unique_brand_name": "Brand A",
        "channel_name": "meta",
        "campaign_id": "cmp_001",
        "booking_id": "booking_001",
        "campaign_duration": "During",
        "journey_type": "Direct",
        "marketing_type": "OFFSITE",
        "subchannel_name": "social",
        "marketing_hierarchy_cd": "mh_001",
        "sub_category_name": "Sub Cat",
        "super_category_name": "Super Cat",
        "campaign_name": "Campaign 1",
        "job_bag_number": "JB001",
        "campaign_type": "Single Channel",
        "overlapping_campaign_flag": False,
        "product_type": "BRAND",
        "recalibration_factor": 1.2,
        "media_spend_amt": 50.0,
        "modelling_weight": 1.0,
        "attributed_recalibrated_sales_amt": 100.0,
        "incremental_sales_amt_exposed": 20.0,
        "attributed_recalibrated_units_qty": 50.0,
        "incremental_units_qty_exposed": 10.0,
        "attributed_sales_amt": 80.0,
        "attributed_units_qty": 40.0,
        "attributed_conversions": 5.0,
        "conversions": 4.0,
        "conversions_recalibrated": 6.0,
        "num_user_journeys": 100.0,
        "num_conversions": 5.0,
    }
    return {**row, **overrides}


_MCR_FIELDS = {field.name: field for field in MeasurementCampaignReportingPollen.measures_schema.fields}
# Integration output is the MCR schema subset plus the two columns MCR drops or never persists.
CHAR_INTEGRATION_SCHEMA = T.StructType(
    [_MCR_FIELDS[name] for name in _char_integration_row() if name in _MCR_FIELDS]
    + [T.StructField("unique_brand_name", T.StringType()), T.StructField("conversions", T.DoubleType())]
)


def _char_output_row(**overrides):
    row = {
        **_char_integration_row(),
        "brand_id": None,
        "correlation_id": "corr-char",
        "run_type": "Pollen",
        "nectar_sales_amt": None,
        "non_nectar_sales_amt": None,
        "spend_weight": 1.0,
        "base_sales_amt_exposed": 80.0,
        "uplift_exposed_sales_amt": 0.25,
        "uplift_exposed_units_qty": 0.25,
        "roas_exposed": 2.0,
        "iroas_exposed": 0.4,
        "attributed_recalibrated_sales_amt_per_uj": 1.0,
        "attributed_recalibrated_sales_amt_per_conversion": 20.0,
        "conversion_per_uj": 0.04,
        "conversion_rate": 6.0,
    }
    row = {**row, **overrides}
    # conversions feeds conversion_per_uj but is not part of the written schema.
    row.pop("conversions")
    return row


# Post rows carry the normalised join keys and no unique_brand_name, as the published During has none.
_CHAR_POST_KEYS = {
    "campaign_id": "Cmp_001",
    "booking_id": "Booking_001",
    "marketing_type": "Offsite",
    "marketing_hierarchy_cd": "Mh_001",
    "job_bag_number": "Jb001",
    "unique_brand_name": None,
    "campaign_duration": "Post",
    "brand_id": "brand_during",
    "conversion_rate": 0.0,
}


@pytest.fixture
def char_paths(spark_session, integration_paths, tmp_path):
    _write_minimum_parquet_inputs(spark_session, integration_paths)
    paths = {
        **integration_paths,
        "unified_campaign_pollen": str(tmp_path / "unified_campaign_pollen"),
        "legacy": str(tmp_path / "legacy"),
        "brand_data": str(tmp_path / "brand_data"),
        "spend_weights": str(tmp_path / "spend_weights"),
        "previous": str(tmp_path / "previous"),
    }
    spark_session.createDataFrame(
    [("JB001", "cmp_001", "meta", "social",
      datetime(2025, 1, 1), datetime(2025, 1, 31), False)],
    "booking_id string, campaign_id string, channel_name string, "
    "subchannel_name string, campaign_start_dt timestamp, "
    "campaign_end_dt timestamp, overlapping_campaign_flag boolean",
    ).write.mode("overwrite").parquet(paths["campaign_execution"])
    spark_session.createDataFrame(
        [("booking_001", "JB001", "cmp_001", "Campaign 1", "meta", "social", 50.0, "Super Cat", "Sub Cat", False, "mh_001")],
        "booking_id string, job_bag_number string, campaign_id string, campaign_name string, channel_name string, "
        "subchannel_name string, media_spend_amt double, super_category_name string, sub_category_name string, "
        "is_multi_channel boolean, marketing_hierarchy_cd string",
    ).write.mode("overwrite").parquet(paths["unified_campaign_pollen"])
    spark_session.createDataFrame(
        [("booking_001", "meta", "social", 100), ("booking_001", "coupon at till", "till", 100)],
        "booking_id string, channel_name string, subchannel_name string, reach_cnt long",
    ).write.mode("overwrite").parquet(paths["reach_engagement"])
    spark_session.createDataFrame(
        [("meta",), ("coupon at till",)], "marketing_channel string",
    ).write.mode("overwrite").parquet(paths["channel_hierarchy"])
    spark_session.createDataFrame(
        [("cmp_001", "During", 40.0, 20.0, "item_1")],
        "campaign_id string, period string, uplift double, media_cost double, item_cd string",
    ).write.mode("overwrite").parquet(paths["legacy"])
    spark_session.createDataFrame(
        [("item_1", "Brand A")], "item_cd string, unique_brand_name string",
    ).write.mode("overwrite").parquet(paths["brand_data"])
    spark_session.createDataFrame(
        [("booking_001", "BRAND", "During", 0.5), ("booking_001", "BRAND", "Post", 0.4)],
        "booking_id string, product_type string, campaign_duration string, spend_weight double",
    ).write.mode("overwrite").parquet(paths["spend_weights"])
    return paths


def _write_char_during(spark_session, path, spend_weight, product_type="BRAND"):
    """Published During output: 100/20 sales, 50/10 units, stored at the given spend weight."""
    spark_session.createDataFrame(
        [{
            "correlation_id": "corr-during",
            "brand_id": "brand_during",
            "campaign_id": "cmp_001",
            "booking_id": "booking_001",
            "campaign_duration": "During",
            "journey_type": "Direct",
            "marketing_type": "OFFSITE",
            "channel_name": "meta",
            "subchannel_name": "social",
            "sub_category_name": "Sub Cat",
            "attributed_conversions": 5.0,
            "incremental_sales_amt_exposed": 20.0,
            "super_category_name": "Super Cat",
            "campaign_name": "Campaign 1",
            "attributed_recalibrated_sales_amt": 100.0,
            "attributed_recalibrated_units_qty": 50.0,
            "incremental_units_qty_exposed": 10.0,
            "attributed_units_qty": 40.0,
            "attributed_sales_amt": 80.0,
            "conversions_recalibrated": 6.0,
            "recalibration_factor": 1.2,
            "job_bag_number": "JB001",
            "media_spend_amt": 50.0,
            "campaign_type": "Single Channel",
            "roas_exposed": 2.0,
            "iroas_exposed": 0.4,
            "base_sales_amt_exposed": 80.0,
            "uplift_exposed_sales_amt": 0.25,
            "uplift_exposed_units_qty": 0.25,
            "num_user_journeys": 100.0,
            "num_conversions": 5.0,
            "attributed_recalibrated_sales_amt_per_uj": 1.0,
            "attributed_recalibrated_sales_amt_per_conversion": 20.0,
            "conversion_per_uj": 0.04,
            "conversion_rate": 6.0,
            "load_ts": datetime(2026, 3, 5),
            "modelling_weight": 1.0,
            "marketing_hierarchy_cd": "mh_001",
            "run_type": "Pollen",
            "dag_run_ts": datetime(2026, 3, 5),
            "overlapping_campaign_flag": False,
            "product_type": product_type,
            "spend_weight": spend_weight,
        }],
        schema=MeasurementCampaignReportingPollen().measures_schema,
    ).write.mode("overwrite").parquet(path)


def _run_char(spark_session, paths, brand_rows, unified_campaign_path=None, written_frames=None, **kwargs):
    """Run the orchestrator on mocked integration rows and return the written rows, minus timestamps."""
    offer = spark_session.createDataFrame([], CHAR_INTEGRATION_SCHEMA)
    brand = spark_session.createDataFrame(brand_rows, CHAR_INTEGRATION_SCHEMA)
    with patch(f"{_MCR}.combine_baseline_mta", side_effect=[offer, brand]), \
            patch(f"{_MCR}.spark_s3_overwrite") as mock_write:
        prepare_baseline_mta_integration(
            spark=spark_session,
            incremental_shrinkage_path=paths["incremental_shrinkage"],
            campaign_execution_path=paths["campaign_execution"],
            unified_campaign_path=unified_campaign_path or paths["unified_campaign_pollen"],
            sku_level_attributed_sales_units_brand_path=paths["slas_brand"],
            sku_level_attributed_sales_units_offer_path=paths["slas_offer"],
            pre_mta_brand_path=paths["pre_mta_brand"],
            pre_mta_offer_path=paths["pre_mta_offer"],
            base_price_path=paths["base_price"],
            reach_engagement_path=paths["reach_engagement"],
            measurement_marketing_channel_hierarchy_path=paths["channel_hierarchy"],
            published_campaign_reporting_path=paths["published_campaign_reporting"],
            output_path=paths["output"],
            run_date="2026-03-06",
            correlation_id="corr-char",
            slack_topic_arn="arn:topic",
            **kwargs,
        )
        if written_frames is not None:
            written_frames.update({path: df for path, df in (call.args for call in mock_write.call_args_list)})
        written_df = _written(mock_write, paths["output"])
        rows = [row.asDict() for row in written_df.drop("load_ts", "dag_run_ts").collect()]
    return sorted(rows, key=lambda r: (r["campaign_duration"], r["product_type"], r["channel_name"]))


def _written(mock_write, path):
    """The DataFrame written to path, which must have been written exactly once."""
    written = [df for written_path, df in (c.args for c in mock_write.call_args_list) if written_path == path]
    assert len(written) == 1
    return written[0]


def _during_kwargs(paths):
    return {
        "campaign_period": "During",
        "measurement_legacy_campaign_performance": paths["legacy"],
        "brand_data_path": paths["brand_data"],
    }


_CHAR_OUT_OF_SCOPE_ROW = _char_integration_row(
    channel_name="outofscope", campaign_id="cmp_002", subchannel_name="display",
    attributed_recalibrated_sales_amt=10.0, incremental_sales_amt_exposed=2.0,
)


def test_char_during_published_fallback(spark_session, char_paths):
    # 120 >= 100 triggers fallback; incremental sales = 100 x 0.3, units = 50 x 0.3.
    with patch(
        "spark_pipeline.measurement_campaign_reporting.incrementality_fallback.compute_fallback_ratio",
        return_value=0.3,
    ):
        rows = _run_char(
            spark_session,
            char_paths,
            [_char_integration_row(incremental_sales_amt_exposed=120.0), _CHAR_OUT_OF_SCOPE_ROW],
            **_during_kwargs(char_paths),
        )

    assert rows == [pytest.approx(_char_output_row(
        incremental_sales_amt_exposed=30.0,
        base_sales_amt_exposed=70.0,
        uplift_exposed_sales_amt=30.0 / 70.0,
        iroas_exposed=0.6,
        incremental_units_qty_exposed=15.0,
        uplift_exposed_units_qty=15.0 / 35.0,
    ))]


def test_char_brand_fallback_preserves_offer_output_and_audit(spark_session, char_paths):
    brand = _char_integration_row(incremental_sales_amt_exposed=120.0, incremental_units_qty_exposed=60.0)
    offer = _char_integration_row(
        product_type="OFFER", incremental_sales_amt_exposed=0.0, incremental_units_qty_exposed=0.0,
    )
    written_frames = {}
    audit_path = "s3://output/reporting-audit"
    metadata_path = "s3://output/fallback-metadata"

    with patch(
        "spark_pipeline.measurement_campaign_reporting.incrementality_fallback.compute_fallback_ratio",
        return_value=0.3,
    ):
        rows = _run_char(
            spark_session,
            char_paths,
            [brand, offer],
            written_frames=written_frames,
            measurement_campaign_reporting_audit_path=audit_path,
            fallback_metadata_path=metadata_path,
            **_during_kwargs(char_paths),
        )

    output = {row["product_type"]: row for row in rows}
    assert output["BRAND"]["incremental_sales_amt_exposed"] == pytest.approx(30.0)
    assert output["BRAND"]["incremental_units_qty_exposed"] == pytest.approx(15.0)
    assert output["BRAND"]["base_sales_amt_exposed"] == pytest.approx(70.0)
    assert output["OFFER"]["incremental_sales_amt_exposed"] == 0.0
    assert output["OFFER"]["incremental_units_qty_exposed"] == 0.0
    assert output["OFFER"]["base_sales_amt_exposed"] == pytest.approx(100.0)
    assert output["OFFER"]["uplift_exposed_sales_amt"] == 0.0
    assert output["OFFER"]["uplift_exposed_units_qty"] == 0.0
    assert output["OFFER"]["iroas_exposed"] == 0.0

    audit = {row["product_type"]: row.asDict() for row in written_frames[audit_path].collect()}
    assert audit["BRAND"]["fallback_incremental_sales_amt_exposed"] == pytest.approx(30.0)
    assert audit["BRAND"]["fallback_ratio"] == pytest.approx(0.3)
    assert audit["OFFER"]["pre_fallback_incremental_sales_amt_exposed"] == 0.0
    assert audit["OFFER"]["fallback_incremental_sales_amt_exposed"] == 0.0
    assert audit["OFFER"]["fallback_incremental_units_qty_exposed"] == 0.0
    assert audit["OFFER"]["fallback_state"] is None
    assert audit["OFFER"]["fallback_ratio"] is None
    assert audit["OFFER"]["fallback_control_factor"] is None
    assert audit["OFFER"]["fallback_is_fallback"] is True
    assert written_frames[metadata_path].first()["is_fallback"] is True


def test_char_post_weighted_no_fallback(spark_session, char_paths):
    # During stored at w_D = 0.5; Post component weighted at w_P = 0.4.
    _write_char_during(spark_session, char_paths["previous"], spend_weight=0.5)
    during_plus_post = _char_integration_row(
        campaign_duration="Post",
        attributed_recalibrated_sales_amt=260.0, incremental_sales_amt_exposed=50.0,
        attributed_recalibrated_units_qty=130.0, incremental_units_qty_exposed=25.0,
        attributed_sales_amt=200.0, attributed_units_qty=100.0, attributed_conversions=12.0,
        conversions=10.0, conversions_recalibrated=14.0, num_conversions=12.0, num_user_journeys=250.0,
        modelling_weight=2.0,
    )

    rows = _run_char(
        spark_session, char_paths, [during_plus_post],
        campaign_period="Post",
        previous_measurement_campaign_reporting=char_paths["previous"],
        overlapping_campaign_spend_weights_path=char_paths["spend_weights"],
    )

    assert rows == [
        # D+P = D + Post for every weighted column.
        pytest.approx(_char_output_row(
            campaign_duration="During+Post", brand_id="brand_during", spend_weight=None,
            attributed_recalibrated_sales_amt=124.0, incremental_sales_amt_exposed=24.0,
            attributed_recalibrated_units_qty=62.0, incremental_units_qty_exposed=12.0,
            attributed_sales_amt=96.0, attributed_units_qty=48.0, attributed_conversions=5.8,
            conversions_recalibrated=6.8, num_conversions=6.0, num_user_journeys=250.0, modelling_weight=2.0,
            base_sales_amt_exposed=100.0, uplift_exposed_sales_amt=0.24, uplift_exposed_units_qty=0.24,
            roas_exposed=2.48, iroas_exposed=0.48, attributed_recalibrated_sales_amt_per_uj=0.496,
            attributed_recalibrated_sales_amt_per_conversion=124.0 / 6.0,
            conversion_per_uj=4.8 / 250, conversion_rate=6.8,
        )),
        # Post = (DP - D / 0.5) x 0.4.
        pytest.approx(_char_output_row(
            **_CHAR_POST_KEYS, spend_weight=0.4,
            attributed_recalibrated_sales_amt=24.0, incremental_sales_amt_exposed=4.0,
            attributed_recalibrated_units_qty=12.0, incremental_units_qty_exposed=2.0,
            attributed_sales_amt=16.0, attributed_units_qty=8.0, attributed_conversions=0.8,
            conversions_recalibrated=0.8, num_conversions=1.0, num_user_journeys=150.0, modelling_weight=1.0,
            base_sales_amt_exposed=20.0, uplift_exposed_sales_amt=0.2, uplift_exposed_units_qty=0.2,
            roas_exposed=0.48, iroas_exposed=0.08, attributed_recalibrated_sales_amt_per_uj=0.16,
            attributed_recalibrated_sales_amt_per_conversion=24.0, conversion_per_uj=0.8 / 150,
        )),
    ]


def test_char_post_unweighted_no_fallback(spark_session, char_paths):
    _write_char_during(spark_session, char_paths["previous"], spend_weight=1.0)
    during_plus_post = _char_integration_row(
        campaign_duration="Post",
        attributed_recalibrated_sales_amt=120.0, incremental_sales_amt_exposed=30.0,
        attributed_recalibrated_units_qty=60.0, incremental_units_qty_exposed=15.0,
        attributed_sales_amt=96.0, attributed_units_qty=48.0, attributed_conversions=6.0,
        conversions=5.0, conversions_recalibrated=7.0, num_conversions=6.0, num_user_journeys=120.0,
        modelling_weight=1.5,
    )

    rows = _run_char(
        spark_session, char_paths, [during_plus_post],
        campaign_period="Post",
        previous_measurement_campaign_reporting=char_paths["previous"],
    )

    assert rows == [
        # Raw D+P, published as is.
        pytest.approx(_char_output_row(
            **{**during_plus_post, "campaign_duration": "During+Post"},
            brand_id="brand_during",
            base_sales_amt_exposed=90.0, uplift_exposed_sales_amt=1.0 / 3, uplift_exposed_units_qty=1.0 / 3,
            roas_exposed=2.4, iroas_exposed=0.6, attributed_recalibrated_sales_amt_per_uj=1.0,
            attributed_recalibrated_sales_amt_per_conversion=20.0,
            conversion_per_uj=5.0 / 120, conversion_rate=7.0,
        )),
        # Post = DP - D.
        pytest.approx(_char_output_row(
            **_CHAR_POST_KEYS,
            attributed_recalibrated_sales_amt=20.0, incremental_sales_amt_exposed=10.0,
            attributed_recalibrated_units_qty=10.0, incremental_units_qty_exposed=5.0,
            attributed_sales_amt=16.0, attributed_units_qty=8.0, attributed_conversions=1.0,
            conversions_recalibrated=1.0, num_conversions=1.0, num_user_journeys=20.0, modelling_weight=0.5,
            base_sales_amt_exposed=10.0, uplift_exposed_sales_amt=1.0, uplift_exposed_units_qty=1.0,
            roas_exposed=0.4, iroas_exposed=0.2, attributed_recalibrated_sales_amt_per_uj=1.0,
            attributed_recalibrated_sales_amt_per_conversion=20.0, conversion_per_uj=0.05,
        )),
    ]


def test_pollen_out_of_scope_channel_does_not_trigger_fallback(spark_session, char_paths):
    # In-scope 100/30 does not trigger; with the out-of-scope 10/90 the totals 110/120 would.
    out_of_scope = _char_integration_row(
        channel_name="banner x", campaign_id="cmp_002", subchannel_name="display",
        attributed_recalibrated_sales_amt=10.0, incremental_sales_amt_exposed=90.0,
    )

    with patch("spark_pipeline.measurement_campaign_reporting.incrementality_fallback.compute_fallback_ratio") as mock_ratio:
        rows = _run_char(
            spark_session, char_paths,
            [_char_integration_row(incremental_sales_amt_exposed=30.0), out_of_scope],
            **_during_kwargs(char_paths),
        )

    mock_ratio.assert_not_called()
    assert rows == [pytest.approx(_char_output_row(
        incremental_sales_amt_exposed=30.0,
        base_sales_amt_exposed=70.0,
        uplift_exposed_sales_amt=30.0 / 70.0,
        iroas_exposed=0.6,
    ))]

# ─── Fallback wiring tests ─────────────


def test_control_method_selected_after_channel_filter(spark_session, char_paths):
    # Coupon at till alone is a control channel once the out-of-scope banner x row is filtered.
    spark_session.createDataFrame(
        [("cmp_001", "During", 15.0, 20.0, "item_1")],
        "campaign_id string, period string, uplift double, media_cost double, item_cd string",
    ).write.mode("overwrite").parquet(char_paths["legacy"])
    coupon_at_till = _char_integration_row(
        channel_name="coupon at till", subchannel_name="till",
        attributed_recalibrated_sales_amt=20.0, incremental_sales_amt_exposed=30.0,
    )
    banner_x = _char_integration_row(
        channel_name="banner x", campaign_id="cmp_002", subchannel_name="display",
        attributed_recalibrated_sales_amt=100.0, incremental_sales_amt_exposed=10.0,
    )

    rows = _run_char(spark_session, char_paths, [coupon_at_till, banner_x], **_during_kwargs(char_paths))

    # Control factor 15 / 30 = 0.5 on sales 30 and units 10.
    assert [row["channel_name"] for row in rows] == ["coupon at till"]
    assert rows[0]["incremental_sales_amt_exposed"] == pytest.approx(15.0)
    assert rows[0]["incremental_units_qty_exposed"] == pytest.approx(5.0)


def test_dtp_skips_fallback(spark_session, char_paths):
    # 120 >= 100 would trigger fallback, which can't run without a campaign period.
    with patch(f"{_MCR}.apply_period_fallback") as mock_fallback, patch(f"{_MCR}.get_fallback_metadata") as mock_metadata:
        rows = _run_char(
            spark_session, char_paths, [_char_integration_row(incremental_sales_amt_exposed=120.0)],
            unified_campaign_path=char_paths["unified_campaign"],
            fallback_metadata_path="s3://bucket/fallback_metadata.json",
        )

    mock_fallback.assert_not_called()
    assert mock_metadata.call_args.kwargs["needs_fallback"] is False
    assert rows == [pytest.approx(_char_output_row(
        run_type="DTP",
        incremental_sales_amt_exposed=120.0,
        base_sales_amt_exposed=-20.0,
        uplift_exposed_sales_amt=0.0,
        iroas_exposed=2.4,
    ))]


# During+Post volumes (sales, incremental, units, incremental units) per weighting and fallback case.
# During is 100/20 and 50/10 throughout, stored at weight 0.5 when weighted; the Post weight is 0.4.
_POST_RUN_VOLUMES = {
    # Post = 24 / (150 - 40) x 0.4 = 44: fallback.
    ("weighted", "fallback"): (260.0, 150.0, 130.0, 25.0),
    # Post = 20 / 40: fallback.
    ("unweighted", "fallback"): (120.0, 60.0, 60.0, 30.0),
    # Post = -10 / -5 and 0 / -5: floored.
    ("unweighted", "negative"): (90.0, 15.0, 50.0, 5.0),
}
_DURING_VOLUMES = {
    "attributed_recalibrated_sales_amt": 100.0,
    "incremental_sales_amt_exposed": 20.0,
    "attributed_recalibrated_units_qty": 50.0,
    "incremental_units_qty_exposed": 10.0,
}


def _run_post(spark_session, char_paths, weighting, fallback, **kwargs):
    """Run a Post booking with fallback at r = 0.3 and return its written rows by campaign_duration."""
    weighted = weighting == "weighted"
    _write_char_during(spark_session, char_paths["previous"], spend_weight=0.5 if weighted else 1.0)
    during_plus_post = _char_integration_row(
        campaign_duration="Post", **dict(zip(_DURING_VOLUMES, _POST_RUN_VOLUMES[(weighting, fallback)])),
    )
    weights = {"overlapping_campaign_spend_weights_path": char_paths["spend_weights"]} if weighted else {}

    with patch(
        "spark_pipeline.measurement_campaign_reporting.incrementality_fallback.compute_fallback_ratio",
        return_value=0.3,
    ):
        rows = _run_char(
            spark_session, char_paths, [during_plus_post],
            campaign_period="Post",
            previous_measurement_campaign_reporting=char_paths["previous"],
            **weights,
            **kwargs,
        )
    return {row["campaign_duration"]: row for row in rows}


def _assert_during_plus_post_additive(rows):
    for column, during in _DURING_VOLUMES.items():
        assert rows["During+Post"][column] == pytest.approx(during + rows["Post"][column])


def test_post_weighted_fallback_delta_matches_rebuild(spark_session, char_paths):
    rows = _run_post(spark_session, char_paths, "weighted", "fallback")

    # Post 24/44 and 12/2 fall back to 24 x 0.3 = 7.2 and 12 x 0.3 = 3.6.
    assert rows["Post"]["incremental_sales_amt_exposed"] == pytest.approx(7.2)
    assert rows["Post"]["incremental_units_qty_exposed"] == pytest.approx(3.6)
    # During+Post = d + Post_final: 20 + 7.2 and 10 + 3.6; attributed stays 100 + 24.
    assert rows["During+Post"]["incremental_sales_amt_exposed"] == pytest.approx(27.2)
    assert rows["During+Post"]["incremental_units_qty_exposed"] == pytest.approx(13.6)
    assert rows["During+Post"]["attributed_recalibrated_sales_amt"] == pytest.approx(124.0)
    _assert_during_plus_post_additive(rows)


def test_post_negative_incrementality_floored_and_rebuilt(spark_session, char_paths):
    with patch(f"{_MCR}.SlackMessenger") as mock_slack:
        rows = _run_post(spark_session, char_paths, "unweighted", "negative")
    messages = [c.kwargs for c in mock_slack.return_value.send_message.call_args_list]

    assert rows["Post"]["attributed_recalibrated_sales_amt"] == pytest.approx(-10.0)
    assert rows["Post"]["incremental_sales_amt_exposed"] == 0.0
    assert rows["Post"]["incremental_units_qty_exposed"] == 0.0
    # 15 + (0 - -5) and 5 + (0 - -5).
    assert rows["During+Post"]["incremental_sales_amt_exposed"] == pytest.approx(20.0)
    assert rows["During+Post"]["incremental_units_qty_exposed"] == pytest.approx(10.0)
    _assert_during_plus_post_additive(rows)
    assert len(messages) == 1


def _audit_frame(spark_session, rows, extra_fields):
    """Build an audit test frame with explicit key and metric types."""
    key_schema = [T.StructField(column_name, T.StringType()) for column_name in AUDIT_KEY_COLUMNS]
    keys = {column_name: column_name for column_name in AUDIT_KEY_COLUMNS}
    return spark_session.createDataFrame(
        [{**keys, **row} for row in rows],
        T.StructType(key_schema + extra_fields),
    )


def test_audit_row_count_unchanged_by_each_step(spark_session):
    """Two channels sharing the old nine keys stay two audit rows, each matched to its own channel."""
    # Arrange
    metric_fields = [
        T.StructField("incremental_sales_amt_exposed", T.DoubleType()),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType()),
    ]
    base = _audit_frame(
        spark_session,
        [
            {"channel_name": "Meta", "incremental_sales_amt_exposed": 10.0,
             "attributed_recalibrated_sales_amt": 100.0},
            {"channel_name": "Coupon at Till", "incremental_sales_amt_exposed": 20.0,
             "attributed_recalibrated_sales_amt": 200.0},
        ],
        metric_fields,
    )
    # The channel filter lowercases channel_name.
    processed = base.withColumn("channel_name", F.lower("channel_name"))

    # Act / Assert
    audit = base.select(AUDIT_KEY_COLUMNS)
    for prefix in ["integration", "overlap", "fallback"]:
        audit = add_to_reporting_audit(audit, processed, prefix)
        assert audit.count() == 2

    by_channel = {row["channel_name"]: row for row in audit.collect()}
    assert by_channel["Meta"]["fallback_incremental_sales_amt_exposed"] == 10.0
    assert by_channel["Coupon at Till"]["fallback_incremental_sales_amt_exposed"] == 20.0


def test_fallback_audit_adds_post_row_and_updates_during_plus_post(spark_session):
    """Fallback audit merges separated Post rows into the matching audit keys."""
    # Arrange
    base_audit = _audit_frame(
        spark_session,
        [{"campaign_duration": "During+Post", "channel_name": "Meta",
          "integration_incremental_sales_amt_exposed": 60.0}],
        [T.StructField("integration_incremental_sales_amt_exposed", T.DoubleType())],
    )
    metric_schema = [
        T.StructField("incremental_sales_amt_exposed", T.DoubleType()),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType()),
        T.StructField("incremental_units_qty_exposed", T.DoubleType()),
    ]
    pre_fallback_df = _audit_frame(
        spark_session,
        [
            {"campaign_duration": "Post", "channel_name": "meta",
             "incremental_sales_amt_exposed": 40.0,
             "attributed_recalibrated_sales_amt": 20.0, "incremental_units_qty_exposed": 20.0},
            {"campaign_duration": "During+Post", "channel_name": "meta",
             "incremental_sales_amt_exposed": 60.0,
             "attributed_recalibrated_sales_amt": 120.0, "incremental_units_qty_exposed": 30.0},
        ],
        metric_schema,
    )
    fallback_df = _audit_frame(
        spark_session,
        [
            {"campaign_duration": "Post", "channel_name": "meta",
             "incremental_sales_amt_exposed": 6.0,
             "attributed_recalibrated_sales_amt": 20.0, "incremental_units_qty_exposed": 3.0,
             "state": "published", "ratio": 0.3, "control_factor": None},
            {"campaign_duration": "During+Post", "channel_name": "meta",
             "incremental_sales_amt_exposed": 26.0,
             "attributed_recalibrated_sales_amt": 120.0, "incremental_units_qty_exposed": 13.0,
             "state": None, "ratio": None, "control_factor": None},
        ],
        metric_schema + [
            T.StructField("state", T.StringType()),
            T.StructField("ratio", T.DoubleType()),
            T.StructField("control_factor", T.DoubleType()),
        ],
    )

    # Act
    audit = add_fallback_audit(
        base_audit, pre_fallback_df, fallback_df, needs_fallback=True, floored=False
    )

    # Assert
    collected_rows = audit.collect()
    assert len(collected_rows) == 2
    rows = {row["campaign_duration"]: row for row in collected_rows}
    assert rows["During+Post"]["integration_incremental_sales_amt_exposed"] == 60.0
    assert rows["Post"]["pre_fallback_incremental_sales_amt_exposed"] == 40.0
    assert rows["Post"]["fallback_incremental_sales_amt_exposed"] == 6.0
    assert rows["Post"]["fallback_state"] == "published"
    assert rows["During+Post"]["pre_fallback_incremental_sales_amt_exposed"] == 60.0
    assert rows["During+Post"]["fallback_incremental_sales_amt_exposed"] == 26.0
    assert rows["Post"]["integration_incremental_sales_amt_exposed"] is None
    assert rows["Post"]["fallback_incremental_units_qty_exposed"] == 3.0
    assert rows["Post"]["fallback_ratio"] == 0.3
    assert rows["Post"]["fallback_floored"] is False
    assert rows["During+Post"]["fallback_floored"] is False
    assert rows["Post"]["fallback_is_fallback"] is True
    assert rows["During+Post"]["fallback_is_fallback"] is True


def test_fallback_audit_adds_typed_null_columns_without_fallback(spark_session):
    """Fallback audit columns exist as typed nulls when no fallback ran."""
    # Arrange
    metric_fields = [
        T.StructField("incremental_sales_amt_exposed", T.DoubleType()),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType()),
        T.StructField("incremental_units_qty_exposed", T.DoubleType()),
    ]
    processed_row = {
        "campaign_duration": "During",
        "incremental_sales_amt_exposed": 10.0,
        "attributed_recalibrated_sales_amt": 20.0,
        "incremental_units_qty_exposed": 5.0,
    }
    base_audit = _audit_frame(spark_session, [{"campaign_duration": "During"}], [])
    pre_fallback_df = _audit_frame(spark_session, [processed_row], metric_fields)
    fallback_df = _audit_frame(spark_session, [processed_row], metric_fields)

    # Act
    audit = add_fallback_audit(
        base_audit, pre_fallback_df, fallback_df, needs_fallback=False, floored=False
    )

    # Assert
    assert audit.schema["fallback_state"].dataType == T.StringType()
    assert audit.schema["fallback_control_factor"].dataType == T.DoubleType()
    assert audit.schema["fallback_ratio"].dataType == T.DoubleType()
    row = audit.first()
    assert row["fallback_state"] is None
    assert row["fallback_control_factor"] is None
    assert row["fallback_ratio"] is None
    assert row["fallback_is_fallback"] is False
