import datetime
import sys
from unittest import mock

from pyspark.sql import SparkSession


from spark_pipeline.utils.pipeline_utils import get_tz_date
from spark_pipeline.dv360_normalise.dv360_normalise_pollen import (
    entrypoint
)


def test_get_tz_date():
    assert get_tz_date(datetime.date(2022, 1, 1)) == "2022-01-01T00:00:00+00:00"
    assert get_tz_date(datetime.date(2022, 5, 1)) == "2022-05-01T00:00:00+01:00"


def test_entrypoint(spark_session: SparkSession):
    dv360_pollen_campaign = "dv360_pollen_campaign"
    output_path = "some_output_path"
    run_date = "2025-03-24"

    args = [
        "--dv360-pollen-campaign", dv360_pollen_campaign,
        "--output-path", output_path,
        "--run-date", run_date,
    ]

    with mock.patch(
        "spark_pipeline.dv360_normalise.dv360_normalise_pollen.normalize_dv360"
    ) as mock_fn:
        with mock.patch.object(sys, "argv", ["script", *args]):
            entrypoint(spark=spark_session)  # Using sys.argv
            mock_fn.assert_called_with(
                spark=spark_session,
                dv360_pollen_input_path=dv360_pollen_campaign,
                output_path=output_path,
                run_date=run_date,
            )
