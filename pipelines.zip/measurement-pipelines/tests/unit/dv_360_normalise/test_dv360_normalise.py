import datetime
import os
import sys
from unittest import mock
from chispa.dataframe_comparer import assert_df_equality

import pytest
from pyspark.sql import SparkSession, Row
import pyspark.sql.types as T

from spark_pipeline.utils.pipeline_utils import get_tz_date
from spark_pipeline.dv360_normalise.dv360_normalise import (
    entrypoint, normalize_dv360
)
from tests.unit.baseline_processed_data.utils import (
    local_spark_s3_overwrite
)


@pytest.fixture(scope="module")
def dv360_campaign(spark_session):
    dv360_data = [(
        """{
            "advertiserId": "61c332da1e97d40008cb6dce",
            "bidStrategy": {
                "fixedBid": {}
            },
            "brandId": "61d42c45b0c11a00088cfc83",
            "budget": {
                "automationType": "None",
                "budgetSegments": {
                    "budgetAmountMicros": "22275000000",
                    "dateRange": {
                        "endDate": {"day": 1,"month": 1,"year": 2026},
                        "startDate": {"day": 19,"month": 11,"year": 2025}
                    }
                },
                "budgetUnit": "Currency"
            },
            "displayName": "CCEP DV360 Campaign C13 and C14 | Coca Cola | 19112025 | nec25110022a",
            "entityStatus": "Active",
            "frequencyCap": {
                "unlimited":true
            },
            "integrationDetails": {
                "details":"JOB_BAG_ID",
                "jobBagId":"nec25110022a"
            },
            "kpi": {
                "kpiPercentageMicros": "700000",
                "kpiType": "Viewability"
            },
            "measurementSkus": ["8152008", "7751621", "3716243"],
            "pacing": {
                "pacingPeriod": "Flight",
                "pacingType": "Even"
            },
            "totalBillableSpend": "NaN",
            "totalBillableSpendMicros":"NaN"
        }""",
        datetime.date(2025, 11, 19),
        datetime.date(2026, 1, 1)),
        # this entry will be filtered out because of the test in displayName
        ("""{
            "displayName": "Test entry",
            "measurementSkus": ["9999999"],
            "integrationDetails": {
                "jobBagId":"nec25110025a"
            },
        }""",
         datetime.date(2025, 9, 5),
         datetime.date(2025, 11, 14)),
        # this entry will be filtered out because of the none in jonBagId
        ("""{
            "displayName": "Correct entry name",
            "measurementSkus": ["9999999"],
            "integrationDetails": {
                "jobBagId": none
            },
        }""",
         datetime.date(2025, 9, 5),
         datetime.date(2025, 11, 14)),
    ]
    dv360_schema = T.StructType([
        T.StructField("DTP_INPUT", T.StringType(), True),
        T.StructField("CAMPAIGN_START_DT", T.DateType(), True),
        T.StructField("CAMPAIGN_END_DT", T.DateType(), True),
    ])

    dv360_df = spark_session.createDataFrame(
        data=dv360_data,
        schema=dv360_schema
    )

    return dv360_df


def test_get_tz_date():
    assert get_tz_date(datetime.date(2022, 1, 1)) == "2022-01-01T00:00:00+00:00"
    assert get_tz_date(datetime.date(2022, 5, 1)) == "2022-05-01T00:00:00+01:00"


def test_entrypoint(spark_session: SparkSession):
    dv360_campaign = "dv360_campaign"
    output_path = "some_output_path"
    run_date = "2025-03-24"

    args = [
        "--dv360-campaign", dv360_campaign,
        "--output-path", output_path,
        "--run-date", run_date,
    ]

    with mock.patch(
        "spark_pipeline.dv360_normalise.dv360_normalise.normalize_dv360"
    ) as mock_fn:
        with mock.patch.object(sys, "argv", ["script", *args]):
            entrypoint(spark=spark_session)  # Using sys.argv
            mock_fn.assert_called_with(
                spark=spark_session,
                dv360_input_path=dv360_campaign,
                output_path=output_path,
                run_date=run_date,
            )


def test_dv360_output(spark_session, dv360_campaign, tmp_dir):
    # Write the test input DataFrame to a temporary Parquet file

    with mock.patch(
        "spark_pipeline.dv360_normalise.dv360_normalise.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        input_path = os.path.join(tmp_dir, "dv360_campaign.parquet")
        dv360_campaign.write.mode("overwrite").parquet(input_path)
        # Create an output path to store out results
        output_path = os.path.join(tmp_dir, "output")

        normalize_dv360(
            spark=spark_session,
            dv360_input_path=input_path,
            output_path=output_path,
            run_date="2026-01-01",
        )
        # Read back results
        actual_df = spark_session.read.parquet(output_path)

        expected_df = spark_session.createDataFrame([
            Row(
                START_DT=datetime.datetime(2025, 11, 19, 0, 0, 0),
                END_DT=datetime.datetime(2026, 1, 1, 0, 0, 0),
                ITEM_CD=item_cd,
                JOBBAGID="nec25110022a",
                CHANNEL="DV360",
            ) for item_cd in ["8152008", "7751621", "3716243"]
        ])

        assert_df_equality(expected_df, actual_df, ignore_row_order=True, ignore_column_order=False)
