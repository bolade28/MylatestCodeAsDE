# tests/unit/campaign_selection/mock_data_campaign_selection.py
from pyspark.sql import Row
from datetime import datetime, timedelta


def get_mock_dataframes(spark):
    # WEEKLY_DATES
    weekly_dates = [
        Row(WEEK_START_DT=datetime.strptime(d, "%Y-%m-%d"))
        for d in [
            '2024-03-04', '2024-02-26', '2024-02-19', '2024-02-12', '2024-02-05',
            '2024-01-29', '2024-01-22', '2024-01-15', '2024-01-08', '2024-01-01',
            '2023-12-25', '2023-12-18', '2023-12-11', '2023-12-04', '2023-11-27',
            '2023-11-20', '2023-11-13', '2023-11-06', '2023-10-30', '2023-10-23',
            '2023-10-16', '2023-10-09', '2023-10-02', '2023-09-25', '2023-09-18',
            '2023-09-11', '2023-09-04', '2023-08-28', '2023-08-21', '2023-08-14',
            '2023-08-07', '2023-07-31', '2023-07-24', '2023-07-17', '2023-07-10',
            '2023-07-03', '2023-06-26', '2023-06-19', '2023-06-12', '2023-06-05',
            '2023-05-29', '2023-05-22', '2023-05-15', '2023-05-08', '2023-05-01',
            '2023-04-24', '2023-04-17', '2023-04-10', '2023-04-03', '2023-03-27',
            '2023-03-20', '2023-03-13', '2023-03-06', '2023-02-27', '2023-02-20',
            '2023-02-13', '2023-02-06', '2023-01-30', '2023-01-23', '2023-01-16',
            '2023-01-09', '2023-01-02', '2022-12-26', '2022-12-19', '2022-12-12',
            '2022-12-05', '2022-11-28', '2022-11-21', '2022-11-14', '2022-11-07',
            '2022-10-31', '2022-10-24', '2022-10-17', '2022-10-10', '2022-10-03',
            '2022-09-26', '2022-09-19', '2022-09-12', '2022-09-05', '2022-08-29',
            '2022-08-22', '2022-08-15', '2022-08-08', '2022-08-01', '2022-07-25',
            '2022-07-18', '2022-07-11', '2022-07-04', '2022-06-27', '2022-06-20',
            '2022-06-13', '2022-06-06', '2022-05-30', '2022-05-23', '2022-05-16',
            '2022-05-09', '2022-05-02', '2022-04-25', '2022-04-18', '2022-04-11',
            '2022-04-04', '2022-03-28', '2022-03-21', '2022-03-14'
        ]
    ]
    weekly_dates_df = spark.createDataFrame(weekly_dates)

    # Generate 60 weeks of dates ending on 2024-03-04
    def get_week_dates(n, end_date="2024-03-04"):
        end = datetime.strptime(end_date, "%Y-%m-%d")
        return [(end - timedelta(weeks=i)).strftime("%Y-%m-%d") for i in reversed(range(n))]

    weeks = get_week_dates(60)

    sales_data = {
        'ITEM_CD': (
            [7991238] +  # New launch, 1 week
            [7991239] * 60 +  # Proxy 1, 60 weeks
            [8991238] +  # New launch, 1 week
            [7991240] * 60  # Proxy 2, 60 weeks
        ),
        'UNIQUE_BRAND_NAME': (
            ['WALKERS|PEPSICO INC 1'] + ['WALKERS|PEPSICO INC 2'] * 60 +
            ['BAILEYS|DIAGEO'] + ['DOVE|UNILEVER'] * 60
        ),
        'SUPER_CATEGORY_NAME': (
            ['CRISPS & SNACKS 1'] + ['CRISPS & SNACKS'] * 60 +
            ['DAIRY'] + ['DAIRY'] * 60
        ),
        'WEEK_START_DT': (
            ['2024-03-04'] + weeks +
            ['2024-03-04'] + weeks
        ),
        'TOTAL_SALES_AMT': (
            [289.91] + [1000] * 60 +
            [289.91] + [1000] * 60
        )
    }

    sales_data_rows = [
        Row(
            ITEM_CD=int(sales_data['ITEM_CD'][i]),
            UNIQUE_BRAND_NAME=sales_data['UNIQUE_BRAND_NAME'][i],
            SUPER_CATEGORY_NAME=sales_data['SUPER_CATEGORY_NAME'][i],
            WEEK_START_DT=datetime.strptime(sales_data['WEEK_START_DT'][i], "%Y-%m-%d"),
            TOTAL_SALES_AMT=float(sales_data['TOTAL_SALES_AMT'][i])
        )
        for i in range(len(sales_data['ITEM_CD']))
    ]
    sales_data_df = spark.createDataFrame(sales_data_rows)

    # unified_campaign
    unified_campaign_rows = [
        Row(
            JOB_BAG_NUMBER=jb,
            CAMPAIGN_ID=cid,
            MEDIA_SPEND_AMT=float(ms),
            CAMPAIGN_START_DT=datetime.strptime(cs_dt, "%Y-%m-%d"),
            CAMPAIGN_END_DT=datetime.strptime(ce, "%Y-%m-%d"),
            SUBCHANNEL_NAME=subch,
            ITEM_CD_LIST=iclist,
            SUPER_CATEGORY_NAME=scn,
            SUB_CATEGORY_NAME=subcat,
            CHANNEL_NAME=chn,
            CAMPAIGN_NAME=cn,
            BOOKING_ID=bid,
            CAMPAIGN_STATUS=cs_status,
            IS_MULTI_CHANNEL=bool(imc),
            LOAD_TS=datetime.strptime(lt, "%Y-%m-%d %H:%M:%S.%f"),
            JOB_RUN_ID=jri,
            UNIQUE_BRAND_NAME=ubn,
            MARKETING_TYPE=mt,
            MARKETING_HIERARCHY_CD=mhcd,
            POST_CAMPAIGN_DT=datetime.strptime(pcd, "%Y-%m-%d")
        )
        for jb, cid, ms, cs_dt, ce, subch, iclist, scn, subcat, chn, cn, bid, cs_status, imc, lt, jri, ubn, mt, mhcd, pcd in
        zip(
            ['nec2302065a', 'nec2302065a', 'test'],
            ['6fddb710-ae7a-4a8f-b943-77c7836649cc1', '8973504a-ebba-41a2-affc-24c77d8f1912', 'test'],
            ['257.4', '272.987603', '0.0'],
            ['2024-02-28', '2024-07-10', '2024-07-10'],
            ['2025-05-04', '2025-06-04', '2025-06-04'],
            ['NA', 'Search', 'NA'],
            ['8053911,8053918,8053920,8173025', '2444888,6779638', '0'],
            ['Healthier Spreads', 'Everyday Sharing C/S', 'test'],
            ['Healthier Spreads', 'Everyday Sharing C/S', 'test'],
            ['Onsite-GOL', 'Secondary Space', 'Onsite-GOL'],
            ['Feb Search', 'Bertolli browse', 'Search below Grid'],
            ['3de4f71c-dff4-4f55-86db-17311b8503a9', '410a5e34-f785-4251-b8c0-5ce8e81db807', 'test'],
            [None, None, 'Approved'],
            [True, True, False],
            ['2025-02-06 05:24:35.234', '2025-02-06 05:24:35.234', '2025-02-06 05:24:35.234'],
            ['cf7df93f-484e-4dd4-91f1-9303b5a50780', 'cf7df93f-484e-4dd4-91f1-9303b5a50780', 'test'],
            ['WALKERS|PEPSICO INC 1', 'BAILEYS|DIAGEO', 'test'],
            ['Onsite', 'Onsite', 'Onsite'],
            [20, 20, 20],
            ['2024-04-16', '2023-08-28', '2023-08-28']
        )
    ]
    unified_campaign_df = spark.createDataFrame(unified_campaign_rows)

    # campaign_product_type
    campaign_product_type_rows = [
        Row(
            ITEM_CD=ic,
            PRODUCT_TYPE=pt,
            CHANNEL_NAME=chn,
            SUBCHANNEL_NAME=subch,
            CAMPAIGN_ID=cid,
            BOOKING_ID=bid,
            JOB_RUN_ID=jri,
            SKU_NAME=sku,
            SUB_CAT_NAME=subcat,
            BRAND_NAME=bn,
            LOAD_TS=datetime.strptime(lt, "%Y-%m-%d %H:%M:%S.%f"),
            UNIQUE_BRAND_NAME=ubn,
            BRAND_OWNER_NAME=bon
        )
        for ic, pt, chn, subch, cid, bid, jri, sku, subcat, bn, lt, ubn, bon in zip(
            [7991238, 8991238],
            ['Aisle', 'Brand'],
            ['Onsite-GOL', 'Secondary Space'],
            ['NA', 'Search'],
            ['6fddb710-ae7a-4a8f-b943-77c7836649cc1', '8973504a-ebba-41a2-affc-24c77d8f1912'],
            ['86dde109-dba2-4c37-b972-55291c70e050', 'a4e15c62-63bf-490d-aeaf-89d9db4706ed'],
            ['1cdf0df6-ec5a-4482-b0d9-61398b4824bf', '1cdf0df6-ec5a-4482-b0d9-61398b4824bf'],
            ['Flora Plant Butter Garlic Block 125g', 'Doritos stax mexican chilli 170g'],
            ['Healthier Spreads', 'Everyday Sharing C/S'],
            ['WALKERS', 'BAILEYS'],
            ['2025-02-06 05:24:35.234', '2025-02-06 05:24:35.234'],
            ['WALKERS|PEPSICO INC 1', 'BAILEYS|DIAGEO'],
            ['PEPSICO INC', 'DIAGEO']
        )
    ]
    campaign_product_type_df = spark.createDataFrame(campaign_product_type_rows)

    # UNIFIED_PRODUCT
    unified_product_rows = [
        Row(
            ITEM_CD=ic,
            SUPER_CAT_NAME=scn,
            SUB_CAT_NAME=sub_cn,
            UNIQUE_BRAND_NAME=ubn
        )
        for ic, scn, sub_cn, ubn in zip(
            [7991238, 8991238],
            ['CRISPS & SNACKS 1', 'DAIRY'],
            ['Everyday Sharing C/S', 'Everyday Sharing C/S'],
            ['WALKERS|PEPSICO INC 1', 'BAILEYS|DIAGEO']
        )
    ]
    unified_product_df = spark.createDataFrame(unified_product_rows)

    # DIM_ITEM_HIST
    dim_item_hist_rows = [
        Row(
            ITEM_CD=7991238,
            VALID_FROM_DT=datetime.strptime('2024-01-04', "%Y-%m-%d"),
            VALID_UNTIL_DT=datetime.strptime('2024-02-04', "%Y-%m-%d"),
            SUPER_CAT_NAME='CRISPS & SNACKS'
        )
    ]
    dim_item_hist_df = spark.createDataFrame(dim_item_hist_rows)

    # ITEM_BRAND_HIST - per-item brand/category, replaces campaign_product_type + UNIFIED_PRODUCT
    item_brand_hist_rows = [
        Row(
            ITEM_CD=ic,
            UNIQUE_BRAND_NAME=ubn,
            SUPER_CAT_NAME=scn,
            SUB_CAT_NAME=sub_cn,
        )
        for ic, ubn, scn, sub_cn in zip(
            [8053911, 8053918, 8053920, 8173025, 2444888, 6779638],
            ['WALKERS|PEPSICO INC 1'] * 4 + ['BAILEYS|DIAGEO'] * 2,
            ['CRISPS & SNACKS 1'] * 4 + ['DAIRY'] * 2,
            ['Healthier Spreads'] * 4 + ['Everyday Sharing C/S'] * 2,
        )
    ]
    item_brand_hist_df = spark.createDataFrame(item_brand_hist_rows)

    return {
        "WEEKLY_DATES": weekly_dates_df,
        "sales_data_transformation_output": sales_data_df,
        "unified_campaign": unified_campaign_df,
        "campaign_product_type": campaign_product_type_df,
        "UNIFIED_PRODUCT": unified_product_df,
        "DIM_ITEM_HIST": dim_item_hist_df,
        "ITEM_BRAND_HIST": item_brand_hist_df,
    }
