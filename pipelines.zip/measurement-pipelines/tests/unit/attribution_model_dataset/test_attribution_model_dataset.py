import os
from datetime import datetime, date
from decimal import Decimal
from unittest.mock import Mock, patch

import pytest
from pyspark.sql import Row

from spark_pipeline.attribution_model_dataset.attribution_model_dataset import (
    process_attribution_model_dataset,
    entrypoint,
)
from spark_pipeline.common.variables import PipelineRunType
from spark_pipeline.schemas.attribution_model_dataset import AttributionModelDatasetSchema
from spark_pipeline.schemas.campaign_decay_rate import CampaignDecayType

PIPELINE_RUN_TYPE = PipelineRunType()


def _write_measurement(spark, path):
    data = [
        Row(
            campaign_id="camp_001",
            booking_id="booking_123",
            job_bag_number="bag_001",
            marketing_type="email_marketing",
            channel_name="email",
            subchannel_name="newsletter",
            campaign_name="Test Campaign",
            campaign_start_dt=date(2024, 1, 1),
            campaign_end_dt=date(2024, 1, 31),
            campaign_duration="30-days",
            job_status="In-progress",
            load_ts=datetime(2024, 1, 1, 12, 0, 0),
            job_run_id="job_001",
        )
    ]
    spark.createDataFrame(data, AttributionModelDatasetSchema.measurement_campaign_execution_schema).write.mode("overwrite").parquet(path)


def _write_attribution(spark, path, n=100):
    data = [
        Row(
            loyalty_id=f"user_{i:03d}",
            channel_name="email",
            subchannel_name="newsletter",
            event_ts=datetime(2024, 1, 15, 10, 0, 0),
            event_name="Touchpoint",
            net_sales_amt=Decimal("100.50"),
            journey_type="Brand",
            transaction_key=f"tx_{i:03d}",
            campaign_id="camp_001",
            booking_id="booking_123",
            position="1",
            campaign_duration="30-days",
            load_ts=datetime(2024, 1, 1, 12, 0, 0),
            job_run_id="job_001",
            userjourney_id=f"journey_{i:03d}",
            regression_variable="email_marketing_email_newsletter_camp_001",
            customer_journey_type="Non-direct",
            isconversion=1 if i < 60 else 0,
            marketing_type="email_marketing",
        )
        for i in range(n)
    ]
    spark.createDataFrame(data, AttributionModelDatasetSchema.attribution_prerequisite_schema).write.mode("overwrite").parquet(path)


def _write_empty_decay(spark, path, is_dtp=True):
    schema = (
        CampaignDecayType.campaign_decay_rate_dtp_schema
        if is_dtp
        else CampaignDecayType.campaign_decay_rate_pollen_schema
    )
    spark.createDataFrame([], schema).write.mode("overwrite").parquet(path)


class TestRunAttributionModelDataset:

    def test_raises_on_invalid_pipeline_run_type(self, spark_session):
        with pytest.raises(ValueError, match="Unknown pipeline_run_type"):
            process_attribution_model_dataset(
                spark=spark_session,
                measurement_campaign_path="x",
                attribution_prerequisite_path="x",
                campaign_decay_path="x",
                journey_channel_metadata_path="x",
                attribution_model_dataset_flattened_path="x",
                job_run_id="job",
                slack_topic_arn="arn",
                journey_type="brand",
                pipeline_run_type="invalid_type",
            )

    def test_writes_channel_mapping_and_flattened_output(self, spark_session, tmp_dir):
        measurement_path = os.path.join(tmp_dir, "measurement.parquet")
        attribution_path = os.path.join(tmp_dir, "attribution.parquet")
        decay_path = os.path.join(tmp_dir, "decay.parquet")
        journey_channel_metadata_path = os.path.join(tmp_dir, "journey_channel_metadata.parquet")
        output_path = os.path.join(tmp_dir, "output.parquet")

        _write_measurement(spark_session, measurement_path)
        _write_attribution(spark_session, attribution_path)
        _write_empty_decay(spark_session, decay_path, is_dtp=False)

        with patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.preprocess_all_campaigns"
        ) as mock_pre, patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.pivot_regression_variables_all_campaigns"
        ) as mock_pivot, patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.apply_decay_rates_for_offsite_campaigns"
        ) as mock_decay, patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.flatten_journey_paths_all_campaigns"
        ) as mock_flatten, patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.AttributionSlackNotifier"
        ) as mock_notifier, patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.spark_s3_overwrite"
        ) as mock_s3_write:

            # Pass DataFrames through unchanged so writes have real data
            mock_pre.side_effect = lambda df: df
            mock_pivot.side_effect = lambda df, *a, **kw: df
            mock_decay.side_effect = lambda df, *a, **kw: df
            mock_flatten.side_effect = lambda df, *a, **kw: df
            mock_notifier.return_value = Mock()

            def fake_s3_write(path, df):
                df.write.mode("overwrite").parquet(path)

            mock_s3_write.side_effect = fake_s3_write

            process_attribution_model_dataset(
                spark=spark_session,
                measurement_campaign_path=measurement_path,
                attribution_prerequisite_path=attribution_path,
                campaign_decay_path=decay_path,
                journey_channel_metadata_path=journey_channel_metadata_path,
                attribution_model_dataset_flattened_path=output_path,
                job_run_id="test_job",
                slack_topic_arn="test_arn",
                journey_type="brand",
                pipeline_run_type=PIPELINE_RUN_TYPE.pollen_run_type,
            )

            journey_channel_metadata_df = spark_session.read.parquet(journey_channel_metadata_path)
            assert journey_channel_metadata_df.count() > 0
            for col in AttributionModelDatasetSchema.columns(AttributionModelDatasetSchema.journey_channel_metadata_schema):
                assert col in journey_channel_metadata_df.columns

            output_df = spark_session.read.parquet(output_path)
            assert output_df.count() > 0

    def test_no_data_sends_slack_and_raises(self, spark_session, tmp_dir):
        """Empty measurement data should trigger Slack notification and raise RuntimeError."""
        measurement_path = os.path.join(tmp_dir, "measurement.parquet")
        attribution_path = os.path.join(tmp_dir, "attribution.parquet")
        decay_path = os.path.join(tmp_dir, "decay.parquet")
        journey_channel_metadata_path = os.path.join(tmp_dir, "journey_channel_metadata.parquet")
        output_path = os.path.join(tmp_dir, "output.parquet")

        spark_session.createDataFrame(
            [], AttributionModelDatasetSchema.measurement_campaign_execution_schema
        ).write.mode("overwrite").parquet(measurement_path)
        _write_attribution(spark_session, attribution_path, n=5)
        _write_empty_decay(spark_session, decay_path)

        mock_notifier_instance = Mock()
        with patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.AttributionSlackNotifier",
            return_value=mock_notifier_instance,
        ):
            with pytest.raises(RuntimeError, match="No data found to execute the ETL!"):
                process_attribution_model_dataset(
                    spark=spark_session,
                    measurement_campaign_path=measurement_path,
                    attribution_prerequisite_path=attribution_path,
                    campaign_decay_path=decay_path,
                    journey_channel_metadata_path=journey_channel_metadata_path,
                    attribution_model_dataset_flattened_path=output_path,
                    job_run_id="test_job",
                    slack_topic_arn="test_arn",
                    journey_type="brand",
                    pipeline_run_type=PIPELINE_RUN_TYPE.dtp_run_type,
                )

        mock_notifier_instance.send_no_data_error.assert_called_once()

    def test_decay_fallback_on_missing_path(self, spark_session, tmp_dir):
        """Missing decay path should use empty fallback schema without crashing."""
        measurement_path = os.path.join(tmp_dir, "measurement.parquet")
        attribution_path = os.path.join(tmp_dir, "attribution.parquet")
        journey_channel_metadata_path = os.path.join(tmp_dir, "journey_channel_metadata.parquet")
        output_path = os.path.join(tmp_dir, "output.parquet")

        _write_measurement(spark_session, measurement_path)
        _write_attribution(spark_session, attribution_path)

        with patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.preprocess_all_campaigns"
        ) as mock_pre, patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.pivot_regression_variables_all_campaigns"
        ) as mock_pivot, patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.apply_decay_rates_for_offsite_campaigns"
        ) as mock_decay, patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.flatten_journey_paths_all_campaigns"
        ) as mock_flatten, patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.AttributionSlackNotifier"
        ) as mock_notifier, patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.spark_s3_overwrite"
        ) as mock_s3_write:

            mock_pre.side_effect = lambda df: df
            mock_pivot.side_effect = lambda df, *a, **kw: df
            mock_decay.side_effect = lambda df, *a, **kw: df
            mock_flatten.side_effect = lambda df, *a, **kw: df
            mock_notifier.return_value = Mock()
            mock_s3_write.return_value = None

            # nonexistent decay path — should use fallback empty DataFrame
            process_attribution_model_dataset(
                spark=spark_session,
                measurement_campaign_path=measurement_path,
                attribution_prerequisite_path=attribution_path,
                campaign_decay_path="/nonexistent/decay",
                journey_channel_metadata_path=journey_channel_metadata_path,
                attribution_model_dataset_flattened_path=output_path,
                job_run_id="test_job",
                slack_topic_arn="test_arn",
                journey_type="brand",
                pipeline_run_type=PIPELINE_RUN_TYPE.pollen_run_type,
            )

            # apply_decay was called with an empty decay df (fallback)
            decay_df_arg = mock_decay.call_args[0][1]
            assert decay_df_arg.count() == 0


class TestAttributionModelDatasetEntrypoint:

    def test_entrypoint_calls_run_with_correct_args(self):
        mock_spark = Mock()
        args = [
            "--measurement-campaign-path", "s3://measurement",
            "--attribution-prerequisite-path", "s3://attribution",
            "--campaign-decay-path", "s3://decay",
            "--journey-channel-metadata-path", "s3://journey_channel_metadata",
            "--attribution-model-dataset-flattened-path", "s3://output",
            "--journey-type", "brand",
            "--job-run-id", "job_001",
            "--slack-topic-arn", "arn:aws:sns:test",
            "--pipeline-run-type", PIPELINE_RUN_TYPE.pollen_run_type,
        ]

        with patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.process_attribution_model_dataset"
        ) as mock_run:
            entrypoint(spark=mock_spark, command_line_args=args)

            mock_run.assert_called_once_with(
                spark=mock_spark,
                measurement_campaign_path="s3://measurement",
                attribution_prerequisite_path="s3://attribution",
                campaign_decay_path="s3://decay",
                journey_channel_metadata_path="s3://journey_channel_metadata",
                attribution_model_dataset_flattened_path="s3://output",
                job_run_id="job_001",
                slack_topic_arn="arn:aws:sns:test",
                journey_type="brand",
                pipeline_run_type=PIPELINE_RUN_TYPE.pollen_run_type,
            )

    def test_entrypoint_dtp_run_type(self):
        mock_spark = Mock()
        args = [
            "--measurement-campaign-path", "s3://measurement",
            "--attribution-prerequisite-path", "s3://attribution",
            "--campaign-decay-path", "s3://decay",
            "--journey-channel-metadata-path", "s3://journey_channel_metadata",
            "--attribution-model-dataset-flattened-path", "s3://output",
            "--journey-type", "offer",
            "--job-run-id", "job_dtp",
            "--slack-topic-arn", "arn:aws:sns:test",
            "--pipeline-run-type", PIPELINE_RUN_TYPE.dtp_run_type,
        ]

        with patch(
            "spark_pipeline.attribution_model_dataset.attribution_model_dataset.process_attribution_model_dataset"
        ) as mock_run:
            entrypoint(spark=mock_spark, command_line_args=args)

            call_kwargs = mock_run.call_args[1]
            assert call_kwargs["pipeline_run_type"] == PIPELINE_RUN_TYPE.dtp_run_type
            assert call_kwargs["journey_type"] == "offer"
