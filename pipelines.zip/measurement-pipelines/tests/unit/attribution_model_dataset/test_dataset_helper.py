import pytest
from unittest.mock import Mock
from pyspark.sql import types as T

from spark_pipeline.attribution_model_dataset.dataset_helper import (
    nest_journeys_by_loyalty_id,
    get_all_campaigns_stats,
)
from spark_pipeline.schemas.attribution_model_dataset import AttributionModelDatasetSchema


_STATIC_JOURNEY_COLS = [
    "userjourney_id",
    "loyalty_id",
    "transaction_key",
    "booking_id",
    "customer_journey_type",
    "journey_type",
    "campaign_duration",
    "isconversion",
]

_INPUT_SCHEMA = T.StructType([
    T.StructField("userjourney_id", T.StringType(), nullable=True),
    T.StructField("loyalty_id", T.StringType(), nullable=True),
    T.StructField("transaction_key", T.StringType(), nullable=True),
    T.StructField("booking_id", T.StringType(), nullable=True),
    T.StructField("customer_journey_type", T.StringType(), nullable=True),
    T.StructField("journey_type", T.StringType(), nullable=True),
    T.StructField("campaign_duration", T.StringType(), nullable=True),
    T.StructField("isconversion", T.IntegerType(), nullable=True),
    T.StructField("email_newsletter", T.DoubleType(), nullable=True),
    T.StructField("dv360_banner", T.DoubleType(), nullable=True),
])


class TestNestJourneysByLoyaltyId:

    def test_groups_multiple_journeys_for_same_loyalty_id(self, spark_session):
        input_data = [
            ("journey_001", "user_001", "tx_001", "booking_123", "Non-direct", "Brand", "30-days", 1, 1.0, 0.0),
            ("journey_002", "user_001", "tx_002", "booking_123", "Non-direct", "Brand", "30-days", 1, 0.0, 1.0),
        ]
        input_df = spark_session.createDataFrame(input_data, _INPUT_SCHEMA)

        result = nest_journeys_by_loyalty_id(
            input_df, AttributionModelDatasetSchema.journey_schema, _STATIC_JOURNEY_COLS
        )

        assert result.count() == 1
        row = result.collect()[0]
        assert row["loyalty_id"] == "user_001"
        assert len(row["user_journeys"]) == 2

    def test_separate_rows_for_different_loyalty_ids(self, spark_session):
        input_data = [
            ("journey_001", "user_001", "tx_001", "booking_123", "Non-direct", "Brand", "30-days", 1, 1.0, 0.0),
            ("journey_002", "user_002", "tx_002", "booking_456", "Non-direct", "Brand", "30-days", 0, 0.0, 1.0),
        ]
        input_df = spark_session.createDataFrame(input_data, _INPUT_SCHEMA)

        result = nest_journeys_by_loyalty_id(
            input_df, AttributionModelDatasetSchema.journey_schema, _STATIC_JOURNEY_COLS
        )

        assert result.count() == 2
        loyalty_ids = {row["loyalty_id"] for row in result.collect()}
        assert loyalty_ids == {"user_001", "user_002"}

    def test_regression_variables_nested_as_name_value_structs(self, spark_session):
        input_data = [
            ("journey_001", "user_001", "tx_001", "booking_123", "Non-direct", "Brand", "30-days", 1, 2.0, 3.0),
        ]
        input_df = spark_session.createDataFrame(input_data, _INPUT_SCHEMA)

        result = nest_journeys_by_loyalty_id(
            input_df, AttributionModelDatasetSchema.journey_schema, _STATIC_JOURNEY_COLS
        )

        journey = result.collect()[0]["user_journeys"][0]
        regression_vars = {rv["name"]: rv["value"] for rv in journey["regression_variables"]}
        assert regression_vars["email_newsletter"] == 2.0
        assert regression_vars["dv360_banner"] == 3.0

    def test_output_schema_matches_attribution_model_dataset_schema(self, spark_session):
        input_data = [
            ("journey_001", "user_001", "tx_001", "booking_123", "Non-direct", "Brand", "30-days", 1, 1.0, 0.0),
        ]
        input_df = spark_session.createDataFrame(input_data, _INPUT_SCHEMA)

        result = nest_journeys_by_loyalty_id(
            input_df, AttributionModelDatasetSchema.journey_schema, _STATIC_JOURNEY_COLS
        )

        expected_top_level_fields = {f.name for f in AttributionModelDatasetSchema.attribution_model_dataset_schema.fields}
        assert set(result.columns) == expected_top_level_fields


_STATS_INPUT_SCHEMA = T.StructType([
    T.StructField("userjourney_id", T.StringType(), nullable=True),
    T.StructField("booking_id", T.StringType(), nullable=True),
    T.StructField("campaign_duration", T.StringType(), nullable=True),
    T.StructField("isconversion", T.IntegerType(), nullable=True),
])


class TestGetAllCampaignsStats:

    def test_returns_stats_for_each_campaign(self, spark_session):
        data = [
            ("j001", "booking_a", "30-days", 1),
            ("j002", "booking_a", "30-days", 1),
            ("j003", "booking_a", "30-days", 0),
        ]
        df = spark_session.createDataFrame(data, _STATS_INPUT_SCHEMA)
        slack_notifier = Mock()

        result = get_all_campaigns_stats(df, 1, slack_notifier)

        row = result.collect()[0]
        assert row["booking_id"] == "booking_a"
        assert row["total_conversions"] == 2
        assert row["total_nonconversions"] == 1
        assert row["total_journeys"] == 3

    def test_sends_alert_but_does_not_raise_for_insufficient_conversions(self, spark_session):
        data = [
            ("j001", "booking_low", "30-days", 1),  # only 1 conversion, below limit of 5
            ("j002", "booking_low", "30-days", 0),
        ]
        df = spark_session.createDataFrame(data, _STATS_INPUT_SCHEMA)
        slack_notifier = Mock()

        # Should not raise
        result = get_all_campaigns_stats(df, 5, slack_notifier)

        assert result.count() == 1
        slack_notifier.send_campaign_no_data_error.assert_called_once_with(
            "booking_low",
            pytest.approx("Insufficient conversions (1) for campaign booking_low, minimum required: 5. Proceeding with lift model.", rel=0),
        )

    def test_no_alert_when_conversions_meet_limit(self, spark_session):
        data = [
            ("j001", "booking_ok", "30-days", 1),
            ("j002", "booking_ok", "30-days", 1),
            ("j003", "booking_ok", "30-days", 0),
        ]
        df = spark_session.createDataFrame(data, _STATS_INPUT_SCHEMA)
        slack_notifier = Mock()

        get_all_campaigns_stats(df, 2, slack_notifier)

        slack_notifier.send_campaign_no_data_error.assert_not_called()

    def test_sends_alert_per_failing_campaign(self, spark_session):
        data = [
            ("j001", "booking_ok", "30-days", 1),
            ("j002", "booking_ok", "30-days", 1),
            ("j003", "booking_low_a", "30-days", 1),  # 1 conversion
            ("j004", "booking_low_b", "30-days", 1),  # 1 conversion
        ]
        df = spark_session.createDataFrame(data, _STATS_INPUT_SCHEMA)
        slack_notifier = Mock()

        result = get_all_campaigns_stats(df, 2, slack_notifier)

        assert result.count() == 3
        assert slack_notifier.send_campaign_no_data_error.call_count == 2
        alerted_ids = {call.args[0] for call in slack_notifier.send_campaign_no_data_error.call_args_list}
        assert alerted_ids == {"booking_low_a", "booking_low_b"}
