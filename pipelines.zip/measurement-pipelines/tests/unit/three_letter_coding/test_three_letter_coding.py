import os
from unittest import mock
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from spark_pipeline.three_letter_coding.three_letter_coding import (
    create_three_letter_coding,
    entrypoint,
)
from spark_pipeline.schemas.three_letter_coding import ThreeLetterCoding
from tests.unit.baseline_processed_data.utils import (
    local_spark_s3_overwrite
)


def test_create_three_letter_coding_no_baseline(spark_session: SparkSession, tmpdir: str):
    """Test three-letter coding creation when no baseline dataset exists"""
    # Setup file paths
    channel_processed_data_path = os.path.join(tmpdir, "channel_processed_data.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")

    # Test data constants
    super_category = "Electronics"
    unique_brand = "Samsung"
    cluster_num = "CL001"
    marketing_type = "OFFSITE"
    marketing_channel = "YOUTUBE"
    marketing_sub_channel = "TOTAL"
    metric_name = "impressions"

    # Create channel processed data with lowercase column names
    channel_data = [
        {
            "super_category_name": super_category,
            "unique_brand_name": unique_brand,
            "cluster_num": cluster_num,
            "marketing_type_name": marketing_type,
            "marketing_channel_name": marketing_channel,
            "marketing_sub_channel_name": marketing_sub_channel,
            "metric_name": metric_name,
            "week_start_dt": "2024-01-01",
            "metric_value": 1000.0,
            "load_ts": datetime(2024, 1, 1, 10, 0, 0),
            "job_run_id": "test-job-001"
        }
    ]

    channel_df = spark_session.createDataFrame(channel_data)
    channel_df.write.mode("overwrite").parquet(channel_processed_data_path)

    with mock.patch(
        "spark_pipeline.three_letter_coding.three_letter_coding.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        # Run the function without baseline
        create_three_letter_coding(
            spark=spark_session,
            channel_processed_data_path=channel_processed_data_path,
            baseline_modelling_dataset_path=None,
            output_path=output_path,
            run_date="2024-01-01",
            correlation_id="test-corr-id"
        )

        # Verify the output
        actual_df = spark_session.read.parquet(output_path)

        # Basic validations
        assert actual_df.count() > 0, "Output should not be empty"

        # Check expected columns
        expected_columns = {"column_name", "original_column_value", "final_code"}
        assert set(actual_df.columns) == expected_columns, f"Column mismatch. Expected: {expected_columns}, Got: {set(actual_df.columns)}"

        # Check that all expected column types are present
        column_names = {row.column_name for row in actual_df.select("column_name").distinct().collect()}
        expected_column_names = {
            "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM",
            "MARKETING_TYPE_NAME", "MARKETING_CHANNEL_NAME", "MARKETING_SUB_CHANNEL_NAME", "METRIC_NAME"
        }
        assert column_names == expected_column_names, f"Expected column names: {expected_column_names}, Got: {column_names}"

        # Check specific three-letter codes
        electronics_row = actual_df.filter(
            (F.col("column_name") == "SUPER_CATEGORY_NAME") &
            (F.col("original_column_value") == super_category)
        ).collect()[0]
        assert electronics_row.final_code == "ELE", f"Expected 'ELE' for Electronics, got {electronics_row.final_code}"

        samsung_row = actual_df.filter(
            (F.col("column_name") == "UNIQUE_BRAND_NAME") &
            (F.col("original_column_value") == unique_brand)
        ).collect()[0]
        assert samsung_row.final_code == "SAM", f"Expected 'SAM' for Samsung, got {samsung_row.final_code}"

        print(f"No baseline test passed! Generated {actual_df.count()} rows")


def test_create_three_letter_coding_with_baseline(spark_session: SparkSession, tmpdir: str):
    """Test three-letter coding when baseline dataset exists"""
    # Setup file paths
    channel_processed_data_path = os.path.join(tmpdir, "channel_processed_data.parquet")
    baseline_modelling_dataset_path = os.path.join(tmpdir, "baseline_modelling_dataset.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")

    # Create channel processed data with lowercase column names
    channel_data = [
        {
            "super_category_name": "Electronics",
            "unique_brand_name": "Samsung",
            "cluster_num": "CL001",
            "marketing_type_name": "OFFSITE",
            "marketing_channel_name": "YOUTUBE",
            "marketing_sub_channel_name": "TOTAL",
            "metric_name": "impressions",
            "week_start_dt": "2024-01-01",
            "metric_value": 1000.0,
            "load_ts": datetime(2024, 1, 1, 10, 0, 0),
            "job_run_id": "test-job-001"
        }
    ]

    channel_df = spark_session.createDataFrame(channel_data)
    channel_df.write.mode("overwrite").parquet(channel_processed_data_path)

    # Create baseline dataset with uppercase column names
    baseline_data = [
        {
            "SUPER_CATEGORY_NAME": "Electronics",
            "UNIQUE_BRAND_NAME": "Samsung",
            "CLUSTER_NUM": "CL001",
            "MARKETING_TYPE_NAME": "OFFSITE",
            "MARKETING_CHANNEL_NAME": "YOUTUBE",
            "MARKETING_SUB_CHANNEL_NAME": "TOTAL",
            "METRIC_NAME": "impressions",
            "VARIABLE_CD": "ELE_SAM_CL0_OFF_YOU_TOT_IMP",
            "week_start_dt": "2024-01-01",
            "metric_value": 1000.0,
            "load_ts": datetime(2024, 1, 1, 10, 0, 0),
            "job_run_id": "test-job-001"
        }
    ]

    baseline_df = spark_session.createDataFrame(baseline_data)
    baseline_df.write.mode("overwrite").parquet(baseline_modelling_dataset_path)

    with mock.patch(
        "spark_pipeline.three_letter_coding.three_letter_coding.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        # Run the function with baseline
        create_three_letter_coding(
            spark=spark_session,
            channel_processed_data_path=channel_processed_data_path,
            baseline_modelling_dataset_path=baseline_modelling_dataset_path,
            output_path=output_path,
            run_date="2024-01-01",
            correlation_id="test-corr-id"
        )

        # Verify we get some output
        actual_df = spark_session.read.parquet(output_path)
        assert actual_df.count() > 0, "Output should not be empty"

        # Check that existing Samsung code is preserved
        samsung_rows = actual_df.filter(
            (F.col("column_name") == "UNIQUE_BRAND_NAME") &
            (F.col("original_column_value") == "Samsung")
        ).collect()
        assert len(samsung_rows) == 1, "Should have one Samsung entry"
        assert samsung_rows[0].final_code == "SAM", f"Expected preserved 'SAM' for Samsung, got {samsung_rows[0].final_code}"

        print("Baseline test passed!")


def test_create_three_letter_coding_duplicate_handling(spark_session: SparkSession, tmpdir: str):
    """Test duplicate handling with alphabetic sequences"""
    # Setup file paths
    channel_processed_data_path = os.path.join(tmpdir, "channel_processed_data.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")

    # Create data with lowercase column names that will generate duplicate three-letter codes
    channel_data = [
        {
            "super_category_name": "Electronics",
            "unique_brand_name": "Samsung",
            "cluster_num": "CL001",
            "marketing_type_name": "OFFSITE",
            "marketing_channel_name": "YOUTUBE",
            "marketing_sub_channel_name": "Salad",  # SAL
            "metric_name": "impressions",
            "week_start_dt": "2024-01-01",
            "metric_value": 1000.0,
            "load_ts": datetime(2024, 1, 1, 10, 0, 0),
            "job_run_id": "test-job-001"
        },
        {
            "super_category_name": "Electronics",
            "unique_brand_name": "Samsung",
            "cluster_num": "CL001",
            "marketing_type_name": "OFFSITE",
            "marketing_channel_name": "YOUTUBE",
            "marketing_sub_channel_name": "Sales",  # SAL - duplicate!
            "metric_name": "impressions",
            "week_start_dt": "2024-01-01",
            "metric_value": 1200.0,
            "load_ts": datetime(2024, 1, 1, 10, 0, 0),
            "job_run_id": "test-job-001"
        }
    ]

    channel_df = spark_session.createDataFrame(channel_data)
    channel_df.write.mode("overwrite").parquet(channel_processed_data_path)

    with mock.patch(
        "spark_pipeline.three_letter_coding.three_letter_coding.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        # Run the function
        create_three_letter_coding(
            spark=spark_session,
            channel_processed_data_path=channel_processed_data_path,
            baseline_modelling_dataset_path=None,
            output_path=output_path,
            run_date="2024-01-01",
            correlation_id="test-corr-id"
        )

        # Verify the output
        actual_df = spark_session.read.parquet(output_path)
        assert actual_df.count() > 0, "Output should not be empty"

        # Check duplicate handling for marketing sub channel
        sub_channel_codes = actual_df.filter(
            F.col("column_name") == "MARKETING_SUB_CHANNEL_NAME"
        ).select("original_column_value", "final_code").collect()

        # Should have two different codes for the duplicates
        codes = {row.final_code for row in sub_channel_codes}
        assert len(codes) == 2, f"Expected 2 different codes for duplicates, got {len(codes)}: {codes}"

        # Since no baseline exists, should use forward alphabetic sequence or numeric suffixes
        code_list = sorted([row.final_code for row in sub_channel_codes])
        assert code_list[0] != code_list[1], "Duplicate codes should be resolved to different values"

        print("Duplicate handling test passed!")


def test_create_three_letter_coding_cluster_num_as_string(spark_session: SparkSession, tmpdir: str):
    """Test that CLUSTER_NUM is properly handled as string type"""
    # Setup file paths
    channel_processed_data_path = os.path.join(tmpdir, "channel_processed_data.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")

    # Create data with lowercase column names and numeric cluster_num
    channel_data = [
        {
            "super_category_name": "Electronics",
            "unique_brand_name": "Samsung",
            "cluster_num": "123",  # Numeric string
            "marketing_type_name": "OFFSITE",
            "marketing_channel_name": "YOUTUBE",
            "marketing_sub_channel_name": "TOTAL",
            "metric_name": "impressions",
            "week_start_dt": "2024-01-01",
            "metric_value": 1000.0,
            "load_ts": datetime(2024, 1, 1, 10, 0, 0),
            "job_run_id": "test-job-001"
        }
    ]

    channel_df = spark_session.createDataFrame(channel_data)
    channel_df.write.mode("overwrite").parquet(channel_processed_data_path)

    with mock.patch(
        "spark_pipeline.three_letter_coding.three_letter_coding.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        # Run the function
        create_three_letter_coding(
            spark=spark_session,
            channel_processed_data_path=channel_processed_data_path,
            baseline_modelling_dataset_path=None,
            output_path=output_path,
            run_date="2024-01-01",
            correlation_id="test-corr-id"
        )

        # Verify the output
        actual_df = spark_session.read.parquet(output_path)
        assert actual_df.count() > 0, "Output should not be empty"

        # Check that cluster_num was processed correctly
        cluster_rows = actual_df.filter(
            (F.col("column_name") == "CLUSTER_NUM") &
            (F.col("original_column_value") == "123")
        ).collect()

        assert len(cluster_rows) > 0, "Should have at least one cluster_num entry"
        cluster_row = cluster_rows[0]
        assert cluster_row.final_code == "123", f"Expected '123' for cluster_num, got {cluster_row.final_code}"

        print("Cluster num string handling test passed!")


def test_create_three_letter_coding_with_correct_column_names(spark_session: SparkSession, tmpdir: str):
    """Test with lowercase column names that match what the code expects"""
    # Setup file paths
    channel_processed_data_path = os.path.join(tmpdir, "channel_processed_data.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")

    # Create data with lowercase column names that the code expects
    channel_data = [
        {
            "super_category_name": "Electronics",
            "unique_brand_name": "Samsung",
            "cluster_num": "CL001",
            "marketing_type_name": "OFFSITE",
            "marketing_channel_name": "YOUTUBE",
            "marketing_sub_channel_name": "TOTAL",
            "metric_name": "impressions",
            "other_column": "value"  # Additional column
        }
    ]

    channel_df = spark_session.createDataFrame(channel_data)
    channel_df.write.mode("overwrite").parquet(channel_processed_data_path)

    with mock.patch(
        "spark_pipeline.three_letter_coding.three_letter_coding.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        # Run the function
        create_three_letter_coding(
            spark=spark_session,
            channel_processed_data_path=channel_processed_data_path,
            baseline_modelling_dataset_path=None,
            output_path=output_path,
            run_date="2024-01-01",
            correlation_id="test-corr-id"
        )

        # Verify the output
        actual_df = spark_session.read.parquet(output_path)

        # Basic validations
        assert actual_df.count() > 0, "Output should not be empty"

        # Check expected columns
        expected_columns = {"column_name", "original_column_value", "final_code"}
        assert set(actual_df.columns) == expected_columns, f"Column mismatch. Expected: {expected_columns}, Got: {set(actual_df.columns)}"

        # Check that all expected column types are present
        column_names = {row.column_name for row in actual_df.select("column_name").distinct().collect()}
        expected_column_names = {
            "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM",
            "MARKETING_TYPE_NAME", "MARKETING_CHANNEL_NAME", "MARKETING_SUB_CHANNEL_NAME", "METRIC_NAME"
        }
        assert column_names == expected_column_names, f"Expected column names: {expected_column_names}, Got: {column_names}"

        # Check specific three-letter codes
        electronics_row = actual_df.filter(
            (F.col("column_name") == "SUPER_CATEGORY_NAME") &
            (F.col("original_column_value") == "Electronics")
        ).collect()[0]
        assert electronics_row.final_code == "ELE", f"Expected 'ELE' for Electronics, got {electronics_row.final_code}"

        samsung_row = actual_df.filter(
            (F.col("column_name") == "UNIQUE_BRAND_NAME") &
            (F.col("original_column_value") == "Samsung")
        ).collect()[0]
        assert samsung_row.final_code == "SAM", f"Expected 'SAM' for Samsung, got {samsung_row.final_code}"

        print(f"Correct column names test passed! Generated {actual_df.count()} rows")


def test_create_three_letter_coding_empty_input(spark_session: SparkSession, tmpdir: str):
    """Test behavior with empty channel processed data"""
    # Setup file paths
    channel_processed_data_path = os.path.join(tmpdir, "channel_processed_data.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")

    # Create empty dataset with correct schema
    empty_data = []
    spark_session.createDataFrame(
        empty_data,
        ThreeLetterCoding.channel_processed_data_schema
    ).write.mode("overwrite").parquet(channel_processed_data_path)

    # The script should handle empty input gracefully and produce empty output
    with mock.patch(
        "spark_pipeline.three_letter_coding.three_letter_coding.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        create_three_letter_coding(
            spark=spark_session,
            channel_processed_data_path=channel_processed_data_path,
            baseline_modelling_dataset_path=None,
            output_path=output_path,
            run_date="2024-01-01",
            correlation_id="test-corr-id"
        )

        # Verify empty output is created with correct schema
        actual_df = spark_session.read.parquet(output_path)
        assert actual_df.count() == 0, "Output should be empty for empty input"

        # Check that correct columns exist even with empty data
        expected_columns = {"column_name", "original_column_value", "final_code"}
        assert set(actual_df.columns) == expected_columns, f"Column mismatch. Expected: {expected_columns}, Got: {set(actual_df.columns)}"

        print("Empty input test passed!")


def test_create_three_letter_coding_null_values(spark_session: SparkSession, tmpdir: str):
    """Test handling of null values in input data"""
    # Setup file paths
    channel_processed_data_path = os.path.join(tmpdir, "channel_processed_data.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    spark_session.conf.set("spark.sql.parquet.writeLegacyFormat", "true")

    # Create data with lowercase column names and some null values
    channel_data = [
        {
            "super_category_name": "Electronics",
            "unique_brand_name": None,  # Null value
            "cluster_num": "CL001",
            "marketing_type_name": "OFFSITE",
            "marketing_channel_name": None,  # Null value
            "marketing_sub_channel_name": "TOTAL",
            "metric_name": "impressions",
            "week_start_dt": "2024-01-01",
            "metric_value": 1000.0,
            "load_ts": datetime(2024, 1, 1, 10, 0, 0),
            "job_run_id": "test-job-001"
        },
        {
            "super_category_name": "Electronics",
            "unique_brand_name": "Samsung",
            "cluster_num": "CL001",
            "marketing_type_name": "OFFSITE",
            "marketing_channel_name": "YOUTUBE",
            "marketing_sub_channel_name": "TOTAL",
            "metric_name": "impressions",
            "week_start_dt": "2024-01-01",
            "metric_value": 1200.0,
            "load_ts": datetime(2024, 1, 1, 10, 0, 0),
            "job_run_id": "test-job-001"
        }
    ]

    channel_df = spark_session.createDataFrame(channel_data)
    channel_df.write.mode("overwrite").parquet(channel_processed_data_path)

    # Run the function
    with mock.patch(
        "spark_pipeline.three_letter_coding.three_letter_coding.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        create_three_letter_coding(
            spark=spark_session,
            channel_processed_data_path=channel_processed_data_path,
            baseline_modelling_dataset_path=None,
            output_path=output_path,
            run_date="2024-01-01",
            correlation_id="test-corr-id"
        )

        # Verify we get some output
        actual_df = spark_session.read.parquet(output_path)
        assert actual_df.count() > 0, "Output should not be empty"

        # Should only have codes for non-null values
        brand_rows = actual_df.filter(F.col("column_name") == "UNIQUE_BRAND_NAME").collect()
        assert len(brand_rows) == 1, f"Expected 1 brand row (nulls filtered out), got {len(brand_rows)}"
        assert brand_rows[0].original_column_value == "Samsung", "Should only have Samsung (non-null) brand"

        channel_rows = actual_df.filter(F.col("column_name") == "MARKETING_CHANNEL_NAME").collect()
        assert len(channel_rows) == 1, f"Expected 1 channel row (nulls filtered out), got {len(channel_rows)}"
        assert channel_rows[0].original_column_value == "YOUTUBE", "Should only have YOUTUBE (non-null) channel"

        print("Null values handling test passed!")


def test_create_three_letter_coding_invalid_input_path(spark_session: SparkSession, tmpdir: str):
    """Test error handling for invalid input path"""
    invalid_path = os.path.join(tmpdir, "nonexistent.parquet")
    output_path = os.path.join(tmpdir, "output.parquet")

    # Should raise an exception for invalid input path
    try:
        create_three_letter_coding(
            spark=spark_session,
            channel_processed_data_path=invalid_path,
            baseline_modelling_dataset_path=None,
            output_path=output_path,
            run_date="2024-01-01",
            correlation_id="test-corr-id"
        )
        assert False, "Should have raised an exception for invalid path"
    except Exception as e:
        # Any exception is acceptable for invalid path
        assert True, f"Expected exception for invalid path: {str(e)}"

    print("Invalid input path test passed!")


def test_entrypoint(monkeypatch):
    """Test the entrypoint function with command line arguments"""
    mock_spark = mock.Mock()
    args = [
        "--channel-processed-data-path", "channel_processed_data_path",
        "--baseline-modelling-dataset-path", "baseline_modelling_dataset_path",
        "--output-path", "output_path",
        "--run-date", "2024-01-01",
        "--correlation-id", "test-corr-id"
    ]

    with mock.patch("spark_pipeline.three_letter_coding.three_letter_coding.create_three_letter_coding") as mock_func:
        entrypoint(spark=mock_spark, command_line_args=args)
        mock_func.assert_called_once_with(
            spark=mock_spark,
            channel_processed_data_path="channel_processed_data_path",
            baseline_modelling_dataset_path="baseline_modelling_dataset_path",
            output_path="output_path",
            run_date="2024-01-01",
            correlation_id="test-corr-id"
        )

    print("Entrypoint test passed!")


def test_entrypoint_without_baseline(monkeypatch):
    """Test the entrypoint function without baseline dataset path"""
    mock_spark = mock.Mock()
    args = [
        "--channel-processed-data-path", "channel_processed_data_path",
        "--output-path", "output_path",
        "--run-date", "2024-01-01",
        "--correlation-id", "test-corr-id"
    ]

    with mock.patch("spark_pipeline.three_letter_coding.three_letter_coding.create_three_letter_coding") as mock_func:
        entrypoint(spark=mock_spark, command_line_args=args)
        mock_func.assert_called_once_with(
            spark=mock_spark,
            channel_processed_data_path="channel_processed_data_path",
            baseline_modelling_dataset_path=None,
            output_path="output_path",
            run_date="2024-01-01",
            correlation_id="test-corr-id"
        )
