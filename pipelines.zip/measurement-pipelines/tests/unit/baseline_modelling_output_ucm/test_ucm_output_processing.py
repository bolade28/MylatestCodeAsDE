from datetime import date

from pyspark.sql import Row

from spark_pipeline.baseline_modelling_output_ucm.ucm_output_processing import (
    baseline_output_parser,
    get_marketing_contribution_column,
    get_marketing_column_names,
)


def test_get_marketing_column_names_returns_empty_list_when_no_marketing_columns():
    pivoted_columns = [
        "wdate",
        "Iteration_Number",
        "modelling_cluster",
        "level_base",
        "nec_sal_tot_xxx_xxx_xxx_sls",
        "nec_tot_tot_tot_tot_tot_sea",
    ]

    marketing_columns = get_marketing_column_names(
        pivoted_columns,
        ["off_met_", "off_you_", "off_dv3_", "off_dv2_"],
    )

    assert marketing_columns == []


def test_get_marketing_contribution_column_returns_zero_when_no_marketing_columns(spark_session, capsys):
    contribution_col = get_marketing_contribution_column(
        [
            "wdate",
            "Iteration_Number",
            "modelling_cluster",
            "level_base",
            "nec_sal_tot_xxx_xxx_xxx_sls",
            "nec_tot_tot_tot_tot_tot_sea",
        ],
        ["off_met_", "off_you_", "off_dv3_", "off_dv2_"],
    )

    result_df = spark_session.range(1).select(contribution_col.alias("marketing_contribution"))
    rows = result_df.collect()
    captured = capsys.readouterr()

    assert rows[0].marketing_contribution == 0.0
    assert "No marketing contribution columns found for patterns" in captured.out


def test_baseline_output_parser_sets_incremental_to_zero_when_no_marketing_columns(spark_session):
    input_rows = [
        Row(
            wdate=date(2026, 4, 7),
            Iteration_Number="iter_1",
            modelling_cluster="brand_a~super_cat_a~1",
            variable="level_base",
            value=100.0,
        ),
        Row(
            wdate=date(2026, 4, 7),
            Iteration_Number="iter_1",
            modelling_cluster="brand_a~super_cat_a~1",
            variable="nec_sal_tot_xxx_xxx_xxx_sls",
            value=100.0,
        ),
        Row(
            wdate=date(2026, 4, 7),
            Iteration_Number="iter_1",
            modelling_cluster="brand_a~super_cat_a~1",
            variable="nec_tot_tot_tot_tot_tot_sea",
            value=5.0,
        ),
    ]
    input_df = spark_session.createDataFrame(input_rows)

    result_df = baseline_output_parser(
        input_df,
        ["off_met_", "off_you_", "off_dv3_", "off_dv2_"],
    )

    rows = result_df.collect()

    assert len(rows) == 1
    assert rows[0].sales == 100.0
    assert rows[0].incremental == 0.0
    assert rows[0].total_baseline == rows[0].sales
