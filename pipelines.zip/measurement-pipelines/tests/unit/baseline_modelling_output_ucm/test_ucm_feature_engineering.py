import pytest
from pyspark.sql import Row

from chispa import assert_df_equality

from spark_pipeline.baseline_modelling_output_ucm.ucm_feature_engineering import (
    dist_ext_vars_priority,
)
from spark_pipeline.schemas.feature_prioritisation import FeaturePrioritisation


@pytest.mark.usefixtures("spark_session")
def test_dist_ext_vars_priority(spark_session):
    fp_output_test_data = [
        Row(
            super_category_name="super_cat_1",
            unique_brand_name="brand_1",
            cluster_num="brand_1~super_cat_1~cluster_1",
            variable_cd="var_1",
            variable_importance_rank=1,
            marketing_type_name="marketing_type_name_1",
            marketing_channel_name="marketing_channel_name_1",
            marketing_sub_channel_name="marketing_sub_channel_name_1",
            metric_name="metric_name_1",
        ),
        Row(
            super_category_name="super_cat_1",
            unique_brand_name="brand_1",
            cluster_num="brand_1~super_cat_1~cluster_1",
            variable_cd="var_2",
            variable_importance_rank=2,
            marketing_type_name="marketing_type_name_1",
            marketing_channel_name="marketing_channel_name_1",
            marketing_sub_channel_name="marketing_sub_channel_name_1",
            metric_name="metric_name_2",
        ),
        Row(
            super_category_name="super_cat_1",
            unique_brand_name="brand_1",
            cluster_num="brand_1~super_cat_1~cluster_1",
            variable_cd="var_3",
            variable_importance_rank=3,
            marketing_type_name="marketing_type_name_2",
            marketing_channel_name="marketing_channel_name_1",
            marketing_sub_channel_name="marketing_sub_channel_name_1",
            metric_name="metric_name_1",
        ),
        Row(
            super_category_name="super_cat_1",
            unique_brand_name="brand_1",
            cluster_num="brand_1~super_cat_1~cluster_1",
            variable_cd="var_4",
            variable_importance_rank=4,
            marketing_type_name="marketing_type_name_2",
            marketing_channel_name="marketing_channel_name_1",
            marketing_sub_channel_name="marketing_sub_channel_name_1",
            metric_name="metric_name_2",
        ),
    ]

    fp_output_df = spark_session.createDataFrame(
        fp_output_test_data, FeaturePrioritisation.output_schema
    )

    no_of_vars_data = [
        Row(
            unique_brand_name="brand_1",
            super_category_name="super_cat_1",
            cluster_num="brand_1~super_cat_1~cluster_1",
            no_of_vars=10,
        )
    ]

    no_of_vars_df = spark_session.createDataFrame(no_of_vars_data)

    # Act - accept many from specified marketing type
    baseline_config_mock = type(
        "MockConfig",
        (),
        {
            "accept_multiple_within_type": ["marketing_type_name_2"],
        },
    )

    diversified_df = dist_ext_vars_priority(
        baseline_config_mock, fp_output_df, no_of_vars_df
    )

    # Assert
    expected_data_priority_filter_data = [
        Row(
            super_category_name="super_cat_1",
            unique_brand_name="brand_1",
            cluster_num="brand_1~super_cat_1~cluster_1",
            variable_cd="var_1",
            variable_importance_rank=1,
            marketing_type_name="marketing_type_name_1",
            marketing_channel_name="marketing_channel_name_1",
            marketing_sub_channel_name="marketing_sub_channel_name_1",
            metric_name="metric_name_1",
        ),
        Row(
            super_category_name="super_cat_1",
            unique_brand_name="brand_1",
            cluster_num="brand_1~super_cat_1~cluster_1",
            variable_cd="var_3",
            variable_importance_rank=3,
            marketing_type_name="marketing_type_name_2",
            marketing_channel_name="marketing_channel_name_1",
            marketing_sub_channel_name="marketing_sub_channel_name_1",
            metric_name="metric_name_1",
        ),
        Row(
            super_category_name="super_cat_1",
            unique_brand_name="brand_1",
            cluster_num="brand_1~super_cat_1~cluster_1",
            variable_cd="var_4",
            variable_importance_rank=4,
            marketing_type_name="marketing_type_name_2",
            marketing_channel_name="marketing_channel_name_1",
            marketing_sub_channel_name="marketing_sub_channel_name_1",
            metric_name="metric_name_2",
        ),
    ]

    expected_data_priority_filter_data = spark_session.createDataFrame(
        expected_data_priority_filter_data, FeaturePrioritisation.output_schema
    )

    assert_df_equality(
        diversified_df, expected_data_priority_filter_data, ignore_column_order=True
    )

    # Act - accept only top variable from each specified marketing type

    baseline_config_mock = type("MockConfig", (), {"accept_multiple_within_type": None})

    diversified_df = dist_ext_vars_priority(
        baseline_config_mock, fp_output_df, no_of_vars_df
    )

    # Assert

    expected_data_priority_filter_data = [
        Row(
            super_category_name="super_cat_1",
            unique_brand_name="brand_1",
            cluster_num="brand_1~super_cat_1~cluster_1",
            variable_cd="var_1",
            variable_importance_rank=1,
            marketing_type_name="marketing_type_name_1",
            marketing_channel_name="marketing_channel_name_1",
            marketing_sub_channel_name="marketing_sub_channel_name_1",
            metric_name="metric_name_1",
        ),
        Row(
            super_category_name="super_cat_1",
            unique_brand_name="brand_1",
            cluster_num="brand_1~super_cat_1~cluster_1",
            variable_cd="var_3",
            variable_importance_rank=3,
            marketing_type_name="marketing_type_name_2",
            marketing_channel_name="marketing_channel_name_1",
            marketing_sub_channel_name="marketing_sub_channel_name_1",
            metric_name="metric_name_1",
        ),
    ]

    expected_data_priority_filter_data = spark_session.createDataFrame(
        expected_data_priority_filter_data, FeaturePrioritisation.output_schema
    )

    assert_df_equality(
        diversified_df, expected_data_priority_filter_data, ignore_column_order=True
    )
