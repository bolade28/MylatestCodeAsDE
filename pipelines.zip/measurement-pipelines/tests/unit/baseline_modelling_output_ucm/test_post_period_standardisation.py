import pytest
from pyspark.sql import SparkSession
from pyspark.sql import Row

from spark_pipeline.baseline_modelling_output_ucm.ucm_ml_functions import post_period_stdize


@pytest.fixture(scope="session")
def spark():
    return (
        SparkSession.builder
        .master("local[1]")
        .appName("unit-test")
        .getOrCreate()
    )


# Test that the function performs standardisation as expected under normal conditions
def test_post_period_stdize(spark):

    dependent = "sales"

    scalers_data = [
        Row(
            modelling_cluster="A",
            var="tv_spend",
            indep_mean=10.0,
            dep_mean=100.0
        )
    ]

    lagdata_data = [
        Row(
            modelling_cluster="A",
            wdate="2024-01-01",
            variable="tv_spend",
            value=50.0
        ),
        Row(
            modelling_cluster="A",
            wdate="2024-01-01",
            variable="sales",
            value=1000.0
        )
    ]

    scalers_df = spark.createDataFrame(scalers_data)
    lagdata_df = spark.createDataFrame(lagdata_data)

    returned_scalers_df, standardized_df = post_period_stdize(
        dependent=dependent,
        scalers_df=scalers_df,
        lagdata_2=lagdata_df
    )

    result = standardized_df.collect()

    result_dict = {
        (r["variable"]): r["value"]
        for r in result
    }

    # independent variable standardized using indep_mean
    assert result_dict["tv_spend"] == 5.0

    # dependent variable standardized using dep_mean
    assert result_dict["sales"] == 10.0

    # scalers_df returned unchanged
    assert returned_scalers_df.collect() == scalers_df.collect()


# Multi cluster test
def test_post_period_stdize_multiple_clusters(spark):

    scalers_df = spark.createDataFrame([
        Row(modelling_cluster="A", var="tv", indep_mean=10.0, dep_mean=100.0),
        Row(modelling_cluster="B", var="tv", indep_mean=20.0, dep_mean=200.0),
    ])

    lagdata_df = spark.createDataFrame([
        Row(modelling_cluster="A", wdate="2024-01-01", variable="tv", value=50.0),
        Row(modelling_cluster="B", wdate="2024-01-01", variable="tv", value=100.0),
    ])

    _, result_df = post_period_stdize(
        dependent="sales",
        scalers_df=scalers_df,
        lagdata_2=lagdata_df
    )

    results = {
        (r["modelling_cluster"], r["variable"]): r["value"]
        for r in result_df.collect()
    }

    assert results[("A", "tv")] == 5.0
    assert results[("B", "tv")] == 5.0


# Missing scaler test
def test_post_period_stdize_missing_scaler(spark):

    scalers_df = spark.createDataFrame([
        Row(modelling_cluster="A", var="tv", indep_mean=10.0, dep_mean=100.0)
    ])

    lagdata_df = spark.createDataFrame([
        Row(modelling_cluster="A", wdate="2024-01-01", variable="radio", value=50.0)
    ])

    _, result_df = post_period_stdize(
        dependent="sales",
        scalers_df=scalers_df,
        lagdata_2=lagdata_df
    )

    result = result_df.collect()[0]

    assert result["value"] == 0.0


# Testing indep_mean as 0
def test_post_period_stdize_zero_mean(spark):

    scalers_df = spark.createDataFrame([
        Row(modelling_cluster="A", var="tv", indep_mean=0.0, dep_mean=100.0)
    ])

    lagdata_df = spark.createDataFrame([
        Row(modelling_cluster="A", wdate="2024-01-01", variable="tv", value=50.0)
    ])

    _, result_df = post_period_stdize(
        dependent="sales",
        scalers_df=scalers_df,
        lagdata_2=lagdata_df
    )

    result = result_df.collect()[0]

    assert result["value"] == 0.0


# Dependent vs Independent variable split
def test_post_period_stdize_dep_vs_indep_scaling(spark):

    scalers_df = spark.createDataFrame([
        Row(modelling_cluster="A", var="tv", indep_mean=10.0, dep_mean=100.0)
    ])

    lagdata_df = spark.createDataFrame([
        Row(modelling_cluster="A", wdate="2024-01-01", variable="tv", value=20.0),
        Row(modelling_cluster="A", wdate="2024-01-01", variable="sales", value=200.0),
    ])

    _, result_df = post_period_stdize(
        dependent="sales",
        scalers_df=scalers_df,
        lagdata_2=lagdata_df
    )

    results = {
        r["variable"]: r["value"]
        for r in result_df.collect()
    }

    assert results["tv"] == 2.0
    assert results["sales"] == 2.0


# Schema consistency testing
def test_post_period_stdize_schema(spark):

    scalers_df = spark.createDataFrame([
        Row(modelling_cluster="A", var="tv", indep_mean=10.0, dep_mean=100.0)
    ])

    lagdata_df = spark.createDataFrame([
        Row(modelling_cluster="A", wdate="2024-01-01", variable="tv", value=50.0)
    ])

    _, result_df = post_period_stdize(
        dependent="sales",
        scalers_df=scalers_df,
        lagdata_2=lagdata_df
    )

    expected_columns = [
        "modelling_cluster",
        "wdate",
        "variable",
        "value"
    ]

    assert result_df.columns == expected_columns
