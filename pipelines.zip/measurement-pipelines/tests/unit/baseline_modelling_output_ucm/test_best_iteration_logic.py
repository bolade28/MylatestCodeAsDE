from dataclasses import dataclass

import pytest
from datetime import date

from pyspark.sql import types as T, functions as F
from chispa.dataframe_comparer import assert_df_equality

from spark_pipeline.baseline_modelling_output_ucm.ucm_utils import get_campaign_details, filter_by_campaign_bounds

from spark_pipeline.baseline_modelling_output_ucm.ucm_output_processing import (
    calculate_unstd_marketing_contributions, combine_penalty_metrics_and_contributions,
    calculate_iroas_penalty, rank_and_select_best_iterations
)
from spark_pipeline.common.variables import BaselineModellingOutputConfig

# ----------------------------
# Shared schemas / helpers
# ----------------------------

MASTER_SCHEMA = T.StructType(
    [
        T.StructField("modelling_cluster", T.StringType(), True),
    ]
)

CAMPAIGN_SELECTION_SCHEMA = T.StructType(
    [
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("super_category_name", T.StringType(), True),
        T.StructField("min_campaign_start_dt", T.DateType(), True),
        T.StructField("max_campaign_end_dt", T.DateType(), True),
        T.StructField("total_media_spend", T.DoubleType(), True),
    ]
)

CAMPAIGN_DETAILS_OUTPUT_SCHEMA = T.StructType(
    [
        T.StructField("modelling_cluster", T.StringType(), True),
        T.StructField("min_campaign_start_dt", T.DateType(), True),
        T.StructField("max_campaign_end_dt", T.DateType(), True),
        T.StructField("total_media_spend", T.DoubleType(), True),
    ]
)

INTERMEDIATE_UCM_BASE_SCHEMA = T.StructType(
    [
        T.StructField("modelling_cluster", T.StringType(), False),
        T.StructField("Iteration_Number", T.StringType(), False),
        T.StructField("wdate", T.DateType(), False),
        T.StructField("variable", T.StringType(), True),
        T.StructField("value", T.DoubleType(), True),
        T.StructField("total_media_spend", T.DoubleType(), True),
    ]
)

UNSTD_MARKETING_CONTRIBUTIONS_OUTPUT_SCHEMA = T.StructType(
    [
        T.StructField("modelling_cluster", T.StringType(), False),
        T.StructField("Iteration_Number", T.StringType(), False),
        T.StructField("iroas", T.DoubleType(), True),
    ]
)

RSQ_MAPE_PEN_SCHEMA = T.StructType(
    [
        T.StructField("modelling_cluster", T.StringType(), False),
        T.StructField("Iteration_Number", T.StringType(), False),
        T.StructField("penalisation_rsq", T.DoubleType(), True),
        T.StructField("penalisation_wsmape", T.DoubleType(), True),
        T.StructField("rsq", T.DoubleType(), True),
        T.StructField("wsmape", T.DoubleType(), True),
    ]
)

PVAL_PENALISATION_SCHEMA = T.StructType(
    [
        T.StructField("modelling_cluster", T.StringType(), False),
        T.StructField("Iteration_Number", T.StringType(), False),
        T.StructField("penalisation_pval", T.DoubleType(), True),
    ]
)


COMBINED_PENALTY_METRICS_AND_CONTRIBUTIONS_SCHEMA = T.StructType(
    [
        T.StructField("modelling_cluster", T.StringType(), False),
        T.StructField("Iteration_Number", T.StringType(), False),
        T.StructField("penalisation_rsq", T.DoubleType(), True),
        T.StructField("penalisation_wsmape", T.DoubleType(), True),
        T.StructField("rsq", T.DoubleType(), True),
        T.StructField("wsmape", T.DoubleType(), True),
        T.StructField("penalisation_pval", T.DoubleType(), True),
        T.StructField("iroas", T.DoubleType(), True),
    ]
)


IROAS_PENALTY_OUTPUT_SCHEMA = T.StructType(
    [
        T.StructField("modelling_cluster", T.StringType(), False),
        T.StructField("Iteration_Number", T.StringType(), False),
        T.StructField("penalisation_rsq", T.DoubleType(), True),
        T.StructField("penalisation_wsmape", T.DoubleType(), True),
        T.StructField("penalisation_iroas", T.DoubleType(), True),
        T.StructField("penalisation_pval", T.DoubleType(), True),
        T.StructField("rsq", T.DoubleType(), True),
        T.StructField("wsmape", T.DoubleType(), True),
        T.StructField("iteration_not_found", T.BooleanType(), False),
    ]
)


RANK_AND_SELECT_BEST_ITERATIONS_OUTPUT_SCHEMA = T.StructType(
    [
        T.StructField("modelling_cluster", T.StringType(), False),
        T.StructField("Iteration_Number", T.StringType(), False),
        T.StructField("penalisation_rsq", T.DoubleType(), True),
        T.StructField("penalisation_wsmape", T.DoubleType(), True),
        T.StructField("penalisation_iroas", T.DoubleType(), True),
        T.StructField("penalisation_pval", T.DoubleType(), True),
        T.StructField("rsq", T.DoubleType(), True),
        T.StructField("wsmape", T.DoubleType(), True),
        T.StructField("iteration_not_found", T.BooleanType(), False),
        T.StructField("total_penalty", T.DoubleType(), True),
        T.StructField("penalty_rank", T.IntegerType(), True),
    ]
)


# Example modelling cluster value to use in tests
modelling_cluster_a = "LURPAK | ARLA~DAIRY~CL1"
modelling_cluster_b = "PEPSICO~CRISPS & SNACKS~CL1"


# Define a test config with the same type as the actual config used in the code, but with test-specific values
_TestConfigType = BaselineModellingOutputConfig


@dataclass
class _TestConfig(_TestConfigType):
    external_variable_pattern: str = "ext"
    marketing_variables_pattern: str = "_ons_|_off_|_in-_|_tar_"


def _schema_drop(schema: T.StructType, *names: str) -> T.StructType:
    """
    Return a copy of a Spark `StructType` with the specified field names removed.

    Args:
        schema: Input Spark schema to filter.
        *names: One or more field names to drop from the schema.

    Returns:
        A new `T.StructType` containing only fields whose `name` is not in `names`.

    Notes:
        - This does not mutate the original `schema`; it constructs a new `StructType`.
        - Field order is preserved for the remaining fields.
    """
    # Convert to a set efficiently
    drop = set(names)
    # Keep only fields not marked for dropping.
    return T.StructType([f for f in schema.fields if f.name not in drop])


def _round_cols(df, cols, scale=6):
    """
    Round the given numeric columns in a Spark DataFrame to a fixed number of decimal places.

    This is intended for tests with floating point numbers, to avoid any comparison issues

    Args:
        df: Input Spark DataFrame.
        cols: Iterable of column names to round.
        scale: Number of decimal places to round to (default: 6).

    Returns:
        A new DataFrame with the specified columns rounded to `scale` decimal places.

    Notes:
        - Uses Spark's `round` which returns null if the input column is null.
        - The function applies transformations iteratively and returns the final DataFrame.
    """
    for c in cols:
        # Replace the column with its rounded version.
        df = df.withColumn(c, F.round(F.col(c), scale))
    return df


# ----------------------------
# Tests for get_campaign_details
# ----------------------------

def test_get_campaign_details_positive_case(spark_session):
    """
    'get_campaign_details' should inner-join the unique cluster list clusters (master data) to campaign selection (brand+super_cat)
    and return per-cluster campaign dates + media spend.
    """

    master_dataset = spark_session.createDataFrame(
        [(modelling_cluster_a,), (modelling_cluster_b,)],
        schema=MASTER_SCHEMA,
    )

    campaign_selection_df = spark_session.createDataFrame(
        [
            (
                "LURPAK | ARLA",
                "DAIRY",
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                10.0,
            ),
            (
                "PEPSICO",
                "CRISPS & SNACKS",
                date.fromisoformat("2021-02-01"),
                date.fromisoformat("2021-02-28"),
                20.0,
            ),
        ],
        schema=CAMPAIGN_SELECTION_SCHEMA,
    )

    result = get_campaign_details(master_dataset, campaign_selection_df)

    expected = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                10.0,
            ),
            (
                modelling_cluster_b,
                date.fromisoformat("2021-02-01"),
                date.fromisoformat("2021-02-28"),
                20.0,
            ),
        ],
        schema=CAMPAIGN_DETAILS_OUTPUT_SCHEMA,
    )

    assert_df_equality(
        result.orderBy("modelling_cluster"),
        expected.orderBy("modelling_cluster"),
        ignore_nullable=True,
    )


def test_get_campaign_details_fills_null_media_spend_with_one(spark_session):
    """'get_campaign_details' should coalesce null `total_media_spend` to 1.0 to avoid iroas division-by-zero."""

    master_dataset = spark_session.createDataFrame(
        [(modelling_cluster_a,)],
        schema=MASTER_SCHEMA,
    )

    campaign_selection_df = spark_session.createDataFrame(
        [
            (
                "LURPAK | ARLA",
                "DAIRY",
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                None,
            )
        ],
        schema=CAMPAIGN_SELECTION_SCHEMA,
    )

    result = get_campaign_details(master_dataset, campaign_selection_df)

    expected = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                1.0,
            )
        ],
        schema=CAMPAIGN_DETAILS_OUTPUT_SCHEMA,
    )

    assert_df_equality(
        result.orderBy("modelling_cluster"),
        expected.orderBy("modelling_cluster"),
        ignore_nullable=True,
    )


def test_get_campaign_details_distinct_modelling_cluster_prevents_duplicate_rows(spark_session):
    """'get_campaign_details' should de-duplicate clusters from master input so downstream joins don't duplicate rows."""

    master_dataset = spark_session.createDataFrame(
        [
            (modelling_cluster_a,),
            (modelling_cluster_a,),
            (modelling_cluster_a,),
        ],
        schema=MASTER_SCHEMA,
    )

    campaign_selection_df = spark_session.createDataFrame(
        [
            (
                "LURPAK | ARLA",
                "DAIRY",
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                5.0,
            )
        ],
        schema=CAMPAIGN_SELECTION_SCHEMA,
    )

    result = get_campaign_details(master_dataset, campaign_selection_df)
    assert result.count() == 1


def test_get_campaign_details_raises_when_no_match(spark_session):
    """'get_campaign_details' should raise an error when the inner-join finds no matching brand/category pairs."""

    master_dataset = spark_session.createDataFrame(
        [(modelling_cluster_a,)],
        schema=MASTER_SCHEMA,
    )

    campaign_selection_df = spark_session.createDataFrame(
        [
            (
                "PEPSICO",
                "CRISPS & SNACKS",
                date.fromisoformat("2021-02-01"),
                date.fromisoformat("2021-02-28"),
                10.0,
            )
        ],
        schema=CAMPAIGN_SELECTION_SCHEMA,
    )

    # Test if it raises the error correctly when there is no match between master data and campaign selection
    with pytest.raises(
        ValueError,
        match=r"The modelling_cluster values do not match between the master data and campaign selection.",
    ):
        get_campaign_details(master_dataset, campaign_selection_df)


def test_get_campaign_details_parses_brand_and_category_and_uses_inner_join(spark_session):
    """'get_campaign_details' should parse brand + super_category from 'modelling_cluster' and only keep exact matches
    via inner join (non-matching categories are dropped)."""

    master_dataset = spark_session.createDataFrame(
        [(modelling_cluster_a,), ("LURPAK | ARLA~BEER~CL1",)],
        schema=MASTER_SCHEMA,
    )

    campaign_selection_df = spark_session.createDataFrame(
        [
            (
                "LURPAK | ARLA",
                "DAIRY",
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                3.0,
            ),
            (
                "LURPAK | ARLA",
                "WINE",
                date.fromisoformat("2021-02-01"),
                date.fromisoformat("2021-02-28"),
                4.0,
            ),
        ],
        schema=CAMPAIGN_SELECTION_SCHEMA,
    )

    result = get_campaign_details(master_dataset, campaign_selection_df)

    expected = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                3.0,
            )
        ],
        schema=CAMPAIGN_DETAILS_OUTPUT_SCHEMA,
    )

    assert_df_equality(
        result.orderBy("modelling_cluster"),
        expected.orderBy("modelling_cluster"),
        ignore_nullable=True,
    )

# ----------------------------
# Tests for filter_by_campaign_bounds
# ----------------------------


def test_filter_by_campaign_bounds_filters_rows_within_bounds_and_enriches_columns(spark_session):
    """'filter_by_campaign_bounds' should inner-join campaign details, keep only rows within min/max dates (inclusive),
    and enrich rows with campaign columns (start/end/spend) when 'drop_extra_column=False'."""

    source_data = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", date.fromisoformat("2021-01-01"), "variable_1", 1.0, 10.0),
            (modelling_cluster_a, "iter_1", date.fromisoformat("2021-01-15"), "variable_1", 2.0, 10.0),
            (modelling_cluster_a, "iter_1", date.fromisoformat("2021-02-01"), "variable_1", 3.0, 10.0),
        ],
        schema=INTERMEDIATE_UCM_BASE_SCHEMA,
    )

    campaign_details = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                10.0,
            ),
        ],
        schema=CAMPAIGN_DETAILS_OUTPUT_SCHEMA,
    )

    result = filter_by_campaign_bounds(source_data, campaign_details)

    expected_schema = T.StructType(
        INTERMEDIATE_UCM_BASE_SCHEMA.fields + CAMPAIGN_DETAILS_OUTPUT_SCHEMA.fields[1:]
    )

    expected = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                "iter_1",
                date.fromisoformat("2021-01-01"),
                "variable_1",
                1.0,
                10.0,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                10.0,
            ),
            (
                modelling_cluster_a,
                "iter_1",
                date.fromisoformat("2021-01-15"),
                "variable_1",
                2.0,
                10.0,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                10.0,
            ),
        ],
        schema=expected_schema,
    )

    assert_df_equality(
        result.orderBy("wdate"),
        expected.orderBy("wdate"),
        ignore_nullable=True,
    )


def test_filter_by_campaign_bounds_includes_start_and_end_dates_inclusive(spark_session):
    """Campaign bounds filtering should be inclusive of both the start date and end date."""

    source_data = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", date.fromisoformat("2021-01-01"), "variable_1", 1.0, 10.0),
            (modelling_cluster_a, "iter_1", date.fromisoformat("2021-01-31"), "variable_1", 2.0, 10.0),
        ],
        schema=INTERMEDIATE_UCM_BASE_SCHEMA,
    )

    campaign_details = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                10.0,
            ),
        ],
        schema=CAMPAIGN_DETAILS_OUTPUT_SCHEMA,
    )

    result = filter_by_campaign_bounds(source_data, campaign_details)
    assert result.count() == 2


def test_filter_by_campaign_bounds_drop_extra_column_true_removes_campaign_columns(spark_session):
    """When 'drop_extra_column=True', campaign enrichment columns (and spend) should be dropped after filtering."""

    source_data = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", date.fromisoformat("2021-01-15"), "variable_1", 1.0, 10.0),
        ],
        schema=INTERMEDIATE_UCM_BASE_SCHEMA,
    )

    campaign_details = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                10.0,
            ),
        ],
        schema=CAMPAIGN_DETAILS_OUTPUT_SCHEMA,
    )

    result = filter_by_campaign_bounds(source_data, campaign_details, drop_extra_column=True)

    expected = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", date.fromisoformat("2021-01-15"), "variable_1", 1.0),
        ],
        schema=_schema_drop(INTERMEDIATE_UCM_BASE_SCHEMA, "total_media_spend"),
    )

    assert_df_equality(
        result.orderBy("wdate"),
        expected.orderBy("wdate"),
        ignore_nullable=True,
    )


def test_filter_by_campaign_bounds_raises_when_no_match_on_cluster(spark_session):
    """'filter_by_campaign_bounds' should raise if cluster keys don't match (inner join => empty result)."""

    source_data = spark_session.createDataFrame(
        [
            ("LURPAK | ARLA~DAIRY~CL27", "iter_1", date.fromisoformat("2021-01-15"), "variable_1", 1.0, 10.0),
        ],
        schema=INTERMEDIATE_UCM_BASE_SCHEMA,
    )

    campaign_details = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                10.0,
            ),
        ],
        schema=CAMPAIGN_DETAILS_OUTPUT_SCHEMA,
    )

    with pytest.raises(
        ValueError,
        match=r"No data points fall within the campaign bounds\. Or the modelling_cluster values do not match between source_data and campaign_details\.",
    ):
        filter_by_campaign_bounds(source_data, campaign_details)


def test_filter_by_campaign_bounds_raises_when_dates_outside_bounds(spark_session):
    """'filter_by_campaign_bounds' should raise if all dates fall outside the provided campaign window."""

    source_data = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", date.fromisoformat("2020-12-31"), "x", 1.0, 10.0),
            (modelling_cluster_a, "iter_1", date.fromisoformat("2021-02-01"), "x", 2.0, 10.0),
        ],
        schema=INTERMEDIATE_UCM_BASE_SCHEMA,
    )

    campaign_details = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                10.0,
            ),
        ],
        schema=CAMPAIGN_DETAILS_OUTPUT_SCHEMA,
    )

    with pytest.raises(
        ValueError,
        match=r"No data points fall within the campaign bounds\. Or the modelling_cluster values do not match between source_data and campaign_details\.",
    ):
        filter_by_campaign_bounds(source_data, campaign_details)


def test_filter_by_campaign_bounds_supports_custom_date_column_name(spark_session):
    """'filter_by_campaign_bounds' should support filtering on a custom date column via 'date_column_name'."""

    custom_schema = T.StructType(
        [
            T.StructField("modelling_cluster", T.StringType(), False),
            T.StructField("Iteration_Number", T.StringType(), False),
            T.StructField("week_start_date", T.DateType(), False),
            T.StructField("variable", T.StringType(), True),
            T.StructField("value", T.DoubleType(), True),
            T.StructField("total_media_spend", T.DoubleType(), True),
        ]
    )

    source_data = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", date.fromisoformat("2021-01-15"), "variable_1", 1.0, 10.0),
            (modelling_cluster_a, "iter_1", date.fromisoformat("2021-02-15"), "variable_1", 2.0, 10.0),
        ],
        schema=custom_schema,
    )

    campaign_details = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                date.fromisoformat("2021-01-01"),
                date.fromisoformat("2021-01-31"),
                10.0,
            ),
        ],
        schema=CAMPAIGN_DETAILS_OUTPUT_SCHEMA,
    )

    result = filter_by_campaign_bounds(
        source_data,
        campaign_details,
        date_column_name="week_start_date",
        drop_extra_column=True,
    )

    assert result.count() == 1
    assert "week_start_date" in result.columns

# ----------------------------
# Test calculate_unstd_marketing_contributions
# ----------------------------


def test_calculate_unstd_marketing_contributions_aggregation(spark_session):
    """
    'calculate_unstd_marketing_contributions' should:
    - include only variables matching the marketing regex,
    - exclude variables containing the external pattern (case-insensitive),
    - aggregate contributions across dates,
    - compute iroas = aggregated_marketing_contribution / total_media_spend.

    ToDo split this into multiple tests to isolate each piece of logic (regex filtering, case-insensitive exclusion, aggregation, iroas calculation)
    """

    ucm_base_data = spark_session.createDataFrame(
        [
            # Two different wdates, multiple rows per wdate; with dummy marketing and external vars
            (modelling_cluster_a, "iter_1", date(2021, 1, 1), "_ons_ons_spend", 2.0, 10.0),
            (modelling_cluster_a, "iter_1", date(2021, 1, 1), "_off_off_spend", 3.0, 10.0),
            (modelling_cluster_a, "iter_1", date(2021, 1, 8), "promo_tar_tar_discount", 5.0, 10.0),
            (modelling_cluster_a, "iter_1", date(2021, 1, 8), "banner_in-_in-_store", 10.0, 10.0),
            # Excluded: contains ext (case-insensitive) even if marketing-like
            (modelling_cluster_a, "iter_1", date(2021, 1, 8), "search_ons_ext_spend", 100.0, 10.0),
            # Excluded: does not match marketing regex
            (modelling_cluster_a, "iter_1", date(2021, 1, 8), "level_base", 999.0, 10.0),
        ],
        schema=INTERMEDIATE_UCM_BASE_SCHEMA,
    )

    result = calculate_unstd_marketing_contributions(ucm_base_data, _TestConfig())

    expected = spark_session.createDataFrame(
        [
            # Included sum = 2 + 3 + 5 + 10 = 20; iroas = 20 / 10 = 2.0
            (modelling_cluster_a, "iter_1", 2.0),
        ],
        schema=UNSTD_MARKETING_CONTRIBUTIONS_OUTPUT_SCHEMA,
    )

    assert_df_equality(
        result,
        expected,
        ignore_nullable=True,
        ignore_row_order=True,
    )


# ----------------------------
# Tests for combine_penalty_metrics_and_contributions
# ----------------------------


def test_combine_penalty_metrics_and_contributions_left_joins_and_preserves_left_rows(spark_session):
    """
    'combine_penalty_metrics_and_contributions' should left-join p-value penalties and iROAS onto the rsq/wsmape
    penalty frame, preserving iterations present on the left even when the right side is missing.
    """

    rsq_mape_pen_df = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", 0.10, 0.20, 0.90, 0.15),
            (modelling_cluster_a, "iter_2", 0.11, 0.21, 0.91, 0.16),
        ],
        schema=RSQ_MAPE_PEN_SCHEMA,
    )

    # Only iter_1 present -> iter_2 should keep row with penalisation_pval = null
    pval_penalisation_df = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", 0.30),
        ],
        schema=PVAL_PENALISATION_SCHEMA,
    )

    # Only iter_1 present -> iter_2 should get iroas filled to 0
    marketing_contribution_unstd = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", 2.5),
        ],
        schema=UNSTD_MARKETING_CONTRIBUTIONS_OUTPUT_SCHEMA,
    )

    result = combine_penalty_metrics_and_contributions(
        rsq_mape_pen_df=rsq_mape_pen_df,
        pval_penalisation_df=pval_penalisation_df,
        marketing_contribution_unstd=marketing_contribution_unstd,
    )

    expected = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", 0.10, 0.20, 0.90, 0.15, 0.30, 2.5),
            (modelling_cluster_a, "iter_2", 0.11, 0.21, 0.91, 0.16, None, 0.0),
        ],
        schema=COMBINED_PENALTY_METRICS_AND_CONTRIBUTIONS_SCHEMA,
    )

    assert_df_equality(
        result.orderBy("Iteration_Number"),
        expected.orderBy("Iteration_Number"),
        ignore_nullable=True,
        ignore_row_order=True,
    )


def test_combine_penalty_metrics_and_contributions_fillna_sets_missing_iroas_to_zero(spark_session):
    """Missing iROAS after the join should be filled to 0.0 (not null) to ensure deterministic scoring downstream."""

    rsq_mape_pen_df = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", 0.10, 0.20, 0.90, 0.15),
        ],
        schema=RSQ_MAPE_PEN_SCHEMA,
    )

    pval_penalisation_df = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", 0.30),
        ],
        schema=PVAL_PENALISATION_SCHEMA,
    )

    # No matching marketing rows -> iroas should be 0.0 (not null) after fillna
    marketing_contribution_unstd = spark_session.createDataFrame(
        [],
        schema=UNSTD_MARKETING_CONTRIBUTIONS_OUTPUT_SCHEMA,
    )

    result = combine_penalty_metrics_and_contributions(
        rsq_mape_pen_df=rsq_mape_pen_df,
        pval_penalisation_df=pval_penalisation_df,
        marketing_contribution_unstd=marketing_contribution_unstd,
    )

    expected = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", 0.10, 0.20, 0.90, 0.15, 0.30, 0.0),
        ],
        schema=COMBINED_PENALTY_METRICS_AND_CONTRIBUTIONS_SCHEMA,
    )

    assert_df_equality(
        result,
        expected,
        ignore_nullable=True,
        ignore_row_order=True,
    )


# ----------------------------
# Tests for calculate_iroas_penalty
# ----------------------------

@pytest.mark.parametrize(
    "iteration_number,pen_rsq,pen_wsmape,pen_pval,rsq,wsmape,iroas,expected_penalty,expected_not_found",
    [
        ("iter_neg", 0.10, 0.20, 0.30, 0.90, 0.15, -1.0, 3.01, True),
        ("iter_zero", 0.11, 0.21, 0.31, 0.91, 0.16, 0.0, 2.00, False),
        ("iter_good", 0.12, 0.22, 0.32, 0.92, 0.17, 7.5, 0.00, False),
        ("iter_high", 0.13, 0.23, 0.33, 0.93, 0.18, 12.0, 0.04, False),
    ],
    ids=["negative", "zero", "valid", "high"],
)
def test_calculate_iroas_penalty_parametrized_branches(
    spark_session,
    iteration_number,
    pen_rsq,
    pen_wsmape,
    pen_pval,
    rsq,
    wsmape,
    iroas,
    expected_penalty,
    expected_not_found,
):
    """
    'calculate_iroas_penalty' should follow its piecewise definition across key branches:
    - negative iroas => high penalty + iteration_not_found True
    - zero iroas => fixed penalty + iteration_not_found False
    - (0, 10] => zero penalty
    - > 10 => increasing penalty.
    """

    model_metrics_df = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                iteration_number,
                pen_rsq,
                pen_wsmape,
                rsq,
                wsmape,
                pen_pval,
                iroas,
            ),
        ],
        schema=COMBINED_PENALTY_METRICS_AND_CONTRIBUTIONS_SCHEMA,
    )

    result = calculate_iroas_penalty(model_metrics_df)

    expected = spark_session.createDataFrame(
        [
            (
                modelling_cluster_a,
                iteration_number,
                pen_rsq,
                pen_wsmape,
                expected_penalty,  # penalisation_iroas
                pen_pval,
                rsq,
                wsmape,
                expected_not_found,  # iteration_not_found
            ),
        ],
        schema=IROAS_PENALTY_OUTPUT_SCHEMA,
    )

    result_rounded = _round_cols(result, ["penalisation_iroas"], scale=2)
    expected_rounded = _round_cols(expected, ["penalisation_iroas"], scale=2)

    assert_df_equality(
        result_rounded.orderBy("Iteration_Number"),
        expected_rounded.orderBy("Iteration_Number"),
        ignore_nullable=True,
        ignore_row_order=True,
    )


@pytest.mark.parametrize(
    "iroas_left,iroas_right",
    [
        (-1.0, 0.0),
        (0.0, 7.5),
        (7.5, 12.0),
    ],
    ids=["neg_vs_zero", "zero_vs_valid", "valid_vs_high"],
)
def test_calculate_iroas_penalty_is_monotonic_in_expected_direction_around_thresholds(
    spark_session,
    iroas_left,
    iroas_right,
):
    """
    Sanity-check penalty ordering around decision thresholds used as business rules:
    - negative should penalise more than zero (and set iteration_not_found=True)
    - zero should penalise more than a "valid" positive iroas (<= 10)
    - very high iroas (> 10) should not reduce penalty versus a valid positive iroas.
    """

    model_metrics_df = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_left", 0.10, 0.20, 0.30, 0.90, 0.15, iroas_left),
            (modelling_cluster_b, "iter_right", 0.10, 0.20, 0.30, 0.90, 0.15, iroas_right),
        ],
        schema=COMBINED_PENALTY_METRICS_AND_CONTRIBUTIONS_SCHEMA,
    )

    result = calculate_iroas_penalty(model_metrics_df).select(
        "Iteration_Number",
        "penalisation_iroas",
        "iteration_not_found",
    )

    rows = {r["Iteration_Number"]: r for r in result.collect()}
    left_pen = float(rows["iter_left"]["penalisation_iroas"])
    right_pen = float(rows["iter_right"]["penalisation_iroas"])

    # Sanity checks across known threshold regions:
    # negative should be penalized more than zero; zero should be penalized more than valid; valid should be <= high (usually smaller).
    if iroas_left < 0 and iroas_right == 0.0:
        assert left_pen > right_pen
        assert rows["iter_left"]["iteration_not_found"] is True
        assert rows["iter_right"]["iteration_not_found"] is False
    elif iroas_left == 0.0 and 0.0 < iroas_right <= 10.0:
        assert left_pen > right_pen
        assert rows["iter_left"]["iteration_not_found"] is False
        assert rows["iter_right"]["iteration_not_found"] is False
    elif 0.0 < iroas_left <= 10.0 and iroas_right > 10.0:
        assert left_pen <= right_pen
        assert rows["iter_left"]["iteration_not_found"] is False
        assert rows["iter_right"]["iteration_not_found"] is False


# ----------------------------
# Tests for rank_and_select_best_iterations
# ----------------------------

def test_rank_and_select_best_iterations_selects_lowest_total_penalty_per_cluster_with_iteration_number_tiebreak(spark_session):
    """
    'rank_and_select_best_iterations' should:
    - compute total_penalty as a weighted sum (with pval null coalesced to 0),
    - rank per cluster by ascending total_penalty, then ascending Iteration_Number as tiebreaker,
    - keep only the single rank==1 row per cluster (Iteration_Number tiebreaker makes this deterministic).
    """

    # Two clusters: one has a clear minimum; the other has a tie for minimum to validate dense_rank behaviour
    model_metrics_df = spark_session.createDataFrame(
        [
            # modelling_cluster_a: iter_2 should win.
            # total_penalty = 1.0*0.10 + 1.0*0.20 + 1.0*0.30 + 1.0*0.40 = 1.00
            (modelling_cluster_a, "iter_1", 0.20, 0.30, 0.40, 0.10, 0.80, 0.12, False),
            # penalisation_pval is null -> coalesce to 0.0
            # total_penalty = 0.0 + 0.10 + 0.10 + 0.10 = 0.30
            (modelling_cluster_a, "iter_2", 0.10, 0.10, 0.10, 0.0, 0.90, 0.08, False),
            # total_penalty = 0.01 + 0.50 + 0.10 + 0.10 = 0.71
            (modelling_cluster_a, "iter_3", 0.50, 0.10, 0.10, 0.01, 0.70, 0.20, False),

            # modelling_cluster_b: iter_1 and iter_2 have equal total_penalty; iter_1 wins via Iteration_Number tiebreaker.
            # total_penalty = 0.50
            (modelling_cluster_b, "iter_1", 0.10, 0.10, 0.10, 0.20, 0.85, 0.10, False),
            # total_penalty = 0.50 — same penalty, but Iteration_Number "iter_2" > "iter_1" so rank=2
            (modelling_cluster_b, "iter_2", 0.10, 0.10, 0.10, 0.20, 0.85, 0.10, False),
            # total_penalty = 0.51
            (modelling_cluster_b, "iter_3", 0.11, 0.10, 0.10, 0.20, 0.60, 0.30, False),
        ],
        schema=IROAS_PENALTY_OUTPUT_SCHEMA,
    )

    # Use equal weights to make expected totals easy to reason about.
    config = _TestConfig()
    config.weight_pvalue = 1.0
    config.weight_rsq = 1.0
    config.weight_wsmape = 1.0
    config.weight_iroas = 1.0

    result = rank_and_select_best_iterations(model_metrics_df, config)

    expected = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_2", 0.10, 0.10, 0.10, 0.0, 0.90, 0.08, False, 0.30, 1),
            (modelling_cluster_b, "iter_1", 0.10, 0.10, 0.10, 0.20, 0.85, 0.10, False, 0.50, 1),
        ],
        schema=RANK_AND_SELECT_BEST_ITERATIONS_OUTPUT_SCHEMA,
    )

    numeric_cols = [
        "total_penalty",
    ]

    result_rounded = _round_cols(result, numeric_cols, scale=2)
    expected_rounded = _round_cols(expected, numeric_cols, scale=2)

    assert_df_equality(
        result_rounded.orderBy("modelling_cluster", "Iteration_Number"),
        expected_rounded.orderBy("modelling_cluster", "Iteration_Number"),
        ignore_nullable=True,
        ignore_row_order=True,
    )


def test_rank_and_select_best_iterations_selects_lowest_total_penalty_with_production_weights(spark_session):
    """
    With non-uniform (production-like) weights, 'rank_and_select_best_iterations' should still select the iteration
    with the minimum weighted total_penalty per cluster.
    """

    model_metrics_df = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_1", 0.20, 0.30, 0.40, 0.10, 0.30, 0.90, False),
            (modelling_cluster_a, "iter_2", 0.10, 0.10, 0.10, None, 0.31, 0.91, False),
            (modelling_cluster_a, "iter_3", 0.50, 0.10, 0.10, 0.01, 0.32, 0.92, False),
            (modelling_cluster_b, "iter_1", 0.09, 0.10, 0.10, 0.20, 0.33, 0.93, False),
            (modelling_cluster_b, "iter_2", 0.10, 0.10, 0.10, 0.20, 0.34, 0.94, False),
            (modelling_cluster_b, "iter_3", 0.11, 0.10, 0.10, 0.20, 0.35, 0.95, False),
        ],
        schema=IROAS_PENALTY_OUTPUT_SCHEMA,
    )

    config = _TestConfig()
    config.weight_pvalue = 0.3
    config.weight_rsq = 0.2
    config.weight_wsmape = 0.2
    config.weight_iroas = 0.3

    result = rank_and_select_best_iterations(model_metrics_df, config)

    expected = spark_session.createDataFrame(
        [
            (modelling_cluster_a, "iter_2", 0.10, 0.10, 0.10, None, 0.31, 0.91, False, 0.07, 1),
            (modelling_cluster_b, "iter_1", 0.09, 0.10, 0.10, 0.20, 0.33, 0.93, False, 0.128, 1),
        ],
        schema=RANK_AND_SELECT_BEST_ITERATIONS_OUTPUT_SCHEMA,
    )

    assert_df_equality(
        result.orderBy("modelling_cluster", "Iteration_Number"),
        expected.orderBy("modelling_cluster", "Iteration_Number"),
        ignore_nullable=True,
        ignore_row_order=True,
    )
