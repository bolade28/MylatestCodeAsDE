import os
from datetime import datetime
from unittest import mock
from unittest.mock import patch
from pyspark.sql import Row, SparkSession

from spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level import (
    entrypoint,
    prepare_baseline_integration_sku_level,
)


# @pytest.mark.skip(reason="Skipping this test for now - needs to be fixed later. The test is taking too long to run and throwing java.lang.OutOfMemoryError: Java heap space")
@mock.patch('spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level_helper.slack_utils.SlackMessenger')
def test_prepare_baseline_attribution_integration_sku_level(mock_slack_messenger, spark_session: SparkSession, tmp_dir: str):

    mock_messenger_instance = mock.Mock()
    mock_slack_messenger.return_value = mock_messenger_instance

    temp_paths = {
        'baseline_modelling_output_path': os.path.join(tmp_dir, 'baseline_modelling_output.parquet'),
        'sku_cluster_mapping_path': os.path.join(tmp_dir, 'sku_cluster_mapping.parquet'),
        'sales_data_transformation_path': os.path.join(tmp_dir, 'sales_data_transformation.parquet'),
        'campaign_product_type_path': os.path.join(tmp_dir, 'campaign_product_type.parquet'),
        'sku_level_attributed_sales_and_units_level_path': os.path.join(tmp_dir,
                                                                        'sku_level_attributed_sales_and_units_level.parquet'),
        'measurement_campaign_execution_path': os.path.join(tmp_dir, 'measurement_campaign_execution.parquet'),
        'output_path': os.path.join(tmp_dir, 'output_path.parquet'),
        'missing_data_path': os.path.join(tmp_dir, 'missing_data_path.parquet'),
        'zero_or_no_incrementality_path': os.path.join(tmp_dir, 'zero_or_no_incrementality_path.parquet'),
    }
    # Create test data for baseline_modelling_output
    spark_session.createDataFrame([
        Row(
            week_start_dt=datetime(2023, 10, 16).date(),
            super_category_name='GROCERIES',
            unique_brand_name='TestBrand',
            cluster_num=1,
            iteration=1,
            modelling_type='CLUSTERING',
            job_run_id='job123',
            metric_name='total_sales_amt',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            cluster_type='PRODUCT',
            best_iteration='Y',
            metric_value=1000.0,
            rsq=0.85,
            wsmape=0.15,
            baseline_perc=0.7
        ),
        Row(
            week_start_dt=datetime(2023, 10, 16).date(),
            super_category_name='GROCERIES',
            unique_brand_name='TestBrand',
            cluster_num=1,
            iteration=1,
            modelling_type='CLUSTERING',
            job_run_id='job123',
            metric_name='total_baseline_amt',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            cluster_type='PRODUCT',
            best_iteration='Y',
            metric_value=700.0,
            rsq=0.85,
            wsmape=0.15,
            baseline_perc=0.7
        ),
        Row(
            week_start_dt=datetime(2023, 10, 16).date(),
            super_category_name='GROCERIES',
            unique_brand_name='TestBrand',
            cluster_num=1,
            iteration=1,
            modelling_type='CLUSTERING',
            job_run_id='job123',
            metric_name='total_incremental_amt',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            cluster_type='PRODUCT',
            best_iteration='Y',
            metric_value=300.0,
            rsq=0.85,
            wsmape=0.15,
            baseline_perc=0.7
        ),
        Row(
            week_start_dt=datetime(2023, 10, 16).date(),
            super_category_name='GROCERIES',
            unique_brand_name='TestBrand',
            cluster_num=1,
            iteration=1,
            modelling_type='CLUSTERING',
            job_run_id='job123',
            metric_name='total_seasonality_amt',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            cluster_type='PRODUCT',
            best_iteration='Y',
            metric_value=50.0,
            rsq=0.85,
            wsmape=0.15,
            baseline_perc=0.7
        )
    ]).write.mode('overwrite').parquet(temp_paths['baseline_modelling_output_path'])

    # Create test data for sku_cluster_mapping
    spark_session.createDataFrame([
        Row(
            item_cd=1001,
            super_category_name='GROCERIES',
            unique_brand_name='TestBrand',
            cluster_num=1,
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            modelling_type='CLUSTERING',
            excluded_from_ucm_flag=0,
        )
    ]).write.mode('overwrite').parquet(temp_paths['sku_cluster_mapping_path'])

    # Create test data for sales_data_transformation
    spark_session.createDataFrame([
        Row(
            week_start_dt=datetime(2023, 10, 16).date(),
            item_cd=1001,
            total_sales_amt=1000.0,
            nectar_sales_amt=600.0,
            non_nectar_sales_amt=400.0,
            frequency_of_purchase=2.5,
            distinct_customer_cnt=100,
            avg_purchase_per_customer_cnt=10.0,
            online_sales_pct=0.3,
            supermarket_sales_pct=0.6,
            convenience_sales_pct=0.1,
            pack_size='Large',
            price_per_point=0.5,
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            base_price_amt=5.99
        )
    ]).write.mode('overwrite').parquet(temp_paths['sales_data_transformation_path'])

    # Create test data for campaign_product_type
    spark_session.createDataFrame([
        Row(
            item_cd=1001,
            product_type='Offer',
            channel_name='Digital',
            subchannel_name='Email',
            booking_id='booking1',
            campaign_id='camp1',
            sku_name='Test SKU',
            sub_cat_name='Dairy',
            brand_name='TestBrand',
            brand_owner_name='TestOwner',
            unique_brand_name='TestBrand',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            technical_metadata='{"test": "data"}'
        )
    ]).write.mode('overwrite').parquet(temp_paths['campaign_product_type_path'])

    # Create test data for sku_level_attributed_sales_and_units_level
    spark_session.createDataFrame([
        Row(
            campaign_id='camp1',
            channel_name='Digital',
            userjourney_id='journey1',
            loyalty_id='loyal1',
            booking_id='booking1',
            customer_journey_type='conversion',
            journey_type='Aisle',
            isconversion=True,
            normalized_weights=0.8,
            campaign_duration='During',
            event_dt=datetime(2023, 10, 16, 10, 0, 0),
            item_cd=1001,
            net_sales_amt=100.0,
            units_qty=5,
            unique_brand_name='TestBrand',
            week_start_dt=datetime(2023, 10, 16).date(),
            regression_variable=1.2,
            subchannel_name='Email',
            attributed_sales_amt=80.0,
            attributed_units_qty=4,
            attributed_recalibrated_sales_amt=85.0,
            attributed_recalibrated_units_qty=4,
            recalibration_factor=1.05,
            job_run_id='job123',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            marketing_type='Promotional',
            campaign_start_dt=datetime(2023, 10, 16).date(),
            campaign_end_dt=datetime(2023, 10, 22).date()
        )
    ]).write.mode('overwrite').parquet(temp_paths['sku_level_attributed_sales_and_units_level_path'])

    # Create test data for measurement_campaign_execution
    spark_session.createDataFrame([
        Row(
            booking_id='booking1',
            campaign_duration='During',
            campaign_start_dt=datetime(2023, 10, 16).date(),
            campaign_end_dt=datetime(2023, 10, 22).date(),
            channel_name='Digital',
            campaign_id='camp1',
            subchannel_name='Email',
            marketing_hierarchy_cd=2850
        )
    ]).write.mode('overwrite').parquet(temp_paths['measurement_campaign_execution_path'])

    with patch(
        "spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level.spark_s3_overwrite"
    ) as mock_s3_write:

        def fake_s3_write(path, df):
            df.write.mode("overwrite").parquet(path)

        mock_s3_write.side_effect = fake_s3_write
        prepare_baseline_integration_sku_level(
            spark=spark_session,
            baseline_modelling_output_path=temp_paths["baseline_modelling_output_path"],
            sku_cluster_mapping_path=temp_paths["sku_cluster_mapping_path"],
            sales_data_transformation_path=temp_paths["sales_data_transformation_path"],
            campaign_product_type_path=temp_paths["campaign_product_type_path"],
            sku_level_attributed_sales_and_units_level_path=temp_paths["sku_level_attributed_sales_and_units_level_path"],
            measurement_campaign_execution_path=temp_paths["measurement_campaign_execution_path"],
            output_path=temp_paths["output_path"],
            mta_baseline_integration_missing_data_output_path=temp_paths["missing_data_path"],
            mta_baseline_integration_zero_or_incrementality_output_path=temp_paths["zero_or_no_incrementality_path"],
            product_type="Aisle",
            run_date="2024-01-01",
            correlation_id="corr-123",
            slack_topic_arn="some_topic_arn"
        )
        actual_df = spark_session.read.parquet(temp_paths["output_path"])
    assert actual_df.count() > 0


def test_entrypoint(monkeypatch):
    mock_spark = mock.Mock()

    args = [
        "--baseline-modelling-output-path", "baseline_modelling_output_path",
        "--sku-cluster-mapping-path", "sku_cluster_mapping_path",
        "--sales-data-transformation-path", "sales_data_transformation_path",
        "--campaign-product-type-path", "campaign_product_type_path",
        "--measurement-campaign-execution-path", "measurement_campaign_execution_path",
        "--sku-level-attributed-sales-and-units-level-path", "sku_level_attributed_sales_and_units_level_path",
        "--output-path", "output_path",
        "--mta-baseline-integration-missing-data-output-path", "missing_data_path",
        "--mta-baseline-integration-zero-or-incrementality-output-path", "zero_or_no_incrementality_path",
        "--product-type", "Aisle",
        "--run-date", "2024-01-01",
        "--correlation-id", "corr-123",
        "--slack-topic-arn", "some_topic_arn",
    ]

    with mock.patch(
        "spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level.prepare_baseline_integration_sku_level"
    ) as mock_func:
        entrypoint(spark=mock_spark, command_line_args=args)

        mock_func.assert_called_once_with(
            spark=mock_spark,
            baseline_modelling_output_path="baseline_modelling_output_path",
            sku_cluster_mapping_path="sku_cluster_mapping_path",
            sales_data_transformation_path="sales_data_transformation_path",
            campaign_product_type_path="campaign_product_type_path",
            sku_level_attributed_sales_and_units_level_path="sku_level_attributed_sales_and_units_level_path",
            measurement_campaign_execution_path="measurement_campaign_execution_path",
            output_path="output_path",
            mta_baseline_integration_missing_data_output_path="missing_data_path",
            mta_baseline_integration_zero_or_incrementality_output_path="zero_or_no_incrementality_path",
            product_type="Aisle",
            run_date="2024-01-01",
            correlation_id="corr-123",
            slack_topic_arn="some_topic_arn"
        )
