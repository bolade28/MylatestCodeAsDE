"""
test_unified_baseline_attribution_integration.py
=================================================
Unit tests for prepare_unified_baseline_integration_sku_level and
create_empty_baseline_attribution_df.

Tests are grouped by concern:

    TestCreateEmptyBaselineAttributionDf   → empty DataFrame factory
    TestPrepareUnifiedBaselineIntegration  → happy-path union, product_type labelling,
                                            run_type/run_date stamping, load_ts stamping
    TestPartialSourceFailure               → graceful fallback when one or more
                                            parquet sources are unavailable
    TestAllSourcesFailure                  → all three sources fail → empty output
    TestIsconversionCasting                → isconversion cast to IntegerType
    TestRecalibrationFactorNulling         → recalibration_factor set to null for brand/aisle
    TestUnionSchema                        → final DataFrame has expected columns

Run with:
    pytest test_unified_baseline_attribution_integration.py -v
"""

from pyspark.sql.readwriter import DataFrameReader
import pytest
from datetime import datetime
from unittest.mock import patch
from pyspark.sql import functions as F
from pyspark.sql import types as T


# ─────────────────────────────────────────────────────────────────────────────
# Shared schema & sample data helpers
# ─────────────────────────────────────────────────────────────────────────────

# Minimal schema that mirrors the source parquet files before any transformations.
# product_type, run_type, dag_run_ts, recalibration_factor are NOT included here
# because they are added by the pipeline via withColumn.
_SOURCE_SCHEMA = T.StructType([
    T.StructField("correlation_id", T.StringType(), True),
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("userjourney_id", T.StringType(), True),
    T.StructField("loyalty_id", T.StringType(), True),
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("customer_journey_type", T.StringType(), True),
    T.StructField("journey_type", T.StringType(), True),
    T.StructField("isconversion", T.StringType(), True),  # string pre-cast
    T.StructField("normalized_weights", T.DoubleType(), True),
    T.StructField("campaign_duration", T.IntegerType(), True),
    T.StructField("event_dt", T.DateType(), True),
    T.StructField("net_sales_amt", T.DoubleType(), True),
    T.StructField("units_qty", T.DoubleType(), True),
    T.StructField("regression_variable", T.StringType(), True),
    T.StructField("attributed_sales_amt", T.DoubleType(), True),
    T.StructField("attributed_units_qty", T.DoubleType(), True),
    T.StructField("frequency_of_purchase", T.DoubleType(), True),
    T.StructField("online_sales_pct", T.DoubleType(), True),
    T.StructField("supermarket_sales_pct", T.DoubleType(), True),
    T.StructField("convenience_sales_pct", T.DoubleType(), True),
    T.StructField("sum_baseline_amt", T.DoubleType(), True),
    T.StructField("sum_of_sales_amt", T.DoubleType(), True),
    T.StructField("sum_of_attr_sales_amt", T.DoubleType(), True),
    T.StructField("sum_of_incr_amt", T.DoubleType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("load_ts", T.TimestampType(), True),
    T.StructField("week_start_dt", T.DateType(), True),
    T.StructField("item_cd", T.StringType(), True),
    T.StructField("incrementality_total", T.DoubleType(), True),
    T.StructField("incrementality_exposed", T.DoubleType(), True),
    T.StructField("attributed_recalibrated_sales_amt", T.DoubleType(), True),
    T.StructField("attributed_recalibrated_units_qty", T.DoubleType(), True),
    T.StructField("unique_brand_name", T.StringType(), True),
    T.StructField("baseline", T.DoubleType(), True),
    T.StructField("marketing_type", T.StringType(), True),
    T.StructField("total_sales_amt", T.DoubleType(), True),
    T.StructField("incremental_sales_amt_exposed", T.DoubleType(), True),
    T.StructField("incremental_sales_amt_total", T.DoubleType(), True),
    T.StructField("incremental_units_qty_total", T.DoubleType(), True),
    T.StructField("incremental_units_qty_exposed", T.DoubleType(), True),
    T.StructField("nectar_sales_amt", T.DoubleType(), True),
    T.StructField("non_nectar_sales_amt", T.DoubleType(), True),
    T.StructField("recalibration_factor", T.DoubleType(), True),
    T.StructField("marketing_hierarchy_cd", T.StringType(), True),
])

# Offer source also needs recalibration_factor (non-null is valid for offer)
_OFFER_SCHEMA = _SOURCE_SCHEMA

# Brand/Aisle sources do NOT have recalibration_factor in the source — it is added
# via withColumn(..., F.lit(None)) by the pipeline
_BRAND_AISLE_SOURCE_SCHEMA = T.StructType(
    [f for f in _SOURCE_SCHEMA.fields if f.name != "recalibration_factor"]
)


def _make_row(spark, schema, overrides: dict = None):
    """Return a single-row DataFrame using the given schema with sensible defaults."""
    defaults = {
        "correlation_id": "corr-001",
        "campaign_id": "camp-001",
        "userjourney_id": "uj-001",
        "loyalty_id": "loy-001",
        "booking_id": "book-001",
        "customer_journey_type": "online",
        "journey_type": "direct",
        "isconversion": "1",
        "normalized_weights": 0.5,
        "campaign_duration": 7,
        "event_dt": datetime(2024, 1, 8).date(),
        "net_sales_amt": 100.0,
        "units_qty": 10.0,
        "regression_variable": "var_a",
        "attributed_sales_amt": 80.0,
        "attributed_units_qty": 8.0,
        "frequency_of_purchase": 2.0,
        "online_sales_pct": 0.6,
        "supermarket_sales_pct": 0.3,
        "convenience_sales_pct": 0.1,
        "sum_baseline_amt": 50.0,
        "sum_of_sales_amt": 200.0,
        "sum_of_attr_sales_amt": 160.0,
        "sum_of_incr_amt": 40.0,
        "channel_name": "display",
        "subchannel_name": "banner",
        "load_ts": datetime(2024, 1, 8, 12, 0, 0),
        "week_start_dt": datetime(2024, 1, 8).date(),
        "item_cd": "sku-001",
        "incrementality_total": 20.0,
        "incrementality_exposed": 15.0,
        "attributed_recalibrated_sales_amt": 85.0,
        "attributed_recalibrated_units_qty": 8.5,
        "unique_brand_name": "BrandA",
        "baseline": 50.0,
        "marketing_type": "paid",
        "total_sales_amt": 200.0,
        "incremental_sales_amt_exposed": 15.0,
        "incremental_sales_amt_total": 20.0,
        "incremental_units_qty_total": 2.0,
        "incremental_units_qty_exposed": 1.5,
        "nectar_sales_amt": 30.0,
        "non_nectar_sales_amt": 70.0,
        "recalibration_factor": 1.05,
        "marketing_hierarchy_cd": "hier-001",
    }
    if overrides:
        defaults.update(overrides)

    # Only keep fields present in the given schema
    schema_field_names = {f.name for f in schema.fields}
    row = {k: v for k, v in defaults.items() if k in schema_field_names}
    return spark.createDataFrame([row], schema=schema)


# ─────────────────────────────────────────────────────────────────────────────
# Module under test — imported after fixtures are defined
# ─────────────────────────────────────────────────────────────────────────────

# We patch spark_s3_overwrite to avoid real S3 writes in all tests
# _OVERWRITE_PATCH = "spark_pipeline.utils.spark_s3_safe_write.spark_s3_overwrite"
_MODULE = "spark_pipeline.baseline_attribution_integration.unified_baseline_attribution_integration"


def _get_functions():
    """Lazy import so the module is only loaded after the session fixture exists."""
    from spark_pipeline.baseline_attribution_integration \
        .unified_baseline_attribution_integration import (
            create_empty_baseline_attribution_df,
            prepare_unified_baseline_integration_sku_level,
        )
    return create_empty_baseline_attribution_df, prepare_unified_baseline_integration_sku_level


# ─────────────────────────────────────────────────────────────────────────────
# 1. create_empty_baseline_attribution_df
# ─────────────────────────────────────────────────────────────────────────────

class TestCreateEmptyBaselineAttributionDf:

    def test_returns_empty_dataframe(self, spark_session):
        create_empty, _ = _get_functions()
        result = create_empty(spark_session)
        assert result.count() == 0

    def test_schema_matches_unified_schema(self, spark_session):
        from spark_pipeline.schemas.baseline_attribution_integration \
            .unified_baseline_attribution_integration import UnifiedBaselineAttributionIntegration

        create_empty, _ = _get_functions()
        result = create_empty(spark_session)
        assert result.schema == UnifiedBaselineAttributionIntegration.schema

    def test_column_names_are_present(self, spark_session):
        create_empty, _ = _get_functions()
        result = create_empty(spark_session)
        expected_cols = {
            "correlation_id", "product_type", "campaign_id", "run_type",
            "dag_run_ts", "load_ts", "item_cd", "unique_brand_name"
        }
        assert expected_cols.issubset(set(result.columns))


# ─────────────────────────────────────────────────────────────────────────────
# 2. Happy-path union: all three sources available
# ─────────────────────────────────────────────────────────────────────────────


class TestPrepareUnifiedBaselineIntegration:

    @pytest.fixture
    def source_dfs(self, spark_session):
        offer_df = _make_row(spark_session, _OFFER_SCHEMA)
        brand_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"campaign_id": "camp-002"})
        aisle_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"campaign_id": "camp-003"})
        return offer_df, brand_df, aisle_df

    def _run(self, spark_session, source_dfs, captured_dfs):
        offer_df, brand_df, aisle_df = source_dfs
        _, prepare = _get_functions()

        def _mock_read_parquet(path):
            return {
                "s3://offer": offer_df,
                "s3://brand": brand_df,
                "s3://aisle": aisle_df,
            }[path]

        def _capture_write(output_path, df):
            captured_dfs.append(df)

        with patch(f"{_MODULE}.spark_s3_overwrite", side_effect=_capture_write), \
                patch.object(DataFrameReader, "parquet", side_effect=_mock_read_parquet):

            prepare(
                spark=spark_session,
                baseline_attribution_integration_sku_level_offer_path="s3://offer",
                baseline_attribution_integration_sku_level_brand_path="s3://brand",
                baseline_attribution_integration_sku_level_aisle_path="s3://aisle",
                output_path="s3://output",
                run_date="2024-01-08",
                run_type="Pollen",
                correlation_id="corr-test",
                slack_topic_arn="arn:aws:sns:eu-west-1:123456789:slack",
            )

    def test_output_row_count_equals_sum_of_sources(self, spark_session, source_dfs):
        captured = []
        self._run(spark_session, source_dfs, captured)
        assert captured[0].count() == 3

    def test_product_type_offer_set_correctly(self, spark_session, source_dfs):
        captured = []
        self._run(spark_session, source_dfs, captured)
        result = captured[0]
        offer_rows = result.filter(F.col("product_type") == "Offer").collect()
        assert len(offer_rows) == 1
        assert offer_rows[0]["campaign_id"] == "camp-001"

    def test_product_type_brand_set_correctly(self, spark_session, source_dfs):
        captured = []
        self._run(spark_session, source_dfs, captured)
        result = captured[0]
        brand_rows = result.filter(F.col("product_type") == "Brand").collect()
        assert len(brand_rows) == 1
        assert brand_rows[0]["campaign_id"] == "camp-002"

    def test_product_type_aisle_set_correctly(self, spark_session, source_dfs):
        captured = []
        self._run(spark_session, source_dfs, captured)
        result = captured[0]
        aisle_rows = result.filter(F.col("product_type") == "Aisle").collect()
        assert len(aisle_rows) == 1
        assert aisle_rows[0]["campaign_id"] == "camp-003"

    def test_run_type_stamped_on_all_rows(self, spark_session, source_dfs):
        captured = []
        self._run(spark_session, source_dfs, captured)
        result = captured[0]
        run_types = {row["run_type"] for row in result.collect()}
        assert run_types == {"Pollen"}

    def test_run_date_stamped_on_all_rows(self, spark_session, source_dfs):
        captured = []
        self._run(spark_session, source_dfs, captured)
        result = captured[0]
        run_dates = {str(row["run_date"]) for row in result.collect()}
        assert run_dates == {"2024-01-08"}

    def test_load_ts_is_consistent_across_all_rows(self, spark_session, source_dfs):
        """load_ts is set from a single datetime.now() captured at function entry,
        so all rows must carry the same timestamp."""
        captured = []
        self._run(spark_session, source_dfs, captured)
        result = captured[0]
        load_ts_values = {row["load_ts"] for row in result.collect()}
        assert len(load_ts_values) == 1, (
            "All rows must share the same load_ts — it is captured once at function "
            "entry, not re-evaluated per row."
        )

    def test_dag_run_ts_is_consistent_across_all_rows(self, spark_session, source_dfs):
        captured = []
        self._run(spark_session, source_dfs, captured)
        result = captured[0]
        dag_ts_values = {row["dag_run_ts"] for row in result.collect()}
        assert len(dag_ts_values) == 1

    def test_s3_overwrite_called_once(self, spark_session, source_dfs):
        captured = []
        self._run(spark_session, source_dfs, captured)
        assert len(captured) == 1


# ─────────────────────────────────────────────────────────────────────────────
# 3. Partial source failure — graceful fallback to empty DataFrame
# ─────────────────────────────────────────────────────────────────────────────

class TestPartialSourceFailure:

    def _run_with_failing_source(self, spark_session, fail_path: str):
        offer_df = _make_row(spark_session, _OFFER_SCHEMA)
        brand_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"campaign_id": "camp-002"})
        aisle_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"campaign_id": "camp-003"})

        source_map = {
            "s3://offer": offer_df,
            "s3://brand": brand_df,
            "s3://aisle": aisle_df,
        }

        def _mock_read_parquet(path):
            if path == fail_path:
                raise Exception(f"Simulated read failure for {path}")
            return source_map[path]

        captured = []
        _, prepare = _get_functions()

        with patch(f"{_MODULE}.spark_s3_overwrite", side_effect=lambda p, df: captured.append(df)), \
                patch.object(DataFrameReader, "parquet", side_effect=_mock_read_parquet):

            prepare(
                spark=spark_session,
                baseline_attribution_integration_sku_level_offer_path="s3://offer",
                baseline_attribution_integration_sku_level_brand_path="s3://brand",
                baseline_attribution_integration_sku_level_aisle_path="s3://aisle",
                output_path="s3://output",
                run_date="2024-01-08",
                run_type="Pollen",
                correlation_id="corr-test",
                slack_topic_arn="arn:aws:sns:eu-west-1:123456789:slack",
            )
        return captured[0]

    def test_offer_failure_produces_two_rows(self, spark_session):
        result = self._run_with_failing_source(spark_session, "s3://offer")
        assert result.count() == 2

    def test_brand_failure_produces_two_rows(self, spark_session):
        result = self._run_with_failing_source(spark_session, "s3://brand")
        assert result.count() == 2

    def test_aisle_failure_produces_two_rows(self, spark_session):
        result = self._run_with_failing_source(spark_session, "s3://aisle")
        assert result.count() == 2

    def test_offer_failure_still_includes_brand_and_aisle(self, spark_session):
        result = self._run_with_failing_source(spark_session, "s3://offer")
        product_types = {row["product_type"] for row in result.collect()}
        assert product_types == {"Aisle", "Brand"}

    def test_pipeline_does_not_raise_when_source_is_unavailable(self, spark_session):
        """The try/except in the pipeline must swallow the read exception."""
        try:
            self._run_with_failing_source(spark_session, "s3://aisle")
        except Exception as exc:
            pytest.fail(f"Pipeline raised unexpectedly: {exc}")

# ─────────────────────────────────────────────────────────────────────────────
# 4. isconversion casting
# ─────────────────────────────────────────────────────────────────────────────


class TestIsconversionCasting:

    def _run_and_get_result(self, spark_session, isconversion_value):
        offer_df = _make_row(spark_session, _OFFER_SCHEMA, {"isconversion": isconversion_value})
        brand_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"isconversion": isconversion_value})
        aisle_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"isconversion": isconversion_value})

        source_map = {"s3://offer": offer_df, "s3://brand": brand_df, "s3://aisle": aisle_df}
        captured = []
        _, prepare = _get_functions()

        with patch(f"{_MODULE}.spark_s3_overwrite", side_effect=lambda p, df: captured.append(df)), \
                patch.object(DataFrameReader, "parquet", side_effect=lambda p: source_map[p]):
            prepare(
                spark=spark_session,
                baseline_attribution_integration_sku_level_offer_path="s3://offer",
                baseline_attribution_integration_sku_level_brand_path="s3://brand",
                baseline_attribution_integration_sku_level_aisle_path="s3://aisle",
                output_path="s3://output",
                run_date="2024-01-08",
                run_type="Pollen",
                correlation_id="corr-test",
                slack_topic_arn="arn:aws:sns:eu-west-1:123456789:slack",
            )
        return captured[0]

    def test_isconversion_cast_to_integer_for_offer(self, spark_session):
        result = self._run_and_get_result(spark_session, "1")
        offer_row = result.filter(F.col("product_type") == "Offer").collect()[0]
        assert isinstance(offer_row["isconversion"], int), (
            "isconversion must be cast to IntegerType for offer rows."
        )

    def test_isconversion_cast_to_integer_for_brand(self, spark_session):
        result = self._run_and_get_result(spark_session, "0")
        brand_row = result.filter(F.col("product_type") == "Brand").collect()[0]
        assert isinstance(brand_row["isconversion"], int)

    def test_isconversion_cast_to_integer_for_aisle(self, spark_session):
        result = self._run_and_get_result(spark_session, "1")
        aisle_row = result.filter(F.col("product_type") == "Aisle").collect()[0]
        assert isinstance(aisle_row["isconversion"], int)

    def test_isconversion_string_1_casts_to_integer_1(self, spark_session):
        result = self._run_and_get_result(spark_session, "1")
        values = {row["isconversion"] for row in result.collect()}
        assert values == {1}

    def test_isconversion_string_0_casts_to_integer_0(self, spark_session):
        result = self._run_and_get_result(spark_session, "0")
        values = {row["isconversion"] for row in result.collect()}
        assert values == {0}


# ─────────────────────────────────────────────────────────────────────────────
# 5. recalibration_factor nulling for brand and aisle
# ─────────────────────────────────────────────────────────────────────────────

class TestRecalibrationFactorNulling:

    @pytest.fixture
    def result(self, spark_session):
        offer_df = _make_row(spark_session, _OFFER_SCHEMA, {"recalibration_factor": 1.05})
        brand_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"campaign_id": "camp-002"})
        aisle_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"campaign_id": "camp-003"})

        source_map = {"s3://offer": offer_df, "s3://brand": brand_df, "s3://aisle": aisle_df}
        captured = []
        _, prepare = _get_functions()

        with patch(f"{_MODULE}.spark_s3_overwrite", side_effect=lambda p, df: captured.append(df)), \
                patch.object(DataFrameReader, "parquet", side_effect=lambda p: source_map[p]):
            prepare(
                spark=spark_session,
                baseline_attribution_integration_sku_level_offer_path="s3://offer",
                baseline_attribution_integration_sku_level_brand_path="s3://brand",
                baseline_attribution_integration_sku_level_aisle_path="s3://aisle",
                output_path="s3://output",
                run_date="2024-01-08",
                run_type="Pollen",
                correlation_id="corr-test",
                slack_topic_arn="arn:aws:sns:eu-west-1:123456789:slack",
            )
        return captured[0]

    def test_brand_recalibration_factor_is_null(self, result):
        brand_row = result.filter(F.col("product_type") == "Brand").collect()[0]
        assert brand_row["recalibration_factor"] is None, (
            "recalibration_factor must be null for brand rows."
        )

    def test_aisle_recalibration_factor_is_null(self, result):
        aisle_row = result.filter(F.col("product_type") == "Aisle").collect()[0]
        assert aisle_row["recalibration_factor"] is None, (
            "recalibration_factor must be null for aisle rows."
        )

    def test_offer_recalibration_factor_is_preserved(self, result):
        offer_row = result.filter(F.col("product_type") == "Offer").collect()[0]
        assert offer_row["recalibration_factor"] == pytest.approx(1.05), (
            "recalibration_factor from the source must be preserved for offer rows."
        )


# ─────────────────────────────────────────────────────────────────────────────
# 6. Final output schema
# ─────────────────────────────────────────────────────────────────────────────

class TestUnionSchema:

    def test_output_contains_all_required_columns(self, spark_session):
        offer_df = _make_row(spark_session, _OFFER_SCHEMA)
        brand_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"campaign_id": "camp-002"})
        aisle_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"campaign_id": "camp-003"})

        source_map = {"s3://offer": offer_df, "s3://brand": brand_df, "s3://aisle": aisle_df}
        captured = []
        _, prepare = _get_functions()

        with patch(f"{_MODULE}.spark_s3_overwrite", side_effect=lambda p, df: captured.append(df)), \
                patch.object(spark_session.read, "parquet", side_effect=lambda p: source_map[p]):
            prepare(
                spark=spark_session,
                baseline_attribution_integration_sku_level_offer_path="s3://offer",
                baseline_attribution_integration_sku_level_brand_path="s3://brand",
                baseline_attribution_integration_sku_level_aisle_path="s3://aisle",
                output_path="s3://output",
                run_date="2024-01-08",
                run_type="DTP",
                correlation_id="corr-test",
                slack_topic_arn="arn:aws:sns:eu-west-1:123456789:slack",
            )

        result_cols = set(captured[0].columns)
        required_cols = {
            "correlation_id", "product_type", "campaign_id", "item_cd",
            "run_type", "run_date", "dag_run_ts", "load_ts",
            "isconversion", "recalibration_factor",
            "marketing_type", "marketing_hierarchy_cd",
            "unique_brand_name", "channel_name", "subchannel_name",
        }
        assert required_cols.issubset(result_cols), (
            f"Missing columns in output: {required_cols - result_cols}"
        )

    def test_no_duplicate_rows_in_output_when_sources_are_distinct(self, spark_session):
        offer_df = _make_row(spark_session, _OFFER_SCHEMA, {"campaign_id": "camp-001"})
        brand_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"campaign_id": "camp-002"})
        aisle_df = _make_row(spark_session, _BRAND_AISLE_SOURCE_SCHEMA, {"campaign_id": "camp-003"})

        source_map = {"s3://offer": offer_df, "s3://brand": brand_df, "s3://aisle": aisle_df}
        captured = []
        _, prepare = _get_functions()

        with patch(f"{_MODULE}.spark_s3_overwrite", side_effect=lambda p, df: captured.append(df)), \
                patch.object(DataFrameReader, "parquet", side_effect=lambda p: source_map[p]):
            prepare(
                spark=spark_session,
                baseline_attribution_integration_sku_level_offer_path="s3://offer",
                baseline_attribution_integration_sku_level_brand_path="s3://brand",
                baseline_attribution_integration_sku_level_aisle_path="s3://aisle",
                output_path="s3://output",
                run_date="2024-01-08",
                run_type="Pollen",
                correlation_id="corr-test",
                slack_topic_arn="arn:aws:sns:eu-west-1:123456789:slack",
            )

        result = captured[0]
        total = result.count()
        distinct = result.dropDuplicates(["campaign_id", "product_type"]).count()
        assert total == distinct, "Output must not contain duplicate rows for distinct source inputs."
