import os
from datetime import datetime, date
from unittest import mock

import pytest
from chispa.dataframe_comparer import assert_df_equality
from pyspark import Row
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level_helper import \
    get_latest_source_data, find_cluster_details, filter_dataframes_by_cluster, calculate_sales_proportion, \
    baseline_sku_level_calculation, baseline_sku_level_integration, log_missing_data, \
    log_negative_or_zero_incrementality, replace_nulls_with_zero, model, \
    calculate_attributed_recalibrated_sales
from spark_pipeline.schemas.baseline_attribution_integration_sku_level import BaselineAttributionIntegrationSkuLevel as schema


@mock.patch('spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level_helper.slack_utils.SlackMessenger')
def test_get_latest_source_data_success_single_booking(mock_slack_messenger, spark_session):
    """Test successful retrieval of latest data for a single booking ID"""
    mock_messenger_instance = mock.Mock()
    mock_slack_messenger.return_value = mock_messenger_instance
    sku_data = [
        ("nec24041223a", "Meta", "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_3",
         "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
         "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
         "Direct", "Offer", 1, 1, "During", "2024-12-03", 8206285.0, 1.65, 1.0,
         "Doritos|PepsiCo", "2024-12-02", "Offsite_Meta_NA_nec24041223a", "NA",
         1.65, 1, 0.6373686514, 0.3862840312,
         datetime(2025, 8, 22, 11, 24, 30), "Offsite"),
        # Same booking_id but earlier timestamp
        ("nec24041223a", "Meta", "32b8f8ed3ee7b6194615a9efc3f0fd0dc391f3f9e8e67c798cec0a1a17a75b77_1",
         "32b8f8ed3ee7b6194615a9efc3f0fd0dc391f3f9e8e67c798cec0a1a17a75b77",
         "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
         "Direct", "Offer", 1, 1, "During", "2024-12-28", 8206287.0, 1.5, 1.0,
         "Doritos|PepsiCo", "2024-12-23", "Offsite_Meta_NA_nec24041223a", "NA",
         1.5, 1, 0.5794260468, 0.3862840312,
         datetime(2025, 8, 22, 10, 24, 30), "Offsite"),  # Earlier timestamp
    ]

    campaign_data = [
        ("nec24041223a", "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
         "During", "2024-11-29", "2024-12-31", "MKT_HIER_001", "NA"),
    ]

    sku_df = spark_session.createDataFrame(sku_data, schema.sku_level_results)
    campaign_df = spark_session.createDataFrame(campaign_data, schema.measurement_campaign_execution)

    # Expected data (only the record with latest timestamp)
    expected_data = [
        ("e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
         "During", "nec24041223a", "Meta",
         "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_3",
         "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
         "Direct", "Offer", 1, 1, "2024-12-03", 8206285.0, 1.65, 1.0,
         "Doritos|PepsiCo", "2024-12-02", "Offsite_Meta_NA_nec24041223a", "NA",
         1.65, 1, 0.6373686514, 0.3862840312,
         datetime(2025, 8, 22, 11, 24, 30), "Offsite", "2024-11-29", "2024-12-31",
         datetime(2025, 8, 22, 11, 24, 30), "MKT_HIER_001")
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.get_latest_source)

    actual_df = get_latest_source_data(sku_df, campaign_df, "brand", mock_messenger_instance)

    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_column_order=True)


@mock.patch('spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level_helper.slack_utils.SlackMessenger')
def test_get_latest_source_data_multiple_bookings(mock_slack_messenger, spark_session):
    """Test that function handles multiple booking IDs correctly"""
    mock_messenger_instance = mock.Mock()
    mock_slack_messenger.return_value = mock_messenger_instance
    # Create data with multiple booking IDs, each with multiple timestamps
    sku_data = [
        # Booking 1 - latest should be item 101
        ("campaign1", "Meta", "user1", "loyalty1", "booking1",
         "Direct", "Offer", 1, 1, "During", "2024-12-03", 100.0, 10.0, 1.0,
         "Brand1", "2024-12-02", "var1", "NA", 1.65, 1, 0.63, 0.38,
         datetime(2025, 8, 22, 10, 0, 0), "Offsite"),
        ("campaign1", "Meta", "user2", "loyalty2", "booking1",
         "Direct", "Offer", 1, 1, "During", "2024-12-03", 101.0, 20.0, 1.0,
         "Brand1", "2024-12-02", "var1", "NA", 1.65, 1, 0.63, 0.38,
         datetime(2025, 8, 22, 11, 0, 0), "Offsite"),

        # Booking 2 - latest should be item 201
        ("campaign2", "Meta", "user3", "loyalty3", "booking2",
         "Direct", "Offer", 1, 1, "During", "2024-12-03", 200.0, 30.0, 1.0,
         "Brand2", "2024-12-02", "var2", "NA", 1.65, 1, 0.63, 0.38,
         datetime(2025, 8, 22, 9, 0, 0), "Offsite"),
        ("campaign2", "Meta", "user4", "loyalty4", "booking2",
         "Direct", "Offer", 1, 1, "During", "2024-12-03", 201.0, 40.0, 1.0,
         "Brand2", "2024-12-02", "var2", "NA", 1.65, 1, 0.63, 0.38,
         datetime(2025, 8, 22, 12, 0, 0), "Offsite"),
    ]

    campaign_data = [
        ("campaign1", "booking1", "During", "2024-11-29", "2024-12-31", "MKT_HIER_001", "NA"),
        ("campaign2", "booking2", "During", "2024-11-29", "2024-12-31", "MKT_HIER_001", "NA"),
    ]

    sku_df = spark_session.createDataFrame(sku_data, schema.sku_level_results)
    campaign_df = spark_session.createDataFrame(campaign_data, schema.measurement_campaign_execution)
    expected_data = [
        # Latest for booking1 (item 101)
        ("booking1", "During", "campaign1", "Meta", "user2", "loyalty2", "Direct", "Offer",
         1, 1, "2024-12-03", 101.0, 20.0, 1.0, "Brand1", "2024-12-02", "var1", "NA",
         1.65, 1, 0.63, 0.38, datetime(2025, 8, 22, 11, 0, 0), "Offsite", "2024-11-29",
         "2024-12-31", datetime(2025, 8, 22, 11, 0, 0), "MKT_HIER_001"),
        # Latest for booking2 (item 201)
        ("booking2", "During", "campaign2", "Meta", "user4", "loyalty4", "Direct", "Offer",
         1, 1, "2024-12-03", 201.0, 40.0, 1.0, "Brand2", "2024-12-02", "var2", "NA",
         1.65, 1, 0.63, 0.38, datetime(2025, 8, 22, 12, 0, 0), "Offsite", "2024-11-29",
         "2024-12-31", datetime(2025, 8, 22, 12, 0, 0), "MKT_HIER_001"),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.get_latest_source)

    actual_df = get_latest_source_data(sku_df, campaign_df, "brand", mock_messenger_instance)

    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_column_order=True)


@mock.patch('spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level_helper.slack_utils.SlackMessenger')
def test_get_latest_source_data_empty_result_raises_exception(mock_slack_messenger, spark_session):
    """Test that empty result after filtering raises ValueError"""
    mock_messenger_instance = mock.Mock()
    mock_slack_messenger.return_value = mock_messenger_instance

    # Create a scneario when booking ids wont match
    sku_data = [
        ("campaign1", "Meta", "user1", "loyalty1", "booking1",
         "Direct", "Offer", 1, 1, "During", "2024-12-03", 100.0, 10.0, 1.0,
         "Brand1", "2024-12-02", "var1", "NA", 1.65, 1, 0.63, 0.38,
         datetime(2025, 8, 22, 10, 0, 0), "Offsite"),
        ("campaign1", "Meta", "user2", "loyalty2", "booking1",
         "Direct", "Offer", 1, 1, "During", "2024-12-03", 101.0, 20.0, 1.0,
         "Brand1", "2024-12-02", "var1", "NA", 1.65, 1, 0.63, 0.38,
         datetime(2025, 8, 22, 11, 0, 0), "Offsite"),

        ("campaign2", "Meta", "user3", "loyalty3", "booking1",
         "Direct", "Offer", 1, 1, "During", "2024-12-03", 200.0, 30.0, 1.0,
         "Brand2", "2024-12-02", "var2", "NA", 1.65, 1, 0.63, 0.38,
         datetime(2025, 8, 22, 9, 0, 0), "Offsite"),
        ("campaign2", "Meta", "user4", "loyalty4", "booking1",
         "Direct", "Offer", 1, 1, "During", "2024-12-03", 201.0, 40.0, 1.0,
         "Brand2", "2024-12-02", "var2", "NA", 1.65, 1, 0.63, 0.38,
         datetime(2025, 8, 22, 12, 0, 0), "Offsite"),
    ]

    campaign_data = [
        ("nec24041223a", "booking3", "During", "2024-11-29", "2024-12-31", "MKT_HIER_001", "NA"),  # ADD FIELD
        ("nec24041224a", "booking4", "During", "2024-11-29", "2024-12-31", "MKT_HIER_001", "NA"),  # ADD FIELD
    ]

    sku_df = spark_session.createDataFrame(sku_data, schema.sku_level_results)
    campaign_df = spark_session.createDataFrame(campaign_data, schema.measurement_campaign_execution)

    with pytest.raises(ValueError,
                       match="Error: no data found in SKU-level attributed sales and units to execute the model!"):
        get_latest_source_data(sku_df, campaign_df, "brand", mock_messenger_instance)


def test_find_cluster_details_success(spark_session):
    """Test successful retrieval of cluster details with matching data"""

    # Create measurement_campaign_execution data
    measurement_campaign_execution_data = [
        ("nec24041223a", "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", None, None, None, "MKT_HIER_001", "ILP"),
        ("f011f273-deab-4109-a427-d15200bc59ae", "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", None, None, None, "MKT_HIER_001", "Meta"),
    ]

    # Create campaign_product_type data (based on your sample data)
    campaign_product_type_data = [
        ("8042694", "Brand", "Secondary Space", "Meta",
         "998f1df47390f7a0266deade638dd73b5924c7e4c55ba0f8f9f32862a3da0321",
         "nec24041032a", "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae"),
        ("8160368", "Brand", "Secondary Space", "ILP",
         "998f1df47390f7a0266deade638dd73b5924c7e4c55ba0f8f9f32862a3da0321",
         "nec24041032a", "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae"),
        ("8206285", "Brand", "Offsite", "ILP",
         "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
         "nec24041223a", "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae"),
        ("8206287", "Brand", "Offsite", "ILP",
         "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
         "nec24041223a", "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae"),
    ]

    # Create clustering_df data (based on your sku_cluster_mapping sample)
    clustering_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL3",
         "f3972a9f-3922-46e8-b56e-047f1255a24b", datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING"),
        ("8206287", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL3",
         "f3972a9f-3922-46e8-b56e-047f1255a24b", datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING"),
        ("8206291", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL3",
         "f3972a9f-3922-46e8-b56e-047f1255a24b", datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING"),
        # Non-matching item to test filtering
        ("9999999", "OTHER CATEGORY", "OTHER|BRAND", "CL1",
         "f3972a9f-3922-46e8-b56e-047f1255a24b", datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING"),
    ]

    # Create DataFrames
    measurement_campaign_execution_df = spark_session.createDataFrame(
        measurement_campaign_execution_data, schema.measurement_campaign_execution
    )
    campaign_product_type_df = spark_session.createDataFrame(
        campaign_product_type_data, schema.campaign_product_type
    )
    clustering_df = spark_session.createDataFrame(clustering_data, schema.clustering)

    # Expected result - should only contain matching items from clustering_df
    expected_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL3",
         "f3972a9f-3922-46e8-b56e-047f1255a24b", datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING",
         "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "MKT_HIER_001"),
        ("8206287", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL3",
         "f3972a9f-3922-46e8-b56e-047f1255a24b", datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING",
         "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "MKT_HIER_001"),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.find_cluster_details)
    actual_df = find_cluster_details(
        measurement_campaign_execution_df,
        campaign_product_type_df,
        clustering_df
    )

    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_column_order=True)


def test_find_cluster_details_no_matching_campaigns(spark_session):
    """Test when no campaigns match between measurement_campaign_execution and campaign_product_type"""

    # Create measurement_campaign_execution with non-matching campaign_id
    measurement_campaign_execution_data = [
        ("non_matching_campaign", "non_matching_booking", None, None, None, "MKT_HIER_001", "Meta"),
    ]

    # Create campaign_product_type with different campaign_id
    campaign_product_type_data = [
        ("8206285", "Brand", "Offsite", "Meta", "different_booking", "different_campaign", "job123"),
    ]

    # Create clustering_df
    clustering_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL3", "job456", "2025-08-22", "CLUSTERING"),
    ]

    measurement_campaign_execution_df = spark_session.createDataFrame(
        measurement_campaign_execution_data, schema.measurement_campaign_execution
    )
    campaign_product_type_df = spark_session.createDataFrame(
        campaign_product_type_data, schema.campaign_product_type
    )
    clustering_df = spark_session.createDataFrame(clustering_data, schema.clustering)

    actual_df = find_cluster_details(
        measurement_campaign_execution_df,
        campaign_product_type_df,
        clustering_df
    )

    assert actual_df.count() == 0


def test_find_cluster_details_multiple_clusters(spark_session):
    """Test with multiple different clusters for different items"""

    # Create measurement_campaign_execution
    measurement_campaign_execution_data = [
        ("nec24041223a", "booking123", None, None, None, "MKT_HIER_001", "Meta"),
    ]

    # Create campaign_product_type with multiple items
    campaign_product_type_data = [
        ("8206285", "Brand", "Offsite", "Meta", "booking123", "nec24041223a", "job123"),
        ("8206287", "Brand", "Offsite", "Meta", "booking123", "nec24041223a", "job123"),
        ("8206291", "Brand", "Offsite", "Meta", "booking123", "nec24041223a", "job123"),
    ]

    # Create clustering_df with different clusters for different items
    clustering_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456", "2025-08-22", "CLUSTERING"),
        ("8206287", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "job456", "2025-08-22", "CLUSTERING"),
        ("8206291", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL3", "job456", "2025-08-22", "CLUSTERING"),
    ]

    # Create DataFrames
    measurement_campaign_execution_df = spark_session.createDataFrame(
        measurement_campaign_execution_data, schema.measurement_campaign_execution
    )
    campaign_product_type_df = spark_session.createDataFrame(
        campaign_product_type_data, schema.campaign_product_type
    )
    clustering_df = spark_session.createDataFrame(clustering_data, schema.clustering)

    # Expected result - all three items should be returned
    expected_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456", "2025-08-22", "CLUSTERING", "booking123", "MKT_HIER_001"),
        ("8206287", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "job456", "2025-08-22", "CLUSTERING", "booking123", "MKT_HIER_001"),
        ("8206291", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL3", "job456", "2025-08-22", "CLUSTERING", "booking123", "MKT_HIER_001"),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.find_cluster_details)

    actual_df = find_cluster_details(
        measurement_campaign_execution_df,
        campaign_product_type_df,
        clustering_df
    )

    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_column_order=True)

    assert actual_df.count() == 3


def test_filter_data_success_with_matching_data(spark_session):
    """Test successful filtering with matching data across all DataFrames"""

    # Create baseline_modelling_output data
    baseline_modelling_output_data = [
        ("2024-11-25", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "level_var:0.05",
         "BASELINE_MODELLING", "job123", "TOTAL_INCREMENTAL_AMT", datetime(2025, 4, 25, 17, 2, 53),
         "HIGH_TOTAL_SALES_AMT", "N", 7714.622202815, 0.9691351457, 0.06696173836, 94.817342675),
        ("2024-11-25", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "level_var:0.05",
         "BASELINE_MODELLING", "job123", "TOTAL_INCREMENTAL_AMT", datetime(2025, 4, 25, 17, 2, 53),
         "HIGH_TOTAL_SALES_AMT", "N", -45100.075755952, 0.945982334, 0.0911887281, 93.652277878),
        # Non-matching brand/category combination
        ("2024-11-25", "OTHER_CATEGORY", "OTHER|BRAND", "CL3", "level_var:0.05",
         "BASELINE_MODELLING", "job123", "TOTAL_INCREMENTAL_AMT", datetime(2025, 4, 25, 17, 2, 53),
         "HIGH_TOTAL_SALES_AMT", "N", 1000.0, 0.9, 0.1, 95.0),
    ]

    # Create sku_cluster_mapping data
    sku_cluster_mapping_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING"),
        ("8206287", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING"),
        ("8206291", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING"),
        # Non-matching item
        ("9999999", "OTHER_CATEGORY", "OTHER|BRAND", "CL3", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING"),
    ]

    # Create sales_data_transformations_output data
    sales_data_transformations_output_data = [
        ("2023-11-13", "8206285", 0.0, 0.0, 0.0,
         0, 0, 0.0, 0.0, 0.0, 0.0, "job789", 180.0, 0.013888888889,
         datetime(2025, 6, 23, 15, 17, 53), 2.5),
        ("2024-12-09", "8206287", 183707.72, 123034.59, 60673.13,
         105009, 70023, 1.499636, 0.0642564177, 0.4508389740, 0.2691316946, "job789", 180.0, 0.013888888889,
         datetime(2025, 6, 23, 15, 17, 53), 2.5),
        # Non-matching brand/category
        ("2024-12-09", "9999999", 1000.0, 500.0, 500.0,
         100, 50, 2.0, 0.1, 0.5, 0.3, "job789", 200.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 3.0),
    ]

    # Create final_df data (this provides the filtering criteria)
    final_df_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
        ("8206291", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
    ]

    baseline_modelling_output_df = spark_session.createDataFrame(
        baseline_modelling_output_data, schema.baseline_modelling_output
    )
    sku_cluster_mapping_df = spark_session.createDataFrame(
        sku_cluster_mapping_data, schema.sku_cluster_mapping
    )
    sales_data_transformations_output_df = spark_session.createDataFrame(
        sales_data_transformations_output_data, schema.sales_data_transformations_output
    )
    final_df = spark_session.createDataFrame(final_df_data, schema.filter_data)

    # Expected baseline_modelling_output_filtered (should match CL1 and CL2 for DORITOS|PEPSICO)
    expected_baseline_data = [
        ("2024-11-25", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "level_var:0.05",
         "BASELINE_MODELLING", "job123", "TOTAL_INCREMENTAL_AMT", datetime(2025, 4, 25, 17, 2, 53),
         "HIGH_TOTAL_SALES_AMT", "N", 7714.622202815, 0.9691351457, 0.06696173836, 94.817342675),
        ("2024-11-25", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "level_var:0.05",
         "BASELINE_MODELLING", "job123", "TOTAL_INCREMENTAL_AMT", datetime(2025, 4, 25, 17, 2, 53),
         "HIGH_TOTAL_SALES_AMT", "N", -45100.075755952, 0.945982334, 0.0911887281, 93.652277878),
    ]
    expected_baseline_df = spark_session.createDataFrame(expected_baseline_data, schema.baseline_modelling_output)

    # Expected sku_cluster_mapping_filtered (should include booking_id)
    expected_sku_cluster_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
        ("8206287", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
        ("8206291", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
    ]

    expected_sku_cluster_df = spark_session.createDataFrame(expected_sku_cluster_data, schema.filtered_sku_cluster)

    # Expected sales_data_transformation_filtered (should include booking_id and marketing_hierarchy_cd)
    expected_sales_data = [
        ("2023-11-13", "8206285", 0.0, 0.0, 0.0,
         0, 0, 0.0, 0.0, 0.0, 0.0, "job789", 180.0, 0.013888888889,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-12-09", "8206287", 183707.72, 123034.59, 60673.13,
         105009, 70023, 1.499636, 0.0642564177, 0.4508389740, 0.2691316946, "job789", 180.0, 0.013888888889,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
    ]

    expected_sales_df = spark_session.createDataFrame(expected_sales_data, schema.filtered_sales)

    acctual_baseline, actual_sku_cluster, actual_sales = filter_dataframes_by_cluster(
        baseline_modelling_output_df,
        sku_cluster_mapping_df,
        sales_data_transformations_output_df,
        final_df
    )

    assert_df_equality(acctual_baseline, expected_baseline_df, ignore_row_order=True, ignore_column_order=True)
    assert_df_equality(actual_sku_cluster, expected_sku_cluster_df, ignore_row_order=True, ignore_column_order=True)
    assert_df_equality(actual_sales, expected_sales_df, ignore_row_order=True, ignore_column_order=True)


def test_filter_data_no_matching_criteria(spark_session):
    """Test when final_df has criteria that don't match any source data"""

    # Create baseline_modelling_output with different brand/category
    baseline_modelling_output_data = [
        ("2024-11-25", "OTHER_CATEGORY", "OTHER|BRAND", "CL1", "level_var:0.05",
         "BASELINE_MODELLING", "job123", "TOTAL_INCREMENTAL_AMT", datetime(2025, 4, 25, 17, 2, 53),
         "HIGH_TOTAL_SALES_AMT", "N", 7714.622202815, 0.9691351457, 0.06696173836, 94.817342675),
    ]
    # Create final_df with criteria that won't match
    final_df_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
    ]
    baseline_modelling_output_df = spark_session.createDataFrame(
        baseline_modelling_output_data, schema.baseline_modelling_output
    )
    sku_cluster_mapping_df = spark_session.createDataFrame([], schema.sku_cluster_mapping)
    sales_data_transformations_output_df = spark_session.createDataFrame([], schema.sales_data_transformations_output)
    final_df = spark_session.createDataFrame(final_df_data, schema.filter_data)

    actual_baseline, actual_sku_cluster, actual_sales = filter_dataframes_by_cluster(
        baseline_modelling_output_df,
        sku_cluster_mapping_df,
        sales_data_transformations_output_df,
        final_df
    )

    # All results should be empty because criteria don't match
    assert actual_baseline.count() == 0
    assert actual_sku_cluster.count() == 0
    assert actual_sales.count() == 0


def test_calculate_sales_proportion_success_with_sufficient_history(spark_session):
    """Test successful calculation with sufficient pre-campaign history"""

    # Create sales_data_output with weekly sales data (using filtered_sales schema)
    sales_data_output_data = [
        # Pre-campaign period (6 weeks before campaign start: 2024-10-14 to 2024-11-24)
        ("2024-10-14", "8206285", 1000.0, 600.0, 400.0,
         50, 25, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-10-21", "8206285", 1200.0, 720.0, 480.0,
         60, 30, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-10-28", "8206285", 800.0, 480.0, 320.0,
         40, 20, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-11-04", "8206285", 1100.0, 660.0, 440.0,
         55, 27, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-11-11", "8206285", 900.0, 540.0, 360.0,
         45, 22, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-11-18", "8206285", 1000.0, 600.0, 400.0,
         50, 25, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),

        # Campaign period (2024-11-25 to 2024-12-31)
        ("2024-11-25", "8206285", 2000.0, 1200.0, 800.0,
         100, 50, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-12-02", "8206285", 2200.0, 1320.0, 880.0,
         110, 55, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-12-09", "8206285", 1800.0, 1080.0, 720.0,
         90, 45, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),

        # Another SKU in same cluster
        ("2024-10-14", "8206287", 500.0, 300.0, 200.0,
         25, 12, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-11-25", "8206287", 1000.0, 600.0, 400.0,
         50, 25, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-12-02", "8206287", 1100.0, 660.0, 440.0,
         55, 27, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
    ]

    # Create sku_cluster_mapping_filtered (using filtered_sku_cluster schema)
    sku_cluster_mapping_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
        ("8206287", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
    ]

    # Create campaign_date
    campaign_date_data = [
        ("booking123", "campaign123", date(2024, 11, 25), date(2024, 12, 31), date(2024, 11, 25), date(2024, 12, 31)),
    ]

    sales_data_output_df = spark_session.createDataFrame(sales_data_output_data, schema.filtered_sales)
    sku_cluster_mapping_df = spark_session.createDataFrame(sku_cluster_mapping_data,
                                                           schema.filtered_sku_cluster)
    campaign_date_df = spark_session.createDataFrame(campaign_date_data, schema.campaign_date)

    actual_sales_proportions, actual_pre_campaign_history = calculate_sales_proportion(
        sales_data_output_df,
        sku_cluster_mapping_df,
        campaign_date_df,
        pre_campaign_weeks=6,
        min_pre_camp_sales_threshold=0.1
    )

    # Expected sales proportions with pre_campaign_total_sales_amt
    # Campaign total sales: 8206285 (6000) + 8206287 (2100) = 8100
    # Pre-campaign total sales: 8206285 (6000) + 8206287 (500) = 6500
    # 8206285 campaign proportion: 6000/8100 = 0.7407407407407407
    # 8206287 campaign proportion: 2100/8100 = 0.25925925925925924
    # 8206285 pre-campaign proportion: 6000/6500 = 0.9230769230769231
    # 8206287 pre-campaign proportion: 500/6500 = 0.07692307692307693
    expected_sales_proportions_data = [
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285", 8100.0,
         0.7407407407407407, 1, 6500.0, 0.9230769230769231),
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287", 8100.0,
         0.25925925925925924, 1, 6500.0, 0.07692307692307693),
    ]

    expected_sales_proportions_df = spark_session.createDataFrame(
        expected_sales_proportions_data, schema.sales_proportions
    )

    # Expected pre-campaign history
    expected_pre_campaign_history_data = [
        ("booking123", "campaign123", True),
    ]

    expected_pre_campaign_history_df = spark_session.createDataFrame(
        expected_pre_campaign_history_data, schema.pre_campaign_history
    )

    # Assert using chispa
    assert_df_equality(
        actual_sales_proportions,
        expected_sales_proportions_df,
        ignore_row_order=True,
        ignore_column_order=True
    )

    assert_df_equality(
        actual_pre_campaign_history,
        expected_pre_campaign_history_df,
        ignore_row_order=True,
        ignore_column_order=True
    )


def test_calculate_sales_proportion_insufficient_history(spark_session):
    """Test when there's insufficient pre-campaign history"""

    # Create sales data with limited history (only 2 weeks before campaign)
    sales_data_output_data = [
        # Limited pre-campaign period (only 2 weeks)
        ("2024-11-11", "8206285", 1000.0, 600.0, 400.0,
         50, 25, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-11-18", "8206285", 1200.0, 720.0, 480.0,
         60, 30, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),

        # Campaign period
        ("2024-11-25", "8206285", 2000.0, 1200.0, 800.0,
         100, 50, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-12-02", "8206285", 2200.0, 1320.0, 880.0,
         110, 55, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
    ]

    sku_cluster_mapping_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
    ]

    campaign_date_data = [
        ("booking123", "campaign123", date(2024, 11, 25), date(2024, 12, 31), date(2024, 11, 25), date(2024, 12, 31)),
    ]

    # Create DataFrames
    sales_data_output_df = spark_session.createDataFrame(sales_data_output_data, schema.filtered_sales)
    sku_cluster_mapping_df = spark_session.createDataFrame(sku_cluster_mapping_data, schema.filtered_sku_cluster)
    campaign_date_df = spark_session.createDataFrame(campaign_date_data, schema.campaign_date)

    # Execute function
    actual_sales_proportions, actual_pre_campaign_history = calculate_sales_proportion(
        sales_data_output_df,
        sku_cluster_mapping_df,
        campaign_date_df,
        pre_campaign_weeks=6,
        min_pre_camp_sales_threshold=0.1
    )

    # Expected sales proportions (should still be calculated for campaign period)
    # No pre-campaign data will be included due to insufficient history
    expected_sales_proportions_data = [
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285", 4200.0, 1.0, None, None, None),
    ]

    expected_sales_proportions_df = spark_session.createDataFrame(
        expected_sales_proportions_data, schema.sales_proportions
    )

    # Expected pre-campaign history (insufficient)
    expected_pre_campaign_history_data = [
        ("booking123", "campaign123", False),
    ]

    expected_pre_campaign_history_df = spark_session.createDataFrame(
        expected_pre_campaign_history_data, schema.pre_campaign_history
    )

    # Assert using chispa
    assert_df_equality(
        actual_sales_proportions,
        expected_sales_proportions_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True
    )

    assert_df_equality(
        actual_pre_campaign_history,
        expected_pre_campaign_history_df,
        ignore_row_order=True,
        ignore_column_order=True
    )


def test_calculate_sales_proportion_zero_campaign_sales(spark_session):
    """Test when campaign period has zero sales"""

    sales_data_output_data = [
        # Pre-campaign period with sales
        ("2024-10-14", "8206285", 1000.0, 600.0, 400.0,
         50, 25, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-10-21", "8206285", 1200.0, 720.0, 480.0,
         60, 30, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),

        # Campaign period with zero sales
        ("2024-11-25", "8206285", 0.0, 0.0, 0.0,
         0, 0, 0.0, 0.0, 0.0, 0.0, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-12-02", "8206285", 0.0, 0.0, 0.0,
         0, 0, 0.0, 0.0, 0.0, 0.0, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
    ]

    sku_cluster_mapping_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
    ]

    campaign_date_data = [
        ("booking123", "campaign123", date(2024, 11, 25), date(2024, 12, 31), date(2024, 11, 25), date(2024, 12, 31)),
    ]

    # Create DataFrames
    sales_data_output_df = spark_session.createDataFrame(sales_data_output_data, schema.filtered_sales)
    sku_cluster_mapping_df = spark_session.createDataFrame(sku_cluster_mapping_data, schema.filtered_sku_cluster)
    campaign_date_df = spark_session.createDataFrame(campaign_date_data, schema.campaign_date)

    actual_sales_proportions, actual_pre_campaign_history = calculate_sales_proportion(
        sales_data_output_df,
        sku_cluster_mapping_df,
        campaign_date_df,
        pre_campaign_weeks=6,
        min_pre_camp_sales_threshold=0.1
    )

    # Expected sales proportions (zero sales case)
    # Pre-campaign total sales: 2200.0, but insufficient history so won't be included
    expected_sales_proportions_data = [
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285", 0.0, 0.0, 1, 2200.0, 1.0),
    ]

    expected_sales_proportions_df = spark_session.createDataFrame(
        expected_sales_proportions_data, schema.sales_proportions
    )

    # Expected pre-campaign history
    expected_pre_campaign_history_data = [
        ("booking123", "campaign123", True),
    ]

    expected_pre_campaign_history_df = spark_session.createDataFrame(
        expected_pre_campaign_history_data, schema.pre_campaign_history
    )

    assert_df_equality(
        actual_sales_proportions,
        expected_sales_proportions_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True,
    )

    assert_df_equality(
        actual_pre_campaign_history,
        expected_pre_campaign_history_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True,
    )


def test_calculate_sales_proportion_multiple_clusters(spark_session):
    """Test with multiple clusters and verify proportions sum correctly"""

    sales_data_output_data = [
        # Cluster 1 SKUs - pre-campaign
        ("2024-10-14", "8206285", 1000.0, 600.0, 400.0,
         50, 25, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-10-14", "8206287", 500.0, 300.0, 200.0,
         25, 12, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),

        # Cluster 1 SKUs - campaign
        ("2024-11-25", "8206285", 2000.0, 1200.0, 800.0,
         100, 50, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
        ("2024-11-25", "8206287", 1000.0, 600.0, 400.0,
         50, 25, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),

        # Cluster 2 SKUs - pre-campaign
        ("2024-10-14", "8206291", 800.0, 480.0, 320.0,
         40, 20, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),

        # Cluster 2 SKUs - campaign
        ("2024-11-25", "8206291", 1600.0, 960.0, 640.0,
         80, 40, 2.0, 0.3, 0.5, 0.2, "job123", 180.0, 0.01,
         datetime(2025, 6, 23, 15, 17, 53), 2.5, "booking123", "MKT_HIER_001"),
    ]

    sku_cluster_mapping_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
        ("8206287", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
        ("8206291", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
    ]

    campaign_date_data = [
        ("booking123", "campaign123", date(2024, 11, 25), date(2024, 12, 31), date(2024, 11, 25), date(2024, 12, 31))
    ]

    # Create DataFrames
    sales_data_output_df = spark_session.createDataFrame(sales_data_output_data, schema.filtered_sales)
    sku_cluster_mapping_df = spark_session.createDataFrame(sku_cluster_mapping_data, schema.filtered_sku_cluster)
    campaign_date_df = spark_session.createDataFrame(campaign_date_data, schema.campaign_date)

    # Execute function
    actual_sales_proportions, actual_pre_campaign_history = calculate_sales_proportion(
        sales_data_output_df,
        sku_cluster_mapping_df,
        campaign_date_df,
        pre_campaign_weeks=6,
        min_pre_camp_sales_threshold=0.1
    )

    # Expected sales proportions
    # Cluster 1: 8206285 (2000) + 8206287 (1000) = 3000 total campaign, 1500 total pre-campaign
    # Cluster 2: 8206291 (1600) = 1600 total campaign, 800 total pre-campaign
    expected_sales_proportions_data = [
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285", 3000.0,
         2000.0 / 3000.0, 1, 1500.0, 1000.0 / 1500.0),  # Campaign: 2000/3000, Pre-campaign: 1000/1500
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287", 3000.0,
         1000.0 / 3000.0, 1, 1500.0, 500.0 / 1500.0),   # Campaign: 1000/3000, Pre-campaign: 500/1500
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "8206291", 1600.0,
         1.0, 1, 800.0, 1.0),                      # Campaign: 1600/1600, Pre-campaign: 800/800
    ]

    expected_sales_proportions_df = spark_session.createDataFrame(
        expected_sales_proportions_data, schema.sales_proportions
    )

    # Expected pre-campaign history
    expected_pre_campaign_history_data = [
        ("booking123", "campaign123", True),
    ]

    expected_pre_campaign_history_df = spark_session.createDataFrame(
        expected_pre_campaign_history_data, schema.pre_campaign_history
    )

    # Assert using chispa
    assert_df_equality(
        actual_sales_proportions,
        expected_sales_proportions_df,
        ignore_row_order=True,
        ignore_column_order=True
    )

    assert_df_equality(
        actual_pre_campaign_history,
        expected_pre_campaign_history_df,
        ignore_row_order=True,
        ignore_column_order=True
    )


def test_baseline_sku_level_calculation_sufficient_pre_campaign_data(spark_session):
    """Test calculation when pre-campaign data exists and is sufficient"""

    input_data = [
        # SKU with sufficient pre-campaign data - should use pre_campaign_sales_proportion
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285",
         2000.0, 0.6, 1, 0.8, True, 1500.0),

        # Another SKU in same cluster with sufficient data
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287",
         1000.0, 0.4, 1, 0.2, True, 1500.0),
    ]

    input_df = spark_session.createDataFrame(input_data, schema.integrated_df)

    # Execute function
    actual_df = baseline_sku_level_calculation(input_df)

    # Expected results
    # SKU 8206285: sales_proportion = 0.8 (pre-campaign), baseline = 0.8 * 1500 = 1200, incremental = 2000 - 1200 = 800
    # SKU 8206287: sales_proportion = 0.2 (pre-campaign), baseline = 0.2 * 1500 = 300, incremental = 1000 - 300 = 700
    expected_data = [
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285",
         2000.0, 0.6, 1, 0.8, True, 1500.0, 0.8, 1200.0, 800.0),
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287",
         1000.0, 0.4, 1, 0.2, True, 1500.0, 0.2, 300.0, 700.0),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.baseline_sku_level_calculation)

    assert_df_equality(
        actual_df,
        expected_df,
        ignore_row_order=True,
        ignore_column_order=True
    )


def test_baseline_sku_level_calculation_insufficient_pre_campaign_data(spark_session):
    """Test calculation when pre-campaign data exists but is insufficient"""

    input_data = [
        # SKU with insufficient pre-campaign data - should use campaign_sales_proportion
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285",
         2000.0, 0.6, 0, 0.8, True, 1500.0),

        # Another SKU in same cluster with insufficient data
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287",
         1000.0, 0.4, 0, 0.2, True, 1500.0),
    ]

    input_df = spark_session.createDataFrame(input_data, schema.integrated_df)

    # Execute function
    actual_df = baseline_sku_level_calculation(input_df)

    # Expected results
    # SKU 8206285: sales_proportion = 0.6 (campaign), baseline = 0.6 * 1500 = 900, incremental = 2000 - 900 = 1100
    # SKU 8206287: sales_proportion = 0.4 (campaign), baseline = 0.4 * 1500 = 600, incremental = 1000 - 600 = 400
    expected_data = [
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285",
         2000.0, 0.6, 0, 0.8, True, 1500.0, 0.6, 900.0, 1100.0),
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287",
         1000.0, 0.4, 0, 0.2, True, 1500.0, 0.4, 600.0, 400.0),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.baseline_sku_level_calculation)

    assert_df_equality(
        actual_df,
        expected_df,
        ignore_row_order=True,
        ignore_column_order=True
    )


def test_baseline_sku_level_calculation_no_pre_campaign_data(spark_session):
    """Test calculation when no pre-campaign data exists"""

    input_data = [
        # SKU with no pre-campaign data - should use campaign_sales_proportion
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285",
         2000.0, 0.6, None, None, False, 1500.0),

        # Another SKU in same cluster with no pre-campaign data
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287",
         1000.0, 0.4, None, None, False, 1500.0),
    ]

    input_df = spark_session.createDataFrame(input_data, schema.integrated_df)

    # Execute function
    actual_df = baseline_sku_level_calculation(input_df)

    # Expected results
    # SKU 8206285: sales_proportion = 0.6 (campaign), baseline = 0.6 * 1500 = 900, incremental = 2000 - 900 = 1100
    # SKU 8206287: sales_proportion = 0.4 (campaign), baseline = 0.4 * 1500 = 600, incremental = 1000 - 600 = 400
    expected_data = [
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285",
         2000.0, 0.6, None, None, False, 1500.0, 0.6, 900.0, 1100.0),
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287",
         1000.0, 0.4, None, None, False, 1500.0, 0.4, 600.0, 400.0),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.baseline_sku_level_calculation)

    assert_df_equality(
        actual_df,
        expected_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True
    )


def test_baseline_sku_level_calculation_zero_values(spark_session):
    """Test calculation with zero sales and baseline values"""

    input_data = [
        # SKU with zero total sales
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285",
         0.0, 0.6, 1, 0.8, True, 1500.0),

        # SKU with zero baseline
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "8206287",
         1000.0, 0.4, 1, 0.3, True, 0.0),

        # SKU with zero proportion
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL3", "8206289",
         500.0, 0.0, 1, 0.0, True, 1200.0),
    ]

    input_df = spark_session.createDataFrame(input_data, schema.integrated_df)

    # Execute function
    actual_df = baseline_sku_level_calculation(input_df)

    # Expected results
    expected_data = [
        # Zero total sales: baseline = 0.8 * 1500 = 1200, incremental = 0 - 1200 = -1200
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285",
         0.0, 0.6, 1, 0.8, True, 1500.0, 0.8, 1200.0, -1200.0),

        # Zero baseline: baseline = 0.3 * 0 = 0, incremental = 1000 - 0 = 1000
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL2", "8206287",
         1000.0, 0.4, 1, 0.3, True, 0.0, 0.3, 0.0, 1000.0),

        # Zero proportion: baseline = 0.0 * 1200 = 0, incremental = 500 - 0 = 500
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL3", "8206289",
         500.0, 0.0, 1, 0.0, True, 1200.0, 0.0, 0.0, 500.0),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.baseline_sku_level_calculation)

    assert_df_equality(
        actual_df,
        expected_df,
        ignore_row_order=True,
        ignore_column_order=True
    )

    """Test when pre_campaign_sales_proportion is NULL but data exists and is sufficient"""

    input_data = [
        # SKU with sufficient flag but NULL pre-campaign proportion - should fallback to campaign proportion
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285",
         2000.0, 0.6, 1, None, True, 1500.0),
    ]

    input_df = spark_session.createDataFrame(input_data, schema.integrated_df)

    # Execute function
    actual_df = baseline_sku_level_calculation(input_df)

    # Expected: should use campaign_sales_proportion due to coalesce with NULL pre-campaign
    expected_data = [
        ("booking123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285",
         2000.0, 0.6, 1, None, True, 1500.0, 0.6, 900.0, 1100.0),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.baseline_sku_level_calculation)

    assert_df_equality(
        actual_df,
        expected_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True
    )


def test_baseline_sku_level_integration_complete_flow(spark_session):
    """Test complete integration flow with all data present"""

    # Baseline data (cluster level)
    baseline_data = [
        (date(2024, 11, 25), "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", 5000.0, 3000.0, 2000.0),
        (date(2024, 11, 25), "BEVERAGES", "COKE|COCA-COLA", "CL2", 8000.0, 4500.0, 3500.0),
    ]
    baseline_df = spark_session.createDataFrame(baseline_data, schema.baseline_cluster_level)

    # SKU mapping data
    sku_mapping_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
        ("8206287", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", "MKT_HIER_001"),
        ("8206291", "BEVERAGES", "COKE|COCA-COLA", "CL2", "job789",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking456", "MKT_HIER_002"),
    ]
    sku_mapping_df = spark_session.createDataFrame(sku_mapping_data, schema.filtered_sku_cluster)

    sales_data = [
        ("booking123", date(2024, 11, 25), "8206285", 2000.0, 100, "MKT_HIER_001"),
        ("booking123", date(2024, 11, 25), "8206287", 1000.0, 50, "MKT_HIER_001"),
        ("booking456", date(2024, 11, 25), "8206291", 3000.0, 150, "MKT_HIER_002"),
    ]
    sales_df = spark_session.createDataFrame(sales_data, schema.sales_for_integration)

    # Sales proportions data
    sales_proportions_data = [
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285", 3000.0, 0.67, 1, 2500.0, 0.8),
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287", 3000.0, 0.33, 1, 2500.0, 0.2),
        ("booking456", "campaign456", "BEVERAGES", "COKE|COCA-COLA", "CL2", "8206291", 3000.0, 1.0, 0, None, None),
    ]
    sales_proportions_df = spark_session.createDataFrame(sales_proportions_data, schema.sales_proportions)

    # Pre-campaign data exists flags
    pre_campaign_data = [
        ("booking123", "campaign123", True),
        ("booking456", "campaign456", False),
    ]
    pre_campaign_df = spark_session.createDataFrame(pre_campaign_data, schema.pre_campaign_history)

    actual_df = baseline_sku_level_integration(
        baseline_df, sku_mapping_df, sales_df, sales_proportions_df, pre_campaign_df
    )

    # Expected calculations:
    # SKU 8206285: sufficient pre-campaign (1) + pre_campaign_sales_data_exists=True → use pre_campaign_sales_proportion=0.8
    #              baseline = 0.8 * 3000 = 2400, incremental = 2000 - 2400 = -400
    # SKU 8206287: sufficient pre-campaign (1) + pre_campaign_sales_data_exists=True → use pre_campaign_sales_proportion=0.2
    #              baseline = 0.2 * 3000 = 600, incremental = 1000 - 600 = 400
    # SKU 8206291: insufficient pre-campaign (0) + pre_campaign_sales_data_exists=False → use campaign_sales_proportion=1.0
    #              baseline = 1.0 * 4500 = 4500, incremental = 3000 - 4500 = -1500
    expected_data = [
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", date(2024, 11, 25), 2000.0, 100, 2400.0, -400.0, "MKT_HIER_001"),
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", date(2024, 11, 25), 1000.0, 50, 600.0, 400.0, "MKT_HIER_001"),
        ("booking456", "campaign456", "BEVERAGES", "COKE|COCA-COLA", "CL2", "8206291", "job789",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", date(2024, 11, 25), 3000.0, 150, 4500.0, -1500.0, "MKT_HIER_002"),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.baseline_sku_level_integration)

    assert_df_equality(
        actual_df,
        expected_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True
    )


def test_dtp_baseline_sku_level_integration_complete_flow(spark_session):
    """Test complete integration flow with all data present"""

    # Baseline data (cluster level)
    baseline_data = [
        (date(2024, 11, 25), "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", 5000.0, 3000.0, 2000.0),
        (date(2024, 11, 25), "BEVERAGES", "COKE|COCA-COLA", "CL2", 8000.0, 4500.0, 3500.0),
    ]
    baseline_df = spark_session.createDataFrame(baseline_data, schema.baseline_cluster_level)

    # SKU mapping data
    sku_mapping_data = [
        ("8206285", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", None),
        ("8206287", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking123", None),
        ("8206291", "BEVERAGES", "COKE|COCA-COLA", "CL2", "job789",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", "booking456", None),
    ]
    sku_mapping_df = spark_session.createDataFrame(sku_mapping_data, schema.filtered_sku_cluster)

    sales_data = [
        ("booking123", date(2024, 11, 25), "8206285", 2000.0, 100, None),
        ("booking123", date(2024, 11, 25), "8206287", 1000.0, 50, None),
        ("booking456", date(2024, 11, 25), "8206291", 3000.0, 150, None),
    ]
    sales_df = spark_session.createDataFrame(sales_data, schema.sales_for_integration)

    # Sales proportions data
    sales_proportions_data = [
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285", 3000.0, 0.67, 1, 2500.0, 0.8),
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287", 3000.0, 0.33, 1, 2500.0, 0.2),
        ("booking456", "campaign456", "BEVERAGES", "COKE|COCA-COLA", "CL2", "8206291", 3000.0, 1.0, 0, None, None),
    ]
    sales_proportions_df = spark_session.createDataFrame(sales_proportions_data, schema.sales_proportions)

    # Pre-campaign data exists flags
    pre_campaign_data = [
        ("booking123", "campaign123", True),
        ("booking456", "campaign456", False),
    ]
    pre_campaign_df = spark_session.createDataFrame(pre_campaign_data, schema.pre_campaign_history)

    actual_df = baseline_sku_level_integration(
        baseline_df, sku_mapping_df, sales_df, sales_proportions_df, pre_campaign_df
    )

    expected_data = [
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206285", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", date(2024, 11, 25), 2000.0, 100, 2400.0, -400.0, None),
        ("booking123", "campaign123", "CRISPS & SNACKS", "DORITOS|PEPSICO", "CL1", "8206287", "job456",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", date(2024, 11, 25), 1000.0, 50, 600.0, 400.0, None),
        ("booking456", "campaign456", "BEVERAGES", "COKE|COCA-COLA", "CL2", "8206291", "job789",
         datetime(2025, 8, 22, 9, 22, 28), "CLUSTERING", date(2024, 11, 25), 3000.0, 150, 4500.0, -1500.0, None),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.baseline_sku_level_integration)

    assert_df_equality(
        actual_df,
        expected_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True
    )


def test_log_missing_data_all_skus_missing(spark_session):
    """Test when all SKUs are missing for a booking"""
    mta_mmm_data = [
        ("1234567", "e209f8c6-68f2-4efb-c842-9e300f3498b8", None, "Aisle", "During"),
        ("1234568", "e209f8c6-68f2-4efb-c842-9e300f3498b8", None, "Aisle", "During"),
        ("1234569", "e209f8c6-68f2-4efb-c842-9e300f3498b8", None, "Aisle", "During"),
    ]
    mta_mmm_integration = spark_session.createDataFrame(mta_mmm_data, schema.mta_mmm)

    sku_results_data = [
        ("1234567", "e209f8c6-68f2-4efb-c842-9e300f3498b8", "Aisle", "During"),
        ("1234568", "e209f8c6-68f2-4efb-c842-9e300f3498b8", "Aisle", "During"),
        ("1234569", "e209f8c6-68f2-4efb-c842-9e300f3498b8", "Aisle", "During"),
    ]
    sku_level_results_filtered = spark_session.createDataFrame(sku_results_data, schema.sku_results)

    correlation_id = "f319a7d7-79f3-5ffc-d953-af401f459ac9"
    run_date = datetime(2023, 10, 18, 12, 0, 0)

    # Execute function
    actual_df = log_missing_data(mta_mmm_integration, sku_level_results_filtered, correlation_id, run_date)

    expected_data = [
        (
            "e209f8c6-68f2-4efb-c842-9e300f3498b8",
            "Aisle",
            "During",
            3,  # expected_sku_count
            3,  # missing_sku_count
            ["1234567", "1234568", "1234569"],  # missing_skus_list
            True,  # all_missing
            "ALL SKUs missing",  # status
            "1234567, 1234568, 1234569",  # complete_sku_list
            "f319a7d7-79f3-5ffc-d953-af401f459ac9",  # correlation_id
            datetime(2023, 10, 18, 12, 0, 0)  # load_ts
        )
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.missing_data)

    # Normalize for comparison (handle array ordering)
    actual_df_normalized = actual_df.withColumn(
        "missing_skus_list", F.sort_array("missing_skus_list")
    ).withColumn(
        "complete_sku_list",
        F.when(F.col("complete_sku_list") != "N/A",
               F.array_join(F.sort_array(F.split("complete_sku_list", ", ")), ", ")
               ).otherwise(F.col("complete_sku_list"))
    )

    expected_normalized = expected_df.withColumn(
        "missing_skus_list", F.sort_array("missing_skus_list")
    ).withColumn(
        "complete_sku_list",
        F.when(F.col("complete_sku_list") != "N/A",
               F.array_join(F.sort_array(F.split("complete_sku_list", ", ")), ", ")
               ).otherwise(F.col("complete_sku_list"))
    )

    # Use chispa to compare
    assert_df_equality(
        actual_df_normalized,
        expected_normalized,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True
    )


def test_log_zero_incrementality_only(spark_session):
    """Test when only zero incrementality exists"""

    test_data = [
        ("SKU001", "booking1", 0.0, "Online", "After"),
        ("SKU002", "booking1", 0.0, "Online", "After"),
        ("SKU003", "booking1", 25.0, "Online", "After"),  # Positive - should not be included
    ]

    baseline_attribution_df = spark_session.createDataFrame(test_data, schema.log_zero_incrementality)
    correlation_id = "test-correlation-456"
    run_date = datetime(2023, 10, 18, 12, 0, 0)

    # Execute function - unpack the tuple
    negative_df, zero_df = log_negative_or_zero_incrementality(baseline_attribution_df, correlation_id, run_date)

    # Test zero incrementality DataFrame
    expected_data = [
        ("SKU001", "booking1", "Online", "After", "test-correlation-456", datetime(2023, 10, 18, 12, 0, 0),
         "incrementality is zero"),
        ("SKU002", "booking1", "Online", "After", "test-correlation-456", datetime(2023, 10, 18, 12, 0, 0),
         "incrementality is zero"),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.log_zer_or_no_incrementality)

    # Assert zero incrementality DataFrame
    assert_df_equality(
        zero_df,  # Use zero_df instead of actual_df
        expected_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True
    )

    # Assert negative incrementality DataFrame is empty
    assert negative_df.count() == 0


def test_log_mixed_incrementality_values(spark_session):
    """Test with mixed incrementality values (negative, zero, positive)"""

    test_data = [
        ("SKU001", "booking1", -10.0, "Aisle", "During"),  # Negative
        ("SKU002", "booking1", 0.0, "Aisle", "During"),  # Zero
        ("SKU003", "booking2", -5.5, "Online", "After"),  # Negative
        ("SKU004", "booking2", 0.0, "Online", "After"),  # Zero
        ("SKU005", "booking1", 20.0, "Aisle", "During"),  # Positive - ignored
    ]

    baseline_attribution_df = spark_session.createDataFrame(test_data, schema.log_zero_incrementality)
    correlation_id = "test-correlation-789"
    run_date = datetime(2023, 10, 18, 12, 0, 0)

    # Execute function - unpack the tuple
    negative_df, zero_df = log_negative_or_zero_incrementality(baseline_attribution_df, correlation_id, run_date)

    # Test negative incrementality DataFrame
    expected_negative_data = [
        ("SKU001", "booking1", "Aisle", "During", "test-correlation-789", datetime(2023, 10, 18, 12, 0, 0),
         "incrementality is negative"),
        ("SKU003", "booking2", "Online", "After", "test-correlation-789", datetime(2023, 10, 18, 12, 0, 0),
         "incrementality is negative"),
    ]

    expected_negative_df = spark_session.createDataFrame(expected_negative_data, schema.log_zer_or_no_incrementality)

    # Test zero incrementality DataFrame
    expected_zero_data = [
        ("SKU002", "booking1", "Aisle", "During", "test-correlation-789", datetime(2023, 10, 18, 12, 0, 0),
         "incrementality is zero"),
        ("SKU004", "booking2", "Online", "After", "test-correlation-789", datetime(2023, 10, 18, 12, 0, 0),
         "incrementality is zero"),
    ]

    expected_zero_df = spark_session.createDataFrame(expected_zero_data, schema.log_zer_or_no_incrementality)

    # Use chispa to compare DataFrames
    assert_df_equality(
        negative_df,
        expected_negative_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True
    )

    assert_df_equality(
        zero_df,
        expected_zero_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True
    )


def test_replace_nulls_with_zero_all_columns_have_nulls(spark_session):
    """Test when all target columns have null values"""
    test_data = [
        ("SKU001", "booking1", None, None, None, None, None, None, None, None, None, "value1"),
        ("SKU002", "booking1", None, None, None, None, None, None, None, None, None, "value2"),
        ("SKU003", "booking2", None, None, None, None, None, None, None, None, None, None),
        # other_column null should remain
    ]

    input_df = spark_session.createDataFrame(test_data, schema.replace_null_with_zeros)

    # Execute function
    actual_df = replace_nulls_with_zero(input_df)

    # Expected result - all target columns filled with 0, other columns unchanged
    expected_data = [
        ("SKU001", "booking1", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, "value1"),
        ("SKU002", "booking1", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, "value2"),
        ("SKU003", "booking2", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, None),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema.replace_null_with_zeros)

    # Use chispa to compare DataFrames
    assert_df_equality(
        actual_df,
        expected_df,
        ignore_row_order=True,
        ignore_column_order=True,
        ignore_nullable=True
    )


@mock.patch('spark_pipeline.baseline_attribution_integration.baseline_attribution_integration_sku_level_helper.slack_utils.SlackMessenger')
def test_model_offer_product_type(mock_slack_messenger, spark_session, tmp_dir):
    """Test model function with Offer product type using chispa for DataFrame comparison"""

    mock_messenger_instance = mock.Mock()
    mock_slack_messenger.return_value = mock_messenger_instance

    temp_paths = {
        'baseline_modelling_output_path': os.path.join(tmp_dir, 'baseline_modelling_output.parquet'),
        'sku_cluster_mapping_path': os.path.join(tmp_dir, 'sku_cluster_mapping.parquet'),
        'sales_data_transformation_path': os.path.join(tmp_dir, 'sales_data_transformation.parquet'),
        'campaign_product_type_path': os.path.join(tmp_dir, 'campaign_product_type.parquet'),
        'sku_level_attributed_sales_and_units_level_path': os.path.join(tmp_dir, 'sku_level_attributed_sales_and_units_level.parquet'),
        'measurement_campaign_execution_path': os.path.join(tmp_dir, 'measurement_campaign_execution.parquet'),
    }

    # Create test data for baseline_modelling_output
    spark_session.createDataFrame([
        Row(
            week_start_dt=datetime(2023, 10, 16).date(),
            super_category_name='GROCERIES',
            unique_brand_name='TestBrand',
            cluster_num=1,
            iteration=1,
            modelling_type='CLUSTERING',
            job_run_id='job123',
            metric_name='total_sales_amt',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            cluster_type='PRODUCT',
            best_iteration='Y',
            metric_value=1000.0,
            rsq=0.85,
            wsmape=0.15,
            baseline_perc=0.7
        ),
        Row(
            week_start_dt=datetime(2023, 10, 16).date(),
            super_category_name='GROCERIES',
            unique_brand_name='TestBrand',
            cluster_num=1,
            iteration=1,
            modelling_type='CLUSTERING',
            job_run_id='job123',
            metric_name='total_baseline_amt',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            cluster_type='PRODUCT',
            best_iteration='Y',
            metric_value=700.0,
            rsq=0.85,
            wsmape=0.15,
            baseline_perc=0.7
        ),
        Row(
            week_start_dt=datetime(2023, 10, 16).date(),
            super_category_name='GROCERIES',
            unique_brand_name='TestBrand',
            cluster_num=1,
            iteration=1,
            modelling_type='CLUSTERING',
            job_run_id='job123',
            metric_name='total_incremental_amt',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            cluster_type='PRODUCT',
            best_iteration='Y',
            metric_value=300.0,
            rsq=0.85,
            wsmape=0.15,
            baseline_perc=0.7
        ),
        Row(
            week_start_dt=datetime(2023, 10, 16).date(),
            super_category_name='GROCERIES',
            unique_brand_name='TestBrand',
            cluster_num=1,
            iteration=1,
            modelling_type='CLUSTERING',
            job_run_id='job123',
            metric_name='total_seasonality_amt',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            cluster_type='PRODUCT',
            best_iteration='Y',
            metric_value=50.0,
            rsq=0.85,
            wsmape=0.15,
            baseline_perc=0.7
        )
    ]).write.mode('overwrite').parquet(temp_paths['baseline_modelling_output_path'])

    # Create test data for sku_cluster_mapping
    spark_session.createDataFrame([
        Row(
            item_cd=1001,
            super_category_name='GROCERIES',
            unique_brand_name='TestBrand',
            cluster_num=1,
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            modelling_type='CLUSTERING'
        )
    ]).write.mode('overwrite').parquet(temp_paths['sku_cluster_mapping_path'])

    # Create test data for sales_data_transformation
    spark_session.createDataFrame([
        Row(
            week_start_dt=datetime(2023, 10, 16).date(),
            item_cd=1001,
            total_sales_amt=1000.0,
            nectar_sales_amt=600.0,
            non_nectar_sales_amt=400.0,
            frequency_of_purchase=2.5,
            distinct_customer_cnt=100,
            avg_purchase_per_customer_cnt=10.0,
            online_sales_pct=0.3,
            supermarket_sales_pct=0.6,
            convenience_sales_pct=0.1,
            pack_size='Large',
            price_per_point=0.5,
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            base_price_amt=5.99
        )
    ]).write.mode('overwrite').parquet(temp_paths['sales_data_transformation_path'])

    # Create test data for campaign_product_type
    spark_session.createDataFrame([
        Row(
            item_cd=1001,
            product_type='Offer',
            channel_name='Digital',
            subchannel_name='Email',
            booking_id='booking1',
            campaign_id='camp1',
            sku_name='Test SKU',
            sub_cat_name='Dairy',
            brand_name='TestBrand',
            brand_owner_name='TestOwner',
            unique_brand_name='TestBrand',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            technical_metadata='{"test": "data"}'
        )
    ]).write.mode('overwrite').parquet(temp_paths['campaign_product_type_path'])

    # Create test data for sku_level_attributed_sales_and_units_level
    spark_session.createDataFrame([
        Row(
            campaign_id='camp1',
            channel_name='Digital',
            userjourney_id='journey1',
            loyalty_id='loyal1',
            booking_id='booking1',
            customer_journey_type='conversion',
            journey_type='Aisle',
            isconversion=True,
            normalized_weights=0.8,
            campaign_duration='During',
            event_dt=datetime(2023, 10, 16, 10, 0, 0),
            item_cd=1001,
            net_sales_amt=100.0,
            units_qty=5,
            unique_brand_name='TestBrand',
            week_start_dt=datetime(2023, 10, 16).date(),
            regression_variable=1.2,
            subchannel_name='Email',
            attributed_sales_amt=80.0,
            attributed_units_qty=4,
            attributed_recalibrated_sales_amt=85.0,
            attributed_recalibrated_units_qty=4,
            recalibration_factor=1.05,
            job_run_id='job123',
            load_ts=datetime(2023, 10, 18, 12, 0, 0),
            marketing_type='Promotional',
            campaign_start_dt=datetime(2023, 10, 16).date(),
            campaign_end_dt=datetime(2023, 10, 22).date()
        )
    ]).write.mode('overwrite').parquet(temp_paths['sku_level_attributed_sales_and_units_level_path'])

    # Create test data for measurement_campaign_execution
    spark_session.createDataFrame([
        Row(
            booking_id='booking1',
            campaign_duration='During',
            campaign_start_dt=datetime(2023, 10, 16).date(),
            campaign_end_dt=datetime(2023, 10, 22).date(),
            channel_name='Digital',
            campaign_id='camp1',
            marketing_hierarchy_cd='MKT_HIER_001',
            subchannel_name="Email"
        )
    ]).write.mode('overwrite').parquet(temp_paths['measurement_campaign_execution_path'])

    # Test parameters
    product_type = 'Offer'
    run_date = '2025-08-24'
    correlation_id = 'test-correlation-123'

    # Execute model function
    actual_df, missing_data_df, negative_zero_df = model(
        spark=spark_session,
        baseline_modelling_output_path=temp_paths['baseline_modelling_output_path'],
        sku_cluster_mapping_path=temp_paths['sku_cluster_mapping_path'],
        sales_data_transformation_path=temp_paths['sales_data_transformation_path'],
        campaign_product_type_path=temp_paths['campaign_product_type_path'],
        sku_level_attributed_sales_and_units_level_path=temp_paths['sku_level_attributed_sales_and_units_level_path'],
        measurement_campaign_execution_path=temp_paths['measurement_campaign_execution_path'],
        product_type=product_type,
        run_date=run_date,
        correlation_id=correlation_id,
        slack_topic_arn="some_topic_arn",
    )

    # actual_df.show(vertical=True)
    # assert actual_df.count() > 0

    expected_df = spark_session.createDataFrame([
        Row(
            campaign_id='camp1',
            userjourney_id='journey1',
            loyalty_id='loyal1',
            booking_id='booking1',
            customer_journey_type='conversion',
            journey_type='Aisle',
            isconversion=True,
            normalized_weights=0.8,
            campaign_duration='During',
            event_dt=datetime(2023, 10, 16, 10, 0, 0),
            net_sales_amt=100.0,
            units_qty=5,
            regression_variable=1.2,
            attributed_sales_amt=80.0,
            attributed_units_qty=4,
            frequency_of_purchase=2.5,
            online_sales_pct=0.3,
            supermarket_sales_pct=0.6,
            convenience_sales_pct=0.1,
            correlation_id='test-correlation-123',
            sum_baseline_amt=700.0,
            sum_of_sales_amt=1000.0,
            sum_of_attr_sales_amt=85.0,
            sum_of_incr_amt=300.0,
            channel_name='Digital',
            subchannel_name='Email',
            load_ts="2025-08-24",
            week_start_dt=datetime(2023, 10, 16).date(),
            item_cd=1001,
            incrementality_total=0.3,
            incrementality_exposed=3.5294117647058822,
            attributed_recalibrated_sales_amt=85.0,
            attributed_recalibrated_units_qty=4,
            unique_brand_name='TestBrand',
            baseline=700.0,
            marketing_type='Promotional',
            total_sales_amt=1000.0,
            incremental_sales_amt_exposed=300.0,
            incremental_sales_amt_total=25.5,
            incremental_units_qty_total=1.2,
            incremental_units_qty_exposed=14.117647058823529,
            nectar_sales_amt=600.0,
            non_nectar_sales_amt=400.0,
            recalibration_factor=1.05,
            marketing_hierarchy_cd='MKT_HIER_001'
        )
    ], schema.baseline_attribution_integration_sku_level)

    # Assert DataFrames are equal (ignoring row order)
    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_column_order=True, ignore_nullable=True)


def test_calculate_attributed_recalibrated_sales_raises_exception(spark_session):
    """Test that mismatch of number of campaign ids result after filtering raises ValueError"""

    # Create campaign_date wth two overlapping campaigns
    campaign_date_data = [
        ("e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec24041223a", date(2024, 4, 25), date(2024, 6, 30), date(2024, 4, 25), date(2024, 6, 30)),
        ("e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec35041332a", date(2024, 5, 25), date(2024, 6, 30), date(2024, 4, 25), date(2024, 6, 30)),
    ]

    sku_avg_window = Window.partitionBy("item_cd", "booking_id", "campaign_id")

    # Create a scneario where there is a missing campaign_id in sku_df
    mta_mmm_integration_data = [
        ("2024-12-02", 8206285, "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec24041223a", "During", "Meta",
         "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_2", "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
         "Direct", "Offer", True, 0.3, date(2024, 12, 3), 1.65, 1, "Doritos|PepsiCo", 1.2, "NA", 1.65, 1, 1.0, 0.38,
         "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae", datetime(2025, 8, 22, 11, 24, 30), "Offsite", "2024-11-29", "2024-12-05", 0, "CLUSTERING", 100.0, 50.0, 50.0,
         20.0, 0.5, 0.3, 0.7, 6.0, 100.0, 50.0, 1000.0, 1200.0),
    ]

    mta_mmm_integration_df = spark_session.createDataFrame(mta_mmm_integration_data, schema.mta_mmm_integration)
    campaign_date_df = spark_session.createDataFrame(campaign_date_data, schema.campaign_date)

    with pytest.raises(ValueError,
                       match="Mismatch in the number of campaign_ids between campaign_date and mta_mmm_integration dataframes."):
        calculate_attributed_recalibrated_sales(campaign_date_df, sku_avg_window, mta_mmm_integration_df)


def test_calculate_attributed_recalibrated_sales_values_signle_campaigns(spark_session):
    """
    Tests single campaign scenario for calculate_attributed_recalibrated_sales function
    """

    # Create campaign_date wth two overlapping campaigns
    campaign_date_data = [
        ("e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec24041223a", date(2024, 11, 29), date(2024, 12, 5), date(2024, 11, 29), date(2024, 12, 5))
    ]

    sku_avg_window = Window.partitionBy("item_cd", "booking_id", "campaign_id")

    # Create a scneario for overlapping campaign data where with overlapping dates and non overlapping dates
    mta_mmm_integration_data = [
        ("2024-12-02", 8206285, "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec24041223a", "During", "Meta",
         "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_2", "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
         "Direct", "Offer", True, 0.3, date(2024, 12, 3), 1.65, 1, "Doritos|PepsiCo", 1.2, "NA", 1.65, 1, 1.0, 0.38,
         "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae", datetime(2025, 8, 22, 11, 24, 30), "Offsite", "2024-11-29", "2024-12-05", 0, "CLUSTERING", 100.0, 50.0, 50.0,
         20.0, 0.5, 0.3, 0.7, 6.0, 100.0, 50.0, 1000.0, 1200.0),
        ("2024-12-02", 8206285, "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec24041223a", "During", "Meta",
         "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_3", "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
         "Direct", "Offer", True, 0.3, date(2024, 12, 4), 1.65, 1, "Doritos|PepsiCo", 1.2, "NA", 1.65, 1, 1.0, 0.38,
         "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae", datetime(2025, 8, 22, 11, 24, 30), "Offsite", "2024-11-29", "2024-12-05", 0, "CLUSTERING", 100.0, 50.0, 50.0,
         20.0, 0.5, 0.3, 0.7, 6.0, 100.0, 50.0, 1000.0, 1200.0),
    ]

    mta_mmm_integration_df = spark_session.createDataFrame(mta_mmm_integration_data, schema.mta_mmm_integration)
    campaign_date_df = spark_session.createDataFrame(campaign_date_data, schema.campaign_date)

    actual_df = calculate_attributed_recalibrated_sales(campaign_date_df, sku_avg_window, mta_mmm_integration_df)
    expected_df = spark_session.createDataFrame([
        Row(
            week_start_dt="2024-12-02",
            item_cd=8206285,
            booking_id="e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
            campaign_id="nec24041223a",
            campaign_duration="During",
            channel_name="Meta",
            userjourney_id="a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_2",
            loyalty_id="a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
            customer_journey_type="Direct",
            journey_type="Offer",
            isconversion=True,
            normalized_weights=0.3,
            event_dt=date(2024, 12, 3),
            net_sales_amt=1.65,
            units_qty=1,
            unique_brand_name="Doritos|PepsiCo",
            regression_variable=1.2,
            subchannel_name="NA",
            attributed_sales_amt=1.65,
            attributed_units_qty=1,
            attributed_recalibrated_sales_amt=1.0,
            attributed_recalibrated_units_qty=0.38,
            job_run_id="b682b19f-43d3-43a4-8d60-9eb5cf68c6ae",
            load_ts=datetime(2025, 8, 22, 11, 24, 30),
            marketing_type="Offsite",
            campaign_start_dt="2024-11-29",
            campaign_end_dt="2024-12-05",
            total_seasonality_amt=0,
            modelling_type="CLUSTERING",
            total_sales_amt=100.0,
            nectar_sales_amt=50.0,
            non_nectar_sales_amt=50.0,
            frequency_of_purchase=20.0,
            online_sales_pct=0.5,
            supermarket_sales_pct=0.3,
            convenience_sales_pct=0.7,
            pack_size=6.0,
            baseline=100.0,
            incremental=50.0,
            sum_baseline_amt=1000.0,
            sum_of_sales_amt=1200.0,
            sum_of_attr_sales_amt=2.0
        ),
        Row(
            week_start_dt="2024-12-02",
            item_cd=8206285,
            booking_id="e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
            campaign_id="nec24041223a",
            campaign_duration="During",
            channel_name="Meta",
            userjourney_id="a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_3",
            loyalty_id="a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
            customer_journey_type="Direct",
            journey_type="Offer",
            isconversion=True,
            normalized_weights=0.3,
            event_dt=date(2024, 12, 4),
            net_sales_amt=1.65,
            units_qty=1,
            unique_brand_name="Doritos|PepsiCo",
            regression_variable=1.2,
            subchannel_name="NA",
            attributed_sales_amt=1.65,
            attributed_units_qty=1,
            attributed_recalibrated_sales_amt=1.0,
            attributed_recalibrated_units_qty=0.38,
            job_run_id="b682b19f-43d3-43a4-8d60-9eb5cf68c6ae",
            load_ts=datetime(2025, 8, 22, 11, 24, 30),
            marketing_type="Offsite",
            campaign_start_dt="2024-11-29",
            campaign_end_dt="2024-12-05",
            total_seasonality_amt=0,
            modelling_type="CLUSTERING",
            total_sales_amt=100.0,
            nectar_sales_amt=50.0,
            non_nectar_sales_amt=50.0,
            frequency_of_purchase=20.0,
            online_sales_pct=0.5,
            supermarket_sales_pct=0.3,
            convenience_sales_pct=0.7,
            pack_size=6.0,
            baseline=100.0,
            incremental=50.0,
            sum_baseline_amt=1000.0,
            sum_of_sales_amt=1200.0,
            sum_of_attr_sales_amt=2.0
        ),
    ], schema.mta_mmm_integration_w_sum_att_sales)
    # Assert DataFrames are equal (ignoring row order)
    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_column_order=True, ignore_nullable=True)


def test_calculate_attributed_recalibrated_sales_values_multiple_campaigns(spark_session):
    """
    This test covers the scenario where there are multiple overlapping campaigns for the same sku and booking id and different SKU same booking id.
    """

    # Create campaign_date wth two overlapping campaigns
    campaign_date_data = [
        ("e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec24041223a", date(2024, 11, 29), date(2024, 12, 5), date(2024, 11, 29), date(2024, 12, 5)),
        ("e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec35041332a", date(2024, 11, 29), date(2024, 12, 31), date(2024, 11, 29), date(2024, 12, 31))
    ]

    sku_avg_window = Window.partitionBy("item_cd", "booking_id", "campaign_id")

    # Create a scneario for overlapping campaign data where with overlapping dates and non overlapping dates
    mta_mmm_integration_data = [
        ("2024-12-02", 8206285, "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec24041223a", "During", "Meta",
         "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_2", "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
         "Direct", "Offer", True, 0.3, date(2024, 12, 3), 1.65, 1, "Doritos|PepsiCo", 1.2, "NA", 1.65, 1, 1.0, 0.38,
         "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae", datetime(2025, 8, 22, 11, 24, 30), "Offsite", "2024-11-29", "2024-12-05", 0, "CLUSTERING", 100.0, 50.0, 50.0,
         20.0, 0.5, 0.3, 0.7, 6.0, 100.0, 50.0, 1000.0, 1200.0),
        ("2024-12-02", 8206285, "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec24041223a", "During", "Meta",
         "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_3", "a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
         "Direct", "Offer", True, 0.3, date(2024, 12, 4), 1.65, 1, "Doritos|PepsiCo", 1.2, "NA", 1.65, 1, 1.0, 0.38,
         "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae", datetime(2025, 8, 22, 11, 24, 30), "Offsite", "2024-11-29", "2024-12-05", 0, "CLUSTERING", 100.0, 50.0, 50.0,
         20.0, 0.5, 0.3, 0.7, 6.0, 100.0, 50.0, 1000.0, 1200.0),
        ("2024-12-02", 7206284, "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec35041332a", "During", "Meta",
         "b4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c36_2", "b4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c36",
         "Direct", "Offer", True, 0.3, date(2024, 12, 3), 1.65, 1, "Doritos|PepsiCo", 1.2, "NA", 1.65, 1, 1.0, 0.38,
         "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae", datetime(2025, 8, 22, 11, 24, 30), "Offsite", "2024-11-29", "2024-12-31", 0, "CLUSTERING", 100.0, 50.0, 50.0,
         20.0, 0.5, 0.3, 0.7, 6.0, 100.0, 50.0, 1000.0, 1200.0),
        ("2024-12-02", 8206285, "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec35041332a", "During", "Meta",
         "y4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c38_3", "y4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c38",
         "Direct", "Offer", True, 0.3, date(2024, 12, 4), 1.65, 1, "Doritos|PepsiCo", 1.2, "NA", 1.65, 1, 1.0, 0.38,
         "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae", datetime(2025, 8, 22, 11, 24, 30), "Offsite", "2024-11-29", "2024-12-31", 0, "CLUSTERING", 100.0, 50.0, 50.0,
         20.0, 0.5, 0.3, 0.7, 6.0, 100.0, 50.0, 1000.0, 1200.0),
        ("2024-12-09", 8206285, "e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006", "nec35041332a", "During", "Meta",
         "y4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c38_1", "y4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c38",
         "Direct", "Offer", True, 0.3, date(2024, 12, 12), 1.65, 1, "Doritos|PepsiCo", 1.2, "NA", 1.65, 1, 1.0, 0.38,
         "b682b19f-43d3-43a4-8d60-9eb5cf68c6ae", datetime(2025, 8, 22, 11, 24, 30), "Offsite", "2024-11-29", "2024-12-31", 0, "CLUSTERING", 100.0, 50.0, 50.0,
         20.0, 0.5, 0.3, 0.7, 6.0, 100.0, 50.0, 1000.0, 1200.0),
    ]

    mta_mmm_integration_df = spark_session.createDataFrame(mta_mmm_integration_data, schema.mta_mmm_integration)
    campaign_date_df = spark_session.createDataFrame(campaign_date_data, schema.campaign_date)

    actual_df = calculate_attributed_recalibrated_sales(campaign_date_df, sku_avg_window, mta_mmm_integration_df)

    expected_df = spark_session.createDataFrame([
        Row(
            week_start_dt="2024-12-02",
            item_cd=8206285,
            booking_id="e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
            campaign_id="nec24041223a",
            campaign_duration="During",
            channel_name="Meta",
            userjourney_id="a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_2",
            loyalty_id="a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
            customer_journey_type="Direct",
            journey_type="Offer",
            isconversion=True,
            normalized_weights=0.3,
            event_dt=date(2024, 12, 3),
            net_sales_amt=1.65,
            units_qty=1,
            unique_brand_name="Doritos|PepsiCo",
            regression_variable=1.2,
            subchannel_name="NA",
            attributed_sales_amt=1.65,
            attributed_units_qty=1,
            attributed_recalibrated_sales_amt=1.0,
            attributed_recalibrated_units_qty=0.38,
            job_run_id="b682b19f-43d3-43a4-8d60-9eb5cf68c6ae",
            load_ts=datetime(2025, 8, 22, 11, 24, 30),
            marketing_type="Offsite",
            campaign_start_dt="2024-11-29",
            campaign_end_dt="2024-12-05",
            total_seasonality_amt=0,
            modelling_type="CLUSTERING",
            total_sales_amt=100.0,
            nectar_sales_amt=50.0,
            non_nectar_sales_amt=50.0,
            frequency_of_purchase=20.0,
            online_sales_pct=0.5,
            supermarket_sales_pct=0.3,
            convenience_sales_pct=0.7,
            pack_size=6.0,
            baseline=100.0,
            incremental=50.0,
            sum_baseline_amt=1000.0,
            sum_of_sales_amt=1200.0,
            sum_of_attr_sales_amt=3.0
        ),
        Row(
            week_start_dt="2024-12-02",
            item_cd=8206285,
            booking_id="e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
            campaign_id="nec24041223a",
            campaign_duration="During",
            channel_name="Meta",
            userjourney_id="a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35_3",
            loyalty_id="a4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c35",
            customer_journey_type="Direct",
            journey_type="Offer",
            isconversion=True,
            normalized_weights=0.3,
            event_dt=date(2024, 12, 4),
            net_sales_amt=1.65,
            units_qty=1,
            unique_brand_name="Doritos|PepsiCo",
            regression_variable=1.2,
            subchannel_name="NA",
            attributed_sales_amt=1.65,
            attributed_units_qty=1,
            attributed_recalibrated_sales_amt=1.0,
            attributed_recalibrated_units_qty=0.38,
            job_run_id="b682b19f-43d3-43a4-8d60-9eb5cf68c6ae",
            load_ts=datetime(2025, 8, 22, 11, 24, 30),
            marketing_type="Offsite",
            campaign_start_dt="2024-11-29",
            campaign_end_dt="2024-12-05",
            total_seasonality_amt=0,
            modelling_type="CLUSTERING",
            total_sales_amt=100.0,
            nectar_sales_amt=50.0,
            non_nectar_sales_amt=50.0,
            frequency_of_purchase=20.0,
            online_sales_pct=0.5,
            supermarket_sales_pct=0.3,
            convenience_sales_pct=0.7,
            pack_size=6.0,
            baseline=100.0,
            incremental=50.0,
            sum_baseline_amt=1000.0,
            sum_of_sales_amt=1200.0,
            sum_of_attr_sales_amt=3.0
        ),
        Row(
            week_start_dt="2024-12-02",
            item_cd=7206284,
            booking_id="e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
            campaign_id="nec35041332a",
            campaign_duration="During",
            channel_name="Meta",
            userjourney_id="b4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c36_2",
            loyalty_id="b4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c36",
            customer_journey_type="Direct",
            journey_type="Offer",
            isconversion=True,
            normalized_weights=0.3,
            event_dt=date(2024, 12, 3),
            net_sales_amt=1.65,
            units_qty=1,
            unique_brand_name="Doritos|PepsiCo",
            regression_variable=1.2,
            subchannel_name="NA",
            attributed_sales_amt=1.65,
            attributed_units_qty=1,
            attributed_recalibrated_sales_amt=1.0,
            attributed_recalibrated_units_qty=0.38,
            job_run_id="b682b19f-43d3-43a4-8d60-9eb5cf68c6ae",
            load_ts=datetime(2025, 8, 22, 11, 24, 30),
            marketing_type="Offsite",
            campaign_start_dt="2024-11-29",
            campaign_end_dt="2024-12-31",
            total_seasonality_amt=0,
            modelling_type="CLUSTERING",
            total_sales_amt=100.0,
            nectar_sales_amt=50.0,
            non_nectar_sales_amt=50.0,
            frequency_of_purchase=20.0,
            online_sales_pct=0.5,
            supermarket_sales_pct=0.3,
            convenience_sales_pct=0.7,
            pack_size=6.0,
            baseline=100.0,
            incremental=50.0,
            sum_baseline_amt=1000.0,
            sum_of_sales_amt=1200.0,
            sum_of_attr_sales_amt=1.0
        ),
        Row(
            week_start_dt="2024-12-02",
            item_cd=8206285,
            booking_id="e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
            campaign_id="nec35041332a",
            campaign_duration="During",
            channel_name="Meta",
            userjourney_id="y4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c38_3",
            loyalty_id="y4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c38",
            customer_journey_type="Direct",
            journey_type="Offer",
            isconversion=True,
            normalized_weights=0.3,
            event_dt=date(2024, 12, 4),
            net_sales_amt=1.65,
            units_qty=1,
            unique_brand_name="Doritos|PepsiCo",
            regression_variable=1.2,
            subchannel_name="NA",
            attributed_sales_amt=1.65,
            attributed_units_qty=1,
            attributed_recalibrated_sales_amt=1.0,
            attributed_recalibrated_units_qty=0.38,
            job_run_id="b682b19f-43d3-43a4-8d60-9eb5cf68c6ae",
            load_ts=datetime(2025, 8, 22, 11, 24, 30),
            marketing_type="Offsite",
            campaign_start_dt="2024-11-29",
            campaign_end_dt="2024-12-31",
            total_seasonality_amt=0,
            modelling_type="CLUSTERING",
            total_sales_amt=100.0,
            nectar_sales_amt=50.0,
            non_nectar_sales_amt=50.0,
            frequency_of_purchase=20.0,
            online_sales_pct=0.5,
            supermarket_sales_pct=0.3,
            convenience_sales_pct=0.7,
            pack_size=6.0,
            baseline=100.0,
            incremental=50.0,
            sum_baseline_amt=1000.0,
            sum_of_sales_amt=1200.0,
            sum_of_attr_sales_amt=4.0
        ),
        Row(
            week_start_dt="2024-12-09",
            item_cd=8206285,
            booking_id="e5d5d5c73e3ce9b8904ecc9fef58ec45faae2f717e4f1b13342724d42af97006",
            campaign_id="nec35041332a",
            campaign_duration="During",
            channel_name="Meta",
            userjourney_id="y4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c38_1",
            loyalty_id="y4644f9cbbe7a3e6f5cac7f1cfeb0ab2bca8f49e8e1eecb026ed063f97c03c38",
            customer_journey_type="Direct",
            journey_type="Offer",
            isconversion=True,
            normalized_weights=0.3,
            event_dt=date(2024, 12, 12),
            net_sales_amt=1.65,
            units_qty=1,
            unique_brand_name="Doritos|PepsiCo",
            regression_variable=1.2,
            subchannel_name="NA",
            attributed_sales_amt=1.65,
            attributed_units_qty=1,
            attributed_recalibrated_sales_amt=1.0,
            attributed_recalibrated_units_qty=0.38,
            job_run_id="b682b19f-43d3-43a4-8d60-9eb5cf68c6ae",
            load_ts=datetime(2025, 8, 22, 11, 24, 30),
            marketing_type="Offsite",
            campaign_start_dt="2024-11-29",
            campaign_end_dt="2024-12-31",
            total_seasonality_amt=0,
            modelling_type="CLUSTERING",
            total_sales_amt=100.0,
            nectar_sales_amt=50.0,
            non_nectar_sales_amt=50.0,
            frequency_of_purchase=20.0,
            online_sales_pct=0.5,
            supermarket_sales_pct=0.3,
            convenience_sales_pct=0.7,
            pack_size=6.0,
            baseline=100.0,
            incremental=50.0,
            sum_baseline_amt=1000.0,
            sum_of_sales_amt=1200.0,
            sum_of_attr_sales_amt=4.0
        ),
    ], schema.mta_mmm_integration_w_sum_att_sales)

    # Assert DataFrames are equal (ignoring row order)
    assert_df_equality(actual_df, expected_df, ignore_row_order=True, ignore_column_order=True, ignore_nullable=True)


def test_negative_incrementality_not_zeroed_at_sku_level(spark_session):
    """
    Test that negative incrementality values are preserved (not zeroed) at SKU level
    by calling baseline_sku_level_calculation function.
    """
    from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, BooleanType

    # Create test data that will result in negative incrementality after calculation
    test_schema = StructType([
        StructField("booking_id", StringType(), True),
        StructField("campaign_id", StringType(), True),
        StructField("item_cd", IntegerType(), True),
        StructField("campaign_sales_proportion", DoubleType(), True),
        StructField("pre_campaign_sales_proportion", DoubleType(), True),
        StructField("cluster_baseline", DoubleType(), True),
        StructField("total_sales_amt", DoubleType(), True),
        StructField("pre_campaign_sales_data_exists", BooleanType(), True),
        StructField("sufficient_pre_campaign_sales", IntegerType(), True),
    ])

    test_data = [
        # Case where baseline > total_sales → negative incrementality
        ("B001", "C001", 123, 0.5, 0.6, 200.0, 80.0, True, 1),   # incremental = 80 - (0.6 * 200) = -40
        # Case with positive incrementality
        ("B001", "C001", 456, 0.4, 0.3, 100.0, 60.0, True, 1),   # incremental = 60 - (0.3 * 100) = 30
        # Another negative case
        ("B002", "C002", 789, 0.7, 0.8, 150.0, 50.0, True, 1),   # incremental = 50 - (0.8 * 150) = -70
    ]

    input_df = spark_session.createDataFrame(test_data, test_schema)

    # Call the actual function
    result_df = baseline_sku_level_calculation(input_df)

    # Collect results
    results = result_df.select(
        "booking_id", "item_cd", "baseline", "incremental", "total_sales_amt"
    ).collect()

    # Assert negative incrementality values are preserved (NOT zeroed)
    assert results[0]["baseline"] == 120.0   # 0.6 * 200
    assert results[0]["incremental"] == -40.0  # 80 - 120 (NEGATIVE preserved)
    assert results[0]["total_sales_amt"] == 80.0

    # Assert positive incrementality remains positive
    assert results[1]["baseline"] == 30.0    # 0.3 * 100
    assert results[1]["incremental"] == 30.0   # 60 - 30 (POSITIVE)

    # Assert another negative case is preserved
    assert results[2]["baseline"] == 120.0   # 0.8 * 150
    assert results[2]["incremental"] == -70.0  # 50 - 120 (NEGATIVE preserved)
