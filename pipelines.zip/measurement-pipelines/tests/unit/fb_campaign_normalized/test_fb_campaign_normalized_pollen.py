import os
import json
import pytest
from pyspark.sql import SparkSession, types as T

from unittest.mock import patch

from spark_pipeline.fb_campaign_normalized.fb_campaign_normalized_pollen import (
    prepare_fb_campaign_normalize, entrypoint
)

from chispa.dataframe_comparer import assert_df_equality
from tests.unit.baseline_processed_data.utils import (
    local_spark_s3_overwrite
)


@pytest.fixture
def sample_campaign_bookings(spark_session: SparkSession):

    schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_media_live_start_dt", T.StringType(), True),
        T.StructField("booking_media_live_end_dt", T.StringType(), True),
        T.StructField("channel_type", T.StringType(), True),
        T.StructField("media_provider", T.StringType(), True),
        T.StructField("booking_status", T.StringType(), True),
        T.StructField("media_business_group", T.StringType(), True),
        T.StructField("item_cd_list", T.StringType(), True),
    ])

    data = [
        # Valid META campaign example 1
        (
            "b1-a", "c1-a", "2025-05-09", "2025-05-20",
            "OFFSITE", "META", "COMPLETED", "sainsburys",
            json.dumps([{"skuId": 2374130}, {"skuId": 7783540}])
        ),
        # Valid META campaign example 2
        (
            "b1-b", "c1-b", "2025-03-09", "2025-07-14",
            "OFFSITE", "META", "COMPLETED", "sainsburys",
            json.dumps([{"skuId": 3374130}, {"skuId": 8783540}, {"skuId": 1783540}])
        ),
        # Wrong media provider (channel)
        (
            "b2", "c2", "2025-07-11", "2025-07-13",
            "OFFSITE", "DV360", "COMPLETED", "sainsburys",
            json.dumps([{"skuId": 6851815}])
        ),
        # Wrong channel type (marketing type)
        (
            "b3", "c3", "2025-04-27", "2025-04-30",
            "ONSITE", "META", "COMPLETED", "sainsburys",
            json.dumps([{"skuId": 8206719}])
        ),
        # Wrong status
        (
            "b4", "c4", "2025-06-01", "2025-06-10",
            "OFFSITE", "META", "IN_SETUP", "sainsburys",
            json.dumps([{"skuId": 603263}])
        ),
        # Wrong media business group
        (
            "b5", "c5", "2025-06-01", "2025-06-10",
            "OFFSITE", "META", "IN_SETUP", "argos",
            json.dumps([{"skuId": 603263}])
        ),
        # Wrong campaign id
        (
            "b1-a", "-1", "2025-05-09", "2025-05-20",
            "OFFSITE", "META", "COMPLETED", "sainsburys",
            json.dumps([{"skuId": 2374130}, {"skuId": 7783540}])
        ),
    ]

    return spark_session.createDataFrame(data, schema=schema)


def test_prepare_fb_campaign_normalize(spark_session, sample_campaign_bookings, tmp_dir):

    # Expected DataFrame schema and data
    schema = T.StructType([
        T.StructField("start_dt", T.StringType(), True),
        T.StructField("end_dt", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("jobbagid", T.StringType(), True),
        T.StructField("channel", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
    ])

    expected_data = [
        ("2025-05-09", "2025-05-20", "2374130", "b1-a", "NA", "Facebook", "c1-a"),
        ("2025-05-09", "2025-05-20", "7783540", "b1-a", "NA", "Facebook", "c1-a"),
        ("2025-03-09", "2025-07-14", "3374130", "b1-b", "NA", "Facebook", "c1-b"),
        ("2025-03-09", "2025-07-14", "8783540", "b1-b", "NA", "Facebook", "c1-b"),
        ("2025-03-09", "2025-07-14", "1783540", "b1-b", "NA", "Facebook", "c1-b"),
    ]
    expected_df = spark_session.createDataFrame(expected_data, schema=schema)
    # Write the test input DataFrame to a temporary Parquet file
    input_path = os.path.join(tmp_dir, "campaign_bookings_path.parquet")
    sample_campaign_bookings.write.mode("overwrite").parquet(input_path)
    # Create an output path to store out results
    output_path = os.path.join(tmp_dir, "output")

    with patch(
        "spark_pipeline.fb_campaign_normalized.fb_campaign_normalized_pollen.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        # Run transformation
        prepare_fb_campaign_normalize(
            spark=spark_session,
            campaign_bookings_path=input_path,
            output_path=output_path,
            correlation_id="NA"
        )

        # Read back results
        actual_df = spark_session.read.parquet(output_path)

        # Compare with chispa
        assert_df_equality(expected_df, actual_df, ignore_row_order=True, ignore_column_order=False)


def test_entrypoint_invokes_main_function(spark_session):
    with patch("spark_pipeline.fb_campaign_normalized.fb_campaign_normalized_pollen.prepare_fb_campaign_normalize") as mock_prepare:
        args = [
            "--campaign-bookings-path", "s3a://input/fb",
            "--output-path", "s3a://output/fb",
            "--correlation-id", "NA"
        ]

        entrypoint(spark_session, command_line_args=args)

        mock_prepare.assert_called_once_with(
            spark=spark_session,
            campaign_bookings_path="s3a://input/fb",
            output_path="s3a://output/fb",
            correlation_id="NA"
        )
