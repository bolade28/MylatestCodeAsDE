import os
import pytest
from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType, DateType
from datetime import date
from unittest.mock import patch
from spark_pipeline.fb_campaign_normalized.fb_campaign_normalized import (
    prepare_fb_campaign_normalize, entrypoint
)
from tests.unit.baseline_processed_data.utils import (
    local_spark_s3_overwrite
)


@pytest.fixture
def sample_input_df(spark_session: SparkSession):
    return spark_session.createDataFrame([
        Row(
            CAMPAIGN_ID="12345",
            CAMPAIGN_START_TS="2024-01-01",
            CAMPAIGN_END_TS="2024-01-10",
            CAMPAIGN_NAME="Spring Launch",
            MEASUREMENT_SKU_LIST='[\"122\"]',
            JOB_BAG_ID="nec123a"
        ),
        Row(
            CAMPAIGN_ID="54321",
            CAMPAIGN_START_TS="2024-02-01",
            CAMPAIGN_END_TS="2024-02-10",
            CAMPAIGN_NAME="Dummy Campaign",
            MEASUREMENT_SKU_LIST='[\"7637944\",\"6536708\",\"7104021\",\"8148582\",\"6369429\"]',
            JOB_BAG_ID="nec456a"
        ),
        Row(
            CAMPAIGN_ID="78901",
            CAMPAIGN_START_TS="2024-03-01",
            CAMPAIGN_END_TS="2024-03-10",
            CAMPAIGN_NAME="March Madness",
            MEASUREMENT_SKU_LIST='[\"7637944\",\"6536708\",\"7104021\",\"8148582\",\"6369429\"]',
            JOB_BAG_ID=None  # To test JOBBAGID isNotNull condition
        )
    ])


def test_prepare_fb_campaign_normalize(spark_session, sample_input_df, tmp_path):

    schema = StructType([
                        StructField("START_DT", DateType(), True),
                        StructField("END_DT", DateType(), True),
                        StructField("ITEM_CD", StringType(), True),
                        StructField("JOBBAGID", StringType(), True),
                        StructField("CHANNEL", StringType(), True),
                        StructField("CAMPAIGN_ID", StringType(), True)])

    # Define the data
    data = [
        (date(2024, 1, 1), date(2024, 1, 10), "122", "nec123a", "Facebook", "12345"),
        (date(2024, 2, 1), date(2024, 2, 10), "6369429", "nec456a", "Facebook", "54321"),
        (date(2024, 2, 1), date(2024, 2, 10), "6536708", "nec456a", "Facebook", "54321"),
        (date(2024, 2, 1), date(2024, 2, 10), "7104021", "nec456a", "Facebook", "54321"),
        (date(2024, 2, 1), date(2024, 2, 10), "7637944", "nec456a", "Facebook", "54321"),
        (date(2024, 2, 1), date(2024, 2, 10), "8148582", "nec456a", "Facebook", "54321"),
    ]

    expected_df = spark_session.createDataFrame(data, schema=schema)

    with patch(
        "spark_pipeline.fb_campaign_normalized.fb_campaign_normalized.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        input_path = os.path.join(tmp_path, "fb_campaign.parquet")
        sample_input_df.write.parquet(input_path)
        output_path = os.path.join(tmp_path, "output.parquet")

        actual_df = prepare_fb_campaign_normalize(
            spark=spark_session,
            fb_campaign=input_path,
            output_path=output_path,
            run_date="2024-01-01"
        )

        is_equal = expected_df.toPandas().equals(actual_df.toPandas())
        assert is_equal


def test_entrypoint_invokes_main_function(spark_session):
    with patch("spark_pipeline.fb_campaign_normalized.fb_campaign_normalized.prepare_fb_campaign_normalize") as mock_prepare:
        args = [
            "--fb-campaign", "s3a://input/fb",
            "--output-path", "s3a://output/fb",
            "--run-date", "2024-06-20"
        ]
        entrypoint(spark_session, command_line_args=args)

        mock_prepare.assert_called_once_with(
            spark=spark_session,
            fb_campaign="s3a://input/fb",
            output_path="s3a://output/fb",
            run_date="2024-06-20"
        )
