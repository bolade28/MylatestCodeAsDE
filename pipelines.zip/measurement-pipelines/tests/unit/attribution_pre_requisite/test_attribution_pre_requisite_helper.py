import os
from decimal import Decimal
from datetime import datetime
from pyspark.sql import Row
from chispa.dataframe_comparer import assert_df_equality
from spark_pipeline.schemas.attribution_pre_requisite import AttributionPreRequisiteSchema
from spark_pipeline.schemas.user_journey import UserJourney

from spark_pipeline.attribution_pre_requisite.attribution_pre_requisite_helper import create_clean_regvarlist_expr, \
    create_attribution_pre_requisite
from pyspark.sql import SparkSession


def test_basic_concatenation_and_cleaning(spark_session: SparkSession):
    '''Test basic concatenation and character replacement'''
    # Create sample DataFrame with proper column names
    data = [
        ('email-newsletter', 'camp-123|promo'),
        ('facebook-ads', 'summer-sale'),
        ('print-media', 'holiday_2024'),
        ('mobile app', 'flash|sale,today'),
        ('web', 'seo-campaign'),
        (None, 'null-test')  # Test None handling - concat_ws skips None
    ]

    # Method 1: Create DataFrame with 2 columns
    sample_df = spark_session.createDataFrame(data, ['subchannel_name', 'campaign_id'])

    columns_to_concat = ['subchannel_name', 'campaign_id']

    # Apply the function
    regvarlist_expr = create_clean_regvarlist_expr(columns_to_concat)
    result_df = sample_df.withColumn('regvarlist', regvarlist_expr)

    # Collect results
    results = [row.regvarlist for row in result_df.collect()]

    # Expected results after cleaning - all special chars replaced with underscores
    expected = [
        'email_newsletter_camp_123_promo',
        'facebook_ads_summer_sale',
        'print_media_holiday_2024',
        'mobile_app_flash_sale_today',
        'web_seo_campaign',
        'null_test'  # concat_ws skips None, so only campaign_id remains
    ]

    assert results == expected


def test_empty_and_null_values(spark_session: SparkSession):
    '''Test handling of empty and null values'''
    data = [
        ('', None, 'valid'),
        (None, '', 'another'),
        ('', '', ''),
        (None, None, None)
    ]

    df = spark_session.createDataFrame(data, ['col1', 'col2', 'col3'])
    regvarlist_expr = create_clean_regvarlist_expr(['col1', 'col2', 'col3'])
    result_df = df.withColumn('regvarlist', regvarlist_expr)

    results = [row.regvarlist for row in result_df.collect()]

    # PySpark concat_ws handles nulls by ignoring them
    expected = [
        '_valid',  # empty + null + 'valid'
        '_another',  # null + empty + 'another'
        '__',  # empty + empty + empty
        ''  # null + null + null
    ]

    assert results == expected


def test_special_characters_replacement(spark_session: SparkSession):
    '''Test all special character replacements'''
    test_cases = [
        ('space test', 'space_test'),
        ('hyphen-test', 'hyphen_test'),
        ('comma,test', 'comma_test'),
        ('pipe|test', 'pipe_test'),
        ('mixed -,| test', 'mixed_____test'),
        ('special@#$%chars', 'special____chars'),  # Non-alphanumeric replaced with underscores
        ('keep_underscores_123', 'keep_underscores_123'),  # Underscores and numbers kept
    ]

    for input_val, expected in test_cases:
        data = [(input_val,)]
        df = spark_session.createDataFrame(data, ['test_col'])

        regvarlist_expr = create_clean_regvarlist_expr(['test_col'])
        result_df = df.withColumn('regvarlist', regvarlist_expr)

        result = result_df.collect()[0].regvarlist
        assert result == expected, f'Failed for input: {input_val}, expected: {expected}, got: {result}'


def test_create_attribution_pre_requisite(spark_session: SparkSession, tmpdir):
    '''Test standard case with valid journey data and campaign execution'''

    measurement_campaign_execution_path = os.path.join(tmpdir, 'measurement_campaign_execution.parquet')
    user_journey_path = os.path.join(tmpdir, 'user_journey.parquet')

    spark_session.createDataFrame([
        Row(booking_id='booking_123', campaign_duration='30-days', job_status='In-progress'),
        Row(booking_id='booking_456', campaign_duration='7-days', job_status='Completed'),  # Should be filtered out
    ]).write.mode('overwrite').parquet(measurement_campaign_execution_path)

    spark_session.createDataFrame([
        Row(
            loyalty_id='user_001',
            transaction_key='tx_001',
            event_ts=datetime(2024, 1, 1, 10, 0, 0),
            purchase_type='',
            channel_name='email',
            subchannel_name='newsletter',
            event_name='Touchpoint',
            booking_id='booking_123',
            campaign_id='camp_001',
            sub_path=1,
            userjourney_id='journey_001',
            rank=1,
            position='1',
            isconversion=0,
            load_ts=datetime(2024, 1, 1, 12, 0, 0),
            campaign_duration='30-days',
            job_run_id='job_001',
            marketing_type='email_marketing',
            net_sales_amt=Decimal('100.50'),
            units_qty=Decimal('1.0'),
            journey_type='Brand'
        ),
        Row(
            loyalty_id='user_001',
            transaction_key='tx_002',
            event_ts=datetime(2024, 1, 2, 11, 0, 0),
            purchase_type='',
            channel_name='social',
            subchannel_name='facebook',
            event_name='Touchpoint',
            booking_id='booking_123',
            campaign_id='camp_002',
            sub_path=2,
            userjourney_id='journey_001',
            rank=2,
            position='2',
            isconversion=1,
            load_ts=datetime(2024, 1, 1, 12, 0, 0),
            campaign_duration='30-days',
            job_run_id='job_001',
            marketing_type='social_media',
            net_sales_amt=Decimal('200.75'),
            units_qty=Decimal('2.0'),
            journey_type='Brand'
        )
    ]).write.mode('overwrite').parquet(user_journey_path)

    result = create_attribution_pre_requisite(
        spark=spark_session,
        measurement_campaign_execution_path=measurement_campaign_execution_path,
        user_journey_type_path=user_journey_path,
        journey_type='Aisle',
        run_date='2024-01-15',
        correlation_id='test_corr_123'
    )

    # Expected results
    expected_df = spark_session.createDataFrame([
        Row(
            loyalty_id='user_001',
            marketing_type='email_marketing',
            channel_name='email',
            subchannel_name='newsletter',
            purchase_type='',
            event_ts=datetime(2024, 1, 1, 10, 0, 0),
            event_name='Touchpoint',
            net_sales_amt=Decimal('100.5000'),
            transaction_key='tx_001',
            campaign_id='camp_001',
            booking_id='booking_123',
            userjourney_id='journey_001',
            position='1',
            isconversion=0,
            campaign_duration='30-days',
            journey_type='Aisle',
            customer_journey_type='Non-direct',
            regression_variable='email_marketing_newsletter_camp_001',
            load_ts=datetime(2024, 1, 15, 0, 0, 0),
            job_run_id='test_corr_123'
        ),
        Row(
            loyalty_id='user_001',
            marketing_type='social_media',
            channel_name='social',
            subchannel_name='facebook',
            purchase_type='',
            event_ts=datetime(2024, 1, 2, 11, 0, 0),
            event_name='Touchpoint',
            net_sales_amt=Decimal('200.7500'),
            transaction_key='tx_002',
            campaign_id='camp_002',
            booking_id='booking_123',
            userjourney_id='journey_001',
            position='2',
            isconversion=1,
            campaign_duration='30-days',
            journey_type='Aisle',
            customer_journey_type='Non-direct',
            regression_variable='social_media_facebook_camp_002',
            load_ts=datetime(2024, 1, 15, 0, 0, 0),
            job_run_id='test_corr_123'
        )
    ], AttributionPreRequisiteSchema.attribution_pre_requisite_schema)

    assert_df_equality(
        result,
        expected_df,
        ignore_row_order=True,
        ignore_nullable=True
    )


def test_direct_journey_single_touchpoint(spark_session: SparkSession, tmpdir):
    '''Test Non-Direct classification with single touchpoint'''

    measurement_campaign_execution_path = os.path.join(tmpdir, 'measurement_campaign_execution.parquet')
    user_journey_path = os.path.join(tmpdir, 'user_journey.parquet')

    spark_session.createDataFrame([
        Row(booking_id='booking_direct', campaign_duration='7-days', job_status='In-progress')
    ]).write.mode('overwrite').parquet(measurement_campaign_execution_path)

    spark_session.createDataFrame([
        Row(
            loyalty_id='user_direct',
            transaction_key='tx_direct',
            event_ts=datetime(2024, 1, 1, 10, 0, 0),
            channel_name='direct',
            subchannel_name=None,  # Test null handling
            event_name='Touchpoint',
            booking_id='booking_direct',
            campaign_id='camp_direct',
            sub_path=1,
            userjourney_id='journey_direct',
            rank=1,
            position='1',
            isconversion=1,
            load_ts=datetime(2024, 1, 1, 12, 0, 0),
            campaign_duration='7-days',
            job_run_id='job_direct',
            marketing_type='direct_mail',
            net_sales_amt=Decimal('150.25'),
            units_qty=Decimal('1.0'),
            journey_type='Brand',
            purchase_type='',
        )
    ], UserJourney.UserJourneySchema).write.mode('overwrite').parquet(user_journey_path)

    result = create_attribution_pre_requisite(
        spark=spark_session,
        measurement_campaign_execution_path=measurement_campaign_execution_path,
        user_journey_type_path=user_journey_path,
        journey_type='Aisle',
        run_date='2024-01-15',
        correlation_id='test_direct_123'
    )

    expected_data = [
        Row(
            loyalty_id='user_direct',
            marketing_type='direct_mail',
            channel_name='direct',
            subchannel_name='NA',  # Null becomes 'NA' after regvar is created
            purchase_type='',
            event_ts=datetime(2024, 1, 1, 10, 0, 0),
            event_name='Touchpoint',
            net_sales_amt=Decimal('150.2500'),
            transaction_key='tx_direct',
            campaign_id='camp_direct',
            booking_id='booking_direct',
            userjourney_id='journey_direct',
            position='1',
            isconversion=1,
            campaign_duration='7-days',
            journey_type='Aisle',
            customer_journey_type='Non-direct',
            regression_variable='direct_mail_camp_direct',  # concat_ws skips null subchannel
            load_ts=datetime(2024, 1, 15, 0, 0, 0),
            job_run_id='test_direct_123'
        )
    ]
    expected_df = spark_session.createDataFrame(expected_data, AttributionPreRequisiteSchema.attribution_pre_requisite_schema)

    assert_df_equality(
        result,
        expected_df,
        ignore_row_order=True,
        ignore_nullable=True
    )
