import os
from decimal import Decimal
from unittest import mock
from unittest.mock import patch
from pyspark.sql import SparkSession

from spark_pipeline.attribution_pre_requisite.attribution_pre_requisite import (
    prepare_attribution_pre_requisite,
    entrypoint,
)
from pyspark.sql import Row
from datetime import datetime

from spark_pipeline.schemas.user_journey import UserJourney


def test_prepare_attribution_pre_requisite(spark_session: SparkSession, tmpdir: str):
    measurement_campaign_execution_path = os.path.join(tmpdir, "measurement_campaign_execution.parquet")
    user_journey_type_path = os.path.join(tmpdir, "user_journey_type.parquet")
    output_path = os.path.join(tmpdir, "output_path.parquet")
    run_date = "2024-01-01"
    correlation_id = "corr-123"

    spark_session.createDataFrame([
        Row(booking_id='booking_direct', campaign_duration='7-days', job_status='In-progress')
    ]).write.mode('overwrite').parquet(measurement_campaign_execution_path)

    spark_session.createDataFrame([
        Row(
            loyalty_id='user_direct',
            transaction_key='tx_direct',
            event_ts=datetime(2024, 1, 1, 10, 0, 0),
            channel_name='direct',
            subchannel_name=None,  # Test null handling
            event_name='Touchpoint',
            booking_id='booking_direct',
            campaign_id='123',
            sub_path=1,
            userjourney_id='journey_direct',
            rank=1,
            position='1',
            isconversion=1,
            load_ts=datetime(2024, 1, 1, 12, 0, 0),
            campaign_duration='7-days',
            job_run_id='job_direct',
            marketing_type='direct_mail',
            net_sales_amt=Decimal('150.25'),
            units_qty=Decimal('1.0'),
            journey_type='Brand',
            purchase_type='',
        )
    ], UserJourney.UserJourneySchema).write.mode('overwrite').parquet(user_journey_type_path)

    with patch(
        "spark_pipeline.attribution_pre_requisite.attribution_pre_requisite.spark_s3_overwrite"
    ) as mock_s3_write:

        def fake_s3_write(path, df):
            df.write.mode("overwrite").parquet(path)

        mock_s3_write.side_effect = fake_s3_write
        prepare_attribution_pre_requisite(
            spark=spark_session,
            measurement_campaign_execution_path=measurement_campaign_execution_path,
            user_journey_path=user_journey_type_path,
            output_path=output_path,
            journey_type="Aisle",
            run_date=run_date,
            correlation_id=correlation_id,
            slack_topic_arn="some_topic_arn"
        )

    actual_df = spark_session.read.parquet(output_path)
    assert actual_df.count() > 0


def test_entrypoint(monkeypatch):
    mock_spark = mock.Mock()

    args = [
        "--measurement-campaign-execution-path", "measurement_campaign_execution",
        "--user-journey-path", "user_journey_aisle",
        "--output-path", "output_path",
        "--journey-type", "Aisle",
        "--run-date", "2024-01-01",
        "--correlation-id", "corr-123",
        "--slack-topic-arn", "some_topic_arn"
    ]

    with mock.patch(
            "spark_pipeline.attribution_pre_requisite.attribution_pre_requisite.prepare_attribution_pre_requisite") as mock_func:
        entrypoint(spark=mock_spark, command_line_args=args)

        mock_func.assert_called_once_with(
            spark=mock_spark,
            measurement_campaign_execution_path="measurement_campaign_execution",
            user_journey_path="user_journey_aisle",
            output_path="output_path",
            journey_type="Aisle",
            run_date="2024-01-01",
            slack_topic_arn="some_topic_arn",
            correlation_id="corr-123"
        )
