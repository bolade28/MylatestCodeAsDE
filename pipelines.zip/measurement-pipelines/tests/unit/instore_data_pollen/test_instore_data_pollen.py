import os
from datetime import date, datetime
from unittest.mock import patch

import pytest
from pyspark.errors import AnalysisException
from pyspark.sql import SparkSession

from spark_pipeline.common.throwing_argument_parser import ArgumentParserError
from spark_pipeline.instore_data_pollen.instore_data import entrypoint, prepare_instore_data_pollen
from spark_pipeline.schemas.instore_data_pollen import InStoreDataPollen

MODULE = "spark_pipeline.instore_data_pollen.instore_data"


@pytest.fixture
def input_paths(spark_session: SparkSession, tmp_dir: str) -> dict:
    """
    One in-store campaign (c1, stores 100 and 200, targeted item i1) and one customer (L1) with:
    - t2: in-store visit buying a non-targeted item (first touch, 2026-01-03 09:00)
    - t1: in-store purchase of the targeted item
    - t3: online purchase of the targeted item after the first touch
    """
    def write(name, rows, schema):
        path = os.path.join(tmp_dir, name)
        spark_session.createDataFrame(rows, schema).write.parquet(path)
        return path

    return {
        "measurement_campaign_execution_status_path": write(
            "mce",
            [("camp", "ch", "sub", date(2026, 1, 1), date(2026, 1, 31), "c1", "b1", "During", "mt", 10, "b1")],
            "campaign_name string, channel_name string, subchannel_name string, campaign_start_dt date, "
            "campaign_end_dt date, campaign_id string, booking_id string, campaign_duration string, "
            "marketing_type string, marketing_hierarchy_cd int, job_bag_number string",
        ),
        "measurement_unified_campaign_pollen_path": write(
            "unified_campaign",
            [("c1", "b1", "ch", "sub", "mt", date(2026, 1, 1), date(2026, 1, 31), date(2026, 1, 31))],
            "campaign_id string, job_bag_number string, channel_name string, subchannel_name string, "
            "marketing_type string, campaign_start_dt date, campaign_end_dt date, post_campaign_dt date",
        ),
        "campaign_booking_media_channel_path": write(
            "campaign_booking_media_channel",
            [("c1", "b1", '["100", 200]')],
            "campaign_id string, booking_id string, store_cd_list string",
        ),
        "campaign_product_type_path": write(
            "campaign_product_type",
            [("c1", "ch", "sub", datetime(2026, 1, 1), "pt", "brand", "i1")],
            "campaign_id string, channel_name string, subchannel_name string, load_ts timestamp, "
            "product_type string, unique_brand_name string, item_cd string",
        ),
        "fact_sale_transaction_basket_path": write(
            "basket",
            [
                (datetime(2026, 1, 5, 10), "h1", "t1", date(2026, 1, 5), 1),
                (datetime(2026, 1, 3, 9), "h1", "t2", date(2026, 1, 3), 1),
                (datetime(2026, 1, 6, 9), "h1", "t3", date(2026, 1, 6), 2),
            ],
            "transaction_end_ts timestamp, nectar_card_num_hash string, transaction_id string, "
            "transaction_dt date, sales_origination_channel_cd int",
        ),
        "fact_sale_transaction_item_path": write(
            "item",
            [
                ("t1", date(2026, 1, 5), "i1", 5.5, 2, 1, "100"),
                ("t2", date(2026, 1, 3), "i9", 3.0, 1, 1, "200"),
                ("t3", date(2026, 1, 6), "i1", 4.0, 1, 1, "999"),
            ],
            "transaction_id string, transaction_dt date, item_cd string, net_retail_sales_amt double, "
            "item_qty int, item_sequence_num int, store_cd string",
        ),
        "dim_customer_loyalty_path": write(
            "dim_customer_loyalty",
            [("L1", "5", "NECTAR", "h1")],
            "nectar_collector_card_num string, household_num string, customer_account_type_name string, "
            "customer_loyalty_cd string",
        ),
        "customer_data_collection_path": write(
            "customer_data_collection",
            [("during-1", "L2", "c1", "ch", "sub", "mt", date(2026, 1, 5))],
            "job_run_id string, loyalty_id string, campaign_id string, channel_name string, "
            "subchannel_name string, marketing_type string, event_dt date",
        ),
    }


def run_prepare(spark_session: SparkSession, input_paths: dict, **overrides):
    written = {}

    def fake_s3_write(path, df):
        written["df"] = df
        written["rows"] = df.collect()

    kwargs = dict(
        spark=spark_session,
        output_path="s3://bucket/instore_data",
        correlation_id="corr-1",
        hierarchy_codes=[10],
        sales_origination_all_codes=[1, 2],
        sales_origination_instore_codes=[1],
        sales_origination_online_codes=[2],
        campaign_duration_is_post=False,
        transaction_event_name="transaction",
        touchpoint_event_name="touchpoint",
        **input_paths,
    )
    kwargs.update(overrides)

    with patch(f"{MODULE}.spark_s3_overwrite", side_effect=fake_s3_write):
        prepare_instore_data_pollen(**kwargs)
    return written


def test_prepare_instore_data_pollen_writes_all_event_rows(spark_session: SparkSession, input_paths: dict):
    written = run_prepare(spark_session, input_paths)

    assert sorted(
        (row.transaction_key, row.event_name, row.purchase_type, row.campaign_id, row.event_ts)
        for row in written["rows"]
    ) == [
        ("NA", "touchpoint", "", "c1", datetime(2026, 1, 3, 9)),  # non-converted in-store visit
        ("t1", "touchpoint", "", "c1", datetime(2026, 1, 5, 10)),  # converted in-store touchpoint
        ("t1", "transaction", "instore", "c1", datetime(2026, 1, 5, 10)),
        ("t3", "touchpoint", "", "c1", datetime(2026, 1, 3, 9)),  # online touchpoint at first in-store touch
        ("t3", "transaction", "online", "", datetime(2026, 1, 6, 9)),
    ]
    assert all(row.job_run_id == "corr-1" for row in written["rows"])


def test_prepare_instore_data_pollen_post_run_drops_instore_purchases_of_new_customers(
    spark_session: SparkSession, input_paths: dict
):
    # The During run only saw L2, so L1's in-store purchase is not counted in the Post run
    written = run_prepare(
        spark_session, input_paths, campaign_duration_is_post=True, during_correlation_id="during-1"
    )

    assert written["rows"]
    assert not [row for row in written["rows"] if row.purchase_type == "instore"]


def test_prepare_instore_data_pollen_writes_empty_output_without_campaigns(
    spark_session: SparkSession, input_paths: dict
):
    written = run_prepare(spark_session, input_paths, hierarchy_codes=[999])

    assert written["rows"] == []
    assert written["df"].schema == InStoreDataPollen.schema


def test_prepare_instore_data_pollen_raises_on_error(spark_session: SparkSession, input_paths: dict):
    with pytest.raises(AnalysisException, match="/does/not/exist"):
        run_prepare(spark_session, input_paths, dim_customer_loyalty_path="/does/not/exist")


ENTRYPOINT_ARGS = [
    "--measurement-campaign-execution-status-path", "mce",
    "--measurement-unified-campaign-pollen-path", "unified",
    "--campaign-booking-media-channel-path", "media",
    "--campaign-product-type-path", "product",
    "--fact-sale-transaction-basket-path", "basket",
    "--fact-sale-transaction-item-path", "item",
    "--dim-customer-loyalty-path", "loyalty",
    "--output-path", "s3://bucket/instore_data",
    "--correlation-id", "corr-1",
    "--hierarchy-codes", "2011", "2020",
    "--sales-origination-all-codes", "14", "16", "17",
    "--sales-origination-instore-codes", "14", "16",
    "--sales-origination-online-codes", "17",
    "--transaction-event-name", "transaction",
    "--touchpoint-event-name", "touchpoint",
]


def test_entrypoint_parses_codes_as_ints():
    with patch(f"{MODULE}.prepare_instore_data_pollen") as mock_prepare:
        entrypoint(spark=None, command_line_args=ENTRYPOINT_ARGS + ["--campaign-duration-is-post", "false"])

    kwargs = mock_prepare.call_args.kwargs
    assert kwargs["hierarchy_codes"] == [2011, 2020]
    assert kwargs["sales_origination_all_codes"] == [14, 16, 17]
    assert kwargs["sales_origination_instore_codes"] == [14, 16]
    assert kwargs["sales_origination_online_codes"] == [17]
    assert kwargs["campaign_duration_is_post"] is False


def test_entrypoint_post_run_requires_during_inputs():
    with patch(f"{MODULE}.prepare_instore_data_pollen") as mock_prepare:
        with pytest.raises(ArgumentParserError, match="--during-correlation-id"):
            entrypoint(spark=None, command_line_args=ENTRYPOINT_ARGS + ["--campaign-duration-is-post", "true"])

    mock_prepare.assert_not_called()
