from datetime import date, datetime
from decimal import Decimal

from pyspark.sql import DataFrame, SparkSession

from spark_pipeline.instore_data_pollen.instore_data_helper import (
    create_campaign_date_range,
    create_store_location,
    finalise_instore_data,
    get_campaign_window_baskets,
    get_campaign_window_items,
    get_channel_transactions,
    get_in_scope_campaigns,
    get_instore_converted_touchpoints,
    get_instore_nonconverted_touchpoints,
    get_instore_relevant_transactions,
    get_loyalty_transactions,
    get_min_timestamp,
    get_online_touchpoints,
    get_online_transactions,
    get_post_period_customers,
    get_store_location,
    get_targeted_skus,
    get_unified_campaigns,
    get_unified_data,
)
from spark_pipeline.schemas.instore_data_pollen import InStoreDataPollen

INSTORE_CODES = [1]
ONLINE_CODES = [2]

CAMPAIGN_DETAILS_SCHEMA = (
    "campaign_name string, channel_name string, subchannel_name string, campaign_start_dt date, "
    "campaign_end_dt date, campaign_id string, booking_id string, campaign_duration string, "
    "marketing_type string, marketing_hierarchy_cd int"
)
LOYALTY_TRANSACTIONS_SCHEMA = (
    "loyalty_id string, transaction_id string, transaction_dt date, transaction_end_ts timestamp, "
    "sales_origination_channel_cd int, item_cd string, net_retail_sales_amt double, item_qty int, "
    "item_sequence_num int, store_cd string"
)
TARGETED_SKUS_SCHEMA = (
    "sku_product_type string, sku_brand_name string, sku_item_cd string, sku_campaign_id string, "
    "sku_channel_name string, sku_subchannel_name string"
)
STORE_LOCATION_SCHEMA = "location_key string, campaign_id string"
UNIFIED_DATA_SCHEMA = "uc_campaign_id string, uc_campaign_start_dt date, uc_campaign_end_dt date"
MIN_TIMESTAMP_SCHEMA = "loyalty_id string, campaign_id string, event_ts timestamp"
POST_PERIOD_CUSTOMERS_SCHEMA = (
    "post_loyalty_id string, post_campaign_id string, post_channel_name string, "
    "post_subchannel_name string, post_marketing_type string"
)


def campaign_row(campaign_duration="During", marketing_hierarchy_cd=10):
    return ("camp", "ch", "sub", date(2026, 1, 1), date(2026, 1, 31), "c1", "b1",
            campaign_duration, "mt", marketing_hierarchy_cd)


def make_campaign_details(spark: SparkSession, rows=None) -> DataFrame:
    return spark.createDataFrame(rows or [campaign_row()], CAMPAIGN_DETAILS_SCHEMA)


def make_targeted_skus(spark: SparkSession) -> DataFrame:
    return spark.createDataFrame([("pt", "brand", "i1", "c1", "ch", "sub")], TARGETED_SKUS_SCHEMA)


def make_store_location(spark: SparkSession) -> DataFrame:
    return spark.createDataFrame([("100", "c1")], STORE_LOCATION_SCHEMA)


def make_unified_data(spark: SparkSession, end_dt=date(2026, 1, 31)) -> DataFrame:
    return spark.createDataFrame([("c1", date(2026, 1, 1), end_dt)], UNIFIED_DATA_SCHEMA)


def txn(transaction_id, ts, code=1, item_cd="i1", sales=5.0, qty=1, seq=1, store="100", loyalty_id="L1"):
    return (loyalty_id, transaction_id, ts.date(), ts, code, item_cd, sales, qty, seq, store)


def make_loyalty_transactions(spark: SparkSession, rows) -> DataFrame:
    return spark.createDataFrame(rows, LOYALTY_TRANSACTIONS_SCHEMA)


def relevant_transactions(spark: SparkSession, loyalty_transactions_df, campaign_details_df=None, post_df=None):
    return get_instore_relevant_transactions(
        get_channel_transactions(loyalty_transactions_df, INSTORE_CODES),
        make_targeted_skus(spark),
        campaign_details_df if campaign_details_df is not None else make_campaign_details(spark),
        make_store_location(spark),
        "transaction",
        post_df,
    )


def test_get_in_scope_campaigns_keeps_in_scope_hierarchy_campaigns(spark_session: SparkSession):
    schema = (
        "campaign_name string, channel_name string, subchannel_name string, campaign_start_dt date, "
        "campaign_end_dt date, campaign_id string, booking_id string, campaign_duration string, "
        "marketing_type string, marketing_hierarchy_cd int, job_bag_number string"
    )
    base = ("camp", "ch", "sub", date(2026, 1, 1), date(2026, 1, 31))
    campaign_execution_status = spark_session.createDataFrame([
        base + ("c1", "b1", "During", "mt", 10, "jb1"),
        base + ("c1", "b1", "During", "mt", 10, "jb1"),  # duplicate
        base + ("c2", "b2", "During", "mt", 10, "jb2"),
        base + ("c4", "b4", "During", "mt", 99, "jb4"),  # not an in-store hierarchy code
    ], schema)

    result = get_in_scope_campaigns(campaign_execution_status, [10])

    assert sorted(row.campaign_id for row in result.collect()) == ["c1", "c2"]


def test_create_campaign_date_range_returns_overall_window(spark_session: SparkSession):
    campaign_details_df = make_campaign_details(spark_session, [
        ("a", "ch", "sub", date(2026, 1, 10), date(2026, 1, 20), "c1", "b1", "During", "mt", 10),
        ("b", "ch", "sub", date(2026, 1, 5), date(2026, 2, 15), "c2", "b2", "During", "mt", 10),
    ])

    assert create_campaign_date_range(campaign_details_df) == (date(2026, 1, 5), date(2026, 2, 15))


def test_get_loyalty_transactions_keeps_valid_nectar_customers_only(spark_session: SparkSession):
    dim_customer_loyalty_df = spark_session.createDataFrame([
        ("L1", "5", "Nectar", "h1"),  # valid, case-insensitive account type
        ("~~", "5", "NECTAR", "h2"),
        ("L3", "0", "NECTAR", "h3"),
        ("L4", "5", "OTHER", "h4"),
    ], "nectar_collector_card_num string, household_num string, customer_account_type_name string, "
       "customer_loyalty_cd string")
    ts = datetime(2026, 1, 5, 10)
    basket_df = spark_session.createDataFrame(
        [(ts, f"h{i}", f"t{i}", ts.date(), 1) for i in range(1, 5)],
        "transaction_end_ts timestamp, nectar_card_num_hash string, transaction_id string, "
        "transaction_dt date, sales_origination_channel_cd int",
    )
    item_df = spark_session.createDataFrame(
        [(f"t{i}", ts.date(), "i1", 5.0, 1, 1, "100") for i in range(1, 5)],
        "transaction_id string, transaction_dt date, item_cd string, net_retail_sales_amt double, "
        "item_qty int, item_sequence_num int, store_cd string",
    )

    result = get_loyalty_transactions(dim_customer_loyalty_df, basket_df, item_df).collect()

    assert [(row.loyalty_id, row.transaction_id) for row in result] == [("L1", "t1")]


def test_get_campaign_window_baskets_filters_card_window_and_channel(spark_session: SparkSession):
    basket_df = spark_session.createDataFrame([
        (datetime(2026, 1, 5, 10), "h1", "keep", date(2026, 1, 5), 1),
        (datetime(2026, 1, 5, 10), None, "no_card", date(2026, 1, 5), 1),
        (datetime(2026, 3, 5, 10), "h1", "outside_window", date(2026, 3, 5), 1),
        (datetime(2026, 1, 5, 10), "h1", "other_channel", date(2026, 1, 5), 99),
    ], "transaction_end_ts timestamp, nectar_card_num_hash string, transaction_id string, "
       "transaction_dt date, sales_origination_channel_cd int")

    result = get_campaign_window_baskets(basket_df, date(2026, 1, 1), date(2026, 1, 31), [1, 2])

    assert [row.transaction_id for row in result.collect()] == ["keep"]


def test_get_campaign_window_items_filters_window_and_positive_sales(spark_session: SparkSession):
    item_df = spark_session.createDataFrame([
        ("keep", date(2026, 1, 5), "i1", 5.0, 1, 1, "100"),
        ("zero_sales", date(2026, 1, 5), "i1", 0.0, 1, 1, "100"),
        ("refund", date(2026, 1, 5), "i1", -2.0, 1, 1, "100"),
        ("outside_window", date(2026, 3, 5), "i1", 5.0, 1, 1, "100"),
    ], "transaction_id string, transaction_dt date, item_cd string, net_retail_sales_amt double, "
       "item_qty int, item_sequence_num int, store_cd string")

    result = get_campaign_window_items(item_df, date(2026, 1, 1), date(2026, 1, 31))

    assert [row.transaction_id for row in result.collect()] == ["keep"]


def test_create_store_location_parses_store_list_and_matches_campaigns(spark_session: SparkSession):
    campaign_execution_status = spark_session.createDataFrame(
        [("c1", "b1", "jb1"), ("c9", "b9", "jb9")],
        "campaign_id string, booking_id string, job_bag_number string",
    )
    campaign_booking_media_channel_df = spark_session.createDataFrame([
        ("c1", "b1", '["100", 200]'),  # matched on campaign_id, mixed string/number store codes
        ("x1", "jb9", '["300"]'),  # matched on booking_id = job_bag_number
        ("zz", "zz", '["400"]'),  # no matching campaign
        ("c1", "b1", None),  # no store list
    ], "campaign_id string, booking_id string, store_cd_list string")

    result = create_store_location(campaign_booking_media_channel_df, campaign_execution_status)

    assert sorted((row.campaign_id, row.location_key) for row in result.collect()) == [
        ("c1", "100"), ("c1", "200"), ("x1", "300"),
    ]


def test_get_store_location_keeps_in_scope_campaigns_only(spark_session: SparkSession):
    store_location_df = spark_session.createDataFrame(
        [("c1", "100", "b1"), ("c1", "100", "b1"), ("c9", "900", "b9")],
        "campaign_id string, location_key string, booking_id string",
    )

    result = get_store_location(store_location_df, make_campaign_details(spark_session))

    assert [(row.campaign_id, row.location_key) for row in result.collect()] == [("c1", "100")]


def test_get_targeted_skus_keeps_latest_load_for_in_scope_campaigns(spark_session: SparkSession):
    campaign_product_type_df = spark_session.createDataFrame([
        ("c1", "ch", "sub", datetime(2026, 1, 1), "pt", "brand", "old_item"),
        ("c1", "ch", "sub", datetime(2026, 1, 2), "pt", "brand", "new_item"),
        ("c9", "ch", "sub", datetime(2026, 1, 2), "pt", "brand", "other_campaign_item"),
    ], "campaign_id string, channel_name string, subchannel_name string, load_ts timestamp, "
       "product_type string, unique_brand_name string, item_cd string")

    result = get_targeted_skus(campaign_product_type_df, make_campaign_details(spark_session)).collect()

    assert [(row.sku_item_cd, row.sku_campaign_id) for row in result] == [("new_item", "c1")]


def test_get_unified_data_returns_overall_dates_for_matched_campaigns(spark_session: SparkSession):
    unified_campaign_source_df = spark_session.createDataFrame([
        ("c1", "b1", "ch", "sub", "mt", date(2026, 1, 1), date(2026, 1, 15), date(2026, 1, 20)),
        ("c1", "b1", "ch", "sub", "mt", date(2026, 1, 1), date(2026, 1, 31), date(2026, 2, 5)),
        ("c9", "b9", "ch", "sub", "mt", date(2026, 1, 1), date(2026, 1, 31), date(2026, 2, 5)),
    ], "campaign_id string, job_bag_number string, channel_name string, subchannel_name string, "
       "marketing_type string, campaign_start_dt date, campaign_end_dt date, post_campaign_dt date")

    matched_df = get_unified_campaigns(unified_campaign_source_df, make_campaign_details(spark_session))
    result = get_unified_data(matched_df).collect()

    assert [(row.uc_campaign_id, row.uc_campaign_start_dt, row.uc_campaign_end_dt) for row in result] == [
        ("c1", date(2026, 1, 1), date(2026, 1, 31)),
    ]


def test_get_post_period_customers_keeps_during_run_customers_in_window(spark_session: SparkSession):
    unified_campaign_source_df = spark_session.createDataFrame(
        [("c1", "b1", "ch", "sub", "mt", date(2026, 1, 1), date(2026, 1, 31), date(2026, 1, 20))],
        "campaign_id string, job_bag_number string, channel_name string, subchannel_name string, "
        "marketing_type string, campaign_start_dt date, campaign_end_dt date, post_campaign_dt date",
    )
    matched_df = get_unified_campaigns(unified_campaign_source_df, make_campaign_details(spark_session))
    customer_data_collection_df = spark_session.createDataFrame([
        ("during-1", "L1", "c1", "ch", "sub", "mt", date(2026, 1, 5)),
        ("other-run", "L2", "c1", "ch", "sub", "mt", date(2026, 1, 5)),
        ("during-1", "L3", "c1", "ch", "sub", "mt", date(2026, 2, 15)),  # outside campaign window
    ], "job_run_id string, loyalty_id string, campaign_id string, channel_name string, "
       "subchannel_name string, marketing_type string, event_dt date")

    result = get_post_period_customers(matched_df, customer_data_collection_df, "during-1").collect()

    assert [(row.post_loyalty_id, row.post_campaign_id) for row in result] == [("L1", "c1")]


def test_get_instore_relevant_transactions_sums_targeted_instore_lines(spark_session: SparkSession):
    loyalty_transactions_df = make_loyalty_transactions(spark_session, [
        txn("t1", datetime(2026, 1, 5, 10), sales=5.0, qty=1, seq=1),
        txn("t1", datetime(2026, 1, 5, 10), sales=2.5, qty=2, seq=2),
        txn("non_targeted", datetime(2026, 1, 5, 11), item_cd="i9"),
        txn("online", datetime(2026, 1, 5, 12), code=2),
        txn("other_store", datetime(2026, 1, 5, 13), store="999"),
        txn("after_campaign", datetime(2026, 2, 10, 10)),
    ])

    result = relevant_transactions(spark_session, loyalty_transactions_df).collect()

    assert len(result) == 1
    row = result[0]
    assert (row.transaction_key, row.net_targetted_sales, row.units) == ("t1", 7.5, 3)
    assert (row.purchase_type, row.marketing_type, row.product_type, row.channel) == ("instore", "NA", "pt", "ch")


def test_get_instore_relevant_transactions_post_run_keeps_during_customers_only(spark_session: SparkSession):
    loyalty_transactions_df = make_loyalty_transactions(spark_session, [
        txn("t1", datetime(2026, 1, 5, 10), loyalty_id="L1"),
        txn("t2", datetime(2026, 1, 5, 10), loyalty_id="L2"),
    ])
    post_df = spark_session.createDataFrame([("L1", "c1", "ch", "sub", "mt")], POST_PERIOD_CUSTOMERS_SCHEMA)

    result = relevant_transactions(spark_session, loyalty_transactions_df, post_df=post_df).collect()

    assert [row.loyalty_id for row in result] == ["L1"]


def test_get_instore_relevant_transactions_does_not_double_count_duplicate_campaign_rows(
    spark_session: SparkSession,
):
    campaign_details_df = make_campaign_details(spark_session, [
        campaign_row(campaign_duration="During", marketing_hierarchy_cd=10),
        campaign_row(campaign_duration="Post", marketing_hierarchy_cd=11),
    ])
    loyalty_transactions_df = make_loyalty_transactions(spark_session, [txn("t1", datetime(2026, 1, 5, 10))])

    result = relevant_transactions(spark_session, loyalty_transactions_df, campaign_details_df).collect()

    assert [(row.net_targetted_sales, row.units) for row in result] == [(5.0, 1)]


def test_get_channel_transactions_keeps_only_given_channel_codes(spark_session: SparkSession):
    loyalty_transactions_df = make_loyalty_transactions(spark_session, [
        txn("instore", datetime(2026, 1, 5, 10), code=1),
        txn("online", datetime(2026, 1, 5, 11), code=2),
        txn("other", datetime(2026, 1, 5, 12), code=3),
    ])

    instore = get_channel_transactions(loyalty_transactions_df, INSTORE_CODES).collect()
    online = get_channel_transactions(loyalty_transactions_df, ONLINE_CODES).collect()

    assert [row.transaction_id for row in instore] == ["instore"]
    assert [row.transaction_id for row in online] == ["online"]


def test_get_instore_converted_touchpoints_stop_at_unified_campaign_end(spark_session: SparkSession):
    loyalty_transactions_df = make_loyalty_transactions(spark_session, [
        txn("t1", datetime(2026, 1, 5, 10)),
        txn("t2", datetime(2026, 1, 20, 10)),  # after unified campaign end
    ])
    instore_relevant_transaction_df = relevant_transactions(spark_session, loyalty_transactions_df)

    result = get_instore_converted_touchpoints(
        instore_relevant_transaction_df,
        make_campaign_details(spark_session),
        make_unified_data(spark_session, end_dt=date(2026, 1, 10)),
        "touchpoint",
    ).collect()

    assert [(row.transaction_key, row.event_name, row.marketing_type, row.channel) for row in result] == [
        ("t1", "touchpoint", "mt", "ch"),
    ]


def test_get_instore_nonconverted_touchpoints_excludes_targeted_and_converted(spark_session: SparkSession):
    campaign_details_df = make_campaign_details(spark_session)
    unified_data_df = make_unified_data(spark_session)
    loyalty_transactions_df = make_loyalty_transactions(spark_session, [
        txn("converted", datetime(2026, 1, 5, 10)),
        txn("converted", datetime(2026, 1, 5, 10), item_cd="i9", seq=2),  # other item in a converted basket
        txn("visit", datetime(2026, 1, 3, 9), item_cd="i9"),
        txn("other_store", datetime(2026, 1, 4, 9), item_cd="i9", store="999"),
        txn("online", datetime(2026, 1, 4, 9), item_cd="i9", code=2),
    ])
    instore_converted_touchpoint_df = get_instore_converted_touchpoints(
        relevant_transactions(spark_session, loyalty_transactions_df),
        campaign_details_df,
        unified_data_df,
        "touchpoint",
    )

    result = get_instore_nonconverted_touchpoints(
        get_channel_transactions(loyalty_transactions_df, INSTORE_CODES),
        campaign_details_df,
        make_store_location(spark_session),
        unified_data_df,
        make_targeted_skus(spark_session),
        instore_converted_touchpoint_df,
        "touchpoint",
    ).collect()

    assert [(row.transaction_key, row.event_time) for row in result] == [(None, datetime(2026, 1, 3, 9))]


def test_get_min_timestamp_returns_first_instore_touch(spark_session: SparkSession):
    instore_relevant_transaction_df = spark_session.createDataFrame(
        [("L1", "c1", datetime(2026, 1, 5, 10))], "loyalty_id string, campaign_id string, event_time timestamp"
    )
    instore_nonconverted_touchpoint_df = spark_session.createDataFrame(
        [("L1", "c1", datetime(2026, 1, 3, 9))], "loyalty_id string, campaign_id string, event_time timestamp"
    )

    result = get_min_timestamp(instore_relevant_transaction_df, instore_nonconverted_touchpoint_df).collect()

    assert [(row.loyalty_id, row.campaign_id, row.event_ts) for row in result] == [
        ("L1", "c1", datetime(2026, 1, 3, 9)),
    ]


def test_get_online_transactions_keeps_targeted_purchases_after_first_touch(spark_session: SparkSession):
    min_timestamp_df = spark_session.createDataFrame([("L1", "c1", datetime(2026, 1, 5, 10))], MIN_TIMESTAMP_SCHEMA)
    loyalty_transactions_df = make_loyalty_transactions(spark_session, [
        txn("keep", datetime(2026, 1, 6, 9), code=2, sales=4.0),
        txn("before_first_touch", datetime(2026, 1, 5, 9), code=2),
        txn("after_campaign", datetime(2026, 2, 5, 9), code=2),
        txn("non_targeted", datetime(2026, 1, 6, 9), code=2, item_cd="i9"),
        txn("instore", datetime(2026, 1, 7, 9), code=1),
    ])
    # Duplicate campaign rows must not double the summed sales
    campaign_details_df = make_campaign_details(spark_session, [
        campaign_row(campaign_duration="During", marketing_hierarchy_cd=10),
        campaign_row(campaign_duration="Post", marketing_hierarchy_cd=11),
    ])

    result = get_online_transactions(
        get_channel_transactions(loyalty_transactions_df, ONLINE_CODES),
        min_timestamp_df,
        make_targeted_skus(spark_session),
        campaign_details_df,
        "transaction",
    ).collect()

    assert [(row.transaction_key, row.net_targetted_sales, row.purchase_type, row.marketing_type)
            for row in result] == [("keep", 4.0, "online", "")]


def test_get_online_touchpoints_are_timed_at_first_instore_touch(spark_session: SparkSession):
    first_touch = datetime(2026, 1, 5, 10)
    min_timestamp_df = spark_session.createDataFrame([("L1", "c1", first_touch)], MIN_TIMESTAMP_SCHEMA)
    online_transaction_df = spark_session.createDataFrame(
        [("L1", "t3", "c1")], "loyalty_id string, transaction_key string, campaign_id string"
    )

    result = get_online_touchpoints(
        online_transaction_df,
        min_timestamp_df,
        make_campaign_details(spark_session),
        make_unified_data(spark_session),
        "touchpoint",
    ).collect()

    assert [(row.transaction_key, row.event_date, row.event_time, row.marketing_type) for row in result] == [
        ("t3", first_touch.date(), first_touch, "mt"),
    ]


def test_finalise_instore_data_applies_defaults_and_output_schema(spark_session: SparkSession):
    instore_data_collection_df = spark_session.createDataFrame([
        ("L1", None, date(2026, 1, 3), datetime(2026, 1, 3, 9), "mt", "ch", "sub", "camp", "c1",
         "touchpoint", "", "b1", None, None, None, None, None),
    ], "loyalty_id string, transaction_key string, event_dt date, event_ts timestamp, marketing_type string, "
       "channel_name string, subchannel_name string, campaign_name string, campaign_id string, "
       "event_name string, purchase_type string, booking_id string, item_cd string, product_type string, "
       "unique_brand_name string, net_sales_amt double, units_qty long")

    result_df = finalise_instore_data(instore_data_collection_df, "corr-1")
    row = result_df.first()

    assert [(f.name, f.dataType) for f in result_df.schema.fields] == [
        (f.name, f.dataType) for f in InStoreDataPollen.schema.fields
    ]
    assert (row.transaction_key, row.item_cd, row.product_type, row.unique_brand_name) == ("NA", "0", "NA", "NA")
    assert (row.net_sales_amt, row.units_qty, row.job_run_id) == (Decimal("0.0000"), 0, "corr-1")
    assert row.load_ts is not None
