import os
import sys
import pytest
from unittest.mock import patch
from datetime import date, timedelta
from pyspark.sql import SparkSession, Row
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, TimestampType, DecimalType,
    StringType,
    DateType)
from decimal import Decimal
from spark_pipeline.common.throwing_argument_parser import ArgumentParserError

from chispa import assert_df_equality

from spark_pipeline.baseline_processed_data.channel_processed_data import (
    # This will be mocked for unit tests
    load_and_union_processed_data,
    build_complete_date_skeleton,
    filter_and_cast_transform,
    prepare_channel_processed_data,  # For integration/orchestration test
    entrypoint
)


def assert_df_equal(actual_df, expected_df, check_order=False):
    """
    Asserts that two Spark DataFrames are equal in schema, column order, and data.
    """
    assert actual_df.schema == expected_df.schema, "Schemas are different"

    if not check_order:
        actual_df = actual_df.sort(actual_df.columns)
        expected_df = expected_df.sort(expected_df.columns)

    assert actual_df.count() == expected_df.count(), "Row counts are different"

    # Collect and compare data
    actual_data = actual_df.collect()
    expected_data = expected_df.collect()

    assert actual_data == expected_data, "DataFrame data is different"


# Fixture for common schema for processed data
@pytest.fixture(scope="session")
def common_processed_schema():
    """
    Defines the schema for the processed data DataFrames.
    """
    return StructType([
        StructField("week_start_dt", DateType(), True),
        StructField("metric_value", DecimalType(38, 10), True),  # Raw value, might be string/double before cast
        StructField("super_category_name", StringType(), True),
        StructField("unique_brand_name", StringType(), True),
        StructField("cluster_num", StringType(), True),
        StructField("marketing_type_name", StringType(), True),
        StructField("marketing_channel_name", StringType(), True),
        StructField("marketing_sub_channel_name", StringType(), True),
        StructField("metric_name", StringType(), True),
    ])


# Sample data fixtures

@pytest.fixture(scope="session")
def mock_dfs(spark_session: SparkSession, common_processed_schema):
    """Provides mock DataFrames for various inputs."""

    # Mock data for different sources
    instore_data = [
        Row(week_start_dt=date(2023, 1, 1), metric_value=Decimal('100.50'), super_category_name="CatA", unique_brand_name="BrandX", cluster_num="C1", marketing_type_name="Type1", marketing_channel_name="ChannelA", marketing_sub_channel_name="SubA", metric_name="Sales"),
        Row(week_start_dt=date(2023, 1, 8), metric_value=Decimal('150.75'), super_category_name="CatA", unique_brand_name="BrandX", cluster_num="C1", marketing_type_name="Type1", marketing_channel_name="ChannelA", marketing_sub_channel_name="SubA", metric_name="Sales")
    ]
    meta_data = [
        Row(week_start_dt=date(2023, 1, 1), metric_value=Decimal('50.25'), super_category_name="CatB", unique_brand_name="BrandY", cluster_num="C2", marketing_type_name="Type2", marketing_channel_name="ChannelB", marketing_sub_channel_name="SubB", metric_name="Impressions")
    ]
    base_price_data = [
        Row(week_start_dt=date(2023, 1, 1), metric_value=Decimal('57.55'), super_category_name="CatC", unique_brand_name="BrandZ", cluster_num="E2", marketing_type_name="Type3", marketing_channel_name="ChannelB", marketing_sub_channel_name="SubC", metric_name="Campaign_beyond")
    ]
    weekly_dates_data = [
        Row(week_start_dt=date(2022, 12, 10)),
        Row(week_start_dt=date(2023, 1, 8)),
        Row(week_start_dt=date(2023, 1, 15))
    ]
    secondary_space_data = [
        Row(week_start_dt=date(2023, 1, 1), metric_value=Decimal('57.55'), super_category_name="CatC", unique_brand_name="BrandZ", cluster_num="E2", marketing_type_name="Type3", marketing_channel_name="ChannelB", marketing_sub_channel_name="SubC", metric_name="Core")
    ]

    # Create dummy DataFrames
    mock_instore_df = spark_session.createDataFrame(instore_data, common_processed_schema)
    mock_meta_df = spark_session.createDataFrame(meta_data, common_processed_schema)
    mock_weekly_dates_df = spark_session.createDataFrame(weekly_dates_data, StructType([StructField("week_start_dt", DateType(), True)]))
    mock_base_price_df = spark_session.createDataFrame(base_price_data, common_processed_schema)
    mock_secondary_space_df = spark_session.createDataFrame(secondary_space_data, common_processed_schema)

    mock_dv360_df = spark_session.createDataFrame([], common_processed_schema)  # Example of adding more
    mock_citrus_df = spark_session.createDataFrame([], common_processed_schema)
    mock_external_df = spark_session.createDataFrame([], common_processed_schema)
    mock_coupon_df = spark_session.createDataFrame([], common_processed_schema)
    mock_promotional_df = spark_session.createDataFrame([], common_processed_schema)
    mock_value_df = spark_session.createDataFrame([], common_processed_schema)
    mock_sales_df = spark_session.createDataFrame([], common_processed_schema)
    mock_youtube_df = spark_session.createDataFrame([], common_processed_schema)

    return {
        "instore_df": mock_instore_df,
        "meta_df": mock_meta_df,
        "base_price_df": mock_base_price_df,
        "secondary_space_df": mock_secondary_space_df,
        "dv360_df": mock_dv360_df,
        "citrus_df": mock_citrus_df,
        "external_df": mock_external_df,
        "coupon_df": mock_coupon_df,
        "promotional_df": mock_promotional_df,
        "value_df": mock_value_df,
        "sales_df": mock_sales_df,
        "youtube_df": mock_youtube_df,
        "weekly_dates_df": mock_weekly_dates_df,
    }


@pytest.fixture(scope="function")
def mock_get_s3_paths(mock_dfs, tmp_path):
    """Provides mock DataFrames for various inputs."""

    instore_path = os.path.join(tmp_path, "instore_df.parquet")
    mock_dfs['instore_df'].write.parquet(instore_path)
    meta_path = os.path.join(tmp_path, "meta_df.parquet")
    mock_dfs['meta_df'].write.parquet(meta_path)

    weekly_dates_path = os.path.join(tmp_path, "weekly_dates_df.parquet")
    mock_dfs['weekly_dates_df'].write.parquet(weekly_dates_path)

    dv360_path = os.path.join(tmp_path, "dv360_df.parquet")
    mock_dfs['dv360_df'].write.parquet(dv360_path)
    citrus_path = os.path.join(tmp_path, "citrus_df.parquet")
    mock_dfs['citrus_df'].write.parquet(citrus_path)

    base_price_path = os.path.join(tmp_path, "base_price_df.parquet")
    mock_dfs['base_price_df'].write.parquet(base_price_path)

    secondary_space_path = os.path.join(tmp_path, "secondary_space_df.parquet")
    mock_dfs['secondary_space_df'].write.parquet(secondary_space_path)

    external_path = os.path.join(tmp_path, "external_df.parquet")
    mock_dfs['external_df'].write.parquet(external_path)
    coupon_path = os.path.join(tmp_path, "coupon_df.parquet")
    mock_dfs['coupon_df'].write.parquet(coupon_path)

    promotional_path = os.path.join(tmp_path, "promotional_df.parquet")
    mock_dfs['promotional_df'].write.parquet(promotional_path)
    value_path = os.path.join(tmp_path, "value_df.parquet")
    mock_dfs['value_df'].write.parquet(value_path)

    # sales_path = os.path.join(tmp_path, "sales_df.parquet")
    # mock_dfs['sales_df'].write.parquet(sales_path)

    # Checks for showing handling of s3 path with a None value.
    sales_path = None
    if sales_path is not None:
        mock_dfs['sales_df'].write.parquet(sales_path)
    youtube_path = os.path.join(tmp_path, "youtube_df.parquet")
    mock_dfs['youtube_df'].write.parquet(youtube_path)

    s3_paths = [instore_path, meta_path, base_price_path, dv360_path, citrus_path,
                external_path, coupon_path, promotional_path, value_path,
                sales_path, youtube_path, secondary_space_path]

    output_path = os.path.join(tmp_path, "output.parquet")
    return weekly_dates_path, s3_paths, output_path


# Fixture for expected final schema
@pytest.fixture(scope="session")
def final_output_schema():
    """
    Defines the expected schema for the final output DataFrame after casting.
    """
    return StructType([
        StructField("week_start_dt", DateType(), True),
        StructField("metric_value", DecimalType(38, 10), True),
        StructField("super_category_name", StringType(), True),
        StructField("unique_brand_name", StringType(), True),
        StructField("cluster_num", StringType(), True),
        StructField("marketing_type_name", StringType(), True),
        StructField("marketing_channel_name", StringType(), True),
        StructField("marketing_sub_channel_name", StringType(), True),
        StructField("metric_name", StringType(), True),
        StructField("job_run_id", StringType(), False),
        StructField("load_ts", TimestampType(), False),
    ])


# Test for load_and_union_processed_data
def test_load_and_union_processed_data(spark_session, mock_get_s3_paths):
    """
    Tests the load_and_union_processed_data function.
    Mocks spark.read.parquet to return dummy DataFrames.
    """

    load_result_df = load_and_union_processed_data(spark_session,
                                                   mock_get_s3_paths[1])

    assert load_result_df.count() == 5
    assert load_result_df.filter(
        (F.col("super_category_name") == "CatA") &
        (F.col("unique_brand_name") == "BrandX")
    ).count() == 2


# @pytest.mark.skip("ignore this test")
def test_filter_and_cast_transform(spark_session, common_processed_schema, final_output_schema):
    """
    Tests the filter_and_cast_transform function.
    """
    # Create dummy weekly_dates_df (will be filtered between these dates)
    weekly_dates_data = [
        Row(week_start_dt=date(2023, 1, 1)),
        Row(week_start_dt=date(2023, 1, 8)),
        Row(week_start_dt=date(2023, 1, 15)),  # This date should be included
        Row(week_start_dt=date(2023, 1, 22))  # This date should be EXCLUDED
    ]
    weekly_dates_df = spark_session.createDataFrame(weekly_dates_data, StructType([StructField("week_start_dt", DateType(), True)]))

    # Create dummy union_df with dates inside and outside the filter range
    union_data = [
        Row(week_start_dt=date(2022, 12, 25), metric_value=Decimal('90.00'), super_category_name="CATX", unique_brand_name="BRANDZ", cluster_num="C0", marketing_type_name="TYPE0", marketing_channel_name="CHANNELX", marketing_sub_channel_name="SUBX", metric_name="COST"),  # Excluded
        Row(week_start_dt=date(2023, 1, 1), metric_value=Decimal('100.50'), super_category_name="CATA", unique_brand_name="BRANDX", cluster_num="C1", marketing_type_name="TYPE1", marketing_channel_name="CHANNELA", marketing_sub_channel_name="SUBA", metric_name="SALES"),  # Included
        Row(week_start_dt=date(2023, 1, 8), metric_value=Decimal('150.75'), super_category_name="CATA", unique_brand_name="BRANDX", cluster_num="C1", marketing_type_name="TYPE1", marketing_channel_name="CHANNELA", marketing_sub_channel_name="SUBA", metric_name="SALES"),  # Included
        Row(week_start_dt=date(2023, 1, 15), metric_value=Decimal('200.00'), super_category_name="CATB", unique_brand_name="BRANDY", cluster_num="C2", marketing_type_name="TYPE2", marketing_channel_name="CHANNELB", marketing_sub_channel_name="SUBB", metric_name="IMPRESSIONS"),  # Included
        Row(week_start_dt=date(2023, 1, 22), metric_value=Decimal('250.00'), super_category_name="CATC", unique_brand_name="BRANDW", cluster_num="C3", marketing_type_name="TYPE3", marketing_channel_name="CHANNELC", marketing_sub_channel_name="SUBC", metric_name="CLICKS")  # Excluded
    ]
    union_df = spark_session.createDataFrame(union_data, common_processed_schema)

    correlation_id = "test-corr-id-123"

    final_df = filter_and_cast_transform(weekly_dates_df, union_df, correlation_id)

    # Assertions for filtered data
    assert final_df.count() == 4  # Should only include dates from 2023-01-01 to 2023-01-15
    assert final_df.filter(F.col("week_start_dt") == date(2022, 12, 25)).count() == 0

    # Assertions for schema and data types
    assert final_df.schema == final_output_schema


def test_build_complete_date_skeleton(spark_session, common_processed_schema):
    """
    Tests happy path of build_complete_date_skeleton
    """

    weekly_dates_data = [
        Row(week_start_dt=date(2023, 1, 1)),
        Row(week_start_dt=date(2023, 1, 8)),
    ]
    weekly_dates_df = spark_session.createDataFrame(
        weekly_dates_data,
        StructType([StructField("week_start_dt", DateType(), True)])
    )

    union_data = [
        Row(
            week_start_dt=date(2023, 1, 1),
            metric_value=Decimal("100.50"),
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="TYPE1",
            marketing_channel_name="CHANNELA",
            marketing_sub_channel_name="SUBA",
            metric_name="SALES",
        ),
        Row(
            week_start_dt=date(2023, 1, 8),
            metric_value=Decimal("50.25"),
            super_category_name="CATB",
            unique_brand_name="BRANDY",
            cluster_num="C1",
            marketing_type_name="TYPE2",
            marketing_channel_name="CHANNELB",
            marketing_sub_channel_name="SUBB",
            metric_name="IMPRESSIONS",
        ),
    ]
    union_df = spark_session.createDataFrame(union_data, common_processed_schema)

    result_df = build_complete_date_skeleton(weekly_dates_df, union_df)

    assert result_df.count() == 4

    expected_data = [
        Row(
            week_start_dt=date(2023, 1, 1),
            metric_value=Decimal("100.50"),
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="TYPE1",
            marketing_channel_name="CHANNELA",
            marketing_sub_channel_name="SUBA",
            metric_name="SALES",
        ),
        Row(
            week_start_dt=date(2023, 1, 8),
            metric_value=Decimal("0"),
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="TYPE1",
            marketing_channel_name="CHANNELA",
            marketing_sub_channel_name="SUBA",
            metric_name="SALES",
        ),
        Row(
            week_start_dt=date(2023, 1, 1),
            metric_value=Decimal("0"),
            super_category_name="CATB",
            unique_brand_name="BRANDY",
            cluster_num="C1",
            marketing_type_name="TYPE2",
            marketing_channel_name="CHANNELB",
            marketing_sub_channel_name="SUBB",
            metric_name="IMPRESSIONS",
        ),
        Row(
            week_start_dt=date(2023, 1, 8),
            metric_value=Decimal("50.25"),
            super_category_name="CATB",
            unique_brand_name="BRANDY",
            cluster_num="C1",
            marketing_type_name="TYPE2",
            marketing_channel_name="CHANNELB",
            marketing_sub_channel_name="SUBB",
            metric_name="IMPRESSIONS",
        ),
    ]
    expected_df = spark_session.createDataFrame(expected_data, common_processed_schema)

    assert_df_equality(
        result_df.select(expected_df.columns),
        expected_df,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_build_complete_date_skeleton_feature_no_historic_data(spark_session, common_processed_schema):
    """
    Tests that a feature with no historic data produces 104 weeks of zeros.
    weekly_dates_df contains 104 weeks; union_df has one row for only one of those weeks,
    so the remaining 103 weeks should be filled with metric_value = 0.
    """
    # Create a 104 week skeleton
    weekly_dates_data = [Row(week_start_dt=date(2021, 1, 4) + timedelta(weeks=i)) for i in range(104)]
    weekly_dates_df = spark_session.createDataFrame(
        weekly_dates_data,
        StructType([StructField("week_start_dt", DateType(), True)])
    )

    # Only one week has actual data — the remaining 103 should be zero-filled
    union_data = [
        Row(
            week_start_dt=date(2021, 1, 4),
            metric_value=Decimal("99.99"),
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="TYPE1",
            marketing_channel_name="CHANNELA",
            marketing_sub_channel_name="SUBA",
            metric_name="SALES",
        )
    ]
    union_df = spark_session.createDataFrame(union_data, common_processed_schema)

    result_df = build_complete_date_skeleton(weekly_dates_df, union_df)

    assert result_df.count() == 104

    # The one week with data should retain its value
    assert result_df.filter(
        (F.col("week_start_dt") == date(2021, 1, 4)) & (F.col("metric_value") == Decimal("99.99"))
    ).count() == 1

    # All remaining 103 weeks should have metric_value == 0
    assert result_df.filter(
        (F.col("week_start_dt") != date(2021, 1, 4)) & (F.col("metric_value") != Decimal("0"))
    ).count() == 0

    assert result_df.filter(F.col("metric_value") == Decimal("0")).count() == 103


def test_build_complete_date_skeleton_empty_union_df(spark_session, common_processed_schema):
    """
    Tests that passing an empty union_df returns an empty DataFrame.
    With no data to cross-join against, the result should be empty.
    """
    weekly_dates_data = [
        Row(week_start_dt=date(2023, 1, 1)),
        Row(week_start_dt=date(2023, 1, 8)),
    ]
    weekly_dates_df = spark_session.createDataFrame(
        weekly_dates_data,
        StructType([StructField("week_start_dt", DateType(), True)])
    )

    union_df = spark_session.createDataFrame([], common_processed_schema)

    result_df = build_complete_date_skeleton(weekly_dates_df, union_df)

    assert result_df.count() == 0
    # Check if the schema's match
    assert_df_equality(
        result_df,
        union_df,
        ignore_column_order=True,
        ignore_nullable=True,
    )


def test_build_complete_date_skeleton_nulls_become_zeros(spark_session, common_processed_schema):
    """
    Tests that null metric_value entries in union_df are replaced with 0
    after the complete date skeleton is built.
    """
    weekly_dates_data = [
        Row(week_start_dt=date(2023, 1, 1)),
        Row(week_start_dt=date(2023, 1, 8)),
    ]
    weekly_dates_df = spark_session.createDataFrame(
        weekly_dates_data,
        StructType([StructField("week_start_dt", DateType(), True)])
    )

    # Explicit null metric_value for one week
    union_data = [
        Row(
            week_start_dt=date(2023, 1, 1),
            metric_value=None,
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="TYPE1",
            marketing_channel_name="CHANNELA",
            marketing_sub_channel_name="SUBA",
            metric_name="SALES",
        ),
        Row(
            week_start_dt=date(2023, 1, 8),
            metric_value=Decimal("75.00"),
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="TYPE1",
            marketing_channel_name="CHANNELA",
            marketing_sub_channel_name="SUBA",
            metric_name="SALES",
        ),
    ]
    union_df = spark_session.createDataFrame(union_data, common_processed_schema)

    result_df = build_complete_date_skeleton(weekly_dates_df, union_df)

    assert result_df.count() == 2

    # Null should have been replaced with 0
    assert result_df.filter(F.col("metric_value").isNull()).count() == 0

    assert result_df.filter(
        (F.col("week_start_dt") == date(2023, 1, 1)) & (F.col("metric_value") == Decimal("0"))
    ).count() == 1

    assert result_df.filter(
        (F.col("week_start_dt") == date(2023, 1, 8)) & (F.col("metric_value") == Decimal("75.00"))
    ).count() == 1


def test_prepare_channel_processed_data_success(spark_session, mock_get_s3_paths, tmp_path):
    # Mock helper functions
    with patch("spark_pipeline.baseline_processed_data.channel_processed_data.load_and_union_processed_data") as mock_load_union, \
            patch("spark_pipeline.baseline_processed_data.channel_processed_data.filter_and_cast_transform") as mock_filter_cast, \
            patch("spark_pipeline.baseline_processed_data.channel_processed_data.spark_s3_overwrite"), \
            patch("spark_pipeline.baseline_processed_data.channel_processed_data.check_pre_imputation_nulls_in_non_marketing_features") as mock_pre_null_check, \
            patch("spark_pipeline.baseline_processed_data.channel_processed_data.check_no_nulls_after_imputation") as mock_null_check, \
            patch("spark_pipeline.baseline_processed_data.channel_processed_data.check_feature_sense_checks") as mock_sense_check:

        mock_df = spark_session.createDataFrame([
            Row(week_start_dt="2024-06-01", metric_value=1.23, super_category_name="FOOD", unique_brand_name="BRANDX",
                cluster_num="123", marketing_type_name="TYPE1",
                marketing_channel_name="CHANNEL1", marketing_sub_channel_name="SUBCHANNEL1", metric_name="METRIC1", job_run_id="job-123",
                load_ts="2024-06-15 12:00:00")
        ])
        mock_load_union.return_value = mock_df
        mock_filter_cast.return_value = mock_df

        output_path = tmp_path / "output"
        result_df = prepare_channel_processed_data(
            spark_session,
            metrics_topic_arn="arn:aws:sns:eu-west-1:123456789:dummy-topic",
            instore_processed_data_path="s3://dummy/instore",
            meta_processed_data_path="s3://dummy/meta",
            dv360_processed_data_path="s3://dummy/dv360",
            citrus_processed_data_path="s3://dummy/citrus",
            external_processed_data_output_path="s3://dummy/external",
            coupon_at_till_processed_data_path="s3://dummy/coupon",
            promotional_discount_processed_data_path="s3://dummy/promo",
            value_index_processed_data_path="s3://dummy/value",
            sales_processed_data_path="s3://dummy/sales",
            youtube_processed_data_path="s3://dummy/youtube",
            base_price_data_path="s3://dummy/baseprice",
            secondary_space_data_path="s3://dummy/secondary_space",
            weekly_dates_path=mock_get_s3_paths[0],
            ecoupon_processed_data_path="s3://dummy/ecoupon_processed_data",
            output_path=str(output_path),
            correlation_id="job-123",
            run_date="2024-06-15"
        )

        # Check that final DataFrame was written and returned
        assert result_df.count() == 1
        mock_load_union.assert_called_once()
        mock_filter_cast.assert_called_once()
        mock_pre_null_check.assert_called_once()
        mock_null_check.assert_called_once()
        mock_sense_check.assert_called_once()


# Test for entrypoint function (argument parsing and orchestration call)
def test_entrypoint(spark_session, mocker):
    """
    Tests the entrypoint function, focusing on argument parsing and
    the correct call to prepare_channel_processed_data.
    """
    # Mock prepare_channel_processed_data to prevent actual processing during entrypoint test
    mocker.patch('spark_pipeline.baseline_processed_data.channel_processed_data.prepare_channel_processed_data', return_value=spark_session.createDataFrame([], "week_start_dt:date"))

    # Define dummy command-line arguments
    test_args = [
        "--instore-processed-data-path", "s3a://test/instore",
        "--meta-processed-data-path", "s3a://test/meta",
        "--dv360-processed-data-path", "s3a://test/dv360",
        "--citrus-processed-data-path", "s3a://test/citrus",
        "--external-processed-data-output-path", "s3a://test/external",
        "--coupon-at-till-processed-data-path", "s3a://test/coupon",
        "--promotional-discount-processed-data-path", "s3a://test/promo",
        "--value-index-processed-data-path", "s3a://test/value",
        "--sales-processed-data-path", "s3a://test/sales",
        "--youtube-processed-data-path", "s3a://test/youtube",
        "--base-price-data-path", "s3a://test/base_price",
        "--secondary-space-data-path", "s3a://test/secondary_space",
        "--weekly-dates-path", "s3a://test/weekly_dates",
        "--ecoupon-processed-data-path", "s3a://test/ecoupon_processed",
        "--output-path", "s3a://test/output",
        "--correlation-id", "entrypoint-test-corr",
        "--run-date", "2024-01-01",
        "--metrics-topic-arn", "arn:aws:sns:eu-west-1:123456789:test-topic",
    ]

    entrypoint(spark_session, test_args)

    # Assert prepare_channel_processed_data was called with the correct arguments
    data_processor_module = sys.modules['spark_pipeline.baseline_processed_data.channel_processed_data']
    data_processor_module.prepare_channel_processed_data.assert_called_once_with(
        spark=spark_session,
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789:test-topic",
        instore_processed_data_path="s3a://test/instore",
        meta_processed_data_path="s3a://test/meta",
        dv360_processed_data_path="s3a://test/dv360",
        citrus_processed_data_path="s3a://test/citrus",
        external_processed_data_output_path="s3a://test/external",
        coupon_at_till_processed_data_path="s3a://test/coupon",
        promotional_discount_processed_data_path="s3a://test/promo",
        value_index_processed_data_path="s3a://test/value",
        sales_processed_data_path="s3a://test/sales",
        youtube_processed_data_path="s3a://test/youtube",
        base_price_data_path="s3a://test/base_price",
        secondary_space_data_path="s3a://test/secondary_space",
        weekly_dates_path="s3a://test/weekly_dates",
        ecoupon_processed_data_path="s3a://test/ecoupon_processed",
        output_path="s3a://test/output",
        correlation_id="entrypoint-test-corr",
        run_date="2024-01-01"
    )


# @pytest.mark.skip("ignore this test")
def test_entrypoint_missing_required_args(spark_session, mocker):
    """
    Tests that entrypoint raises an error for missing required arguments.
    """
    mocker.patch('spark_pipeline.baseline_processed_data.channel_processed_data.prepare_channel_processed_data')

    # Test with missing required arguments (e.g., output_path)
    test_args_missing = [
        "--instore-processed-data-path", "s3a://test/instore",
        # ... other args
        "--correlation-id", "test-corr",
        "--run-date", "2024-01-01"
        # Missing --output-path
    ]

    # Expect ValueError because ThrowingArgumentParser will raise it
    with pytest.raises(ArgumentParserError):
        entrypoint(spark_session, test_args_missing)
