from datetime import date, datetime
from decimal import Decimal

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data_helper import (
    aggregate_to_cluster_level,
    calculate_sku_counts,
    format_final_output,
    join_cluster_info,
    merge_pollen_and_dtp_data,
    scale_metrics_to_sku_level,
    unpivot_metrics,
)
from spark_pipeline.common.variables import DV360Config
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.dv360_processed_data import DV360ProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    drop_load_ts,
    round_columns,
)


# ----- Helper functions -----
def _build_dv360_output_df(spark_session: SparkSession, rows):
    return spark_session.createDataFrame(rows, schema=ProcessedData.shared_timestamp_output_with_job_run_id_double_schema)


def test_calculate_sku_counts_counts_distinct_non_null_skus_per_campaign(spark_session: SparkSession):
    # Arrange duplicated and null SKU rows across two campaigns.
    metrics_with_sku = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "camp-1", "sku-1", "BRAND A", "CAT A", 100.0, 10.0, 50.0, 70.0, 80.0),
            (date(2024, 1, 1), "camp-1", "sku-1", "BRAND A", "CAT A", 100.0, 10.0, 50.0, 70.0, 80.0),
            (date(2024, 1, 1), "camp-1", None, "BRAND A", "CAT A", 100.0, 10.0, 50.0, 70.0, 80.0),
            (date(2024, 1, 1), "camp-1", "sku-2", "BRAND A", "CAT A", 100.0, 10.0, 50.0, 70.0, 80.0),
            (date(2024, 1, 8), "camp-2", "sku-9", "BRAND B", "CAT B", 5.0, 1.0, 2.0, 3.0, 4.0),
        ],
        schema=DV360ProcessedData.dv360_campaign_sku_metrics_schema,
    )

    # Act: the helper should count distinct non-null SKUs per campaign id.
    actual_df = calculate_sku_counts(metrics_with_sku, campaign_id_col="jobbagid", sku_col="sku_no")

    # Assert: duplicates and null SKUs do not inflate the distinct count.
    expected_df = spark_session.createDataFrame(
        [
            ("camp-1", 2),
            ("camp-2", 1),
        ],
        schema=DV360ProcessedData.dv360_sku_counts_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_scale_metrics_to_sku_level_splits_campaign_metrics_evenly_across_skus(spark_session: SparkSession):
    # Arrange one campaign expanded to two SKU rows with a precomputed SKU count of two.
    metrics_with_sku = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "camp-1", "sku-1", "BRAND A", "CAT A", 100.0, 10.0, 50.0, 70.0, 80.0),
            (date(2024, 1, 1), "camp-1", "sku-2", "BRAND A", "CAT A", 100.0, 10.0, 50.0, 70.0, 80.0),
        ],
        schema=DV360ProcessedData.dv360_campaign_sku_metrics_schema,
    )
    sku_counts = spark_session.createDataFrame(
        [("camp-1", 2)],
        schema=DV360ProcessedData.dv360_sku_counts_schema,
    )

    # Act: each metric should be divided by number_of_skus and projected in the requested order.
    actual_df = round_columns(
        scale_metrics_to_sku_level(
            metrics_with_sku,
            sku_counts,
            campaign_id_col="jobbagid",
            metric_columns=DV360Config.METRIC_COLUMNS,
            select_columns=DV360ProcessedData.dv360_campaign_sku_metrics_schema.fieldNames(),
        ),
        DV360Config.METRIC_COLUMNS,
    )

    # Assert: each SKU row receives half of the campaign-level totals.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "camp-1", "sku-1", "BRAND A", "CAT A", 50.0, 5.0, 25.0, 35.0, 40.0),
            (date(2024, 1, 1), "camp-1", "sku-2", "BRAND A", "CAT A", 50.0, 5.0, 25.0, 35.0, 40.0),
        ],
        schema=DV360ProcessedData.dv360_campaign_sku_metrics_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_scale_metrics_sku_zero_when_missing_or_zero_skus(spark_session: SparkSession):
    # Arrange one campaign with an explicit zero SKU count and one without any matching count row.
    metrics_with_sku = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "camp-1", "sku-1", "BRAND A", "CAT A", 100.0, 10.0, 50.0, 70.0, 80.0),
            (date(2024, 1, 8), "camp-2", "sku-9", "BRAND B", "CAT B", 90.0, 9.0, 45.0, 63.0, 72.0),
        ],
        schema=DV360ProcessedData.dv360_campaign_sku_metrics_schema,
    )
    sku_counts = spark_session.createDataFrame(
        [("camp-1", 0)],
        schema=DV360ProcessedData.dv360_sku_counts_schema,
    )

    # Act: zero and missing SKU counts should both coalesce the scaled metrics to zero rather than erroring.
    actual_df = scale_metrics_to_sku_level(
        metrics_with_sku,
        sku_counts,
        campaign_id_col="jobbagid",
        metric_columns=DV360Config.METRIC_COLUMNS,
        select_columns=DV360ProcessedData.dv360_campaign_sku_metrics_schema.fieldNames(),
    )

    # Assert: all metric columns are safely zero-filled for both edge cases.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "camp-1", "sku-1", "BRAND A", "CAT A", 0.0, 0.0, 0.0, 0.0, 0.0),
            (date(2024, 1, 8), "camp-2", "sku-9", "BRAND B", "CAT B", 0.0, 0.0, 0.0, 0.0, 0.0),
        ],
        schema=DV360ProcessedData.dv360_campaign_sku_metrics_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_join_cluster_info_attaches_cluster_numbers_and_preserves_unmatched_rows(spark_session: SparkSession):
    # Arrange weekly SKU metrics where only one SKU exists in the cluster mapping lookup.
    weekly_metrics = spark_session.createDataFrame(
        [
            ("camp-1", "sku-1", "BRAND A", "CAT A", datetime(2024, 1, 1, 0, 0, 0), 50.0, 5.0, 25.0, 35.0, 40.0),
            ("camp-1", "sku-x", "BRAND A", "CAT A", datetime(2024, 1, 1, 0, 0, 0), 50.0, 5.0, 25.0, 35.0, 40.0),
        ],
        schema=DV360ProcessedData.dv360_weekly_sku_metrics_schema,
    )
    sku_cluster_mapping = spark_session.createDataFrame(
        [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: the helper should rename the lookup item key to sku_no and left join cluster metadata.
    actual_df = join_cluster_info(
        weekly_metrics,
        sku_cluster_mapping,
        sku_col="sku_no",
        metric_columns=DV360Config.METRIC_COLUMNS,
    )

    # Assert: matched SKUs gain cluster_num while unmatched rows are preserved with a null cluster.
    # Note Null clusters just get filtered out downstream, later this will be turned into an inner join
    expected_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", 50.0, 5.0, 35.0, 40.0, 25.0),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", None, 50.0, 5.0, 35.0, 40.0, 25.0),
        ],
        schema=DV360ProcessedData.dv360_cluster_metrics_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_aggregate_to_cluster_level_sums_metrics_for_each_week_brand_and_cluster(spark_session: SparkSession):
    # Arrange two SKU-level rows that roll up to the same cluster bucket plus one separate week.
    cluster_pre = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", 10.0, 1.0, 7.0, 8.0, 5.0),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", 20.0, 2.0, 14.0, 16.0, 10.0),
            (datetime(2024, 1, 8, 0, 0, 0), "CAT A", "BRAND A", "CL1", 30.0, 3.0, 21.0, 24.0, 15.0),
        ],
        schema=DV360ProcessedData.dv360_cluster_metrics_schema,
    )

    # Act: all metric columns should be summed within each week/brand/cluster group.
    actual_df = aggregate_to_cluster_level(cluster_pre, DV360Config.METRIC_COLUMNS)

    # Assert: the first two rows aggregate together while the second week stays separate.
    expected_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", 30.0, 3.0, 21.0, 24.0, 15.0),
            (datetime(2024, 1, 8, 0, 0, 0), "CAT A", "BRAND A", "CL1", 30.0, 3.0, 21.0, 24.0, 15.0),
        ],
        schema=DV360ProcessedData.dv360_cluster_metrics_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_unpivot_metrics_creates_one_row_per_metric_and_adds_dv360_hierarchy(spark_session: SparkSession):
    # Arrange one aggregated cluster row containing all DV360 metrics.
    cluster_metrics = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", 100.0, 10.0, 70.0, 80.0, 50.0),
        ],
        schema=DV360ProcessedData.dv360_cluster_metrics_schema,
    )

    # Act: the wide metric columns should be exploded into the standard long-format processed-data shape.
    actual_df = unpivot_metrics(cluster_metrics, DV360Config.METRIC_COLUMNS)

    # Assert: one row is emitted per configured metric with the static DV360 hierarchy attached.
    expected_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "impressions", 100.0, DV360Config.MARKETING_TYPE, DV360Config.MARKETING_CHANNEL, DV360Config.MARKETING_SUB_CHANNEL),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "clicks", 10.0, DV360Config.MARKETING_TYPE, DV360Config.MARKETING_CHANNEL, DV360Config.MARKETING_SUB_CHANNEL),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "measurable_impressions", 70.0, DV360Config.MARKETING_TYPE, DV360Config.MARKETING_CHANNEL, DV360Config.MARKETING_SUB_CHANNEL),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "viewable_impressions", 80.0, DV360Config.MARKETING_TYPE, DV360Config.MARKETING_CHANNEL, DV360Config.MARKETING_SUB_CHANNEL),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "campaign_spend", 50.0, DV360Config.MARKETING_TYPE, DV360Config.MARKETING_CHANNEL, DV360Config.MARKETING_SUB_CHANNEL),
        ],
        schema=DV360ProcessedData.dv360_unpivot_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_format_final_renames_zero_fills_drops_null_clusters(spark_session: SparkSession):
    # Arrange one valid unpivoted row with a null metric and one invalid row with a null cluster.
    processed_metrics = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "clicks", None, DV360Config.MARKETING_TYPE, DV360Config.MARKETING_CHANNEL, DV360Config.MARKETING_SUB_CHANNEL),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", None, "impressions", 999.0, DV360Config.MARKETING_TYPE, DV360Config.MARKETING_CHANNEL, DV360Config.MARKETING_SUB_CHANNEL),
        ],
        schema=DV360ProcessedData.dv360_unpivot_schema,
    )

    # Act: null metric values should be coalesced to zero and null-cluster rows filtered out.
    actual_df = format_final_output(processed_metrics, correlation_id="corr-123")

    # Assert: only the valid cluster row remains and the schema matches the final DV360 helper output contract.
    expected_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", DV360Config.MARKETING_TYPE, DV360Config.MARKETING_CHANNEL, DV360Config.MARKETING_SUB_CHANNEL, "clicks", 0.0, "corr-123"),
        ],
        schema=ProcessedData.shared_timestamp_output_with_job_run_id_double_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_merge_pollen_and_dtp_data_preserves_brand_and_category_case(spark_session: SparkSession):
    # Arrange overlapping pollen and DTP rows plus one DTP-only metric.
    pollen_df = _build_dv360_output_df(
        spark_session,
        [
            (datetime(2024, 1, 1, 0, 0, 0), "cat a", "brand a", "cl1", "offsite", "dv360", "total", "clicks", 10.0, "pollen-run"),
        ],
    )
    dtp_df = _build_dv360_output_df(
        spark_session,
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "CLICKS", 999.0, "dtp-run"),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "IMPRESSIONS", 30.0, "dtp-run"),
        ],
    )

    # Act: overlapping DTP rows should be removed
    actual_df = merge_pollen_and_dtp_data(pollen_df, dtp_df)

    # Assert: pollen keeps the overlapping clicks metric, the DTP-only metric is retained, and runtime columns are populated.
    # Mixed-case brand/category rows are preserved separately while other merge keys remain normalized.
    expected_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "cat a", "brand a", "CL1", "OFFSITE", "DV360", "TOTAL", "CLICKS", Decimal("10.00000"), "NA", None),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "CLICKS", Decimal("999.00000"), "NA", None),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "IMPRESSIONS", Decimal("30.00000"), "NA", None),
        ],
        schema=ProcessedData.shared_timestamp_output_with_load_ts_decimal_18_5_schema,
    )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_merge_pollen_and_dtp_data_empty_pollen_preserves_brand_and_category_case(spark_session: SparkSession):
    # Arrange no pollen rows and one lowercase DTP row.
    pollen_df = spark_session.createDataFrame([], schema=ProcessedData.shared_timestamp_output_with_job_run_id_double_schema)
    dtp_df = _build_dv360_output_df(
        spark_session,
        [
            (datetime(2024, 1, 8, 0, 0, 0), "cat b", "brand b", "cl9", "offsite", "dv360", "total", "campaign_spend", 55.5, "dtp-run"),
        ],
    )

    # Act: with no overlapping pollen data, all DTP rows should flow through after normalization and casting.
    actual_df = merge_pollen_and_dtp_data(pollen_df, dtp_df)

    # Assert: brand/category case is preserved while the remaining dimensions are normalized.
    expected_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 8, 0, 0, 0), "cat b", "brand b", "CL9", "OFFSITE", "DV360", "TOTAL", "CAMPAIGN_SPEND", Decimal("55.50000"), "NA", None),
        ],
        schema=ProcessedData.shared_timestamp_output_with_load_ts_decimal_18_5_schema,
    )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])
