from datetime import date, datetime
from decimal import Decimal
from unittest import mock
from unittest.mock import patch

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.youtube_processed_data_pollen import (
    calculate_sku_counts,
    create_final_output,
    entrypoint,
    get_yt_required_campaigns,
    get_youtube_media_data,
    merge_pollen_and_dtp_data,
    prepare_youtube_processed_data,
    scale_metrics_to_sku_level,
)
from spark_pipeline.common.variables import YoutubeConfig
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.dv360_processed_data import DV360ProcessedData
from spark_pipeline.schemas.baseline_processed_data.youtube_processed_data import YouTubeProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    drop_load_ts,
    round_columns,
    write_pipeline_inputs_to_parquet,
    local_spark_s3_overwrite
)


# ----- Helper functions -----
def _build_youtube_output_df(spark_session: SparkSession, rows):
    return spark_session.createDataFrame(rows, schema=YouTubeProcessedData.youtube_output_schema)


# Tests for get_yt_required_campaigns
def test_get_yt_required_campaigns_keeps_only_skus_present_in_cluster_mapping(spark_session: SparkSession):
    # Arrange YouTube normalized rows where only one SKU is present in the brand SKU mapping.
    youtube_normalised_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), date(2024, 1, 7), "sku-1", "booking-1", "camp-1"),
            (date(2024, 1, 1), date(2024, 1, 7), "sku-x", "booking-1", "camp-1"),
        ],
        schema=YouTubeProcessedData.youtube_normalised_input_schema,
    )
    sku_cluster_df = spark_session.createDataFrame(
        [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: the helper should inner join to the cluster mapping and add brand/category columns.
    actual_df = get_yt_required_campaigns(youtube_normalised_df, sku_cluster_df)

    # Assert: only mapped SKUs remain after the inner join.
    expected_df = spark_session.createDataFrame(
        [(date(2024, 1, 1), date(2024, 1, 7), "sku-1", "booking-1", "camp-1", "CAT A", "BRAND A")],
        schema=YouTubeProcessedData.youtube_required_campaigns_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


# Tests for get_youtube_media_data
def test_get_youtube_media_data_aggregates_weekly_metrics_when_campaign_id_matches(spark_session: SparkSession):
    # Arrange a media report with two rows in the same week for one required campaign plus one irrelevant campaign.
    media_report_df = spark_session.createDataFrame(
        [
            ("camp-1", "io-1", date(2024, 1, 1), Decimal("90.00"), Decimal("80.00"), Decimal("10.00"), Decimal("100.00"), Decimal("50.00")),
            ("camp-1", "io-1", date(2024, 1, 2), Decimal("110.00"), Decimal("100.00"), Decimal("20.00"), Decimal("200.00"), Decimal("60.00")),
            ("camp-x", "io-x", date(2024, 1, 2), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00"), Decimal("1.00")),
        ],
        schema=DV360ProcessedData.dv60_pollen_media_report_input_schema,
    )
    yt_required_campaigns = spark_session.createDataFrame(
        [(date(2024, 1, 1), date(2024, 1, 7), "sku-1", "booking-1", "camp-1", "CAT A", "BRAND A")],
        schema=YouTubeProcessedData.youtube_required_campaigns_schema,
    )

    # Act: the helper should filter to required campaigns and aggregate metrics to the week grain.
    actual_df = get_youtube_media_data(media_report_df, yt_required_campaigns)

    # Assert: only the required campaign remains and the two daily rows are summed into one week.
    expected_df = spark_session.createDataFrame(
        [("camp-1", datetime(2024, 1, 1, 0, 0, 0), Decimal("300.00"), Decimal("30.00"), Decimal("110.00"), Decimal("200.00"), Decimal("180.00"))],
        schema=actual_df.schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_get_youtube_media_data_falls_back_to_insertion_order_id(spark_session: SparkSession):
    # Arrange a media report whose campaign_id does not match but insertion_order_id does.
    media_report_df = spark_session.createDataFrame(
        [
            ("NA", "camp-1", date(2024, 1, 1), Decimal("90.00"), Decimal("80.00"), Decimal("10.00"), Decimal("100.00"), Decimal("50.00")),
            ("NA", "camp-1", date(2024, 1, 2), Decimal("110.00"), Decimal("100.00"), Decimal("20.00"), Decimal("200.00"), Decimal("60.00")),
        ],
        schema=DV360ProcessedData.dv60_pollen_media_report_input_schema,
    )
    yt_required_campaigns = spark_session.createDataFrame(
        [(date(2024, 1, 1), date(2024, 1, 7), "sku-1", "booking-1", "camp-1", "CAT A", "BRAND A")],
        schema=YouTubeProcessedData.youtube_required_campaigns_schema,
    )

    # Act: when the first campaign_id join returns empty, the helper should retry using insertion_order_id.
    actual_df = get_youtube_media_data(media_report_df, yt_required_campaigns)

    # Assert: the insertion_order fallback still returns the weekly metrics for the required campaign.
    expected_df = spark_session.createDataFrame(
        [("camp-1", datetime(2024, 1, 1, 0, 0, 0), Decimal("300.00"), Decimal("30.00"), Decimal("110.00"), Decimal("200.00"), Decimal("180.00"))],
        schema=actual_df.schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


# Tests for calculate_sku_counts / scale_metrics_to_sku_level
def test_calculate_sku_counts_counts_distinct_non_null_skus_per_booking(spark_session: SparkSession):
    # Arrange duplicated and null SKU rows under the same booking.
    metrics_with_sku = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "booking-1", Decimal("100.00"), Decimal("10.00"), Decimal("50.00"), Decimal("90.00"), Decimal("80.00"), "sku-1", "CAT A", "BRAND A"),
            (datetime(2024, 1, 1, 0, 0, 0), "booking-1", Decimal("100.00"), Decimal("10.00"), Decimal("50.00"), Decimal("90.00"), Decimal("80.00"), "sku-1", "CAT A", "BRAND A"),
            (datetime(2024, 1, 1, 0, 0, 0), "booking-1", Decimal("100.00"), Decimal("10.00"), Decimal("50.00"), Decimal("90.00"), Decimal("80.00"), None, "CAT A", "BRAND A"),
            (datetime(2024, 1, 1, 0, 0, 0), "booking-1", Decimal("100.00"), Decimal("10.00"), Decimal("50.00"), Decimal("90.00"), Decimal("80.00"), "sku-2", "CAT A", "BRAND A"),
        ],
        schema="week_start_date timestamp, booking_id string, impressions decimal(38,2), clicks decimal(38,2), campaign_spend decimal(38,2), measurable_impressions decimal(38,2), viewable_impressions decimal(38,2), item_cd string, super_category_name string, unique_brand_name string",
    )

    # Act: distinct non-null SKU counts should be calculated per booking.
    actual_df = calculate_sku_counts(metrics_with_sku)

    # Assert: duplicate and null SKU values do not inflate the count.
    expected_df = spark_session.createDataFrame(
        [("booking-1", 2)],
        schema=YouTubeProcessedData.youtube_sku_counts_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_scale_metrics_to_sku_level_zero_fills_missing_counts(spark_session: SparkSession):
    # Arrange one booking with two SKUs and one booking missing a SKU-count row entirely.
    metrics_with_sku = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "booking-1", Decimal("100.00"), Decimal("10.00"), Decimal("50.00"), Decimal("90.00"), Decimal("80.00"), "sku-1", "CAT A", "BRAND A"),
            (datetime(2024, 1, 1, 0, 0, 0), "booking-1", Decimal("100.00"), Decimal("10.00"), Decimal("50.00"), Decimal("90.00"), Decimal("80.00"), "sku-2", "CAT A", "BRAND A"),
            (datetime(2024, 1, 8, 0, 0, 0), "booking-2", Decimal("120.00"), Decimal("12.00"), Decimal("60.00"), Decimal("108.00"), Decimal("96.00"), "sku-9", "CAT B", "BRAND B"),
        ],
        schema="week_start_date timestamp, booking_id string, impressions decimal(38,2), clicks decimal(38,2), campaign_spend decimal(38,2), measurable_impressions decimal(38,2), viewable_impressions decimal(38,2), item_cd string, super_category_name string, unique_brand_name string",
    )
    sku_counts = spark_session.createDataFrame(
        [("booking-1", 2)],
        schema=YouTubeProcessedData.youtube_sku_counts_schema,
    )

    # Act: matching bookings should be divided by number_of_skus, while missing counts should coalesce to zero.
    actual_df = round_columns(
        scale_metrics_to_sku_level(metrics_with_sku, sku_counts),
        ["impressions", "clicks", "campaign_spend", "measurable_impressions", "viewable_impressions"],
    )

    # Assert: booking-1 metrics are split 50/50 and booking-2 is zero-filled because its sku count is missing.
    expected_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "booking-1", "sku-1", "BRAND A", "CAT A", 2, Decimal("50.000000"), Decimal("5.000000"), Decimal("25.000000"), Decimal("45.000000"), Decimal("40.000000")),
            (datetime(2024, 1, 1, 0, 0, 0), "booking-1", "sku-2", "BRAND A", "CAT A", 2, Decimal("50.000000"), Decimal("5.000000"), Decimal("25.000000"), Decimal("45.000000"), Decimal("40.000000")),
            (datetime(2024, 1, 8, 0, 0, 0), "booking-2", "sku-9", "BRAND B", "CAT B", None, Decimal("0.000000"), Decimal("0.000000"), Decimal("0.000000"), Decimal("0.000000"), Decimal("0.000000")),
        ],
        schema=actual_df.schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


# Tests for create_final_output
def test_create_final_output_zero_fills_null_values_and_filters_null_clusters(spark_session: SparkSession):
    # Arrange one valid unpivoted row with a null value and one row with a null cluster.
    cluster_unpivot = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "impressions", None, YoutubeConfig.MARKETING_TYPE, YoutubeConfig.MARKETING_CHANNEL, YoutubeConfig.MARKETING_SUB_CHANNEL),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", None, "clicks", Decimal("10.00000000"), YoutubeConfig.MARKETING_TYPE, YoutubeConfig.MARKETING_CHANNEL, YoutubeConfig.MARKETING_SUB_CHANNEL),
        ],
        schema=YouTubeProcessedData.youtube_unpivot_schema,
    )

    # Act: null metric values should be coalesced to zero and null-cluster rows should be excluded.
    actual_df = create_final_output(cluster_unpivot, correlation_id="corr-yt")

    # Assert: only the valid cluster row remains in the final YouTube pollen output.
    expected_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", YoutubeConfig.MARKETING_TYPE, YoutubeConfig.MARKETING_CHANNEL, YoutubeConfig.MARKETING_SUB_CHANNEL, "impressions", Decimal("0E-8"), "corr-yt"),
        ],
        schema=actual_df.schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


# Tests for merge_pollen_and_dtp_data
def test_merge_pollen_and_dtp_data_prefers_pollen_and_preserves_unmatched_dtp_rows(spark_session: SparkSession):
    # Arrange overlapping pollen and DTP rows plus one DTP-only metric.
    pollen_df = _build_youtube_output_df(
        spark_session,
        [
            (datetime(2024, 1, 1, 0, 0, 0), "cat a", "brand a", "cl1", "offsite", "youtube", "total", "clicks", Decimal("10.00000000"), "pollen-run"),
        ],
    )
    dtp_df = _build_youtube_output_df(
        spark_session,
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "CLICKS", Decimal("999.00000000"), "dtp-run"),
            (datetime(2024, 1, 8, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "IMPRESSIONS", Decimal("30.00000000"), "dtp-run"),
        ],
    )

    # Act: overlapping DTP rows should be removed
    # brand/category comparisons are now case-sensitive, so mixed-case rows are treated as distinct.
    actual_df = merge_pollen_and_dtp_data(pollen_df, dtp_df)

    # Assert: pollen wins on overlaps, unmatched DTP rows remain, and runtime metadata is populated.
    expected_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "cat a", "brand a", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "CLICKS", Decimal("10.00000"), "NA", None),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "CLICKS", Decimal("999.00000"), "NA", None),
            (datetime(2024, 1, 8, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "IMPRESSIONS", Decimal("30.00000"), "NA", None),
        ],
        schema=ProcessedData.shared_timestamp_output_with_load_ts_decimal_18_5_schema,
    )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


# Tests for prepare_youtube_processed_data
def test_youtube_pollen_returns_pollen_and_writes_merged_output(spark_session: SparkSession, tmp_path):
    # Arrange parquet inputs for one valid campaign plus a historic DTP-only metric.
    youtube_normalised_path = str(tmp_path / "youtube_normalised")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    dv360_media_report_path = str(tmp_path / "dv360_media_report")
    historic_youtube_processed_data_path = str(tmp_path / "historic_youtube_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[youtube_normalised_path, sku_cluster_mapping_path, dv360_media_report_path, historic_youtube_processed_data_path],
        rows_list=[
            [(date(2024, 1, 1), date(2024, 1, 2), "sku-1", "booking-1", "camp-1")],
            [("sku-1", "Cat A", "Sub A", "Brand A", "CL1")],
            [
                ("camp-1", "io-1", date(2024, 1, 1), Decimal("90.00"), Decimal("80.00"), Decimal("10.00"), Decimal("100.00"), Decimal("50.00")),
                ("camp-1", "io-1", date(2024, 1, 2), Decimal("110.00"), Decimal("100.00"), Decimal("20.00"), Decimal("200.00"), Decimal("60.00")),
            ],
            [
                (datetime(2024, 1, 8, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "IMPRESSIONS", Decimal("30.00000000"), "historic-run"),
            ],
        ],
        schemas=[
            YouTubeProcessedData.youtube_normalised_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            DV360ProcessedData.dv60_pollen_media_report_input_schema,
            YouTubeProcessedData.youtube_output_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.youtube_processed_data_pollen.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: the orchestration function should return pollen-only data but write the merged pollen-over-DTP dataset.
        returned_df = prepare_youtube_processed_data(
            spark=spark_session,
            youtube_normalised_path=youtube_normalised_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            dv360_media_report_path=dv360_media_report_path,
            historic_youtube_processed_data=historic_youtube_processed_data_path,
            output_path=output_path,
            correlation_id="corr-youtube",
        )
        actual_written_df = spark_session.read.parquet(output_path)

        # Assert: the return value is the fresh pollen dataset and the written output includes merged historic rows.
        expected_returned_df = spark_session.createDataFrame(
            [
                (datetime(2024, 1, 1, 0, 0, 0), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "impressions", Decimal("300.00000000"), "corr-youtube"),
                (datetime(2024, 1, 1, 0, 0, 0), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "clicks", Decimal("30.00000000"), "corr-youtube"),
                (datetime(2024, 1, 1, 0, 0, 0), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "measurable_impressions", Decimal("200.00000000"), "corr-youtube"),
                (datetime(2024, 1, 1, 0, 0, 0), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "viewable_impressions", Decimal("180.00000000"), "corr-youtube"),
                (datetime(2024, 1, 1, 0, 0, 0), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "campaign_spend", Decimal("110.00000000"), "corr-youtube"),
            ],
            schema=returned_df.schema,
        )
        expected_written_df = spark_session.createDataFrame(
            [
                (datetime(2024, 1, 1, 0, 0, 0), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "IMPRESSIONS", Decimal("300.00000"), "NA", None),
                (datetime(2024, 1, 1, 0, 0, 0), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "CLICKS", Decimal("30.00000"), "NA", None),
                (datetime(2024, 1, 1, 0, 0, 0), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "MEASURABLE_IMPRESSIONS", Decimal("200.00000"), "NA", None),
                (datetime(2024, 1, 1, 0, 0, 0), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "VIEWABLE_IMPRESSIONS", Decimal("180.00000"), "NA", None),
                (datetime(2024, 1, 1, 0, 0, 0), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "CAMPAIGN_SPEND", Decimal("110.00000"), "NA", None),
                (datetime(2024, 1, 8, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "IMPRESSIONS", Decimal("30.00000"), "NA", None),
            ],
            schema=ProcessedData.shared_timestamp_output_with_load_ts_decimal_18_5_schema,
        )

    assert_spark_df_equal(returned_df, expected_returned_df)
    assert_spark_df_equal(drop_load_ts(actual_written_df), drop_load_ts(expected_written_df))
    assert_non_null_columns(actual_written_df, ["load_ts"])


def test_youtube_pollen_empty_output_when_campaigns_miss_brand_skus(spark_session: SparkSession, tmp_path):
    # Arrange parquet inputs where the YouTube normalized SKU is absent from the SKU cluster mapping and historic data is empty.
    youtube_normalised_path = str(tmp_path / "youtube_normalised")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    dv360_media_report_path = str(tmp_path / "dv360_media_report")
    historic_youtube_processed_data_path = str(tmp_path / "historic_youtube_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[youtube_normalised_path, sku_cluster_mapping_path, dv360_media_report_path, historic_youtube_processed_data_path],
        rows_list=[
            [(date(2024, 1, 1), date(2024, 1, 2), "sku-x", "booking-1", "camp-1")],
            [("sku-1", "Cat A", "Sub A", "Brand A", "CL1")],
            [("camp-1", "io-1", date(2024, 1, 1), Decimal("90.00"), Decimal("80.00"), Decimal("10.00"), Decimal("100.00"), Decimal("50.00"))],
            [],
        ],
        schemas=[
            YouTubeProcessedData.youtube_normalised_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            DV360ProcessedData.dv60_pollen_media_report_input_schema,
            YouTubeProcessedData.youtube_output_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.youtube_processed_data_pollen.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: no required campaigns means no pollen metrics and therefore an empty merged output.
        returned_df = prepare_youtube_processed_data(
            spark=spark_session,
            youtube_normalised_path=youtube_normalised_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            dv360_media_report_path=dv360_media_report_path,
            historic_youtube_processed_data=historic_youtube_processed_data_path,
            output_path=output_path,
            correlation_id="corr-empty",
        )
        actual_written_df = spark_session.read.parquet(output_path)

    # Assert: both the returned pollen dataframe and the written merged dataframe are empty but schema-correct.
    assert returned_df.count() == 0
    assert actual_written_df.count() == 0
    assert actual_written_df.schema == ProcessedData.shared_timestamp_output_with_load_ts_decimal_18_5_schema


def test_entrypoint_invokes_prepare_youtube_processed_data_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current YouTube pollen entrypoint contract.
    args = [
        "--youtube-normalize-path", "s3://input/youtube-normalized",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--dv360-media-report-path", "s3://input/dv360-report",
        "--historic-youtube-processed-data", "s3://input/historic-youtube",
        "--output-path", "s3://output/youtube",
        "--correlation-id", "corr-entrypoint",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.marketing_features.youtube_processed_data_pollen.prepare_youtube_processed_data") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        youtube_normalised_path="s3://input/youtube-normalized",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        dv360_media_report_path="s3://input/dv360-report",
        historic_youtube_processed_data="s3://input/historic-youtube",
        output_path="s3://output/youtube",
        correlation_id="corr-entrypoint",
    )
