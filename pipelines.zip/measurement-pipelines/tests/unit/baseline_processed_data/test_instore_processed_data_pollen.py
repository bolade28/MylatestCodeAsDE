from datetime import date, datetime
from decimal import Decimal
from unittest import mock

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.instore_processed_data_pollen import (
    entrypoint,
    prepare_instore_processed_data,
)
from spark_pipeline.common.variables import InstoreConfig
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.instore_processed_data import InstoreProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    drop_load_ts,
    local_spark_s3_overwrite,
    write_pipeline_inputs_to_parquet,
)


ITEM_JSON = '[{"skuId": "sku-1"}]'
STORE_JSON = '["STORE1"]'


# Note: scenarios are tested in the helper test file, so these tests focus on the end-to-end integration, rather than a broad number of scenarios
def test_instore_pollen_merged_output_with_pollen_precedence(spark_session: SparkSession, tmp_path):
    # Arrange a valid pollen booking plus one historic DTP-only metric row.
    campaign_booking_media_channel_path = str(tmp_path / "campaign_booking_media_channel")
    cust_by_location_path = str(tmp_path / "cust_by_location")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    historic_instore_processed_data_path = str(tmp_path / "historic_instore_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            campaign_booking_media_channel_path,
            cust_by_location_path,
            sku_cluster_mapping_path,
            historic_instore_processed_data_path,
        ],
        rows_list=[
            [("b1", "camp-1", "instore", "completed", "instore", "sainsbury", 20.0, "2024-01-01", "2024-01-01", ITEM_JSON, STORE_JSON)],
            [(datetime(2024, 1, 1, 0, 0, 0), "STORE1", 30)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [(date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "IN-STORE", "IN-STORE", "TOTAL", "EXPOSED_CUSTOMERS", 12.0)],
        ],
        schemas=[
            InstoreProcessedData.instore_campaign_booking_input_schema,
            InstoreProcessedData.instore_cust_by_location_schema,
            ProcessedData.sku_cluster_mapping_schema,
            InstoreProcessedData.instore_merge_input_schema,
        ],
    )

    # patch the writer function so the test performs a normal local parquet write.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.instore_processed_data_pollen.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_instore_processed_data(
            spark=spark_session,
            campaign_booking_media_channel_path=campaign_booking_media_channel_path,
            cust_by_location_path=cust_by_location_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            historic_instore_processed_data=historic_instore_processed_data_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            correlation_id="corr-instore-pollen",
            output_path=output_path,
        )

    # Assert: pollen rows are written and the unmatched historic row is preserved after merge normalization.
    actual_df = spark_session.read.parquet(output_path)
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", InstoreConfig.MARKETING_TYPE, InstoreConfig.MARKETING_CHANNEL, InstoreConfig.MARKETING_SUB_CHANNEL, "TOTAL_MEDIA_COST", Decimal("20.00000"), "NA", None),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", InstoreConfig.MARKETING_TYPE, InstoreConfig.MARKETING_CHANNEL, InstoreConfig.MARKETING_SUB_CHANNEL, "EXPOSED_CUSTOMERS", Decimal("30.00000"), "NA", None),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "IN-STORE", "IN-STORE", "TOTAL", "EXPOSED_CUSTOMERS", Decimal("12.00000"), "NA", None),
        ],
        schema=InstoreProcessedData.instore_merge_output_schema,
    )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_instore_pollen_empty_output_without_bookings_or_history(spark_session: SparkSession, tmp_path):
    # Arrange a booking outside the in-store filter and an empty historic dataset.
    campaign_booking_media_channel_path = str(tmp_path / "campaign_booking_media_channel")
    cust_by_location_path = str(tmp_path / "cust_by_location")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    historic_instore_processed_data_path = str(tmp_path / "historic_instore_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            campaign_booking_media_channel_path,
            cust_by_location_path,
            sku_cluster_mapping_path,
            historic_instore_processed_data_path,
        ],
        rows_list=[
            [("b1", "camp-1", "onsite", "completed", "ecoupon", "sainsbury", 20.0, "2024-01-01", "2024-01-01", ITEM_JSON, STORE_JSON)],
            [(datetime(2024, 1, 1, 0, 0, 0), "STORE1", 30)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [],
        ],
        schemas=[
            InstoreProcessedData.instore_campaign_booking_input_schema,
            InstoreProcessedData.instore_cust_by_location_schema,
            ProcessedData.sku_cluster_mapping_schema,
            InstoreProcessedData.instore_merge_input_schema,
        ],
    )

    # Act: with no qualifying pollen campaigns and no historic data, the final output should be empty.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.instore_processed_data_pollen.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_instore_processed_data(
            spark=spark_session,
            campaign_booking_media_channel_path=campaign_booking_media_channel_path,
            cust_by_location_path=cust_by_location_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            historic_instore_processed_data=historic_instore_processed_data_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            correlation_id="corr-empty",
            output_path=output_path,
        )

    # Assert: the merged output parquet is empty.
    expected_df = spark_session.createDataFrame([], schema=InstoreProcessedData.instore_merge_output_schema)
    assert_spark_df_equal(spark_session.read.parquet(output_path), expected_df)


def test_entrypoint_invokes_prepare_instore_processed_data_pollen_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current Instore pollen entrypoint contract.
    args = [
        "--campaign-booking-media-channel-path", "s3://input/campaign-bookings",
        "--cust-by-location-path", "s3://input/cust-by-location",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--historic-instore-processed-data", "s3://input/historic-instore",
        "--start-date", "2024-01-01",
        "--end-date", "2024-01-31",
        "--correlation-id", "corr-entrypoint",
        "--output-path", "s3://output/instore",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.marketing_features.instore_processed_data_pollen.prepare_instore_processed_data") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        campaign_booking_media_channel_path="s3://input/campaign-bookings",
        cust_by_location_path="s3://input/cust-by-location",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        historic_instore_processed_data="s3://input/historic-instore",
        start_date="2024-01-01",
        end_date="2024-01-31",
        correlation_id="corr-entrypoint",
        output_path="s3://output/instore",
    )
