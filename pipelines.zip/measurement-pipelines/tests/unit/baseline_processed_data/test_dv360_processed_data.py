from datetime import date
from unittest import mock

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data import (
    entrypoint,
    prepare_dv360_processed_data,
)
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.dv360_processed_data import DV360ProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_spark_df_equal,
    local_spark_s3_overwrite,
    write_pipeline_inputs_to_parquet,
)

# Note: scenarios are tested in the helper test file, so these tests focus on the end-to-end integration, rather than a broad number of scenarios


def test_dv360_outputs_zero_filled_cluster_metrics(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange parquet inputs with one mapped campaign week and a second modelling week for zero-fill logic.
    dv360_normalised_path = str(tmp_path / "dv360_normalised")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    dv360_media_report_path = str(tmp_path / "dv360_media_report")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            dv360_normalised_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
            dv360_media_report_path,
        ],
        rows_list=[
            [(date(2024, 1, 1), date(2024, 1, 2), "sku-1", "camp-1", "DISPLAY")],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [(date(2024, 1, 1),), (date(2024, 1, 8),)],
            [
                ("camp-1", date(2024, 1, 1), 90.0, 80.0, 10.0, 100.0, 50.0),
                ("camp-1", date(2024, 1, 2), 110.0, 100.0, 20.0, 200.0, 60.0),
            ],
        ],
        schemas=[
            DV360ProcessedData.dv360_normalised_dtp_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
            DV360ProcessedData.dv360_media_report_dtp_input_schema,
        ],
    )

    # patch the safe writer so the test performs a normal local parquet write.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        actual_df = prepare_dv360_processed_data(
            spark=spark_session,
            dv360_normalised_path=dv360_normalised_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            dv360_media_report_path=dv360_media_report_path,
            output_path=output_path,
            correlation_id="corr-dv360",
        )

    # Assert: the first week contains observed metrics and the second week is zero-filled for all metric rows.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "impressions", 300.0, "corr-dv360"),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "clicks", 30.0, "corr-dv360"),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "measurable_impressions", 200.0, "corr-dv360"),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "viewable_impressions", 180.0, "corr-dv360"),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "campaign_spend", 110.0, "corr-dv360"),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "impressions", 0.0, "corr-dv360"),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "clicks", 0.0, "corr-dv360"),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "measurable_impressions", 0.0, "corr-dv360"),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "viewable_impressions", 0.0, "corr-dv360"),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "campaign_spend", 0.0, "corr-dv360"),
        ],
        schema=actual_df.schema,
    )

    assert_spark_df_equal(actual_df, expected_df)
    assert_spark_df_equal(
        spark_session.read.parquet(output_path).select(*ProcessedData.shared_timestamp_output_with_job_run_id_double_schema.fieldNames()),
        expected_df,
    )


def test_dv360_empty_output_when_no_skus_map_clusters(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange parquet inputs where all normalized DV360 rows miss the SKU cluster mapping.
    dv360_normalised_path = str(tmp_path / "dv360_normalised")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    dv360_media_report_path = str(tmp_path / "dv360_media_report")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            dv360_normalised_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
            dv360_media_report_path,
        ],
        rows_list=[
            [(date(2024, 1, 1), date(2024, 1, 2), "sku-x", "camp-1", "DISPLAY")],  # Incorrect sku mapping
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [(date(2024, 1, 1),)],
            [("camp-1", date(2024, 1, 1), 90.0, 80.0, 10.0, 100.0, 50.0)],
        ],
        schemas=[
            DV360ProcessedData.dv360_normalised_dtp_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
            DV360ProcessedData.dv360_media_report_dtp_input_schema,
        ],
    )

    # Act: with no mapped brand SKUs, the pipeline should still write an empty final dataframe.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        actual_df = prepare_dv360_processed_data(
            spark=spark_session,
            dv360_normalised_path=dv360_normalised_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            dv360_media_report_path=dv360_media_report_path,
            output_path=output_path,
            correlation_id="corr-empty",
        )

    # Assert: no mapped campaigns means no skeleton rows and therefore an empty output.
    expected_df = spark_session.createDataFrame([], schema=actual_df.schema)
    assert_spark_df_equal(actual_df, expected_df)
    assert_spark_df_equal(
        spark_session.read.parquet(output_path).select(*ProcessedData.shared_timestamp_output_with_job_run_id_double_schema.fieldNames()),
        expected_df,
    )


def test_entrypoint_invokes_prepare_dv360_processed_data_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current DV360 DTP entrypoint contract.
    args = [
        "--dv360-normalised-path", "s3://input/dv360-normalised",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--weekly-dates-path", "s3://input/weekly-dates",
        "--dv360-media-report-path", "s3://input/dv360-report",
        "--output-path", "s3://output/dv360",
        "--correlation-id", "corr-entrypoint",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data.prepare_dv360_processed_data") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        dv360_normalised_path="s3://input/dv360-normalised",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        weekly_dates_path="s3://input/weekly-dates",
        dv360_media_report_path="s3://input/dv360-report",
        output_path="s3://output/dv360",
        correlation_id="corr-entrypoint",
    )
