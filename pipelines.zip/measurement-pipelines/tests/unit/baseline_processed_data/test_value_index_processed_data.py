from datetime import date
from decimal import Decimal
from unittest import mock

import pytest
from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.value_index_processed_data import (
    calculate_value_indices,
    entrypoint,
    get_final_result,
    get_value_index_item_cd_cluster,
    join_with_skeleton,
    prepare_value_index_processed_data,
    unpivot_data,
)
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.value_index_processed_data import ValueIndexProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_spark_df_equal,
    local_spark_s3_overwrite,
    write_pipeline_inputs_to_parquet,
)


# ----- Helper functions ------
def _read_value_index_output(spark_session: SparkSession, output_path: str):
    # Read only the stable final columns that are part of the contract.
    return spark_session.read.parquet(output_path).select(*ProcessedData.shared_date_output_decimal_38_2_schema.fieldNames())


@pytest.fixture
def value_index_test_dfs(spark_session: SparkSession):
    # Keep one standard fixture since value-index tests reuse the same decimal-heavy shapes across stages.
    agg_value_index_dashboard_w_df = spark_session.createDataFrame(
        [
            # TESCO row with sku in sku cluster mapping and date within the filter range.
            # This exercises the normal case where a key retailer contributes to both metrics and is retained in the cluster-level join.
            ("ITEM001", Decimal("1000.00"), Decimal("500.00"), "TESCO_Retailer1", date(2024, 1, 30)),
            # Same as above
            ("ITEM002", Decimal("800.00"), Decimal("400.00"), "ALDI_Retailer2", date(2024, 1, 30)),
            # Non-key "Other" retailer row that is intentionally unmapped in the SKU-cluster data,
            # so it is dropped by `get_value_index_item_cd_cluster` before downstream calculations.
            ("ITEM003", Decimal("1200.00"), Decimal("600.00"), "Other_Retailer3", date(2024, 2, 6)),
            # Second mapped TESCO row for ITEM001 with a zero secondary sales amount; this exercises the
            # zero-denominator edge case used by the value-index calculation tests.
            ("ITEM001", Decimal("100.00"), Decimal("0.00"), "TESCO_Retailer1", date(2024, 2, 6)),
            # Mapped later TESCO row that sits outside the narrower end-date used in the filter test,
            # so it helps prove that late rows are excluded when the requested range ends earlier.
            ("ITEM004", Decimal("500.00"), Decimal("250.00"), "TESCO_Retailer4", date(2024, 2, 13)),
        ],
        schema=ValueIndexProcessedData.value_index_dashboard_renamed_schema,
    )
    sku_cluster_mapping_df = spark_session.createDataFrame(
        [
            ("ITEM001", "CatX", "SubA", "BrandA", "1"),
            ("ITEM002", "CatY", "SubB", "BrandB", "2"),
            ("ITEM004", "CatX", "SubA", "BrandA", "1"),
        ],
        schema=ProcessedData.sku_cluster_mapping_schema
    )
    weekly_dates_df = spark_session.createDataFrame(
        [(date(2024, 1, 28),), (date(2024, 2, 4),), (date(2024, 2, 11),), (date(2024, 2, 18),)],
        schema=ProcessedData.weekly_dates_schema,
    )

    return {
        "agg_value_index_dashboard_w_df": agg_value_index_dashboard_w_df,
        "sku_cluster_mapping_df": sku_cluster_mapping_df,
        "weekly_dates_df": weekly_dates_df,
    }


def test_get_value_index_item_cd_cluster_filters_to_mapped_items_and_date_range(
    spark_session: SparkSession,
    value_index_test_dfs,
):
    # Arrange value-index rows with both in-range and out-of-range dates plus an unmapped item.
    agg_value_index_dashboard_w_df = value_index_test_dfs["agg_value_index_dashboard_w_df"]
    sku_cluster_mapping_df = value_index_test_dfs["sku_cluster_mapping_df"]

    # Act: only mapped rows inside the requested campaign weeks should remain.
    actual_df = get_value_index_item_cd_cluster(
        agg_value_index_dashboard_w_df,
        sku_cluster_mapping_df,
        "2024-01-01",
        "2024-02-04",
    )

    # Assert: ITEM003 is dropped because it is unmapped, and later dates outside the range are excluded.
    expected_df = spark_session.createDataFrame(
        [
            (Decimal("1000.00"), Decimal("500.00"), "TESCO_Retailer1", date(2024, 1, 30), "CatX", "BrandA", "1"),
            (Decimal("800.00"), Decimal("400.00"), "ALDI_Retailer2", date(2024, 1, 30), "CatY", "BrandB", "2"),
        ],
        schema=ValueIndexProcessedData.value_index_item_cd_cluster_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


@pytest.mark.parametrize("end_day", range(5, 12))
def test_value_indices_include_wednesday_load_for_campaign_end_week(
    spark_session: SparkSession,
    value_index_test_dfs,
    end_day: int,
):
    dashboard_df = spark_session.createDataFrame(
        [
            ("ITEM001", Decimal("1000.00"), Decimal("500.00"), "TESCO_Retailer1", process_dt)
            for process_dt in [date(2024, 1, 24), date(2024, 1, 31), date(2024, 2, 7), date(2024, 2, 14)]
        ],
        schema=ValueIndexProcessedData.value_index_dashboard_renamed_schema,
    )

    filtered_df = get_value_index_item_cd_cluster(
        dashboard_df,
        value_index_test_dfs["sku_cluster_mapping_df"],
        "2024-02-01",
        date(2024, 2, end_day).isoformat(),
    )
    actual_df = calculate_value_indices(filtered_df, BaselineProcessedData.value_index_config)

    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 29), "CatX", "BrandA", "1", Decimal("200.00"), Decimal("200.00")),
            (date(2024, 2, 5), "CatX", "BrandA", "1", Decimal("200.00"), Decimal("200.00")),
        ],
        schema=ValueIndexProcessedData.value_index_all_metrics_schema,
    )
    assert_spark_df_equal(actual_df, expected_df)


def test_get_value_index_item_cd_cluster_returns_empty_when_no_rows_match_filters(
    spark_session: SparkSession,
    value_index_test_dfs,
):
    # Arrange the same source data but request a date range with no matching rows.
    agg_value_index_dashboard_w_df = value_index_test_dfs["agg_value_index_dashboard_w_df"]
    sku_cluster_mapping_df = value_index_test_dfs["sku_cluster_mapping_df"]

    # Act: a non-overlapping date range should produce no joined value-index rows.
    actual_df = get_value_index_item_cd_cluster(
        agg_value_index_dashboard_w_df,
        sku_cluster_mapping_df,
        "2024-03-01",
        "2024-03-31",
    )

    # Assert: downstream aggregation receives an empty DataFrame with the expected schema.
    expected_df = spark_session.createDataFrame([], schema=ValueIndexProcessedData.value_index_item_cd_cluster_schema)
    assert_spark_df_equal(actual_df, expected_df)


def test_calculate_value_indices_computes_all_and_key_retailer_metrics(
    spark_session: SparkSession,
):
    # Arrange cluster-level rows covering key and non-key retailers across two weeks.
    value_index_item_cd_cluster_df = spark_session.createDataFrame(
        [
            (Decimal("1000.00"), Decimal("500.00"), "TESCO_Retailer1", date(2024, 1, 30), "CatX", "BrandA", "1"),
            (Decimal("100.00"), Decimal("0.00"), "TESCO_Retailer1", date(2024, 2, 6), "CatX", "BrandA", "1"),
            (Decimal("800.00"), Decimal("400.00"), "ALDI_Retailer2", date(2024, 1, 30), "CatY", "BrandB", "2"),
            (Decimal("1200.00"), Decimal("600.00"), "Other_Retailer3", date(2024, 2, 6), "CatX", "BrandC", "3"),
        ],
        schema=ValueIndexProcessedData.value_index_item_cd_cluster_schema,
    )

    # Act: the function should compute all-retailer and key-retailer ratios per cluster/week.
    actual_df = calculate_value_indices(
        value_index_item_cd_cluster_df,
        BaselineProcessedData.value_index_config,
    )

    # Assert: BrandA week 2024-02-04 uses the zero-denominator fallback for all retailers and returns 0 for key retailers.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 28), "CatX", "BrandA", "1", Decimal("200.00"), Decimal("200.00")),
            (date(2024, 1, 28), "CatY", "BrandB", "2", Decimal("200.00"), Decimal("200.00")),
            (date(2024, 2, 4), "CatX", "BrandA", "1", Decimal("10000.00"), Decimal("0.00")),
            (date(2024, 2, 4), "CatX", "BrandC", "3", Decimal("200.00"), Decimal("0.00")),
        ],
        schema=ValueIndexProcessedData.value_index_all_metrics_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_join_with_skeleton_zero_fills_missing_weeks_and_adds_static_hierarchy(
    spark_session: SparkSession,
):
    # Arrange a skeleton containing one missing week plus one populated week.
    value_index_skeleton_final_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 28), "CatX", "BrandA", "1"),
            (date(2024, 2, 4), "CatX", "BrandA", "1"),
        ],
        schema=ValueIndexProcessedData.value_index_skeleton_schema,
    )
    value_index_all_metrics_df = spark_session.createDataFrame(
        [(date(2024, 1, 28), "CatX", "BrandA", "1", Decimal("200.00"), Decimal("200.00"))],
        schema=ValueIndexProcessedData.value_index_all_metrics_schema,
    )

    # Act: missing metric rows should be filled with zero and static marketing labels should be added.
    actual_df = join_with_skeleton(
        value_index_skeleton_final_df,
        value_index_all_metrics_df,
        BaselineProcessedData.value_index_config,
    )

    # Assert: the week without observed metrics still appears with zero-valued indices.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 28), "CatX", "BrandA", "1", "VALUE INDEX", "VALUE INDEX", "TOTAL", Decimal("200.00"), Decimal("200.00")),
            (date(2024, 2, 4), "CatX", "BrandA", "1", "VALUE INDEX", "VALUE INDEX", "TOTAL", Decimal("0.00"), Decimal("0.00")),
        ],
        schema=ValueIndexProcessedData.value_index_joined_skeleton_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_unpivot_data_creates_two_metric_rows_for_each_skeleton_row(
    spark_session: SparkSession,
):
    # Arrange one joined skeleton row containing both value-index metrics.
    value_index_unique_brand_cluster_hierarchy_df = spark_session.createDataFrame(
        [(date(2024, 1, 28), "CatX", "BrandA", "1", "VALUE INDEX", "VALUE INDEX", "TOTAL", Decimal("200.00"), Decimal("150.00"))],
        schema=ValueIndexProcessedData.value_index_joined_skeleton_schema,
    )

    # Act: the two metric columns should become two metric rows with the job run id attached.
    actual_df = unpivot_data(
        value_index_unique_brand_cluster_hierarchy_df,
        "corr-unpivot",
        BaselineProcessedData.value_index_config,
    )

    # Assert: all-retailer and key-retailer metrics are both emitted.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 28), "CatX", "BrandA", "VALUE INDEX", "VALUE INDEX", "TOTAL", "1", "all_retailer_value_index", Decimal("200.00"), "corr-unpivot"),
            (date(2024, 1, 28), "CatX", "BrandA", "VALUE INDEX", "VALUE INDEX", "TOTAL", "1", "key_retailer_value_index", Decimal("150.00"), "corr-unpivot"),
        ],
        schema=ValueIndexProcessedData.value_index_unpivoted_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_get_final_result_renames_columns_to_output_contract(
    spark_session: SparkSession,
):
    # Arrange unpivoted rows in the pre-output column names.
    value_index_processed_data_df = spark_session.createDataFrame(
        [(date(2024, 1, 28), "CatX", "BrandA", "VALUE INDEX", "VALUE INDEX", "TOTAL", "1", "all_retailer_value_index", Decimal("200.00"), "corr-final")],
        schema=ValueIndexProcessedData.value_index_unpivoted_schema,
    )

    # Act: the formatter should rename columns into the final processed-data contract.
    actual_df = get_final_result(value_index_processed_data_df)

    # Assert: the final output uses the standard processed-data naming convention.
    expected_df = spark_session.createDataFrame(
        [(date(2024, 1, 28), "CatX", "BrandA", "1", "VALUE INDEX", "VALUE INDEX", "TOTAL", "all_retailer_value_index", Decimal("200.00"), "corr-final")],
        schema=ProcessedData.shared_date_output_decimal_38_2_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


@pytest.mark.parametrize("end_date", ["2024-02-12", "2024-02-13", "2024-02-14", "2024-02-29"])
def test_prepare_value_index_processed_data_writes_expected_output(
    spark_session: SparkSession,
    tmp_path,
    end_date: str,
):
    # Arrange parquet inputs covering populated metrics and one missing week for the skeleton.
    agg_value_index_dashboard_w_path = str(tmp_path / "agg_value_index_dashboard_w")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            agg_value_index_dashboard_w_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [
                ("ITEM001", Decimal("1000.00"), Decimal("500.00"), "TESCO_Retailer1", date(2024, 1, 30)),
                ("ITEM002", Decimal("800.00"), Decimal("400.00"), "ALDI_Retailer2", date(2024, 1, 30)),
                ("ITEM004", Decimal("500.00"), Decimal("250.00"), "TESCO_Retailer4", date(2024, 2, 14)),
                ("ITEM999", Decimal("900.00"), Decimal("450.00"), "TESCO_Retailer9", date(2024, 1, 30)),
            ],
            [
                ("ITEM001", "CatX", "SubA", "BrandA", "1"),
                ("ITEM002", "CatY", "SubB", "BrandB", "2"),
                ("ITEM004", "CatX", "SubA", "BrandA", "1"),
            ],
            [
                (date(2024, 1, 28),),
                (date(2024, 2, 4),),
                (date(2024, 2, 12),),
            ],
        ],
        schemas=[
            ValueIndexProcessedData.value_index_dashboard_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    # patch the writer so the test performs a normal local parquet write.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.value_index_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        actual_df = prepare_value_index_processed_data(
            spark=spark_session,
            agg_value_index_dashboard_w_path=agg_value_index_dashboard_w_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
            start_date="2024-01-01",
            end_date=end_date,
            correlation_id="corr-123",
        )

    # Assert: the output contains observed metrics plus zero-filled skeleton weeks and is written to parquet.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 28), "CatX", "BrandA", "1", "VALUE INDEX", "VALUE INDEX", "TOTAL", "all_retailer_value_index", Decimal("200.00"), "corr-123"),
            (date(2024, 1, 28), "CatX", "BrandA", "1", "VALUE INDEX", "VALUE INDEX", "TOTAL", "key_retailer_value_index", Decimal("200.00"), "corr-123"),
            (date(2024, 1, 28), "CatY", "BrandB", "2", "VALUE INDEX", "VALUE INDEX", "TOTAL", "all_retailer_value_index", Decimal("200.00"), "corr-123"),
            (date(2024, 1, 28), "CatY", "BrandB", "2", "VALUE INDEX", "VALUE INDEX", "TOTAL", "key_retailer_value_index", Decimal("200.00"), "corr-123"),
            (date(2024, 2, 4), "CatX", "BrandA", "1", "VALUE INDEX", "VALUE INDEX", "TOTAL", "all_retailer_value_index", Decimal("0.00"), "corr-123"),
            (date(2024, 2, 4), "CatX", "BrandA", "1", "VALUE INDEX", "VALUE INDEX", "TOTAL", "key_retailer_value_index", Decimal("0.00"), "corr-123"),
            (date(2024, 2, 4), "CatY", "BrandB", "2", "VALUE INDEX", "VALUE INDEX", "TOTAL", "all_retailer_value_index", Decimal("0.00"), "corr-123"),
            (date(2024, 2, 4), "CatY", "BrandB", "2", "VALUE INDEX", "VALUE INDEX", "TOTAL", "key_retailer_value_index", Decimal("0.00"), "corr-123"),
            (date(2024, 2, 12), "CatX", "BrandA", "1", "VALUE INDEX", "VALUE INDEX", "TOTAL", "all_retailer_value_index", Decimal("200.00"), "corr-123"),
            (date(2024, 2, 12), "CatX", "BrandA", "1", "VALUE INDEX", "VALUE INDEX", "TOTAL", "key_retailer_value_index", Decimal("200.00"), "corr-123"),
            (date(2024, 2, 12), "CatY", "BrandB", "2", "VALUE INDEX", "VALUE INDEX", "TOTAL", "all_retailer_value_index", Decimal("0.00"), "corr-123"),
            (date(2024, 2, 12), "CatY", "BrandB", "2", "VALUE INDEX", "VALUE INDEX", "TOTAL", "key_retailer_value_index", Decimal("0.00"), "corr-123"),
        ],
        schema=ProcessedData.shared_date_output_decimal_38_2_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)
    assert_spark_df_equal(_read_value_index_output(spark_session, output_path), expected_df)


def test_prepare_value_index_processed_data_writes_empty_output_when_no_rows_match(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange parquet inputs where all dashboard rows are filtered out by the requested date range.
    agg_value_index_dashboard_w_path = str(tmp_path / "agg_value_index_dashboard_w")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            agg_value_index_dashboard_w_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [
                ("ITEM001", Decimal("1000.00"), Decimal("500.00"), "TESCO_Retailer1", date(2024, 1, 30)),
            ],
            [
                ("ITEM001", "CatX", "SubA", "BrandA", "1"),
            ],
            [
                (date(2024, 1, 28),),
            ],
        ],
        schemas=[
            ValueIndexProcessedData.value_index_dashboard_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    # Act: with no matched rows, the pipeline should still write an empty DataFrame with the final schema.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.value_index_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        actual_df = prepare_value_index_processed_data(
            spark=spark_session,
            agg_value_index_dashboard_w_path=agg_value_index_dashboard_w_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
            start_date="2024-03-01",
            end_date="2024-03-31",
            correlation_id="corr-empty",
        )

    # Assert: no matched input rows means no derived clusters, so the output is empty but schema-correct.
    expected_df = spark_session.createDataFrame([], schema=ProcessedData.shared_date_output_decimal_38_2_schema)
    assert_spark_df_equal(actual_df, expected_df)
    assert_spark_df_equal(_read_value_index_output(spark_session, output_path), expected_df)


def test_entrypoint_invokes_prepare_value_index_processed_data_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current entrypoint contract.
    args = [
        "--agg-value-index-dashboard-w-path", "s3://input/value-index",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--weekly-dates-path", "s3://input/weekly-dates",
        "--output-path", "s3://output/value-index",
        "--correlation-id", "corr-entrypoint",
        "--start-date", "2024-01-01",
        "--end-date", "2024-12-31",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.value_index_processed_data.prepare_value_index_processed_data") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        agg_value_index_dashboard_w_path="s3://input/value-index",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        weekly_dates_path="s3://input/weekly-dates",
        output_path="s3://output/value-index",
        correlation_id="corr-entrypoint",
        start_date="2024-01-01",
        end_date="2024-12-31",
    )
