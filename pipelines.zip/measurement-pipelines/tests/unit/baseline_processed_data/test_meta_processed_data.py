from datetime import date, datetime
from decimal import Decimal
from unittest import mock
from unittest.mock import patch

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data import (
    entrypoint,
    prepare_meta_processed_data,
)
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.meta_processed_data import MetaProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_spark_df_equal,
    write_pipeline_inputs_to_parquet,
    local_spark_s3_overwrite
)


def _read_meta_output(spark_session: SparkSession, output_path: str):
    return spark_session.read.parquet(output_path).select(*ProcessedData.meta_output_schema.fieldNames())


def test_prepare_meta_processed_data_writes_expected_zero_filled_weekly_output(spark_session: SparkSession, tmp_path):
    # Arrange campaign, insight, cluster, and weekly date inputs with one populated week and one missing week.
    fb_campaign_normalize_path = str(tmp_path / "fb_campaign_normalize")
    fb_insight_normalize_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            fb_campaign_normalize_path,
            fb_insight_normalize_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [("job-1", None, "camp-1", date(2024, 1, 1), date(2024, 1, 7), "sku-1")],
            [("camp-1", datetime(2024, 1, 1, 0, 0, 0), 10, 100, 5.0, 15.0)],
            [("sku-1", "CRISPS & SNACKS", "SUB A", "BARE|PEPSICO", "CL1")],
            [(date(2024, 1, 1),), (date(2024, 1, 8),)],
        ],
        schemas=[
            MetaProcessedData.meta_campaign_normalize_schema,
            MetaProcessedData.meta_insight_normalize_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: the top-level Meta DTP pipeline should write formatted output using the helper stages.
        prepare_meta_processed_data(
            spark=spark_session,
            fb_campaign_normalize_path=fb_campaign_normalize_path,
            fb_insight_normalize_path=fb_insight_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
        )

        # Assert: one observed week and one zero-filled week are written for each Meta metric.
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "CLICKS", Decimal("10.00000")),
                (date(2024, 1, 1), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("100.00000")),
                (date(2024, 1, 1), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "INTERNALS_MEDIA_SPEND", Decimal("5.00000")),
                (date(2024, 1, 1), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "EXTERNALS_MEDIA_SPEND", Decimal("15.00000")),
                (date(2024, 1, 8), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "CLICKS", Decimal("0.00000")),
                (date(2024, 1, 8), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("0.00000")),
                (date(2024, 1, 8), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "INTERNALS_MEDIA_SPEND", Decimal("0.00000")),
                (date(2024, 1, 8), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "EXTERNALS_MEDIA_SPEND", Decimal("0.00000")),
            ],
            schema=ProcessedData.meta_output_schema,
        )

        assert_spark_df_equal(_read_meta_output(spark_session, output_path), expected_df)


def test_meta_empty_output_when_no_skus_map_clusters(spark_session: SparkSession, tmp_path):
    # Arrange inputs where the Meta campaign SKU is not present in the cluster mapping.
    fb_campaign_normalize_path = str(tmp_path / "fb_campaign_normalize")
    fb_insight_normalize_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            fb_campaign_normalize_path,
            fb_insight_normalize_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [("job-1", None, "camp-1", date(2024, 1, 1), date(2024, 1, 7), "sku-x")],
            [("camp-1", datetime(2024, 1, 1, 0, 0, 0), 10, 100, 5.0, 15.0)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [(date(2024, 1, 1),)],
        ],
        schemas=[
            MetaProcessedData.meta_campaign_normalize_schema,
            MetaProcessedData.meta_insight_normalize_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: without mapped brand SKUs, the final output should be empty.
        prepare_meta_processed_data(
            spark=spark_session,
            fb_campaign_normalize_path=fb_campaign_normalize_path,
            fb_insight_normalize_path=fb_insight_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
        )

        # Assert: the pipeline still writes an empty dataframe with the final Meta schema.
        expected_df = spark_session.createDataFrame([], schema=ProcessedData.meta_output_schema)
        assert_spark_df_equal(_read_meta_output(spark_session, output_path), expected_df)


def test_meta_multiple_brands_write_rows_per_cluster(spark_session: SparkSession, tmp_path):
    # Arrange campaign, insight, cluster, and weekly-date inputs for two independent brands in the same modelling week.
    fb_campaign_normalize_path = str(tmp_path / "fb_campaign_normalize")
    fb_insight_normalize_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            fb_campaign_normalize_path,
            fb_insight_normalize_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [
                ("job-1", None, "camp-1", date(2024, 1, 1), date(2024, 1, 7), "sku-1"),  # Brand A campaign mapped to CL1
                ("job-2", None, "camp-2", date(2024, 1, 1), date(2024, 1, 7), "sku-2"),  # Brand B campaign mapped to CL2
            ],
            [
                ("camp-1", datetime(2024, 1, 1, 0, 0, 0), 10, 100, 5.0, 15.0),  # Metrics for Brand A
                ("camp-2", datetime(2024, 1, 1, 0, 0, 0), 20, 200, 8.0, 18.0),  # Metrics for Brand B
            ],
            [
                ("sku-1", "CRISPS & SNACKS", "SUB A", "BARE|PEPSICO", "CL1"),
                ("sku-2", "SOFT DRINKS", "SUB B", "PEPSI MAX|PEPSICO", "CL2"),
            ],
            [(date(2024, 1, 1),)],
        ],
        schemas=[
            MetaProcessedData.meta_campaign_normalize_schema,
            MetaProcessedData.meta_insight_normalize_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: the DTP pipeline should emit one cluster-level metric set per mapped brand.
        prepare_meta_processed_data(
            spark=spark_session,
            fb_campaign_normalize_path=fb_campaign_normalize_path,
            fb_insight_normalize_path=fb_insight_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
        )

        # Assert: both brands appear in the final dataset with four metrics each.
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "CLICKS", Decimal("10.00000")),
                (date(2024, 1, 1), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("100.00000")),
                (date(2024, 1, 1), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "INTERNALS_MEDIA_SPEND", Decimal("5.00000")),
                (date(2024, 1, 1), "CRISPS & SNACKS", "BARE|PEPSICO", "CL1", "OFFSITE", "META", "TOTAL", "EXTERNALS_MEDIA_SPEND", Decimal("15.00000")),
                (date(2024, 1, 1), "SOFT DRINKS", "PEPSI MAX|PEPSICO", "CL2", "OFFSITE", "META", "TOTAL", "CLICKS", Decimal("20.00000")),
                (date(2024, 1, 1), "SOFT DRINKS", "PEPSI MAX|PEPSICO", "CL2", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("200.00000")),
                (date(2024, 1, 1), "SOFT DRINKS", "PEPSI MAX|PEPSICO", "CL2", "OFFSITE", "META", "TOTAL", "INTERNALS_MEDIA_SPEND", Decimal("8.00000")),
                (date(2024, 1, 1), "SOFT DRINKS", "PEPSI MAX|PEPSICO", "CL2", "OFFSITE", "META", "TOTAL", "EXTERNALS_MEDIA_SPEND", Decimal("18.00000")),
            ],
            schema=ProcessedData.meta_output_schema,
        )

        assert_spark_df_equal(_read_meta_output(spark_session, output_path), expected_df)


def test_meta_empty_output_when_insights_miss_campaigns(spark_session: SparkSession, tmp_path):
    # Arrange mapped campaign SKUs whose campaign_id never appears in the insight feed.
    fb_campaign_normalize_path = str(tmp_path / "fb_campaign_normalize")
    fb_insight_normalize_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            fb_campaign_normalize_path,
            fb_insight_normalize_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [("job-1", None, "camp-1", date(2024, 1, 1), date(2024, 1, 7), "sku-1")],
            [("camp-x", datetime(2024, 1, 1, 0, 0, 0), 10, 100, 5.0, 15.0)],  # Unmatched campaign_id, so no metrics should survive the required-campaign join
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [(date(2024, 1, 1),)],
        ],
        schemas=[
            MetaProcessedData.meta_campaign_normalize_schema,
            MetaProcessedData.meta_insight_normalize_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: with no matching insight campaign rows, the pipeline should produce no cluster-level metrics.
        prepare_meta_processed_data(
            spark=spark_session,
            fb_campaign_normalize_path=fb_campaign_normalize_path,
            fb_insight_normalize_path=fb_insight_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
        )

        # Assert: the final parquet is empty but still conforms to the Meta output schema.
        expected_df = spark_session.createDataFrame([], schema=ProcessedData.meta_output_schema)
        assert_spark_df_equal(_read_meta_output(spark_session, output_path), expected_df)


def test_entrypoint_invokes_prepare_meta_processed_data_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current Meta DTP entrypoint contract.
    args = [
        "--fb-campaign-normalize-path", "s3://input/fb-campaign",
        "--fb-insight-normalize-path", "s3://input/fb-insight",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--weekly-dates-path", "s3://input/weekly-dates",
        "--output-path", "s3://output/meta",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data.prepare_meta_processed_data") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        fb_campaign_normalize_path="s3://input/fb-campaign",
        fb_insight_normalize_path="s3://input/fb-insight",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        weekly_dates_path="s3://input/weekly-dates",
        output_path="s3://output/meta",
    )
