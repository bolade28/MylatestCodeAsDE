from datetime import date
from unittest import mock

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.sales_processed_data import (
    entrypoint,
    prepare_sales_processed_data,
)
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.sales_processed_data import SalesProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    drop_load_ts,
    local_spark_s3_overwrite,
    write_pipeline_inputs_to_parquet,
)


def test_prepare_sales_processed_data_writes_expected_cluster_level_output(
        spark_session: SparkSession,
        tmp_path,
):
    # Arrange parquet inputs covering duplicate item/week rows, unmapped SKUs, and out-of-model-range weeks.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    sales_data_transaction_path = str(tmp_path / "sales_data_transaction")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            sku_cluster_mapping_path,
            sales_data_transaction_path,
        ],
        rows_list=[
            [
                (date(2024, 1, 8),),
                (date(2024, 1, 15),),
            ],
            [
                ("item-1", "CatA", "SubA", "BrandA", "CL1"),
                ("item-2", "CatA", "SubA", "BrandA", "CL1"),
                ("item-3", "CatB", "SubB", "BrandB", "CL2"),
            ],
            [
                (date(2024, 1, 8), "item-1", 10.0),
                (date(2024, 1, 8), "item-1", 5.0),  # Same mapped SKU/week as the row above; aggregates into the same cluster total
                (date(2024, 1, 8), "item-2", 20.0),  # Second mapped SKU in CL1; contributes to the same cluster/week rollup
                (date(2024, 1, 15), "item-3", 7.0),  # Valid mapped sale for a different brand/cluster in the second modelling week
                (date(2024, 1, 1), "item-1", 999.0),  # Mapped SKU but outside the min weekly_dates bound, so removed by the final date filter
                (date(2024, 1, 22), "item-3", 8.0),  # Mapped SKU but beyond the max weekly_dates bound, so excluded from the final output
                (date(2024, 1, 8), "item-x", 100.0),  # Unknown SKU; fails the cluster-mapping join and never reaches aggregation
            ],
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            ProcessedData.sku_cluster_mapping_schema,
            SalesProcessedData.sales_data_transaction_input_schema,
        ],
    )

    # patch the writer so the test performs a normal local parquet write.
    with mock.patch(
            "spark_pipeline.baseline_processed_data.sales_processed_data.spark_s3_overwrite",
            side_effect=local_spark_s3_overwrite,
    ):
        prepare_sales_processed_data(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            sales_data_transaction=sales_data_transaction_path,
            output_path=output_path,
            correlation_id="corr-sales",
        )

    # Assert: duplicate mapped rows roll up by cluster/week, unmapped rows are dropped, and weeks outside the skeleton bounds are filtered out.
    actual_df = spark_session.read.parquet(output_path).select(*ProcessedData.shared_date_output_with_load_ts_double_schema.fieldNames())
    expected_df = spark_session.createDataFrame(
        [
            (
                date(2024, 1, 8),
                "CatA",
                "BrandA",
                "CL1",
                BaselineProcessedData.sales_data_config["marketing_type_name"],
                BaselineProcessedData.sales_data_config["marketing_channel_name"],
                BaselineProcessedData.sales_data_config["marketing_sub_channel_name"],
                BaselineProcessedData.sales_data_config["metric_name"],
                35.0,
                "corr-sales",
                None,
            ),
            (
                date(2024, 1, 15),
                "CatB",
                "BrandB",
                "CL2",
                BaselineProcessedData.sales_data_config["marketing_type_name"],
                BaselineProcessedData.sales_data_config["marketing_channel_name"],
                BaselineProcessedData.sales_data_config["marketing_sub_channel_name"],
                BaselineProcessedData.sales_data_config["metric_name"],
                7.0,
                "corr-sales",
                None,
            ),
        ],
        schema=ProcessedData.shared_date_output_with_load_ts_double_schema,
    )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_sales_processed_data_empty_output_when_all_skus_unmapped(
        spark_session: SparkSession,
        tmp_path,
):
    # Arrange parquet inputs where no sales item exists in the SKU cluster mapping.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    sales_data_transaction_path = str(tmp_path / "sales_data_transaction")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            sku_cluster_mapping_path,
            sales_data_transaction_path,
        ],
        rows_list=[
            [(date(2024, 1, 8),)],
            [("item-1", "CatA", "SubA", "BrandA", "CL1")],
            [
                (date(2024, 1, 8), "item-x", 10.0),  # Unmapped SKU; filtered out by the inner join to sku_cluster_mapping
                (date(2024, 1, 8), "item-y", 20.0),  # Another unmapped SKU; included to show all rows can be dropped before aggregation
            ],
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            ProcessedData.sku_cluster_mapping_schema,
            SalesProcessedData.sales_data_transaction_input_schema,
        ],
    )

    # Act: with no mapped brand SKUs, the inner join should remove every row before aggregation.
    with mock.patch(
            "spark_pipeline.baseline_processed_data.sales_processed_data.spark_s3_overwrite",
            side_effect=local_spark_s3_overwrite,
    ):
        prepare_sales_processed_data(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            sales_data_transaction=sales_data_transaction_path,
            output_path=output_path,
            correlation_id="corr-empty-unmapped",
        )

    # Assert: the pipeline still writes an empty dataframe with the final output schema.
    actual_df = spark_session.read.parquet(output_path).select(*ProcessedData.shared_date_output_with_load_ts_double_schema.fieldNames())
    expected_df = spark_session.createDataFrame([], schema=ProcessedData.shared_date_output_with_load_ts_double_schema)
    assert_spark_df_equal(actual_df, expected_df)


def test_empty_output_for_weeks_outside_bounds(
        spark_session: SparkSession,
        tmp_path,
):
    # Arrange mapped sales rows that all fall outside the min/max week range derived from weekly_dates.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    sales_data_transaction_path = str(tmp_path / "sales_data_transaction")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            sku_cluster_mapping_path,
            sales_data_transaction_path,
        ],
        rows_list=[
            [(date(2024, 1, 15),)],
            [("item-1", "CatA", "SubA", "BrandA", "CL1")],
            [
                (date(2024, 1, 8), "item-1", 10.0),  # Valid mapped SKU, but earlier than the only modelling week so it is filtered out by date bounds
                (date(2024, 1, 22), "item-1", 20.0),  # Valid mapped SKU, but later than the only modelling week so it is also filtered out
            ],
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            ProcessedData.sku_cluster_mapping_schema,
            SalesProcessedData.sales_data_transaction_input_schema,
        ],
    )

    # Act: the intermediate aggregation is populated, but the final date-bound filter should remove every row.
    with mock.patch(
            "spark_pipeline.baseline_processed_data.sales_processed_data.spark_s3_overwrite",
            side_effect=local_spark_s3_overwrite,
    ):
        prepare_sales_processed_data(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            sales_data_transaction=sales_data_transaction_path,
            output_path=output_path,
            correlation_id="corr-empty-dates",
        )

    # Assert: rows outside the model-date bounds are excluded and an empty final dataset is still written.
    actual_df = spark_session.read.parquet(output_path).select(*ProcessedData.shared_date_output_with_load_ts_double_schema.fieldNames())
    expected_df = spark_session.createDataFrame([], schema=ProcessedData.shared_date_output_with_load_ts_double_schema)
    assert_spark_df_equal(actual_df, expected_df)


def test_entrypoint_invokes_prepare_sales_processed_data_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current sales entrypoint contract.
    args = [
        "--weekly-dates-path", "s3://input/weekly-dates",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--sales-data-transaction", "s3://input/sales-transactions",
        "--output-path", "s3://output/sales",
        "--correlation-id", "corr-entrypoint",
    ]

    # Act: the entrypoint should parse the arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.sales_processed_data.prepare_sales_processed_data") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed values.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        weekly_dates_path="s3://input/weekly-dates",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        sales_data_transaction="s3://input/sales-transactions",
        output_path="s3://output/sales",
        correlation_id="corr-entrypoint",
    )
