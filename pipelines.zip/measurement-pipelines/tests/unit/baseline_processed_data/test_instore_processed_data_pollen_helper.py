from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.instore_processed_data_pollen_helper import (
    aggregate_daily_costs_to_weekly,
    build_campaign_durations_sku_level,
    build_instore_campaign_bookings,
    build_instore_campaigns,
    build_weekly_brand_metrics,
    build_weekly_exposed_customers,
    compute_daily_media_costs,
    explode_campaign_items,
    explode_campaign_stores,
    format_metrics_to_hierarchy,
    merge_pollen_and_dtp_data,
    read_instore_pollen_s3_inputs,
    split_media_cost_across_skus,
    unpivot_metrics_long_format,
)
from spark_pipeline.common.variables import InstoreConfig
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.instore_processed_data import InstoreProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    round_columns,
    write_rows_to_parquet, drop_load_ts,
)

# Helper functions
VALID_ITEM_JSON = '[{"skuId": 700}, {"skuId": 800}]'
VALID_STORE_JSON = '["100", "101"]'


# ----------------------------
# Tests for read_instore_pollen_s3_inputs
# ----------------------------

def test_read_instore_pollen_s3_inputs_loads_expected_columns(spark_session: SparkSession, tmp_path):
    # Arrange parquet inputs for bookings, customer-by-location and sku cluster mapping.
    campaign_booking_media_channel_path = str(tmp_path / "campaign_booking_media_channel")
    cust_by_location_path = str(tmp_path / "cust_by_location")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")

    write_rows_to_parquet(
        spark_session,
        campaign_booking_media_channel_path,
        [
            (
                "b1",
                "c1",
                InstoreConfig.CHANNEL_TYPE,
                InstoreConfig.BOOKING_STATUS[0],
                "instore",
                "sainsbury",
                10.0,
                "2021-01-05",
                "2021-01-10",
                VALID_ITEM_JSON,
                VALID_STORE_JSON,
            ),
        ],
        InstoreProcessedData.instore_campaign_booking_input_schema,
    )
    write_rows_to_parquet(
        spark_session,
        cust_by_location_path,
        [(datetime(2021, 1, 4, 0, 0, 0), "100", 10)],
        InstoreProcessedData.instore_cust_by_location_schema,
    )
    write_rows_to_parquet(
        spark_session,
        sku_cluster_mapping_path,
        [("700", "DAIRY", "BUTTER", "LURPAK | ARLA", "CL1")],
        ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: the read helper should load the three parquet sources and project the expected columns.
    result = read_instore_pollen_s3_inputs(
        spark=spark_session,
        campaign_booking_media_channel_path=campaign_booking_media_channel_path,
        cust_by_location_path=cust_by_location_path,
        sku_cluster_mapping_path=sku_cluster_mapping_path,
    )

    # Assert: the returned frames contain the expected source data in the expected shapes.
    expected_bookings = spark_session.createDataFrame(
        [
            (
                "b1",
                "c1",
                InstoreConfig.CHANNEL_TYPE,
                InstoreConfig.BOOKING_STATUS[0],
                "instore",
                "sainsbury",
                10.0,
                "2021-01-05",
                "2021-01-10",
                VALID_ITEM_JSON,
                VALID_STORE_JSON,
            ),
        ],
        schema=InstoreProcessedData.instore_campaign_booking_input_schema,
    )
    expected_cust = spark_session.createDataFrame(
        [(datetime(2021, 1, 4, 0, 0, 0), "100", 10)],
        schema=InstoreProcessedData.instore_cust_by_location_schema,
    )
    expected_sku = spark_session.createDataFrame(
        [("700", "DAIRY", "BUTTER", "LURPAK | ARLA", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    assert_spark_df_equal(result["campaign_booking_media_channel_br"], expected_bookings)
    assert_spark_df_equal(result["cust_by_location"], expected_cust)
    assert_spark_df_equal(result["sku_cluster_mapping"], expected_sku)


# ----------------------------
# Tests for build_instore_campaign_bookings
# ----------------------------

def test_build_instore_campaign_bookings_filters_and_parses_lists(spark_session: SparkSession):
    # Arrange valid and invalid campaign booking rows spanning filter branches.
    df = spark_session.createDataFrame(
        [
            (
                "b1",
                "c1",
                InstoreConfig.CHANNEL_TYPE,
                InstoreConfig.BOOKING_STATUS[0],
                "instore",
                "sainsbury",
                10.0,
                "2021-01-05",
                "2021-01-10",
                VALID_ITEM_JSON,
                VALID_STORE_JSON,
            ),
            (
                "b2",
                "~~",  # Invalid placeholder campaign id; filtered out by the campaign_id guard
                InstoreConfig.CHANNEL_TYPE,
                InstoreConfig.BOOKING_STATUS[0],
                "instore",
                "sainsbury",
                10.0,
                "2021-01-05",
                "2021-01-10",
                VALID_ITEM_JSON,
                VALID_STORE_JSON,
            ),
            (
                "b3",
                "c3",
                InstoreConfig.CHANNEL_TYPE,
                InstoreConfig.BOOKING_STATUS[0],
                "coupon_at_till",  # Invalid media_provider for this flow; filtered out by the instore-only provider filter
                "sainsbury",
                10.0,
                "2021-01-05",
                "2021-01-10",
                VALID_ITEM_JSON,
                VALID_STORE_JSON,
            ),
            (
                "b4",
                "c4",
                InstoreConfig.CHANNEL_TYPE,
                InstoreConfig.BOOKING_STATUS[0],
                "instore",
                "tesco",  # Invalid media_business_group; filtered out because only sainsbury-style values are allowed
                10.0,
                "2021-01-05",
                "2021-01-10",
                VALID_ITEM_JSON,
                VALID_STORE_JSON,
            ),
            (
                "b5",
                "c5",
                InstoreConfig.CHANNEL_TYPE,
                InstoreConfig.BOOKING_STATUS[0],
                "instore",
                "sainsbury",
                10.0,
                "2021-01-05",
                "2021-01-10",
                "not-json",  # Invalid JSON; item_cd_list parsing fails and the row is filtered out
                VALID_STORE_JSON,
            ),
        ],
        schema=InstoreProcessedData.instore_campaign_booking_input_schema,
    )

    # Act: the helper should keep only valid instore campaign rows and parse both list columns from JSON.
    result = build_instore_campaign_bookings(df, start_date="2021-01-01", end_date="2021-01-31")

    # Assert: invalid campaign ids, media providers, business groups and malformed item JSON are filtered out.
    expected = spark_session.createDataFrame(
        [
            (
                "b1",
                "c1",
                10.0,
                date(2021, 1, 5),
                date(2021, 1, 10),
                False,
                ["100", "101"],
                [{"skuId": "700"}, {"skuId": "800"}],
            )
        ],
        schema=InstoreProcessedData.instore_campaign_bookings_output_schema,
    )

    assert_spark_df_equal(result, expected)


def test_build_instore_campaign_bookings_marks_invalid_date_range_true(spark_session: SparkSession):
    # Arrange a booking whose start date is after its end date but still falls in the requested window.
    df = spark_session.createDataFrame(
        [
            (
                "b1",
                "c1",
                InstoreConfig.CHANNEL_TYPE,
                InstoreConfig.BOOKING_STATUS[0],
                "instore",
                "sainsbury",
                10.0,
                "2021-01-10",
                "2021-01-05",
                VALID_ITEM_JSON,
                VALID_STORE_JSON,
            ),
        ],
        schema=InstoreProcessedData.instore_campaign_booking_input_schema,
    )

    # Act: invalid date ranges should not be discarded yet, but should be flagged for downstream logic.
    result = build_instore_campaign_bookings(df, start_date="2021-01-01", end_date="2021-01-31")

    # Assert: the row survives filtering and carries invalid_date_range=True.
    expected = spark_session.createDataFrame(
        [
            (
                "b1",
                "c1",
                10.0,
                date(2021, 1, 10),
                date(2021, 1, 5),
                True,
                ["100", "101"],
                [{"skuId": "700"}, {"skuId": "800"}],
            )
        ],
        schema=InstoreProcessedData.instore_campaign_bookings_output_schema,
    )

    assert_spark_df_equal(result, expected)


# ----------------------------
# Tests for explode_campaign_stores / explode_campaign_items
# ----------------------------

def test_explode_campaign_stores_explodes_to_one_row_per_store(spark_session: SparkSession):
    # Arrange a booking with two targeted stores.
    df = spark_session.createDataFrame(
        [("b1", "c1", ["100", "101"])],
        schema="booking_id string, master_campaign_id string, store_cd_list array<string>",
    )

    # Act: store ids should be exploded into one row per store.
    result = explode_campaign_stores(df)

    # Assert: each store becomes an individual location row.
    expected = spark_session.createDataFrame(
        [("b1", "c1", "100"), ("b1", "c1", "101")],
        schema=InstoreProcessedData.instore_store_flattened_schema,
    )

    assert_spark_df_equal(result, expected)


def test_explode_campaign_items_explodes_and_casts_item_cd_to_string(spark_session: SparkSession):
    # Arrange a booking with mixed string and numeric skuId values.
    df = spark_session.createDataFrame(
        [("b1", "c1", [{"skuId": "100"}, {"skuId": 200}])],
        schema="booking_id string, master_campaign_id string, item_cd_list array<struct<skuId:string>>",
    )

    # Act: sku objects should explode into one row per item and item_cd should remain string-typed.
    result = explode_campaign_items(df)

    # Assert: both items are emitted as strings.
    expected = spark_session.createDataFrame(
        [("b1", "c1", "100"), ("b1", "c1", "200")],
        schema=InstoreProcessedData.instore_items_flattened_schema,
    )

    assert_spark_df_equal(result, expected)


# ----------------------------
# Tests for build_instore_campaigns
# ----------------------------

def test_build_instore_campaigns_filters_null_brands(spark_session: SparkSession):
    # Arrange booking, item and store data where one campaign item has a null brand and should be dropped.
    campaign_bookings = spark_session.createDataFrame(
        [("b1", "c1", 12.0, date(2021, 1, 1), date(2021, 1, 7), False, ["100"], [{"skuId": "700"}])],
        schema=InstoreProcessedData.instore_campaign_bookings_output_schema,
    )
    campaign_items = spark_session.createDataFrame(
        [
            ("b1", "c1", "700", "DAIRY", "LURPAK | ARLA", "CL1"),
            ("b1", "c1", "701", "DAIRY", None, "CL1"),  # Invalid brand enrichment; filtered out because build_instore_campaigns requires non-null brand
        ],
        schema=InstoreProcessedData.instore_campaign_items_schema,
    )
    stores = spark_session.createDataFrame(
        [("b1", "c1", "1"), ("b1", "c1", "2")],
        schema=InstoreProcessedData.instore_store_flattened_schema,
    )

    # Act: the helper should create sku x store rows but exclude null-brand items.
    result = build_instore_campaigns(campaign_bookings, campaign_items, stores)

    # Assert: only the valid branded item is retained for each store.
    expected = spark_session.createDataFrame(
        [
            ("c1", 12.0, date(2021, 1, 1), date(2021, 1, 7), False, "700", "DAIRY", "LURPAK | ARLA", "1"),
            ("c1", 12.0, date(2021, 1, 1), date(2021, 1, 7), False, "700", "DAIRY", "LURPAK | ARLA", "2"),
        ],
        schema=InstoreProcessedData.instore_campaigns_schema,
    )

    assert_spark_df_equal(result, expected)


# ----------------------------
# Tests for build_campaign_durations_sku_level
# ----------------------------

def test_build_campaign_durations_sku_level_computes_campaign_days_inclusive(spark_session: SparkSession):
    # Arrange one campaign row spanning three inclusive days.
    df = spark_session.createDataFrame(
        [("c1", date(2021, 1, 1), date(2021, 1, 3), 9.0, "DAIRY", "LURPAK | ARLA", "100")],
        schema="master_campaign_id string, campaign_start_date date, campaign_end_date date, media_cost double, super_category_name string, unique_brand_name string, item_cd string",
    )

    # Act: campaign_days should be derived using inclusive date arithmetic.
    result = build_campaign_durations_sku_level(df)

    # Assert: 1 Jan through 3 Jan counts as three days.
    expected = spark_session.createDataFrame(
        [("c1", date(2021, 1, 1), date(2021, 1, 3), 9.0, "DAIRY", "LURPAK | ARLA", "100", 3)],
        schema=InstoreProcessedData.instore_campaign_durations_schema,
    )

    assert_spark_df_equal(result, expected)


# ----------------------------
# Tests for split_media_cost_across_skus
# ----------------------------

def test_split_media_cost_across_skus_splits_evenly_by_distinct_sku_count(spark_session: SparkSession):
    # Arrange one campaign containing two distinct SKUs.
    df = spark_session.createDataFrame(
        [
            ("c1", date(2021, 1, 1), date(2021, 1, 3), 10.0, "DAIRY", "LURPAK | ARLA", "100", 3),
            ("c1", date(2021, 1, 1), date(2021, 1, 3), 10.0, "DAIRY", "LURPAK | ARLA", "200", 3),
        ],
        schema=InstoreProcessedData.instore_campaign_durations_schema,
    )

    # Act: the helper should compute number_skus and split the media cost evenly.
    result = round_columns(split_media_cost_across_skus(df), ["split_media_cost"], 6)

    # Assert: each SKU receives half the campaign media cost.
    expected = spark_session.createDataFrame(
        [
            ("c1", date(2021, 1, 1), date(2021, 1, 3), 10.0, 5.0, "DAIRY", "LURPAK | ARLA", "100", 2, 3),
            ("c1", date(2021, 1, 1), date(2021, 1, 3), 10.0, 5.0, "DAIRY", "LURPAK | ARLA", "200", 2, 3),
        ],
        schema=InstoreProcessedData.instore_split_costs_schema,
    )

    assert_spark_df_equal(result, expected)


# ----------------------------
# Tests for compute_daily_media_costs
# ----------------------------

def test_compute_daily_media_costs_explodes_dates_adds_cluster(spark_session: SparkSession):
    # Arrange one split campaign row and a matching sku cluster mapping row.
    instore_split = spark_session.createDataFrame(
        [("c1", date(2021, 1, 1), date(2021, 1, 3), 9.0, 9.0, "DAIRY", "LURPAK | ARLA", "100", 1, 3)],
        schema=InstoreProcessedData.instore_split_costs_schema,
    )
    sku_cluster_mapping = spark_session.createDataFrame(
        [("100", "LURPAK | ARLA", "DAIRY", "C1")],
        schema="item_cd string, unique_brand_name string, super_category_name string, cluster_num string",
    )

    # Act: the helper should compute daily cost, explode the full campaign window, and filter to the requested range.
    result = round_columns(
        compute_daily_media_costs(instore_split, sku_cluster_mapping, start_date="2021-01-02", end_date="2021-01-03"),
        ["media_cost_per_day"],
        6,
    )

    # Assert: only dates inside the requested window remain and the cluster number is attached.
    expected = spark_session.createDataFrame(
        [
            ("c1", "DAIRY", "LURPAK | ARLA", "100", "C1", 3.0, date(2021, 1, 2)),
            ("c1", "DAIRY", "LURPAK | ARLA", "100", "C1", 3.0, date(2021, 1, 3)),
        ],
        schema=InstoreProcessedData.instore_daily_costs_schema,
    )

    assert_spark_df_equal(result, expected)


def test_compute_daily_media_costs_zero_when_campaign_days_null(spark_session: SparkSession):
    # Arrange a split row with null campaign_days so the helper must fall back to zero.
    instore_split = spark_session.createDataFrame(
        [("c1", date(2021, 1, 1), date(2021, 1, 1), 9.0, 9.0, "DAIRY", "LURPAK | ARLA", "100", 1, None)],
        schema=InstoreProcessedData.instore_split_costs_schema,
    )
    sku_cluster_mapping = spark_session.createDataFrame(
        [("100", "LURPAK | ARLA", "DAIRY", "C1")],
        schema="item_cd string, unique_brand_name string, super_category_name string, cluster_num string",
    )

    # Act: daily costs should still be produced for the date sequence, but with zero cost per day.
    result = compute_daily_media_costs(instore_split, sku_cluster_mapping, start_date="2021-01-01", end_date="2021-01-01")

    # Assert: missing campaign_days does not error and instead yields zero-valued daily costs.
    expected = spark_session.createDataFrame(
        [("c1", "DAIRY", "LURPAK | ARLA", "100", "C1", 0.0, date(2021, 1, 1))],
        schema=InstoreProcessedData.instore_daily_costs_schema,
    )

    assert_spark_df_equal(result, expected)


# ----------------------------
# Tests for aggregate_daily_costs_to_weekly
# ----------------------------

def test_aggregate_daily_costs_to_weekly_sums_across_campaigns_in_the_same_week(spark_session: SparkSession):
    # Arrange daily costs from two campaigns in the same calendar week.
    df = spark_session.createDataFrame(
        [
            ("c1", "DAIRY", "LURPAK | ARLA", "100", "CL1", 1.0, date(2021, 1, 4)),
            ("c1", "DAIRY", "LURPAK | ARLA", "100", "CL1", 2.0, date(2021, 1, 5)),
            ("c2", "DAIRY", "LURPAK | ARLA", "100", "CL1", 3.0, date(2021, 1, 6)),
        ],
        schema=InstoreProcessedData.instore_daily_costs_schema,
    )

    # Act: the helper should first aggregate within campaign/week and then across campaigns.
    result = aggregate_daily_costs_to_weekly(df)

    # Assert: all three daily rows roll up to a single weekly total of 6.0.
    expected = spark_session.createDataFrame(
        [(datetime(2021, 1, 4, 0, 0, 0), "DAIRY", "LURPAK | ARLA", "CL1", 6.0)],
        schema=InstoreProcessedData.instore_weekly_media_schema,
    )

    assert_spark_df_equal(result, expected)


# ----------------------------
# Tests for build_weekly_exposed_customers
# ----------------------------

def test_build_weekly_exposed_customers_ignores_invalid_date_ranges(spark_session: SparkSession):
    # Arrange location-level campaign rows where one campaign is marked invalid and should be excluded.
    instore_campaigns_enriched = spark_session.createDataFrame(
        [
            ("c1", date(2021, 1, 4), date(2021, 1, 5), False, "100", "DAIRY", "LURPAK | ARLA", "CL1"),
            ("c1", date(2021, 1, 4), date(2021, 1, 5), False, "200", "DAIRY", "LURPAK | ARLA", "CL1"),
            ("c2", date(2021, 1, 10), date(2021, 1, 9), True, "100", "DAIRY", "LURPAK | ARLA", "CL1"),  # Invalid date range; excluded before exposed-customer aggregation
        ],
        schema=InstoreProcessedData.instore_campaigns_location_schema,
    )
    cust_by_location = spark_session.createDataFrame(
        [
            (datetime(2021, 1, 4, 0, 0, 0), "100", 10),
            (datetime(2021, 1, 4, 0, 0, 0), "200", 20),
        ],
        schema=InstoreProcessedData.instore_cust_by_location_schema,
    )

    # Act: valid campaign dates should expand to daily rows, bucket to week, and join to customer counts.
    result = build_weekly_exposed_customers(
        instore_campaigns_enriched,
        cust_by_location,
        start_date="2021-01-01",
        end_date="2021-01-31",
    )

    # Assert: the invalid date range campaign is ignored and customer counts sum to 30.
    expected = spark_session.createDataFrame(
        [("DAIRY", "LURPAK | ARLA", "CL1", datetime(2021, 1, 4, 0, 0, 0), 30)],
        schema=InstoreProcessedData.instore_weekly_exposed_schema,
    )

    assert_spark_df_equal(result, expected)


def test_build_weekly_exposed_customers_empty_inputs_return_empty(spark_session):
    instore_campaigns_enriched = spark_session.createDataFrame([], schema=InstoreProcessedData.INSTORES_CAMPAIGNS_LOCATION_SCHEMA)
    cust_by_location = spark_session.createDataFrame([], schema=InstoreProcessedData.CUST_BY_LOCATION_SCHEMA)

    result = build_weekly_exposed_customers(instore_campaigns_enriched, cust_by_location, "2021-01-01", "2021-01-31")
    assert result.count() == 0


# ----------------------------
# Tests for build_weekly_brand_metrics
# ----------------------------

def test_build_weekly_brand_metrics_joins_to_exposed_cust_data(spark_session):
    weekly_media = spark_session.createDataFrame(
        [(datetime(2021, 1, 4, 0, 0, 0), "DAIRY", "LURPAK | ARLA", "CL1", 12.0)],
        schema=InstoreProcessedData.instore_weekly_media_schema,
    )

    weekly_exposed = spark_session.createDataFrame(
        [("DAIRY", "LURPAK | ARLA", "CL1", datetime(2021, 1, 4, 0, 0, 0), 30)],
        schema=InstoreProcessedData.instore_weekly_exposed_schema,
    )

    result = build_weekly_brand_metrics(weekly_media, weekly_exposed)

    expected = spark_session.createDataFrame(
        [(datetime(2021, 1, 4, 0, 0, 0), "DAIRY", "LURPAK | ARLA", "CL1", 12.0, 30)],
        schema=InstoreProcessedData.instore_weekly_brand_metrics_schema,
    )

    assert_spark_df_equal(result, expected)


def test_build_weekly_brand_metrics_coalesces_missing_exposed_customers_to_zero(spark_session: SparkSession):
    # Arrange a weekly media row with no matching exposed-customer row.
    weekly_media = spark_session.createDataFrame(
        [(datetime(2021, 1, 4, 0, 0, 0), "DAIRY", "LURPAK | ARLA", "CL1", 12.0)],
        schema=InstoreProcessedData.instore_weekly_media_schema,
    )
    weekly_exposed = spark_session.createDataFrame([], schema=InstoreProcessedData.instore_weekly_exposed_schema)

    # Act: the left join should preserve media rows and default missing exposed_customers to zero.
    result = build_weekly_brand_metrics(weekly_media, weekly_exposed)

    # Assert: the row survives with exposed_customers set to 0.
    expected = spark_session.createDataFrame(
        [(datetime(2021, 1, 4, 0, 0, 0), "DAIRY", "LURPAK | ARLA", "CL1", 12.0, 0)],
        schema=InstoreProcessedData.instore_weekly_brand_metrics_schema,
    )

    assert_spark_df_equal(result, expected)


# ----------------------------
# Tests for format_metrics_to_hierarchy
# ----------------------------

def test_format_metrics_to_hierarchy_adds_constants_and_casts_metrics(spark_session: SparkSession):
    # Arrange one weekly metric row before marketing hierarchy columns are added.
    df = spark_session.createDataFrame(
        [(datetime(2021, 1, 4, 0, 0, 0), "DAIRY", "LURPAK | ARLA", "CL1", 12.0, 30)],
        schema=InstoreProcessedData.instore_weekly_brand_metrics_schema,
    )

    # Act: the helper should add marketing hierarchy constants and cast the numeric metrics to decimals.
    result = format_metrics_to_hierarchy(df)

    # Assert: the hierarchy columns match the config constants and decimals are rounded to scale 0.
    expected = spark_session.createDataFrame(
        [
            (
                datetime(2021, 1, 4, 0, 0, 0),
                "DAIRY",
                "LURPAK | ARLA",
                InstoreConfig.MARKETING_TYPE,
                InstoreConfig.MARKETING_CHANNEL,
                InstoreConfig.MARKETING_SUB_CHANNEL,
                "CL1",
                Decimal("12"),
                Decimal("30"),
            )
        ],
        schema=InstoreProcessedData.instore_hierarchy_schema,
    )

    assert_spark_df_equal(result, expected)


# ----------------------------
# Tests for unpivot_metrics_long_format
# ----------------------------

def test_unpivot_metrics_long_format_creates_metric_rows_and_filters_null_clusters(spark_session: SparkSession):
    # Arrange one valid hierarchy row and one row with null cluster_num that should be filtered out.
    df = spark_session.createDataFrame(
        [
            (
                datetime(2021, 1, 4, 0, 0, 0),
                "DAIRY",
                "LURPAK | ARLA",
                InstoreConfig.MARKETING_TYPE,
                InstoreConfig.MARKETING_CHANNEL,
                InstoreConfig.MARKETING_SUB_CHANNEL,
                "CL1",
                Decimal("12"),
                Decimal("30"),
            ),
            (
                datetime(2021, 1, 4, 0, 0, 0),
                "DAIRY",
                "LURPAK | ARLA",
                InstoreConfig.MARKETING_TYPE,
                InstoreConfig.MARKETING_CHANNEL,
                InstoreConfig.MARKETING_SUB_CHANNEL,
                None,
                Decimal("1"),
                Decimal("1"),
            ),  # Invalid cluster; filtered out before long-format output is emitted
        ],
        schema=InstoreProcessedData.instore_hierarchy_schema,
    )

    # Act: the helper should unpivot both metrics for valid clusters only.
    result = unpivot_metrics_long_format(df, correlation_id="run123")

    # Assert: the valid row produces two metrics and the null-cluster row is excluded.
    expected = spark_session.createDataFrame(
        [
            (datetime(2021, 1, 4, 0, 0, 0), "DAIRY", "LURPAK | ARLA", "CL1", InstoreConfig.MARKETING_TYPE, InstoreConfig.MARKETING_CHANNEL, InstoreConfig.MARKETING_SUB_CHANNEL, "total_media_cost", Decimal("12"), "run123"),
            (datetime(2021, 1, 4, 0, 0, 0), "DAIRY", "LURPAK | ARLA", "CL1", InstoreConfig.MARKETING_TYPE, InstoreConfig.MARKETING_CHANNEL, InstoreConfig.MARKETING_SUB_CHANNEL, "exposed_customers", Decimal("30"), "run123"),
        ],
        schema=InstoreProcessedData.instore_unpivot_schema,
    )

    assert_spark_df_equal(result, expected)


# ----------------------------
# Tests for merge_pollen_and_dtp_data
# ----------------------------

def test_merge_pollen_and_dtp_data_pollen_takes_precedence_and_unmatched_dtp_is_kept(spark_session: SparkSession):
    # Arrange overlapping pollen and DTP rows plus one DTP-only metric.
    pollen = spark_session.createDataFrame(
        [(date(2021, 1, 4), "dairy", "lurpak | arla", "cl1", "type", "chan", "sub", "total_media_cost", 10.0)],
        schema=InstoreProcessedData.instore_merge_input_schema,
    )
    dtp = spark_session.createDataFrame(
        [
            (date(2021, 1, 4), "DAIRY", "LURPAK | ARLA", "CL1", "TYPE", "CHAN", "SUB", "TOTAL_MEDIA_COST", 999.0),
            (date(2021, 1, 4), "DAIRY", "LURPAK | ARLA", "CL1", "TYPE", "CHAN", "SUB", "EXPOSED_CUSTOMERS", 30.0),
        ],
        schema=InstoreProcessedData.instore_merge_input_schema,
    )

    # Act: pollen should win on overlapping keys after both inputs are normalized to uppercase.
    # brand/category comparisons are now case-sensitive, so mixed-case rows are retained separately.
    result = merge_pollen_and_dtp_data(pollen, dtp)

    # Assert: the overlapping DTP total_media_cost row is removed, the DTP-only row is preserved, and runtime columns are populated.
    expected = spark_session.createDataFrame(
        [
            (date(2021, 1, 4), "dairy", "lurpak | arla", "CL1", "TYPE", "CHAN", "SUB", "TOTAL_MEDIA_COST", Decimal("10.00000"), "NA", None),
            (date(2021, 1, 4), "DAIRY", "LURPAK | ARLA", "CL1", "TYPE", "CHAN", "SUB", "TOTAL_MEDIA_COST", Decimal("999.00000"), "NA", None),
            (date(2021, 1, 4), "DAIRY", "LURPAK | ARLA", "CL1", "TYPE", "CHAN", "SUB", "EXPOSED_CUSTOMERS", Decimal("30.00000"), "NA", None),
        ],
        schema=InstoreProcessedData.instore_merge_output_schema,
    )

    assert_spark_df_equal(drop_load_ts(result), drop_load_ts(expected))
    assert_non_null_columns(result, ["load_ts"])


def test_merge_pollen_and_dtp_data_empty_pollen_preserves_brand_and_category_case(spark_session: SparkSession):
    # Arrange no pollen rows and one lowercase DTP row.
    pollen = spark_session.createDataFrame([], schema=InstoreProcessedData.instore_merge_input_schema)
    dtp = spark_session.createDataFrame(
        [(date(2021, 1, 4), "dairy", "lurpak | arla", "1", "type", "chan", "sub", "total_media_cost", 10.0)],
        schema=InstoreProcessedData.instore_merge_input_schema,
    )

    # Act: when pollen is empty, all DTP rows should flow through after normalization.
    result = merge_pollen_and_dtp_data(pollen, dtp)

    # Assert: brand/category case is preserved while the other merge dimensions are normalized.
    expected = spark_session.createDataFrame(
        [(date(2021, 1, 4), "dairy", "lurpak | arla", "1", "TYPE", "CHAN", "SUB", "TOTAL_MEDIA_COST", Decimal("10.00000"), "NA", None)],
        schema=InstoreProcessedData.instore_merge_output_schema,
    )

    assert_spark_df_equal(drop_load_ts(result), drop_load_ts(expected))
    assert_non_null_columns(result, ["load_ts"])
