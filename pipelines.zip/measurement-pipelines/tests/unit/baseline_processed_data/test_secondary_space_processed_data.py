from datetime import date, datetime
from unittest import mock

import pytest
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from spark_pipeline.baseline_processed_data.secondary_space_processed_data import (
    _build_baseline_specific_attributes_df,
    _build_secondary_space_metric_grid,
    _calculate_ranged_items_metrics,
    _filter_planogram_campaign_data,
    _format_secondary_space_output,
    _get_weekly_date_bounds,
    prepare_during_data,
    prepare_secondary_space_data,
    reconcile_during_data,
)
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.secondary_space import SecondarySpace
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    local_spark_s3_overwrite,
    write_pipeline_inputs_to_parquet,
)

# Please note in the data store_cd and section_id are both codes but for readability I have added them as store-X and section-X likewise with item_cd I have done the same throughout


def _read_secondary_space_output_without_runtime_columns(spark_session: SparkSession, output_path: str):
    # Compare only stable fields and ignore runtime-generated timestamps.
    return spark_session.read.parquet(output_path).select(
        *ProcessedData.secondary_space_output_no_load_ts_schema.fieldNames()
    )


def _build_secondary_space_output_with_runtime_columns(
    spark_session: SparkSession,
    rows,
    load_ts: str = "2024-01-20 10:00:00",
):
    # Build a DataFrame that matches the runtime output contract used by reconciliation logic.
    return (
        spark_session.createDataFrame(
            rows,
            schema=ProcessedData.secondary_space_output_no_load_ts_schema,
        )
        .withColumn("load_ts", F.to_timestamp(F.lit(load_ts)))
        .select(
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "job_run_id",
            "load_ts",
            "run_date",
        )
    )


def test_get_weekly_date_bounds_filters_requested_weeks_and_returns_min_max(
    spark_session: SparkSession,
):
    # Arrange a wider weekly calendar than the requested modelling period.
    weekly_dates_df = spark_session.createDataFrame(
        [(date(2023, 12, 25),), (date(2024, 1, 1),), (date(2024, 1, 8),), (date(2024, 1, 15),)],
        schema=ProcessedData.weekly_dates_schema,
    )

    # Act: only weeks inside the requested inclusive bounds should remain.
    actual_df, min_week_start_dt, max_week_start_dt = _get_weekly_date_bounds(
        weekly_dates_df,
        "2024-01-01",
        "2024-01-14",
    )

    # Assert: the returned DataFrame is filtered and the min/max bounds match the remaining weeks.
    expected_df = spark_session.createDataFrame(
        [(date(2024, 1, 1),), (date(2024, 1, 8),)],
        schema=ProcessedData.weekly_dates_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)
    assert min_week_start_dt == date(2024, 1, 1)
    assert max_week_start_dt == date(2024, 1, 8)


def test_weekly_date_bounds_empty_when_no_weeks_match(
    spark_session: SparkSession,
):
    # Arrange a weekly calendar that does not overlap the requested date range.
    weekly_dates_df = spark_session.createDataFrame(
        [(date(2024, 1, 1),), (date(2024, 1, 8),)],
        schema=ProcessedData.weekly_dates_schema,
    )

    # Act: a non-overlapping range should produce an empty frame and no derived bounds.
    actual_df, min_week_start_dt, max_week_start_dt = _get_weekly_date_bounds(
        weekly_dates_df,
        "2024-02-01",
        "2024-02-07",
    )

    # Assert: downstream code can detect that there is no modelling period to process.
    expected_df = spark_session.createDataFrame([], schema=ProcessedData.weekly_dates_schema)
    assert_spark_df_equal(actual_df, expected_df)
    assert min_week_start_dt is None
    assert max_week_start_dt is None


def test_filter_planogram_campaign_data_filters_to_brand_skus_and_week_bounds(
    spark_session: SparkSession,
):
    # Arrange planogram rows covering valid, out-of-range and unmapped SKU cases.
    planogram_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 2), date(2024, 1, 1), "store-1", "section-1", "item-1"),
            (date(2024, 1, 9), date(2024, 1, 8), "store-1", "section-1", "item-1"),
            (date(2024, 1, 2), date(2024, 1, 1), "store-1", "section-1", "item-9"),
        ],
        schema=SecondarySpace.secondary_space_planogram_schema,
    )
    sku_cluster_mapping_df = spark_session.createDataFrame(
        [("item-1", "CatA", "SubA", "BrandA", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: only mapped brand SKUs within the requested week range should remain.
    actual_df = _filter_planogram_campaign_data(
        planogram_df,
        sku_cluster_mapping_df,
        date(2024, 1, 1),
        date(2024, 1, 1),
    )

    # Assert: the out-of-range week and unmapped SKU are excluded.
    expected_df = spark_session.createDataFrame(
        [(date(2024, 1, 2), date(2024, 1, 1), "store-1", "section-1", "item-1", "CatA", "BrandA", "CL1")],
        schema=SecondarySpace.secondary_space_filtered_planogram_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_ranged_items_metrics_deduplicate_and_respect_section_dates(
    spark_session: SparkSession,
):
    # Arrange filtered planogram data including duplicates and a row that falls outside section validity.
    planogram_campaign_data_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 2), date(2024, 1, 1), "store-1", "section-promo", "item-1", "CatA", "BrandA", "CL1"),
            (date(2024, 1, 2), date(2024, 1, 1), "store-1", "section-promo", "item-1", "CatA", "BrandA", "CL1"),  # Duplicate of the row above
            (date(2024, 1, 3), date(2024, 1, 1), "store-1", "section-promo", "item-2", "CatA", "BrandA", "CL1"),  # Second promo item in the same store/week; contributes another valid PROMO observation
            (date(2024, 1, 4), date(2024, 1, 1), "store-2", "section-core", "item-1", "CatA", "BrandA", "CL1"),  # Valid CORE placement in a different store; drives the CORE metric for the week
            (date(2024, 1, 5), date(2024, 1, 1), "store-2", "section-expired", "item-2", "CatA", "BrandA", "CL1"),  # Section expired before this date, so this row should be filtered out by section validity dates
        ],
        schema=SecondarySpace.secondary_space_filtered_planogram_schema,
    )
    dim_section_df = spark_session.createDataFrame(
        [
            ("section-promo", "PROMO", datetime(2023, 12, 1, 0, 0, 0), None),  # Open-ended valid promo section; all matching promo rows remain in scope
            ("section-core", "CORE", datetime(2023, 12, 1, 0, 0, 0), None),  # Open-ended valid core section; matching core rows remain in scope
            ("section-expired", "PROMO", datetime(2023, 12, 1, 0, 0, 0), datetime(2024, 1, 4, 0, 0, 0)),  # Valid only up to 2024-01-04, so the 2024-01-05 planogram row is excluded
        ],
        schema=SecondarySpace.secondary_space_dim_section_schema,
    )

    # Act: duplicate item/store/day rows should be deduplicated and expired section rows should be ignored.
    actual_df = _calculate_ranged_items_metrics(planogram_campaign_data_df, dim_section_df)

    # Assert: store denominator is based on two stores and two cluster items, so promo = 2/28 and core = 1/28.
    expected_df = spark_session.createDataFrame(
        [
            ("CatA", "BrandA", "CL1", date(2024, 1, 1), "CORE", 1 / 28),
            ("CatA", "BrandA", "CL1", date(2024, 1, 1), "PROMO", 2 / 28),
        ],
        schema=SecondarySpace.secondary_space_ranged_items_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_baseline_specific_attributes_df_returns_core_and_promo_metric_rows(
    spark_session: SparkSession,
):
    # Arrange the static configuration used for secondary-space output rows.
    config = BaselineProcessedData.secondary_space_config

    # Act: the helper should materialise one row for promo and one for core metrics.
    actual_df = _build_baseline_specific_attributes_df(spark_session, config)

    # Assert: both marketing channel / metric combinations are present.
    expected_df = spark_session.createDataFrame(
        [
            ("PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE"),
            ("PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE"),
        ],
        schema=SecondarySpace.secondary_space_baseline_specific_attributes_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_secondary_space_metric_grid_cross_joins_weeks_clusters(
    spark_session: SparkSession,
):
    # Arrange two weeks, one cluster and the two static metric definitions.
    weekly_dates_range_df = spark_session.createDataFrame(
        [(date(2024, 1, 1),), (date(2024, 1, 8),)],
        schema=ProcessedData.weekly_dates_schema,
    )
    sku_cluster_mapping_df = spark_session.createDataFrame(
        [
            ("item-1", "CatA", "SubA", "BrandA", "CL1"),
            ("item-2", "CatA", "SubA", "BrandA", "CL1"),
        ],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )
    baseline_specific_attributes_df = spark_session.createDataFrame(
        [
            ("PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE"),
            ("PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE"),
        ],
        schema=SecondarySpace.secondary_space_baseline_specific_attributes_schema,
    )

    # Act: the metric grid should cover every week/cluster/metric combination.
    actual_df = _build_secondary_space_metric_grid(
        weekly_dates_range_df,
        sku_cluster_mapping_df,
        baseline_specific_attributes_df,
    )

    # Assert: one cluster across two weeks and two metric rows yields four rows.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE"),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE"),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE"),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE"),
        ],
        schema=SecondarySpace.secondary_space_metric_grid_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_format_secondary_space_output_zero_fills_missing_metric_values(
    spark_session: SparkSession,
):
    # Arrange a metric grid with one observed metric and one missing metric.
    secondary_space_metric_grid_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE"),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE"),
        ],
        schema=SecondarySpace.secondary_space_metric_grid_schema,
    )
    ranged_items_df = spark_session.createDataFrame(
        [("CatA", "BrandA", "CL1", date(2024, 1, 1), "PROMO", 2 / 28)],
        schema=SecondarySpace.secondary_space_ranged_items_schema,
    )

    # Act: missing metric values should be filled with zero in the final shaped output.
    actual_df = _format_secondary_space_output(
        secondary_space_metric_grid_df,
        ranged_items_df,
        "2024-01-10",
        "corr-format",
    )

    # Assert: observed promo values are preserved while missing core values become zero.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE", 0.0, "corr-format", "2024-01-10"),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 2 / 28, "corr-format", "2024-01-10"),
        ],
        schema=ProcessedData.secondary_space_output_no_load_ts_schema,
    )

    assert_spark_df_equal(
        actual_df.select(*ProcessedData.secondary_space_output_no_load_ts_schema.fieldNames()),
        expected_df,
    )
    assert_non_null_columns(actual_df, ["load_ts"])


def test_prepare_during_data_filters_correctly(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange a mixed baseline modelling dataset with both matching and non-matching rows.
    during_baseline_modelling_path = str(tmp_path / "during_baseline_modelling")
    spark_session.createDataFrame(
        [
            ("2024-01-01", "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.25, "var-a", datetime(2024, 1, 20, 9, 0, 0), "during-123"),
            ("2024-01-08", "CatA", "BrandA", "CL1", "PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE", 0.40, "var-b", datetime(2024, 1, 20, 9, 0, 0), "during-123"),
            ("2024-01-08", "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "NOT_TOTAL", "RANGED_SECONDARY_SPACE", 0.99, "var-c", datetime(2024, 1, 20, 9, 0, 0), "during-123"),
            ("2024-01-08", "CatA", "BrandA", "CL1", "OFFSITE", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.88, "var-d", datetime(2024, 1, 20, 9, 0, 0), "during-123"),
            ("2024-01-08", "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.77, "var-e", datetime(2024, 1, 20, 9, 0, 0), "during-999"),
        ],
        [
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "variable_cd",
            "load_ts",
            "job_run_id",
        ],
    ).write.mode("overwrite").parquet(during_baseline_modelling_path)

    # Act: only the requested During run and secondary-space rows should remain.
    actual_df = prepare_during_data(
        spark=spark_session,
        during_correlation_id="during-123",
        during_baseline_modelling_path=during_baseline_modelling_path,
        config=BaselineProcessedData.secondary_space_config,
    )

    # Assert: filtering is applied and only the projected reconciliation columns remain.
    expected_df = spark_session.createDataFrame(
        [
            ("2024-01-01", "CL1", "RANGED_SECONDARY_SPACE", 0.25),
            ("2024-01-08", "CL1", "RANGED_CORE_SPACE", 0.40),
        ],
        ["week_start_dt", "cluster_num", "metric_name", "metric_value"],
    )

    assert actual_df.columns == ["week_start_dt", "cluster_num", "metric_name", "metric_value"]
    assert_spark_df_equal(actual_df, expected_df)


def test_prepare_during_data_returns_empty_df(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange a baseline modelling dataset that does not match the requested During filters.
    during_baseline_modelling_path = str(tmp_path / "during_baseline_modelling_empty")
    spark_session.createDataFrame(
        [
            ("2024-01-01", "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "NOT_TOTAL", "RANGED_SECONDARY_SPACE", 0.25, "var-a", datetime(2024, 1, 20, 9, 0, 0), "during-123"),
            ("2024-01-08", "CatA", "BrandA", "CL1", "OFFSITE", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.40, "var-b", datetime(2024, 1, 20, 9, 0, 0), "during-123"),
            ("2024-01-15", "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.55, "var-c", datetime(2024, 1, 20, 9, 0, 0), "during-999"),
        ],
        [
            "week_start_dt",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "marketing_type_name",
            "marketing_channel_name",
            "marketing_sub_channel_name",
            "metric_name",
            "metric_value",
            "variable_cd",
            "load_ts",
            "job_run_id",
        ],
    ).write.mode("overwrite").parquet(during_baseline_modelling_path)

    # Act: no rows should survive when correlation id / marketing filters do not match.
    actual_df = prepare_during_data(
        spark=spark_session,
        during_correlation_id="during-123",
        during_baseline_modelling_path=during_baseline_modelling_path,
        config=BaselineProcessedData.secondary_space_config,
    )

    # Assert: the projected schema is preserved even when the result is empty.
    expected_df = spark_session.createDataFrame([], schema=actual_df.schema)
    assert actual_df.columns == ["week_start_dt", "cluster_num", "metric_name", "metric_value"]
    assert_spark_df_equal(actual_df, expected_df)


def test_reconcile_during_data_replaces_overlapping_metrics_and_keeps_final_only_rows(
    spark_session: SparkSession,
):
    # Arrange a current-run output with one overlapping week and one final-only week.
    final_df = _build_secondary_space_output_with_runtime_columns(
        spark_session,
        [
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.50, "corr-post", "2024-01-20"),
            (date(2024, 1, 15), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.70, "corr-post", "2024-01-20"),
        ],
    )
    during_secondary_space_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 8), "CL1", "RANGED_SECONDARY_SPACE", 0.90),
            (date(2024, 1, 22), "CL1", "RANGED_SECONDARY_SPACE", 0.95),
        ],
        ["week_start_dt", "cluster_num", "metric_name", "metric_value"],
    )

    # Act: overlapping metric values should be replaced from During while final-only rows remain untouched.
    actual_df = reconcile_during_data(final_df, during_secondary_space_df)

    # Assert: overlap uses the During value and the non-overlapping final week is retained.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.90, "corr-post", "2024-01-20"),
            (date(2024, 1, 15), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.70, "corr-post", "2024-01-20"),
        ],
        schema=ProcessedData.secondary_space_output_no_load_ts_schema,
    )

    assert_spark_df_equal(
        actual_df.select(*ProcessedData.secondary_space_output_no_load_ts_schema.fieldNames()),
        expected_df,
    )
    assert_non_null_columns(actual_df, ["load_ts"])


def test_reconcile_during_data_does_not_append_during_only_weeks(
    spark_session: SparkSession,
):
    # Arrange a current-run output with one overlapping week and one During-only historical week.
    final_df = _build_secondary_space_output_with_runtime_columns(
        spark_session,
        [
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.50, "corr-post", "2024-01-20"),
        ],
    )
    during_secondary_space_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CL1", "RANGED_SECONDARY_SPACE", 0.25),
            (date(2024, 1, 8), "CL1", "RANGED_SECONDARY_SPACE", 0.99),
        ],
        ["week_start_dt", "cluster_num", "metric_name", "metric_value"],
    )

    # Act: reconciliation should only operate on rows already present in the current-run output.
    actual_df = reconcile_during_data(final_df, during_secondary_space_df)

    # Assert: the overlapping week is replaced and the During-only historical week is not appended.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.99, "corr-post", "2024-01-20"),
        ],
        schema=ProcessedData.secondary_space_output_no_load_ts_schema,
    )

    assert_spark_df_equal(
        actual_df.select(*ProcessedData.secondary_space_output_no_load_ts_schema.fieldNames()),
        expected_df,
    )
    assert actual_df.filter(F.col("week_start_dt") == F.lit(date(2024, 1, 1))).count() == 0


def test_reconcile_during_data_returns_final_df_when_no_during_rows_match(
    spark_session: SparkSession,
):
    # Arrange a current-run output whose rows do not match the During join keys.
    final_df = _build_secondary_space_output_with_runtime_columns(
        spark_session,
        [
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.50, "corr-post", "2024-01-20"),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE", 1 / 28, "corr-post", "2024-01-20"),
        ],
    )
    during_secondary_space_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 8), "CL9", "RANGED_SECONDARY_SPACE", 0.99),
            (date(2024, 1, 15), "CL1", "RANGED_SECONDARY_SPACE", 0.75),
        ],
        ["week_start_dt", "cluster_num", "metric_name", "metric_value"],
    )

    # Act: no overlap on the full join key should leave the final output unchanged.
    actual_df = reconcile_during_data(final_df, during_secondary_space_df)

    # Assert: the original final output is preserved as-is.
    assert_spark_df_equal(
        actual_df.select(*final_df.columns),
        final_df,
    )
    assert_non_null_columns(actual_df, ["load_ts"])


def test_prepare_secondary_space_data_requires_during_path_when_during_id_is_provided(
    spark_session: SparkSession,
):
    # Arrange: Post-period reconciliation has been requested without the required During dataset path.

    # Act / Assert: argument validation should fail before any data is loaded.
    with pytest.raises(
        ValueError,
        match="during_baseline_modelling_path is required when during_correlation_id is provided.",
    ):
        prepare_secondary_space_data(
            spark=spark_session,
            weekly_dates_path="ignored",
            sku_cluster_mapping_path="ignored",
            plngrm_campaign_item_postn_daily_path="ignored",
            dim_section_path="ignored",
            output_path="ignored",
            run_date="2024-01-20",
            start_date="2024-01-08",
            end_date="2024-01-14",
            correlation_id="corr-post",
            during_correlation_id="during-123",
        )


def test_prepare_secondary_space_data_writes_expected_cluster_level_output(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange parquet inputs covering promo/core planogram rows and an unmapped SKU that should be ignored.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    planogram_path = str(tmp_path / "planogram")
    dim_section_path = str(tmp_path / "dim_section")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            sku_cluster_mapping_path,
            planogram_path,
            dim_section_path,
        ],
        rows_list=[
            [
                (date(2024, 1, 1),),
                (date(2024, 1, 8),),
            ],
            [
                ("item-1", "CatA", "SubA", "BrandA", "CL1"),
                ("item-2", "CatA", "SubA", "BrandA", "CL1"),
            ],
            [
                (date(2024, 1, 2), date(2024, 1, 1), "store-1", "section-promo", "item-1"),  # Valid mapped promo row
                (date(2024, 1, 3), date(2024, 1, 1), "store-1", "section-promo", "item-2"),  # Second valid mapped promo row
                (date(2024, 1, 4), date(2024, 1, 1), "store-2", "section-core", "item-1"),  # Valid mapped core row in a second store
                (date(2024, 1, 4), date(2024, 1, 1), "store-2", "section-core", "item-9"),  # Unmapped SKU; dropped before metric calculation by the sku-cluster join
            ],
            [
                ("section-promo", "PROMO", datetime(2023, 12, 1, 0, 0, 0), None),
                ("section-core", "CORE", datetime(2023, 12, 1, 0, 0, 0), None),
            ],
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            ProcessedData.sku_cluster_mapping_schema,
            SecondarySpace.secondary_space_planogram_schema,
            SecondarySpace.secondary_space_dim_section_schema,
        ],
    )

    # patch the writer so the test still exercises a real local parquet write.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.secondary_space_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_secondary_space_data(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            plngrm_campaign_item_postn_daily_path=planogram_path,
            dim_section_path=dim_section_path,
            output_path=output_path,
            run_date="2024-01-10",
            start_date="2024-01-01",
            end_date="2024-01-14",
            correlation_id="corr-123",
        )

    # Assert: observed week metrics are populated and the missing modelling week is zero-filled.
    actual_df = _read_secondary_space_output_without_runtime_columns(spark_session, output_path)
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE", 1 / 28, "corr-123", "2024-01-10"),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 2 / 28, "corr-123", "2024-01-10"),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE", 0.0, "corr-123", "2024-01-10"),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.0, "corr-123", "2024-01-10"),
        ],
        schema=ProcessedData.secondary_space_output_no_load_ts_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)
    assert_non_null_columns(spark_session.read.parquet(output_path), ["load_ts"])


def test_prepare_secondary_space_data_replaces_overlapping_metrics_with_during_values(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange current-run inputs for one week and a mocked During dataset with both overlap and historical-only rows.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    planogram_path = str(tmp_path / "planogram")
    dim_section_path = str(tmp_path / "dim_section")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            sku_cluster_mapping_path,
            planogram_path,
            dim_section_path,
        ],
        rows_list=[
            [
                (date(2024, 1, 8),),
            ],
            [
                ("item-1", "CatA", "SubA", "BrandA", "CL1"),
                ("item-2", "CatA", "SubA", "BrandA", "CL1"),
            ],
            [
                (date(2024, 1, 9), date(2024, 1, 8), "store-1", "section-promo", "item-1"),
                (date(2024, 1, 10), date(2024, 1, 8), "store-1", "section-promo", "item-2"),
                (date(2024, 1, 11), date(2024, 1, 8), "store-2", "section-core", "item-1"),
            ],
            [
                ("section-promo", "PROMO", datetime(2023, 12, 1, 0, 0, 0), None),
                ("section-core", "CORE", datetime(2023, 12, 1, 0, 0, 0), None),
            ],
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            ProcessedData.sku_cluster_mapping_schema,
            SecondarySpace.secondary_space_planogram_schema,
            SecondarySpace.secondary_space_dim_section_schema,
        ],
    )

    mocked_during_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CL1", "RANGED_SECONDARY_SPACE", 0.25),
            (date(2024, 1, 8), "CL1", "RANGED_SECONDARY_SPACE", 0.99),
        ],
        ["week_start_dt", "cluster_num", "metric_name", "metric_value"],
    )

    with mock.patch(
        "spark_pipeline.baseline_processed_data.secondary_space_processed_data.prepare_during_data",
        return_value=mocked_during_df,
    ), mock.patch(
        "spark_pipeline.baseline_processed_data.secondary_space_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_secondary_space_data(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            plngrm_campaign_item_postn_daily_path=planogram_path,
            dim_section_path=dim_section_path,
            output_path=output_path,
            run_date="2024-01-20",
            start_date="2024-01-08",
            end_date="2024-01-14",
            correlation_id="corr-post",
            during_baseline_modelling_path="ignored-by-test",
            during_correlation_id="during-123",
        )

    # Assert: overlapping current-week values are replaced from During, while During-only prior weeks are not appended.
    actual_df = _read_secondary_space_output_without_runtime_columns(spark_session, output_path)
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE", 1 / 28, "corr-post", "2024-01-20"),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.99, "corr-post", "2024-01-20"),
        ],
        schema=ProcessedData.secondary_space_output_no_load_ts_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)
    assert_non_null_columns(spark_session.read.parquet(output_path), ["load_ts"])


def test_secondary_space_zero_output_when_no_planogram_rows_match(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange a valid cluster skeleton but only out-of-range / unmapped planogram rows.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    planogram_path = str(tmp_path / "planogram")
    dim_section_path = str(tmp_path / "dim_section")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            sku_cluster_mapping_path,
            planogram_path,
            dim_section_path,
        ],
        rows_list=[
            [
                (date(2024, 1, 1),),
            ],
            [
                ("item-1", "CatA", "SubA", "BrandA", "CL1"),
            ],
            [
                (date(2024, 1, 15), date(2024, 1, 15), "store-1", "section-promo", "item-1"),  # Mapped SKU, but week_start_dt is outside the requested modelling window
                (date(2024, 1, 2), date(2024, 1, 1), "store-1", "section-promo", "item-9"),  # In-range week, but unmapped SKU so it is removed by the sku-cluster join
            ],
            [
                ("section-promo", "PROMO", datetime(2023, 12, 1, 0, 0, 0), None),
            ],
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            ProcessedData.sku_cluster_mapping_schema,
            SecondarySpace.secondary_space_planogram_schema,
            SecondarySpace.secondary_space_dim_section_schema,
        ],
    )

    # Act: with no matching ranged-item observations, the output should still contain the full metric grid with zeros.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.secondary_space_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_secondary_space_data(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            plngrm_campaign_item_postn_daily_path=planogram_path,
            dim_section_path=dim_section_path,
            output_path=output_path,
            run_date="2024-01-10",
            start_date="2024-01-01",
            end_date="2024-01-07",
            correlation_id="corr-empty",
        )

    # Assert: the cluster/week grid remains intact and every metric is zero-filled.
    actual_df = _read_secondary_space_output_without_runtime_columns(spark_session, output_path)
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "PLANOGRAM", "CORE", "TOTAL", "RANGED_CORE_SPACE", 0.0, "corr-empty", "2024-01-10"),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "PLANOGRAM", "PROMO", "TOTAL", "RANGED_SECONDARY_SPACE", 0.0, "corr-empty", "2024-01-10"),
        ],
        schema=ProcessedData.secondary_space_output_no_load_ts_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)
    assert_non_null_columns(spark_session.read.parquet(output_path), ["load_ts"])
