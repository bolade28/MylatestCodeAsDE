from datetime import date
from decimal import Decimal
from unittest import mock
from unittest.mock import patch

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.youtube_processed_data import (
    entrypoint,
    prepare_youtube_processed_data,
)
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.youtube_processed_data import YouTubeProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    read_parquet_columns,
    write_pipeline_inputs_to_parquet,
    local_spark_s3_overwrite
)


# ----- Helper functions -----
def _read_youtube_processed_output(spark_session: SparkSession, output_path: str):
    return read_parquet_columns(
        spark_session,
        output_path,
        YouTubeProcessedData.youtube_processed_data_output_schema.fieldNames(),
    )


def test_prepare_youtube_processed_data_writes_expected_zero_filled_weekly_output(spark_session: SparkSession, tmp_path):
    # Arrange YouTube DTP inputs with one populated week and one extra skeleton week.
    youtube_normalize_path = str(tmp_path / "youtube_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    media_report_path = str(tmp_path / "media_report")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[youtube_normalize_path, sku_cluster_mapping_path, media_report_path, weekly_dates_path],
        rows_list=[
            [("sku-1", "job-1", date(2024, 1, 1), date(2024, 1, 2))],
            [("sku-1", "Cat A", "Sub A", "Brand A", "CL1")],
            [
                ("job-1", date(2024, 1, 1), Decimal("100.00"), Decimal("10.00"), Decimal("50.00"), Decimal("90.00"), Decimal("80.00")),
                ("job-1", date(2024, 1, 2), Decimal("200.00"), Decimal("20.00"), Decimal("60.00"), Decimal("110.00"), Decimal("100.00")),
            ],
            [(date(2024, 1, 1),), (date(2024, 1, 8),)],
        ],
        schemas=[
            YouTubeProcessedData.youtube_normalize_dtp_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            YouTubeProcessedData.youtube_media_report_dtp_input_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.youtube_processed_data.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: the top-level YouTube DTP pipeline should write the final processed-data output.
        prepare_youtube_processed_data(
            spark=spark_session,
            youtube_normalize_path=youtube_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            media_report_path=media_report_path,
            weekly_dates_path=weekly_dates_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            correlation_id="corr-youtube-dtp",
        )

        # Assert: one observed week and one zero-filled week are written for each YouTube metric.
        actual_output_df = _read_youtube_processed_output(spark_session, output_path)
        actual_df = actual_output_df.select(*ProcessedData.shared_date_output_decimal_38_2_schema.fieldNames())
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "impressions", Decimal("300.00"), "corr-youtube-dtp"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "clicks", Decimal("30.00"), "corr-youtube-dtp"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "measurable_impressions", Decimal("200.00"), "corr-youtube-dtp"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "viewable_impressions", Decimal("180.00"), "corr-youtube-dtp"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "campaign_spend", Decimal("110.00"), "corr-youtube-dtp"),
                (date(2024, 1, 8), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "impressions", Decimal("0.00"), "corr-youtube-dtp"),
                (date(2024, 1, 8), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "clicks", Decimal("0.00"), "corr-youtube-dtp"),
                (date(2024, 1, 8), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "measurable_impressions", Decimal("0.00"), "corr-youtube-dtp"),
                (date(2024, 1, 8), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "viewable_impressions", Decimal("0.00"), "corr-youtube-dtp"),
                (date(2024, 1, 8), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "campaign_spend", Decimal("0.00"), "corr-youtube-dtp"),
            ],
            schema=ProcessedData.shared_date_output_decimal_38_2_schema,
        )

    assert_spark_df_equal(actual_df, expected_df)
    assert_non_null_columns(actual_output_df, ["load_ts", "technical_metadata"])


def test_youtube_splits_metrics_evenly_across_clusters(spark_session: SparkSession, tmp_path):
    # Arrange one YouTube campaign that targets two mapped SKUs in different clusters during a single modelling week.
    youtube_normalize_path = str(tmp_path / "youtube_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    media_report_path = str(tmp_path / "media_report")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[youtube_normalize_path, sku_cluster_mapping_path, media_report_path, weekly_dates_path],
        rows_list=[
            [
                ("sku-1", "job-1", date(2024, 1, 1), date(2024, 1, 2)),
                ("sku-2", "job-1", date(2024, 1, 1), date(2024, 1, 2)),
            ],
            [
                ("sku-1", "Cat A", "Sub A", "Brand A", "CL1"),
                ("sku-2", "Cat A", "Sub A", "Brand A", "CL2"),
            ],
            [
                ("job-1", date(2024, 1, 1), Decimal("100.00"), Decimal("10.00"), Decimal("50.00"), Decimal("90.00"), Decimal("80.00")),
                ("job-1", date(2024, 1, 2), Decimal("200.00"), Decimal("20.00"), Decimal("60.00"), Decimal("110.00"), Decimal("100.00")),
            ],
            [(date(2024, 1, 1),)],
        ],
        schemas=[
            YouTubeProcessedData.youtube_normalize_dtp_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            YouTubeProcessedData.youtube_media_report_dtp_input_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.youtube_processed_data.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: campaign-level metrics should be split evenly across the two SKUs and retained at cluster level.
        prepare_youtube_processed_data(
            spark=spark_session,
            youtube_normalize_path=youtube_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            media_report_path=media_report_path,
            weekly_dates_path=weekly_dates_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            correlation_id="corr-youtube-split",
        )

        # Assert: each cluster receives half of the weekly campaign totals and runtime metadata is populated.
        actual_output_df = _read_youtube_processed_output(spark_session, output_path)
        actual_df = actual_output_df.select(*ProcessedData.shared_date_output_decimal_38_2_schema.fieldNames())
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "impressions", Decimal("150.00"), "corr-youtube-split"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "clicks", Decimal("15.00"), "corr-youtube-split"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "measurable_impressions", Decimal("100.00"), "corr-youtube-split"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "viewable_impressions", Decimal("90.00"), "corr-youtube-split"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL1", "OFFSITE", "YOUTUBE", "TOTAL", "campaign_spend", Decimal("55.00"), "corr-youtube-split"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL2", "OFFSITE", "YOUTUBE", "TOTAL", "impressions", Decimal("150.00"), "corr-youtube-split"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL2", "OFFSITE", "YOUTUBE", "TOTAL", "clicks", Decimal("15.00"), "corr-youtube-split"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL2", "OFFSITE", "YOUTUBE", "TOTAL", "measurable_impressions", Decimal("100.00"), "corr-youtube-split"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL2", "OFFSITE", "YOUTUBE", "TOTAL", "viewable_impressions", Decimal("90.00"), "corr-youtube-split"),
                (date(2024, 1, 1), "Cat A", "Brand A", "CL2", "OFFSITE", "YOUTUBE", "TOTAL", "campaign_spend", Decimal("55.00"), "corr-youtube-split"),
            ],
            schema=ProcessedData.shared_date_output_decimal_38_2_schema,
        )

    assert_spark_df_equal(actual_df, expected_df)
    assert_non_null_columns(actual_output_df, ["load_ts", "technical_metadata"])


def test_youtube_empty_output_when_no_skus_map_clusters(spark_session: SparkSession, tmp_path):
    # Arrange YouTube DTP inputs where the normalized SKU is absent from the cluster mapping.
    youtube_normalize_path = str(tmp_path / "youtube_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    media_report_path = str(tmp_path / "media_report")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[youtube_normalize_path, sku_cluster_mapping_path, media_report_path, weekly_dates_path],
        rows_list=[
            [("sku-x", "job-1", date(2024, 1, 1), date(2024, 1, 2))],
            [("sku-1", "Cat A", "Sub A", "Brand A", "CL1")],
            [("job-1", date(2024, 1, 1), Decimal("100.00"), Decimal("10.00"), Decimal("50.00"), Decimal("90.00"), Decimal("80.00"))],
            [(date(2024, 1, 1),)],
        ],
        schemas=[
            YouTubeProcessedData.youtube_normalize_dtp_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            YouTubeProcessedData.youtube_media_report_dtp_input_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.youtube_processed_data.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: with no mapped brand SKUs, the final YouTube output should be empty.
        prepare_youtube_processed_data(
            spark=spark_session,
            youtube_normalize_path=youtube_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            media_report_path=media_report_path,
            weekly_dates_path=weekly_dates_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            correlation_id="corr-empty",
        )

        # Assert: the output parquet is empty but still projects to the stable final contract columns.
        expected_df = spark_session.createDataFrame([], schema=ProcessedData.shared_date_output_decimal_38_2_schema)
        actual_output_df = _read_youtube_processed_output(spark_session, output_path)
    assert actual_output_df.columns == YouTubeProcessedData.youtube_processed_data_output_schema.fieldNames()
    assert_spark_df_equal(actual_output_df.select(*ProcessedData.shared_date_output_decimal_38_2_schema.fieldNames()), expected_df)


def test_entrypoint_invokes_prepare_youtube_processed_data_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current YouTube DTP entrypoint contract.
    args = [
        "--youtube-normalize-path", "s3://input/youtube-normalize",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--media-report-path", "s3://input/media-report",
        "--weekly-dates-path", "s3://input/weekly-dates",
        "--start-date", "2024-01-01",
        "--end-date", "2024-01-31",
        "--output-path", "s3://output/youtube",
        "--correlation-id", "corr-entrypoint",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.marketing_features.youtube_processed_data.prepare_youtube_processed_data") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        youtube_normalize_path="s3://input/youtube-normalize",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        media_report_path="s3://input/media-report",
        weekly_dates_path="s3://input/weekly-dates",
        start_date="2024-01-01",
        end_date="2024-01-31",
        output_path="s3://output/youtube",
        correlation_id="corr-entrypoint",
    )
