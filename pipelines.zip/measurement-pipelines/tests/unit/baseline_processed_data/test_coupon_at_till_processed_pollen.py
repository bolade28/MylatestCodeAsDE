from datetime import date
from decimal import Decimal
from unittest import mock
from unittest.mock import patch

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed_pollen import (
    entrypoint,
    prepare_coupon_at_till_processed,
)
from spark_pipeline.common.variables import CouponAtTillConfig
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.coupon_at_till_processed import CouponAtTillProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    drop_load_ts,
    write_pipeline_inputs_to_parquet,
    local_spark_s3_overwrite
)

# Expected sku format
ITEM_JSON = '[{"skuId": "sku-1"}]'


def test_coupon_at_till_pollen_merged_output_with_pollen_precedence(spark_session: SparkSession, tmp_path):
    # Arrange a valid pollen booking plus overlapping and DTP-only historic coupon-at-till rows.
    campaign_booking_media_channel_path = str(tmp_path / "campaign_booking_media_channel")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    coupon_path = str(tmp_path / "coupon")
    coupon_cell_path = str(tmp_path / "coupon_cell")
    cell_path = str(tmp_path / "cell")
    campaign_path = str(tmp_path / "campaign")
    historic_cat_processed_data_path = str(tmp_path / "historic_cat_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            campaign_booking_media_channel_path,
            sku_cluster_mapping_path,
            coupon_path,
            coupon_cell_path,
            cell_path,
            campaign_path,
            historic_cat_processed_data_path,
        ],
        rows_list=[
            [("b1", "camp-1", "instore", "completed", "coupon_at_till", "sainsbury", 20.0, date(2024, 1, 1), date(2024, 1, 7), ITEM_JSON)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [("coupon-1", date(2024, 1, 1), date(2024, 1, 7), Decimal("35.00"))],
            [("cell-1", "coupon-1")],
            [("camp-1", "cell-1")],
            [("camp-1", "pre", "post")],
            [
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "TARGETED MEDIA", "COUPON AT TILL", "TOTAL", "BASE_VALUE", 999.0),
                (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "TARGETED MEDIA", "COUPON AT TILL", "TOTAL", "COUPON_VALUE", 12.0),
            ],
        ],
        schemas=[
            CouponAtTillProcessedData.coupon_at_till_campaign_booking_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            CouponAtTillProcessedData.coupon_schema,
            CouponAtTillProcessedData.coupon_cell_schema,
            CouponAtTillProcessedData.cell_schema,
            CouponAtTillProcessedData.campaign_schema,
            ProcessedData.shared_date_merge_input_schema,
        ],
    )

    with patch(
        "spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed_pollen.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        # Act: the pollen script should merge its fresh rows over the historic DTP data and write the combined output.
        prepare_coupon_at_till_processed(
            spark=spark_session,
            campaign_booking_media_channel_path=campaign_booking_media_channel_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            coupon_path=coupon_path,
            coupon_cell_path=coupon_cell_path,
            cell_path=cell_path,
            campaign_path=campaign_path,
            historic_cat_processed_data=historic_cat_processed_data_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            run_date="2024-01-31",
            correlation_id="corr-cat-pollen",
        )

        # Assert: pollen wins on the overlapping base-value row and the unmatched historic coupon row is preserved.
        actual_df = spark_session.read.parquet(output_path)
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "BASE_VALUE", Decimal("20.00000"), "NA", None),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "COUPON_VALUE", Decimal("35.00000"), "NA", None),
                (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "TARGETED MEDIA", "COUPON AT TILL", "TOTAL", "COUPON_VALUE", Decimal("12.00000"), "NA", None),
            ],
            schema=ProcessedData.shared_date_output_with_load_ts_decimal_18_5_schema,
        )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_coupon_at_till_pollen_empty_output_without_bookings_or_history(spark_session: SparkSession, tmp_path):
    # Arrange an out-of-scope booking plus an empty historic dataset.
    campaign_booking_media_channel_path = str(tmp_path / "campaign_booking_media_channel")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    coupon_path = str(tmp_path / "coupon")
    coupon_cell_path = str(tmp_path / "coupon_cell")
    cell_path = str(tmp_path / "cell")
    campaign_path = str(tmp_path / "campaign")
    historic_cat_processed_data_path = str(tmp_path / "historic_cat_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            campaign_booking_media_channel_path,
            sku_cluster_mapping_path,
            coupon_path,
            coupon_cell_path,
            cell_path,
            campaign_path,
            historic_cat_processed_data_path,
        ],
        rows_list=[
            [("b1", "camp-1", "onsite", "completed", "other", "sainsbury", 20.0, date(2024, 1, 1), date(2024, 1, 7), ITEM_JSON)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [("coupon-1", date(2024, 1, 1), date(2024, 1, 7), Decimal("35.00"))],
            [("cell-1", "coupon-1")],
            [("camp-1", "cell-1")],
            [("camp-1", "pre", "post")],
            [],
        ],
        schemas=[
            CouponAtTillProcessedData.coupon_at_till_campaign_booking_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            CouponAtTillProcessedData.coupon_schema,
            CouponAtTillProcessedData.coupon_cell_schema,
            CouponAtTillProcessedData.cell_schema,
            CouponAtTillProcessedData.campaign_schema,
            ProcessedData.shared_date_merge_input_schema,
        ],
    )

    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed_pollen.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        # Act: with no valid pollen rows and no historic rows, the final parquet should be empty.
        prepare_coupon_at_till_processed(
            spark=spark_session,
            campaign_booking_media_channel_path=campaign_booking_media_channel_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            coupon_path=coupon_path,
            coupon_cell_path=coupon_cell_path,
            cell_path=cell_path,
            campaign_path=campaign_path,
            historic_cat_processed_data=historic_cat_processed_data_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            run_date="2024-01-31",
            correlation_id="corr-empty",
        )

    # Assert: the merged output parquet is empty but still conforms to the merge contract.
    expected_df = spark_session.createDataFrame([], schema=ProcessedData.shared_date_output_with_load_ts_decimal_18_5_schema)
    assert_spark_df_equal(spark_session.read.parquet(output_path), expected_df)


def test_coupon_at_till_pollen_aggregates_campaigns_ignores_problem_rows(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange two valid pollen campaigns plus problematic rows that should be filtered or ignored.
    campaign_booking_media_channel_path = str(tmp_path / "campaign_booking_media_channel")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    coupon_path = str(tmp_path / "coupon")
    coupon_cell_path = str(tmp_path / "coupon_cell")
    cell_path = str(tmp_path / "cell")
    campaign_path = str(tmp_path / "campaign")
    historic_cat_processed_data_path = str(tmp_path / "historic_cat_processed_data")
    output_path = str(tmp_path / "output")
    unmapped_item_json = '[{"skuId": "sku-x"}]'

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            campaign_booking_media_channel_path,
            sku_cluster_mapping_path,
            coupon_path,
            coupon_cell_path,
            cell_path,
            campaign_path,
            historic_cat_processed_data_path,
        ],
        rows_list=[
            [
                ("b1", "camp-1", "instore", "completed", "coupon_at_till", "sainsbury", 20.0, date(2024, 1, 1), date(2024, 1, 7), ITEM_JSON),
                ("b2", "camp-2", "instore", "completed", "coupon_at_till", "sainsbury", 30.0, date(2024, 1, 1), date(2024, 1, 7), ITEM_JSON),
                ("b3", "camp-3", "onsite", "completed", "coupon_at_till", "sainsbury", 15.0, date(2024, 1, 1), date(2024, 1, 7), ITEM_JSON),  # Wrong channel_type -> filtered out
                ("b4", "camp-4", "instore", "completed", "coupon_at_till", "sainsbury", 15.0, date(2024, 1, 1), date(2024, 1, 7), unmapped_item_json),  # SKU not in cluster mapping -> dropped by inner join
            ],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [
                ("coupon-1", date(2024, 1, 1), date(2024, 1, 7), Decimal("35.00")),
                ("coupon-2", date(2024, 1, 1), date(2024, 1, 7), Decimal("15.00")),
                ("coupon-3", date(2024, 1, 1), date(2024, 1, 7), Decimal("99.00")),
            ],
            [
                ("cell-1", "coupon-1"),
                ("cell-2", "coupon-2"),
                ("cell-3", "coupon-3"),
            ],
            [
                ("camp-1", "cell-1"),
                ("camp-2", "cell-2"),
                ("camp-3", "cell-3"),
            ],
            [
                ("camp-1", "pre", "post"),
                ("camp-2", "pre", "post"),
                ("camp-3", "pre", "post"),
            ],
            [
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "TARGETED MEDIA", "COUPON AT TILL", "TOTAL", "BASE_VALUE", 999.0),  # Overlapping historic row -> should be replaced by pollen output
                (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "TARGETED MEDIA", "COUPON AT TILL", "TOTAL", "COUPON_VALUE", 12.0),
            ],
        ],
        schemas=[
            CouponAtTillProcessedData.coupon_at_till_campaign_booking_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            CouponAtTillProcessedData.coupon_schema,
            CouponAtTillProcessedData.coupon_cell_schema,
            CouponAtTillProcessedData.cell_schema,
            CouponAtTillProcessedData.campaign_schema,
            ProcessedData.shared_date_merge_input_schema,
        ],
    )

    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed_pollen.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_coupon_at_till_processed(
            spark=spark_session,
            campaign_booking_media_channel_path=campaign_booking_media_channel_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            coupon_path=coupon_path,
            coupon_cell_path=coupon_cell_path,
            cell_path=cell_path,
            campaign_path=campaign_path,
            historic_cat_processed_data=historic_cat_processed_data_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            run_date="2024-01-31",
            correlation_id="corr-multi-pollen",
        )

        actual_df = spark_session.read.parquet(output_path)
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "BASE_VALUE", Decimal("50.00000"), "NA", None),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "COUPON_VALUE", Decimal("50.00000"), "NA", None),
                (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "TARGETED MEDIA", "COUPON AT TILL", "TOTAL", "COUPON_VALUE", Decimal("12.00000"), "NA", None),
            ],
            schema=ProcessedData.shared_date_output_with_load_ts_decimal_18_5_schema,
        )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_coupon_at_till_pollen_keeps_history_when_bookings_invalid(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange only problematic pollen rows plus a historic row that should survive unchanged.
    campaign_booking_media_channel_path = str(tmp_path / "campaign_booking_media_channel")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    coupon_path = str(tmp_path / "coupon")
    coupon_cell_path = str(tmp_path / "coupon_cell")
    cell_path = str(tmp_path / "cell")
    campaign_path = str(tmp_path / "campaign")
    historic_cat_processed_data_path = str(tmp_path / "historic_cat_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            campaign_booking_media_channel_path,
            sku_cluster_mapping_path,
            coupon_path,
            coupon_cell_path,
            cell_path,
            campaign_path,
            historic_cat_processed_data_path,
        ],
        rows_list=[
            [
                ("b1", "camp-1", "onsite", "completed", "coupon_at_till", "sainsbury", 20.0, date(2024, 1, 1), date(2024, 1, 7), ITEM_JSON),  # Wrong channel_type -> filtered out
                ("b2", "camp-2", "instore", "cancelled", "coupon_at_till", "sainsbury", 20.0, date(2024, 1, 1), date(2024, 1, 7), ITEM_JSON),  # Invalid booking_status -> filtered out
            ],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [("coupon-1", date(2024, 1, 1), date(2024, 1, 7), Decimal("35.00"))],
            [("cell-1", "coupon-1")],
            [("camp-1", "cell-1")],
            [("camp-1", "pre", "post")],
            [
                (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "TARGETED MEDIA", "COUPON AT TILL", "TOTAL", "BASE_VALUE", 18.0),
            ],
        ],
        schemas=[
            CouponAtTillProcessedData.coupon_at_till_campaign_booking_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            CouponAtTillProcessedData.coupon_schema,
            CouponAtTillProcessedData.coupon_cell_schema,
            CouponAtTillProcessedData.cell_schema,
            CouponAtTillProcessedData.campaign_schema,
            ProcessedData.shared_date_merge_input_schema,
        ],
    )

    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed_pollen.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_coupon_at_till_processed(
            spark=spark_session,
            campaign_booking_media_channel_path=campaign_booking_media_channel_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            coupon_path=coupon_path,
            coupon_cell_path=coupon_cell_path,
            cell_path=cell_path,
            campaign_path=campaign_path,
            historic_cat_processed_data=historic_cat_processed_data_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            run_date="2024-01-31",
            correlation_id="corr-historic-only",
        )

        actual_df = spark_session.read.parquet(output_path)
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "TARGETED MEDIA", "COUPON AT TILL", "TOTAL", "BASE_VALUE", Decimal("18.00000"), "NA", None),
            ],
            schema=ProcessedData.shared_date_output_with_load_ts_decimal_18_5_schema,
        )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_entrypoint_invokes_prepare_coupon_at_till_processed_pollen_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current coupon-at-till pollen entrypoint contract.
    args = [
        "--campaign-booking-media-channel-path", "s3://input/campaign-bookings",
        "--cell-path", "s3://input/cell",
        "--coupon-cell-path", "s3://input/coupon-cell",
        "--coupon-path", "s3://input/coupon",
        "--campaign-path", "s3://input/campaign",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--historic-cat-processed-data", "s3://input/historic-coupon-at-till",
        "--start-date", "2024-01-01",
        "--end-date", "2024-01-31",
        "--output-path", "s3://output/coupon-at-till",
        "--run-date", "2024-01-31",
        "--correlation-id", "corr-entrypoint",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed_pollen.prepare_coupon_at_till_processed") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        campaign_booking_media_channel_path="s3://input/campaign-bookings",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        coupon_path="s3://input/coupon",
        coupon_cell_path="s3://input/coupon-cell",
        cell_path="s3://input/cell",
        campaign_path="s3://input/campaign",
        historic_cat_processed_data="s3://input/historic-coupon-at-till",
        start_date="2024-01-01",
        end_date="2024-01-31",
        output_path="s3://output/coupon-at-till",
        run_date="2024-01-31",
        correlation_id="corr-entrypoint",
    )
