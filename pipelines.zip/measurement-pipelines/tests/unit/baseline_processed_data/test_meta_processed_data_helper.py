from datetime import date, datetime
from decimal import Decimal

import pytest
from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data_helper import (
    build_meta_camp_cluster,
    build_meta_camp_skus_split,
    build_meta_metrics_jb_sku_pre,
    build_meta_num_skus,
    build_meta_processed_data,
    build_meta_reqd_metrics,
    build_meta_reqd_metrics_jb,
    build_meta_required_campaigns,
    build_meta_required_campaigns_columns,
    build_meta_unique_brand_cluster,
    build_meta_unique_brand_cluster_unpivot,
    build_skeleton_meta_unique_brand,
    build_skeleton_with_dates,
    format_meta_processed_data,
    merge_pollen_and_dtp_data,
    read_s3_data,
)
from spark_pipeline.common.variables import MetaConfig
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.meta_processed_data import MetaProcessedData
from tests.unit.baseline_processed_data.utils import assert_spark_df_equal, write_rows_to_parquet, drop_load_ts


# ----- Helper functions -----

def _write_meta_read_inputs(
    spark_session: SparkSession,
    campaign_path: str,
    insight_path: str,
    sku_cluster_mapping_path: str,
    campaign_rows,
    insight_rows,
    sku_cluster_rows,
    weekly_dates_path: str | None = None,
    weekly_date_rows=None,
    historic_meta_processed_data_path: str | None = None,
    historic_rows=None,
):
    write_rows_to_parquet(
        spark_session,
        campaign_path,
        campaign_rows,
        MetaProcessedData.meta_campaign_normalize_schema,
    )
    write_rows_to_parquet(
        spark_session,
        insight_path,
        insight_rows,
        MetaProcessedData.meta_insight_normalize_schema,
    )
    write_rows_to_parquet(
        spark_session,
        sku_cluster_mapping_path,
        sku_cluster_rows,
        ProcessedData.sku_cluster_mapping_schema,
    )

    if weekly_dates_path is not None:
        write_rows_to_parquet(
            spark_session,
            weekly_dates_path,
            weekly_date_rows or [],
            ProcessedData.weekly_dates_schema,
        )

    if historic_meta_processed_data_path is not None:
        write_rows_to_parquet(
            spark_session,
            historic_meta_processed_data_path,
            historic_rows or [],
            ProcessedData.meta_output_schema,
        )


def _build_meta_output_df(spark_session: SparkSession, rows):
    return spark_session.createDataFrame(rows, schema=ProcessedData.meta_output_schema)


# ----- Tests for read_s3_data -----

def test_read_s3_data_dtp_loads_expected_inputs_and_aggregates_metrics(spark_session: SparkSession, tmp_path):
    # Arrange parquet inputs for the DTP branch.
    campaign_path = str(tmp_path / "fb_campaign_normalize")
    insight_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")

    _write_meta_read_inputs(
        spark_session,
        campaign_path,
        insight_path,
        sku_cluster_mapping_path,
        campaign_rows=[
            ("job-1", None, "camp-1", date(2025, 1, 1), date(2025, 1, 31), "sku-1"),
            ("job-1", None, "camp-1", date(2025, 1, 1), date(2025, 1, 31), "sku-1"),
            ("job-2", None, "camp-2", date(2025, 1, 8), date(2025, 2, 7), "sku-2"),
        ],
        insight_rows=[
            ("camp-1", datetime(2025, 1, 13, 9, 0, 0), 10, 100, 5.0, 15.0),
            ("camp-1", datetime(2025, 1, 15, 10, 0, 0), 20, 200, 7.5, 22.5),
            ("camp-2", datetime(2025, 1, 20, 11, 0, 0), 5, 50, 3.0, 12.0),
        ],
        sku_cluster_rows=[
            ("sku-1", "Category 1", "Sub 1", "Brand A", "CL1"),
            ("sku-2", "Category 2", "Sub 2", "Brand B", "CL2"),
        ],
        weekly_dates_path=weekly_dates_path,
        weekly_date_rows=[
            (date(2025, 1, 13),),
            (date(2025, 1, 20),),
        ],
    )

    # Act: the helper should alias `jobbagid` to `job_id`, aggregate weekly metrics, and load weekly dates.
    meta_camp_skus, meta_metrics, sku_cluster_df, weekly_dates_df, historic_meta_df = read_s3_data(
        spark_session,
        campaign_path,
        insight_path,
        sku_cluster_mapping_path,
        "DTP",
        weekly_dates_path=weekly_dates_path,
    )

    # Assert: DTP returns the three loaded frames plus weekly dates, with no historic pollen fallback.
    expected_meta_camp_skus = spark_session.createDataFrame(
        [
            ("job-1", "camp-1", date(2025, 1, 1), date(2025, 1, 31), "sku-1", "SKU-1"),
            ("job-2", "camp-2", date(2025, 1, 8), date(2025, 2, 7), "sku-2", "SKU-2"),
        ],
        schema=MetaProcessedData.meta_campaign_skus_schema,
    )
    expected_meta_metrics = spark_session.createDataFrame(
        [
            ("camp-1", datetime(2025, 1, 13, 0, 0, 0), 30, 300, 12.5, 37.5),
            ("camp-2", datetime(2025, 1, 20, 0, 0, 0), 5, 50, 3.0, 12.0),
        ],
        schema=MetaProcessedData.meta_metrics_schema,
    )
    expected_sku_cluster_df = spark_session.createDataFrame(
        [
            ("sku-1", "Category 1", "Sub 1", "Brand A", "CL1"),
            ("sku-2", "Category 2", "Sub 2", "Brand B", "CL2"),
        ],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )
    expected_weekly_dates_df = spark_session.createDataFrame(
        [
            (date(2025, 1, 13),),
            (date(2025, 1, 20),),
        ],
        schema=ProcessedData.weekly_dates_schema,
    )

    assert_spark_df_equal(meta_camp_skus, expected_meta_camp_skus)
    assert_spark_df_equal(meta_metrics, expected_meta_metrics)
    assert_spark_df_equal(sku_cluster_df, expected_sku_cluster_df)
    assert_spark_df_equal(weekly_dates_df, expected_weekly_dates_df)
    assert historic_meta_df is None


def test_read_s3_data_dtp_requires_weekly_dates_path(spark_session: SparkSession, tmp_path):
    # Arrange minimal parquet inputs without the branch-specific weekly dates dataset.
    campaign_path = str(tmp_path / "fb_campaign_normalize")
    insight_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")

    _write_meta_read_inputs(
        spark_session,
        campaign_path,
        insight_path,
        sku_cluster_mapping_path,
        campaign_rows=[("job-1", None, "camp-1", date(2025, 1, 1), date(2025, 1, 31), "sku-1")],
        insight_rows=[("camp-1", datetime(2025, 1, 13, 9, 0, 0), 10, 100, 5.0, 15.0)],
        sku_cluster_rows=[("sku-1", "Category 1", "Sub 1", "Brand A", "CL1")],
    )

    # Act / Assert: DTP runs should fail fast when the weekly dates path is omitted.
    with pytest.raises(ValueError, match="weekly_dates_path is required for DTP branch"):
        read_s3_data(
            spark_session,
            campaign_path,
            insight_path,
            sku_cluster_mapping_path,
            "DTP",
        )


def test_read_s3_data_pollen_loads_booking_id_and_historic_dataset(spark_session: SparkSession, tmp_path):
    # Arrange parquet inputs for the POLLEN branch.
    campaign_path = str(tmp_path / "fb_campaign_normalize_pollen")
    insight_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    historic_meta_processed_data_path = str(tmp_path / "historic_meta_processed_data")

    _write_meta_read_inputs(
        spark_session,
        campaign_path,
        insight_path,
        sku_cluster_mapping_path,
        campaign_rows=[
            (None, "booking-1", "camp-1", date(2025, 2, 1), date(2025, 2, 28), "sku-1"),
        ],
        insight_rows=[
            ("camp-1", datetime(2025, 2, 5, 12, 0, 0), 12, 120, 8.5, 18.5),
        ],
        sku_cluster_rows=[
            ("sku-1", "Category 1", "Sub 1", "Brand A", "CL1"),
        ],
        historic_meta_processed_data_path=historic_meta_processed_data_path,
        historic_rows=[
            (
                date(2025, 1, 27),
                "Category 1",
                "Brand A",
                "CL1",
                "OFFSITE",
                "META",
                "TOTAL",
                "IMPRESSIONS",
                Decimal("1000.00000"),
            ),
        ],
    )

    # Act: POLLEN should alias `booking_id` to `job_id` and load historic DTP output instead of weekly dates.
    meta_camp_skus, meta_metrics, sku_cluster_df, weekly_dates_df, historic_meta_df = read_s3_data(
        spark_session,
        campaign_path,
        insight_path,
        sku_cluster_mapping_path,
        "POLLEN",
        historic_meta_processed_data_path=historic_meta_processed_data_path,
    )

    # Assert: POLLEN returns the expected campaign rows, metrics and historic output, with no weekly dates frame.
    expected_meta_camp_skus = spark_session.createDataFrame(
        [
            ("booking-1", "camp-1", date(2025, 2, 1), date(2025, 2, 28), "sku-1", "SKU-1"),
        ],
        schema=MetaProcessedData.meta_campaign_skus_schema,
    )
    expected_meta_metrics = spark_session.createDataFrame(
        [
            ("camp-1", datetime(2025, 2, 3, 0, 0, 0), 12, 120, 8.5, 18.5),
        ],
        schema=MetaProcessedData.meta_metrics_schema,
    )
    expected_sku_cluster_df = spark_session.createDataFrame(
        [("sku-1", "Category 1", "Sub 1", "Brand A", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )
    expected_historic_meta_df = spark_session.createDataFrame(
        [
            (
                date(2025, 1, 27),
                "Category 1",
                "Brand A",
                "CL1",
                "OFFSITE",
                "META",
                "TOTAL",
                "IMPRESSIONS",
                Decimal("1000.00000"),
            ),
        ],
        schema=ProcessedData.meta_output_schema,
    )

    assert_spark_df_equal(meta_camp_skus, expected_meta_camp_skus)
    assert_spark_df_equal(meta_metrics, expected_meta_metrics)
    assert_spark_df_equal(sku_cluster_df, expected_sku_cluster_df)
    assert weekly_dates_df is None
    assert_spark_df_equal(historic_meta_df, expected_historic_meta_df)


def test_read_s3_data_pollen_requires_historic_meta_processed_data_path(spark_session: SparkSession, tmp_path):
    # Arrange minimal parquet inputs without the branch-specific historic meta dataset.
    campaign_path = str(tmp_path / "fb_campaign_normalize_pollen")
    insight_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")

    _write_meta_read_inputs(
        spark_session,
        campaign_path,
        insight_path,
        sku_cluster_mapping_path,
        campaign_rows=[(None, "booking-1", "camp-1", date(2025, 2, 1), date(2025, 2, 28), "sku-1")],
        insight_rows=[("camp-1", datetime(2025, 2, 5, 12, 0, 0), 12, 120, 8.5, 18.5)],
        sku_cluster_rows=[("sku-1", "Category 1", "Sub 1", "Brand A", "CL1")],
    )

    # Act / Assert: POLLEN runs should fail fast when the historic fallback path is omitted.
    with pytest.raises(ValueError, match="historic_meta_processed_data_path is required for POLLEN branch"):
        read_s3_data(
            spark_session,
            campaign_path,
            insight_path,
            sku_cluster_mapping_path,
            "POLLEN",
        )


# ------ Tests for campaign and metric helpers ------

def test_build_meta_required_campaigns_keeps_only_skus_present_in_cluster_mapping(spark_session: SparkSession):
    # Arrange campaign SKUs where one item is mapped to a brand/cluster and one is not.
    meta_camp_skus = spark_session.createDataFrame(
        [
            ("job-1", "camp-1", date(2025, 1, 1), date(2025, 1, 31), "sku-1", "SKU-1"),
            ("job-2", "camp-2", date(2025, 1, 8), date(2025, 2, 7), "sku-x", "SKU-X"),  # No matching sku
        ],
        schema=MetaProcessedData.meta_campaign_skus_schema,
    )
    sku_cluster_df = spark_session.createDataFrame(
        [
            ("sku-1", "Category 1", "Sub 1", "Brand A", "CL1"),
        ],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: the helper should keep only campaign rows whose item appears in the cluster lookup.
    actual_df = build_meta_required_campaigns(meta_camp_skus, sku_cluster_df)

    # Assert: the unmatched SKU is excluded and the mapped row gains category + brand columns.
    expected_df = spark_session.createDataFrame(
        [
            ("job-1", "camp-1", date(2025, 1, 1), date(2025, 1, 31), "sku-1", "SKU-1", "Category 1", "Brand A"),
        ],
        schema=MetaProcessedData.meta_required_campaigns_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_required_campaigns_columns_returns_distinct_job_campaign_pairs(spark_session: SparkSession):
    # Arrange required campaign rows containing a duplicated job/campaign combination.
    meta_required_campaigns_df = spark_session.createDataFrame(
        [
            ("job-1", "camp-1", date(2025, 1, 1), date(2025, 1, 31), "sku-1", "SKU-1", "Category 1", "Brand A"),
            ("job-1", "camp-1", date(2025, 1, 1), date(2025, 1, 31), "sku-2", "SKU-2", "Category 1", "Brand A"),
            ("job-2", "camp-2", date(2025, 1, 8), date(2025, 2, 7), "sku-3", "SKU-3", "Category 2", "Brand B"),
        ],
        schema=MetaProcessedData.meta_required_campaigns_schema,
    )

    # Act: only distinct job/campaign identifiers should be retained.
    actual_df = build_meta_required_campaigns_columns(meta_required_campaigns_df)

    # Assert: duplicate campaign is removed.
    expected_df = spark_session.createDataFrame(
        [
            ("job-1", "camp-1"),
            ("job-2", "camp-2"),
        ],
        schema=MetaProcessedData.meta_required_campaigns_columns_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_reqd_metrics_filters_to_required_campaigns_and_attaches_job_id(spark_session: SparkSession):
    # Arrange campaign metrics where one campaign is out of scope.
    meta_metrics_df = spark_session.createDataFrame(
        [
            ("camp-1", datetime(2025, 1, 13, 0, 0, 0), 10, 100, 5.0, 15.0),
            ("camp-2", datetime(2025, 1, 13, 0, 0, 0), 20, 200, 8.0, 18.0),
        ],
        schema=MetaProcessedData.meta_metrics_schema,
    )
    meta_required_campaigns_columns_df = spark_session.createDataFrame(
        [("job-1", "camp-1")],
        schema=MetaProcessedData.meta_required_campaigns_columns_schema,
    )

    # Act: only metrics for the required campaigns should survive, enriched with job_id.
    actual_df = build_meta_reqd_metrics(meta_metrics_df, meta_required_campaigns_columns_df)

    # Assert: out-of-scope campaign metrics are removed.
    expected_df = spark_session.createDataFrame(
        [("camp-1", datetime(2025, 1, 13, 0, 0, 0), 10, 100, 5.0, 15.0, "job-1")],
        schema=MetaProcessedData.meta_reqd_metrics_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_reqd_metrics_jb_aggregates_metrics_per_week_and_job(spark_session: SparkSession):
    # Arrange required metrics with duplicate rows in the same job/week bucket.
    meta_reqd_metrics_df = spark_session.createDataFrame(
        [
            ("camp-1", datetime(2025, 1, 13, 0, 0, 0), 10, 100, 5.0, 15.0, "job-1"),
            ("camp-1", datetime(2025, 1, 13, 0, 0, 0), 20, 200, 7.5, 12.5, "job-1"),
            ("camp-1", datetime(2025, 1, 20, 0, 0, 0), 5, 50, 2.0, 6.0, "job-1"),
        ],
        schema=MetaProcessedData.meta_reqd_metrics_schema,
    )

    # Act: each job/week combination should be summed once.
    actual_df = build_meta_reqd_metrics_jb(meta_reqd_metrics_df)

    # Assert: duplicate rows are aggregated into weekly totals.
    expected_df = spark_session.createDataFrame(
        [
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), 30, 300, 12.5, 27.5),
            ("job-1", datetime(2025, 1, 20, 0, 0, 0), 5, 50, 2.0, 6.0),
        ],
        schema=MetaProcessedData.meta_metrics_jb_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_metrics_jb_sku_pre_expands_each_job_to_distinct_skus(spark_session: SparkSession):
    # Arrange one aggregated job/week metric row plus campaign rows containing a duplicated SKU.
    meta_reqd_metrics_jb_df = spark_session.createDataFrame(
        [("job-1", datetime(2025, 1, 13, 0, 0, 0), 30, 300, 12.5, 27.5)],
        schema=MetaProcessedData.meta_metrics_jb_schema,
    )
    meta_required_campaigns_df = spark_session.createDataFrame(
        [
            ("job-1", "camp-1", date(2025, 1, 1), date(2025, 1, 31), "sku-1", "SKU-1", "Category 1", "Brand A"),
            ("job-1", "camp-1", date(2025, 1, 1), date(2025, 1, 31), "sku-1", "SKU-1", "Category 1", "Brand A"),
            ("job-1", "camp-2", date(2025, 1, 8), date(2025, 2, 7), "sku-2", "SKU-2", "Category 1", "Brand A"),
        ],
        schema=MetaProcessedData.meta_required_campaigns_schema,
    )

    # Act: the helper should attach the distinct SKU list for the job.
    actual_df = build_meta_metrics_jb_sku_pre(meta_reqd_metrics_jb_df, meta_required_campaigns_df)

    # Assert: duplicated SKU membership is removed before the expansion.
    expected_df = spark_session.createDataFrame(
        [
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), 30, 300, 12.5, 27.5, "sku-1", "Category 1", "Brand A"),
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), 30, 300, 12.5, 27.5, "sku-2", "Category 1", "Brand A"),
        ],
        schema=MetaProcessedData.meta_metrics_jb_sku_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_num_skus_counts_distinct_non_null_skus(spark_session: SparkSession):
    # Arrange job/SKU rows with duplicate and null SKU values.
    meta_metrics_jb_sku_df = spark_session.createDataFrame(
        [
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), 30, 300, 12.5, 27.5, "sku-1", "Category 1", "Brand A"),
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), 30, 300, 12.5, 27.5, "sku-1", "Category 1", "Brand A"),
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), 30, 300, 12.5, 27.5, None, "Category 1", "Brand A"),
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), 30, 300, 12.5, 27.5, "sku-2", "Category 1", "Brand A"),
        ],
        schema=MetaProcessedData.meta_metrics_jb_sku_schema,
    )

    # Act: distinct non-null SKUs should be counted per job.
    actual_df = build_meta_num_skus(meta_metrics_jb_sku_df)

    # Assert: duplicates and null SKUs do not inflate the count.
    expected_df = spark_session.createDataFrame(
        [("job-1", 2)],
        schema=MetaProcessedData.meta_num_skus_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_camp_skus_split_divides_metrics_evenly_across_skus(spark_session: SparkSession):
    # Arrange per-job metrics expanded across two SKU rows with a known SKU count.
    meta_metrics_jb_sku_df = spark_session.createDataFrame(
        [
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), 100, 1000, 40.0, 80.0, "sku-1", "Category 1", "Brand A"),
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), 100, 1000, 40.0, 80.0, "sku-2", "Category 1", "Brand A"),
        ],
        schema=MetaProcessedData.meta_metrics_jb_sku_schema,
    )
    meta_num_skus_df = spark_session.createDataFrame(
        [("job-1", 2)],
        schema=MetaProcessedData.meta_num_skus_schema,
    )

    # Act: each metric should be split equally across the two SKUs.
    actual_df = build_meta_camp_skus_split(meta_metrics_jb_sku_df, meta_num_skus_df)

    # Assert: each SKU receives half of the original per-job totals.
    expected_df = spark_session.createDataFrame(
        [
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), "Category 1", "Brand A", "sku-1", 2, 50.0, 500.0, 40.0, 20.0),
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), "Category 1", "Brand A", "sku-2", 2, 50.0, 500.0, 40.0, 20.0),
        ],
        schema=MetaProcessedData.meta_camp_skus_split_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_camp_skus_split_zero_when_skus_missing(spark_session: SparkSession):
    # Arrange per-job metrics without a matching SKU-count row.
    meta_metrics_jb_sku_df = spark_session.createDataFrame(
        [("job-1", datetime(2025, 1, 13, 0, 0, 0), 100, 1000, 40.0, 80.0, "sku-1", "Category 1", "Brand A")],
        schema=MetaProcessedData.meta_metrics_jb_sku_schema,
    )
    meta_num_skus_df = spark_session.createDataFrame([], schema=MetaProcessedData.meta_num_skus_schema)

    # Act: the left join leaves `number_of_skus` null, so the helper should coalesce the divided metrics to zero.
    actual_df = build_meta_camp_skus_split(meta_metrics_jb_sku_df, meta_num_skus_df)

    # Assert: missing SKU counts do not crash the split step and yield zero-valued metrics.
    expected_df = spark_session.createDataFrame(
        [("job-1", datetime(2025, 1, 13, 0, 0, 0), "Category 1", "Brand A", "sku-1", None, 0.0, 0.0, 0.0, 0.0)],
        schema=MetaProcessedData.meta_camp_skus_split_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_camp_cluster_left_joins_cluster_numbers(spark_session: SparkSession):
    # Arrange split SKU rows where only one SKU exists in the cluster mapping.
    meta_camp_skus_split_df = spark_session.createDataFrame(
        [
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), "Category 1", "Brand A", "sku-1", 2, 50.0, 500.0, 40.0, 20.0),
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), "Category 1", "Brand A", "sku-x", 2, 50.0, 500.0, 40.0, 20.0),
        ],
        schema=MetaProcessedData.meta_camp_skus_split_schema,
    )
    sku_cluster_df = spark_session.createDataFrame(
        [("sku-1", "Category 1", "Sub 1", "Brand A", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: the cluster mapping should be attached where available and left null otherwise.
    actual_df = build_meta_camp_cluster(meta_camp_skus_split_df, sku_cluster_df)

    # Assert: unmatched SKUs are preserved because this stage uses a left join.
    expected_df = spark_session.createDataFrame(
        [
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), "Category 1", "Brand A", "sku-1", 2, 50.0, 500.0, 40.0, 20.0, "CL1"),
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), "Category 1", "Brand A", "sku-x", 2, 50.0, 500.0, 40.0, 20.0, None),
        ],
        schema=MetaProcessedData.meta_camp_cluster_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_unique_brand_cluster_sums_metrics_by_brand_cluster_and_week(spark_session: SparkSession):
    # Arrange two SKU rows that roll up into the same brand/cluster/week bucket.
    meta_camp_cluster_df = spark_session.createDataFrame(
        [
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), "Category 1", "Brand A", "sku-1", 2, 50.0, 500.0, 40.0, 20.0, "CL1"),
            ("job-1", datetime(2025, 1, 13, 0, 0, 0), "Category 1", "Brand A", "sku-2", 2, 50.0, 500.0, 40.0, 20.0, "CL1"),
        ],
        schema=MetaProcessedData.meta_camp_cluster_schema,
    )

    # Act: metrics should aggregate to one row per brand/cluster/week.
    actual_df = build_meta_unique_brand_cluster(meta_camp_cluster_df)

    # Assert: the two SKU-level rows sum into a single cluster-level record.
    expected_df = spark_session.createDataFrame(
        [("Category 1", "Brand A", "CL1", datetime(2025, 1, 13, 0, 0, 0), 100.0, 1000.0, 40.0, 80.0)],
        schema=MetaProcessedData.meta_unique_brand_cluster_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_unpivot_creates_metric_rows_with_attributes(spark_session: SparkSession):
    # Arrange one aggregated brand/cluster/week row containing all metric columns.
    meta_unique_brand_cluster_df = spark_session.createDataFrame(
        [("Category 1", "Brand A", "CL1", datetime(2025, 1, 13, 0, 0, 0), 100.0, 1000.0, 40.0, 80.0)],
        schema=MetaProcessedData.meta_unique_brand_cluster_schema,
    )

    # Act: the wide metric columns should be unpivoted into four long-format metric rows.
    actual_df = build_meta_unique_brand_cluster_unpivot(meta_unique_brand_cluster_df)

    # Assert: the helper adds the static Meta marketing hierarchy to each metric row.
    expected_df = spark_session.createDataFrame(
        [
            ("Category 1", "Brand A", "CL1", date(2025, 1, 13), "impressions", 1000.0, MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL),
            ("Category 1", "Brand A", "CL1", date(2025, 1, 13), "clicks", 100.0, MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL),
            ("Category 1", "Brand A", "CL1", date(2025, 1, 13), "internals_media_spend", 40.0, MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL),
            ("Category 1", "Brand A", "CL1", date(2025, 1, 13), "externals_media_spend", 80.0, MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL),
        ],
        schema=MetaProcessedData.meta_unique_brand_cluster_unpivot_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_skeleton_meta_unique_brand_returns_distinct_dimensions_without_weeks(spark_session: SparkSession):
    # Arrange unpivoted rows spanning multiple weeks for the same metric dimensions.
    meta_unique_brand_cluster_unpivot_df = spark_session.createDataFrame(
        [
            ("Category 1", "Brand A", "CL1", date(2025, 1, 13), "clicks", 100.0, MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL),
            ("Category 1", "Brand A", "CL1", date(2025, 1, 20), "clicks", 120.0, MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL),
        ],
        schema=MetaProcessedData.meta_unique_brand_cluster_unpivot_schema,
    )

    # Act: the skeleton should drop the week/value fields and keep one distinct metric dimension row.
    actual_df = build_skeleton_meta_unique_brand(meta_unique_brand_cluster_unpivot_df)

    # Assert: repeated dimensions across weeks collapse into one row.
    expected_df = spark_session.createDataFrame(
        [("Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "clicks")],
        schema=MetaProcessedData.meta_skeleton_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_skeleton_with_dates_cross_joins_each_week_with_each_metric_dimension(spark_session: SparkSession):
    # Arrange two weekly dates and two distinct skeleton rows.
    weekly_dates_df = spark_session.createDataFrame(
        [
            (date(2025, 1, 13),),
            (date(2025, 1, 20),),
        ],
        schema=ProcessedData.weekly_dates_schema,
    )
    skeleton_df = spark_session.createDataFrame(
        [
            ("Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "clicks"),
            ("Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "impressions"),
        ],
        schema=MetaProcessedData.meta_skeleton_schema,
    )

    # Act: each weekly date should be paired with every metric dimension row.
    actual_df = build_skeleton_with_dates(weekly_dates_df, skeleton_df)

    # Assert: the resulting skeleton contains all week x metric combinations.
    expected_df = spark_session.createDataFrame(
        [
            (date(2025, 1, 13), "Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "clicks"),
            (date(2025, 1, 13), "Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "impressions"),
            (date(2025, 1, 20), "Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "clicks"),
            (date(2025, 1, 20), "Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "impressions"),
        ],
        schema=spark_session.createDataFrame([], schema=MetaProcessedData.meta_processed_data_intermediate_schema).drop("value").schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_meta_processed_data_fills_missing_values_and_drops_null_clusters(spark_session: SparkSession):
    # Arrange a skeleton with one missing metric row and one null-cluster row that should be removed.
    skeleton_with_dates_df = spark_session.createDataFrame(
        [
            (date(2025, 1, 13), "Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "clicks"),
            (date(2025, 1, 20), "Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "clicks"),
            (date(2025, 1, 13), "Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, None, "clicks"),
        ],
        schema=spark_session.createDataFrame([], schema=MetaProcessedData.meta_processed_data_intermediate_schema).drop("value").schema,
    )
    meta_unique_brand_cluster_unpivot_df = spark_session.createDataFrame(
        [
            ("Category 1", "Brand A", "CL1", date(2025, 1, 13), "clicks", 100.0, MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL),
        ],
        schema=MetaProcessedData.meta_unique_brand_cluster_unpivot_schema,
    )

    # Act: missing metric rows should be filled with zero and null-cluster rows filtered out.
    actual_df = build_meta_processed_data(skeleton_with_dates_df, meta_unique_brand_cluster_unpivot_df)

    # Assert: one real value and one zero-filled value remain, while the null cluster row is removed.
    expected_df = spark_session.createDataFrame(
        [
            (date(2025, 1, 13), "Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "clicks", 100.0),
            (date(2025, 1, 20), "Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "clicks", 0.0),
        ],
        schema=MetaProcessedData.meta_processed_data_intermediate_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_format_meta_processed_data_renames_columns_and_casts_metric_values(spark_session: SparkSession):
    # Arrange one long-format intermediate Meta processed-data row.
    meta_processed_data_df = spark_session.createDataFrame(
        [
            (date(2025, 1, 13), "Category 1", "Brand A", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CL1", "clicks", 100.0),
        ],
        schema=MetaProcessedData.meta_processed_data_intermediate_schema,
    )

    # Act: the helper should upper-case the metric name and cast the value to the output decimal type.
    actual_df = format_meta_processed_data(meta_processed_data_df)

    # Assert: the output matches the production Meta processed-data shape.
    expected_df = spark_session.createDataFrame(
        [
            (date(2025, 1, 13), "Category 1", "Brand A", "CL1", MetaConfig.MARKETING_TYPE, MetaConfig.MARKETING_CHANNEL, MetaConfig.MARKETING_SUB_CHANNEL, "CLICKS", Decimal("100.00000")),
        ],
        schema=ProcessedData.meta_output_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


# Tests for merge_pollen_and_dtp_data

def test_merge_pollen_and_dtp_data_prefers_pollen_only_for_exact_case_matches(spark_session: SparkSession):
    # Arrange overlapping pollen + DTP rows plus one DTP-only row.
    pollen_df = _build_meta_output_df(
        spark_session,
        [
            (date(2025, 1, 13), "Category 1", "Brand A", "cl1", "offsite", "meta", "total", "clicks", Decimal("100.00000")),
        ],
    )
    dtp_df = _build_meta_output_df(
        spark_session,
        [
            (date(2025, 1, 13), "CATEGORY 1", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "CLICKS", Decimal("999.00000")),
            (date(2025, 1, 20), "Category 1", "Brand A", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("2000.00000")),
        ],
    )

    # Act: pollen rows should win for overlapping keys, and both inputs should be normalised to uppercase dimensions.
    # Brand/category comparisons are now case-sensitive, so mixed-case rows are treated as distinct.
    actual_df = drop_load_ts(merge_pollen_and_dtp_data(pollen_df, dtp_df))

    # Assert: the overlapping DTP row is removed, the unique DTP row is kept, and runtime metadata is attached.
    expected_df = spark_session.createDataFrame(
        [
            (date(2025, 1, 13), "Category 1", "Brand A", "CL1", "OFFSITE", "META", "TOTAL", "CLICKS", Decimal("100.00000"), "NA"),
            (date(2025, 1, 13), "CATEGORY 1", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "CLICKS", Decimal("999.00000"), "NA"),
            (date(2025, 1, 20), "Category 1", "Brand A", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("2000.00000"), "NA"),
        ],
        schema=actual_df.schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_merge_pollen_dtp_empty_inputs_keep_runtime_columns(spark_session: SparkSession):
    # Arrange two empty Meta processed-data inputs.
    pollen_df = spark_session.createDataFrame([], schema=ProcessedData.meta_output_schema)
    dtp_df = spark_session.createDataFrame([], schema=ProcessedData.meta_output_schema)

    # Act: merging two empty inputs should still return the full runtime output shape.
    actual_df = merge_pollen_and_dtp_data(pollen_df, dtp_df)

    # Assert: the result is empty but contains the metadata columns needed downstream.
    assert actual_df.count() == 0
    assert actual_df.columns == [field.name for field in ProcessedData.shared_date_output_with_load_ts_decimal_18_5_schema.fields]


def test_merge_pollen_dtp_keeps_null_pollen_metric_on_overlap(spark_session: SparkSession):
    # Arrange overlapping pollen/DTP rows where pollen wins even though the metric value is null.
    pollen_df = _build_meta_output_df(
        spark_session,
        [
            (date(2025, 1, 13), "Category 1", "Brand A", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", None),
        ],
    )
    dtp_df = _build_meta_output_df(
        spark_session,
        [
            (date(2025, 1, 13), "Category 1", "Brand A", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("1000.00000")),
        ],
    )

    # Act: DTP should be dropped because the join key exists in pollen, regardless of the pollen value.
    actual_df = merge_pollen_and_dtp_data(pollen_df, dtp_df)

    # Assert: the pollen row is retained with its null metric value.
    assert actual_df.count() == 1
    assert actual_df.first().metric_value is None
