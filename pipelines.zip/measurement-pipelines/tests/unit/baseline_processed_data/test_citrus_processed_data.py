from datetime import date, datetime
from decimal import Decimal
from unittest import mock

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.citrus_processed_data import (
    _aggregate_weekly_citrus_metrics,
    _build_citrus_item_cluster_data,
    _build_citrus_metric_grid,
    _format_citrus_output,
    _load_s3_data,
    _unpivot_citrus_metrics,
    entrypoint,
    prepare_citrus_processed_data,
)
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.citrus_processed_data import CitrusProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_spark_df_equal,
    local_spark_s3_overwrite,
    write_pipeline_inputs_to_parquet,
)


def test_build_citrus_item_cluster_data_drops_unmapped_items_and_enriches_attributes(
    spark_session: SparkSession,
):
    # Arrange loaded citrus rows where only one item exists in the cluster mapping.
    ad_request_realised_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 2, 10, 0, 0), 100.0, 10.0, 5.0, 1000.0, 100.0, 2.0, 20.0, "10129232"),
            (datetime(2024, 1, 2, 10, 0, 0), 50.0, 5.0, 2.0, 500.0, 50.0, 1.0, 10.0, "9094304"),
        ],
        schema=CitrusProcessedData.citrus_loaded_request_schema,
    )
    sku_cluster_mapping_df = spark_session.createDataFrame(
        [("10129232", "CatA", "SubA", "BrandA", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: only mapped item ids should survive the join and pick up cluster attributes.
    actual_df = _build_citrus_item_cluster_data(
        ad_request_realised_df,
        sku_cluster_mapping_df,
        BaselineProcessedData.citrus_processed_data_config,
    )

    # Assert: the unmapped Citrus row is removed and the remaining row has the expected hierarchy values.
    expected_df = spark_session.createDataFrame(
        [("10129232", "BrandA", "CL1", "CatA", datetime(2024, 1, 2, 10, 0, 0), 100.0, 10.0, 5.0, 1000.0, 100.0, 2.0, 20.0)],
        schema=CitrusProcessedData.citrus_item_cluster_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_aggregate_weekly_citrus_metrics_sums_rows_within_the_same_cluster_week(
    spark_session: SparkSession,
):
    # Arrange two Citrus rows in the same cluster/week and one in a different week.
    citrus_item_cluster_df = spark_session.createDataFrame(
        [
            ("1", "BrandA", "CL1", "CatA", datetime(2024, 1, 2, 10, 0, 0), 100.0, 10.0, 5.0, 1000.0, 100.0, 2.0, 20.0),
            ("2", "BrandA", "CL1", "CatA", datetime(2024, 1, 3, 12, 0, 0), 40.0, 4.0, 2.0, 400.0, 40.0, 1.0, 8.0),
            ("1", "BrandA", "CL1", "CatA", datetime(2024, 1, 9, 10, 0, 0), 20.0, 2.0, 1.0, 200.0, 20.0, 0.0, 4.0),
        ],
        schema=CitrusProcessedData.citrus_item_cluster_schema,
    )

    # Act: the helper should aggregate every metric at week/brand/cluster granularity.
    actual_df = _aggregate_weekly_citrus_metrics(
        citrus_item_cluster_df,
        BaselineProcessedData.citrus_processed_data_config,
    )

    # Assert: the two rows in the first week are summed together and the second week remains separate.
    expected_df = spark_session.createDataFrame(
        [
            ("BrandA", "CL1", "CatA", date(2024, 1, 1), 140.0, 14.0, 7.0, 1400.0, 140.0, 3.0, 28.0),
            ("BrandA", "CL1", "CatA", date(2024, 1, 8), 20.0, 2.0, 1.0, 200.0, 20.0, 0.0, 4.0),
        ],
        schema=CitrusProcessedData.citrus_weekly_cluster_metrics_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_citrus_metric_grid_zero_fills_missing_weeks(spark_session: SparkSession):
    # Arrange one observed Citrus week and one missing modelling week in the skeleton.
    weekly_citrus_metrics_df = spark_session.createDataFrame(
        [
            ("BrandA", "CL1", "CatA", date(2024, 1, 8), 10.0, 2.0, 1.0, 100.0, 20.0, 3.0, 5.0),
        ],
        schema=CitrusProcessedData.citrus_weekly_cluster_metrics_schema,
    )
    weekly_dates_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1),),
            (date(2024, 1, 8),),
        ],
        schema=ProcessedData.weekly_dates_schema,
    )

    # Act: missing modelling weeks should be added and every metric column should be zero-filled.
    actual_df = _build_citrus_metric_grid(
        weekly_citrus_metrics_df,
        weekly_dates_df,
        BaselineProcessedData.citrus_processed_data_config,
    )

    # Assert: the missing week is present with zeros while static marketing attributes are attached to every row.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, "ONSITE", "ONSITE-GOL", "TOTAL"),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", 10.0, 2.0, 1.0, 100.0, 20.0, 3.0, 5.0, "ONSITE", "ONSITE-GOL", "TOTAL"),
        ],
        schema=CitrusProcessedData.citrus_metric_grid_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_unpivot_citrus_metrics_filters_null_clusters_and_creates_metric_rows(
    spark_session: SparkSession,
):
    # Arrange one valid cluster row and one null-cluster row that should be filtered out.
    citrus_metric_grid_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", 10.0, 2.0, 1.0, 100.0, 20.0, 3.0, 5.0, "ONSITE", "ONSITE-GOL", "TOTAL"),
            (date(2024, 1, 1), "CatA", "BrandA", None, 10.0, 2.0, 1.0, 100.0, 20.0, 3.0, 5.0, "ONSITE", "ONSITE-GOL", "TOTAL"),
        ],
        schema=CitrusProcessedData.citrus_metric_grid_schema,
    )

    # Act: the helper should unpivot only the non-null cluster rows into one row per metric.
    actual_df = _unpivot_citrus_metrics(
        citrus_metric_grid_df,
        BaselineProcessedData.citrus_processed_data_config,
    )

    # Assert: one valid cluster row expands to seven metric rows.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "sales_revenue", 10.0),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "ad_revenue", 2.0),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "ad_spend", 1.0),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "impressions", 100.0),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "clicks", 20.0),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "conversions", 3.0),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "unit_sales", 5.0),
        ],
        schema=CitrusProcessedData.citrus_unpivoted_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_format_citrus_output_uppercases_metric_names_and_casts_metric_values(spark_session: SparkSession):
    # Arrange unpivoted Citrus metric rows before the final formatting step.
    citrus_unpivoted_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "sales_revenue", 140.0),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "clicks", 140.0),
        ],
        schema=CitrusProcessedData.citrus_unpivoted_schema,
    )

    # Act: the final formatter should uppercase metric names and cast metric values to the output decimal type.
    actual_df = _format_citrus_output(citrus_unpivoted_df)

    # Assert: final rows follow the public output contract used by the pipeline writer.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "SALES_REVENUE", Decimal("140")),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "CLICKS", Decimal("140")),
        ],
        schema=ProcessedData.citrus_output_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_load_s3_data_normalises_item_codes_and_loads_shared_sources(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange parquet sources containing padded item ids and one weekly date.
    advertise_request_realised_path = str(tmp_path / "advertise_request_realised")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            advertise_request_realised_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [
                (datetime(2024, 1, 2, 10, 0, 0), 100.0, 10.0, 5.0, 1000.0, 100.0, 20.0, 2.0, "0001"),
                (datetime(2024, 1, 2, 10, 0, 0), 50.0, 5.0, 2.0, 500.0, 50.0, 10.0, 1.0, "ABC2"),
            ],
            [
                ("1", "CatA", "SubA", "BrandA", "CL1"),
            ],
            [
                (date(2024, 1, 1),),
            ],
        ],
        schemas=[
            CitrusProcessedData.citrus_ad_request_realised_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    # Act: the loader should normalise item ids and return the three shared sources.
    ad_request_realised_df, sku_cluster_mapping_df, weekly_dates_df = _load_s3_data(
        spark=spark_session,
        advertise_request_realised_path=advertise_request_realised_path,
        sku_cluster_mapping_path=sku_cluster_mapping_path,
        weekly_dates_path=weekly_dates_path,
        config=BaselineProcessedData.citrus_processed_data_config,
    )

    # Assert: leading zeroes are stripped, ids are lower-cased, and the shared sources are loaded unchanged.
    expected_loaded_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 2, 10, 0, 0), 100.0, 10.0, 5.0, 1000.0, 100.0, 2.0, 20.0, "1"),
            (datetime(2024, 1, 2, 10, 0, 0), 50.0, 5.0, 2.0, 500.0, 50.0, 1.0, 10.0, "abc2"),
        ],
        schema=CitrusProcessedData.citrus_loaded_request_schema,
    )
    expected_sku_cluster_df = spark_session.createDataFrame(
        [("1", "CatA", "SubA", "BrandA", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )
    expected_weekly_dates_df = spark_session.createDataFrame(
        [(date(2024, 1, 1),)],
        schema=ProcessedData.weekly_dates_schema,
    )

    assert_spark_df_equal(ad_request_realised_df, expected_loaded_df)
    assert_spark_df_equal(sku_cluster_mapping_df, expected_sku_cluster_df)
    assert_spark_df_equal(weekly_dates_df, expected_weekly_dates_df)


def test_prepare_citrus_processed_data_writes_expected_cluster_level_output(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange parquet inputs with two mapped items in one cluster plus one unmapped item that should be ignored.
    advertise_request_realised_path = str(tmp_path / "advertise_request_realised")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            advertise_request_realised_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [
                (datetime(2024, 1, 2, 10, 0, 0), 100.0, 10.0, 5.0, 1000.0, 100.0, 20.0, 2.0, "0001"),
                (datetime(2024, 1, 3, 12, 0, 0), 40.0, 4.0, 2.0, 400.0, 40.0, 8.0, 1.0, "0002"),
                (datetime(2024, 1, 2, 13, 0, 0), 999.0, 99.0, 50.0, 9999.0, 999.0, 99.0, 9.0, "0009"),
            ],
            [
                ("1", "CatA", "SubA", "BrandA", "CL1"),
                ("2", "CatA", "SubA", "BrandA", "CL1"),
            ],
            [
                (date(2024, 1, 1),),
                (date(2024, 1, 8),),
            ],
        ],
        schemas=[
            CitrusProcessedData.citrus_ad_request_realised_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    # patch the safe writer so the test still exercises a local parquet write.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.citrus_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_citrus_processed_data(
            spark=spark_session,
            advertise_request_realised_path=advertise_request_realised_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
        )

    # Assert: the observed week is aggregated correctly and the missing week is zero-filled across all metrics.
    actual_df = spark_session.read.parquet(output_path).select(*ProcessedData.citrus_output_schema.fieldNames())
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "AD_REVENUE", Decimal("14")),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "AD_SPEND", Decimal("7")),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "CLICKS", Decimal("140")),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "CONVERSIONS", Decimal("3")),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "IMPRESSIONS", Decimal("1400")),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "SALES_REVENUE", Decimal("140")),
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "UNIT_SALES", Decimal("28")),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "AD_REVENUE", Decimal("0")),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "AD_SPEND", Decimal("0")),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "CLICKS", Decimal("0")),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "CONVERSIONS", Decimal("0")),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "IMPRESSIONS", Decimal("0")),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "SALES_REVENUE", Decimal("0")),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "ONSITE", "ONSITE-GOL", "TOTAL", "UNIT_SALES", Decimal("0")),
        ],
        schema=ProcessedData.citrus_output_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_citrus_empty_output_when_no_items_map_clusters(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange parquet inputs where every Citrus row is unmapped after item-id normalisation.
    advertise_request_realised_path = str(tmp_path / "advertise_request_realised")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            advertise_request_realised_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [
                (datetime(2024, 1, 2, 10, 0, 0), 100.0, 10.0, 5.0, 1000.0, 100.0, 20.0, 2.0, "0009"),
            ],
            [
                ("1", "CatA", "SubA", "BrandA", "CL1"),
            ],
            [
                (date(2024, 1, 1),),
            ],
        ],
        schemas=[
            CitrusProcessedData.citrus_ad_request_realised_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    # Act: with no mapped Citrus rows, the pipeline should write an empty final DataFrame.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.citrus_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_citrus_processed_data(
            spark=spark_session,
            advertise_request_realised_path=advertise_request_realised_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
        )

    # Assert: no mapped clusters means no skeleton rows and therefore an empty output.
    actual_df = spark_session.read.parquet(output_path).select(*ProcessedData.citrus_output_schema.fieldNames())
    expected_df = spark_session.createDataFrame([], schema=ProcessedData.citrus_output_schema)
    assert_spark_df_equal(actual_df, expected_df)


def test_entrypoint_invokes_prepare_citrus_processed_data_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the Citrus entrypoint.
    args = [
        "--advertise-request-realised-path", "s3://input/citrus",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--weekly-dates-path", "s3://input/weekly-dates",
        "--output-path", "s3://output/citrus",
    ]

    # Act: the entrypoint should parse and forward the arguments to the orchestration function.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.citrus_processed_data.prepare_citrus_processed_data"
    ) as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called exactly once with parsed values.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        advertise_request_realised_path="s3://input/citrus",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        weekly_dates_path="s3://input/weekly-dates",
        output_path="s3://output/citrus",
    )
