from datetime import date, datetime
from decimal import Decimal
from unittest import mock

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.instore_processed_data import (
    entrypoint,
    prepare_instore_processed_data,
)
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.instore_processed_data import InstoreProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_spark_df_equal,
    local_spark_s3_overwrite,
    read_parquet_columns,
    write_pipeline_inputs_to_parquet,
)


def test_prepare_instore_processed_data_writes_expected_zero_filled_weekly_output(spark_session: SparkSession, tmp_path):
    # Arrange minimal in-store inputs with one active campaign week and one extra skeleton week.
    ie_product_path = str(tmp_path / "ie_product")
    ie_location_path = str(tmp_path / "ie_location")
    ie_campaign_filt_path = str(tmp_path / "ie_campaign_filt")
    cust_by_location_path = str(tmp_path / "cust_by_location")
    media_instore_init_path = str(tmp_path / "media_instore_init")
    temp_unified_product_path = str(tmp_path / "temp_unified_product")
    is_active_filter_path = str(tmp_path / "is_active_filter")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            ie_product_path,
            ie_location_path,
            ie_campaign_filt_path,
            cust_by_location_path,
            media_instore_init_path,
            temp_unified_product_path,
            is_active_filter_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [("camp-1", "prod-1")],
            [("camp-1", 101, "STORE1")],
            [("camp-1", date(2024, 1, 1), date(2024, 1, 1), 20.0, None)],
            [(datetime(2024, 1, 1, 0, 0, 0), "STORE1", 30)],
            [("camp-1", "target-1", 101)],
            [("prod-1", "sku-1")],
            [(1,)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [(date(2024, 1, 1),), (date(2024, 1, 8),)],
        ],
        schemas=[
            InstoreProcessedData.instore_ie_product_input_schema,
            InstoreProcessedData.instore_ie_location_input_schema,
            InstoreProcessedData.instore_ie_campaign_filt_input_schema,
            InstoreProcessedData.instore_cust_by_location_schema,
            InstoreProcessedData.instore_media_instore_init_input_schema,
            ProcessedData.temp_unified_product_input_schema,
            InstoreProcessedData.instore_is_active_filter_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    # patch the writer function so the test performs a normal local parquet write.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.instore_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_instore_processed_data(
            spark=spark_session,
            ie_product_path=ie_product_path,
            ie_location_path=ie_location_path,
            ie_campaign_filt_path=ie_campaign_filt_path,
            cust_by_location_path=cust_by_location_path,
            media_instore_init_path=media_instore_init_path,
            temp_unified_product_path=temp_unified_product_path,
            is_active_filter_path=is_active_filter_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
        )

    # Assert: the first week contains observed media cost and exposed customers while the second week is zero-filled.
    actual_df = read_parquet_columns(spark_session, output_path, InstoreProcessedData.instore_dtp_output_schema.fieldNames())
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "IN-STORE", "IN-STORE", "TOTAL", "TOTAL_MEDIA_COST", Decimal("20")),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "IN-STORE", "IN-STORE", "TOTAL", "EXPOSED_CUSTOMERS", Decimal("30")),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "IN-STORE", "IN-STORE", "TOTAL", "TOTAL_MEDIA_COST", Decimal("0")),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "IN-STORE", "IN-STORE", "TOTAL", "EXPOSED_CUSTOMERS", Decimal("0")),
        ],
        schema=InstoreProcessedData.instore_dtp_output_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_instore_empty_output_when_media_cost_zero(spark_session: SparkSession, tmp_path):
    # Arrange in-store inputs where the only campaign has zero media cost and is filtered out.
    ie_product_path = str(tmp_path / "ie_product")
    ie_location_path = str(tmp_path / "ie_location")
    ie_campaign_filt_path = str(tmp_path / "ie_campaign_filt")
    cust_by_location_path = str(tmp_path / "cust_by_location")
    media_instore_init_path = str(tmp_path / "media_instore_init")
    temp_unified_product_path = str(tmp_path / "temp_unified_product")
    is_active_filter_path = str(tmp_path / "is_active_filter")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            ie_product_path,
            ie_location_path,
            ie_campaign_filt_path,
            cust_by_location_path,
            media_instore_init_path,
            temp_unified_product_path,
            is_active_filter_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [("camp-1", "prod-1")],
            [("camp-1", 101, "STORE1")],
            [("camp-1", date(2024, 1, 1), date(2024, 1, 1), 0.0, None)],
            [(datetime(2024, 1, 1, 0, 0, 0), "STORE1", 30)],
            [("camp-1", "target-1", 101)],
            [("prod-1", "sku-1")],
            [(1,)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [(date(2024, 1, 1),)],
        ],
        schemas=[
            InstoreProcessedData.instore_ie_product_input_schema,
            InstoreProcessedData.instore_ie_location_input_schema,
            InstoreProcessedData.instore_ie_campaign_filt_input_schema,
            InstoreProcessedData.instore_cust_by_location_schema,
            InstoreProcessedData.instore_media_instore_init_input_schema,
            ProcessedData.temp_unified_product_input_schema,
            InstoreProcessedData.instore_is_active_filter_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    # Act: With zero media cost, no in-scope campaign survives to the final output.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.instore_processed_data.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_instore_processed_data(
            spark=spark_session,
            ie_product_path=ie_product_path,
            ie_location_path=ie_location_path,
            ie_campaign_filt_path=ie_campaign_filt_path,
            cust_by_location_path=cust_by_location_path,
            media_instore_init_path=media_instore_init_path,
            temp_unified_product_path=temp_unified_product_path,
            is_active_filter_path=is_active_filter_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
        )

    # Assert: the final dataset is empty but still projects to the expected output contract columns.
    expected_df = spark_session.createDataFrame([], schema=InstoreProcessedData.instore_dtp_output_schema)
    assert_spark_df_equal(read_parquet_columns(spark_session, output_path, InstoreProcessedData.instore_dtp_output_schema.fieldNames()), expected_df)


def test_entrypoint_invokes_prepare_instore_processed_data_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current Instore DTP entrypoint
    args = [
        "--ie-product-path", "s3://input/ie-product",
        "--ie-location-path", "s3://input/ie-location",
        "--ie-campaign-filt-path", "s3://input/ie-campaign",
        "--cust-by-location-path", "s3://input/cust-by-location",
        "--media-instore-init-path", "s3://input/media-instore",
        "--temp-unified-product-path", "s3://input/temp-unified-product",
        "--is-active-filter-path", "s3://input/active-filter",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--weekly-dates-path", "s3://input/weekly-dates",
        "--start-date", "2024-01-01",
        "--end-date", "2024-01-31",
        "--output-path", "s3://output/instore",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.marketing_features.instore_processed_data.prepare_instore_processed_data") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        ie_product_path="s3://input/ie-product",
        ie_location_path="s3://input/ie-location",
        ie_campaign_filt_path="s3://input/ie-campaign",
        cust_by_location_path="s3://input/cust-by-location",
        media_instore_init_path="s3://input/media-instore",
        temp_unified_product_path="s3://input/temp-unified-product",
        is_active_filter_path="s3://input/active-filter",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        weekly_dates_path="s3://input/weekly-dates",
        start_date="2024-01-01",
        end_date="2024-01-31",
        output_path="s3://output/instore",
    )
