from datetime import date, datetime
from unittest import mock

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from spark_pipeline.baseline_processed_data.base_price_data import (
    _aggregate_weekly_cluster_base_prices,
    _aggregate_weekly_item_base_prices,
    _build_cluster_metric_grid,
    _enrich_with_sku_clusters,
    _fill_missing_base_price_weeks,
    _filter_to_supermarket_sales,
    prepare_base_price_data,
)
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.schemas.baseline_processed_data.base_price_data import BasePriceDataSchema
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from tests.unit.baseline_processed_data.utils import assert_spark_df_equal, write_pipeline_inputs_to_parquet


def test_filter_to_supermarket_sales_keeps_only_valid_supermarket_rows(
        spark_session: SparkSession,
):
    # Arrange a mix of supermarket, non-supermarket and unmapped stores.
    fact_sales_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 2, 10, 0, 0), "item-1", "store-1", 10.0),
            (datetime(2024, 1, 2, 11, 0, 0), "item-2", "store-2", 20.0),
            (datetime(2024, 1, 2, 12, 0, 0), "item-3", "store-9", 30.0),
        ],
        schema=BasePriceDataSchema.fact_sales_base_price_schema,
    )
    store_hierarchy_df = spark_session.createDataFrame(
        [
            ("store-1", "Supermarket"),
            ("store-2", "Convenience"),
        ],
        schema=ProcessedData.store_hierarchy_schema,
    )

    # Act: only the supermarket store should survive the inner join + site type filter.
    actual_df = _filter_to_supermarket_sales(
        fact_sales_df,
        store_hierarchy_df,
        BaselineProcessedData.base_price_data_config,  # Use real config filters
    ).select("transaction_dt", "item_cd", "store_cd", "base_unit_price_amt", "site_type")

    # Assert: convenience and missing stores are both excluded.
    expected_df = spark_session.createDataFrame(
        [(datetime(2024, 1, 2, 10, 0, 0), "item-1", "store-1", 10.0, "Supermarket")],
        schema=actual_df.schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_weekly_item_base_prices_filter_non_supermarket_take_max(
        spark_session: SparkSession,
):
    # Arrange daily transaction data where the same item has multiple prices in one week.
    fact_sales_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 2, 10, 0, 0), "item-1", "store-1", 10.0),
            (datetime(2024, 1, 4, 12, 0, 0), "item-1", "store-1", 12.0),
            (datetime(2024, 1, 6, 9, 0, 0), "item-1", "store-2", 99.0),
            (datetime(2024, 1, 10, 10, 0, 0), "item-2", "store-1", 15.0),
        ],
        schema=BasePriceDataSchema.fact_sales_base_price_schema,
    )
    store_hierarchy_df = spark_session.createDataFrame(
        [
            ("store-1", "Supermarket"),
            ("store-2", "Convenience"),  # Invalid store type
        ],
        schema=ProcessedData.store_hierarchy_schema,
    )

    # Act: convenience sales are filtered first, then each item/week keeps the max base price.
    actual_df = _aggregate_weekly_item_base_prices(
        _filter_to_supermarket_sales(fact_sales_df, store_hierarchy_df, BaselineProcessedData.base_price_data_config)
    )
    expected_df = spark_session.createDataFrame(
        [
            ("item-1", date(2024, 1, 1), 12.0),
            ("item-2", date(2024, 1, 8), 15.0),
        ],
        schema=BasePriceDataSchema.weekly_item_base_price_schema,
    )

    # Assert: the 99.0 convenience price is ignored and 12.0 is the retained weekly max.
    assert_spark_df_equal(actual_df, expected_df)


def test_enrich_with_sku_clusters_returns_empty_when_no_weekly_items_are_mapped(
        spark_session: SparkSession,
):
    # Arrange weekly item prices that do not exist in the cluster mapping.
    transaction_weekly_df = spark_session.createDataFrame(
        [("item-unknown", date(2024, 1, 1), 50.0)],
        schema=BasePriceDataSchema.weekly_item_base_price_schema,
    )
    sku_cluster_df = spark_session.createDataFrame(
        [("item-1", "CatA", "SubA", "BrandA", 1)],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: the inner join should drop all rows because nothing maps.
    actual_df = _enrich_with_sku_clusters(transaction_weekly_df, sku_cluster_df)

    # Assert: no mapped items means no cluster-level rows can be produced.
    expected_df = spark_session.createDataFrame([], schema=actual_df.schema)
    assert_spark_df_equal(actual_df, expected_df)


def test_enrich_with_sku_clusters_returns_data_when_matching_items_are_mapped(
        spark_session: SparkSession,
):
    # Arrange weekly item prices that do not exist in the cluster mapping.
    transaction_weekly_df = spark_session.createDataFrame(
        [("item-1", date(2024, 1, 1), 50.0)],
        schema=BasePriceDataSchema.weekly_item_base_price_schema,
    )
    sku_cluster_df = spark_session.createDataFrame(
        [("item-1", "CatA", "SubA", "BrandA", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: the inner join should keep the one row because the skus (item_cd) match
    actual_df = _enrich_with_sku_clusters(transaction_weekly_df, sku_cluster_df)

    expected_df = spark_session.createDataFrame(
        [
            ("item-1", date(2024, 1, 1), 50.0, "CatA", "SubA", "BrandA", "CL1"),
        ],
        schema=BasePriceDataSchema.transactions_with_cluster_information_schema,
    )

    # Assert: one row is produced with the values from transaction_weekly_df and sku_cluster_df
    assert_spark_df_equal(actual_df, expected_df)


def test_aggregate_weekly_cluster_base_prices_drops_unmapped_items(spark_session: SparkSession):
    # Arrange weekly prices where one item is mapped into the cluster and one is not.
    transaction_weekly_df = spark_session.createDataFrame(
        [
            ("item-1", date(2024, 1, 1), 12.0),
            ("item-unknown", date(2024, 1, 1), 50.0),
            ("item-2", date(2024, 1, 1), 20.0),
        ],
        schema=BasePriceDataSchema.weekly_item_base_price_schema,
    )
    sku_cluster_df = spark_session.createDataFrame(
        [
            ("item-1", "CatA", "SubA", "BrandA", "CL1"),
            ("item-2", "CatA", "SubA", "BrandA", "CL1"),
        ],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: only mapped items should contribute to the cluster average.
    actual_df = _aggregate_weekly_cluster_base_prices(
        _enrich_with_sku_clusters(transaction_weekly_df, sku_cluster_df)
    )
    expected_df = spark_session.createDataFrame(
        [("CatA", "BrandA", "CL1", date(2024, 1, 1), 16.0)],
        schema=ProcessedData.weekly_cluster_base_price_schema,
    )

    # Assert: the average is (12 + 20) / 2 and the unmapped item is dropped.
    assert_spark_df_equal(actual_df, expected_df)


def test_build_cluster_metric_grid_creates_every_cluster_week_combination(
        spark_session: SparkSession,
):
    # Arrange two observed cluster weeks plus a third week that should be added by the skeleton.
    weekly_cluster_avg_df = spark_session.createDataFrame(
        [
            ("CatA", "BrandA", "CL1", date(2024, 1, 1), 16.0),
            ("CatA", "BrandA", "CL1", date(2024, 1, 15), 27.0),
        ],
        schema=ProcessedData.weekly_cluster_base_price_schema,
    )
    weekly_dates_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1),),
            (date(2024, 1, 8),),
            (date(2024, 1, 15),),
        ],
        schema=ProcessedData.weekly_dates_schema,
    )

    # Act: the helper should cross join all cluster keys with all available modelling weeks.
    actual_df = _build_cluster_metric_grid(
        weekly_cluster_avg_df,
        weekly_dates_df,
        BaselineProcessedData.base_price_data_config["metric"],
    ).select(
        "week_start_date",
        "super_category_name",
        "unique_brand_name",
        "cluster_num",
        "metric",
        "metric_value",
    )

    # Assert: the missing middle week exists with a null metric value ready for imputation.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "TOTAL_SALES", 16.0),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "TOTAL_SALES", None),
            (date(2024, 1, 15), "CatA", "BrandA", "CL1", "TOTAL_SALES", 27.0),
        ],
        schema=actual_df.schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_fill_missing_base_price_weeks_forward_and_backward_fills(spark_session: SparkSession):
    # Arrange a single observed cluster week so both leading and trailing gaps need filling.
    weekly_cluster_avg_df = spark_session.createDataFrame(
        [("CatA", "BrandA", "CL1", date(2024, 1, 8), 25.0)],
        schema=ProcessedData.weekly_cluster_base_price_schema,
    )
    weekly_dates_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1),),
            (date(2024, 1, 8),),
            (date(2024, 1, 15),),
        ],
        schema=ProcessedData.weekly_dates_schema,
    )

    actual_df = (
        _fill_missing_base_price_weeks(
            _build_cluster_metric_grid(
                weekly_cluster_avg_df,
                weekly_dates_df,
                BaselineProcessedData.base_price_data_config["metric"],
            )
        )
        .select(
            "week_start_date",
            "super_category_name",
            "unique_brand_name",
            "cluster_num",
            "metric",
            "final_value",
        )
    )
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "TOTAL_SALES", 25.0),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "TOTAL_SALES", 25.0),
            (date(2024, 1, 15), "CatA", "BrandA", "CL1", "TOTAL_SALES", 25.0),
        ],
        schema=ProcessedData.filled_weekly_cluster_base_price_schema,
    )

    # Assert: missing weeks inherit the nearest observed base price in both directions.
    assert_spark_df_equal(actual_df, expected_df)


def test_fill_missing_base_price_weeks_uses_zero_when_cluster_has_no_observed_values(
        spark_session: SparkSession,
):
    # Arrange a full cluster/week grid that has no metric values at all.
    full_grid_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "TOTAL_SALES", None),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "TOTAL_SALES", None),
        ],
        schema="week_start_date date, super_category_name string, unique_brand_name string, cluster_num string, metric string, metric_value double",
    )

    # Act: with no forward or backward observation available, the function should fall back to zero.
    actual_df = _fill_missing_base_price_weeks(full_grid_df).select(
        "week_start_date",
        "super_category_name",
        "unique_brand_name",
        "cluster_num",
        "metric",
        "final_value",
    )

    # Assert: zero fallback protects downstream consumers from fully null time series.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "CL1", "TOTAL_SALES", 0.0),
            (date(2024, 1, 8), "CatA", "BrandA", "CL1", "TOTAL_SALES", 0.0),
        ],
        schema=ProcessedData.filled_weekly_cluster_base_price_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


# ----- Integration Tests -----
def test_prepare_base_price_data_writes_expected_cluster_level_output(
        spark_session: SparkSession,
        tmp_path,
):
    fact_sales_path = str(tmp_path / "fact_sales")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    store_hierarchy_path = str(tmp_path / "store_hierarchy")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            fact_sales_path,
            sku_cluster_mapping_path,
            store_hierarchy_path,
            weekly_dates_path,
        ],
        rows_list=[
            [
                (datetime(2024, 1, 2, 10, 0, 0), "item-1", "store-1", 10.0),
                (datetime(2024, 1, 3, 10, 0, 0), "item-1", "store-1", 12.0),
                (datetime(2024, 1, 4, 10, 0, 0), "item-2", "store-1", 20.0),
                (datetime(2024, 1, 5, 10, 0, 0), "item-1", "store-2", 999.0),
                (datetime(2024, 1, 2, 10, 0, 0), "item-9", "store-1", 50.0),
                (datetime(2024, 1, 16, 10, 0, 0), "item-1", "store-1", 24.0),
                (datetime(2024, 1, 16, 11, 0, 0), "item-2", "store-1", 30.0),
            ],
            [
                ("item-1", "CatA", "SubA", "BrandA", "CL1"),  # We only run with one cluster now
                ("item-2", "CatA", "SubA", "BrandA", "CL1"),
            ],
            [
                ("store-1", "Supermarket"),
                ("store-2", "Convenience"),  # This store will get filtered out
                ("store-9", "Supermarket"),  # This store has no mapped items
            ],
            [
                (date(2024, 1, 1),),
                (date(2024, 1, 8),),
                (date(2024, 1, 15),),
            ],
        ],
        schemas=[
            BasePriceDataSchema.fact_sales_base_price_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.store_hierarchy_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    # patch the safe writer so unit tests still write the parquet locally.
    with mock.patch(
            "spark_pipeline.baseline_processed_data.base_price_data.spark_s3_overwrite",
            side_effect=lambda path, df: df.write.mode("overwrite").parquet(path),
    ):
        prepare_base_price_data(
            spark=spark_session,
            fact_sales_path=fact_sales_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            store_hierarchy_path=store_hierarchy_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
            correlation_id="corr-123",
        )

    actual_df = spark_session.read.parquet(output_path)
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CatA", "BrandA", "SALES", "SALES", "TOTAL", "CL1", "TOTAL_SALES", "BASE_UNIT_PRICE_AMT", 16.0, "corr-123"),
            (date(2024, 1, 8), "CatA", "BrandA", "SALES", "SALES", "TOTAL", "CL1", "TOTAL_SALES", "BASE_UNIT_PRICE_AMT", 16.0, "corr-123"),
            (date(2024, 1, 15), "CatA", "BrandA", "SALES", "SALES", "TOTAL", "CL1", "TOTAL_SALES", "BASE_UNIT_PRICE_AMT", 27.0, "corr-123"),
        ],
        schema=BasePriceDataSchema.base_price_no_dates_schema,
    )

    assert_spark_df_equal(
        actual_df.select(*BasePriceDataSchema.base_price_no_dates_schema.fieldNames()),  # Ignore any datetime/runtime generated time columns
        expected_df,
    )

    assert actual_df.filter(F.col("load_ts").isNull()).count() == 0
    assert actual_df.filter(F.col("technical_metadata").isNull()).count() == 0


def test_prepare_base_price_data_writes_empty_output_when_no_valid_rows(
        spark_session: SparkSession,
        tmp_path,
):
    # Arrange inputs where all rows are invalid after filtering.
    fact_sales_path = str(tmp_path / "fact_sales")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    store_hierarchy_path = str(tmp_path / "store_hierarchy")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            fact_sales_path,
            sku_cluster_mapping_path,
            store_hierarchy_path,
            weekly_dates_path,
        ],
        rows_list=[
            [
                (datetime(2024, 1, 2, 10, 0, 0), "item-1", "store-1", 10.0),
                (datetime(2024, 1, 2, 10, 0, 0), "item-9", "store-2", 99.0),
            ],
            [("item-1", "CatA", "SubA", "BrandA", "CL1")],
            [
                ("store-1", "Convenience"),
                ("store-2", "Supermarket"),
            ],
            [(date(2024, 1, 1),)],
        ],
        schemas=[
            BasePriceDataSchema.fact_sales_base_price_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.store_hierarchy_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    with mock.patch(
            "spark_pipeline.baseline_processed_data.base_price_data.spark_s3_overwrite",
            side_effect=lambda path, df: df.write.mode("overwrite").parquet(path),
    ):
        prepare_base_price_data(
            spark=spark_session,
            fact_sales_path=fact_sales_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            store_hierarchy_path=store_hierarchy_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
            correlation_id="corr-empty",
        )

    # Assert: one row is removed by store filtering and the other by missing SKU mapping, leaving no output rows.
    actual_df = spark_session.read.parquet(output_path)
    expected_df = spark_session.createDataFrame([], schema=BasePriceDataSchema.base_price_no_dates_schema)  # Ignore any datetime/runtime generated time columns

    assert_spark_df_equal(
        actual_df.select(*BasePriceDataSchema.base_price_no_dates_schema.fieldNames()),
        expected_df,
    )
