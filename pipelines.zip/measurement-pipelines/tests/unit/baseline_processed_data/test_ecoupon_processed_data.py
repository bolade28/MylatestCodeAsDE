from datetime import date
from unittest.mock import patch
from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.ecoupon_processed_data import (
    build_final_aggregated_output,
    calculate_aggregate_coupon_values,
    enrich_with_product_and_brand_info,
    extract_base_brand_campaign_data,
    run_and_save_ecoupon_data_to_parquet,
    run_ecoupon_transformation_pipeline,
)
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.ecoupon_processed_data import EcouponProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    drop_load_ts,
    write_pipeline_inputs_to_parquet,
    local_spark_s3_overwrite
)


def test_extract_base_campaign_data_keeps_latest_matching_assets(
        spark_session: SparkSession,
):
    # Arrange base finance campaign rows spanning every filter choice.
    base_finance_assets_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), date(2024, 1, 7), "Sainsburys", "JB-1", 2, "Campaign completed", 100.0, "asset-123456"),  # Valid latest-timeid
            (date(2024, 1, 1), date(2024, 1, 7), "Sainsburys", "JB-old", 1, "Campaign completed", 200.0, "asset-123456"),  # Filtered out because only the latest timeid should be kept
            (date(2024, 1, 1), date(2024, 1, 7), "Tesco", "JB-2", 2, "Campaign completed", 300.0, "asset-654321"),  # Filtered out due to wrong media_host_name
            (date(2024, 1, 1), date(2024, 1, 7), "Sainsburys", None, 2, "Campaign completed", 100.0, "asset-111111"),  # Filtered out because job bag is required
            (date(2024, 1, 1), date(2024, 1, 7), "Sainsburys", "JB-3", 2, "Campaign active", 100.0, "asset-222222"),  # Filtered out due to incorrect campaign status
            (date(2024, 1, 1), date(2024, 1, 7), "Sainsburys", "JB-4", 2, "Campaign completed", 0.0, "asset-333333"),  # Filtered out because asset value must be positive
            (date(2023, 12, 1), date(2023, 12, 7), "Sainsburys", "JB-5", 2, "Campaign completed", 100.0, "asset-444444"),  # Filtered out because campaign dates are outside the requested range
        ],
        schema=EcouponProcessedData.ecoupon_base_finance_assets_input_schema,
    )
    oc_campaign_df = spark_session.createDataFrame(
        [
            ("camp-1", "123456", date(2024, 1, 1), date(2024, 1, 14)),  # Matching campaign for the surviving asset id suffix
            ("camp-2", None, date(2024, 1, 1), date(2024, 1, 14)),  # No asset id mapping -> cannot join to finance asset
            ("camp-3", "999999", date(2024, 1, 1), date(2024, 1, 14)),  # Unmatched asset id -> should not affect result
        ],
        schema=EcouponProcessedData.ecoupon_oc_campaign_input_schema,
    )

    # Act: only latest-timeid completed Sainsbury finance rows with a matching campaign asset should survive.
    actual_df = extract_base_brand_campaign_data(
        base_finance_assets_df,
        oc_campaign_df,
        start_date=date(2024, 1, 1),
        end_date=date(2024, 1, 31),
    )

    # Assert: all stale, invalid, zero-value, wrong-host and unmatched rows are excluded.
    expected_df = spark_session.createDataFrame(
        [
            ("JB-1", date(2024, 1, 1), date(2024, 1, 7), 100.0, "123456", "camp-1", "123456", date(2024, 1, 1), date(2024, 1, 14)),
        ],
        schema=EcouponProcessedData.ecoupon_base_brand_campaign_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_enrich_with_product_brand_keeps_mapped_assets(
        spark_session: SparkSession,
):
    # Arrange extracted base rows where one asset maps through products to a brand SKU and one does not.
    ecoupon_base_value_df = spark_session.createDataFrame(
        [
            ("JB-1", date(2024, 1, 1), date(2024, 1, 7), 100.0, "123456", "camp-1", "123456", date(2024, 1, 1), date(2024, 1, 14)),
            ("JB-2", date(2024, 1, 1), date(2024, 1, 7), 50.0, "654321", "camp-2", "654321", date(2024, 1, 1), date(2024, 1, 14)),  # sku is not in the cluster mapping
        ],
        schema=EcouponProcessedData.ecoupon_base_brand_campaign_schema,
    )
    oc_products_df = spark_session.createDataFrame(
        [("pk-1", "123456"), ("pk-2", "654321")],
        schema=EcouponProcessedData.ecoupon_oc_products_input_schema,
    )
    temp_unified_product_df = spark_session.createDataFrame(
        [("pk-1", "sku-1"), ("pk-2", "sku-x")],  # sku-x has no brand cluster mapping
        schema=ProcessedData.temp_unified_product_input_schema,
    )
    sku_cluster_df = spark_session.createDataFrame(
        [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: only rows that can map from asset -> product_key -> item_cd -> brand SKU should survive.
    actual_df = enrich_with_product_and_brand_info(
        oc_products_df,
        temp_unified_product_df,
        sku_cluster_df,
        ecoupon_base_value_df,
    )

    # Assert: the unmatched asset is excluded and the surviving row gains item, brand, category and cluster data.
    expected_df = spark_session.createDataFrame(
        [
            ("JB-1", date(2024, 1, 1), date(2024, 1, 7), 100.0, "123456", "camp-1", "123456", date(2024, 1, 1), date(2024, 1, 14), "sku-1", "BRAND A", "CAT A", "CL1"),
        ],
        schema=EcouponProcessedData.ecoupon_base_value_brand_sku_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_calculate_coupon_values_parses_patterns_keeps_unmatched_rows(
        spark_session: SparkSession,
):
    # Arrange one campaign with parseable 99/28 coupons and one campaign with no matching coupon selections.
    ecoupon_base_value_bs = spark_session.createDataFrame(
        [
            ("JB-1", date(2024, 1, 1), date(2024, 1, 7), 100.0, "123456", "camp-1", "123456", date(2024, 1, 1), date(2024, 1, 14), "sku-1", "BRAND A", "CAT A", "CL1"),  # Campaign with matching coupon selections to aggregate
            ("JB-2", date(2024, 1, 8), date(2024, 1, 14), 50.0, "654321", "camp-2", "654321", date(2024, 1, 8), date(2024, 1, 21), "sku-2", "BRAND B", "CAT B", "CL2"),
        ],
        schema=EcouponProcessedData.ecoupon_base_value_brand_sku_schema,
    )
    oc_customer_selection_df = spark_session.createDataFrame(
        [
            ("camp-1", "123456", "sent", "9901000"),
            ("camp-1", "123456", "sent", "2800100"),
            ("camp-1", "123456", "sent", "7700100"),  # Ignored because the prefix is not one of the supported coupon patterns
        ],
        schema=EcouponProcessedData.ecoupon_customer_selection_input_schema,
    )

    # Act: 99-prefixed and 28-prefixed coupon ids should be parsed and aggregated, while unmatched rows stay null.
    actual_df = calculate_aggregate_coupon_values(oc_customer_selection_df, ecoupon_base_value_bs)

    # Assert: campaign one gets 100 + 50 = 150.0 and campaign two is preserved with a null coupon value.
    expected_df = spark_session.createDataFrame(
        [
            ("camp-1", "123456", "JB-1", date(2024, 1, 1), date(2024, 1, 7), 100.0, "123456", date(2024, 1, 1), date(2024, 1, 14), "sku-1", "BRAND A", "CAT A", "CL1", 150.0),
            ("camp-2", "654321", "JB-2", date(2024, 1, 8), date(2024, 1, 14), 50.0, "654321", date(2024, 1, 8), date(2024, 1, 21), "sku-2", "BRAND B", "CAT B", "CL2", None),
        ],
        schema=EcouponProcessedData.ecoupon_performance_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_final_output_zero_fills_drops_null_clusters(spark_session: SparkSession):
    # Arrange one valid cluster row plus one null-cluster row that should be filtered after skeleton expansion.
    weekly_dates_df = spark_session.createDataFrame(
        [(date(2024, 1, 1),), (date(2024, 1, 8),)],
        schema=ProcessedData.weekly_dates_schema,
    )
    ecoupon_performance = spark_session.createDataFrame(
        [
            ("camp-1", "123456", "JB-1", date(2024, 1, 1), date(2024, 1, 7), 70.0, "123456", date(2024, 1, 1), date(2024, 1, 7), "sku-1", "BRAND A", "CAT A", "CL1", 35.0),  # Valid mapped cluster row
            ("camp-2", "654321", "JB-2", date(2024, 1, 1), date(2024, 1, 7), 14.0, "654321", date(2024, 1, 1), date(2024, 1, 7), "sku-x", "BRAND A", "CAT A", None, 7.0),  # Null cluster row should be removed before final output
        ],
        schema=EcouponProcessedData.ecoupon_performance_schema,
    )

    # Act: the helper should build a complete week skeleton, keep valid clusters only, and zero-fill missing week metrics.
    actual_df = build_final_aggregated_output(weekly_dates_df, ecoupon_performance, correlation_id="corr-123")

    # Assert: the valid cluster produces two metrics for both weeks, and runtime load_ts is populated.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "eCoupon", "TOTAL", "base_value", 70.0, "corr-123", None),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "eCoupon", "TOTAL", "coupon_value", 35.0, "corr-123", None),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "ONSITE", "eCoupon", "TOTAL", "base_value", 0.0, "corr-123", None),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "ONSITE", "eCoupon", "TOTAL", "coupon_value", 0.0, "corr-123", None),
        ],
        schema=ProcessedData.shared_date_output_with_load_ts_double_schema,
    )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


# Tests for orchestration
def test_run_ecoupon_transformation_pipeline_returns_expected_cluster_metrics(spark_session: SparkSession):
    # Arrange a minimal but fully connected eCoupon input set spanning one campaign week.
    base_finance_assets_df = spark_session.createDataFrame(
        [(date(2024, 1, 1), date(2024, 1, 7), "Sainsburys", "JB-1", 2, "Campaign completed", 70.0, "asset-123456")],
        schema=EcouponProcessedData.ecoupon_base_finance_assets_input_schema,
    )
    oc_campaign_df = spark_session.createDataFrame(
        [("camp-1", "123456", date(2024, 1, 1), date(2024, 1, 7))],
        schema=EcouponProcessedData.ecoupon_oc_campaign_input_schema,
    )
    oc_products_df = spark_session.createDataFrame(
        [("pk-1", "123456")],
        schema=EcouponProcessedData.ecoupon_oc_products_input_schema,
    )
    temp_unified_product_df = spark_session.createDataFrame(
        [("pk-1", "sku-1")],
        schema=ProcessedData.temp_unified_product_input_schema,
    )
    sku_cluster_df = spark_session.createDataFrame(
        [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )
    oc_customer_selection_df = spark_session.createDataFrame(
        [("camp-1", "123456", "sent", "9901000")],
        schema=EcouponProcessedData.ecoupon_customer_selection_input_schema,
    )
    weekly_dates_df = spark_session.createDataFrame(
        [(date(2024, 1, 1),)],
        schema=ProcessedData.weekly_dates_schema,
    )

    # Act: the orchestrator should chain the helper stages and return the final DTP output shape.
    actual_df = run_ecoupon_transformation_pipeline(
        base_finance_assets_df,
        oc_campaign_df,
        date(2024, 1, 1),
        date(2024, 1, 31),
        oc_products_df,
        temp_unified_product_df,
        sku_cluster_df,
        oc_customer_selection_df,
        weekly_dates_df,
        correlation_id="corr-pipeline",
    )

    # Assert: the pipeline returns the expected two metric rows and runtime metadata.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "eCoupon", "TOTAL", "base_value", 70.0, "corr-pipeline", None),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "eCoupon", "TOTAL", "coupon_value", 100.0, "corr-pipeline", None),
        ],
        schema=ProcessedData.shared_date_output_with_load_ts_double_schema,
    )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_run_and_save_ecoupon_data_to_parquet_writes_expected_output(spark_session: SparkSession, tmp_path):
    # Arrange parquet inputs for one fully connected DTP campaign.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    base_finance_assets_path = str(tmp_path / "base_finance_assets")
    oc_campaign_path = str(tmp_path / "oc_campaign")
    oc_products_path = str(tmp_path / "oc_products")
    temp_unified_product_path = str(tmp_path / "temp_unified_product")
    oc_customer_selection_path = str(tmp_path / "oc_customer_selection")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            base_finance_assets_path,
            oc_campaign_path,
            oc_products_path,
            temp_unified_product_path,
            oc_customer_selection_path,
            sku_cluster_mapping_path,
        ],
        rows_list=[
            [(date(2024, 1, 1),)],  # Weekly skeleton contains the single modelling week expected in the output
            [(date(2024, 1, 1), date(2024, 1, 7), "Sainsburys", "JB-1", 2, "Campaign completed", 70.0, "asset-123456")],  # Valid finance asset feeding base value
            [("camp-1", "123456", date(2024, 1, 1), date(2024, 1, 7))],  # Campaign row matched via the asset id suffix
            [("pk-1", "123456")],  # Product lookup from asset id to product key
            [("pk-1", "sku-1")],  # Unified product mapping from product key to item code
            [("camp-1", "123456", "sent", "9901000")],  # One coupon selection worth 100.0
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],  # Brand cluster mapping needed for the final cluster-level output
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            EcouponProcessedData.ecoupon_base_finance_assets_input_schema,
            EcouponProcessedData.ecoupon_oc_campaign_input_schema,
            EcouponProcessedData.ecoupon_oc_products_input_schema,
            ProcessedData.temp_unified_product_input_schema,
            EcouponProcessedData.ecoupon_customer_selection_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.ecoupon_processed_data.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):

        # Act: the top-level DTP script should load all parquet inputs and write the transformed output locally.
        run_and_save_ecoupon_data_to_parquet(
            spark=spark_session,
            base_finance_assets_path=base_finance_assets_path,
            oc_campaign_path=oc_campaign_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            oc_products_path=oc_products_path,
            temp_unified_product_path=temp_unified_product_path,
            oc_customer_selection_path=oc_customer_selection_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            weekly_dates_path=weekly_dates_path,
            output_path=output_path,
            correlation_id="corr-write",
        )

        # Assert: the written parquet matches the expected DTP output contract and includes runtime timestamps.
        actual_df = spark_session.read.parquet(output_path)
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "eCoupon", "TOTAL", "base_value", 70.0, "corr-write", None),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "eCoupon", "TOTAL", "coupon_value", 100.0, "corr-write", None),
            ],
            schema=ProcessedData.shared_date_output_with_load_ts_double_schema,
        )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])
