from datetime import date
from decimal import Decimal
from unittest.mock import patch
from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.ecoupon_processed_data_pollen import (
    build_ecoupon_processed_data,
    load_campaign_data,
    merge_pollen_and_dtp_data,
    prepare_ecoupon_base,
    prepare_ecoupon_processed_data_pollen,
    transform_ecoupon_metrics,
)
from spark_pipeline.common.variables import EcouponConfig
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.ecoupon_processed_data import EcouponProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    drop_load_ts,
    write_pipeline_inputs_to_parquet,
    local_spark_s3_overwrite
)

# Expected sku format
VALID_ITEM_JSON = '[{"skuId": "700"}, {"skuId": "999"}]'


def test_load_campaign_data_filters_invalid_bookings_and_keeps_only_brand_skus(spark_session: SparkSession):
    # Arrange valid and invalid campaign booking rows spanning filter branches and unknown SKUs.
    campaign_booking_media_channel_df = spark_session.createDataFrame(
        [
            ("b1", "camp-1", "onsite", "completed", "ecoupon", "sainsbury", 10.0, date(2024, 1, 1), date(2024, 1, 7), VALID_ITEM_JSON),  # Valid booking; sku 700 maps and sku 999 is intentionally unmapped
            ("b2", "~~", "onsite", "completed", "ecoupon", "sainsbury", 10.0, date(2024, 1, 1), date(2024, 1, 7), VALID_ITEM_JSON),  # Filtered out because placeholder campaign ids are invalid
            ("b3", "camp-3", "onsite", "completed", "other", "sainsbury", 10.0, date(2024, 1, 1), date(2024, 1, 7), VALID_ITEM_JSON),  # Filtered out because media provider is not ecoupon
            ("b4", "camp-4", "onsite", "completed", "ecoupon", "sainsbury", 10.0, date(2024, 2, 1), date(2024, 2, 7), VALID_ITEM_JSON),  # Filtered out because booking dates are outside the requested window
            ("b5", "camp-5", "onsite", "completed", "ecoupon", "sainsbury", 10.0, date(2024, 1, 1), date(2024, 1, 7), "[]"),  # Filtered out because the booking contains no sku ids
        ],
        schema=EcouponProcessedData.ecoupon_campaign_booking_input_schema,
    )
    sku_cluster_df = spark_session.createDataFrame(
        [("700", "CAT A", "SUB A", "BRAND A", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: only in-range completed ecoupon bookings with at least one mapped brand SKU should survive.
    actual_df = load_campaign_data(
        campaign_booking_media_channel_df,
        sku_cluster_df,
        start_date="2024-01-01",
        end_date="2024-01-31",
    )

    # Assert: invalid rows are filtered out and the unknown SKU in the valid booking is dropped by the inner brand join.
    expected_df = spark_session.createDataFrame(
        [("camp-1", date(2024, 1, 1), date(2024, 1, 7), 10.0, "700", "BRAND A", "CAT A", "CL1")],
        schema=EcouponProcessedData.ecoupon_onsite_campaigns_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


# Tests for prepare_ecoupon_base
def test_prepare_ecoupon_base_filters_non_positive_spend(spark_session: SparkSession):
    # Arrange positive, zero-spend, and no-selection onsite campaign rows.
    onsite_campaigns = spark_session.createDataFrame(
        [
            ("camp-1", date(2024, 1, 1), date(2024, 1, 7), 10.0, "700", "BRAND A", "CAT A", "CL1"),
            ("camp-2", date(2024, 1, 1), date(2024, 1, 7), 0.0, "800", "BRAND B", "CAT B", "CL2"),
            ("camp-3", date(2024, 1, 8), date(2024, 1, 14), 8.0, "900", "BRAND C", "CAT C", "CL3"),
        ],
        schema=EcouponProcessedData.ecoupon_onsite_campaigns_schema,
    )
    oc_customer_selection_df = spark_session.createDataFrame(
        [
            ("camp-1", None, "sent", "9901000"),
            ("camp-1", None, "sent", "2800100"),
            ("camp-1", None, "sent", "0000000"),  # Ignored because the coupon id does not match a supported prefix
        ],
        schema=EcouponProcessedData.ecoupon_customer_selection_input_schema,
    )

    # Act: positive-spend rows should form the base dataset and coupon values should aggregate by campaign id.
    actual_df = prepare_ecoupon_base(onsite_campaigns, oc_customer_selection_df)

    # Assert: zero-spend campaigns are excluded, parseable coupons sum to 150.0, and unmatched campaigns remain with null coupon_value.
    expected_df = spark_session.createDataFrame(
        [
            ("NA", date(2024, 1, 1), date(2024, 1, 7), 10.0, "camp-1", "700", "BRAND A", "CAT A", 150.0),
            ("NA", date(2024, 1, 8), date(2024, 1, 14), 8.0, "camp-3", "900", "BRAND C", "CAT C", None),
        ],
        schema=EcouponProcessedData.ecoupon_pollen_base_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_transform_ecoupon_metrics_keeps_case_mismatched_clusters_null(spark_session: SparkSession):
    # Arrange one matched SKU and one unmatched SKU spanning a single week.
    ecoupon_performance = spark_session.createDataFrame(
        [
            ("NA", date(2024, 1, 1), date(2024, 1, 7), 70.0, "camp-1", "700", "BRAND A", "CAT A", 35.0),  # Mapped sku that should receive cluster metadata
            ("NA", date(2024, 1, 1), date(2024, 1, 7), 14.0, "camp-2", "999", "BRAND A", "CAT A", 7.0),  # Unmapped sku preserved with null cluster for downstream filtering
        ],
        schema=EcouponProcessedData.ecoupon_pollen_base_schema,
    )
    sku_cluster_df = spark_session.createDataFrame(
        [("700", "cat a", "sub a", "brand a", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: the helper should expand to daily grain, roll up to week, left join cluster mapping, and unpivot base/coupon metrics.
    actual_df = transform_ecoupon_metrics(ecoupon_performance, sku_cluster_df)

    # Assert: Case-mismatched brand/category values no longer match the cluster mapping, so both rows keep null clusters.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CAT A", "BRAND A", "700", None, "base_value", 70.0, EcouponConfig.MARKETING_TYPE, EcouponConfig.MARKETING_CHANNEL, EcouponConfig.MARKETING_SUB_CHANNEL),
            (date(2024, 1, 1), "CAT A", "BRAND A", "700", None, "coupon_value", 35.0, EcouponConfig.MARKETING_TYPE, EcouponConfig.MARKETING_CHANNEL, EcouponConfig.MARKETING_SUB_CHANNEL),
            (date(2024, 1, 1), "CAT A", "BRAND A", "999", None, "base_value", 14.0, EcouponConfig.MARKETING_TYPE, EcouponConfig.MARKETING_CHANNEL, EcouponConfig.MARKETING_SUB_CHANNEL),
            (date(2024, 1, 1), "CAT A", "BRAND A", "999", None, "coupon_value", 7.0, EcouponConfig.MARKETING_TYPE, EcouponConfig.MARKETING_CHANNEL, EcouponConfig.MARKETING_SUB_CHANNEL),
        ],
        schema=EcouponProcessedData.ecoupon_unpivot_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_build_ecoupon_processed_data_filters_null_clusters_formats_output(spark_session: SparkSession):
    # Arrange booking and coupon data where only one of the exploded SKUs exists in the cluster mapping.
    campaign_booking_media_channel_df = spark_session.createDataFrame(
        [("b1", "camp-1", "onsite", "completed", "ecoupon", "sainsbury", 10.0, date(2024, 1, 1), date(2024, 1, 7), VALID_ITEM_JSON)],
        schema=EcouponProcessedData.ecoupon_campaign_booking_input_schema,
    )
    oc_customer_selection_df = spark_session.createDataFrame(
        [("camp-1", None, "sent", "9901000")],
        schema=EcouponProcessedData.ecoupon_customer_selection_input_schema,
    )
    sku_cluster_mapping_df = spark_session.createDataFrame(
        [("700", "CAT A", "SUB A", "BRAND A", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: the orchestrator should keep only mapped brand clusters, aggregate metrics, and cast metric values to decimal output type.
    actual_df = build_ecoupon_processed_data(
        campaign_booking_media_channel_df,
        oc_customer_selection_df,
        sku_cluster_mapping_df,
        start_date="2024-01-01",
        end_date="2024-01-31",
        correlation_id="corr-pollen",
    )

    # Assert: the null-cluster SKU is dropped and the final output contains one row per metric with runtime metadata.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", EcouponConfig.MARKETING_TYPE, EcouponConfig.MARKETING_CHANNEL, EcouponConfig.MARKETING_SUB_CHANNEL, "base_value", Decimal("10.0000000000"), "corr-pollen", None),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", EcouponConfig.MARKETING_TYPE, EcouponConfig.MARKETING_CHANNEL, EcouponConfig.MARKETING_SUB_CHANNEL, "coupon_value", Decimal("100.0000000000"), "corr-pollen", None),
        ],
        schema=ProcessedData.shared_timestamp_output_with_load_ts_decimal_38_10_schema,
    )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_merge_pollen_and_dtp_data_prefers_pollen_and_keeps_unmatched_dtp_rows(spark_session: SparkSession):
    # Arrange overlapping pollen and DTP rows plus one DTP-only metric.
    pollen_df = spark_session.createDataFrame(
        [(date(2024, 1, 1), "cat a", "brand a", "cl1", "onsite", "ecoupon", "total", "base_value", 10.0)],
        schema=ProcessedData.shared_date_merge_input_schema,
    )
    dtp_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "ECOUPON", "TOTAL", "BASE_VALUE", 999.0),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "ECOUPON", "TOTAL", "COUPON_VALUE", 50.0),
        ],
        schema=ProcessedData.shared_date_merge_input_schema,
    )

    # Act: pollen should take precedence
    # Brand/category comparisons are now case-sensitive, so mixed-case rows are retained separately.
    actual_df = merge_pollen_and_dtp_data(pollen_df, dtp_df)

    # Assert: differently-cased brand/category rows are both kept and runtime metadata is attached.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "cat a", "brand a", "CL1", "ONSITE", "ECOUPON", "TOTAL", "BASE_VALUE", Decimal("10.00000"), "NA", None),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "ECOUPON", "TOTAL", "BASE_VALUE", Decimal("999.00000"), "NA", None),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "ECOUPON", "TOTAL", "COUPON_VALUE", Decimal("50.00000"), "NA", None),
        ],
        schema=ProcessedData.shared_date_output_with_load_ts_decimal_18_5_schema,
    )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


# Tests for prepare_ecoupon_processed_data_pollen
def test_ecoupon_pollen_returns_pollen_and_writes_merged_output(
        spark_session: SparkSession,
        tmp_path,
):
    # Arrange parquet inputs for one valid pollen campaign plus one DTP-only historic metric.
    campaign_booking_media_channel_path = str(tmp_path / "campaign_booking_media_channel")
    historic_ecoupon_processed_data_path = str(tmp_path / "historic_ecoupon_processed_data")
    oc_customer_selection_path = str(tmp_path / "oc_customer_selection")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            campaign_booking_media_channel_path,
            historic_ecoupon_processed_data_path,
            oc_customer_selection_path,
            sku_cluster_mapping_path,
        ],
        rows_list=[
            [("b1", "camp-1", "onsite", "completed", "ecoupon", "sainsbury", 10.0, date(2024, 1, 1), date(2024, 1, 7), VALID_ITEM_JSON)],  # Valid booking that will produce the fresh pollen output
            [(date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "ECOUPON", "TOTAL", "COUPON_VALUE", 50.0)],  # Historic DTP-only metric that should survive the merge when not overlapped
            [("camp-1", None, "sent", "9901000")],  # One coupon selection worth 100.0 for the active booking
            [("700", "CAT A", "SUB A", "BRAND A", "CL1")],  # Cluster mapping needed so the valid sku is retained in the final output
        ],
        schemas=[
            EcouponProcessedData.ecoupon_campaign_booking_input_schema,
            ProcessedData.shared_date_merge_input_schema,
            EcouponProcessedData.ecoupon_customer_selection_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.ecoupon_processed_data_pollen.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):

        # Act: the pollen script should return the fresh pollen output but write the merged pollen-over-DTP dataset to parquet.
        returned_pollen_df = prepare_ecoupon_processed_data_pollen(
            spark=spark_session,
            campaign_booking_media_channel_path=campaign_booking_media_channel_path,
            historic_ecoupon_processed_data=historic_ecoupon_processed_data_path,
            oc_customer_selection_path=oc_customer_selection_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            output_path=output_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            correlation_id="corr-write",
        )
        written_df = spark_session.read.parquet(output_path)

        # Assert: the return value is the pollen-only dataframe, while the written parquet contains the merged uppercase output with runtime metadata.
        expected_returned_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", EcouponConfig.MARKETING_TYPE, EcouponConfig.MARKETING_CHANNEL, EcouponConfig.MARKETING_SUB_CHANNEL, "base_value", Decimal("10.0000000000"), "corr-write", None),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", EcouponConfig.MARKETING_TYPE, EcouponConfig.MARKETING_CHANNEL, EcouponConfig.MARKETING_SUB_CHANNEL, "coupon_value", Decimal("100.0000000000"), "corr-write", None),
            ],
            schema=ProcessedData.shared_timestamp_output_with_load_ts_decimal_38_10_schema,
        )
        expected_written_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "ECOUPON", "TOTAL", "BASE_VALUE", Decimal("10.00000"), "NA", None),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "ONSITE", "ECOUPON", "TOTAL", "COUPON_VALUE", Decimal("100.00000"), "NA", None),
            ],
            schema=ProcessedData.shared_date_output_with_load_ts_decimal_18_5_schema,
        )

    assert_spark_df_equal(drop_load_ts(returned_pollen_df), drop_load_ts(expected_returned_df))
    assert_non_null_columns(returned_pollen_df, ["load_ts"])
    assert_spark_df_equal(drop_load_ts(written_df), drop_load_ts(expected_written_df))
    assert_non_null_columns(written_df, ["load_ts"])
