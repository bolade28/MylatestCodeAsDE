from datetime import date, datetime
from decimal import Decimal
from unittest import mock
from unittest.mock import patch
from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data_pollen import (
    entrypoint,
    prepare_meta_processed_data,
)
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.meta_processed_data import MetaProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    drop_load_ts,
    write_pipeline_inputs_to_parquet,
    local_spark_s3_overwrite
)


def test_meta_pollen_merged_output_with_pollen_precedence(spark_session: SparkSession, tmp_path):
    # Arrange pollen inputs that produce one Meta week plus one historic DTP-only week.
    fb_campaign_normalize_pollen_path = str(tmp_path / "fb_campaign_normalize_pollen")
    fb_insight_normalize_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    historic_meta_processed_data_path = str(tmp_path / "historic_meta_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            fb_campaign_normalize_pollen_path,
            fb_insight_normalize_path,
            sku_cluster_mapping_path,
            historic_meta_processed_data_path,
        ],
        rows_list=[
            [(None, "booking-1", "camp-1", date(2024, 1, 1), date(2024, 1, 7), "sku-1")],
            [("camp-1", datetime(2024, 1, 1, 0, 0, 0), 10, 100, 5.0, 15.0)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [(date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("30.00000"))],
        ],
        schemas=[
            MetaProcessedData.meta_campaign_normalize_schema,
            MetaProcessedData.meta_insight_normalize_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.meta_output_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data_pollen.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: the pollen pipeline should write the merged pollen-over-DTP dataset.
        prepare_meta_processed_data(
            spark=spark_session,
            fb_campaign_normalize_pollen_path=fb_campaign_normalize_pollen_path,
            fb_insight_normalize_path=fb_insight_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            historic_meta_processed_data=historic_meta_processed_data_path,
            output_path=output_path,
        )

        # Assert: pollen wins for the current week and unmatched historic rows are preserved with runtime metadata.
        actual_df = spark_session.read.parquet(output_path)
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "CLICKS", Decimal("10.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("100.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "INTERNALS_MEDIA_SPEND", Decimal("5.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "EXTERNALS_MEDIA_SPEND", Decimal("15.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("30.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
            ],
            schema=actual_df.schema,
        )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_meta_pollen_empty_output_without_brand_skus_or_history(spark_session: SparkSession, tmp_path):
    # Arrange pollen inputs where no campaign SKU maps to a brand cluster and the historic dataset is empty.
    fb_campaign_normalize_pollen_path = str(tmp_path / "fb_campaign_normalize_pollen")
    fb_insight_normalize_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    historic_meta_processed_data_path = str(tmp_path / "historic_meta_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            fb_campaign_normalize_pollen_path,
            fb_insight_normalize_path,
            sku_cluster_mapping_path,
            historic_meta_processed_data_path,
        ],
        rows_list=[
            [(None, "booking-1", "camp-1", date(2024, 1, 1), date(2024, 1, 7), "sku-x")],
            [("camp-1", datetime(2024, 1, 1, 0, 0, 0), 10, 100, 5.0, 15.0)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [],
        ],
        schemas=[
            MetaProcessedData.meta_campaign_normalize_schema,
            MetaProcessedData.meta_insight_normalize_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.meta_output_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data_pollen.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: no mapped pollen campaigns and no historic data should result in an empty final dataset.
        prepare_meta_processed_data(
            spark=spark_session,
            fb_campaign_normalize_pollen_path=fb_campaign_normalize_pollen_path,
            fb_insight_normalize_path=fb_insight_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            historic_meta_processed_data=historic_meta_processed_data_path,
            output_path=output_path,
        )

        # Assert: the merged output is empty but still has the expected final schema.
        expected_df = spark_session.createDataFrame([], schema=ProcessedData.shared_date_output_with_load_ts_decimal_18_5_schema)
        assert_spark_df_equal(spark_session.read.parquet(output_path), expected_df)


def test_meta_pollen_multiple_brands_write_rows_per_cluster(spark_session: SparkSession, tmp_path):
    # Arrange pollen inputs for two mapped brands in the same modelling week with no historic fallback rows.
    fb_campaign_normalize_pollen_path = str(tmp_path / "fb_campaign_normalize_pollen")
    fb_insight_normalize_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    historic_meta_processed_data_path = str(tmp_path / "historic_meta_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            fb_campaign_normalize_pollen_path,
            fb_insight_normalize_path,
            sku_cluster_mapping_path,
            historic_meta_processed_data_path,
        ],
        rows_list=[
            [
                (None, "booking-1", "camp-1", date(2024, 1, 1), date(2024, 1, 7), "sku-1"),  # Brand A booking mapped to CL1
                (None, "booking-2", "camp-2", date(2024, 1, 1), date(2024, 1, 7), "sku-2"),  # Brand B booking mapped to CL2
            ],
            [
                ("camp-1", datetime(2024, 1, 1, 0, 0, 0), 10, 100, 5.0, 15.0),  # Metrics for Brand A
                ("camp-2", datetime(2024, 1, 1, 0, 0, 0), 20, 200, 8.0, 18.0),  # Metrics for Brand B
            ],
            [
                ("sku-1", "CAT A", "SUB A", "BRAND A", "CL1"),
                ("sku-2", "CAT B", "SUB B", "BRAND B", "CL2"),
            ],
            [],
        ],
        schemas=[
            MetaProcessedData.meta_campaign_normalize_schema,
            MetaProcessedData.meta_insight_normalize_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.meta_output_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data_pollen.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: the pollen pipeline should emit merged output for both brands.
        prepare_meta_processed_data(
            spark=spark_session,
            fb_campaign_normalize_pollen_path=fb_campaign_normalize_pollen_path,
            fb_insight_normalize_path=fb_insight_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            historic_meta_processed_data=historic_meta_processed_data_path,
            output_path=output_path,
        )

        # Assert: both brands appear in the merged output with one row per Meta metric.
        actual_df = spark_session.read.parquet(output_path)
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "CLICKS", Decimal("10.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("100.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "INTERNALS_MEDIA_SPEND", Decimal("5.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "EXTERNALS_MEDIA_SPEND", Decimal("15.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 1), "CAT B", "BRAND B", "CL2", "OFFSITE", "META", "TOTAL", "CLICKS", Decimal("20.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 1), "CAT B", "BRAND B", "CL2", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("200.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 1), "CAT B", "BRAND B", "CL2", "OFFSITE", "META", "TOTAL", "INTERNALS_MEDIA_SPEND", Decimal("8.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
                (date(2024, 1, 1), "CAT B", "BRAND B", "CL2", "OFFSITE", "META", "TOTAL", "EXTERNALS_MEDIA_SPEND", Decimal("18.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
            ],
            schema=actual_df.schema,
        )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_meta_pollen_keeps_history_when_campaigns_do_not_map(spark_session: SparkSession, tmp_path):
    # Arrange unmapped pollen campaigns plus one historic Meta row that should backfill the final output.
    fb_campaign_normalize_pollen_path = str(tmp_path / "fb_campaign_normalize_pollen")
    fb_insight_normalize_path = str(tmp_path / "fb_insight_normalize")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    historic_meta_processed_data_path = str(tmp_path / "historic_meta_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            fb_campaign_normalize_pollen_path,
            fb_insight_normalize_path,
            sku_cluster_mapping_path,
            historic_meta_processed_data_path,
        ],
        rows_list=[
            [(None, "booking-1", "camp-1", date(2024, 1, 1), date(2024, 1, 7), "sku-x")],  # Unmapped pollen sku, so no fresh pollen rows should survive
            [("camp-1", datetime(2024, 1, 1, 0, 0, 0), 10, 100, 5.0, 15.0)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [(date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("30.00000"))],  # Historic row should be preserved
        ],
        schemas=[
            MetaProcessedData.meta_campaign_normalize_schema,
            MetaProcessedData.meta_insight_normalize_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.meta_output_schema,
        ],
    )

    with patch("spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data_pollen.spark_s3_overwrite",
               side_effect=local_spark_s3_overwrite):
        # Act: with no valid pollen brand rows, the merged output should fall back to historic DTP data.
        prepare_meta_processed_data(
            spark=spark_session,
            fb_campaign_normalize_pollen_path=fb_campaign_normalize_pollen_path,
            fb_insight_normalize_path=fb_insight_normalize_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            historic_meta_processed_data=historic_meta_processed_data_path,
            output_path=output_path,
        )

        # Assert: the historic row survives the merge, normalized to uppercase with runtime metadata attached.
        actual_df = spark_session.read.parquet(output_path)
        expected_df = spark_session.createDataFrame(
            [
                (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", "OFFSITE", "META", "TOTAL", "IMPRESSIONS", Decimal("30.00000"), "NA", datetime(2024, 1, 1, 0, 0, 0)),
            ],
            schema=actual_df.schema,
        )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_entrypoint_invokes_prepare_meta_processed_data_pollen_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current Meta pollen entrypoint contract.
    args = [
        "--fb-campaign-normalize-pollen-path", "s3://input/fb-campaign-pollen",
        "--fb-insight-normalize-path", "s3://input/fb-insight",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--historic-meta-processed-data", "s3://input/historic-meta",
        "--output-path", "s3://output/meta",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.marketing_features.meta_processed_data_pollen.prepare_meta_processed_data") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        fb_campaign_normalize_pollen_path="s3://input/fb-campaign-pollen",
        fb_insight_normalize_path="s3://input/fb-insight",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        historic_meta_processed_data="s3://input/historic-meta",
        output_path="s3://output/meta",
    )
