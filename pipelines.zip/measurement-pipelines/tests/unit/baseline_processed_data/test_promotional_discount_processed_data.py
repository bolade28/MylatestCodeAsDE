from datetime import date, datetime
from unittest import mock

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from spark_pipeline.baseline_processed_data.promotional_discount_processed_data import (
    _aggregate_sales_per_cluster,
    _aggregate_sales_per_supercategory,
    _calculate_promotional_discount_per_cluster,
    _format_promotional_discount_output,
    _join_with_data_skeleton,
    _prepare_transactional_item_data,
    _unpivot_promotional_discount_metrics,
    prepare_promotional_discount_processed_data,
)
from spark_pipeline.common.variables import BaselineProcessedData
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.promotional_discount_processed_data import PromotionalDiscountProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    write_pipeline_inputs_to_parquet,
)


def test_prepare_transactional_items_filter_subcategories_label_non_cluster(
    spark_session: SparkSession,
):
    # Arrange transactional rows spanning mapped, non-cluster, irrelevant and missing-hierarchy items.
    transaction_sale_return_df = spark_session.createDataFrame(
        [
            ("tx-1", datetime(2024, 1, 2, 10, 0, 0), 10.0, 12.0, "item-1", "Sale", "EA", 2.0),
            ("tx-2", datetime(2024, 1, 2, 11, 0, 0), 5.0, 7.0, "item-2", "Return", "KG", 3.0),
            ("tx-3", datetime(2024, 1, 2, 12, 0, 0), 99.0, 100.0, "item-3", "Sale", "EA", 1.0),
            ("tx-4", datetime(2024, 1, 2, 13, 0, 0), 8.0, 9.0, "item-9", "Sale", "EA", 1.0),
        ],
        schema=PromotionalDiscountProcessedData.promotional_discount_transaction_sale_return_schema,
    )
    item_brand_hist_df = spark_session.createDataFrame(
        [
            ("item-1", "CATA", "SUBA", "BRANDA"),
            ("item-2", "CATA", "SUBA", "BRANDB"),
            ("item-3", "CATX", "SUBX", "BRANDX"),
        ],
        schema=PromotionalDiscountProcessedData.promotional_discount_item_brand_hist_schema,
    )
    sku_cluster_mapping_df = spark_session.createDataFrame(
        [("item-1", "CATA", "SUBA", "BRANDA", "CL1")],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )

    # Act: only relevant sub-categories should remain and unmatched brand SKUs should be labelled non_cluster.
    actual_df = _prepare_transactional_item_data(
        transaction_sale_return_df,
        item_brand_hist_df,
        sku_cluster_mapping_df,
        BaselineProcessedData.promotional_discount_config,
    ).select(
        "item_cd",
        "super_category_name",
        "sub_category_name",
        "cluster_num",
        "item_sale_qty",
        "item_return_qty",
        F.to_date("week_start_date").alias("week_start_date"),
    )

    # Assert: irrelevant categories and missing product hierarchy are dropped, while quantities are normalised correctly.
    expected_df = spark_session.createDataFrame(
        [
            ("item-1", "CATA", "SUBA", "CL1", 2, 0, date(2024, 1, 1)),
            ("item-2", "CATA", "SUBA", "non_cluster", 0, 1, date(2024, 1, 1)),
        ],
        schema=actual_df.schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_aggregate_sales_per_cluster_groups_transactions_and_counts_distinct_brands(
    spark_session: SparkSession,
):
    # Arrange transactional rows for one cluster and one non-cluster group in the same week.
    transactional_item_data_df = spark_session.createDataFrame(
        [
            ("tx-1", datetime(2024, 1, 2, 10, 0, 0), 80.0, 100.0, "item-1", "Sale", "EA", 1.0, "CATA", "SUBA", "BRANDA", "CL1", 1, 0, datetime(2024, 1, 1, 0, 0, 0)),
            ("tx-2", datetime(2024, 1, 2, 11, 0, 0), 45.0, 50.0, "item-2", "Sale", "EA", 1.0, "CATA", "SUBA", "BRANDA", "CL1", 1, 0, datetime(2024, 1, 1, 0, 0, 0)),
            ("tx-3", datetime(2024, 1, 3, 12, 0, 0), 90.0, 100.0, "item-3", "Sale", "EA", 1.0, "CATA", "SUBA", "BRANDB", "non_cluster", 1, 0, datetime(2024, 1, 1, 0, 0, 0)),
        ],
        schema=PromotionalDiscountProcessedData.promotional_discount_transactional_item_data_schema,
    )

    # Act: rows should aggregate by super-category, cluster label and week.
    actual_df = _aggregate_sales_per_cluster(transactional_item_data_df)

    # Assert: cluster totals are summed and distinct brands are counted once per grouped bucket.
    expected_df = spark_session.createDataFrame(
        [
            ("CATA", "CL1", datetime(2024, 1, 1, 0, 0, 0), 125.0, 150.0, 1),
            ("CATA", "non_cluster", datetime(2024, 1, 1, 0, 0, 0), 90.0, 100.0, 1),
        ],
        schema=PromotionalDiscountProcessedData.promotional_discount_sales_per_cluster_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_aggregate_sales_per_supercategory_sums_all_cluster_buckets_for_each_week(
    spark_session: SparkSession,
):
    # Arrange cluster-level sales that should roll up to a single super-category total.
    sales_per_cluster_df = spark_session.createDataFrame(
        [
            ("CATA", "CL1", datetime(2024, 1, 1, 0, 0, 0), 125.0, 150.0, 1),
            ("CATA", "non_cluster", datetime(2024, 1, 1, 0, 0, 0), 90.0, 100.0, 1),
        ],
        schema=PromotionalDiscountProcessedData.promotional_discount_sales_per_cluster_schema,
    )

    # Act: the function should aggregate across all cluster labels for the same week.
    actual_df = _aggregate_sales_per_supercategory(sales_per_cluster_df)

    # Assert: totals represent the full super-category, which is later used to derive non-cluster metrics.
    expected_df = spark_session.createDataFrame(
        [("CATA", datetime(2024, 1, 1, 0, 0, 0), 215.0, 250.0, 2)],
        schema=PromotionalDiscountProcessedData.promotional_discount_sales_per_supercategory_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_calculate_promotional_discount_cluster_and_non_cluster(
    spark_session: SparkSession,
):
    # Arrange a cluster summary and a matching super-category total that includes one extra non-cluster brand.
    sales_per_cluster_df = spark_session.createDataFrame(
        [("CATA", "CL1", datetime(2024, 1, 1, 0, 0, 0), 125.0, 150.0, 1)],
        schema=PromotionalDiscountProcessedData.promotional_discount_sales_per_cluster_schema,
    )
    sales_per_supercategory_df = spark_session.createDataFrame(
        [("CATA", datetime(2024, 1, 1, 0, 0, 0), 215.0, 250.0, 2)],
        schema=PromotionalDiscountProcessedData.promotional_discount_sales_per_supercategory_schema,
    )

    # Act: promotional discount is computed for the cluster and for the remaining non-cluster portion.
    actual_df = _calculate_promotional_discount_per_cluster(
        sales_per_cluster_df,
        sales_per_supercategory_df,
        BaselineProcessedData.promotional_discount_config,
    )

    # Assert: the cluster discount is 16.66667 and the remainder of the category is discounted by 10%.
    expected_df = spark_session.createDataFrame(
        [("CL1", datetime(2024, 1, 1, 0, 0, 0), 1, 16.66667, 10.0)],
        schema=PromotionalDiscountProcessedData.promotional_discount_per_cluster_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_calculate_promotional_discount_zero_when_sales_non_positive(
    spark_session: SparkSession,
):
    # Arrange non-positive sales so both cluster and non-cluster discount branches hit the zero fallback.
    sales_per_cluster_df = spark_session.createDataFrame(
        [("CATA", "CL1", datetime(2024, 1, 1, 0, 0, 0), 0.0, 100.0, 1)],
        schema=PromotionalDiscountProcessedData.promotional_discount_sales_per_cluster_schema,
    )
    sales_per_supercategory_df = spark_session.createDataFrame(
        [("CATA", datetime(2024, 1, 1, 0, 0, 0), 0.0, 100.0, 2)],
        schema=PromotionalDiscountProcessedData.promotional_discount_sales_per_supercategory_schema,
    )

    # Act: the function should protect against division by zero / invalid discounts.
    actual_df = _calculate_promotional_discount_per_cluster(
        sales_per_cluster_df,
        sales_per_supercategory_df,
        BaselineProcessedData.promotional_discount_config,
    )

    # Assert: invalid cluster and non-cluster inputs both resolve to zero-valued discount metrics.
    expected_df = spark_session.createDataFrame(
        [("CL1", datetime(2024, 1, 1, 0, 0, 0), 1, 0.0, 0.0)],
        schema=PromotionalDiscountProcessedData.promotional_discount_per_cluster_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_join_with_data_skeleton_creates_missing_weeks_and_zero_fills_metrics(
    spark_session: SparkSession,
):
    # Arrange one computed week and a weekly skeleton containing an additional missing modelling week.
    weekly_dates_df = spark_session.createDataFrame(
        [(date(2024, 1, 1),), (date(2024, 1, 8),)],
        schema=ProcessedData.weekly_dates_schema,
    )
    sku_cluster_mapping_df = spark_session.createDataFrame(
        [
            ("item-1", "CATA", "SUBA", "BRANDA", "CL1"),
            ("item-2", "CATA", "SUBA", "BRANDA", "CL1"),
        ],
        schema=ProcessedData.sku_cluster_mapping_schema,
    )
    promotional_discount_per_cluster_df = spark_session.createDataFrame(
        [("CL1", datetime(2024, 1, 1, 0, 0, 0), 1, 16.66667, 10.0)],
        schema=PromotionalDiscountProcessedData.promotional_discount_per_cluster_schema,
    )

    # Act: the skeleton should guarantee a row for every cluster/week combination.
    actual_df = _join_with_data_skeleton(
        weekly_dates_df,
        sku_cluster_mapping_df,
        promotional_discount_per_cluster_df,
        BaselineProcessedData.promotional_discount_config,
    )

    # Assert: the missing week is present with zero-valued metrics ready for downstream unpivoting.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CATA", "BRANDA", "PROMOTIONAL DISCOUNT", "TOTAL", "CL1", 16.66667, 10.0, 1),
            (date(2024, 1, 8), "CATA", "BRANDA", "PROMOTIONAL DISCOUNT", "TOTAL", "CL1", 0.0, 0.0, 0),
        ],
        schema=PromotionalDiscountProcessedData.promotional_discount_skeleton_metrics_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_unpivot_promotional_discount_metrics_sets_channels(
    spark_session: SparkSession,
):
    # Arrange a single cluster/week row containing all three promotional discount metrics.
    promotional_discount_unique_brand_cluster_hierarchy_df = spark_session.createDataFrame(
        [(date(2024, 1, 1), "CATA", "BRANDA", "PROMOTIONAL DISCOUNT", "TOTAL", "CL1", 16.66667, 10.0, 1)],
        schema=PromotionalDiscountProcessedData.promotional_discount_skeleton_metrics_schema,
    )

    # Act: the wide metrics should be unpivoted into one row per metric with channel labels applied.
    actual_df = _unpivot_promotional_discount_metrics(
        promotional_discount_unique_brand_cluster_hierarchy_df,
        BaselineProcessedData.promotional_discount_config,
    )

    # Assert: discount_perc is labelled DISCOUNT, while the other two metrics are labelled NON_CLUSTER.
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "discount_perc", 16.66667, "DISCOUNT"),
            (date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "non_cluster_discount_perc", 10.0, "NON_CLUSTER"),
            (date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "num_brands", 1.0, "NON_CLUSTER"),
        ],
        schema=PromotionalDiscountProcessedData.promotional_discount_unpivoted_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_format_promotional_discount_output_adds_final_metadata_columns(
    spark_session: SparkSession,
):
    # Arrange unpivoted promotional discount rows before final output formatting.
    promotional_discount_processed_data_df = spark_session.createDataFrame(
        [(date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "discount_perc", 16.66667, "DISCOUNT")],
        schema=PromotionalDiscountProcessedData.promotional_discount_unpivoted_schema,
    )

    # Act: the formatter should rename fields and append pipeline metadata columns.
    actual_df = _format_promotional_discount_output(
        promotional_discount_processed_data_df,
        BaselineProcessedData.promotional_discount_config,
        "corr-format",
    )

    # Assert: stable fields match expectations and runtime timestamps are populated.
    expected_df = spark_session.createDataFrame(
        [(date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "DISCOUNT", "TOTAL", "discount_perc", 16.66667, "corr-format")],
        schema=ProcessedData.promotional_discount_output_no_load_ts_schema,
    )

    assert_spark_df_equal(
        actual_df.select(*ProcessedData.promotional_discount_output_no_load_ts_schema.fieldNames()),
        expected_df,
    )
    assert_non_null_columns(actual_df, ["load_ts"])


def test_promotional_discount_writes_expected_output(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange parquet inputs with mapped cluster sales, one non-cluster brand and one irrelevant sub-category.
    processed_sales_transaction_item_path = str(tmp_path / "processed_sales_transaction_item")
    item_brand_hist_path = str(tmp_path / "item_brand_hist")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            processed_sales_transaction_item_path,
            item_brand_hist_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [
                ("tx-1", datetime(2024, 1, 2, 10, 0, 0), 80.0, 100.0, "item-1", "Sale", "EA", 1.0),
                ("tx-2", datetime(2024, 1, 2, 11, 0, 0), 45.0, 50.0, "item-2", "Sale", "EA", 1.0),
                ("tx-3", datetime(2024, 1, 3, 12, 0, 0), 90.0, 100.0, "item-3", "Sale", "EA", 1.0),
                ("tx-4", datetime(2024, 1, 3, 13, 0, 0), 30.0, 35.0, "item-4", "Sale", "EA", 1.0),
            ],
            [
                ("item-1", "SUBA", "CATA", "BRANDA"),
                ("item-2", "SUBA", "CATA", "BRANDA"),
                ("item-3", "SUBA", "CATA", "BRANDB"),
                ("item-4", "SUBB", "CATB", "BRANDC"),
            ],
            [
                ("item-1", "CATA", "SUBA", "BRANDA", "CL1"),
                ("item-2", "CATA", "SUBA", "BRANDA", "CL1"),
            ],
            [
                (date(2024, 1, 1),),
                (date(2024, 1, 8),),
            ],
        ],
        schemas=[
            PromotionalDiscountProcessedData.promotional_discount_transaction_sale_return_schema,
            PromotionalDiscountProcessedData.promotional_discount_item_brand_hist_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    # Act: patch the safe writer so the test still performs a normal local parquet write.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.promotional_discount_processed_data.spark_s3_overwrite",
        side_effect=lambda path, df: df.write.mode("overwrite").parquet(path),
    ):
        prepare_promotional_discount_processed_data(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            item_brand_hist_path=item_brand_hist_path,
            processed_sales_transaction_item_path=processed_sales_transaction_item_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            output_path=output_path,
            correlation_id="corr-123",
        )

    # Assert: the pipeline writes expected metrics for the observed week and zero-fills the missing week.
    actual_df = spark_session.read.parquet(output_path).select(*ProcessedData.promotional_discount_output_no_load_ts_schema.fieldNames())
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "DISCOUNT", "TOTAL", "discount_perc", 16.66667, "corr-123"),
            (date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "NON_CLUSTER", "TOTAL", "non_cluster_discount_perc", 10.0, "corr-123"),
            (date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "NON_CLUSTER", "TOTAL", "num_brands", 1.0, "corr-123"),
            (date(2024, 1, 8), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "DISCOUNT", "TOTAL", "discount_perc", 0.0, "corr-123"),
            (date(2024, 1, 8), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "NON_CLUSTER", "TOTAL", "non_cluster_discount_perc", 0.0, "corr-123"),
            (date(2024, 1, 8), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "NON_CLUSTER", "TOTAL", "num_brands", 0.0, "corr-123"),
        ],
        schema=ProcessedData.promotional_discount_output_no_load_ts_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)
    assert_non_null_columns(spark_session.read.parquet(output_path), ["load_ts"])


def test_promotional_discount_zero_metrics_when_no_transactions(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange inputs where all transactions are filtered out before aggregation, but the cluster skeleton still exists.
    processed_sales_transaction_item_path = str(tmp_path / "processed_sales_transaction_item")
    item_brand_hist_path = str(tmp_path / "item_brand_hist")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    weekly_dates_path = str(tmp_path / "weekly_dates")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            processed_sales_transaction_item_path,
            item_brand_hist_path,
            sku_cluster_mapping_path,
            weekly_dates_path,
        ],
        rows_list=[
            [
                ("tx-1", datetime(2024, 1, 2, 10, 0, 0), 50.0, 60.0, "item-9", "Sale", "EA", 1.0),
            ],
            [
                ("item-9", "SubX", "CatX", "BrandX"),
            ],
            [
                ("item-1", "CATA", "SUBA", "BRANDA", "CL1"),
            ],
            [
                (date(2024, 1, 1),),
            ],
        ],
        schemas=[
            PromotionalDiscountProcessedData.promotional_discount_transaction_sale_return_schema,
            PromotionalDiscountProcessedData.promotional_discount_item_brand_hist_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.weekly_dates_schema,
        ],
    )

    # patch the writer so the unit test can validate a local parquet output.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.promotional_discount_processed_data.spark_s3_overwrite",
        side_effect=lambda path, df: df.write.mode("overwrite").parquet(path),
    ):
        prepare_promotional_discount_processed_data(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            item_brand_hist_path=item_brand_hist_path,
            processed_sales_transaction_item_path=processed_sales_transaction_item_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            output_path=output_path,
            correlation_id="corr-empty",
        )

    # Assert: no matching transactions still yields zero-valued rows for every cluster/week/metric in the skeleton.
    actual_df = spark_session.read.parquet(output_path).select(*ProcessedData.promotional_discount_output_no_load_ts_schema.fieldNames())
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "DISCOUNT", "TOTAL", "discount_perc", 0.0, "corr-empty"),
            (date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "NON_CLUSTER", "TOTAL", "non_cluster_discount_perc", 0.0, "corr-empty"),
            (date(2024, 1, 1), "CATA", "BRANDA", "CL1", "PROMOTIONAL DISCOUNT", "NON_CLUSTER", "TOTAL", "num_brands", 0.0, "corr-empty"),
        ],
        schema=ProcessedData.promotional_discount_output_no_load_ts_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)
    assert_non_null_columns(spark_session.read.parquet(output_path), ["load_ts"])
