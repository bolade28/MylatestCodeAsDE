from datetime import date
from decimal import Decimal
from unittest import mock

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed import (
    entrypoint,
    prepare_coupon_at_till_processed,
)
from spark_pipeline.common.variables import CouponAtTillConfig
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.coupon_at_till_processed import CouponAtTillProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_spark_df_equal,
    local_spark_s3_overwrite,
    read_parquet_columns,
    write_pipeline_inputs_to_parquet,
)


def test_prepare_coupon_at_till_processed_writes_expected_zero_filled_weekly_output(spark_session: SparkSession, tmp_path):
    # Arrange one valid coupon-at-till campaign week plus one extra weekly skeleton row.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    temp_unified_product_path = str(tmp_path / "temp_unified_product")
    base_finance_assets_path = str(tmp_path / "base_finance_assets")
    coupon_path = str(tmp_path / "coupon")
    coupon_cell_path = str(tmp_path / "coupon_cell")
    cell_path = str(tmp_path / "cell")
    campaign_path = str(tmp_path / "campaign")
    coupon_to_product_path = str(tmp_path / "coupon_to_product")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            sku_cluster_mapping_path,
            temp_unified_product_path,
            base_finance_assets_path,
            coupon_path,
            coupon_cell_path,
            cell_path,
            campaign_path,
            coupon_to_product_path,
        ],
        rows_list=[
            [(date(2024, 1, 1),), (date(2024, 1, 8),)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [("prod-1", "sku-1")],
            [(date(2024, 1, 1), date(2024, 1, 7), "COUPON AT TILL", "SAINSBURYS", "JB-1", 2, "Campaign completed", Decimal("70.00"), "asset-123456")],
            [("coupon-1", date(2024, 1, 1), date(2024, 1, 7), Decimal("35.00"))],
            [("cell-1", "coupon-1")],
            [("123456", "cell-1")],
            [("123456", "pre", "post")],
            [("coupon-1", "prod-1", "Y", "Y")],
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.temp_unified_product_input_schema,
            CouponAtTillProcessedData.base_finance_assets_input_schema,
            CouponAtTillProcessedData.coupon_schema,
            CouponAtTillProcessedData.coupon_cell_schema,
            CouponAtTillProcessedData.cell_schema,
            CouponAtTillProcessedData.campaign_schema,
            CouponAtTillProcessedData.coupon_to_product_schema,
        ],
    )

    # Act: patch the safe writer so the test performs a normal local parquet write.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_coupon_at_till_processed(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            temp_unified_product_path=temp_unified_product_path,
            base_finance_assets_path=base_finance_assets_path,
            coupon_path=coupon_path,
            coupon_cell_path=coupon_cell_path,
            cell_path=cell_path,
            campaign_path=campaign_path,
            coupon_to_product_path=coupon_to_product_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            correlation_id="test-correlation-id",
        )

    # Assert: the populated week contains the aggregated metrics and the extra week is zero-filled.
    actual_df = read_parquet_columns(spark_session, output_path, ProcessedData.shared_date_output_decimal_38_2_schema.fieldNames())
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "base_value", Decimal("70.00"), "test-correlation-id"),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "coupon_value", Decimal("35.00"), "test-correlation-id"),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "base_value", Decimal("0.00"), "test-correlation-id"),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "coupon_value", Decimal("0.00"), "test-correlation-id"),
        ],
        schema=ProcessedData.shared_date_output_decimal_38_2_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_coupon_at_till_empty_output_when_products_miss_brand_skus(spark_session: SparkSession, tmp_path):
    # Arrange one valid campaign whose coupon product never maps into the SKU cluster table.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    temp_unified_product_path = str(tmp_path / "temp_unified_product")
    base_finance_assets_path = str(tmp_path / "base_finance_assets")
    coupon_path = str(tmp_path / "coupon")
    coupon_cell_path = str(tmp_path / "coupon_cell")
    cell_path = str(tmp_path / "cell")
    campaign_path = str(tmp_path / "campaign")
    coupon_to_product_path = str(tmp_path / "coupon_to_product")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            sku_cluster_mapping_path,
            temp_unified_product_path,
            base_finance_assets_path,
            coupon_path,
            coupon_cell_path,
            cell_path,
            campaign_path,
            coupon_to_product_path,
        ],
        rows_list=[
            [(date(2024, 1, 1),)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [("prod-1", "sku-x")],  # Incorrect mapping for the product to sku join means this product won't map to the campaign's brand SKU and should be dropped from the output.
            [(date(2024, 1, 1), date(2024, 1, 7), "COUPON AT TILL", "COUPON AT TILL", "JB-1", 2, "Campaign completed", Decimal("70.00"), "asset-123456")],
            [("coupon-1", date(2024, 1, 1), date(2024, 1, 7), Decimal("35.00"))],
            [("cell-1", "coupon-1")],
            [("123456", "cell-1")],
            [("123456", "pre", "post")],
            [("coupon-1", "prod-1", "Y", "Y")],
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.temp_unified_product_input_schema,
            CouponAtTillProcessedData.base_finance_assets_input_schema,
            CouponAtTillProcessedData.coupon_schema,
            CouponAtTillProcessedData.coupon_cell_schema,
            CouponAtTillProcessedData.cell_schema,
            CouponAtTillProcessedData.campaign_schema,
            CouponAtTillProcessedData.coupon_to_product_schema,
        ],
    )

    # Act: with no mapped brand SKUs, the final coupon-at-till output should be empty.
    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_coupon_at_till_processed(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            temp_unified_product_path=temp_unified_product_path,
            base_finance_assets_path=base_finance_assets_path,
            coupon_path=coupon_path,
            coupon_cell_path=coupon_cell_path,
            cell_path=cell_path,
            campaign_path=campaign_path,
            coupon_to_product_path=coupon_to_product_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            correlation_id="corr-empty",
        )

    # Assert: no mapped coupon products means no cluster-level rows are written.
    expected_df = spark_session.createDataFrame([], schema=ProcessedData.shared_date_output_decimal_38_2_schema)
    assert_spark_df_equal(
        read_parquet_columns(spark_session, output_path, ProcessedData.shared_date_output_decimal_38_2_schema.fieldNames()),
        expected_df,
    )


def test_coupon_at_till_aggregates_campaigns_ignores_problem_rows(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange two valid campaigns in the same cluster/week plus several rows that should be filtered out.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    temp_unified_product_path = str(tmp_path / "temp_unified_product")
    base_finance_assets_path = str(tmp_path / "base_finance_assets")
    coupon_path = str(tmp_path / "coupon")
    coupon_cell_path = str(tmp_path / "coupon_cell")
    cell_path = str(tmp_path / "cell")
    campaign_path = str(tmp_path / "campaign")
    coupon_to_product_path = str(tmp_path / "coupon_to_product")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            sku_cluster_mapping_path,
            temp_unified_product_path,
            base_finance_assets_path,
            coupon_path,
            coupon_cell_path,
            cell_path,
            campaign_path,
            coupon_to_product_path,
        ],
        rows_list=[
            [
                (date(2024, 1, 1),),
                (date(2024, 1, 8),),
                (date(2024, 1, 15),),
            ],
            [
                ("sku-1", "CAT A", "SUB A", "BRAND A", "CL1"),
                ("sku-2", "CAT A", "SUB A", "BRAND A", "CL1"),
            ],
            [
                ("prod-1", "sku-1"),
                ("prod-2", "sku-2"),
                ("prod-x", "sku-x"),  # Unmapped SKU -> would be dropped if campaign were otherwise valid
            ],
            [
                (date(2024, 1, 1), date(2024, 1, 7), "COUPON AT TILL", "SAINSBURYS", "JB-1", 2, "Campaign completed", Decimal("70.00"), "asset-123456"),
                (date(2024, 1, 1), date(2024, 1, 7), "COUPON AT TILL", "SAINSBURYS", "JB-2", 2, "Campaign completed", Decimal("28.00"), "asset-654321"),
                (date(2024, 1, 1), date(2024, 1, 7), "ECOUPON", "SAINSBURYS", "JB-BAD-SERVICE", 2, "Campaign completed", Decimal("90.00"), "asset-111111"),  # Wrong service_type -> filtered out
                (date(2024, 1, 1), date(2024, 1, 7), "COUPON AT TILL", "SAINSBURYS", "JB-ZERO", 2, "Campaign completed", Decimal("0.00"), "asset-222222"),  # Zero spend -> filtered out
                (date(2024, 1, 1), date(2024, 1, 7), "COUPON AT TILL", "SAINSBURYS", "JB-OLD", 1, "Campaign completed", Decimal("999.00"), "asset-333333"),  # Older timeid -> filtered out by latest timeid join
            ],
            [
                ("coupon-1", date(2024, 1, 1), date(2024, 1, 7), Decimal("35.00")),
                ("coupon-2", date(2024, 1, 1), date(2024, 1, 7), Decimal("14.00")),
                ("coupon-3", date(2024, 1, 1), date(2024, 1, 7), Decimal("99.00")),
            ],
            [
                ("cell-1", "coupon-1"),
                ("cell-2", "coupon-2"),
                ("cell-3", "coupon-3"),
            ],
            [
                ("123456", "cell-1"),
                ("654321", "cell-2"),
                ("111111", "cell-3"),
            ],
            [
                ("123456", "pre", "post"),
                ("654321", "pre", "post"),
                ("111111", "pre", "post"),
            ],
            [
                ("coupon-1", "prod-1", "Y", "Y"),
                ("coupon-2", "prod-2", "Y", "Y"),
                ("coupon-3", "prod-x", "Y", "Y"),
            ],
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.temp_unified_product_input_schema,
            CouponAtTillProcessedData.base_finance_assets_input_schema,
            CouponAtTillProcessedData.coupon_schema,
            CouponAtTillProcessedData.coupon_cell_schema,
            CouponAtTillProcessedData.cell_schema,
            CouponAtTillProcessedData.campaign_schema,
            CouponAtTillProcessedData.coupon_to_product_schema,
        ],
    )

    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_coupon_at_till_processed(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            temp_unified_product_path=temp_unified_product_path,
            base_finance_assets_path=base_finance_assets_path,
            coupon_path=coupon_path,
            coupon_cell_path=coupon_cell_path,
            cell_path=cell_path,
            campaign_path=campaign_path,
            coupon_to_product_path=coupon_to_product_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            correlation_id="corr-multi-campaign",
        )

    actual_df = read_parquet_columns(spark_session, output_path, ProcessedData.shared_date_output_decimal_38_2_schema.fieldNames())
    expected_df = spark_session.createDataFrame(
        [
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "base_value", Decimal("98.00"), "corr-multi-campaign"),
            (date(2024, 1, 1), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "coupon_value", Decimal("49.00"), "corr-multi-campaign"),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "base_value", Decimal("0.00"), "corr-multi-campaign"),
            (date(2024, 1, 8), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "coupon_value", Decimal("0.00"), "corr-multi-campaign"),
            (date(2024, 1, 15), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "base_value", Decimal("0.00"), "corr-multi-campaign"),
            (date(2024, 1, 15), "CAT A", "BRAND A", "CL1", CouponAtTillConfig.MARKETING_TYPE, CouponAtTillConfig.MARKETING_CHANNEL, CouponAtTillConfig.MARKETING_SUB_CHANNEL, "coupon_value", Decimal("0.00"), "corr-multi-campaign"),
        ],
        schema=ProcessedData.shared_date_output_decimal_38_2_schema,
    )

    assert_spark_df_equal(actual_df, expected_df)


def test_coupon_at_till_empty_output_when_campaign_rows_fail_filters(
    spark_session: SparkSession,
    tmp_path,
):
    # Arrange structurally complete inputs where every base-finance row should be rejected before campaign creation.
    weekly_dates_path = str(tmp_path / "weekly_dates")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    temp_unified_product_path = str(tmp_path / "temp_unified_product")
    base_finance_assets_path = str(tmp_path / "base_finance_assets")
    coupon_path = str(tmp_path / "coupon")
    coupon_cell_path = str(tmp_path / "coupon_cell")
    cell_path = str(tmp_path / "cell")
    campaign_path = str(tmp_path / "campaign")
    coupon_to_product_path = str(tmp_path / "coupon_to_product")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            weekly_dates_path,
            sku_cluster_mapping_path,
            temp_unified_product_path,
            base_finance_assets_path,
            coupon_path,
            coupon_cell_path,
            cell_path,
            campaign_path,
            coupon_to_product_path,
        ],
        rows_list=[
            [(date(2024, 1, 1),), (date(2024, 1, 8),)],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [("prod-1", "sku-1")],
            [
                (date(2024, 1, 1), date(2024, 1, 7), "ECOUPON", "COUPON AT TILL", "JB-BAD-SERVICE", 2, "Campaign completed", Decimal("70.00"), "asset-123456"),  # Wrong service_type -> filtered out
                (date(2024, 1, 1), date(2024, 1, 7), "COUPON AT TILL", "COUPON AT TILL", None, 2, "Campaign completed", Decimal("70.00"), "asset-654321"),  # Null job bag -> filtered out
                (date(2024, 1, 1), date(2024, 1, 7), "COUPON AT TILL", "COUPON AT TILL", "JB-ZERO", 2, "Campaign completed", Decimal("0.00"), "asset-777777"),  # Non-positive spend -> filtered out
            ],
            [("coupon-1", date(2024, 1, 1), date(2024, 1, 7), Decimal("35.00"))],
            [("cell-1", "coupon-1")],
            [("123456", "cell-1")],
            [("123456", "pre", "post")],
            [("coupon-1", "prod-1", "Y", "Y")],
        ],
        schemas=[
            ProcessedData.weekly_dates_schema,
            ProcessedData.sku_cluster_mapping_schema,
            ProcessedData.temp_unified_product_input_schema,
            CouponAtTillProcessedData.base_finance_assets_input_schema,
            CouponAtTillProcessedData.coupon_schema,
            CouponAtTillProcessedData.coupon_cell_schema,
            CouponAtTillProcessedData.cell_schema,
            CouponAtTillProcessedData.campaign_schema,
            CouponAtTillProcessedData.coupon_to_product_schema,
        ],
    )

    with mock.patch(
        "spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed.spark_s3_overwrite",
        side_effect=local_spark_s3_overwrite,
    ):
        prepare_coupon_at_till_processed(
            spark=spark_session,
            weekly_dates_path=weekly_dates_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            temp_unified_product_path=temp_unified_product_path,
            base_finance_assets_path=base_finance_assets_path,
            coupon_path=coupon_path,
            coupon_cell_path=coupon_cell_path,
            cell_path=cell_path,
            campaign_path=campaign_path,
            coupon_to_product_path=coupon_to_product_path,
            start_date="2024-01-01",
            end_date="2024-01-31",
            output_path=output_path,
            correlation_id="corr-all-filtered",
        )

    expected_df = spark_session.createDataFrame([], schema=ProcessedData.shared_date_output_decimal_38_2_schema)
    assert_spark_df_equal(
        read_parquet_columns(spark_session, output_path, ProcessedData.shared_date_output_decimal_38_2_schema.fieldNames()),
        expected_df,
    )


def test_entrypoint_invokes_prepare_coupon_at_till_processed_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current coupon-at-till DTP entrypoint contract.
    args = [
        "--weekly-dates-path", "s3://input/weekly-dates",
        "--base-finance-assets-path", "s3://input/base-finance-assets",
        "--campaign-path", "s3://input/campaign",
        "--cell-path", "s3://input/cell",
        "--coupon-cell-path", "s3://input/coupon-cell",
        "--coupon-to-product-path", "s3://input/coupon-to-product",
        "--coupon-path", "s3://input/coupon",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--temp-unified-product-path", "s3://input/temp-unified-product",
        "--start-date", "2024-01-01",
        "--end-date", "2024-01-31",
        "--output-path", "s3://output/coupon-at-till",
        "--correlation-id", "corr-entrypoint",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.marketing_features.coupon_at_till_processed.prepare_coupon_at_till_processed") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        weekly_dates_path="s3://input/weekly-dates",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        temp_unified_product_path="s3://input/temp-unified-product",
        base_finance_assets_path="s3://input/base-finance-assets",
        coupon_path="s3://input/coupon",
        coupon_cell_path="s3://input/coupon-cell",
        cell_path="s3://input/cell",
        campaign_path="s3://input/campaign",
        coupon_to_product_path="s3://input/coupon-to-product",
        start_date="2024-01-01",
        end_date="2024-01-31",
        output_path="s3://output/coupon-at-till",
        correlation_id="corr-entrypoint",
    )
