from typing import Iterable, Sequence, Any

from chispa.dataframe_comparer import assert_df_equality
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F


def assert_spark_df_equal(actual_df: DataFrame, expected_df: DataFrame):
    assert_df_equality(
        actual_df,
        expected_df,
        ignore_nullable=True,
        ignore_row_order=True,
        ignore_column_order=False,
    )


def local_spark_s3_overwrite(path: str, df: DataFrame):
    """Test side effect stand-in for spark_s3_overwrite that performs a local parquet overwrite."""
    df.write.mode("overwrite").parquet(path)


def write_pipeline_inputs_to_parquet(
    spark_session: SparkSession,
    paths: Sequence[str],
    rows_list: Sequence[Iterable],
    schemas: Sequence[Any],
):
    """
    Write multiple parquet inputs for integration test setup.
    Each entry in `paths`, `rows_list`, and `schemas` must align by index.
    """
    if not (len(paths) == len(rows_list) == len(schemas)):
        raise ValueError("paths, rows_list, and schemas must have the same length")

    for path, rows, schema in zip(paths, rows_list, schemas):
        write_rows_to_parquet(spark_session, path, rows, schema)


def write_rows_to_parquet(
    spark_session: SparkSession,
    path: str,
    rows: Iterable,
    schema,
):
    """Create a Spark DataFrame from rows and persist it as parquet for test setup."""
    spark_session.createDataFrame(rows, schema=schema).write.mode("overwrite").parquet(path)


def assert_non_null_columns(df: DataFrame, columns: Sequence[str]):
    """Assert that the provided columns do not contain null values."""
    null_counts = df.select([
        F.sum(F.col(c).isNull().cast("int")).alias(c)
        for c in columns
    ]).collect()[0].asDict()

    columns_with_nulls = {col: count for col, count in null_counts.items() if count > 0}
    assert not columns_with_nulls, f"Null values found in columns: {columns_with_nulls}"


def round_columns(df: DataFrame, columns: Sequence[str], scale: int = 6) -> DataFrame:
    """Round selected numeric columns to make floating-point comparisons deterministic in tests."""
    for column_name in columns:
        df = df.withColumn(column_name, F.round(F.col(column_name), scale))
    return df


def drop_load_ts(df: DataFrame) -> DataFrame:
    """Drop runtime-generated load_ts columns when asserting stable dataframe content."""
    return df.drop("load_ts")


def read_parquet_columns(spark_session: SparkSession, path: str, columns: Sequence[str]) -> DataFrame:
    """
    Read a parquet dataset and project only the stable columns relevant to a test assertion.
    Makes it clear which schema is being used easier to read
    """
    return spark_session.read.parquet(path).select(*columns)
