from datetime import date, datetime
from decimal import Decimal
from unittest import mock

from pyspark.sql import SparkSession

from spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data_pollen import (
    entrypoint,
    prepare_dv360_processed_data,
)
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.baseline_processed_data.dv360_processed_data import DV360ProcessedData
from tests.unit.baseline_processed_data.utils import (
    assert_non_null_columns,
    assert_spark_df_equal,
    drop_load_ts,
    local_spark_s3_overwrite,
    write_pipeline_inputs_to_parquet,
)


# Note: scenarios are tested in the helper test file, so these tests focus on the end-to-end integration, rather than a broad number of scenarios
def test_dv360_pollen_merged_output_with_pollen_precedence(
        spark_session: SparkSession,
        tmp_path,
):
    # Arrange pollen inputs that produce one cluster-week plus one historic DTP-only metric.
    dv360_normalised_path = str(tmp_path / "dv360_normalised")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    dv360_media_report_path = str(tmp_path / "dv360_media_report")
    historic_dv360_processed_data_path = str(tmp_path / "historic_dv360_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            dv360_normalised_path,
            sku_cluster_mapping_path,
            dv360_media_report_path,
            historic_dv360_processed_data_path,
        ],
        rows_list=[
            [(date(2024, 1, 1), date(2024, 1, 2), "sku-1", "booking-1", "camp-1")],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [
                ("NA", "camp-1", date(2024, 1, 1), Decimal("90.00"), Decimal("80.00"), Decimal("10.00"), Decimal("100.00"), Decimal("50.00")),
                ("NA", "camp-1", date(2024, 1, 2), Decimal("110.00"), Decimal("100.00"), Decimal("20.00"), Decimal("200.00"), Decimal("60.00")),
            ],
            [
                (datetime(2024, 1, 8, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "IMPRESSIONS", 30.0, "historic-run"),
            ],
        ],
        schemas=[
            DV360ProcessedData.dv360_normalised_pollen_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            DV360ProcessedData.dv60_pollen_media_report_input_schema,
            ProcessedData.shared_timestamp_output_with_job_run_id_double_schema,
        ],
    )

    # patch the spark s3 writer so the test performs a normal local parquet write.
    with mock.patch(
            "spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data_pollen.spark_s3_overwrite",
            side_effect=local_spark_s3_overwrite,
    ):
        prepare_dv360_processed_data(
            spark=spark_session,
            dv360_normalised_path=dv360_normalised_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            dv360_media_report_path=dv360_media_report_path,
            historic_dv360_processed_data=historic_dv360_processed_data_path,
            output_path=output_path,
            correlation_id="corr-pollen",
        )

    # Assert: pollen metrics are written and unmatched historic DTP rows are retained after the merge.
    actual_df = spark_session.read.parquet(output_path)
    expected_df = spark_session.createDataFrame(
        [
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "IMPRESSIONS", Decimal("300.00000"), "NA", None),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "CLICKS", Decimal("30.00000"), "NA", None),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "MEASURABLE_IMPRESSIONS", Decimal("200.00000"), "NA", None),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "VIEWABLE_IMPRESSIONS", Decimal("180.00000"), "NA", None),
            (datetime(2024, 1, 1, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "CAMPAIGN_SPEND", Decimal("110.00000"), "NA", None),
            (datetime(2024, 1, 8, 0, 0, 0), "CAT A", "BRAND A", "CL1", "OFFSITE", "DV360", "TOTAL", "IMPRESSIONS", Decimal("30.00000"), "NA", None),
        ],
        schema=ProcessedData.shared_timestamp_output_with_load_ts_decimal_18_5_schema,
    )

    assert_spark_df_equal(drop_load_ts(actual_df), drop_load_ts(expected_df))
    assert_non_null_columns(actual_df, ["load_ts"])


def test_dv360_pollen_empty_output_without_brand_skus_or_history(
        spark_session: SparkSession,
        tmp_path,
):
    # Arrange inputs where the normalized pollen SKU does not map and the historic DTP dataset is empty.
    dv360_normalised_path = str(tmp_path / "dv360_normalised")
    sku_cluster_mapping_path = str(tmp_path / "sku_cluster_mapping")
    dv360_media_report_path = str(tmp_path / "dv360_media_report")
    historic_dv360_processed_data_path = str(tmp_path / "historic_dv360_processed_data")
    output_path = str(tmp_path / "output")

    write_pipeline_inputs_to_parquet(
        spark_session=spark_session,
        paths=[
            dv360_normalised_path,
            sku_cluster_mapping_path,
            dv360_media_report_path,
            historic_dv360_processed_data_path,
        ],
        rows_list=[
            [(date(2024, 1, 1), date(2024, 1, 2), "sku-x", "booking-1", "camp-1")],
            [("sku-1", "CAT A", "SUB A", "BRAND A", "CL1")],
            [("NA", "camp-1", date(2024, 1, 1), Decimal("90.00"), Decimal("80.00"), Decimal("10.00"), Decimal("100.00"), Decimal("50.00"))],
            [],
        ],
        schemas=[
            DV360ProcessedData.dv360_normalised_pollen_input_schema,
            ProcessedData.sku_cluster_mapping_schema,
            DV360ProcessedData.dv60_pollen_media_report_input_schema,
            ProcessedData.shared_timestamp_output_with_job_run_id_double_schema,
        ],
    )

    # With no required campaigns and no historic backfill, the final output should be empty.
    with mock.patch(
            "spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data_pollen.spark_s3_overwrite",
            side_effect=local_spark_s3_overwrite,
    ):
        prepare_dv360_processed_data(
            spark=spark_session,
            dv360_normalised_path=dv360_normalised_path,
            sku_cluster_mapping_path=sku_cluster_mapping_path,
            dv360_media_report_path=dv360_media_report_path,
            historic_dv360_processed_data=historic_dv360_processed_data_path,
            output_path=output_path,
            correlation_id="corr-empty",
        )

    # Assert: the merged output is empty but still readable from parquet.
    actual_df = spark_session.read.parquet(output_path)
    expected_df = spark_session.createDataFrame([], schema=ProcessedData.shared_timestamp_output_with_load_ts_decimal_18_5_schema)
    assert_spark_df_equal(actual_df, expected_df)


def test_entrypoint_invokes_prepare_dv360_processed_data_pollen_with_parsed_args(spark_session: SparkSession):
    # Arrange CLI-style arguments for the current DV360 pollen entrypoint contract.
    args = [
        "--dv360-normalised-path", "s3://input/dv360-normalised",
        "--sku-cluster-mapping-path", "s3://input/sku-clusters",
        "--dv360-media-report-path", "s3://input/dv360-report",
        "--historic-dv360-processed-data", "s3://input/historic-dv360",
        "--output-path", "s3://output/dv360",
        "--correlation-id", "corr-entrypoint",
    ]

    # Act: the entrypoint should parse arguments and forward them unchanged.
    with mock.patch("spark_pipeline.baseline_processed_data.marketing_features.dv360_processed_data_pollen.prepare_dv360_processed_data") as mock_prepare:
        entrypoint(spark_session, command_line_args=args)

    # Assert: the orchestration function is called once with the parsed arguments.
    mock_prepare.assert_called_once_with(
        spark=spark_session,
        dv360_normalised_path="s3://input/dv360-normalised",
        sku_cluster_mapping_path="s3://input/sku-clusters",
        dv360_media_report_path="s3://input/dv360-report",
        historic_dv360_processed_data="s3://input/historic-dv360",
        output_path="s3://output/dv360",
        correlation_id="corr-entrypoint",
    )
