from unittest.mock import Mock, patch

from spark_pipeline.metrics.publish_mta_validation import (
    publish_mta_validation_metrics,
    entrypoint,
)
_REPORTING_COLS = [
    "booking_id",
    "campaign_id",
    "journey_type",
    "marketing_type",
    "channel_name",
    "subchannel_name",
    "conversion_rate",
    "recalibration_factor",
    "roas_exposed",
    "media_spend_amt",
    "attributed_sales_amt",
    "attributed_recalibrated_sales_amt",
    "attributed_recalibrated_units_qty",
    "conversions_recalibrated",
    "incremental_sales_amt_exposed",
    "job_bag_number",
    "load_ts",
]


def test_publish_mta_validation_metrics_reads_correct_data(mock_spark, all_checks_patched):
    """
    Test that the orchestrator reads correct DataFrames and columns.

    Verifies that:
    - Parquet files are read from correct S3 paths
    - Correct columns are selected from measurement_campaign_reporting
    """
    spark, measurement_reporting_original, measurement_reporting_selected = mock_spark
    all_checks_patched.c1.return_value = 0
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-123",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    # Only verify data reading - not checks or messaging
    spark.read.parquet.assert_any_call("s3://bucket/attribution_model_results")
    spark.read.parquet.assert_any_call("s3://bucket/measurement_campaign_reporting")
    measurement_reporting_original.select.assert_called_once_with(*_REPORTING_COLS)


def test_publish_mta_validation_invokes_all_checks_with_correct_params(mock_spark, all_checks_patched):
    """
    Test that the orchestrator invokes all validation checks with correct parameters.

    Verifies that:
    - Check 1 is called with measurement_campaign_reporting_df
    - Check 7 is called with incremental_sales_iroas_df containing required columns
    """
    spark, measurement_reporting_original, measurement_reporting_selected = mock_spark
    all_checks_patched.c1.return_value = 0
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-123",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    # Only verify check invocations - not data reading or messaging
    all_checks_patched.c0.assert_called_once()
    c0_kwargs = all_checks_patched.c0.call_args[1]
    assert c0_kwargs["correlation_id"] == "corr-123"
    assert c0_kwargs["metrics_topic_arn"] == "arn:aws:sns:eu-west-1:123456789012:metrics-topic"
    assert c0_kwargs["spark"] is spark
    all_checks_patched.c1.assert_called_once_with(
        measurement_campaign_reporting_df=measurement_reporting_selected,
        correlation_id="corr-123",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    all_checks_patched.c7.assert_called_once()
    c7_call_kwargs = all_checks_patched.c7.call_args[1]
    assert "campaign_reporting_df" in c7_call_kwargs
    assert c7_call_kwargs["correlation_id"] == "corr-123"
    assert c7_call_kwargs["metrics_topic_arn"] == "arn:aws:sns:eu-west-1:123456789012:metrics-topic"


def test_publish_mta_validation_metrics_with_no_breaches(mock_spark, all_checks_patched):
    """
    Test that no-breach Slack message is sent when validation returns 0 breach groups.

    Verifies that:
    - Slack notification indicates no breaches when all checks pass
    """
    spark, measurement_reporting_original, measurement_reporting_selected = mock_spark
    all_checks_patched.c1.return_value = 0
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-123",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    # Only verify Slack messaging - not data reading or check invocations
    all_checks_patched.slack.return_value.send_message.assert_called_once()
    call_kwargs = all_checks_patched.slack.return_value.send_message.call_args[1]

    assert call_kwargs["event_type"] == "MTA Validation Metrics Status"
    assert call_kwargs["data"]["status"] == "Validation metrics published successfully - no breaches detected"
    assert call_kwargs["data"]["correlation_id"] == "corr-123"


def test_publish_mta_validation_metrics_with_breaches_detected(mock_spark, all_checks_patched):
    """
    Test that breach-detected Slack message is sent when validation returns breach groups.

    Verifies that the orchestrator:
    - Sends a breach alert Slack notification with breach count
    - Includes breach count in the notification data
    - Logs at all standard stages (no additional warning log)
    """
    spark, measurement_reporting_original, measurement_reporting_selected = mock_spark
    measurement_reporting_selected.cache.return_value = measurement_reporting_selected
    all_checks_patched.c1.return_value = 5
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-456",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    # Only verify Slack messaging - not check invocations or data reading
    slack_instance = all_checks_patched.slack.return_value
    slack_instance.send_message.assert_called_once()
    call_kwargs = slack_instance.send_message.call_args[1]

    assert call_kwargs["event_type"] == "MTA Validation Metrics Breach Detected"
    assert call_kwargs["data"]["status"] == "Validation threshold breaches or errors detected"
    assert call_kwargs["data"]["user_journey_validation_breaches"] == 0
    assert call_kwargs["data"]["conversion_rate_and_recalibration_factor_breaches"] == 5
    assert call_kwargs["data"]["correlation_id"] == "corr-456"


def test_publish_mta_validation_metrics_initialises_slack_messenger_correctly(all_checks_patched, mock_spark):
    """
    Test that SlackMessenger is initialised with correct parameters.

    Verifies that the orchestrator creates SlackMessenger with the correct
    topic ARN and correlation ID.
    """
    spark, measurement_reporting_original, measurement_reporting_selected = mock_spark
    all_checks_patched.c1.return_value = 0
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-789",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    all_checks_patched.slack.assert_called_once_with(
        topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
        correlation_id="corr-789",
    )

    # Verify Check 7 is called even when not the primary focus
    all_checks_patched.c7.assert_called_once()


def test_publish_mta_validation_metrics_logs_all_stages(all_checks_patched, mock_spark):
    """
    Test that the orchestrator logs at all key stages of execution.

    Verifies that logging occurs for:
    - Starting the validation
    - Reading attribution model results from S3
    - Reading measurement campaign reporting from S3
    - Running validation
    - Validation completion
    - Running Check 4 and Check 5
    """
    spark, measurement_reporting_original, measurement_reporting_selected = mock_spark
    all_checks_patched.c1.return_value = 2
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/path",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-log-test",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    info_calls = [call[0][0] for call in mock_logger_instance.info.call_args_list]
    assert any("Starting MTA validation metrics" in call for call in info_calls)
    assert any("Reading attribution model results from" in call for call in info_calls)
    assert any("Reading measurement campaign reporting from" in call for call in info_calls)
    assert any("Running Check 1: Conversion Rate and Recalibration Factor Validation" in call for call in info_calls)
    assert any("Check 1: Conversion Rate and Recalibration Factor Validation complete: breach_count=2" in call for call in info_calls)
    assert any("Check 0: User Journey Validation" in call for call in info_calls)
    assert any("Check 2: Normalized Weight Distribution" in call for call in info_calls)
    assert any("Check 3: Channel Sales Ratio Validation" in call for call in info_calls)
    assert any("Check 4: Media Spend Validation" in call for call in info_calls)
    assert any("Check 5: Channel Contribution Distribution" in call for call in info_calls)
    assert any("Check 6: ROAS Threshold Validation" in call for call in info_calls)
    assert any("Check 7: Incremental Sales and iROAS Validation" in call for call in info_calls)

    # Verify Check 7 is invoked
    all_checks_patched.c7.assert_called_once()


@patch("spark_pipeline.metrics.publish_mta_validation.publish_mta_validation_metrics")
def test_entrypoint_parses_arguments_correctly(mock_publish_mta_validation_metrics):
    """
    Test that entrypoint correctly parses command-line arguments.

    Verifies that all required arguments are parsed and passed to the
    publish_mta_validation_metrics function.
    """
    spark = Mock()
    args = [
        "--attribution-model-results-path",
        "s3://bucket/attribution_model_results",
        "--measurement-campaign-reporting-path",
        "s3://bucket/measurement_campaign_reporting",
        "--unified-campaign-path",
        "s3://bucket/unified_campaign",
        "--user-journey-brand-path",
        "s3://bucket/brand_journey",
        "--user-journey-offer-path",
        "s3://bucket/offer_journey",
        "--metrics-topic-arn",
        "arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        "--correlation-id",
        "corr-entrypoint-123",
        "--slack-topic-arn",
        "arn:aws:sns:eu-west-1:123456789012:slack-topic",
    ]

    entrypoint(spark=spark, command_line_args=args)

    mock_publish_mta_validation_metrics.assert_called_once_with(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-entrypoint-123",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )


def test_publish_mta_validation_metrics_reads_from_correct_s3_path(mock_spark, all_checks_patched):
    """
    Test that the orchestrator reads data from the correct S3 paths.

    Verifies that spark.read.parquet is called with the exact paths provided.
    """
    spark, measurement_reporting_original, measurement_reporting_selected = mock_spark
    all_checks_patched.c1.return_value = 0
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    attr_path = "s3://test-bucket/attribution_model_results"
    report_path = "s3://test-bucket/custom/path/to/data"
    unified_path = "s3://test-bucket/unified_campaign"
    brand_path = "s3://test-bucket/brand_journey"
    offer_path = "s3://test-bucket/offer_journey"
    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path=attr_path,
        measurement_campaign_reporting_path=report_path,
        unified_campaign_path=unified_path,
        brand_journey_path=brand_path,
        offer_journey_path=offer_path,
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-path-test",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    spark.read.parquet.assert_any_call(attr_path)
    spark.read.parquet.assert_any_call(report_path)
    spark.read.parquet.assert_any_call(unified_path)
    spark.read.parquet.assert_any_call(brand_path)
    spark.read.parquet.assert_any_call(offer_path)


def test_check1_exception_is_caught_and_reported_via_slack(all_checks_patched, mock_spark):
    """
    Test that a Check 1 (conversion rate validation) exception is caught and surfaced via Slack.

    Verifies that:
    - The pipeline does not halt when Check 1 raises
    - Other checks still run
    - A Slack error notification is sent
    """
    spark, _, _ = mock_spark
    all_checks_patched.c1.side_effect = RuntimeError("check1 boom")
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-check1-err",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    all_checks_patched.c2.assert_called_once()
    slack_instance = all_checks_patched.slack.return_value
    slack_instance.send_message.assert_called_once()
    call_kwargs = slack_instance.send_message.call_args[1]

    assert call_kwargs["event_type"] == "MTA Validation Metrics Breach Detected"
    assert any("check1 boom" in e for e in call_kwargs["data"]["errors"])


def test_check4_exception_is_caught_and_reported_via_slack(all_checks_patched, mock_spark):
    """
    Test that a Check 4 (media_spend_check) exception is caught and surfaced via Slack.

    Verifies that:
    - The pipeline does not halt when Check 4 raises
    - Other checks still run
    - A Slack error notification is sent
    """
    spark, _, _ = mock_spark
    all_checks_patched.c1.return_value = 0
    all_checks_patched.c4.side_effect = RuntimeError("check4 boom")
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-check4-err",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    all_checks_patched.c5.assert_called_once()
    slack_instance = all_checks_patched.slack.return_value
    slack_instance.send_message.assert_called_once()
    call_kwargs = slack_instance.send_message.call_args[1]

    assert call_kwargs["event_type"] == "MTA Validation Metrics Breach Detected"
    assert any("check4 boom" in e for e in call_kwargs["data"]["errors"])


def test_check5_exception_is_caught_and_reported_via_slack(
    all_checks_patched,
    mock_spark,
):
    """
    Test that a Check 5 exception is caught and surfaced via Slack.

    Verifies that:
    - The pipeline does not halt when Check 5 raises
    - Other checks still run
    - A Slack error notification is sent
    """
    spark, _, _ = mock_spark
    all_checks_patched.c1.return_value = 0
    all_checks_patched.c5.side_effect = RuntimeError("check5 boom")
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-check5-err",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    all_checks_patched.c4.assert_called_once()
    all_checks_patched.c1.assert_called_once()
    slack_instance = all_checks_patched.slack.return_value
    slack_instance.send_message.assert_called_once()
    call_kwargs = slack_instance.send_message.call_args[1]

    assert call_kwargs["event_type"] == "MTA Validation Metrics Breach Detected"
    assert any("check5 boom" in e for e in call_kwargs["data"]["errors"])


def test_check6_exception_is_caught_and_reported_via_slack(all_checks_patched, mock_spark):
    """
    Test that a Check 6 (ROAS thresholds) exception is caught and surfaced via Slack.

    Verifies that:
    - The pipeline does not halt when Check 6 raises
    - Other checks still run
    - A Slack error notification is sent
    """
    spark, _, _ = mock_spark
    all_checks_patched.c1.return_value = 0
    all_checks_patched.c6.side_effect = RuntimeError("check6 boom")
    mock_logger_instance = Mock()
    all_checks_patched.logger.return_value = mock_logger_instance

    publish_mta_validation_metrics(
        spark=spark,
        attribution_model_results_path="s3://bucket/attribution_model_results",
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        unified_campaign_path="s3://bucket/unified_campaign",
        brand_journey_path="s3://bucket/brand_journey",
        offer_journey_path="s3://bucket/offer_journey",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-check6-err",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
    )

    slack_instance = all_checks_patched.slack.return_value
    slack_instance.send_message.assert_called_once()
    call_kwargs = slack_instance.send_message.call_args[1]

    assert call_kwargs["event_type"] == "MTA Validation Metrics Breach Detected"
    assert any("check6 boom" in e for e in call_kwargs["data"]["errors"])
