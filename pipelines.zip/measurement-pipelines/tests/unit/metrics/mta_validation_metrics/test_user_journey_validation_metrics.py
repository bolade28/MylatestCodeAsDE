import json
import pytest

from chispa.dataframe_comparer import assert_df_equality
from pyspark.sql import types as T, functions as F
from spark_pipeline.metrics.mta_validation_metrics.user_journey_validation_metrics import (
    check_brand_vs_offer_sales,
    check_channel_cooccurrence,
    check_channel_conversion_ratio,
    check_channel_sales,
    check_duplicate_journeys,
    check_input_output_sales_match,
    check_invalid_touchpoint_names,
    check_multi_touchpoint_journeys,
    check_num_converted_journeys,
    check_subchannel_consistency_across_sources,
    get_journey_sales_comparison,
    get_journey_skus,
    user_journey_validation_metric,
)
from spark_pipeline.schemas.mta_validation_metrics import MTAValidationMetrics

CORRELATION_ID = "test-correlation-id"
BOOKING_ID = "booking-001"

USER_JOURNEY_INPUT_SCHEMA = MTAValidationMetrics.user_journey_input_schema
OUTPUT_SCHEMA = MTAValidationMetrics.user_journey_validation_schema

UNIFIED_CAMPAIGN_SCHEMA = T.StructType([
    T.StructField("job_bag_number", T.StringType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("item_cd_list", T.StringType(), True),
])

UNIFIED_CAMPAIGN_FULL_SCHEMA = T.StructType([
    T.StructField("job_bag_number", T.StringType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("item_cd_list", T.StringType(), True),
])

REPORTING_SCHEMA = T.StructType([
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("journey_type", T.StringType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("attributed_sales_amt", T.DoubleType(), True),
])


def _row(**kwargs):
    """Return a dict with all USER_JOURNEY_INPUT_SCHEMA fields set to sensible defaults."""
    defaults = dict(
        loyalty_id="loyalty-1",
        booking_id=BOOKING_ID,
        channel_name="channel-a",
        subchannel_name="sub-a",
        event_name="event-a",
        userjourney_id="journey-1",
        transaction_key="tx-1",
        event_ts="2024-01-01",
        campaign_id="camp-1",
        isconversion=0,
        campaign_duration="During",
        job_run_id="job-1",
        marketing_type="OFFSITE",
        net_sales_amt=500.0,
        units_qty=1,
        journey_type="offer",
        purchase_type="online",
        item_cd="sku-1",
    )
    defaults.update(kwargs)
    return defaults


SORT_COLS = ["channel_name", "comment"]


def _empty(spark_session):
    """Return an empty DataFrame with the canonical output schema."""
    return spark_session.createDataFrame([], schema=OUTPUT_SCHEMA)


def _expected(spark_session, rows):
    """Return an expected output DataFrame from a list of output-schema dicts."""
    return spark_session.createDataFrame(rows, schema=OUTPUT_SCHEMA)


def _assert_equal(result, expected):
    """Compare two DataFrames, sorting by non-MapType columns to avoid ordering errors."""
    assert_df_equality(
        result.orderBy(SORT_COLS),
        expected.orderBy(SORT_COLS),
        ignore_row_order=False,
        ignore_nullable=True,
    )


def test_check_num_converted_journeys_returns_empty_when_above_threshold(spark_session):
    """Happy path: converted count exceeds threshold → no warning."""
    # Arrange
    rows = [_row(loyalty_id=f"l{i}", isconversion=1) for i in range(10)]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_num_converted_journeys(spark_session, BOOKING_ID, df, min_threshold=5)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_num_converted_journeys_warns_when_at_threshold(spark_session):
    """Boundary: converted count == threshold → warning emitted."""
    # Arrange
    rows = [_row(loyalty_id=f"l{i}", isconversion=1) for i in range(5)]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_num_converted_journeys(spark_session, BOOKING_ID, df, min_threshold=5)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "HIGH",
        "Number of converted journeys (5) is at or below min_threshold.",
        json.dumps({"min_threshold": "5"}, separators=(",", ":")),
        "check_num_converted_journeys",
        5.0,
    )])
    _assert_equal(result, expected)


def test_check_num_converted_journeys_warns_when_below_threshold(spark_session):
    """Negative: converted count < threshold → warning emitted."""
    # Arrange
    rows = [_row(loyalty_id="l1", isconversion=1), _row(loyalty_id="l2", isconversion=0)]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_num_converted_journeys(spark_session, BOOKING_ID, df, min_threshold=5)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "HIGH",
        "Number of converted journeys (1) is at or below min_threshold.",
        json.dumps({"min_threshold": "5"}, separators=(",", ":")),
        "check_num_converted_journeys",
        1.0,
    )])
    _assert_equal(result, expected)


def test_check_num_converted_journeys_deduplicates_loyalty_ids(spark_session):
    """Same loyalty_id appearing multiple times is counted once."""
    # Arrange – loyalty-1 appears twice with isconversion=1; effective count = 1
    rows = [
        _row(loyalty_id="loyalty-1", isconversion=1),
        _row(loyalty_id="loyalty-1", isconversion=1),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_num_converted_journeys(spark_session, BOOKING_ID, df, min_threshold=5)

    # Assert – deduplicated count is 1, which is below threshold of 5
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "HIGH",
        "Number of converted journeys (1) is at or below min_threshold.",
        json.dumps({"min_threshold": "5"}, separators=(",", ":")),
        "check_num_converted_journeys",
        1.0,
    )])
    _assert_equal(result, expected)


def test_check_num_converted_journeys_output_schema_matches_canonical(spark_session):
    """Output schema must always match user_journey_validation_schema."""
    # Arrange
    df = spark_session.createDataFrame([_row()], schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_num_converted_journeys(spark_session, BOOKING_ID, df, min_threshold=1000)

    # Assert – schema check only; row content depends on data
    assert result.schema == OUTPUT_SCHEMA


def test_check_channel_conversion_ratio_returns_empty_when_all_channels_within_bounds(spark_session):
    """Happy path: all channels satisfy ratio and count thresholds."""
    # Arrange – 200 converted, 200 non-converted → ratio = 1.0, within max=2.0
    rows = (
        [_row(loyalty_id=f"c{i}", isconversion=1, channel_name="ch-a") for i in range(200)]
        + [_row(loyalty_id=f"n{i}", isconversion=0, channel_name="ch-a") for i in range(200)]
    )
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_conversion_ratio(
        df, BOOKING_ID, min_ratio=0.001, max_ratio=2.0, min_converted=100, min_non_converted=100
    )

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_channel_conversion_ratio_warns_when_non_converted_count_below_minimum(spark_session):
    """Negative: channel has fewer non-converted journeys than min_non_converted."""
    # Arrange – 200 converted, only 10 non-converted; threshold is 100
    rows = (
        [_row(loyalty_id=f"c{i}", isconversion=1, channel_name="ch-a") for i in range(200)]
        + [_row(loyalty_id=f"n{i}", isconversion=0, channel_name="ch-a") for i in range(10)]
    )
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_conversion_ratio(
        df, BOOKING_ID, min_ratio=0.001, max_ratio=50.0, min_converted=100, min_non_converted=100
    )

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        "ch-a",
        "HIGH",
        "Non-converted journey count (10) is below minimum threshold of 100",
        json.dumps({"min_threshold": "100.0", "max_threshold": None}, separators=(",", ":")),
        "check_channel_conversion_ratio",
        10.0,
    )])
    _assert_equal(result, expected)


def test_check_channel_conversion_ratio_warns_when_ratio_below_minimum(spark_session):
    """Negative: conversion ratio is below min_ratio."""
    # Arrange – 100 converted, 200000 non-converted → ratio ≈ 0.0005, below min_ratio=0.001
    rows = (
        [_row(loyalty_id=f"c{i}", isconversion=1, channel_name="ch-a") for i in range(100)]
        + [_row(loyalty_id=f"n{i}", isconversion=0, channel_name="ch-a") for i in range(200_000)]
    )
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_conversion_ratio(
        df, BOOKING_ID, min_ratio=0.001, max_ratio=0.3, min_converted=100, min_non_converted=100
    )

    # Assert
    result_rows = result.collect()
    assert len(result_rows) == 1
    assert result_rows[0]["channel_name"] == "ch-a"
    assert "below minimum threshold of 0.001" in result_rows[0]["comment"]
    assert result_rows[0]["check_name"] == "check_channel_conversion_ratio"


def test_check_channel_conversion_ratio_warns_when_converted_count_below_minimum(spark_session):
    """Negative: channel has fewer converted journeys than min_converted."""
    # Arrange – only 10 converted, threshold is 100
    rows = (
        [_row(loyalty_id=f"c{i}", isconversion=1, channel_name="ch-a") for i in range(10)]
        + [_row(loyalty_id=f"n{i}", isconversion=0, channel_name="ch-a") for i in range(200)]
    )
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_conversion_ratio(
        df, BOOKING_ID, min_ratio=0.001, max_ratio=2.0, min_converted=100, min_non_converted=100
    )

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        "ch-a",
        "HIGH",
        "Converted journey count (10) is below minimum threshold of 100",
        json.dumps({"min_threshold": "100.0", "max_threshold": None}, separators=(",", ":")),
        "check_channel_conversion_ratio",
        10.0,
    )])
    _assert_equal(result, expected)


def test_check_channel_conversion_ratio_warns_when_ratio_above_maximum(spark_session):
    """Negative: conversion ratio exceeds max_ratio."""
    # Arrange – 200 converted, 100 non-converted → ratio = 2.0, max is 0.3
    rows = (
        [_row(loyalty_id=f"c{i}", isconversion=1, channel_name="ch-a") for i in range(200)]
        + [_row(loyalty_id=f"n{i}", isconversion=0, channel_name="ch-a") for i in range(100)]
    )
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_conversion_ratio(
        df, BOOKING_ID, min_ratio=0.001, max_ratio=0.3, min_converted=100, min_non_converted=100
    )

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        "ch-a",
        "HIGH",
        "Conversion ratio (2.0) is above maximum threshold of 0.3",
        json.dumps({"min_threshold": "0.001", "max_threshold": "0.3"}, separators=(",", ":")),
        "check_channel_conversion_ratio",
        2.0,
    )])
    _assert_equal(result, expected)


def test_check_channel_conversion_ratio_ignores_empty_channel_name(spark_session):
    """Touchpoints with empty channel_name are excluded from the check."""
    # Arrange – all rows have empty channel, so no channel appears in the pivot
    rows = [_row(loyalty_id=f"l{i}", channel_name="", isconversion=i % 2) for i in range(20)]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_conversion_ratio(
        df, BOOKING_ID, min_ratio=0.001, max_ratio=2.0, min_converted=5, min_non_converted=5
    )

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_multi_touchpoint_journeys_returns_empty_for_single_channel_campaign(spark_session):
    """Skipped check: only one active channel → always returns empty."""
    # Arrange
    rows = [_row(loyalty_id=f"l{i}", channel_name="ch-a") for i in range(5)]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_multi_touchpoint_journeys(spark_session, df, BOOKING_ID, min_multi_touchpoint_journeys=10)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_multi_touchpoint_journeys_returns_empty_when_threshold_met(spark_session):
    """Happy path: enough journeys contain 2+ channels → no warning."""
    # Arrange – 20 journeys, each touching 2 channels
    rows = []
    for i in range(20):
        rows.append(_row(loyalty_id=f"l{i}", userjourney_id=f"j{i}", channel_name="ch-a"))
        rows.append(_row(loyalty_id=f"l{i}", userjourney_id=f"j{i}", channel_name="ch-b"))
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_multi_touchpoint_journeys(spark_session, df, BOOKING_ID, min_multi_touchpoint_journeys=10)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_multi_touchpoint_journeys_warns_when_threshold_not_met(spark_session):
    """Negative: too few journeys span multiple channels."""
    # Arrange – 3 multi-touchpoint journeys + 7 single-channel; threshold is 10
    rows = []
    for i in range(3):
        rows.append(_row(loyalty_id=f"l{i}", userjourney_id=f"j{i}", channel_name="ch-a"))
        rows.append(_row(loyalty_id=f"l{i}", userjourney_id=f"j{i}", channel_name="ch-b"))
    for i in range(3, 10):
        rows.append(_row(loyalty_id=f"s{i}", userjourney_id=f"j{i}", channel_name="ch-a"))
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_multi_touchpoint_journeys(spark_session, df, BOOKING_ID, min_multi_touchpoint_journeys=10)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "MEDIUM",
        (
            "Only 3 journeys contain more than one channel as a touchpoint, "
            "which is below the minimum threshold of 10. "
            "The campaign has 2 active channels."
        ),
        json.dumps({"min_threshold": "10", "num_multi_touchpoint": "3", "num_active_channels": "2"}, separators=(",", ":")),
        "check_multi_touchpoint_journeys",
        3.0,
    )])
    _assert_equal(result, expected)


def test_check_duplicate_journeys_returns_empty_when_no_duplicates(spark_session):
    """Happy path: all rows are unique → no warning."""
    # Arrange
    rows = [_row(loyalty_id=f"l{i}", transaction_key=f"tx-{i}") for i in range(5)]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_duplicate_journeys(spark_session, df, BOOKING_ID)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_duplicate_journeys_warns_when_exact_duplicate_rows_exist(spark_session):
    """Negative: two identical rows → one summary warning row with duplicate_count=1."""
    # Arrange – same row repeated twice
    row = _row(loyalty_id="l1", transaction_key="tx-dup")
    df = spark_session.createDataFrame([row, row], schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_duplicate_journeys(spark_session, df, BOOKING_ID)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "HIGH",
        "Duplicate user journeys detected: 1 duplicate rows found.",
        json.dumps({"duplicate_count": "1"}, separators=(",", ":")),
        "check_duplicate_journeys",
        1.0,
    )])
    _assert_equal(result, expected)


def test_check_duplicate_journeys_does_not_flag_unique_rows(spark_session):
    """Only duplicate rows contribute to the count; unique rows do not."""
    # Arrange
    rows = [
        _row(loyalty_id="l1", transaction_key="tx-1"),
        _row(loyalty_id="l2", transaction_key="tx-2"),
        _row(loyalty_id="l3", transaction_key="tx-dup"),
        _row(loyalty_id="l3", transaction_key="tx-dup"),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_duplicate_journeys(spark_session, df, BOOKING_ID)

    # Assert – one summary row, count=1 (the one duplicated combination)
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "HIGH",
        "Duplicate user journeys detected: 1 duplicate rows found.",
        json.dumps({"duplicate_count": "1"}, separators=(",", ":")),
        "check_duplicate_journeys",
        1.0,
    )])
    _assert_equal(result, expected)


def test_check_channel_cooccurrence_returns_empty_when_no_journeys(spark_session):
    """Edge case: empty DataFrame → no warning."""
    # Arrange
    df = spark_session.createDataFrame([], schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_cooccurrence(spark_session, df, BOOKING_ID, threshold=0.9)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_channel_cooccurrence_returns_empty_when_below_threshold(spark_session):
    """Happy path: channel combo appears in 50% of journeys, threshold is 90% → no warning."""
    # Arrange – 5 journeys with ch-a+ch-b (50%), 5 with only ch-a
    rows = []
    for i in range(5):
        rows.append(_row(userjourney_id=f"j{i}", channel_name="ch-a"))
        rows.append(_row(userjourney_id=f"j{i}", channel_name="ch-b"))
    for i in range(5, 10):
        rows.append(_row(userjourney_id=f"j{i}", channel_name="ch-a"))
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_cooccurrence(spark_session, df, BOOKING_ID, threshold=0.9)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_channel_cooccurrence_warns_when_single_combo_dominates(spark_session):
    """Negative: ch-a+ch-b appears in 100% of journeys, threshold 90% → warning."""
    # Arrange – 10 journeys all with ch-a+ch-b
    rows = []
    for i in range(10):
        rows.append(_row(userjourney_id=f"j{i}", channel_name="ch-a"))
        rows.append(_row(userjourney_id=f"j{i}", channel_name="ch-b"))
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_cooccurrence(spark_session, df, BOOKING_ID, threshold=0.9)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "MEDIUM",
        (
            "Channel combination appears in more than 90% of journeys. "
            "Verify this is expected (e.g. full-store instore campaign)."
        ),
        json.dumps({"channel_combo": "[ch-a, ch-b]", "journey_count": "10", "journey_pct": "1.0"}, separators=(",", ":")),
        "check_channel_cooccurrence",
        1.0,
    )])
    _assert_equal(result, expected)


def test_check_invalid_touchpoint_names_returns_empty_when_all_names_valid(spark_session):
    """Happy path: touchpoint row with valid names → no warning."""
    # Arrange
    rows = [_row(channel_name="ch-a", subchannel_name="sub-a", event_name="touchpoint")]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_invalid_touchpoint_names(spark_session, df, BOOKING_ID)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_invalid_touchpoint_names_warns_on_null_channel_name(spark_session):
    """Negative: touchpoint row with null channel_name → one summary warning row."""
    # Arrange
    rows = [_row(channel_name=None, subchannel_name="sub-a", event_name="touchpoint")]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_invalid_touchpoint_names(spark_session, df, BOOKING_ID)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "HIGH",
        "Invalid touchpoint data detected: 1 rows with invalid channel_name, subchannel_name, or isconversion.",
        json.dumps({"invalid_count": "1"}, separators=(",", ":")),
        "check_invalid_touchpoint_names",
        1.0,
    )])
    _assert_equal(result, expected)


def test_check_invalid_touchpoint_names_warns_on_empty_subchannel(spark_session):
    """Negative: touchpoint row with empty subchannel_name → one summary warning row."""
    # Arrange
    rows = [_row(channel_name="ch-a", subchannel_name="", event_name="touchpoint")]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_invalid_touchpoint_names(spark_session, df, BOOKING_ID)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "HIGH",
        "Invalid touchpoint data detected: 1 rows with invalid channel_name, subchannel_name, or isconversion.",
        json.dumps({"invalid_count": "1"}, separators=(",", ":")),
        "check_invalid_touchpoint_names",
        1.0,
    )])
    _assert_equal(result, expected)


def test_check_invalid_touchpoint_names_warns_on_na_event_name_case_insensitive(spark_session):
    """Negative: touchpoint rows where channel_name or subchannel_name is 'NA' (mixed case) → one summary row."""
    # Arrange
    rows = [
        _row(loyalty_id="l1", userjourney_id="j1", channel_name="NA", subchannel_name="sub-a", event_name="touchpoint"),
        _row(loyalty_id="l2", userjourney_id="j2", channel_name="ch-b", subchannel_name="na", event_name="touchpoint"),
        _row(loyalty_id="l3", userjourney_id="j3", channel_name="Na", subchannel_name="sub-c", event_name="touchpoint"),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_invalid_touchpoint_names(spark_session, df, BOOKING_ID)

    # Assert – one summary row with count=3
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "HIGH",
        "Invalid touchpoint data detected: 3 rows with invalid channel_name, subchannel_name, or isconversion.",
        json.dumps({"invalid_count": "3"}, separators=(",", ":")),
        "check_invalid_touchpoint_names",
        3.0,
    )])
    _assert_equal(result, expected)
    _assert_equal(result, expected)


def test_check_invalid_touchpoint_names_ignores_transaction_rows(spark_session):
    """Transaction rows with null/empty/NA channel or subchannel are expected and must not trigger a warning."""
    # Arrange
    rows = [
        _row(channel_name=None, subchannel_name=None, event_name="transaction", isconversion=1),
        _row(channel_name="", subchannel_name="NA", event_name="transaction", isconversion=0),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_invalid_touchpoint_names(spark_session, df, BOOKING_ID)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_invalid_touchpoint_names_warns_on_invalid_isconversion(spark_session):
    """Negative: isconversion not in (0, 1) → one summary warning row."""
    # Arrange
    rows = [
        _row(loyalty_id="l1", userjourney_id="j1", channel_name="ch-a", subchannel_name="sub-a", event_name="touchpoint", isconversion=2),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_invalid_touchpoint_names(spark_session, df, BOOKING_ID)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID, None, "HIGH",
        "Invalid touchpoint data detected: 1 rows with invalid channel_name, subchannel_name, or isconversion.",
        json.dumps({"invalid_count": "1"}, separators=(',', ':')),
        "check_invalid_touchpoint_names", 1.0,
    )])
    _assert_equal(result, expected)


def test_check_channel_sales_returns_empty_when_all_channels_above_threshold(spark_session):
    """Happy path: channel total sales > threshold → no warning."""
    # Arrange
    rows = [_row(loyalty_id="l1", userjourney_id="j1", channel_name="ch-a", isconversion=1, net_sales_amt=500.0)]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_sales(spark_session, df, BOOKING_ID, low_sales_threshold=100.0)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_channel_sales_warns_when_sales_at_threshold(spark_session):
    """Boundary: total sales == threshold → warning emitted (inclusive <=)."""
    # Arrange
    rows = [_row(loyalty_id="l1", userjourney_id="j1", channel_name="ch-a", isconversion=1, net_sales_amt=100.0)]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_sales(spark_session, df, BOOKING_ID, low_sales_threshold=100.0)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        "ch-a",
        "HIGH",
        "Channel has zero or very low total sales (<= 100.0) across all converted user journeys. High severity data quality issue.",
        json.dumps({"total_sales": "100.0", "low_sales_threshold": "100.0"}, separators=(",", ":")),
        "check_channel_sales",
        100.0,
    )])
    _assert_equal(result, expected)


def test_check_channel_sales_warns_when_channel_has_zero_sales(spark_session):
    """Negative: zero converted sales → warning with total_sales=0.0."""
    # Arrange
    rows = [_row(loyalty_id="l1", userjourney_id="j1", channel_name="ch-zero", isconversion=1, net_sales_amt=0.0)]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_sales(spark_session, df, BOOKING_ID, low_sales_threshold=100.0)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        "ch-zero",
        "HIGH",
        "Channel has zero or very low total sales (<= 100.0) across all converted user journeys. High severity data quality issue.",
        json.dumps({"total_sales": "0.0", "low_sales_threshold": "100.0"}, separators=(",", ":")),
        "check_channel_sales",
        0.0,
    )])
    _assert_equal(result, expected)


def test_check_channel_sales_only_converted_journeys_contribute(spark_session):
    """Non-converted journeys must not inflate a channel's total sales."""
    # Arrange – tiny converted sales (10), huge non-converted sales (99999) for same channel
    rows = [
        _row(loyalty_id="l1", userjourney_id="j1", channel_name="ch-a", isconversion=1, net_sales_amt=10.0),
        _row(loyalty_id="l2", userjourney_id="j2", channel_name="ch-a", isconversion=0, net_sales_amt=99999.0),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)

    # Act
    result = check_channel_sales(spark_session, df, BOOKING_ID, low_sales_threshold=100.0)

    # Assert – only converted sales (10.0) counted, so threshold breached
    expected = _expected(spark_session, [(
        BOOKING_ID,
        "ch-a",
        "HIGH",
        "Channel has zero or very low total sales (<= 100.0) across all converted user journeys. High severity data quality issue.",
        json.dumps({"total_sales": "10.0", "low_sales_threshold": "100.0"}, separators=(",", ":")),
        "check_channel_sales",
        10.0,
    )])
    _assert_equal(result, expected)


@pytest.mark.parametrize("brand_values,offer_values,brand_total,offer_total", [
    ([], [], 0.0, 0.0),
    ([None], [None], 0.0, 0.0),
    ([100.0, 100.0], [200.004], 200.0, 200.004),
    ([10.0, 5.0], [10.0], 15.0, 10.0),
])
def test_get_journey_sales_comparison_preserves_campaign_totals(
    spark_session, brand_values, offer_values, brand_total, offer_total,
):
    """Campaign totals sum all rows, default missing values to zero and compare without rounding."""
    brand_df = spark_session.createDataFrame(
        [_row(net_sales_amt=value) for value in brand_values], schema=USER_JOURNEY_INPUT_SCHEMA,
    )
    offer_df = spark_session.createDataFrame(
        [_row(net_sales_amt=value) for value in offer_values], schema=USER_JOURNEY_INPUT_SCHEMA,
    )
    expected_df = spark_session.range(1).select(
        F.lit(brand_total).alias("brand_sales"), F.lit(offer_total).alias("offer_sales"),
        F.lit(offer_total > brand_total).alias("offer_exceeds_brand"),
        F.lit(offer_total == brand_total).alias("sales_equal"),
    )

    result = get_journey_sales_comparison(brand_df, offer_df)

    assert_df_equality(result, expected_df, ignore_nullable=True)


def test_get_journey_skus_scopes_and_normalizes_sets(spark_session):
    """SKU resolution excludes other bookings/channels and removes duplicates, blanks and whitespace."""
    journey_df = spark_session.createDataFrame(
        [_row(channel_name="brand-ch"), _row(channel_name="brand-ch")], schema=USER_JOURNEY_INPUT_SCHEMA,
    )
    unified_df = spark_session.createDataFrame([
        (BOOKING_ID, "brand-ch", " sku-1,\tsku-2\t,sku-1,, "),
        (BOOKING_ID, "brand-ch", None),
        (BOOKING_ID, "other-ch", "excluded-channel"),
        ("other-booking", "brand-ch", "excluded-booking"),
    ], schema=UNIFIED_CAMPAIGN_SCHEMA)
    expected_df = spark_session.range(2).select(
        F.element_at(F.array(F.lit("sku-1"), F.lit("sku-2")), F.col("id").cast("int") + 1).alias("sku"),
    )

    result = get_journey_skus(journey_df, unified_df, BOOKING_ID)

    assert_df_equality(result, expected_df, ignore_nullable=True, ignore_row_order=True)


def test_check_brand_vs_offer_sales_bounds_sorted_sku_samples(spark_session):
    """Equal sales with twelve differing SKUs report only the first ten sorted SKU samples."""
    brand_df = spark_session.createDataFrame(
        [_row(channel_name="brand-ch")], schema=USER_JOURNEY_INPUT_SCHEMA,
    )
    offer_df = spark_session.createDataFrame(
        [_row(channel_name="offer-ch")], schema=USER_JOURNEY_INPUT_SCHEMA,
    )
    brand_skus = [f"sku-{index:02d}" for index in reversed(range(12))]
    unified_df = spark_session.createDataFrame([
        (BOOKING_ID, "brand-ch", ",".join(brand_skus)),
        (BOOKING_ID, "offer-ch", ""),
    ], schema=UNIFIED_CAMPAIGN_SCHEMA)
    sample = sorted(brand_skus)[:10]
    expected = _expected(spark_session, [(
        BOOKING_ID, None, "HIGH",
        f"Brand sales equal offer sales (500.0) but the SKU sets differ. "
        f"Brand-only SKUs (sample): {sample}. Offer-only SKUs (sample): [].",
        json.dumps({"brand_sales": "500.0", "offer_sales": "500.0"}, separators=(",", ":")),
        "check_brand_vs_offer_sales", 500.0,
    )])

    result = check_brand_vs_offer_sales(spark_session, brand_df, offer_df, unified_df, BOOKING_ID)

    _assert_equal(result, expected)


def test_check_brand_vs_offer_sales_returns_empty_when_brand_exceeds_offer(spark_session):
    """Happy path: brand sales > offer sales → no warning."""
    # Arrange
    brand_df = spark_session.createDataFrame(
        [_row(journey_type="brand", net_sales_amt=1000.0, channel_name="brand-ch")], schema=USER_JOURNEY_INPUT_SCHEMA
    )
    offer_df = spark_session.createDataFrame(
        [_row(journey_type="offer", net_sales_amt=500.0, channel_name="offer-ch")], schema=USER_JOURNEY_INPUT_SCHEMA
    )
    unified_df = spark_session.createDataFrame([], schema=UNIFIED_CAMPAIGN_SCHEMA)

    # Act
    result = check_brand_vs_offer_sales(spark_session, brand_df, offer_df, unified_df, BOOKING_ID)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_brand_vs_offer_sales_returns_empty_when_equal_sales_same_skus(spark_session):
    """Equal sales with identical SKU sets → no warning."""
    # Arrange
    brand_df = spark_session.createDataFrame(
        [_row(journey_type="brand", net_sales_amt=500.0, channel_name="brand-ch")], schema=USER_JOURNEY_INPUT_SCHEMA
    )
    offer_df = spark_session.createDataFrame(
        [_row(journey_type="offer", net_sales_amt=500.0, channel_name="offer-ch")], schema=USER_JOURNEY_INPUT_SCHEMA
    )
    unified_df = spark_session.createDataFrame(
        [
            (BOOKING_ID, "brand-ch", "sku-1,sku-2"),
            (BOOKING_ID, "offer-ch", "sku-1,sku-2"),
        ],
        schema=UNIFIED_CAMPAIGN_SCHEMA,
    )

    # Act
    result = check_brand_vs_offer_sales(spark_session, brand_df, offer_df, unified_df, BOOKING_ID)

    # Assert
    _assert_equal(result, _empty(spark_session))


def test_check_brand_vs_offer_sales_warns_when_equal_sales_different_skus(spark_session):
    """Equal sales but differing SKU sets → warning with diverging SKUs in comment."""
    # Arrange
    brand_df = spark_session.createDataFrame(
        [_row(journey_type="brand", net_sales_amt=500.0, channel_name="brand-ch")], schema=USER_JOURNEY_INPUT_SCHEMA
    )
    offer_df = spark_session.createDataFrame(
        [_row(journey_type="offer", net_sales_amt=500.0, channel_name="offer-ch")], schema=USER_JOURNEY_INPUT_SCHEMA
    )
    unified_df = spark_session.createDataFrame(
        [
            (BOOKING_ID, "brand-ch", "sku-brand-only"),
            (BOOKING_ID, "offer-ch", "sku-offer-only"),
        ],
        schema=UNIFIED_CAMPAIGN_SCHEMA,
    )

    # Act
    result = check_brand_vs_offer_sales(spark_session, brand_df, offer_df, unified_df, BOOKING_ID)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "HIGH",
        (
            "Brand sales equal offer sales (500.0) but the SKU sets differ. "
            "Brand-only SKUs (sample): ['sku-brand-only']. "
            "Offer-only SKUs (sample): ['sku-offer-only']."
        ),
        json.dumps({"brand_sales": "500.0", "offer_sales": "500.0"}, separators=(",", ":")),
        "check_brand_vs_offer_sales",
        500.0,
    )])
    _assert_equal(result, expected)


def test_check_brand_vs_offer_sales_warns_when_offer_exceeds_brand(spark_session):
    """Offer sales > brand sales → warning."""
    # Arrange
    brand_df = spark_session.createDataFrame(
        [_row(journey_type="brand", net_sales_amt=500.0)], schema=USER_JOURNEY_INPUT_SCHEMA
    )
    offer_df = spark_session.createDataFrame(
        [_row(journey_type="offer", net_sales_amt=1000.0)], schema=USER_JOURNEY_INPUT_SCHEMA
    )
    unified_df = spark_session.createDataFrame([], schema=UNIFIED_CAMPAIGN_SCHEMA)

    # Act
    result = check_brand_vs_offer_sales(spark_session, brand_df, offer_df, unified_df, BOOKING_ID)

    # Assert
    expected = _expected(spark_session, [(
        BOOKING_ID,
        None,
        "HIGH",
        "Offer sales (1000.0) are higher than brand sales (500.0). Brand sales should always be greater than or equal to offer sales; this may indicate a data quality issue.",
        json.dumps({"brand_sales": "500.0", "offer_sales": "1000.0"}, separators=(",", ":")),
        "check_brand_vs_offer_sales",
        1000.0,
    )])
    _assert_equal(result, expected)


def test_user_journey_validation_metric_output_schema_always_matches_canonical(spark_session):
    """Schema of the unioned result must always equal user_journey_validation_schema."""
    # Arrange – minimal data that will trigger at least one warning
    rows = [_row(loyalty_id="l1", isconversion=1, transaction_key="tx-1", journey_type="brand")]
    brand_df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    offer_df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    unified_df = spark_session.createDataFrame([], schema=UNIFIED_CAMPAIGN_FULL_SCHEMA)
    reporting_df = spark_session.createDataFrame([], schema=REPORTING_SCHEMA)

    # Act
    result = user_journey_validation_metric(brand_df, offer_df, unified_df, spark_session, reporting_df)

    # Assert – schema check via an empty DataFrame comparison (schema mismatch raises)
    assert result.schema == OUTPUT_SCHEMA


def _reporting_row(**kwargs):
    defaults = dict(
        booking_id=BOOKING_ID,
        journey_type="brand",
        channel_name="channel-a",
        subchannel_name="sub-a",
        attributed_sales_amt=500.0,
    )
    defaults.update(kwargs)
    return defaults


def test_check_input_output_sales_match_happy_path_returns_empty(spark_session):
    """Sales are equal across input and output → no warning."""
    journey_rows = [
        _row(loyalty_id="l1", isconversion=1, net_sales_amt=200.0, journey_type="brand"),
        _row(loyalty_id="l2", isconversion=1, net_sales_amt=300.0, journey_type="brand"),
    ]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    reporting_df = spark_session.createDataFrame(
        [_reporting_row(attributed_sales_amt=500.0)], schema=REPORTING_SCHEMA,
    )

    result = check_input_output_sales_match(spark_session, journey_df, reporting_df, BOOKING_ID, "brand")

    _assert_equal(result, _empty(spark_session))


def test_check_input_output_sales_match_mismatch_raises_warning(spark_session):
    """Sales differ → warning with abs-diff as value and both totals in metadata."""
    journey_rows = [_row(loyalty_id="l1", isconversion=1, net_sales_amt=400.0, journey_type="brand")]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    reporting_df = spark_session.createDataFrame(
        [_reporting_row(attributed_sales_amt=600.0)], schema=REPORTING_SCHEMA,
    )

    result = check_input_output_sales_match(spark_session, journey_df, reporting_df, BOOKING_ID, "brand")

    expected = _expected(spark_session, [(
        BOOKING_ID, None, "HIGH",
        "Total converted sales mismatch for brand journeys: "
        "MTA input (net_sales_amt) = 400.0, MTA output (attributed_sales_amt) = 600.0.",
        json.dumps({"journey_type": "brand", "input_sales": "400.0", "output_sales": "600.0"}, separators=(",", ":")),
        "check_input_output_sales_match",
        200.0,
    )])
    _assert_equal(result, expected)


def test_check_input_output_sales_match_input_sales_zero_raises_warning(spark_session):
    """No converted journeys → input sales zero → warning."""
    journey_rows = [_row(loyalty_id="l1", isconversion=0, net_sales_amt=500.0, journey_type="brand")]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    reporting_df = spark_session.createDataFrame(
        [_reporting_row(attributed_sales_amt=500.0)], schema=REPORTING_SCHEMA,
    )

    result = check_input_output_sales_match(spark_session, journey_df, reporting_df, BOOKING_ID, "brand")

    expected = _expected(spark_session, [(
        BOOKING_ID, None, "HIGH",
        "MTA input total converted sales (net_sales_amt) is zero for brand journeys.",
        json.dumps({"journey_type": "brand", "input_sales": "0.0", "output_sales": "500.0"}, separators=(",", ":")),
        "check_input_output_sales_match",
        0.0,
    )])
    _assert_equal(result, expected)


def test_check_input_output_sales_match_output_sales_zero_raises_warning(spark_session):
    """No reporting rows for the journey type → output sales zero → warning."""
    journey_rows = [_row(loyalty_id="l1", isconversion=1, net_sales_amt=500.0, journey_type="brand")]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    reporting_df = spark_session.createDataFrame(
        [_reporting_row(journey_type="offer", attributed_sales_amt=500.0)], schema=REPORTING_SCHEMA,
    )

    result = check_input_output_sales_match(spark_session, journey_df, reporting_df, BOOKING_ID, "brand")

    expected = _expected(spark_session, [(
        BOOKING_ID, None, "HIGH",
        "MTA output total sales (attributed_sales_amt) is zero for brand journeys.",
        json.dumps({"journey_type": "brand", "input_sales": "500.0", "output_sales": "0.0"}, separators=(",", ":")),
        "check_input_output_sales_match",
        0.0,
    )])
    _assert_equal(result, expected)


def test_check_input_output_sales_match_non_converted_rows_excluded(spark_session):
    """Non-converted journeys must not inflate input_sales."""
    journey_rows = [
        _row(loyalty_id="l1", isconversion=1, net_sales_amt=300.0, journey_type="brand"),
        _row(loyalty_id="l2", isconversion=0, net_sales_amt=9000.0, journey_type="brand"),
    ]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    reporting_df = spark_session.createDataFrame(
        [_reporting_row(attributed_sales_amt=300.0)], schema=REPORTING_SCHEMA,
    )

    result = check_input_output_sales_match(spark_session, journey_df, reporting_df, BOOKING_ID, "brand")

    _assert_equal(result, _empty(spark_session))


def test_check_input_output_sales_match_journey_type_filter_applied(spark_session):
    """Only the matching journey_type rows in reporting are summed; other types ignored."""
    journey_rows = [_row(loyalty_id="l1", isconversion=1, net_sales_amt=100.0, journey_type="offer")]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    reporting_df = spark_session.createDataFrame(
        [
            _reporting_row(journey_type="offer", attributed_sales_amt=100.0),
            _reporting_row(journey_type="brand", attributed_sales_amt=999.0),
        ],
        schema=REPORTING_SCHEMA,
    )

    result = check_input_output_sales_match(spark_session, journey_df, reporting_df, BOOKING_ID, "offer")

    _assert_equal(result, _empty(spark_session))


TOUCHPOINT_EVENT = "touchpoint"


def _unified_full_row(**kwargs):
    defaults = dict(
        job_bag_number=BOOKING_ID,
        channel_name="channel-a",
        subchannel_name="sub-a",
        item_cd_list=None,
    )
    defaults.update(kwargs)
    return defaults


def _consistency_reporting_row(**kwargs):
    defaults = dict(
        booking_id=BOOKING_ID,
        journey_type="brand",
        channel_name="channel-a",
        subchannel_name="sub-a",
        attributed_sales_amt=0.0,
    )
    defaults.update(kwargs)
    return defaults


def test_check_subchannel_consistency_happy_path_returns_empty(spark_session):
    """All three sources agree on all subchannels per channel → no warning."""
    journey_rows = [
        _row(loyalty_id="l1", isconversion=1, channel_name="ch-a", subchannel_name="sub-a", event_name=TOUCHPOINT_EVENT),
    ]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    unified_df = spark_session.createDataFrame(
        [_unified_full_row(channel_name="ch-a", subchannel_name="sub-a")],
        schema=UNIFIED_CAMPAIGN_FULL_SCHEMA,
    )
    reporting_df = spark_session.createDataFrame(
        [_consistency_reporting_row(channel_name="ch-a", subchannel_name="sub-a")],
        schema=REPORTING_SCHEMA,
    )

    result = check_subchannel_consistency_across_sources(
        spark_session, journey_df, unified_df, reporting_df, BOOKING_ID
    )

    _assert_equal(result, _empty(spark_session))


def test_check_subchannel_consistency_booking_has_extra_subchannel_raises_warning(spark_session):
    """Booking has a subchannel absent from journeys and reporting → warning."""
    journey_rows = [
        _row(loyalty_id="l1", isconversion=1, channel_name="ch-a", subchannel_name="sub-a", event_name=TOUCHPOINT_EVENT),
    ]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    unified_df = spark_session.createDataFrame(
        [
            _unified_full_row(channel_name="ch-a", subchannel_name="sub-a"),
            _unified_full_row(channel_name="ch-a", subchannel_name="sub-b"),
        ],
        schema=UNIFIED_CAMPAIGN_FULL_SCHEMA,
    )
    reporting_df = spark_session.createDataFrame(
        [_consistency_reporting_row(channel_name="ch-a", subchannel_name="sub-a")],
        schema=REPORTING_SCHEMA,
    )

    result = check_subchannel_consistency_across_sources(
        spark_session, journey_df, unified_df, reporting_df, BOOKING_ID
    )

    expected = _expected(spark_session, [(
        BOOKING_ID, "ch-a", "HIGH",
        "Subchannel mismatch detected for channel (ch-a): subchannels do not match across booking, journeys, and reporting.",
        json.dumps({"booking_subchannels": ["sub-a", "sub-b"], "journey_subchannels": ["sub-a"], "reporting_subchannels": ["sub-a"]}, separators=(",", ":")),
        "check_subchannel_consistency_across_sources", 0.0,
    )])
    _assert_equal(result, expected)


def test_check_subchannel_consistency_journeys_has_extra_subchannel_raises_warning(spark_session):
    """Journeys contain a subchannel absent from booking and reporting → warning."""
    journey_rows = [
        _row(loyalty_id="l1", isconversion=1, channel_name="ch-a", subchannel_name="sub-a", event_name=TOUCHPOINT_EVENT),
        _row(loyalty_id="l2", isconversion=1, channel_name="ch-a", subchannel_name="sub-b", event_name=TOUCHPOINT_EVENT),
    ]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    unified_df = spark_session.createDataFrame(
        [_unified_full_row(channel_name="ch-a", subchannel_name="sub-a")],
        schema=UNIFIED_CAMPAIGN_FULL_SCHEMA,
    )
    reporting_df = spark_session.createDataFrame(
        [_consistency_reporting_row(channel_name="ch-a", subchannel_name="sub-a")],
        schema=REPORTING_SCHEMA,
    )

    result = check_subchannel_consistency_across_sources(
        spark_session, journey_df, unified_df, reporting_df, BOOKING_ID
    )

    expected = _expected(spark_session, [(
        BOOKING_ID, "ch-a", "HIGH",
        "Subchannel mismatch detected for channel (ch-a): subchannels do not match across booking, journeys, and reporting.",
        json.dumps({"booking_subchannels": ["sub-a"], "journey_subchannels": ["sub-a", "sub-b"], "reporting_subchannels": ["sub-a"]}, separators=(",", ":")),
        "check_subchannel_consistency_across_sources", 0.0,
    )])
    _assert_equal(result, expected)


def test_check_subchannel_consistency_reporting_has_extra_subchannel_raises_warning(spark_session):
    """Reporting contains a subchannel absent from booking and journeys → warning."""
    journey_rows = [
        _row(loyalty_id="l1", isconversion=1, channel_name="ch-a", subchannel_name="sub-a", event_name=TOUCHPOINT_EVENT),
    ]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    unified_df = spark_session.createDataFrame(
        [_unified_full_row(channel_name="ch-a", subchannel_name="sub-a")],
        schema=UNIFIED_CAMPAIGN_FULL_SCHEMA,
    )
    reporting_df = spark_session.createDataFrame(
        [
            _consistency_reporting_row(channel_name="ch-a", subchannel_name="sub-a"),
            _consistency_reporting_row(channel_name="ch-a", subchannel_name="sub-b"),
        ],
        schema=REPORTING_SCHEMA,
    )

    result = check_subchannel_consistency_across_sources(
        spark_session, journey_df, unified_df, reporting_df, BOOKING_ID
    )

    expected = _expected(spark_session, [(
        BOOKING_ID, "ch-a", "HIGH",
        "Subchannel mismatch detected for channel (ch-a): subchannels do not match across booking, journeys, and reporting.",
        json.dumps({"booking_subchannels": ["sub-a"], "journey_subchannels": ["sub-a"], "reporting_subchannels": ["sub-a", "sub-b"]}, separators=(",", ":")),
        "check_subchannel_consistency_across_sources", 0.0,
    )])
    _assert_equal(result, expected)


def test_check_subchannel_consistency_non_converted_journeys_excluded(spark_session):
    """Subchannels only in non-converted journeys are not counted as present in journeys."""
    journey_rows = [
        _row(loyalty_id="l1", isconversion=1, channel_name="ch-a", subchannel_name="sub-a", event_name=TOUCHPOINT_EVENT),
        _row(loyalty_id="l2", isconversion=0, channel_name="ch-a", subchannel_name="sub-b", event_name=TOUCHPOINT_EVENT),
    ]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    unified_df = spark_session.createDataFrame(
        [
            _unified_full_row(channel_name="ch-a", subchannel_name="sub-a"),
            _unified_full_row(channel_name="ch-a", subchannel_name="sub-b"),
        ],
        schema=UNIFIED_CAMPAIGN_FULL_SCHEMA,
    )
    reporting_df = spark_session.createDataFrame(
        [
            _consistency_reporting_row(channel_name="ch-a", subchannel_name="sub-a"),
            _consistency_reporting_row(channel_name="ch-a", subchannel_name="sub-b"),
        ],
        schema=REPORTING_SCHEMA,
    )

    result = check_subchannel_consistency_across_sources(
        spark_session, journey_df, unified_df, reporting_df, BOOKING_ID
    )

    expected = _expected(spark_session, [(
        BOOKING_ID, "ch-a", "HIGH",
        "Subchannel mismatch detected for channel (ch-a): subchannels do not match across booking, journeys, and reporting.",
        json.dumps({"booking_subchannels": ["sub-a", "sub-b"], "journey_subchannels": ["sub-a"], "reporting_subchannels": ["sub-a", "sub-b"]}, separators=(",", ":")),
        "check_subchannel_consistency_across_sources", 0.0,
    )])
    _assert_equal(result, expected)


def test_check_subchannel_consistency_booking_id_filter_applied(spark_session):
    """Rows in unified/reporting for other booking_ids are ignored."""
    journey_rows = [
        _row(loyalty_id="l1", isconversion=1, channel_name="ch-a", subchannel_name="sub-a", event_name=TOUCHPOINT_EVENT),
    ]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    unified_df = spark_session.createDataFrame(
        [
            _unified_full_row(channel_name="ch-a", subchannel_name="sub-a"),
            _unified_full_row(job_bag_number="other", channel_name="ch-a", subchannel_name="sub-z"),
        ],
        schema=UNIFIED_CAMPAIGN_FULL_SCHEMA,
    )
    reporting_df = spark_session.createDataFrame(
        [
            _consistency_reporting_row(channel_name="ch-a", subchannel_name="sub-a"),
            _consistency_reporting_row(booking_id="other", channel_name="ch-a", subchannel_name="sub-z"),
        ],
        schema=REPORTING_SCHEMA,
    )

    result = check_subchannel_consistency_across_sources(
        spark_session, journey_df, unified_df, reporting_df, BOOKING_ID
    )

    _assert_equal(result, _empty(spark_session))


def test_check_subchannel_consistency_only_mismatched_channels_flagged(spark_session):
    """Only channels with differing subchannel sets are flagged; matching channels are not."""
    journey_rows = [
        _row(loyalty_id="l1", isconversion=1, channel_name="ch-a", subchannel_name="sub-a", event_name=TOUCHPOINT_EVENT),
        _row(loyalty_id="l2", isconversion=1, channel_name="ch-b", subchannel_name="sub-b", event_name=TOUCHPOINT_EVENT),
    ]
    journey_df = spark_session.createDataFrame(journey_rows, schema=USER_JOURNEY_INPUT_SCHEMA)
    unified_df = spark_session.createDataFrame(
        [
            _unified_full_row(channel_name="ch-a", subchannel_name="sub-a"),
            _unified_full_row(channel_name="ch-b", subchannel_name="sub-b"),
            _unified_full_row(channel_name="ch-b", subchannel_name="sub-c"),
        ],
        schema=UNIFIED_CAMPAIGN_FULL_SCHEMA,
    )
    reporting_df = spark_session.createDataFrame(
        [
            _consistency_reporting_row(channel_name="ch-a", subchannel_name="sub-a"),
            _consistency_reporting_row(channel_name="ch-b", subchannel_name="sub-b"),
        ],
        schema=REPORTING_SCHEMA,
    )

    result = check_subchannel_consistency_across_sources(
        spark_session, journey_df, unified_df, reporting_df, BOOKING_ID
    )

    expected = _expected(spark_session, [(
        BOOKING_ID, "ch-b", "HIGH",
        "Subchannel mismatch detected for channel (ch-b): subchannels do not match across booking, journeys, and reporting.",
        json.dumps({"booking_subchannels": ["sub-b", "sub-c"], "journey_subchannels": ["sub-b"], "reporting_subchannels": ["sub-b"]}, separators=(",", ":")),
        "check_subchannel_consistency_across_sources", 0.0,
    )])
    _assert_equal(result, expected)
