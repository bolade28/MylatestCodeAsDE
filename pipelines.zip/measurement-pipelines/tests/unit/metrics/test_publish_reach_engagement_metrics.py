from unittest import mock
from unittest.mock import Mock

from spark_pipeline.metrics.reach_engagement_metrics import (
    publish_reach_engagement_detail_metrics,
)
from spark_pipeline.utils.mta_events import (
    ReachEngagementDetails,
)
from spark_pipeline.utils.pipeline_utils import make_unique_key


@mock.patch("spark_pipeline.metrics.reach_engagement_metrics.MetricsPublisher")
def test_publish_measurement_booking_reach_engagement_detail_metrics_success(
    mock_publisher_class,
):
    mock_publisher = Mock()
    mock_publisher_class.return_value = mock_publisher

    topic_arn = "arn:aws:sns:eu-west-1:123456789012:test-topic"
    correlation_id = "test-correlation-id"

    row = {
        "campaign_id": "cmp-1",
        "channel_name": "Meta",
        "subchannel_name": "Meta",
        "marketing_type": "Offsite",
        "booking_id": "book-1",
        "reach_cnt": 100.0,
        "dedup_campaign_reach": 95.0,
        "clicks_cnt": 20.0,
        "impressions_cnt": 1000.0,
        "sales_amt": 500.5,
        "conversions_cnt": 12.0,
        "media_spend_amt": 120.25,
        "engagement_ctr_pct": 2.0,
        "load_ts": "2026-01-01 00:00:00",
        "job_run_id": "job-run-1",
        "run_type": "Pollen",
        "dag_run_ts": "2026-01-02 00:00:00",
    }

    row_2 = {
        "campaign_id": "cmp-2",
        "channel_name": "DV360",
        "subchannel_name": "Display",
        "marketing_type": "Offsite",
        "booking_id": "book-2",
        "reach_cnt": 200.0,
        "dedup_campaign_reach": 180.0,
        "clicks_cnt": 40.0,
        "impressions_cnt": 2000.0,
        "sales_amt": 750.0,
        "conversions_cnt": 18.0,
        "media_spend_amt": 240.0,
        "engagement_ctr_pct": 3.0,
        "load_ts": "2026-01-01 00:00:00",
        "job_run_id": "job-run-1",
        "run_type": "Pollen",
        "dag_run_ts": "2026-01-02 00:00:00",
    }

    df = Mock()
    df.collect.return_value = [row, row_2]

    published = publish_reach_engagement_detail_metrics(
        reach_engagement_detail_df=df,
        metrics_topic_arn=topic_arn,
        correlation_id=correlation_id,
    )

    assert published == 2
    mock_publisher_class.assert_called_once_with(topic_arn=topic_arn)
    assert mock_publisher.publish_event.call_count == 2

    call_1 = mock_publisher.publish_event.call_args_list[0]
    assert call_1[1]["message_subject"] == "Campaign Metrics Event"
    assert isinstance(call_1[1]["event"], ReachEngagementDetails)
    assert call_1[1]["event"].name == f"REACH_DETAILS|{make_unique_key(campaign_id='cmp-1', subchannel_name='Meta', booking_id='book-1')}"
    assert call_1[1]["event"].correlation_id == "job-run-1"

    call_2 = mock_publisher.publish_event.call_args_list[1]
    assert isinstance(call_2[1]["event"], ReachEngagementDetails)
    assert call_2[1]["event"].name == f"REACH_DETAILS|{make_unique_key(campaign_id='cmp-2', subchannel_name='Display', booking_id='book-2')}"
    assert call_2[1]["event"].correlation_id == "job-run-1"

    # Assert each row produces a distinct name — the core fix for the upsert collision bug
    names = [mock_publisher.publish_event.call_args_list[i][1]["event"].name for i in range(2)]
    assert len(set(names)) == 2
