from unittest.mock import Mock, patch

import pytest
from pyspark.sql import Row, SparkSession
from pyspark.sql import types as T

from spark_pipeline.common.throwing_argument_parser import ArgumentParserError
from spark_pipeline.metrics.publish_pipeline_summary import (
    entrypoint,
    publish_pipeline_summary,
)

CORRELATION_ID = "test-correlation-id-123"
METRICS_ARN = "arn:aws:sns:eu-west-1:123456789012:metrics-topic"
SLACK_ARN = "arn:aws:sns:eu-west-1:123456789012:slack-topic"

_SUMMARY_SCHEMA = T.StructType([
    T.StructField("correlation_id", T.StringType(), True),
    T.StructField("name", T.StringType(), True),
    T.StructField("data_group", T.StringType(), True),
    T.StructField("data_sources", T.StringType(), True),
    T.StructField("severity", T.StringType(), True),
    T.StructField("metadata", T.StringType(), True),
    T.StructField("load_timestamp", T.StringType(), True),
])

_PATHS = dict(
    baseline_modelling_dataset_path="s3://bucket/baseline_modelling_dataset",
    feature_prioritisation_path="s3://bucket/feature_prioritisation",
    incremental_shrinkage_path="s3://bucket/incremental_shrinkage",
    calibration_audit_path="s3://bucket/calibration_audit",
    ucm_output_data_path="s3://bucket/ucm_output_data",
    ucm_base_data_path="s3://bucket/ucm_base_data",
    user_journey_offer_path="s3://bucket/user_journey_offer",
    user_journey_brand_path="s3://bucket/user_journey_brand",
    attribution_model_results_path="s3://bucket/attribution_model_results",
    sku_level_attributed_sales_offer_path="s3://bucket/sku_level_attributed_sales_offer",
    sku_level_attributed_sales_brand_path="s3://bucket/sku_level_attributed_sales_brand",
)


def _loaded_paths(load_mock):
    return {
        call.kwargs["path"] if "path" in call.kwargs else call.args[1]
        for call in load_mock.call_args_list
    }


def _entrypoint_args(include_correlation_id: bool = True):
    args = [
        "--baseline-modelling-dataset-path", "s3://bucket/baseline_modelling_dataset",
        "--feature-prioritisation-path", "s3://bucket/feature_prioritisation",
        "--incremental-shrinkage-path", "s3://bucket/incremental_shrinkage",
        "--calibration-audit-path", "s3://bucket/calibration_audit",
        "--ucm-output-data-path", "s3://bucket/ucm_output_data",
        "--ucm-base-data-path", "s3://bucket/ucm_base_data",
        "--metrics-topic-arn", METRICS_ARN,
        "--slack-topic-arn", SLACK_ARN,
        "--user-journey-offer-path", _PATHS["user_journey_offer_path"],
        "--user-journey-brand-path", _PATHS["user_journey_brand_path"],
        "--attribution-model-results-path", _PATHS["attribution_model_results_path"],
        "--sku-level-attributed-sales-offer-path", _PATHS["sku_level_attributed_sales_offer_path"],
        "--sku-level-attributed-sales-brand-path", _PATHS["sku_level_attributed_sales_brand_path"],
        "--unified-campaign-path", "s3://bucket/unified_campaign",
        "--campaign-product-type-path", "s3://bucket/campaign_product_type",
        "--campaign-booking-media-channel-path", "s3://bucket/campaign_booking_media_channel",
        "--booking-id", "booking-123",
    ]

    if include_correlation_id:
        args.extend(["--correlation-id", CORRELATION_ID])

    return args


def _make_summary_row(**kwargs) -> Row:
    defaults = dict(
        correlation_id=CORRELATION_ID,
        name="features_overview_baseline_modelling_dataset",
        data_group="features_overview",
        data_sources="baseline_modelling_dataset",
        severity="HIGH",
        metadata='{"row_count": 1}',
        load_timestamp="2026-01-01 00:00:00",
    )
    defaults.update(kwargs)
    return Row(**defaults)


@pytest.fixture
def all_pipeline_summary_patched():
    with (
        patch("spark_pipeline.metrics.publish_pipeline_summary.load_parquet_dataset") as m_load,
        patch("spark_pipeline.metrics.publish_pipeline_summary.input_layer_summary") as m_input_summary,
        patch("spark_pipeline.metrics.publish_pipeline_summary.incrementality_layer_summary") as m_summary,
        patch("spark_pipeline.metrics.publish_pipeline_summary.mta_layer_summary") as m_mta_summary,
        patch("spark_pipeline.metrics.publish_pipeline_summary.MetricsPublisher") as m_publisher,
        patch("spark_pipeline.metrics.publish_pipeline_summary.SlackMessenger") as m_slack,
        patch("spark_pipeline.metrics.publish_pipeline_summary.get_stdout_logger") as m_logger,
    ):
        mock_logger_instance = Mock()
        m_logger.return_value = mock_logger_instance

        mock_publisher_instance = Mock()
        m_publisher.return_value = mock_publisher_instance

        mock_slack_instance = Mock()
        m_slack.return_value = mock_slack_instance

        empty_summary_df = Mock()
        empty_summary_df.toLocalIterator.return_value = iter([])

        m_load.return_value = Mock()
        m_input_summary.return_value = None
        m_summary.return_value = empty_summary_df
        m_mta_summary.return_value = empty_summary_df

        yield type("Patches", (), {
            "load": m_load,
            "input_summary": m_input_summary,
            "summary": m_summary,
            "mta_summary": m_mta_summary,
            "publisher_cls": m_publisher,
            "publisher": mock_publisher_instance,
            "slack_cls": m_slack,
            "slack": mock_slack_instance,
            "logger_cls": m_logger,
            "logger": mock_logger_instance,
        })()


def _call_publish(spark, summary_rows, patches):
    """Helper to wire up the summary DataFrame mock and call the publish function."""
    mock_df = Mock()
    mock_df.toLocalIterator.return_value = iter(summary_rows)
    mock_df.unionByName.return_value = mock_df
    patches.summary.return_value = mock_df
    patches.mta_summary.return_value = mock_df

    publish_pipeline_summary(
        spark=spark,
        **_PATHS,
        metrics_topic_arn=METRICS_ARN,
        slack_topic_arn=SLACK_ARN,
        correlation_id=CORRELATION_ID,
    )


def test_publishes_one_event_per_summary_row(spark_session: SparkSession, all_pipeline_summary_patched):
    # Arrange
    rows = [_make_summary_row(), _make_summary_row(name="features_overview_feature_prioritisation")]

    # Act
    _call_publish(spark_session, rows, all_pipeline_summary_patched)

    # Assert
    assert all_pipeline_summary_patched.publisher.publish_event.call_count == 2


def test_publish_event_called_with_correct_subject(spark_session: SparkSession, all_pipeline_summary_patched):
    # Arrange
    rows = [_make_summary_row()]

    # Act
    _call_publish(spark_session, rows, all_pipeline_summary_patched)

    # Assert
    call_kwargs = all_pipeline_summary_patched.publisher.publish_event.call_args[1]
    assert call_kwargs["message_subject"] == "Pipeline Summary Metrics Event"


def test_slack_success_message_sent_when_no_errors(spark_session: SparkSession, all_pipeline_summary_patched):
    # Arrange
    rows = [_make_summary_row()]

    # Act
    _call_publish(spark_session, rows, all_pipeline_summary_patched)

    # Assert
    all_pipeline_summary_patched.slack.send_message.assert_called_once()
    call_kwargs = all_pipeline_summary_patched.slack.send_message.call_args[1]
    assert call_kwargs["event_type"] == "Pipeline Summary — Published"
    assert call_kwargs["data"]["status"] == "All pipeline summary metrics published successfully"
    assert call_kwargs["data"]["published_count"] == 1
    assert call_kwargs["data"]["correlation_id"] == CORRELATION_ID


def test_slack_messenger_initialised_with_correct_args(spark_session: SparkSession, all_pipeline_summary_patched):
    # Arrange / Act
    _call_publish(spark_session, [_make_summary_row()], all_pipeline_summary_patched)

    # Assert
    all_pipeline_summary_patched.slack_cls.assert_called_once_with(
        topic_arn=SLACK_ARN,
        correlation_id=CORRELATION_ID,
    )


def test_metrics_publisher_initialised_with_correct_arn(spark_session: SparkSession, all_pipeline_summary_patched):
    # Arrange / Act
    _call_publish(spark_session, [_make_summary_row()], all_pipeline_summary_patched)

    # Assert
    all_pipeline_summary_patched.publisher_cls.assert_called_once_with(topic_arn=METRICS_ARN)


def test_all_datasets_loaded_via_load_parquet_dataset(spark_session: SparkSession, all_pipeline_summary_patched):
    # Arrange / Act
    _call_publish(spark_session, [], all_pipeline_summary_patched)

    # Assert — one call per mandatory dataset, eleven total
    assert all_pipeline_summary_patched.load.call_count == 11
    loaded_paths = _loaded_paths(all_pipeline_summary_patched.load)
    assert loaded_paths == set(_PATHS.values())


def test_user_journey_datasets_are_loaded_with_transaction_key(
    spark_session: SparkSession,
    all_pipeline_summary_patched,
):
    # Arrange / Act
    _call_publish(spark_session, [], all_pipeline_summary_patched)

    # Assert
    calls_by_dataset = {
        call.kwargs.get("dataset_name"): call.kwargs
        for call in all_pipeline_summary_patched.load.call_args_list
    }

    offer_columns = calls_by_dataset["user_journey_offer"]["columns"]
    brand_columns = calls_by_dataset["user_journey_brand"]["columns"]

    assert "transaction_key" in offer_columns
    assert "transaction_key" in brand_columns


def test_sku_datasets_are_loaded_with_booking_id_and_join_columns(
    spark_session: SparkSession,
    all_pipeline_summary_patched,
):
    _call_publish(spark_session, [], all_pipeline_summary_patched)

    calls_by_dataset = {
        call.kwargs.get("dataset_name"): call.kwargs
        for call in all_pipeline_summary_patched.load.call_args_list
    }

    for dataset in ("sku_level_attributed_sales_offer", "sku_level_attributed_sales_brand"):
        cols = calls_by_dataset[dataset]["columns"]
        assert "attributed_sales_amt" in cols
        assert "booking_id" not in cols


def test_incrementality_layer_summary_called_with_correct_correlation_id(
    spark_session: SparkSession, all_pipeline_summary_patched
):
    # Arrange / Act
    _call_publish(spark_session, [], all_pipeline_summary_patched)

    # Assert
    call_kwargs = all_pipeline_summary_patched.summary.call_args[1]
    assert call_kwargs["correlation_id"] == CORRELATION_ID


def test_no_events_published_for_empty_summary(spark_session: SparkSession, all_pipeline_summary_patched):
    # Arrange / Act
    _call_publish(spark_session, [], all_pipeline_summary_patched)

    # Assert
    all_pipeline_summary_patched.publisher.publish_event.assert_not_called()


def test_slack_success_message_sent_for_empty_summary(spark_session: SparkSession, all_pipeline_summary_patched):
    # Arrange / Act
    _call_publish(spark_session, [], all_pipeline_summary_patched)

    # Assert
    call_kwargs = all_pipeline_summary_patched.slack.send_message.call_args[1]
    assert call_kwargs["event_type"] == "Pipeline Summary — Published"
    assert call_kwargs["data"]["published_count"] == 0


def test_slack_error_message_sent_when_publish_event_fails(spark_session: SparkSession, all_pipeline_summary_patched):
    # Arrange
    rows = [_make_summary_row()]
    mock_df = Mock()
    mock_df.toLocalIterator.return_value = iter(rows)
    mock_df.unionByName.return_value = mock_df
    all_pipeline_summary_patched.summary.return_value = mock_df
    all_pipeline_summary_patched.mta_summary.return_value = mock_df
    all_pipeline_summary_patched.publisher.publish_event.side_effect = RuntimeError("SNS unavailable")

    # Act
    publish_pipeline_summary(
        spark=spark_session,
        **_PATHS,
        metrics_topic_arn=METRICS_ARN,
        slack_topic_arn=SLACK_ARN,
        correlation_id=CORRELATION_ID,
    )

    # Assert
    call_kwargs = all_pipeline_summary_patched.slack.send_message.call_args[1]
    assert call_kwargs["event_type"] == "Pipeline Summary — Publish Errors"
    assert call_kwargs["data"]["error_count"] == 1
    assert call_kwargs["data"]["published_count"] == 0


def test_campaign_details_summary_called_when_optional_inputs_present(
    spark_session: SparkSession,
    all_pipeline_summary_patched,
):
    # Arrange
    incrementality_rows = [_make_summary_row(name="inc_row")]

    incrementality_df = Mock()
    incrementality_df.toLocalIterator.return_value = iter(incrementality_rows)
    incrementality_df.unionByName.return_value = incrementality_df
    all_pipeline_summary_patched.summary.return_value = incrementality_df

    campaign_df = Mock()
    campaign_df.unionByName.return_value = incrementality_df
    all_pipeline_summary_patched.input_summary.return_value = campaign_df

    def _mock_loaded_df(columns):
        dataset_df = Mock()
        dataset_df.columns = columns
        dataset_df.filter.return_value = dataset_df
        return dataset_df

    # 14 loads total when campaign-details and MTA inputs are provided.
    all_pipeline_summary_patched.load.side_effect = [
        _mock_loaded_df(["booking_id"]),
        _mock_loaded_df(["booking_id"]),
        _mock_loaded_df(["booking_id"]),
        _mock_loaded_df(["booking_id"]),
        _mock_loaded_df(["variable_cd"]),
        _mock_loaded_df(["metric_name"]),
        _mock_loaded_df(["marketing_type"]),
        _mock_loaded_df(["best_iteration"]),
        _mock_loaded_df(["iteration"]),
        _mock_loaded_df(["loyalty_id"]),
        _mock_loaded_df(["loyalty_id"]),
        _mock_loaded_df(["journey_type"]),
        _mock_loaded_df(["attributed_sales_amt"]),
        _mock_loaded_df(["attributed_sales_amt"]),
    ]

    all_pipeline_summary_patched.mta_summary.return_value = incrementality_df

    # Act
    publish_pipeline_summary(
        spark=spark_session,
        **_PATHS,
        metrics_topic_arn=METRICS_ARN,
        slack_topic_arn=SLACK_ARN,
        correlation_id=CORRELATION_ID,
        unified_campaign_path="s3://bucket/unified_campaign",
        campaign_product_type_path="s3://bucket/campaign_product_type",
        campaign_booking_media_channel_path="s3://bucket/campaign_booking_media_channel",
        booking_id="booking-123",
    )

    # Assert
    all_pipeline_summary_patched.input_summary.assert_called_once()
    assert all_pipeline_summary_patched.load.call_count == 14


def test_campaign_details_summary_not_called_when_optional_inputs_missing(
    spark_session: SparkSession,
    all_pipeline_summary_patched,
):
    # Arrange
    rows = [_make_summary_row()]

    # Act
    _call_publish(spark_session, rows, all_pipeline_summary_patched)

    # Assert
    all_pipeline_summary_patched.input_summary.assert_not_called()


def test_partial_failure_counts_published_and_errors_correctly(
    spark_session: SparkSession, all_pipeline_summary_patched
):
    # Arrange — first call succeeds, second raises
    rows = [
        _make_summary_row(name="row_1"),
        _make_summary_row(name="row_2"),
    ]
    mock_df = Mock()
    mock_df.toLocalIterator.return_value = iter(rows)
    mock_df.unionByName.return_value = mock_df
    all_pipeline_summary_patched.summary.return_value = mock_df
    all_pipeline_summary_patched.mta_summary.return_value = mock_df
    all_pipeline_summary_patched.publisher.publish_event.side_effect = [None, RuntimeError("fail")]

    # Act
    publish_pipeline_summary(
        spark=spark_session,
        **_PATHS,
        metrics_topic_arn=METRICS_ARN,
        slack_topic_arn=SLACK_ARN,
        correlation_id=CORRELATION_ID,
    )

    # Assert
    call_kwargs = all_pipeline_summary_patched.slack.send_message.call_args[1]
    assert call_kwargs["data"]["published_count"] == 1
    assert call_kwargs["data"]["error_count"] == 1


@patch("spark_pipeline.metrics.publish_pipeline_summary.publish_pipeline_summary")
def test_entrypoint_parses_arguments_and_calls_publish(mock_publish):
    # Arrange
    spark = Mock()
    args = _entrypoint_args()

    # Act
    entrypoint(spark=spark, command_line_args=args)

    # Assert
    mock_publish.assert_called_once_with(
        spark=spark,
        baseline_modelling_dataset_path="s3://bucket/baseline_modelling_dataset",
        feature_prioritisation_path="s3://bucket/feature_prioritisation",
        incremental_shrinkage_path="s3://bucket/incremental_shrinkage",
        calibration_audit_path="s3://bucket/calibration_audit",
        ucm_output_data_path="s3://bucket/ucm_output_data",
        ucm_base_data_path="s3://bucket/ucm_base_data",
        metrics_topic_arn=METRICS_ARN,
        slack_topic_arn=SLACK_ARN,
        correlation_id=CORRELATION_ID,
        user_journey_offer_path=_PATHS["user_journey_offer_path"],
        user_journey_brand_path=_PATHS["user_journey_brand_path"],
        attribution_model_results_path=_PATHS["attribution_model_results_path"],
        sku_level_attributed_sales_offer_path=_PATHS["sku_level_attributed_sales_offer_path"],
        sku_level_attributed_sales_brand_path=_PATHS["sku_level_attributed_sales_brand_path"],
        unified_campaign_path="s3://bucket/unified_campaign",
        campaign_product_type_path="s3://bucket/campaign_product_type",
        campaign_booking_media_channel_path="s3://bucket/campaign_booking_media_channel",
        booking_id="booking-123",
    )


@patch("spark_pipeline.metrics.publish_pipeline_summary.publish_pipeline_summary")
def test_entrypoint_raises_on_missing_required_arg(mock_publish):
    # Arrange — omit --correlation-id
    spark = Mock()
    args = _entrypoint_args(include_correlation_id=False)

    # Act / Assert
    with pytest.raises(ArgumentParserError):
        entrypoint(spark=spark, command_line_args=args)


@patch("spark_pipeline.metrics.publish_pipeline_summary.publish_pipeline_summary")
def test_entrypoint_passes_campaign_details_args_when_all_required_provided(mock_publish):
    # Arrange
    spark = Mock()
    args = _entrypoint_args()

    # Act
    entrypoint(spark=spark, command_line_args=args)

    # Assert
    called_kwargs = mock_publish.call_args[1]
    assert called_kwargs["unified_campaign_path"] == "s3://bucket/unified_campaign"
    assert called_kwargs["campaign_product_type_path"] == "s3://bucket/campaign_product_type"
    assert called_kwargs["campaign_booking_media_channel_path"] == "s3://bucket/campaign_booking_media_channel"
    assert called_kwargs["booking_id"] == "booking-123"
    assert called_kwargs["user_journey_offer_path"] == _PATHS["user_journey_offer_path"]
    assert called_kwargs["user_journey_brand_path"] == _PATHS["user_journey_brand_path"]


@patch("spark_pipeline.metrics.publish_pipeline_summary.publish_pipeline_summary")
def test_entrypoint_raises_when_campaign_details_arg_missing(mock_publish):
    # Arrange — omit --booking-id
    spark = Mock()
    args = _entrypoint_args()
    args = [arg for arg in args if arg != "booking-123"]
    args.remove("--booking-id")

    # Act / Assert
    with pytest.raises(ArgumentParserError):
        entrypoint(spark=spark, command_line_args=args)

    mock_publish.assert_not_called()
