"""AAA tests for analytics checks, readable details and the publishing flow."""

import json
from unittest.mock import Mock, patch

import pytest
from pyspark.sql import functions as F
from pyspark.sql.utils import AnalysisException

from spark_pipeline.common.variables import AnalyticsValidationConfig as Config
from spark_pipeline.metrics.qa_validation_metrics.analytics_validation_metrics import analytics_validation_metrics as checks
from spark_pipeline.schemas.qa_checks import QAChecks

RUN = "run-1"


def reporting_row(**overrides):
    """
    Build the measurement campaign reporting row with default values for test setup.

    Keyword arguments replace individual fields without repeating the whole row.
    Unspecified fields keep their defaults, and each call returns a new dictionary.

    Journey types match the uppercase input supplied by the publisher.
    Reported ratios are independent of raw inputs, so tests can prove that
    grouped checks recompute values rather than trusting cached ratios.
    """
    row = {
        "booking_id": "B1", "correlation_id": RUN, "journey_type": "BRAND",
        "campaign_duration": "During", "marketing_type": "offsite", "campaign_id": "C1",
        "channel_name": "Fins", "subchannel_name": "Main Estate - JS Templated",
        "conversion_rate": 5.0, "roas_exposed": 3.0, "iroas_exposed": 1.0,
        "uplift_exposed_sales_amt": 0.1, "media_spend_amt": 1234.5,
        "attributed_recalibrated_sales_amt": 500.0,
        "incremental_sales_amt_exposed": 1234.5, "base_sales_amt_exposed": 12345.0,
    }
    row.update(overrides)
    return row


def offer_row(**overrides):
    return reporting_row(**{
        "journey_type": "OFFER", "attributed_recalibrated_sales_amt": 100.0,
        "iroas_exposed": None, "incremental_sales_amt_exposed": None, **overrides,
    })


def make_df(spark, *rows):
    """Use the reporting schema even for empty inputs or entirely null metrics."""
    return spark.createDataFrame(list(rows), QAChecks.measurement_campaign_reporting_schema)


def failed_reporting_row(value, threshold=10.0, **overrides):
    """Expected diagnostic for a reporting row, with named fields rather than tuples."""
    return {
        "booking_id": "B1", "campaign_id": "C1", "journey_type": "BRAND",
        "channel_name": "Fins", "subchannel_name": "Main Estate - JS Templated",
        "value": value, "threshold": threshold, **overrides,
    }


def metric_row(metric, value, **overrides):
    """Set raw inputs to produce the requested ratio with a unit denominator."""
    inputs = {
        "roas_exposed": {"attributed_recalibrated_sales_amt": value, "media_spend_amt": 1.0},
        "iroas_exposed": {"incremental_sales_amt_exposed": value, "media_spend_amt": 1.0},
        "uplift_exposed_sales_amt": {"incremental_sales_amt_exposed": value, "base_sales_amt_exposed": 1.0},
    }
    return reporting_row(**{metric: value, **inputs.get(metric, {}), **overrides})


def failed_group(value, threshold, **overrides):
    return {
        "booking_id": "B1", "campaign_duration": "During", "journey_type": "BRAND",
        "numerator": value, "denominator": 1.0, "value": value, "threshold": threshold,
        **overrides,
    }


def result(df):
    rows = df.collect()
    assert len(rows) == 1
    return rows[0]


def metadata(row):
    return json.loads(row.additional_metadata)


def assert_qa_schema(df):
    # Spark expressions may infer different nullability; field order and types are the contract.
    assert [(field.name, field.dataType) for field in df.schema] == [
        (field.name, field.dataType) for field in QAChecks.detail_schema
    ]


def test_is_instore_matches_normalized_types_and_preserves_nulls(spark_session):
    # Arrange
    marketing_types = ["instore", "INSTORE", " In-Store ", "onsite", "offsite", "in store", "", None]
    df = make_df(spark_session, *[reporting_row(marketing_type=value) for value in marketing_types])
    expected = [True, True, True, False, False, False, False, None]

    # Act
    rows = df.select(checks.is_instore(F.col("marketing_type")).alias("is_instore")).collect()

    # Assert
    assert [row.is_instore for row in rows] == expected


@pytest.mark.parametrize("input_rows, checked_count, failed_rows", [
    pytest.param([], 0, [], id="empty-reporting"),
    pytest.param([reporting_row(roas_exposed=None)], 0, [], id="missing-roas"),
    pytest.param([
        reporting_row(roas_exposed=10.0), reporting_row(roas_exposed=-1.0),
        reporting_row(roas_exposed=None),
    ], 2, [], id="boundary-and-negative-roas-pass"),
    pytest.param(
        [
            reporting_row(channel_name="Social", roas_exposed=12.0),
            reporting_row(roas_exposed=11.0), reporting_row(roas_exposed=11.0),
            reporting_row(channel_name="Display", roas_exposed=10.0),
            reporting_row(channel_name="Email", roas_exposed=None),
        ],
        4,
        [failed_reporting_row(11.0), failed_reporting_row(11.0), failed_reporting_row(12.0, channel_name="Social")],
        id="failures-are-sorted-and-duplicates-retained",
    ),
])
def test_count_failed_rows_counts_non_null_values_and_sorts_failures(
    spark_session, input_rows, checked_count, failed_rows,
):
    # Arrange: use the same reporting fields and failure diagnostic as the ROAS check.
    df = make_df(spark_session, *input_rows)

    # Act
    stats = result(checks.count_failed_rows(
        df, value=F.col("roas_exposed"), fail_condition=F.col("roas_exposed") > 10.0,
        failed_row=F.struct(
            "booking_id", "campaign_id", "journey_type", "channel_name", "subchannel_name",
            F.col("roas_exposed").alias("value"), F.lit(10.0).alias("threshold"),
        ),
    ))

    # Assert: null ROAS is unchecked; duplicates remain separate reporting rows.
    # Identifiers are identical here, so sorting the struct orders failures by channel.
    # Sets recursive to True so the nested struct is converted to a dict for comparison.
    assert stats.asDict(recursive=True) == {
        "checked_count": checked_count,
        "failed_count": len(failed_rows),
        "failed_rows": failed_rows,
    }


@pytest.mark.parametrize("input_rows, checked_count, failed_rows", [
    pytest.param([], 0, [], id="empty-reporting"),
    pytest.param([reporting_row(conversion_rate=None)], 0, [], id="missing-conversion-rate"),
    pytest.param(
        [
            reporting_row(booking_id="B1", marketing_type="instore", conversion_rate=10.0),
            reporting_row(booking_id="B2", marketing_type="instore", conversion_rate=12.0),
            reporting_row(booking_id="B3", marketing_type="offsite", conversion_rate=21.0),
            reporting_row(booking_id="B4", marketing_type="offsite", conversion_rate=None),
        ],
        3,
        [failed_reporting_row(12.0, booking_id="B2"), failed_reporting_row(21.0, threshold=20.0, booking_id="B3")],
        id="each-row-uses-its-own-threshold",
    ),
])
def test_count_rows_above_threshold_casts_values_and_uses_each_rows_limit(
    spark_session, input_rows, checked_count, failed_rows,
):
    # Arrange: string metrics exercise casting; in-store/offsite rows have 10%/20% limits.
    df = make_df(spark_session, *input_rows).withColumn("conversion_rate", F.col("conversion_rate").cast("string"))
    threshold = F.when(checks.is_instore(F.col("marketing_type")), F.lit(10.0)).otherwise(F.lit(20.0))

    # Act
    stats = result(checks.count_rows_above_threshold(df, "conversion_rate", threshold))

    # Assert
    assert stats.asDict(recursive=True) == {
        "checked_count": checked_count,
        "failed_count": len(failed_rows),
        "failed_rows": failed_rows,
    }


def test_format_value_formats_two_decimals_without_losing_precision(spark_session):
    # Arrange
    values = [0.0, 12.0, 12.34, 1234.5, -1234.5, 10.004, -10.004, None]
    df = make_df(spark_session, *[reporting_row(roas_exposed=value) for value in values])
    expected = ["0.00", "12.00", "12.34", "1,234.50", "-1,234.50", "10.004", "-10.004", None]

    # Act
    rows = df.select(checks.format_value(F.col("roas_exposed")).alias("formatted")).collect()

    # Assert: exact hundredths get two decimals, but 10.004 must not display as 10.00.
    assert [row.formatted for row in rows] == expected


def test_format_details_for_failed_checks_handles_missing_names_and_precise_values(spark_session):
    # Arrange
    df = spark_session.createDataFrame([
        failed_reporting_row(12.0, subchannel_name="Main"),
        failed_reporting_row(10.004, subchannel_name=None),
        failed_reporting_row(1000.0, channel_name=None, subchannel_name="Main"),
        failed_reporting_row(-12.34, channel_name=None, subchannel_name=None),
        failed_reporting_row(None, subchannel_name="Main"),
    ], QAChecks.analytics_failed_row_schema)
    expected = ["Fins - Main (12.00)", "Fins (10.004)", "Main (1,000.00)", " (-12.34)", None]

    # Act
    rows = df.select(checks.format_details_for_failed_checks(
        F.struct("channel_name", "subchannel_name", "value"),
    ).alias("details")).collect()

    # Assert: missing names are omitted by concat_ws; a missing value nulls the whole detail.
    assert [row.details for row in rows] == expected


@pytest.mark.parametrize("checked_count, failed_rows, expected_value, outcome, details", [
    pytest.param(0, [], None, "skipped", "No values to check.", id="no-checked-values"),
    pytest.param(2, [], "10", "pass", "All rows passed.", id="all-values-pass"),
    pytest.param(
        3,
        [
            failed_reporting_row(12.34, channel_name="A", subchannel_name="Main"),
            failed_reporting_row(10.004, channel_name="Z", subchannel_name=None),
        ],
        "10", "fail", "A - Main (12.34); Z (10.004)",
        id="failures-include-readable-details",
    ),
])
def test_format_fail_result_builds_qa_schema_outcome_details_and_metadata(
    spark_session, expected_value, checked_count, failed_rows, outcome, details,
):
    # Arrange: supply the single aggregate row produced by the counting helpers.
    statistics = {
        "checked_count": checked_count,
        "failed_count": len(failed_rows),
        "failed_rows": failed_rows,
    }
    stats = spark_session.createDataFrame([statistics], QAChecks.analytics_validation_stats_schema)
    expected_metadata = {
        **statistics,
        # Spark's JSON encoder omits null struct fields, including a missing subchannel.
        "failed_rows": [
            {key: value for key, value in failure.items() if value is not None}
            for failure in failed_rows
        ],
        "threshold": 10.0,
    }

    # Act: whitespace/case in the campaign period must not leak into the check name.
    output = checks.format_fail_result(
        stats, RUN, " Post ", Config.ROAS_CHECK, expected_value=expected_value, threshold=10.0,
    )
    row = result(output)

    # Assert
    assert_qa_schema(output)
    assert row.correlation_id == RUN
    assert row.type == "analytics"
    assert row.name == f"{Config.ROAS_CHECK}_post"
    assert row.expected_value == expected_value
    assert row.outcome == outcome
    assert row.details == details
    assert metadata(row) == expected_metadata
    assert row.load_timestamp is not None


def test_sales_wrapper_configures_campaign_grain_and_surfaces_shared_comment(spark_session):
    # Arrange: shared comparison is retained, but receives campaign maxima.
    reporting = make_df(spark_session, reporting_row())
    shared_result = reporting.select(
        F.lit(RUN).alias("correlation_id"), F.lit("hypercare").alias("type"), F.lit("shared").alias("name"),
        F.lit("Brand >= Offer").alias("expected_value"), F.lit("fail").alias("outcome"),
        F.lit("").alias("details"), F.lit('{"breach_count":1,"comment":"Shared diagnostic"}').alias("additional_metadata"),
        F.lit("2026-10-16 12:00:00").cast("timestamp").alias("load_timestamp"),
    )
    expected = {
        **result(shared_result).asDict(), "type": "analytics",
        "name": f"{Config.OFFER_VS_BRAND_SALES_CHECK}_post", "details": "Shared diagnostic",
    }

    # Act
    with patch.object(checks, "check_hypercare_brand_vs_offer_sales", return_value=shared_result) as shared_check:
        output = checks.check_brand_vs_offer_sales(reporting, RUN, "Post")

    # Assert
    shared_check.assert_called_once()
    args, kwargs = shared_check.call_args
    assert args[1:] == (RUN, "Post")
    assert kwargs == {"group_by_columns": ("booking_id", "campaign_id", "campaign_duration"), "decimal_places": 4}
    assert result(args[0]).attributed_recalibrated_sales_amt == 500.0
    assert_qa_schema(output)
    assert result(output).asDict() == expected


def test_sales_uses_campaign_maxima_and_isolates_bookings_campaigns_and_periods(spark_session):
    # Duplicate sales must not be summed; another campaign/booking/period cannot offset a breach.
    df = make_df(
        spark_session, reporting_row(attributed_recalibrated_sales_amt=100.0),
        reporting_row(channel_name="Other", subchannel_name="Other",
                      attributed_recalibrated_sales_amt=100.0),
        offer_row(attributed_recalibrated_sales_amt=100.00014),
        offer_row(attributed_recalibrated_sales_amt=100.0),
        reporting_row(campaign_id="C2", attributed_recalibrated_sales_amt=1000.0), offer_row(campaign_id="C2"),
        reporting_row(booking_id="B2", attributed_recalibrated_sales_amt=1000.0), offer_row(booking_id="B2"),
        reporting_row(campaign_duration="Post", attributed_recalibrated_sales_amt=1000.0), offer_row(campaign_duration="Post"),
        reporting_row(correlation_id="other-run", attributed_recalibrated_sales_amt=10000.0),
    )

    # Act
    row = result(checks.check_brand_vs_offer_sales(df, RUN))

    # Assert: the 4-decimal breach is retained, with exact group identifiers.
    assert row.outcome == "fail"
    assert row.expected_value == "Brand >= Offer"
    assert "B1 | C1 | During" in row.details
    assert metadata(row)["group_count"] == 4
    assert metadata(row)["breach_count"] == 1
    assert metadata(row)["breaches"] == [{
        "booking_id": "B1", "campaign_id": "C1", "campaign_duration": "During",
        "brand_sales": 100.0, "offer_sales": 100.0001,
    }]
    assert "Offer > Brand" in metadata(row)["comment"]


@pytest.mark.parametrize("check, numerator, high_value, expected_value", [
    (checks.check_roas, "attributed_recalibrated_sales_amt", 60.0, "20"),
    (checks.check_iroas, "incremental_sales_amt_exposed", 6.0, "2"),
])
def test_return_on_spend_uses_ratio_of_sums_across_campaigns(spark_session, check, numerator, high_value, expected_value):
    # One row and the average of row ratios fail, but the ratio of totals passes.
    df = make_df(
        spark_session, reporting_row(media_spend_amt=1.0, **{numerator: high_value}),
        reporting_row(campaign_id="C2", channel_name="Other", subchannel_name="Other",
                      media_spend_amt=9.0, **{numerator: 0.0}),
        offer_row(media_spend_amt=1.0, **{numerator: 1.0}),
        reporting_row(booking_id="B2", media_spend_amt=1.0, **{numerator: 1.0}),
        reporting_row(campaign_duration="Post", media_spend_amt=1.0, **{numerator: 1.0}),
    )

    # Act
    row = result(check(df, RUN))

    # Assert
    assert row.outcome == "pass"
    assert row.expected_value == expected_value
    assert row.details == "All rows passed."
    assert metadata(row) == {"checked_count": 4, "failed_count": 0, "failed_rows": [], "threshold": float(expected_value)}


def test_check_iroas_skips_null_offer_values(spark_session):
    # Arrange
    df = make_df(spark_session, metric_row("iroas_exposed", 2.0), offer_row())

    # Act
    row = result(checks.check_iroas(df, RUN))

    # Assert
    assert row.outcome == "pass"
    assert row.expected_value == "2"
    assert row.details == "All rows passed."
    assert metadata(row) == {"checked_count": 1, "failed_count": 0, "failed_rows": [], "threshold": 2.0}


def test_uplift_uses_ratio_of_sums_and_keeps_marketing_types_and_journeys_separate(spark_session):
    # Offsite's row ratio fails, but its total ratio passes. In-store still fails:
    # another marketing type, booking, journey or period must not dilute it.
    instore = reporting_row(marketing_type="INSTORE", incremental_sales_amt_exposed=30.0, base_sales_amt_exposed=100.0, uplift_exposed_sales_amt=0.0)
    df = make_df(
        spark_session, instore, instore,
        reporting_row(incremental_sales_amt_exposed=90.0, base_sales_amt_exposed=100.0),
        reporting_row(campaign_id="C2", channel_name="Other", subchannel_name="Other",
                      incremental_sales_amt_exposed=0.0, base_sales_amt_exposed=900.0),
        {**instore, "booking_id": "B2", "incremental_sales_amt_exposed": 0.0, "base_sales_amt_exposed": 1000.0},
        {**instore, "journey_type": "OFFER", "incremental_sales_amt_exposed": 0.0, "base_sales_amt_exposed": 1000.0},
        {**instore, "campaign_duration": "Post", "incremental_sales_amt_exposed": 0.0, "base_sales_amt_exposed": 1000.0},
    )

    row = result(checks.check_exposed_sales_uplift(df, RUN))

    assert row.outcome == "fail"
    assert row.details == "B1 - During - BRAND - INSTORE (0.30)"
    assert metadata(row) == {
        "checked_count": 5, "failed_count": 1,
        "failed_rows": [failed_group(0.3, 0.2, numerator=60.0, denominator=200.0, marketing_type="INSTORE")],
        "instore_threshold": 0.2, "default_channel_threshold": 0.8,
    }


@pytest.mark.parametrize("check, numerator, denominator", [
    (checks.check_roas, "attributed_recalibrated_sales_amt", "media_spend_amt"),
    (checks.check_iroas, "incremental_sales_amt_exposed", "media_spend_amt"),
    (checks.check_exposed_sales_uplift, "incremental_sales_amt_exposed", "base_sales_amt_exposed"),
])
def test_grouped_ratios_guard_undefined_values_even_in_ansi_mode(spark_session, check, numerator, denominator):
    df = make_df(spark_session, *[
        reporting_row(booking_id=f"B{index}", **{numerator: sales, denominator: spend})
        for index, (sales, spend) in enumerate([(10.0, 0.0), (10.0, None), (None, 10.0)])
    ])
    previous = spark_session.conf.get("spark.sql.ansi.enabled")
    try:
        spark_session.conf.set("spark.sql.ansi.enabled", "true")
        row = result(check(df, RUN))
    finally:
        spark_session.conf.set("spark.sql.ansi.enabled", previous)

    assert row.outcome == "skipped"
    assert row.details == "No values to check."
    assert metadata(row)["checked_count"] == 0
    assert metadata(row)["failed_rows"] == []


def test_grouped_ratio_preserves_null_sum_negative_denominator_and_duplicate_semantics(spark_session):
    # SUM ignores individual nulls; cached row-level ROAS is deliberately misleading.
    df = make_df(
        spark_session, reporting_row(attributed_recalibrated_sales_amt=20.0, media_spend_amt=None, roas_exposed=999.0),
        reporting_row(attributed_recalibrated_sales_amt=None, media_spend_amt=1.0, roas_exposed=999.0),
        reporting_row(booking_id="B2", attributed_recalibrated_sales_amt=100.0, media_spend_amt=-1.0),
        metric_row("roas_exposed", 30.0, booking_id="B3"),
        metric_row("roas_exposed", 30.0, booking_id="B3"),
        metric_row("roas_exposed", 0.0, booking_id="B3"),
    )

    row = result(checks.check_roas(df, RUN, threshold=19.0))

    assert row.outcome == "fail"
    assert metadata(row)["checked_count"] == 3
    assert metadata(row)["failed_rows"] == [
        failed_group(20.0, 19.0, numerator=20.0),
        failed_group(20.0, 19.0, booking_id="B3", numerator=60.0, denominator=3.0),
    ]


@pytest.mark.parametrize("check, metric, instore_limit, default_limit, expected_value", [
    pytest.param(checks.check_conversion_rate, "conversion_rate", 10.0, 20.0, None, id="conversion-percentage-points"),
    pytest.param(checks.check_roas, "roas_exposed", 20.0, 20.0, "20", id="roas"),
    pytest.param(checks.check_iroas, "iroas_exposed", 2.0, 2.0, "2", id="iroas"),
    pytest.param(checks.check_exposed_sales_uplift, "uplift_exposed_sales_amt", 0.2, 0.8, None, id="uplift-ratios"),
])
def test_threshold_checks_preserve_boundaries_channel_limits_and_failure_details(
    spark_session, check, metric, instore_limit, default_limit, expected_value,
):
    # Arrange: batch independent cases instead of running the channel/value Cartesian product.
    # Uplift uses ratios (0.2/0.8), while conversion uses percentage points (10/20).
    channels = [
        ("instore", instore_limit), (" In-Store ", instore_limit), ("INSTORE", instore_limit),
        ("onsite", default_limit), ("offsite", default_limit), ("unknown", default_limit), (None, default_limit),
    ]
    input_rows, expected_failures = [], []
    for index, (marketing_type, limit) in enumerate(channels):
        for case, value in (("below", limit / 2), ("equal", limit), ("above", round(limit + 0.01, 2)), ("missing", None)):
            booking_id = f"B{index}-{case}"
            input_rows.append(
                metric_row(
                    metric, value,
                    booking_id=booking_id, marketing_type=marketing_type,
                    journey_type="OFFER" if case == "above" else "BRAND",
                    channel_name="Fins" if case == "above" else "Passing",
                )
            )
            if case == "above":
                failure = (
                    failed_reporting_row(value, limit, booking_id=booking_id, journey_type="OFFER")
                    if check == checks.check_conversion_rate else
                    failed_group(value, limit, booking_id=booking_id, journey_type="OFFER")
                )

                if check == checks.check_exposed_sales_uplift and marketing_type is not None:
                    failure["marketing_type"] = marketing_type

                expected_failures.append(failure)

    thresholds = (
        {"threshold": default_limit} if expected_value is not None else
        {"instore_threshold": instore_limit, "default_channel_threshold": default_limit}
    )

    # Act: mixed data proves exact failed-row selection; null-only data proves skipped status.
    row = result(check(make_df(spark_session, *input_rows), RUN))
    missing = result(check(make_df(spark_session, metric_row(metric, None)), RUN))

    # Assert
    assert row.outcome == "fail"
    assert row.expected_value == expected_value
    assert metadata(row) == {
        "checked_count": 3 * len(channels), "failed_count": len(channels),
        "failed_rows": expected_failures, **thresholds,
    }
    detail_columns = (
        ("channel_name", "subchannel_name") if check == checks.check_conversion_rate
        else ("booking_id", "campaign_duration", "journey_type")
        + (("marketing_type",) if check == checks.check_exposed_sales_uplift else ())
    )
    assert row.details == "; ".join(
        f"{' - '.join(str(failure[name]) for name in detail_columns if name in failure)} ({failure['value']:,.2f})"
        for failure in expected_failures
    )
    assert missing.outcome == "skipped"
    assert missing.details == "No values to check."
    assert metadata(missing) == {"checked_count": 0, "failed_count": 0, "failed_rows": [], **thresholds}


@pytest.mark.parametrize("check, kwargs, expected_value", [
    (checks.check_conversion_rate, {"instore_threshold": 4.0, "default_channel_threshold": 4.0}, None),
    (checks.check_roas, {"threshold": 2.0}, "2"),
    (checks.check_iroas, {"threshold": 0.5}, "0.5"),
    (checks.check_exposed_sales_uplift, {"instore_threshold": 0.05, "default_channel_threshold": 0.05}, None),
    (checks.check_offsite_media_spend, {"multiple": 1234.5}, "1234.5"),
])
def test_threshold_overrides_and_singular_expected_value(spark_session, check, kwargs, expected_value):
    # Arrange
    df = make_df(spark_session, reporting_row(marketing_type="instore", attributed_recalibrated_sales_amt=3703.5),
                 reporting_row(attributed_recalibrated_sales_amt=3703.5))

    # Act
    row = result(check(df, RUN, **kwargs))

    # Assert
    assert row.outcome == "fail"
    assert row.expected_value == expected_value
    for name, value in kwargs.items():
        assert metadata(row)[name] == value


def test_offsite_spend_checks_exact_multiples_without_rounding(spark_session):
    # All nonpositive values fail; nearby floating-point values must not be rounded.
    spends = [1234.5, 2000.0, 0.0, -123.5, 1000.0000001, 999.9999999, None]
    df = make_df(spark_session, *[
        offer_row(booking_id=f"B{index}", media_spend_amt=spend, marketing_type=" Offsite ")
        for index, spend in enumerate(spends)
    ], reporting_row(marketing_type="instore", media_spend_amt=2000.0))
    expected_failures = [
        failed_reporting_row(spend, 1000.0, booking_id=f"B{index}", journey_type="OFFER")
        for index, spend in ((1, 2000.0), (2, 0.0), (3, -123.5))
    ]

    # Act
    row = result(checks.check_offsite_media_spend(df, RUN))

    # Assert
    assert row.outcome == "fail"
    assert row.expected_value == "1000"
    assert metadata(row) == {
        "checked_count": 6, "failed_count": 3, "failed_rows": expected_failures, "multiple": 1000.0,
    }
    assert row.details == "; ".join(
        f"Fins - Main Estate - JS Templated ({failure['value']:,.2f})" for failure in expected_failures
    )


def test_offsite_spend_is_neither_summed_nor_deduplicated(spark_session):
    # Arrange: 600 + 400 would fail if summed; repeated 600 rows must both be checked.
    df = make_df(
        spark_session, reporting_row(media_spend_amt=600.0), reporting_row(media_spend_amt=600.0),
        reporting_row(channel_name="Other", media_spend_amt=400.0),
    )

    # Act
    row = result(checks.check_offsite_media_spend(df, RUN))

    # Assert
    assert row.outcome == "pass"
    assert metadata(row)["checked_count"] == 3


@pytest.mark.parametrize("marketing_type, spend", [("offsite", None), ("onsite", 2000.0)])
def test_missing_or_non_offsite_spend_is_skipped(spark_session, marketing_type, spend):
    # Arrange
    df = make_df(spark_session, reporting_row(marketing_type=marketing_type, media_spend_amt=spend))

    # Act
    row = result(checks.check_offsite_media_spend(df, RUN))

    # Assert
    assert row.outcome == "skipped"
    assert row.details == "No values to check."


@pytest.mark.parametrize("multiple", [0, -1000])
def test_offsite_multiple_must_be_positive(spark_session, multiple):
    # Arrange
    df = make_df(spark_session, reporting_row())

    # Act
    with pytest.raises(ValueError) as error:
        checks.check_offsite_media_spend(df, RUN, multiple=multiple)

    # Assert
    assert "must be positive" in str(error.value)


def test_failure_details_are_sorted(spark_session):
    # Group diagnostics are sorted by booking, not arbitrary source channels.
    df = make_df(
        spark_session, metric_row("roas_exposed", 21.0, booking_id="Z"),
        metric_row("roas_exposed", 22.0, booking_id="A"),
    )

    # Act
    row = result(checks.check_roas(df, RUN))

    # Assert
    assert row.details == "A - During - BRAND (22.00); Z - During - BRAND (21.00)"


def test_details_do_not_round_away_the_reason_a_row_failed(spark_session):
    # Arrange
    df = make_df(spark_session, metric_row("roas_exposed", 20.004))

    # Act
    row = result(checks.check_roas(df, RUN))

    # Assert
    assert row.outcome == "fail"
    assert row.details == "B1 - During - BRAND (20.004)"


@pytest.mark.parametrize("details", [None, "Readable analytics failure."])
def test_shared_formatter_supports_optional_details_and_preserves_qa_schema(spark_session, details):
    # Arrange: omit the keyword entirely to exercise the default; null outcome must become fail.
    stats = spark_session.range(1)
    kwargs = {} if details is None else {"details": F.lit(details)}

    # Act
    output = checks.format_qa_result(
        stats, RUN, "analytics", "check_during", None, F.lit(None), F.struct(F.lit(1).alias("observed")), **kwargs,
    )
    row = result(output)

    # Assert
    assert_qa_schema(output)
    assert row.details == ("" if details is None else details)
    assert row.outcome == "fail"
    assert row.expected_value is None
    assert metadata(row) == {"observed": 1}


@pytest.mark.parametrize("campaign_period, durations", [
    pytest.param("During", ("During",), id="during-run"),
    pytest.param("Post", ("POST", "DURING+POST"), id="post-run-with-both-durations"),
])
def test_run_analytics_validation_checks_filters_by_run_and_returns_six_unique_rows(spark_session, campaign_period, durations):
    # Arrange: retain every duration generated by the run, but exclude other runs.
    df = make_df(
        spark_session, *[
            row(campaign_duration=duration)
            for duration in durations for row in (reporting_row, offer_row)
        ],
        offer_row(correlation_id="other-run", campaign_duration=campaign_period, roas_exposed=99.0,
                  attributed_recalibrated_sales_amt=10000.0),
    )
    with patch.object(checks, "filter_reporting_by_correlation_id", wraps=checks.filter_reporting_by_correlation_id) as filtering:
        # Act
        output = checks.run_analytics_validation_checks(df, RUN, campaign_period)
        rows = output.collect()

    # Assert
    filtering.assert_called_once_with(df, RUN)
    assert_qa_schema(output)
    assert len(rows) == len({row.name for row in rows}) == 6
    assert {row.outcome for row in rows} == {"pass"}
    assert {row.type for row in rows} == {"analytics"}
    assert {row.correlation_id for row in rows} == {RUN}
    assert {row.name for row in rows} == {
        f"{name}_{campaign_period.lower()}" for name in (
            Config.OFFER_VS_BRAND_SALES_CHECK, Config.CONVERSION_RATE_CHECK, Config.ROAS_CHECK,
            Config.IROAS_CHECK, Config.EXPOSED_SALES_UPLIFT_CHECK, Config.OFFSITE_MEDIA_SPEND_CHECK,
        )
    }
    by_name = {row.name: row for row in rows}
    assert metadata(by_name[f"{Config.OFFER_VS_BRAND_SALES_CHECK}_{campaign_period.lower()}"])["group_count"] == len(durations)
    for name in (Config.ROAS_CHECK, Config.IROAS_CHECK, Config.EXPOSED_SALES_UPLIFT_CHECK):
        expected_count = len(durations) * (2 if name == Config.ROAS_CHECK else 1)
        assert metadata(by_name[f"{name}_{campaign_period.lower()}"])["checked_count"] == expected_count
    for name in (Config.CONVERSION_RATE_CHECK, Config.OFFSITE_MEDIA_SPEND_CHECK):
        assert metadata(by_name[f"{name}_{campaign_period.lower()}"])["checked_count"] == 2 * len(durations)


@pytest.mark.parametrize("failing_duration, passing_duration", [
    ("POST", "DURING+POST"), ("DURING+POST", "POST"),
])
@pytest.mark.parametrize("check_name, metric, failing_value, threshold", [
    (Config.ROAS_CHECK, "roas_exposed", 60.0, 20.0),
    (Config.IROAS_CHECK, "iroas_exposed", 6.0, 2.0),
    (Config.EXPOSED_SALES_UPLIFT_CHECK, "uplift_exposed_sales_amt", 0.9, 0.2),
])
def test_post_run_grouped_ratios_keep_durations_separate_in_metadata_and_details(
    spark_session, failing_duration, passing_duration, check_name, metric, failing_value, threshold,
):
    # Arrange: combining durations would dilute the failing ratio below its limit.
    denominator = "base_sales_amt_exposed" if metric == "uplift_exposed_sales_amt" else "media_spend_amt"
    df = make_df(
        spark_session,
        metric_row(metric, failing_value, campaign_duration=failing_duration, marketing_type="instore"),
        metric_row(metric, 0.0, campaign_duration=passing_duration, marketing_type="instore", **{denominator: 9.0}),
        metric_row(metric, 999.0, correlation_id="other-run", campaign_duration=passing_duration, marketing_type="instore"),
    )

    # Act
    rows = checks.run_analytics_validation_checks(df, RUN, "Post").collect()
    row = next(row for row in rows if row.name == f"{check_name}_post")

    # Assert: neither post duration is dropped, nor are their totals combined.
    expected_failure = failed_group(failing_value, threshold, campaign_duration=failing_duration)
    if metric == "uplift_exposed_sales_amt":
        expected_failure["marketing_type"] = "instore"
    assert row.outcome == "fail"
    assert metadata(row)["checked_count"] == 2
    assert metadata(row)["failed_count"] == 1
    assert metadata(row)["failed_rows"] == [expected_failure]
    marketing_detail = " - instore" if metric == "uplift_exposed_sales_amt" else ""
    assert row.details == f"B1 - {failing_duration} - BRAND{marketing_detail} ({failing_value:,.2f})"


@pytest.mark.parametrize("failing_duration, passing_duration", [
    ("POST", "DURING+POST"), ("DURING+POST", "POST"),
])
def test_post_run_sales_compares_brand_and_offer_separately_for_each_duration(
    spark_session, failing_duration, passing_duration,
):
    # Arrange: the passing duration's Brand sales must not offset the failing pair.
    df = make_df(
        spark_session,
        reporting_row(campaign_duration=failing_duration, attributed_recalibrated_sales_amt=100.0),
        offer_row(campaign_duration=failing_duration, attributed_recalibrated_sales_amt=200.0),
        reporting_row(campaign_duration=passing_duration, attributed_recalibrated_sales_amt=1000.0),
        offer_row(campaign_duration=passing_duration, attributed_recalibrated_sales_amt=100.0),
        offer_row(correlation_id="other-run", campaign_duration=passing_duration, attributed_recalibrated_sales_amt=10000.0),
    )

    # Act
    rows = checks.run_analytics_validation_checks(df, RUN, "Post").collect()
    row = next(row for row in rows if row.name == f"{Config.OFFER_VS_BRAND_SALES_CHECK}_post")

    # Assert
    assert row.outcome == "fail"
    assert metadata(row)["group_count"] == 2
    assert metadata(row)["breach_count"] == 1
    assert metadata(row)["breaches"] == [{
        "booking_id": "B1", "campaign_id": "C1", "campaign_duration": failing_duration,
        "brand_sales": 100.0, "offer_sales": 200.0,
    }]
    assert row.details == f"Offer > Brand for: B1 | C1 | {failing_duration} [Brand=100.0, Offer=200.0]"


def test_post_run_row_level_checks_include_failures_from_both_durations(spark_session):
    # Arrange: one failure per duration; failures from another run must stay excluded.
    df = make_df(
        spark_session,
        reporting_row(campaign_duration="POST", conversion_rate=21.0, media_spend_amt=2000.0),
        reporting_row(campaign_duration="DURING+POST", conversion_rate=22.0, media_spend_amt=3000.0),
        reporting_row(correlation_id="other-run", campaign_duration="POST", conversion_rate=99.0, media_spend_amt=4000.0),
    )

    # Act
    rows = checks.run_analytics_validation_checks(df, RUN, "Post").collect()
    by_name = {row.name: row for row in rows}

    # Assert: both rows are checked, without aggregation or duration filtering.
    for name, values, threshold in (
        (Config.CONVERSION_RATE_CHECK, (21.0, 22.0), 20.0),
        (Config.OFFSITE_MEDIA_SPEND_CHECK, (2000.0, 3000.0), 1000.0),
    ):
        row = by_name[f"{name}_post"]
        assert row.outcome == "fail"
        assert metadata(row)["checked_count"] == 2
        assert metadata(row)["failed_count"] == 2
        assert metadata(row)["failed_rows"] == [failed_reporting_row(value, threshold) for value in values]
        assert row.details == "; ".join(f"Fins - Main Estate - JS Templated ({value:,.2f})" for value in values)


def test_period_label_formats_check_names_without_filtering_reporting_durations(spark_session):
    # Arrange: the supplied period labels results; it does not scope input rows.
    df = make_df(spark_session, reporting_row(campaign_duration=" during+post "))

    # Act
    rows = checks.run_analytics_validation_checks(df, RUN, " During+Post ").collect()

    # Assert
    assert len({row.name for row in rows}) == 6
    assert all(row.name.endswith("_during_post") for row in rows)
    roas = next(row for row in rows if row.name.startswith(Config.ROAS_CHECK))
    assert roas.outcome == "pass"
    assert metadata(roas)["checked_count"] == 1


def test_empty_run_preserves_shared_sales_pass_and_skips_row_level_checks(spark_session):
    # Arrange
    df = make_df(spark_session)

    # Act
    rows = checks.run_analytics_validation_checks(df, RUN).collect()

    # Assert: the reused sales check passes with no pairs; row-level checks skip with no values.
    assert len(rows) == 6
    sales_row = next(row for row in rows if row.name.startswith(Config.OFFER_VS_BRAND_SALES_CHECK))
    assert sales_row.outcome == "pass"
    assert metadata(sales_row)["group_count"] == 0
    other_rows = [row for row in rows if row != sales_row]
    assert len(other_rows) == 5
    assert {row.outcome for row in other_rows} == {"skipped"}
    assert {row.details for row in other_rows} == {"No values to check."}


def test_missing_required_column_raises_analysis_exception(spark_session):
    # Arrange: remove a column required by the iROAS check.
    df = make_df(spark_session, reporting_row(), offer_row()).drop("incremental_sales_amt_exposed")

    # Act: Spark may detect the missing column during transformation or execution.
    with pytest.raises(AnalysisException) as error:
        checks.run_analytics_validation_checks(df, RUN)

    # Assert: confirm the exception identifies the missing column.
    assert "incremental_sales_amt_exposed" in str(error.value)


def test_run_propagates_check_errors_without_catching_them():
    # Arrange
    reporting_df = Mock()

    with (
        patch.object(checks, "filter_reporting_by_correlation_id"),
        patch.object(checks, "check_brand_vs_offer_sales", side_effect=RuntimeError("invalid sales")),
    ):
        # Act
        with pytest.raises(RuntimeError) as error:
            checks.run_analytics_validation_checks(reporting_df, RUN)

    # Assert
    assert str(error.value) == "invalid sales"


@pytest.mark.parametrize("durations", [
    pytest.param(("Post",), id="post-only"),
    pytest.param(("POST", "DURING+POST"), id="both-post-durations"),
])
def test_real_checks_persist_and_publish_corrected_results_with_stable_upsert_keys(spark_session, tmp_path, durations):
    # Arrange
    from spark_pipeline.metrics import publish_analytics_validation as publishing

    campaign_period = "Post"
    input_path = str(tmp_path / "reporting")
    output_path = str(tmp_path / "analytics")
    failing = [row for duration in durations for row in (
        reporting_row(
            campaign_duration=duration,
            conversion_rate=60.21, roas_exposed=60.21, iroas_exposed=60.21,
            uplift_exposed_sales_amt=0.81, media_spend_amt=2000.0,
            attributed_recalibrated_sales_amt=50000.0,
            incremental_sales_amt_exposed=6000.0, base_sales_amt_exposed=5000.0,
        ),
        offer_row(campaign_duration=duration, attributed_recalibrated_sales_amt=60000.0),
    )]
    passing = [row(campaign_duration=duration) for duration in durations for row in (reporting_row, offer_row)]
    stored_outputs = []
    with (
        patch.object(publishing, "spark_s3_overwrite", side_effect=lambda path, df: df.write.mode("overwrite").parquet(path)),
        patch("spark_pipeline.utils.publish_metrics.boto3.client") as sns,
    ):
        # Act: rerun the same campaign with corrected data, keeping the six check identities.
        for input_rows in (failing, passing):
            make_df(spark_session, *input_rows).write.mode("overwrite").parquet(input_path)
            publishing.publish_analytics_validation(
                spark_session, input_path, campaign_period, RUN, "arn:aws:sns:eu-west-1:123456789012:metrics", output_path,
            )
            stored = spark_session.read.parquet(output_path)
            stored_outputs.append((stored.columns, stored.collect()))
        # SNS wraps the event JSON in a second JSON envelope under the "default" key.
        payloads = [
            json.loads(json.loads(call.kwargs["Message"])["default"])
            for call in sns.return_value.publish.call_args_list
        ]

    # Assert
    assert len(payloads) == 12
    for index, (columns, rows) in enumerate(stored_outputs):
        assert columns == QAChecks.detail_schema.fieldNames()
        assert len(rows) == 6
        assert {row.outcome for row in rows} == {"fail" if index == 0 else "pass"}
        if index == 0:
            for row in rows:
                if row.name.startswith(Config.OFFER_VS_BRAND_SALES_CHECK):
                    failures = metadata(row)["breaches"]
                elif row.name in {
                    f"{name}_post" for name in (Config.ROAS_CHECK, Config.IROAS_CHECK, Config.EXPOSED_SALES_UPLIFT_CHECK)
                }:
                    failures = metadata(row)["failed_rows"]
                else:
                    assert metadata(row)["failed_count"] == len(durations)
                    continue
                expected_count = len(durations) * (2 if row.name == f"{Config.ROAS_CHECK}_post" else 1)
                assert len(failures) == expected_count
                assert {failure["campaign_duration"] for failure in failures} == set(durations)
        stored_by_name = {
            row.name: {
                **row.asDict(), "load_timestamp": str(row.load_timestamp),
            }
            for row in rows
        }
        assert {
            event["name"]: {key: value for key, value in event.items() if key != "event_schema"}
            for event in payloads[index * 6:(index + 1) * 6]
        } == stored_by_name
    # Assert: reruns change outcomes, not upsert keys, so downstream rows are updated.
    keys = [(event["correlation_id"], event["type"], event["name"]) for event in payloads]
    assert set(keys[:6]) == set(keys[6:])
    assert len(set(keys)) == 6
    assert {event["outcome"] for event in payloads[:6]} == {"fail"}
    assert {event["outcome"] for event in payloads[6:]} == {"pass"}
    for event in payloads:
        assert event["type"] == "analytics"
        assert event["name"].endswith(f"_{campaign_period.lower()}")
        assert event["event_schema"]["write_operation"] == "upsert"
        assert event["event_schema"]["table_schema"]["additional_metadata"] == "jsonb"
        assert event["event_schema"]["table_schema"]["load_timestamp"] == "timestamp"
        assert isinstance(event["load_timestamp"], str)
        assert "load_ts" not in event
        assert "load_ts" not in event["event_schema"]["table_schema"]
        metadata_key = "breaches" if event["name"].startswith(Config.OFFER_VS_BRAND_SALES_CHECK) else "failed_rows"
        assert isinstance(json.loads(event["additional_metadata"])[metadata_key], list)
