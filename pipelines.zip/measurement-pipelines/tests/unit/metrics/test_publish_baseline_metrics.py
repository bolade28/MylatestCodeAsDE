from datetime import date
from pyspark.sql import SparkSession
from unittest import mock
from unittest.mock import Mock

from spark_pipeline.schemas.campaign_selection import CampaignSelection
from spark_pipeline.metrics.publish_baseline_metrics import publish_baseline_metrics
from spark_pipeline.utils.baseline_events import CampaignMetrics, UCMIncrementalityMetrics


@mock.patch('spark_pipeline.metrics.publish_baseline_metrics.MetricsPublisher')
def test_publish_baseline_metrics_success(mock_publisher_class, spark_session: SparkSession, tmp_dir: str):
    """Publishes the standard campaign-selection metrics when incrementality inputs are not provided."""

    mock_publisher = Mock()
    mock_publisher_class.return_value = mock_publisher

    correlation_id = "test-correlation-123"
    campaign_path = f"{tmp_dir}/campaign-selection"
    topic_arn = "arn:aws:sns:us-east-1:123456789012:test-topic"
    baseline_output_path = f"{tmp_dir}/baseline-modelling-output-empty"
    shrinkage_output_path = f"{tmp_dir}/incremental-shrinkage-output-empty"

    # Updated campaign selection schema with None values for all dates, so UCM incrementality returns None.
    campaign_selection_data = [
        ("MCCOYS|KP SNACKS", "CRISPS & SNACKS", "CLUSTERING", "NULL", None, None, None),
        ("GOLDEN WONDER|KP SNACKS", "CRISPS & SNACKS", "CLUSTERING", "NULL", None, None, None),
        ("HOWDAH|HOWDAH SNACKS", "CRISPS & SNACKS", "NEW_LAUNCH", "NULL", None, None, None),
        ("SNACK A JACKS|PEPSICO", "CRISPS & SNACKS", "REFACTORING", "NULL", None, None, None),
        ("KIND|MARS", "BEVERAGES", "NEW_LAUNCH_WITH_NO_SALES", "NULL", None, None, None),
    ]
    (
        spark_session
        .createDataFrame(campaign_selection_data, schema=CampaignSelection.campaign_selection_with_dates_schema)
        .write
        .mode("overwrite")
        .parquet(campaign_path)
    )

    # Baseline output with no best-iteration rows — incrementality aggregation returns None.
    spark_session.createDataFrame(
        [{"week_start_dt": date(2024, 6, 3), "metric_name": "TOTAL_INCREMENTAL_AMT", "metric_value": 5.0, "best_iteration": "N"}]
    ).write.mode("overwrite").parquet(baseline_output_path)

    # Shrinkage output with no rows whose metric_name matches what we query — returns None.
    spark_session.createDataFrame(
        [{"metric_name": "unrelated_metric", "metric_value": 0.0}]
    ).write.mode("overwrite").parquet(shrinkage_output_path)

    publish_baseline_metrics(
        spark=spark_session,
        campaign_selection_path=campaign_path,
        baseline_modelling_output_path=baseline_output_path,
        incremental_shrinkage_output_path=shrinkage_output_path,
        metrics_topic_arn=topic_arn,
        correlation_id=correlation_id,
        unified_campaign_path=f"{tmp_dir}/unified-campaigns",
        manual_campaign_list=["campaign1", "campaign2"],
        manual_run_flag=False,
    )
    # Verify
    # Check that MetricsPublisher was initialized with correct topic_arn
    mock_publisher_class.assert_called_once_with(topic_arn=topic_arn)

    # Check that publish_event was called the expected number of times
    # Should be called 2 times total (2 metrics)
    # 0 UCM incrementality events (all values resolved to None).
    assert mock_publisher.publish_event.call_count == 2

    calls = mock_publisher.publish_event.call_args_list
    # Check unique brand names metric
    first_call = calls[0]
    assert first_call[1]['message_subject'] == "Campaign Metrics Event"
    assert isinstance(first_call[1]['event'], CampaignMetrics)
    assert first_call[1]['event'].name == "unique_brand_names"
    assert first_call[1]['event'].value == 5  # Should count distinct brand names

    # Check unique super category metric
    second_call = calls[1]
    assert second_call[1]['event'].name == "unique_super_category"
    assert second_call[1]['event'].value == 2  # Should count distinct super categories


@mock.patch('spark_pipeline.metrics.publish_baseline_metrics.MetricsPublisher')
def test_publish_baseline_metrics_publishes_ucm_incrementality_metrics(
    mock_publisher_class,
    spark_session: SparkSession,
    tmp_dir: str,
):
    """
    Publish all three UCM incrementality events with complete JSON-safe metadata.

    Verifies that:
    - Exactly 5 events are published (2 campaign-selection + 3 incrementality).
    - All three incrementality events carry the ``UCM Incrementality Metrics Event`` subject.
    - Event values match the fixture data written to baseline modelling output and
      incremental shrinkage output parquets.
    - The shared metadata payload contains ISO-8601 date strings (not raw date objects)
    """
    mock_publisher = Mock()
    mock_publisher_class.return_value = mock_publisher

    correlation_id = "test-correlation-456"
    topic_arn = "arn:aws:sns:us-east-1:123456789012:test-topic"
    campaign_path = f"{tmp_dir}/campaign-selection-ucm"
    baseline_output_path = f"{tmp_dir}/baseline-modelling-output"
    incremental_shrinkage_output_path = f"{tmp_dir}/incremental-shrinkage-output"

    campaign_selection_data = [
        {
            "unique_brand_name": "BRAND A",
            "super_category_name": "SUPER CAT",
            "sub_category_name": "SUB CAT",
            "final_status": "CLUSTERING",
            "product_type": "offer",
            "min_campaign_start_dt": date(2024, 6, 5),
            "max_campaign_end_dt": date(2024, 6, 20),
            "max_post_campaign_dt": date(2024, 6, 27),
        }
    ]
    spark_session.createDataFrame(
        campaign_selection_data,
        schema=CampaignSelection.campaign_selection_with_dates_schema
    ).write.mode("overwrite").parquet(campaign_path)

    # Baseline output: two best-iteration rows (sum = 30) and one non-best row (excluded).
    baseline_output_data = [
        {"week_start_dt": date(2024, 6, 3), "super_category_name": "SUPER CAT", "unique_brand_name": "BRAND A", "metric_name": "TOTAL_INCREMENTAL_AMT", "metric_value": 10.0, "best_iteration": "Y"},
        {"week_start_dt": date(2024, 6, 10), "super_category_name": "SUPER CAT", "unique_brand_name": "BRAND A", "metric_name": "TOTAL_INCREMENTAL_AMT", "metric_value": 20.0, "best_iteration": "Y"},
        {"week_start_dt": date(2024, 6, 10), "super_category_name": "SUPER CAT", "unique_brand_name": "BRAND A", "metric_name": "TOTAL_INCREMENTAL_AMT", "metric_value": 999.0, "best_iteration": "N"},
    ]
    spark_session.createDataFrame(baseline_output_data).write.mode("overwrite").parquet(baseline_output_path)

    # Shrinkage output: raw UCM (30.0) and calibrated (25.0) incrementality rows.
    incremental_shrinkage_output_data = [
        {"metric_name": "ucm_incrementality", "metric_value": 30.0},
        {"metric_name": "calibrated_incrementality", "metric_value": 25.0},
    ]
    spark_session.createDataFrame(incremental_shrinkage_output_data).write.mode("overwrite").parquet(incremental_shrinkage_output_path)

    publish_baseline_metrics(
        spark=spark_session,
        campaign_selection_path=campaign_path,
        baseline_modelling_output_path=baseline_output_path,
        incremental_shrinkage_output_path=incremental_shrinkage_output_path,
        metrics_topic_arn=topic_arn,
        correlation_id=correlation_id,
        unified_campaign_path=f"{tmp_dir}/unified-campaigns",
        manual_campaign_list=[],
        manual_run_flag=False,
    )

    # 2 campaign-selection events + 3 UCM incrementality events.
    assert mock_publisher.publish_event.call_count == 5

    incrementality_calls = mock_publisher.publish_event.call_args_list[-3:]
    incrementality_events = {
        call.kwargs["event"].name: call.kwargs["event"]
        for call in incrementality_calls
    }

    assert set(incrementality_events.keys()) == {
        "ucm_incrementality",
        "calibrated_incrementality",
        "raw_incrementality_from_calibration",
    }

    for call in incrementality_calls:
        assert call.kwargs["message_subject"] == "UCM Incrementality Metrics Event"
        assert isinstance(call.kwargs["event"], UCMIncrementalityMetrics)

    # ucm_incrementality comes from baseline modelling output (best_iteration=Y rows only).
    assert incrementality_events["ucm_incrementality"].value == 30.0
    assert incrementality_events["calibrated_incrementality"].value == 25.0
    # raw_incrementality_from_calibration is the shrinkage parquet's "ucm_incrementality" row.
    assert incrementality_events["raw_incrementality_from_calibration"].value == 30.0

    # Validate the shared metadata payload is complete and JSON-safe.
    metadata = incrementality_events["ucm_incrementality"].metadata
    assert metadata["unique_brand_count"] == 1
    assert metadata["unique_brand_names"] == ["BRAND A"]
    # Dates must be ISO-8601 strings, not raw date objects (which are not JSON-serialisable).
    assert metadata["min_campaign_start_dt"] == "2024-06-05"
    assert metadata["max_campaign_end_dt"] == "2024-06-20"
    assert metadata["max_post_campaign_dt"] == "2024-06-27"
    assert incrementality_events["ucm_incrementality"].event_schema["table_schema"]["metadata"] == "jsonb"


def test_campaign_metrics_creation():
    """Test that CampaignMetrics objects are created correctly"""
    correlation_id = "test-123"

    # Test with value
    metric_with_value = CampaignMetrics(
        correlation_id=correlation_id,
        name="test_metric",
        value=42.5
    )

    assert metric_with_value.correlation_id == correlation_id
    assert metric_with_value.name == "test_metric"
    assert metric_with_value.value == 42.5
    assert metric_with_value.int_value is None
    assert metric_with_value.type is None

    # Test with int_value and type
    metric_with_int = CampaignMetrics(
        correlation_id=correlation_id,
        name="status_count",
        int_value=10,
        type="campaign_status"
    )

    assert metric_with_int.correlation_id == correlation_id
    assert metric_with_int.name == "status_count"
    assert metric_with_int.value is None
    assert metric_with_int.int_value == 10
    assert metric_with_int.type == "campaign_status"
