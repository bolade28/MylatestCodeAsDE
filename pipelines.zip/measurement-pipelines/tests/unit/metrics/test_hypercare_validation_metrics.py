import json

import pytest
from chispa import assert_df_equality
from pyspark.sql import types as T, functions as F

from spark_pipeline.common.variables import (
    HypercareValidationConfig as Config,
    RecalibrationFactorsConfig,
    ValidationStatus,
)
from spark_pipeline.metrics.qa_validation_metrics.hypercare_validation_metrics.hypercare_validation_metrics import (
    check_attributed_vs_recalibrated_sales,
    check_booking_id,
    check_channel_coverage,
    check_channel_dominance,
    check_correlation_id,
    check_conversion_rates,
    check_brand_vs_offer_sales,
    check_incremental_sales,
    check_near_zero_sales,
    check_iroas,
    check_media_spend,
    check_missing_inscope_subchannel,
    check_post_period_conversions,
    check_post_period_incremental_sales,
    check_post_period_sales,
    check_recalibration_factor,
    check_roas,
    check_rounded_media_spend,
    check_subchannel_consistency,
    check_units_per_conversion,
    recalibration_expected_value,
    resolve_booking_subchannels,
    run_hypercare_validation_checks,
)
from spark_pipeline.metrics import publish_hypercare_validation as hypercare_publisher
from spark_pipeline.schemas.qa_checks import QAChecks
from spark_pipeline.metrics.utils.shared_helper import (
    ThresholdBounds,
    calculate_iroas,
    evaluate_brand_offer_sales,
    evaluate_conversion_rate_thresholds,
    evaluate_expected_value,
    evaluate_incremental_sales,
    evaluate_iroas_thresholds,
    get_threshold_violations,
    safe_ratio,
)


INPUT_SCHEMA = T.StructType([
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("correlation_id", T.StringType(), True),
    T.StructField("journey_type", T.StringType(), True),
    T.StructField("campaign_duration", T.StringType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("attributed_recalibrated_sales_amt", T.DoubleType(), True),
    T.StructField("conversions_recalibrated", T.DoubleType(), True),
    T.StructField("conversion_rate", T.DoubleType(), True),
    T.StructField("marketing_type", T.StringType(), True),
    T.StructField("incremental_sales_amt_exposed", T.DoubleType(), True),
    T.StructField("iroas_exposed", T.DoubleType(), True),
])


def make_df(spark, rows=None):
    if rows is None:
        rows = [("123", "run-1", "BRAND", "During", "META", 90.0),
                ("123", "run-1", "BRAND", "During", "INSTORE", 10.0)]
    rows = [row + (None,) * 5 if len(row) == 6 else row for row in rows]
    return spark.createDataFrame(rows, INPUT_SCHEMA)


def test_union_has_ten_schema_compatible_alert_rows(spark_session):
    """All ten checks retain the QA schema and leave details empty."""
    result = run_hypercare_validation_checks(make_df(spark_session), "run-1")
    expected_details = spark_session.createDataFrame(
        [("",)], schema=T.StructType([QAChecks.detail_schema["details"]]),
    )
    assert_df_equality(result.select("details").distinct(), expected_details, ignore_nullable=True)
    assert result.columns == QAChecks.detail_schema.fieldNames()
    assert [field.dataType for field in result.schema] == [field.dataType for field in QAChecks.detail_schema]
    rows = result.collect()
    assert len(rows) == len({row.name for row in rows}) == 10
    assert {row.type for row in rows} == {"hypercare"}
    assert all(row.load_timestamp is not None for row in rows)
    assert all(json.loads(row.additional_metadata) for row in rows)
    assert {row.name: row.outcome for row in rows}["channel_dominance_during"] == "warning"


def test_sample_details_are_serialized_as_metadata_comments(spark_session):
    """Every former details message in the single-channel example is serialized as metadata.comment."""
    correlation_id = "923b3200-3613-4a84-bd20-339cd3c9de5e"
    booking_id = "6a7f4dee2389b6c2b520ebce"
    sales = 9673.991284151725
    reporting_df = make_df(spark_session, [
        (booking_id, correlation_id, "BRAND", "During", "social", sales,
         sales / 8.895780364475183, 2.0, "offsite", 100.0, 0.038757435777132636),
    ])
    expected_comments = {
        "booking_id_during": f"Distinct booking IDs: {booking_id}",
        "correlation_id_during": "Correlation ID matches the expected run.",
        "channel_coverage_during": "Channels present: social",
        "near_zero_sales_during": "No near-zero attributed sales detected.",
        "channel_dominance_during": "Single-channel campaign; dominance warning does not apply.",
        "units_per_conversion_during": "Min: 8.896 | Max: 8.896 | Spread (max/min): 1.0x",
        "brand_vs_offer_sales_during": "OK  Brand >= Offer for all channels.",
        "conversion_rate_during": "OK Conversion rates within expected ranges.",
        "incremental_sales_during": "OK Incremental sales within expected range for all channels.",
        "iroas_during": "OK iROAS = 0.04",
    }
    expected_df = spark_session.range(1).select(F.explode(F.array(*[
        F.struct(
            F.lit(name).alias("name"), F.lit("pass").alias("outcome"),
            F.lit("").alias("details"), F.lit(comment).alias("comment"),
        )
        for name, comment in expected_comments.items()
    ])).alias("check")).select("check.*")

    result = run_hypercare_validation_checks(reporting_df, correlation_id).select(
        "name", "outcome", "details",
        F.from_json(F.col("additional_metadata"), "comment STRING").getField("comment").alias("comment"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True, ignore_row_order=True)


def test_publish_hypercare_validation_writes_and_publishes_all_check_rows(
    spark_session, tmp_path, monkeypatch,
):
    """Persist all ten QA checks and publish matching SNS events for one run."""
    reporting_df = make_df(spark_session)
    reporting_path = str(tmp_path / "reporting")
    output_path = str(tmp_path / "validation")
    reporting_df.write.parquet(reporting_path)
    published_events = []

    class FakeMetricsPublisher:
        def __init__(self, topic_arn):
            self.topic_arn = topic_arn

        def publish_event(self, message_subject, event):
            published_events.append((message_subject, event))

    slack_messages = []

    class FakeSlackMessenger:
        def __init__(self, topic_arn, correlation_id):
            self.topic_arn = topic_arn
            self.correlation_id = correlation_id

        def send_message(self, **kwargs):
            slack_messages.append(kwargs)

    monkeypatch.setattr(hypercare_publisher, "MetricsPublisher", FakeMetricsPublisher)
    monkeypatch.setattr(hypercare_publisher, "SlackMessenger", FakeSlackMessenger)

    hypercare_publisher.publish_hypercare_validation(
        spark=spark_session,
        measurement_campaign_reporting_path=reporting_path,
        reach_engagement_path="unused-reach-engagement-path",
        campaign_period="During",
        booking_id="123",
        correlation_id="run-1",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack",
        output_path=output_path,
    )

    expected_df = run_hypercare_validation_checks(reporting_df, "run-1")
    output_df = spark_session.read.parquet(output_path)
    assert_df_equality(
        output_df.drop("load_timestamp"), expected_df.drop("load_timestamp"),
        ignore_nullable=True, ignore_row_order=True,
    )
    assert len(published_events) == 10
    detail_events = [event for _, event in published_events if hasattr(event, "outcome")]
    assert len(detail_events) == 10
    assert {subject for subject, event in published_events if hasattr(event, "outcome")} == {
        "Hypercare Validation Metric Event",
    }
    assert {
        (event.name, event.outcome)
        for event in detail_events
    } == {
        (row.name, row.outcome)
        for row in expected_df.select("name", "outcome").collect()
    }
    assert all(event.event_schema["table_name"] == "qa_validation_check_metrics_upsert" for event in detail_events)
    assert all(event.event_schema["schema"] == "metrics" for event in detail_events)
    assert all(event.event_schema["write_operation"] == "upsert" for event in detail_events)
    assert all(event.load_timestamp for event in detail_events)
    assert all(event.details == "" for event in detail_events)
    assert all(event.event_schema["table_schema"]["load_timestamp"] == "timestamp" for event in detail_events)
    assert all("load_ts" not in vars(event) for event in detail_events)
    assert len(slack_messages) == 1
    slack_call = slack_messages[0]
    assert slack_call["event_type"] == "Hypercare Validation Metrics Status"
    assert slack_call["data"]["checks_run"] == 10
    assert set(slack_call["data"]["status_counts"]) == {
        status.value for status in ValidationStatus
    }
    assert slack_call["data"]["status_counts"][ValidationStatus.WARNING.value] == 1
    assert slack_call["data"]["status_counts"][ValidationStatus.FAIL.value] == 0
    assert "10 checks run" in slack_call["text"]
    assert all(status.value in slack_call["text"] for status in ValidationStatus)


@pytest.mark.parametrize("ids,expected", [
    ([], "fail"), ([None], "fail"), (["123"], "pass"), (["123", "456"], "warning"),
    (["456", "123", "456", None], "warning"),
])
def test_booking_id_outcomes(spark_session, ids, expected):
    """Booking checks retain every distinct non-null ID, sorted, alongside counts and the outcome."""
    df = make_df(spark_session, [(identifier, "run-1", "BRAND", "During", "META", 1.0) for identifier in ids])
    distinct_ids = sorted({identifier for identifier in ids if identifier is not None})
    expected_df = spark_session.range(1).select(
        F.lit(expected).alias("outcome"),
        F.lit("").alias("details"),
        F.struct(
            F.lit(len(distinct_ids)).cast("long").alias("distinct_count"),
            F.array(*[F.lit(identifier) for identifier in distinct_ids])
            .cast("array<string>").alias("distinct_booking_ids"),
            F.lit(ids.count(None)).cast("long").alias("null_count"),
        ).alias("metadata"),
    )

    result = check_booking_id(df, "run-1").select(
        "outcome", "details",
        F.from_json(
            F.col("additional_metadata"),
            "distinct_count LONG, distinct_booking_ids ARRAY<STRING>, null_count LONG",
        ).alias("metadata"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


def test_booking_id_scopes_to_run_but_correlation_check_sees_mismatch(spark_session):
    """Booking IDs are scoped to the requested run while the correlation check inspects all input rows."""
    df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", 1.0),
        ("456", "other-run", "BRAND", "During", "META", 1.0),
    ])

    booking_result = check_booking_id(df, "run-1").first()
    correlation_result = check_correlation_id(df, "run-1").first()

    assert booking_result.outcome == "pass"
    assert correlation_result.outcome == "fail"


@pytest.mark.parametrize("ids,expected", [
    ([], "fail"), ([None], "fail"), (["run-1"], "pass"),
    (["other"], "fail"), (["run-1", "other"], "fail"), (["run-1", None], "fail"),
])
def test_correlation_id_outcomes(spark_session, ids, expected):
    df = make_df(spark_session, [("123", identifier, "BRAND", "During", "META", 1.0) for identifier in ids])
    assert check_correlation_id(df, "run-1").first().outcome == expected


def test_channel_coverage_uses_brand_and_exact_period(spark_session):
    df = make_df(spark_session, [("123", "run-1", "OFFER", "During", "META", 1.0),
                                 ("123", "run-1", "BRAND", "Post", "INSTORE", 1.0)])
    assert check_channel_coverage(df, "run-1").first().outcome == "fail"
    row = check_channel_coverage(df, "run-1", "Post").first()
    assert row.outcome == "pass"
    assert json.loads(row.additional_metadata)["channels"] == ["INSTORE"]
    assert row.name.endswith("_post")


def test_runner_accepts_offer_journey_type(spark_session):
    df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", 90.0),
        ("123", "run-1", "OFFER", "During", "COUPON", 10.0),
    ])

    result = run_hypercare_validation_checks(df, "run-1", journey_type="OFFER")

    coverage = result.filter("name = 'channel_coverage_during'").first()
    assert coverage.outcome == "pass"
    assert json.loads(coverage.additional_metadata)["channels"] == ["COUPON"]


@pytest.mark.parametrize("pairs,threshold,outcome,minimum,maximum,spread", [
    ([(6.0, 1.0), (1.0, 1.0)], 3.0, "warning", 1.0, 6.0, 6.0),
    ([(-2.0, 1.0), (6.0, 1.0)], 3.0, "fail", -2.0, 6.0, -3.0),
    ([(2.0, 1.0), (6.0, 1.0)], 3.0, "pass", 2.0, 6.0, 3.0),
    ([(2.0, 1.0), (6.0, 1.0)], 2.0, "warning", 2.0, 6.0, 3.0),
    ([(0.0, 1.0), (6.0, 1.0)], 3.0, "pass", 0.0, 6.0, None),
    ([(6.0, 0.0)], 3.0, "pass", None, None, None),
    ([(None, 1.0), (6.0, None)], 3.0, "pass", None, None, None),
    ([], 3.0, "pass", None, None, None),
    ([(2.0, 1.0), (None, 1.0), (6.0, 0.0)], 3.0, "pass", 2.0, 2.0, 1.0),
    ([(1.23456, 1.0), (2.46912, 1.0)], 3.0, "pass", 1.23456, 2.46912, 2.0),
])
def test_units_per_conversion_matches_sql_check_06(
    spark_session, pairs, threshold, outcome, minimum, maximum, spread,
):
    """Row-level ratios preserve status, nulls and raw metadata while details stays empty."""
    reporting_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", sales, conversions, None, None, None, None)
        for sales, conversions in pairs
    ])
    expected_df = spark_session.range(1).select(
        F.lit(outcome).alias("outcome"),
        F.lit("").alias("details"),
        F.struct(
            F.lit(minimum).cast("double").alias("minimum_ratio"),
            F.lit(maximum).cast("double").alias("maximum_ratio"),
            F.lit(spread).cast("double").alias("spread"),
            F.lit(threshold).alias("threshold"),
            F.lit("undefined_ratio_spread" if spread is None else None).cast("string").alias("reason"),
        ).alias("metadata"),
    )

    result = check_units_per_conversion(reporting_df, "run-1", threshold=threshold).select(
        "outcome", "details",
        F.from_json(
            F.col("additional_metadata"),
            "minimum_ratio DOUBLE, maximum_ratio DOUBLE, spread DOUBLE, threshold DOUBLE, reason STRING",
        ).alias("metadata"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("brand,offer,precision,expected_brand,expected_offer,exceeds,equal", [
    (100.0, 100.004, None, 100.0, 100.004, True, False),
    (100.0, 100.004, 2, 100.0, 100.0, False, True),
    (100.0, 99.0, 2, 100.0, 99.0, False, False),
    (None, 100.0, 2, None, 100.0, None, None),
    (100.0, None, None, 100.0, None, None, None),
])
def test_evaluate_brand_offer_sales_preserves_rounding_and_nulls(
    spark_session, brand, offer, precision, expected_brand, expected_offer, exceeds, equal,
):
    """Shared comparison preserves optional rounding and SQL null comparison semantics."""
    reporting_df = spark_session.range(1).select(
        F.lit(brand).cast("double").alias("brand_sales"),
        F.lit(offer).cast("double").alias("offer_sales"),
    )
    expected_df = spark_session.range(1).select(
        F.lit(expected_brand).cast("double").alias("brand_sales"),
        F.lit(expected_offer).cast("double").alias("offer_sales"),
        F.lit(exceeds).cast("boolean").alias("offer_exceeds_brand"),
        F.lit(equal).cast("boolean").alias("sales_equal"),
    )

    result = evaluate_brand_offer_sales(reporting_df, decimal_places=precision)

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("sales,channel_count,breach_count,breaches", [
    ([("META", "BRAND", 100.0), ("META", "OFFER", 100.01)], 1, 1, [("META", 100.0, 100.01)]),
    ([("META", "BRAND", 100.0), ("META", "OFFER", 100.004)], 1, 0, []),
    ([("META", "BRAND", 50.002), ("META", "BRAND", 50.002), ("META", "OFFER", 100.006)], 1, 1, [("META", 100.0, 100.01)]),
    ([("META", "brand", 100.0), ("META", "Offer", 101.0)], 1, 1, [("META", 100.0, 101.0)]),
    ([("META", " BRAND ", 100.0), ("META", "OFFER", 101.0)], 1, 0, []),
    ([("META", "BRAND", None), ("META", "OFFER", None)], 1, 0, []),
    ([("META", "BRAND", 100.0)], 1, 0, []),
    ([("META", "OFFER", 100.0)], 1, 0, []),
    ([(None, "BRAND", 100.0), (None, "OFFER", 101.0)], 1, 1, [(None, 100.0, 101.0)]),
    ([("B", "BRAND", 100.0), ("B", "OFFER", 101.0), ("A", "BRAND", 50.0), ("A", "OFFER", 51.0)], 2, 2, [("A", 50.0, 51.0), ("B", 100.0, 101.0)]),
    ([], 0, 0, []),
])
def test_brand_vs_offer_sales_matches_sql_check_07(
    spark_session, sales, channel_count, breach_count, breaches,
):
    """SQL channel sums are rounded before comparison; empty or incomplete pairs pass."""
    reporting_df = make_df(spark_session, [
        ("123", "run-1", journey_type, "During", channel, amount, None, None, None, None, None)
        for channel, journey_type, amount in sales
    ])
    outcome = "fail" if breach_count else "pass"
    expected_df = spark_session.range(1).select(
        F.lit(outcome).alias("outcome"), F.lit("").alias("details"),
        F.struct(
            F.lit(channel_count).cast("long").alias("channel_count"),
            F.lit(breach_count).cast("long").alias("breach_count"),
            F.array(*[F.struct(
                F.lit(channel).cast("string").alias("channel"),
                F.lit(brand).alias("brand_sales"),
                F.lit(offer).alias("offer_sales"),
            ) for channel, brand, offer in breaches]).cast(
                "array<struct<channel:string,brand_sales:double,offer_sales:double>>",
            ).alias("breaches"),
        ).alias("metadata"),
    )

    result = check_brand_vs_offer_sales(reporting_df, "run-1").select(
        "outcome", "details",
        F.from_json(
            F.col("additional_metadata"),
            "channel_count LONG, breach_count LONG, "
            "breaches ARRAY<STRUCT<channel: STRING, brand_sales: DOUBLE, offer_sales: DOUBLE>>",
        ).alias("metadata"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


def test_brand_vs_offer_sales_supports_subchannel_grain_without_changing_channel_default(spark_session):
    """A surplus in one subchannel must not hide another subchannel's breach."""
    df = spark_session.createDataFrame([
        ("run-1", "META", "A", "Brand", 10.0),
        ("run-1", "META", "A", "Offer", 20.0),
        ("run-1", "META", "B", "Brand", 100.0),
        ("run-1", "META", "B", "Offer", 1.0),
        ("run-1", "OTHER", "A", "Brand", 1000.0),
        ("run-1", "OTHER", "A", "Offer", 1.0),
        ("run-1", "META", None, "Brand", 10.0),
        ("run-1", "META", None, "Offer", 11.0),
        ("other-run", "META", "A", "Brand", 1000.0),
    ], "correlation_id STRING, channel_name STRING, subchannel_name STRING, "
       "journey_type STRING, attributed_recalibrated_sales_amt DOUBLE")

    channel = check_brand_vs_offer_sales(df, "run-1").first()
    subchannel = check_brand_vs_offer_sales(
        df, "run-1", group_by_columns=("channel_name", "subchannel_name"),
    ).first()

    assert channel.outcome == "pass"
    assert json.loads(channel.additional_metadata)["channel_count"] == 2
    assert subchannel.outcome == "fail"
    assert subchannel.details == ""
    assert json.loads(subchannel.additional_metadata)["group_count"] == 4
    assert json.loads(subchannel.additional_metadata)["breaches"] == [
        {"channel": "META", "brand_sales": 10.0, "offer_sales": 11.0},
        {"channel": "META", "subchannel": "A", "brand_sales": 10.0, "offer_sales": 20.0},
    ]


def test_brand_vs_offer_sales_scopes_run_not_period(spark_session):
    """The SQL base_mcr scope includes all periods but only the requested correlation ID."""
    reporting_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", 100.0, None, None, None, None, None),
        ("123", "run-1", "OFFER", "Post", "META", 101.0, None, None, None, None, None),
        ("123", "other-run", "BRAND", "During", "META", 1000.0, None, None, None, None, None),
    ])
    expected_df = spark_session.range(1).select(
        F.lit("fail").alias("outcome"),
        F.lit("").alias("details"),
    )

    result = check_brand_vs_offer_sales(reporting_df, "run-1").select("outcome", "details")

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("positive_only,expected_rates", [(False, [-1.0, 0.0, 2.5]), (True, [2.5])])
@pytest.mark.parametrize("empty_input", [False, True])
def test_evaluate_conversion_rate_thresholds_filters_and_normalizes(spark_session, positive_only, expected_rates, empty_input):
    """Prepare string rates and mixed-case types, preserving nonpositive rates only when requested."""
    rates = [] if empty_input else [None, -1.0, 0.0, 2.5]
    reporting_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", 1.0, None, rate, " OnSiTe ", None, None)
        for rate in rates
    ]).withColumn("conversion_rate", F.col("conversion_rate").cast("string"))
    expected_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", 1.0, None, rate, " OnSiTe ", None, None)
        for rate in ([] if empty_input else expected_rates)
    ]).withColumn("marketing_type_lower", F.lit("onsite")).withColumn(
        "threshold_value", F.lit(None).cast("double"),
    ).withColumn("is_breach", F.lit(False))

    result = evaluate_conversion_rate_thresholds(reporting_df, thresholds={}, positive_only=positive_only)

    assert_df_equality(result, expected_df, ignore_nullable=True, ignore_row_order=True)


@pytest.mark.parametrize("marketing_type,rate,bounds,breached_threshold", [
    (" OnSiTe ", 1.0, (2.0, 8.0), 2.0),
    ("onsite", 2.0, (2.0, 8.0), None),
    ("onsite", 5.0, (2.0, 8.0), None),
    ("onsite", 8.0, (2.0, 8.0), None),
    ("onsite", 9.0, (2.0, 8.0), 8.0),
    ("onsite", 1.0, (None, 8.0), None),
    ("onsite", 99.0, (2.0, None), None),
    ("onsite", -1.0, (0.0, None), 0.0),
    ("unknown", 9.0, (2.0, 8.0), None),
    (None, 9.0, (2.0, 8.0), None),
])
def test_evaluate_conversion_rate_thresholds_evaluates_configured_bounds(
    spark_session, marketing_type, rate, bounds, breached_threshold,
):
    """Inclusive custom bounds flag breaches and retain nonbreaching or unknown-type rows."""
    reporting_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", 1.0, None, rate, marketing_type, None, None),
    ])
    normalized_type = marketing_type.strip().lower() if marketing_type is not None else None
    expected_df = (
        reporting_df
        .withColumn("marketing_type_lower", F.lit(normalized_type).cast("string"))
        .withColumn("threshold_value", F.lit(breached_threshold).cast("double"))
        .withColumn("is_breach", F.lit(breached_threshold is not None))
    )

    result = evaluate_conversion_rate_thresholds(
        reporting_df, thresholds={"onsite": ThresholdBounds(minimum=bounds[0], maximum=bounds[1])},
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("value,minimum,maximum,expected", [
    (-1.0, 0.0, None, 0.0),
    (0.0, 0.0, 10.0, None),
    (11.0, 0.0, 10.0, 10.0),
    (None, 0.0, 10.0, None),
    (11.0, None, None, None),
    (10.0, 10.0, 10.0, None),
])
def test_get_breached_threshold_supports_other_metrics(spark_session, value, minimum, maximum, expected):
    """The generic threshold expression handles sales values, nulls and disabled or equal bounds."""
    reporting_df = make_df(spark_session, [("123", "run-1", "BRAND", "During", "META", value)])
    expected_df = reporting_df.withColumn("threshold_value", F.lit(expected).cast("double"))

    result = reporting_df.withColumn(
        "threshold_value",
        get_threshold_violations(
            F.col("attributed_recalibrated_sales_amt"), ThresholdBounds(minimum=minimum, maximum=maximum),
        ),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("numerator,denominator,expected", [
    (6.0, 2.0, 3.0),
    (6.0, -2.0, -3.0),
    (0.0, 2.0, 0.0),
    (6.0, 0.0, None),
    (6.0, None, None),
    (None, 2.0, None),
])
def test_safe_ratio_guards_zero_and_missing_denominators(spark_session, numerator, denominator, expected):
    """Guarded division preserves negative denominators and returns null for undefined ratios."""
    reporting_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", numerator, denominator, None, None, None, None),
    ])
    expected_df = reporting_df.withColumn("ratio", F.lit(expected).cast("double"))

    result = reporting_df.withColumn(
        "ratio", safe_ratio(F.col("attributed_recalibrated_sales_amt"), F.col("conversions_recalibrated")),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("marketing_type,rate,expected", [
    ("OFFSITE", 3.0, "pass"),
    ("OFFSITE", 3.1, "warning"),
    ("OFFSITE", 5.0, "warning"),
    (" OnSiTe ", -1.0, "pass"),
    ("ONSITE", 0.0, "warning"),
    ("ONSITE", 1.0, "pass"),
    ("ONSITE", 10.0, "pass"),
    ("ONSITE", 10.1, "warning"),
    ("INSTORE", 0.0, "warning"),
    ("INSTORE", 35.0, "pass"),
    ("in-store", 0.0, "pass"),
    ("ONSITE", None, "pass"),
])
def test_conversion_rates_preserves_threshold_rules(spark_session, marketing_type, rate, expected):
    """Shared preparation preserves hypercare's limits, aliases and missing-rate outcome."""
    df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", 1.0, None, rate, marketing_type, None, None),
    ])
    expected_df = spark_session.createDataFrame(
        [(expected,)], schema=T.StructType([QAChecks.detail_schema["outcome"]]),
    )

    result = check_conversion_rates(df, "run-1").select("outcome")

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("rates,breach_count,affected_rates", [
    ([("META", "offsite", 3.1)], 1, [("META", "offsite", 3.1, 3.0)]),
    ([("META", "onsite", 0.0)], 1, [("META", "onsite", 0.0, 1.0)]),
    ([("META", "OnSiTe", 10.1)], 1, [("META", "onsite", 10.1, 10.0)]),
    ([("STORE", "instore", -1.0)], 1, [("STORE", "instore", -1.0, 1.0)]),
    ([("A", "offsite", 4.0), ("A", "offsite", 4.0), ("B", "onsite", 0.0), ("C", "onsite", 11.0), ("D", "instore", 0.0)], 5, [("A", "offsite", 4.0, 3.0), ("A", "offsite", 4.0, 3.0), ("B", "onsite", 0.0, 1.0), ("C", "onsite", 11.0, 10.0), ("D", "instore", 0.0, 1.0)]),
    ([(None, "offsite", 4.0)], 1, [(None, "offsite", 4.0, 3.0)]),
    ([(None, "offsite", 4.0), ("META", "offsite", 5.0)], 2, [(None, "offsite", 4.0, 3.0), ("META", "offsite", 5.0, 3.0)]),
    ([("A", "offsite", 3.0), ("B", "onsite", 1.0), ("C", "onsite", 10.0),
      ("D", "instore", 1.0)], 0, []),
    ([("META", " OFFSITE ", 4.0), ("META", "unknown", 99.0), ("META", None, 99.0)], 0, []),
    ([("META", "ONSITE", None)], 0, []),
    ([], 0, []),
])
def test_conversion_rates_matches_sql_check_08_metadata_with_empty_details(
    spark_session, rates, breach_count, affected_rates,
):
    """Structured rate breaches preserve duplicates, null channels, numeric bounds and empty details."""
    reporting_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", channel, 1.0, None, rate, marketing_type, None, None)
        for channel, marketing_type, rate in rates
    ])
    outcome = "warning" if breach_count else "pass"
    value_count = sum(rate is not None for _, _, rate in rates)
    expected_df = spark_session.range(1).select(
        F.lit(outcome).alias("outcome"), F.lit("").alias("details"),
        F.struct(
            F.lit(value_count).cast("long").alias("value_count"),
            F.lit(breach_count).cast("long").alias("breach_count"),
            F.array(*[F.struct(
                F.lit(channel).cast("string").alias("channel"),
                F.lit(marketing_type).alias("marketing_type"),
                F.lit(rate).alias("conversion_rate"),
                F.lit(threshold).alias("threshold"),
            ) for channel, marketing_type, rate, threshold in affected_rates]).cast(
                "array<struct<channel:string,marketing_type:string,conversion_rate:double,threshold:double>>",
            ).alias("affected_rates"),
            F.struct(
                F.lit(Config.OFFSITE_CONVERSION_RATE_WARNING).cast("double").alias("offsite_maximum"),
                F.lit(Config.ONSITE_CONVERSION_RATE_MIN).cast("double").alias("onsite_minimum"),
                F.lit(Config.ONSITE_CONVERSION_RATE_MAX).cast("double").alias("onsite_maximum"),
                F.lit(Config.INSTORE_CONVERSION_RATE_MIN).cast("double").alias("instore_minimum"),
            ).alias("thresholds"),
        ).alias("metadata"),
    )

    result = check_conversion_rates(reporting_df, "run-1").select(
        "outcome", "details",
        F.from_json(
            F.col("additional_metadata"),
            "value_count LONG, breach_count LONG, "
            "affected_rates ARRAY<STRUCT<channel: STRING, marketing_type: STRING, "
            "conversion_rate: DOUBLE, threshold: DOUBLE>>, "
            "thresholds STRUCT<offsite_maximum: DOUBLE, onsite_minimum: DOUBLE, "
            "onsite_maximum: DOUBLE, instore_minimum: DOUBLE>",
        ).alias("metadata"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("pairs,threshold,outcome,fail_count,warning_count", [
    ([("META", 150.0, 100.0)], 0.5, "fail", 1, 1),
    ([("META", 100.0, 100.0)], 0.5, "warning", 0, 1),
    ([("META", 50.0, 100.0)], 0.5, "warning", 0, 1),
    ([("META", 49.99, 100.0)], 0.5, "pass", 0, 0),
    ([("META", 1.0, 0.0)], 0.5, "fail", 1, 0),
    ([("META", 0.0, 0.0)], 0.5, "pass", 0, 0),
    ([("META", None, 100.0), ("META", 50.0, None)], 0.5, "pass", 0, 0),
    ([], 0.5, "pass", 0, 0),
    ([("META", 60.0, 100.0), ("META", 0.0, 1000.0)], 0.5, "warning", 0, 1),
    ([("B", 110.0, 100.0), ("A", 120.0, 100.0)], 0.5, "fail", 2, 2),
    ([(None, 150.0, 100.0)], 0.5, "fail", 1, 1),
    ([(None, 50.0, 100.0)], 0.5, "warning", 0, 1),
    ([("META", -5.0, -10.0)], 0.5, "fail", 1, 1),
    ([("META", -10.0, -5.0)], 0.5, "warning", 0, 1),
    ([("META", 50.0, 100.0)], 0.75, "pass", 0, 0),
    ([("META", 75.0, 100.0)], 0.75, "warning", 0, 1),
])
def test_incremental_sales_matches_sql_check_09(
    spark_session, pairs, threshold, outcome, fail_count, warning_count,
):
    """SQL row-level comparisons preserve fail precedence, inclusive warnings, nulls and guarded ratios."""
    reporting_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", channel, attributed, None, None, None, incremental, None)
        for channel, incremental, attributed in pairs
    ])
    value_count = sum(incremental is not None and attributed is not None for _, incremental, attributed in pairs)
    sales_pairs = [
        {"channel": channel, "incremental_sales": incremental, "attributed_sales": attributed,
         "incremental_ratio": incremental / attributed if attributed != 0 else None}
        for channel, incremental, attributed in pairs
        if incremental is not None and attributed is not None
    ]
    failures = [pair for pair in sales_pairs if pair["incremental_sales"] > pair["attributed_sales"]]
    warnings = [
        pair for pair in sales_pairs
        if pair["incremental_ratio"] is not None and pair["incremental_ratio"] >= threshold
    ]
    affected_sales_schema = (
        "array<struct<channel:string,incremental_sales:double,attributed_sales:double,incremental_ratio:double>>"
    )
    expected_df = spark_session.range(1).select(
        F.lit(outcome).alias("outcome"), F.lit("").alias("details"),
        F.lit(f"<=100%; warn >= {threshold:.0%}").alias("expected_value"),
        F.struct(
            F.lit(value_count).cast("long").alias("value_count"),
            F.lit(fail_count).cast("long").alias("fail_count"),
            F.lit(warning_count).cast("long").alias("warning_count"),
            F.sort_array(F.from_json(F.lit(json.dumps(failures)), affected_sales_schema)).alias("failures"),
            F.sort_array(F.from_json(F.lit(json.dumps(warnings)), affected_sales_schema)).alias("warnings"),
            F.lit(threshold).alias("warning_threshold"),
        ).alias("metadata"),
    )

    result = check_incremental_sales(reporting_df, "run-1", warning_threshold=threshold).select(
        "outcome", "details", "expected_value",
        F.from_json(
            F.col("additional_metadata"),
            f"value_count LONG, fail_count LONG, warning_count LONG, failures {affected_sales_schema}, "
            f"warnings {affected_sales_schema}, warning_threshold DOUBLE",
        ).alias("metadata"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("fail_on_equal,expected_breach", [(False, False), (True, True)])
def test_evaluate_incremental_sales_parameterizes_equality(spark_session, fail_on_equal, expected_breach):
    """Equal inputs warn in hypercare but breach the MTA failure rule without applying a percentage warning."""
    reporting_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", 100.0, None, None, None, 100.0, None),
    ])
    expected_df = (
        reporting_df
        .withColumn("incremental_ratio", F.lit(1.0))
        .withColumn("incremental_breach", F.lit(expected_breach))
        .withColumn("incremental_warning", F.lit(False))
    )

    result = evaluate_incremental_sales(
        reporting_df, F.col("incremental_sales_amt_exposed"), F.col("attributed_recalibrated_sales_amt"),
        fail_on_equal=fail_on_equal,
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("values,threshold,outcome,maximum", [
    ([11.23456, None], 10.0, "warning", 11.23456),
    ([10.001], 10.0, "warning", 10.001),
    ([10.0], 10.0, "pass", 10.0),
    ([0.0], 10.0, "fail", 0.0),
    ([-2.0, -1.0], 10.0, "fail", -1.0),
    ([-2.0, 5.0], 10.0, "pass", 5.0),
    ([None], 10.0, "pass", None),
    ([], 10.0, "pass", None),
    ([6.0], 5.0, "warning", 6.0),
])
def test_iroas_matches_sql_check_10(spark_session, values, threshold, outcome, maximum):
    """iROAS uses the raw maximum for status and metadata, leaves details empty and passes missing inputs."""
    reporting_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", 1.0, None, None, None, None, value)
        for value in values
    ])
    expected_df = spark_session.range(1).select(
        F.lit(outcome).alias("outcome"), F.lit("").alias("details"),
        F.struct(
            F.lit(sum(value is not None for value in values)).cast("long").alias("value_count"),
            F.lit(maximum).cast("double").alias("maximum_iroas"),
            F.lit(threshold).alias("threshold"),
            F.lit("no_usable_iroas" if maximum is None else None).cast("string").alias("reason"),
        ).alias("metadata"),
    )

    result = check_iroas(reporting_df, "run-1", threshold=threshold).select(
        "outcome", "details",
        F.from_json(
            F.col("additional_metadata"), "value_count LONG, maximum_iroas DOUBLE, threshold DOUBLE, reason STRING",
        ).alias("metadata"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("value,minimum_inclusive,maximum_inclusive,below,above", [
    (0.0, False, True, True, False),
    (0.0, True, True, False, False),
    (-1.0, True, True, True, False),
    (10.0, True, True, False, False),
    (10.0, True, False, False, True),
    (11.0, True, True, False, True),
    (None, False, True, False, False),
])
def test_evaluate_iroas_thresholds_parameterizes_boundaries(
    spark_session, value, minimum_inclusive, maximum_inclusive, below, above,
):
    """Bound evaluation supports hypercare's nonpositive failure and MTA's negative-only failure."""
    reporting_df = make_df(spark_session, [
        ("123", "run-1", "BRAND", "During", "META", 1.0, None, None, None, None, value),
    ])
    expected_df = (
        reporting_df
        .withColumn("iroas_below_minimum", F.lit(below))
        .withColumn("iroas_above_maximum", F.lit(above))
    )
    bounds = ThresholdBounds(
        minimum=0.0, maximum=10.0, minimum_inclusive=minimum_inclusive, maximum_inclusive=maximum_inclusive,
    )

    result = evaluate_iroas_thresholds(reporting_df, F.col("iroas_exposed"), bounds)

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("incremental,spend,fallback,expected", [
    (100.0, 20.0, None, 5.0),
    (100.0, 0.0, None, None),
    (100.0, 0.0, 0.0, 0.0),
    (100.0, -20.0, 0.0, 0.0),
    (100.0, None, 0.0, 0.0),
    (None, 20.0, 0.0, None),
    (-100.0, 20.0, 0.0, -5.0),
])
def test_calculate_iroas_preserves_spend_policy(spark_session, incremental, spend, fallback, expected):
    """Positive-spend division preserves null sales and explicitly controls missing/nonpositive-spend fallback."""
    reporting_df = spark_session.range(1).select(
        F.lit(incremental).cast("double").alias("incremental_sales"),
        F.lit(spend).cast("double").alias("media_spend"),
    )
    expected_df = reporting_df.withColumn("iroas", F.lit(expected).cast("double"))

    result = reporting_df.withColumn(
        "iroas", calculate_iroas(F.col("incremental_sales"), F.col("media_spend"), nonpositive_spend_value=fallback),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("sales,expected", [(0.99, "warning"), (1.0, "pass"), (-1.0, "warning"), (None, "skipped")])
def test_near_zero_sales_boundaries(spark_session, sales, expected):
    df = make_df(spark_session, [("123", "run-1", "BRAND", "During", "META", sales)])
    assert check_near_zero_sales(df, "run-1").first().outcome == expected


@pytest.mark.parametrize("sales,expected", [
    ([80.0, 20.0], "pass"), ([80.01, 19.99], "warning"),
    ([100.0], "pass"), ([100.0, 0.0], "warning"),
    ([0.0, 0.0], "skipped"), ([100.0, -10.0], "skipped"),
    ([None, None], "skipped"), ([], "skipped"),
])
def test_dominance_boundaries(spark_session, sales, expected):
    df = make_df(spark_session, [("123", "run-1", "BRAND", "During", str(index), value)
                                 for index, value in enumerate(sales)])
    assert check_channel_dominance(df, "run-1").first().outcome == expected


def test_empty_input_returns_findings_not_exceptions(spark_session):
    rows = run_hypercare_validation_checks(make_df(spark_session, []), "run-1").collect()
    assert {row.name: row.outcome for row in rows} == {
        "booking_id_during": "fail", "correlation_id_during": "fail", "channel_coverage_during": "fail",
        "near_zero_sales_during": "skipped", "channel_dominance_during": "skipped",
        "units_per_conversion_during": "pass", "brand_vs_offer_sales_during": "pass",
        "conversion_rate_during": "pass", "incremental_sales_during": "pass", "iroas_during": "pass",
    }


@pytest.mark.parametrize("mismatch", ["missing_column", "wrong_type", "wrong_order", "extra_column"])
def test_runner_schema_mismatches_become_failed_alerts(spark_session, monkeypatch, mismatch):
    """Missing, extra, reordered or wrongly typed QA fields become schema-compatible failed alerts."""
    reporting_df = make_df(spark_session)
    valid_result = check_booking_id(reporting_df, "run-1")
    if mismatch == "missing_column":
        malformed_result = valid_result.drop("details")
    elif mismatch == "wrong_type":
        malformed_result = valid_result.withColumn("details", F.lit(1))
    elif mismatch == "wrong_order":
        malformed_result = valid_result.select(*reversed(valid_result.columns))
    else:
        malformed_result = valid_result.withColumn("extra", F.lit("unexpected"))
    monkeypatch.setattr(
        "spark_pipeline.metrics.qa_validation_metrics.hypercare_validation_metrics.hypercare_validation_metrics.check_booking_id",
        lambda reporting_df, correlation_id, campaign_period: malformed_result,
    )
    error_message = (
        f"QA schema mismatch: expected {QAChecks.detail_schema.simpleString()}, "
        f"got {malformed_result.schema.simpleString()}."
    )
    metadata_schema = "error_type STRING, error_message STRING, comment STRING"
    expected_metadata = {
        "error_type": "ValueError", "error_message": error_message,
        "comment": f"Check could not be evaluated: {error_message}",
    }
    expected_df = spark_session.range(1).select(
        F.lit("fail").alias("outcome"), F.lit("").alias("details"),
        F.from_json(F.lit(json.dumps(expected_metadata)), metadata_schema).alias("metadata"),
    )

    result = (
        run_hypercare_validation_checks(reporting_df, "run-1")
        .filter(F.col("name") == "booking_id_during")
        .select(
            "outcome", "details",
            F.from_json(F.col("additional_metadata"), metadata_schema).alias("metadata"),
        )
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


def test_missing_columns_become_alert_rows(spark_session):
    """Missing sales columns produce failed alerts with error metadata and empty details."""
    df = make_df(spark_session).drop("attributed_recalibrated_sales_amt")
    expected_df = spark_session.range(1).select(
        F.lit("fail").alias("outcome"),
        F.lit("").alias("details"),
        F.lit("AnalysisException").alias("error_type"),
        F.lit(True).alias("has_error_message"),
    )

    result = (
        run_hypercare_validation_checks(df, "run-1")
        .filter(F.col("name").isin("near_zero_sales_during", "channel_dominance_during"))
        .withColumn("metadata", F.from_json(
            F.col("additional_metadata"), "error_type STRING, error_message STRING",
        ))
        .select(
            "outcome", "details", F.col("metadata.error_type").alias("error_type"),
            (F.length(F.col("metadata.error_message")) > 0).alias("has_error_message"),
        )
    )

    assert_df_equality(result, expected_df.unionByName(expected_df), ignore_nullable=True)


@pytest.mark.parametrize("check_function,sales,expected_reason", [
    (check_near_zero_sales, None, "no_usable_sales"),
    (check_channel_dominance, None, "unusable_channel_sales"),
    (check_channel_dominance, 100.0, "single_channel"),
])
def test_check_reasons_live_in_metadata(spark_session, check_function, sales, expected_reason):
    """Skipped sales checks and single-channel exemptions retain reasons in metadata, not details."""
    reporting_df = make_df(spark_session, [("123", "run-1", "BRAND", "During", "META", sales)])
    expected_df = spark_session.range(1).select(
        F.lit("").alias("details"), F.lit(expected_reason).alias("reason"),
    )

    result = check_function(reporting_df, "run-1").select(
        "details",
        F.from_json(F.col("additional_metadata"), "reason STRING").getField("reason").alias("reason"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


@pytest.mark.parametrize("check_function,rows,expected_comment", [
    (check_correlation_id, [("123", "run-1", "BRAND", "During", "META", 100.0)],
     "Correlation ID matches the expected run."),
    (check_correlation_id, [("123", "other-run", "BRAND", "During", "META", 100.0)],
     "Expected correlation ID: run-1; observed IDs: other-run"),
    (check_channel_coverage, [("123", "run-1", "BRAND", "During", "META", 100.0)],
     "Channels present: META"),
    (check_channel_coverage, [], "No channels found for the requested journey type and period."),
])
def test_identity_and_coverage_comments_live_in_metadata(spark_session, check_function, rows, expected_comment):
    """Identity and coverage pass/fail messages live in metadata while details stays empty."""
    reporting_df = make_df(spark_session, rows)
    expected_df = spark_session.range(1).select(
        F.lit("").alias("details"), F.lit(expected_comment).alias("comment"),
    )

    result = check_function(reporting_df, "run-1").select(
        "details", F.from_json(F.col("additional_metadata"), "comment STRING").getField("comment").alias("comment"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


def test_correlation_metadata_contains_expected_and_observed_ids(spark_session):
    """A mismatched run retains expected and observed IDs in metadata with empty details."""
    reporting_df = make_df(spark_session, [("123", "other-run", "BRAND", "During", "META", 100.0)])
    metadata_schema = (
        "distinct_count LONG, correlation_ids ARRAY<STRING>, null_count LONG, expected_correlation_id STRING"
    )
    expected_metadata = {
        "distinct_count": 1, "correlation_ids": ["other-run"], "null_count": 0,
        "expected_correlation_id": "run-1",
    }
    expected_df = spark_session.range(1).select(
        F.lit("fail").alias("outcome"), F.lit("").alias("details"),
        F.from_json(F.lit(json.dumps(expected_metadata)), metadata_schema).alias("metadata"),
    )

    result = check_correlation_id(reporting_df, "run-1").select(
        "outcome", "details", F.from_json(F.col("additional_metadata"), metadata_schema).alias("metadata"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


def test_dominance_metadata_contains_leader_and_clean_channel_totals(spark_session):
    """Dominance metadata preserves all sales, shares and counts without the internal sort key."""
    reporting_df = make_df(spark_session)
    expected_metadata = {
        "channel_count": 2, "null_channel_count": 0, "null_sales_count": 0, "negative_channel_count": 0,
        "total_sales": 100.0, "leading_share": 0.9, "leading_channel": "META",
        "channel_totals": [{"channel": "META", "sales": 90.0}, {"channel": "INSTORE", "sales": 10.0}],
        "threshold": 0.8,
    }
    metadata_schema = F.schema_of_json(json.dumps(expected_metadata))
    expected_df = spark_session.range(1).select(
        F.lit("warning").alias("outcome"), F.lit("").alias("details"),
        F.from_json(F.lit(json.dumps(expected_metadata)), metadata_schema).alias("metadata"),
        F.lit(False).alias("has_sort_key"),
    )

    result = check_channel_dominance(reporting_df, "run-1").select(
        "outcome", "details", F.from_json(F.col("additional_metadata"), metadata_schema).alias("metadata"),
        F.from_json(
            F.col("additional_metadata"), "channel_totals ARRAY<MAP<STRING,STRING>>",
        ).getField("channel_totals").getItem(0).getItem("sort_sales").isNotNull().alias("has_sort_key"),
    )

    assert_df_equality(result, expected_df, ignore_nullable=True)


EXTENDED_INPUT_SCHEMA = T.StructType([
    *INPUT_SCHEMA.fields,
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("attributed_sales_amt", T.DoubleType(), True),
    T.StructField("media_spend_amt", T.DoubleType(), True),
    T.StructField("roas_exposed", T.DoubleType(), True),
    T.StructField("recalibration_factor", T.DoubleType(), True),
])


def make_reporting_row(
    booking_id="123",
    correlation_id="run-1",
    journey_type="BRAND",
    campaign_duration="During",
    channel_name="META",
    attributed_recalibrated_sales_amt=100.0,
    conversions_recalibrated=10.0,
    conversion_rate=2.0,
    marketing_type="offsite",
    incremental_sales_amt_exposed=10.0,
    iroas_exposed=1.0,
    campaign_id="campaign-1",
    subchannel_name="Meta Social",
    attributed_sales_amt=100.0,
    media_spend_amt=100.25,
    roas_exposed=10.0,
    recalibration_factor=0.16,
):
    return (
        booking_id, correlation_id, journey_type, campaign_duration, channel_name,
        attributed_recalibrated_sales_amt, conversions_recalibrated, conversion_rate,
        marketing_type, incremental_sales_amt_exposed, iroas_exposed, campaign_id,
        subchannel_name, attributed_sales_amt, media_spend_amt, roas_exposed,
        recalibration_factor,
    )


def make_reporting_df(spark_session, rows=None):
    return spark_session.createDataFrame(rows or [make_reporting_row()], EXTENDED_INPUT_SCHEMA)


def test_shared_expected_value_preserves_null_comparison(spark_session):
    reporting_df = spark_session.createDataFrame(
        [(1.0, 1.0), (0.16, 1.0), (None, 1.0)],
        "actual DOUBLE, expected DOUBLE",
    )

    results = evaluate_expected_value(
        reporting_df, F.col("actual"), F.col("expected"),
    ).select("matches_expected_value").collect()

    assert [row.matches_expected_value for row in results] == [True, False, None]


@pytest.mark.parametrize("roas,expected", [
    (100.0, "pass"), (100.01, "warning"), (0.0, "fail"), (-1.0, "fail"), (None, "pass"),
])
def test_check_roas_matches_runbook_threshold_and_nonpositive_rules(spark_session, roas, expected):
    reporting_df = make_reporting_df(spark_session, [make_reporting_row(roas_exposed=roas)])

    assert check_roas(reporting_df, "run-1").first().outcome == expected


def test_check_roas_uses_maximum_for_nonpositive_rule(spark_session):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(roas_exposed=-1.0),
        make_reporting_row(roas_exposed=10.0),
    ])

    result = check_roas(reporting_df, "run-1").first()

    assert result.outcome == "pass"
    assert json.loads(result.additional_metadata)["maximum_roas"] == 10.0


def test_check_media_spend_checks_each_row_not_channel_sum(spark_session):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(channel_name="META", media_spend_amt=30.0),
        make_reporting_row(channel_name="META", media_spend_amt=25.0),
    ])

    result = check_media_spend(reporting_df, "run-1").first()

    assert result.outcome == "warning"
    assert json.loads(result.additional_metadata)["breach_count"] == 2


@pytest.mark.parametrize("factors,expected", [
    (
        RecalibrationFactorsConfig(),
        "Meta: >0 and <=1, required; DV360/YouTube exempt; otherwise=1",
    ),
    (
        RecalibrationFactorsConfig(
            offsite_recalibration_min_threshold=0.1,
            offsite_recalibration_max_threshold=0.9,
            non_offsite_recalibration_factor=0.95,
        ),
        "Meta: >0.1 and <=0.9, required; DV360/YouTube exempt; otherwise=0.95",
    ),
])
def test_recalibration_expected_value_describes_configured_bounds(factors, expected):
    """The description reflects configured bounds and the missing-Meta requirement."""
    assert recalibration_expected_value(factors) == expected


@pytest.mark.parametrize("subchannel,factor,expected", [
    ("Meta Social", 0.16, "pass"),
    ("Meta Social", 1.0, "pass"),
    ("Meta Social", None, "warning"),
    ("Meta YouTube", 1.0, "pass"),
    ("Meta YouTube", 1.01, "warning"),
    ("Social - Meta", 0.01719430576038334, "pass"),
    ("social - mEtA", 0.85, "pass"),
    ("Social - Meta", 0.0, "warning"),
    ("Social - Meta", -0.1, "warning"),
    ("Social - Meta", 1.000001, "warning"),
    ("DV360 Video", 0.16, "pass"),
    ("DV360 Video", None, "pass"),
    ("YouTube", 0.25, "pass"),
    ("YouTube", None, "pass"),
    ("Instore", 1.0, "pass"),
    ("Instore", 0.16, "warning"),
    ("Instore", None, "warning"),
    (None, None, "pass"),
])
def test_check_recalibration_factor_uses_subchannel_rules(
    spark_session, subchannel, factor, expected,
):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(subchannel_name=subchannel, recalibration_factor=factor),
    ])

    assert check_recalibration_factor(reporting_df, "run-1").first().outcome == expected


def test_check_recalibration_factor_reports_bounds_and_equality_breaches(spark_session):
    """Breach metadata distinguishes Meta bounds from non-Meta equality."""
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(subchannel_name="Social - Meta", recalibration_factor=1.1),
        make_reporting_row(subchannel_name="Instore", recalibration_factor=0.16),
        make_reporting_row(subchannel_name="YouTube", recalibration_factor=None),
        make_reporting_row(subchannel_name=None, recalibration_factor=None),
    ])

    result = check_recalibration_factor(reporting_df, "run-1").first()
    metadata = json.loads(result.additional_metadata)
    breaches = {row["subchannel"]: row for row in metadata["breaches"]}

    assert result.outcome == "warning"
    assert metadata["value_count"] == 2
    assert metadata["breach_count"] == 2
    assert breaches["Social - Meta"]["actual_factor"] == 1.1
    assert breaches["Social - Meta"]["minimum_factor"] == 0.0
    assert breaches["Social - Meta"]["maximum_factor"] == 1.0
    assert breaches["Social - Meta"].get("expected_factor") is None
    assert breaches["Instore"]["expected_factor"] == 1.0
    assert breaches["Instore"].get("minimum_factor") is None
    assert breaches["Instore"].get("maximum_factor") is None


@pytest.mark.parametrize("factor,expected", [
    (0.1, "warning"), (0.100001, "pass"), (0.9, "pass"), (0.900001, "warning"),
])
def test_check_recalibration_factor_uses_configured_meta_bounds(
    spark_session, monkeypatch, factor, expected,
):
    """Meta comparisons and displayed expectations use the same configuration."""
    factors = RecalibrationFactorsConfig(
        offsite_recalibration_min_threshold=0.1,
        offsite_recalibration_max_threshold=0.9,
    )
    monkeypatch.setattr(
        "spark_pipeline.metrics.qa_validation_metrics.hypercare_validation_metrics."
        "hypercare_validation_metrics.RecalibrationFactorsConfig",
        lambda: factors,
    )
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(subchannel_name="Social - Meta", recalibration_factor=factor),
    ])

    result = check_recalibration_factor(reporting_df, "run-1").first()

    assert result.outcome == expected
    assert result.expected_value == recalibration_expected_value(factors)


@pytest.mark.parametrize("marketing_type,raw,recalibrated,expected", [
    ("instore", 100.01, 100.0, "pass"),
    ("instore", 100.011, 100.0, "fail"),
    ("offsite", 120.0, 100.0, "pass"),
])
def test_check_attributed_vs_recalibrated_sales_uses_sql_tolerance(
    spark_session, marketing_type, raw, recalibrated, expected,
):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(
            marketing_type=marketing_type, attributed_sales_amt=raw,
            attributed_recalibrated_sales_amt=recalibrated,
        ),
    ])

    assert check_attributed_vs_recalibrated_sales(reporting_df, "run-1").first().outcome == expected


@pytest.mark.parametrize("check_function,metric_column", [
    (check_post_period_sales, "attributed_recalibrated_sales_amt"),
    (check_post_period_conversions, "conversions_recalibrated"),
    (check_post_period_incremental_sales, "incremental_sales_amt_exposed"),
])
@pytest.mark.parametrize("combined_value,expected", [
    (90.0, "fail"),
    (120.0, "pass"),
    (180.0, "warning"),
])
def test_post_period_checks_pair_channels_with_different_case_and_spaces(
    spark_session, check_function, metric_column, combined_value, expected,
):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(
            campaign_duration="POST", channel_name=" Meta ",
            **{metric_column: 100.0},
        ),
        make_reporting_row(
            campaign_duration="DURING+POST", channel_name="meta",
            **{metric_column: combined_value},
        ),
    ])

    result = check_function(reporting_df, "run-1", "Post").first()
    metadata = json.loads(result.additional_metadata)

    assert result.outcome == expected
    assert metadata["pair_count"] == 1
    assert metadata["failure_channels"] == (["META"] if expected == "fail" else [])
    assert metadata["warning_channels"] == (["META"] if expected == "warning" else [])


def test_check_post_period_sales_uses_strict_warning_boundary(spark_session):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(campaign_duration="POST", attributed_recalibrated_sales_amt=100.0),
        make_reporting_row(campaign_duration="DURING+POST", attributed_recalibrated_sales_amt=150.0),
    ])

    assert check_post_period_sales(reporting_df, "run-1").first().outcome == "pass"


def test_check_post_period_conversions_skips_without_complete_pairs(spark_session):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(campaign_duration="POST", conversions_recalibrated=100.0),
    ])

    assert check_post_period_conversions(reporting_df, "run-1").first().outcome == "skipped"


def test_check_post_period_incremental_sales_fails_when_combined_is_lower(spark_session):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(campaign_duration="POST", incremental_sales_amt_exposed=100.0),
        make_reporting_row(campaign_duration="DURING+POST", incremental_sales_amt_exposed=90.0),
    ])

    assert check_post_period_incremental_sales(reporting_df, "run-1").first().outcome == "fail"


@pytest.mark.parametrize("campaign_period", ["During", "Post"])
@pytest.mark.parametrize("reach_booking,reach_campaign,reach_subchannel,expected", [
    (" booking-abc ", " campaign-xyz ", " citrus ", "pass"),
    ("other-booking", "campaign-xyz", "citrus", "fail"),
    ("booking-abc", "other-campaign", "citrus", "fail"),
    ("booking-abc", "campaign-xyz", "other-subchannel", "fail"),
])
def test_check_subchannel_consistency_normalizes_keys_without_hiding_mismatches(
    spark_session, campaign_period, reach_booking, reach_campaign, reach_subchannel, expected,
):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(
            booking_id="Booking-Abc", campaign_id="Campaign-Xyz",
            subchannel_name="Citrus", campaign_duration=campaign_period,
        ),
    ])
    reach_engagement_df = spark_session.createDataFrame(
        [
            (reach_booking, reach_campaign, reach_subchannel),
            (reach_booking.upper(), reach_campaign.upper(), reach_subchannel.upper()),
        ],
        "booking_id STRING, campaign_id STRING, subchannel_name STRING",
    )

    result = check_subchannel_consistency(
        reporting_df, "run-1", campaign_period, reach_engagement_df=reach_engagement_df,
    ).first()
    metadata = json.loads(result.additional_metadata)

    assert result.outcome == expected
    assert metadata["failure_count"] == (0 if expected == "pass" else 2)


def test_check_subchannel_consistency_detects_source_mismatch(spark_session):
    reporting_df = make_reporting_df(spark_session)
    reach_engagement_df = spark_session.createDataFrame(
        [("123", "campaign-1", "Other")],
        "booking_id STRING, campaign_id STRING, subchannel_name STRING",
    )

    result = check_subchannel_consistency(
        reporting_df, "run-1", "During", reach_engagement_df=reach_engagement_df,
    ).first()

    assert result.outcome == "fail"
    assert json.loads(result.additional_metadata)["failure_count"] > 0


def test_check_subchannel_consistency_fails_when_during_reach_data_is_empty(spark_session):
    reporting_df = make_reporting_df(spark_session)
    reach_engagement_df = spark_session.createDataFrame(
        [], "booking_id STRING, campaign_id STRING, subchannel_name STRING",
    )

    result = check_subchannel_consistency(
        reporting_df, "run-1", "During", reach_engagement_df=reach_engagement_df,
    ).first()

    assert result.outcome == "fail"


def test_check_subchannel_consistency_skips_when_post_reach_data_is_empty(spark_session):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(campaign_duration="Post"),
    ])
    reach_engagement_df = spark_session.createDataFrame(
        [], "booking_id STRING, campaign_id STRING, subchannel_name STRING",
    )

    result = check_subchannel_consistency(
        reporting_df, "run-1", "Post", reach_engagement_df=reach_engagement_df,
    ).first()

    assert result.outcome == "skipped"


@pytest.mark.parametrize("spend,expected", [(100.0, "warning"), (101.0, "pass"), (100.25, "pass")])
def test_check_rounded_media_spend_flags_integer_multiples(spend, expected, spark_session):
    reporting_df = make_reporting_df(spark_session, [make_reporting_row(media_spend_amt=spend)])

    result = check_rounded_media_spend(reporting_df, "run-1", "Post").first()

    assert result.outcome == expected
    assert result.name == "rounded_media_spend_campaign_wide"


def test_check_missing_inscope_subchannel_normalizes_case_and_whitespace(spark_session):
    reporting_df = make_reporting_df(spark_session)
    campaign_booking_media_channel_df = spark_session.createDataFrame(
        [("123", "campaign-1", "  META SOCIAL  ")],
        "booking_id STRING, campaign_id STRING, marketing_subchannel STRING",
    )

    result = check_missing_inscope_subchannel(
        reporting_df, "run-1", "During",
        campaign_booking_media_channel_df=campaign_booking_media_channel_df,
    ).first()

    assert result.outcome == "pass"


def test_check_missing_inscope_subchannel_fails_for_missing_reporting_key(spark_session):
    reporting_df = make_reporting_df(spark_session)
    campaign_booking_media_channel_df = spark_session.createDataFrame(
        [("123", "campaign-2", "Meta Social")],
        "booking_id STRING, campaign_id STRING, marketing_subchannel STRING",
    )

    result = check_missing_inscope_subchannel(
        reporting_df, "run-1", "During",
        campaign_booking_media_channel_df=campaign_booking_media_channel_df,
    ).first()

    assert result.outcome == "fail"


def test_check_missing_inscope_subchannel_fails_when_reporting_scope_is_empty(spark_session):
    reporting_df = make_reporting_df(spark_session)
    campaign_booking_media_channel_df = spark_session.createDataFrame(
        [("123", "campaign-1", "Meta Social")],
        "booking_id STRING, campaign_id STRING, marketing_subchannel STRING",
    )

    result = check_missing_inscope_subchannel(
        reporting_df, "missing-run", "During",
        campaign_booking_media_channel_df=campaign_booking_media_channel_df,
    ).first()
    metadata = json.loads(result.additional_metadata)

    assert result.outcome == "fail"
    assert metadata["reporting_row_count"] == 0
    assert metadata["comment"] == (
        "No reporting rows found for the correlation ID; in-scope coverage cannot be validated."
    )


def test_extended_runner_enables_checks_only_when_new_input_is_supplied(spark_session):
    reporting_df = make_reporting_df(spark_session)
    legacy_results = run_hypercare_validation_checks(reporting_df, "run-1")
    assert legacy_results.count() == 10

    reach_engagement_df = reporting_df.select("booking_id", "campaign_id", "subchannel_name")
    campaign_booking_media_channel_df = reporting_df.select(
        "booking_id", "campaign_id", F.col("subchannel_name").alias("marketing_subchannel"),
    )
    extended_results = run_hypercare_validation_checks(
        reporting_df, "run-1", reach_engagement_df=reach_engagement_df,
        campaign_booking_media_channel_df=campaign_booking_media_channel_df,
    )

    assert extended_results.count() == 20
    assert {row.name for row in extended_results.collect()} >= {
        "roas_during", "media_spend_during", "recalibration_factor_during",
        "attributed_vs_recalibrated_sales_during", "post_period_sales_during",
        "post_period_conversions_during", "post_period_incremental_sales_during",
        "subchannel_consistency_during", "rounded_media_spend_campaign_wide",
        "missing_inscope_subchannel_during",
    }


@pytest.mark.parametrize("mapped_subchannel,expected_outcome", [
    ("Meta Social", "pass"),
    (None, "fail"),
])
def test_extended_publisher_persists_and_publishes_twenty_checks(
    spark_session, tmp_path, monkeypatch,
    mapped_subchannel, expected_outcome,
):
    reporting_df = make_reporting_df(spark_session, [
        make_reporting_row(
            channel_name="META", subchannel_name="Meta Social",
            attributed_recalibrated_sales_amt=90.0, conversions_recalibrated=10.0,
            incremental_sales_amt_exposed=20.0, attributed_sales_amt=100.0,
            media_spend_amt=100.25, roas_exposed=5.0, recalibration_factor=0.16,
        ),
        make_reporting_row(
            channel_name="INSTORE", subchannel_name="Instore",
            attributed_recalibrated_sales_amt=10.0, conversions_recalibrated=10.0,
            marketing_type="instore", incremental_sales_amt_exposed=2.0,
            attributed_sales_amt=10.0, media_spend_amt=90.25, roas_exposed=5.0,
            recalibration_factor=1.0, campaign_id="campaign-2",
        ),
    ])
    reporting_path = str(tmp_path / "reporting")
    reach_engagement_path = str(tmp_path / "reach-engagement")
    campaign_booking_media_channel_path = str(tmp_path / "campaign-booking-media-channel")
    hierarchy_path = str(tmp_path / "hierarchy")
    output_path = str(tmp_path / "validation")
    reporting_df.write.parquet(reporting_path)
    reporting_df.select("booking_id", "campaign_id", "subchannel_name").write.parquet(reach_engagement_path)
    booking_media_df = spark_session.createDataFrame(
        [("123", "campaign-1", "meta-code"), ("123", "campaign-2", "instore-code")],
        "BOOKING_ID STRING, CAMPAIGN_ID STRING, MARKETING_HIERARCHY_CD STRING",
    )
    hierarchy_df = spark_session.createDataFrame(
        [("meta-code", mapped_subchannel), ("instore-code", "Instore")],
        "MARKETING_HIERARCHY_CD STRING, MARKETING_SUBCHANNEL STRING",
    )
    booking_media_df.write.parquet(campaign_booking_media_channel_path)
    hierarchy_df.write.parquet(hierarchy_path)
    published_events = []
    slack_messages = []

    class FakeMetricsPublisher:
        def __init__(self, topic_arn):
            self.topic_arn = topic_arn

        def publish_event(self, message_subject, event):
            published_events.append((message_subject, event))

    class FakeSlackMessenger:
        def __init__(self, topic_arn, correlation_id):
            self.topic_arn = topic_arn
            self.correlation_id = correlation_id

        def send_message(self, **kwargs):
            slack_messages.append(kwargs)

    monkeypatch.setattr(hypercare_publisher, "MetricsPublisher", FakeMetricsPublisher)
    monkeypatch.setattr(hypercare_publisher, "SlackMessenger", FakeSlackMessenger)

    hypercare_publisher.publish_hypercare_validation(
        spark=spark_session,
        measurement_campaign_reporting_path=reporting_path,
        reach_engagement_path=reach_engagement_path,
        campaign_period="During",
        booking_id="123",
        correlation_id="run-1",
        metrics_topic_arn="metrics-topic",
        slack_topic_arn="slack-topic",
        output_path=output_path,
        campaign_booking_media_channel_path=campaign_booking_media_channel_path,
        measurement_marketing_channel_hierarchy_path=hierarchy_path,
    )

    output_df = spark_session.read.parquet(output_path)
    assert output_df.count() == 20
    assert len([event for _, event in published_events if hasattr(event, "outcome")]) == 20
    assert slack_messages[0]["data"]["checks_run"] == 20
    check_twenty = output_df.filter(F.col("name") == "missing_inscope_subchannel_during").first()
    assert check_twenty.outcome == expected_outcome
    assert json.loads(check_twenty.additional_metadata)["unmapped_subchannel_count"] == (
        1 if mapped_subchannel is None else 0
    )
    published_check_twenty = next(
        event for _, event in published_events if event.name == "missing_inscope_subchannel_during"
    )
    assert published_check_twenty.outcome == expected_outcome
    assert slack_messages[0]["data"]["status_counts"]["fail"] == (1 if expected_outcome == "fail" else 0)
    assert_df_equality(
        spark_session.read.parquet(campaign_booking_media_channel_path),
        booking_media_df,
        ignore_nullable=True,
        ignore_row_order=True,
    )
    assert_df_equality(
        spark_session.read.parquet(hierarchy_path),
        hierarchy_df,
        ignore_nullable=True,
        ignore_row_order=True,
    )


@pytest.mark.parametrize("hierarchy_rows,expected_rows,expected_outcome,unmapped_count", [
    ([("meta-code", "Meta Social")], [("123", "campaign-1", "Meta Social")], "pass", 0),
    ([("other-code", "YouTube")], [], "pass", 0),
    ([], [], "pass", 0),
    ([("meta-code", None)], [("123", "campaign-1", None)], "fail", 1),
    ([("meta-code", "YouTube")], [("123", "campaign-1", "YouTube")], "fail", 0),
])
def test_resolve_booking_subchannels_excludes_ineligible_media_and_validates_eligible_media(
    spark_session, hierarchy_rows, expected_rows, expected_outcome, unmapped_count,
):
    booking_media_df = spark_session.createDataFrame(
        [
            ("123", "campaign-1", "meta-code"),
            ("123", "excluded-campaign", "excluded-code"),
            ("other-booking", "other-campaign", "other-code"),
        ],
        "booking_id STRING, campaign_id STRING, marketing_hierarchy_cd STRING",
    )
    hierarchy_df = spark_session.createDataFrame(
        hierarchy_rows, "marketing_hierarchy_cd STRING, marketing_subchannel STRING",
    )
    expected_df = spark_session.createDataFrame(
        expected_rows,
        "booking_id STRING, campaign_id STRING, marketing_subchannel STRING",
    )

    resolved = resolve_booking_subchannels(booking_media_df, hierarchy_df)
    result = check_missing_inscope_subchannel(
        make_reporting_df(spark_session), "run-1", "During",
        campaign_booking_media_channel_df=resolved,
    ).first()

    assert_df_equality(
        resolved.filter(F.col("booking_id") == "123"), expected_df, ignore_nullable=True,
    )
    assert result.outcome == expected_outcome
    assert json.loads(result.additional_metadata)["unmapped_subchannel_count"] == unmapped_count


def test_extended_publisher_requires_hierarchy_path(spark_session):
    with pytest.raises(ValueError, match="marketing hierarchy path is required"):
        hypercare_publisher.publish_hypercare_validation(
            spark=spark_session,
            measurement_campaign_reporting_path="unused",
            reach_engagement_path="unused",
            campaign_period="During",
            booking_id="123",
            correlation_id="run-1",
            metrics_topic_arn="metrics-topic",
            slack_topic_arn="slack-topic",
            output_path="unused",
            campaign_booking_media_channel_path="booking-media",
        )


def test_hypercare_entrypoint_passes_existing_hierarchy_path(monkeypatch):
    captured_arguments = {}
    spark = object()
    path_arguments = {
        "measurement_campaign_reporting_path": "reporting",
        "reach_engagement_path": "reach",
        "campaign_booking_media_channel_path": "booking-media",
        "measurement_marketing_channel_hierarchy_path": "hierarchy",
        "output_path": "validation",
    }
    expected_arguments = {
        **path_arguments,
        "campaign_period": "Post",
        "booking_id": "123",
        "correlation_id": "run-1",
        "metrics_topic_arn": "metrics-topic",
        "slack_topic_arn": "slack-topic",
    }

    def capture_publisher(**kwargs):
        captured_arguments.update(kwargs)

    monkeypatch.setattr(hypercare_publisher, "publish_hypercare_validation", capture_publisher)
    command_line_args = [
        argument
        for name, value in expected_arguments.items()
        for argument in (f"--{name.replace('_', '-')}", value)
    ]

    hypercare_publisher.entrypoint(spark, command_line_args)

    assert captured_arguments == {"spark": spark, **expected_arguments}
