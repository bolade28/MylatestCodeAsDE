"""AAA tests for analytics persistence, SNS events and the command-line contract."""

import json
from datetime import datetime
from unittest.mock import Mock, patch

import pytest

from spark_pipeline.common.throwing_argument_parser import ArgumentParserError
from spark_pipeline.metrics import publish_analytics_validation as task
from spark_pipeline.schemas.qa_checks import QAChecks
from spark_pipeline.utils.metrics_schema import QAChecksSchema
from spark_pipeline.utils.mta_events import QAChecksMetric
from spark_pipeline.utils.publish_metrics import MetricsPublisher

RUN = "analytics-run-1"
METRICS_ARN = "arn:aws:sns:eu-west-1:123456789012:metrics-topic"
INPUT_COLUMNS = [
    "correlation_id", "campaign_duration", "booking_id", "campaign_id", "journey_type",
    "channel_name", "subchannel_name", "marketing_type", "attributed_recalibrated_sales_amt",
    "conversion_rate", "roas_exposed", "iroas_exposed", "uplift_exposed_sales_amt", "media_spend_amt",
    "incremental_sales_amt_exposed", "base_sales_amt_exposed",
]
OUTPUT_COLUMNS = [
    "correlation_id", "type", "name", "expected_value", "outcome",
    "details", "additional_metadata", "load_timestamp",
]


@pytest.fixture
def qa_rows():
    # Three checks cover every outcome
    return [
        {
            "correlation_id": RUN, "type": "analytics", "name": f"check_{index}_during",
            "expected_value": None if index == 0 else "less than 10", "outcome": outcome,
            "details": f"Check {index}: booking's result",
            "additional_metadata": json.dumps({"booking_ids": ["123"], "observed": index, "missing": None}),
            "load_timestamp": datetime(2026, 10, 16, 12, 0, 0),
        }
        for index, outcome in enumerate(("pass", "fail", "skipped"))
    ]


@pytest.fixture(autouse=True)
def local_writer(monkeypatch):
    # Exercise real Parquet writes, not the S3 deletion/URI validation tested elsewhere.
    writer = Mock(side_effect=lambda path, df: df.write.mode("overwrite").parquet(path))
    monkeypatch.setattr(task, "spark_s3_overwrite", writer)
    return writer


@pytest.fixture
def published(monkeypatch):
    # Keep event construction real, but prevent SNS requests.
    publisher = Mock()
    factory = Mock(return_value=publisher)
    monkeypatch.setattr(task, "MetricsPublisher", factory)
    return factory, publisher


def run_task(spark, tmp_path, qa_rows, campaign_period="During"):
    """Provide a reporting input but stub rule evaluation to isolate the publishing contract."""
    input_path, output_path = str(tmp_path / "mcr"), str(tmp_path / "checks")
    spark.createDataFrame([
        (
            RUN, campaign_period, "booking-1", "campaign-1", "BRAND", "Channel", "Subchannel",
            "offsite", 100.0, 1.0, 1.0, 1.0, 0.1, 123.0, 10.0, 100.0,
        ),
    ], QAChecks.measurement_campaign_reporting_schema).write.mode("overwrite").parquet(input_path)

    checks_df = spark.createDataFrame(qa_rows, QAChecks.detail_schema)
    with patch.object(task, "run_analytics_validation_checks", return_value=checks_df):
        task.publish_analytics_validation(
            spark=spark,
            measurement_campaign_reporting_path=input_path,
            campaign_period=campaign_period,
            correlation_id=RUN,
            metrics_topic_arn=METRICS_ARN,
            output_path=output_path,
        )
    return output_path


def test_persists_and_publishes_all_checks_with_stable_upsert_keys(spark_session, tmp_path, qa_rows, published):
    # Arrange: cover pass/fail/skipped forwarding, then update outcomes under the same keys.
    factory, publisher = published
    updated_rows = [{**row, "outcome": "fail"} for row in qa_rows]
    keys = []

    for expected_rows in (qa_rows, updated_rows):
        # Act: each invocation must overwrite Parquet and emit one event per supplied check.
        output_path = run_task(spark_session, tmp_path, expected_rows)
        written = spark_session.read.parquet(output_path)

        # Assert: Parquet keeps TimestampType; events stringify it. Match by name, not Spark order.
        factory.assert_called_with(topic_arn=METRICS_ARN)
        assert written.columns == OUTPUT_COLUMNS
        assert written.schema["load_timestamp"].dataType == QAChecks.detail_schema["load_timestamp"].dataType
        assert [row.asDict() for row in written.orderBy("name").collect()] == expected_rows
        expected_by_name = {row["name"]: row for row in expected_rows}
        calls = publisher.publish_event.call_args_list[-len(expected_rows):]
        assert {call.kwargs["event"].name for call in calls} == set(expected_by_name)
        for call in calls:
            event = call.kwargs["event"]
            original = expected_by_name[event.name]
            assert call.kwargs["message_subject"] == "Analytics Validation Metric Event"
            assert isinstance(event, QAChecksMetric)
            assert vars(event) == {
                **original, "load_timestamp": str(original["load_timestamp"]),
                "event_schema": vars(QAChecksSchema()),
            }
            keys.append((event.correlation_id, event.type, event.name))

    # Assert: reruns update existing downstream rows rather than introduce new identities.
    assert factory.call_count == 2
    assert publisher.publish_event.call_count == 2 * len(qa_rows)
    assert set(keys[:len(qa_rows)]) == set(keys[len(qa_rows):])
    assert len(set(keys)) == len(qa_rows)


def test_normalizes_journey_types_before_passing_reporting_to_checks(spark_session, tmp_path, qa_rows, published):
    # Arrange: normalization belongs at the publisher boundary, not in rule-test fixtures.
    journeys = ["Brand", "BRAND", "brand", "Offer", "OFFER", "offer", None]
    input_path, output_path = str(tmp_path / "mcr"), str(tmp_path / "checks")
    spark_session.createDataFrame([
        {"booking_id": str(index), "correlation_id": RUN, "campaign_duration": "Post", "journey_type": journey}
        for index, journey in enumerate(journeys)
    ], QAChecks.measurement_campaign_reporting_schema).write.parquet(input_path)
    checks_df = spark_session.createDataFrame(qa_rows, QAChecks.detail_schema)
    with patch.object(task, "run_analytics_validation_checks", return_value=checks_df) as checks:
        # Act: keep the real Spark upper expression and inspect the actual check input.
        task.publish_analytics_validation(spark_session, input_path, "Post", RUN, METRICS_ARN, output_path)

    # Assert: case variants merge, uppercase values stay unchanged and nulls are preserved.
    checks.assert_called_once()
    reporting = checks.call_args.args[0]
    assert checks.call_args.kwargs == {"correlation_id": RUN, "campaign_period": "Post"}
    assert reporting.columns == INPUT_COLUMNS
    assert [row.journey_type for row in reporting.orderBy("booking_id").collect()] == [
        "BRAND", "BRAND", "BRAND", "OFFER", "OFFER", "OFFER", None,
    ]


def test_passes_reporting_and_run_context_to_checks(local_writer):
    # Arrange: an empty result isolates input projection/context forwarding from event creation.
    spark, validation_results = Mock(), Mock()
    validation_results.select.return_value.cache.return_value.collect.return_value = []
    with (
        patch.object(task.F, "upper") as upper,
        patch.object(task, "run_analytics_validation_checks", return_value=validation_results) as checks,
        patch.object(task, "MetricsPublisher"),
    ):
        # Act
        task.publish_analytics_validation(spark, "input", "Post", RUN, METRICS_ARN, "output")

    # Assert
    spark.read.parquet.assert_called_once_with("input")
    upper.assert_called_once_with("journey_type")
    source = spark.read.parquet.return_value
    source.withColumn.assert_called_once_with("journey_type", upper.return_value)
    source.withColumn.return_value.select.assert_called_once_with(*INPUT_COLUMNS)
    checks.assert_called_once_with(
        source.withColumn.return_value.select.return_value, correlation_id=RUN, campaign_period="Post",
    )
    validation_results.unpersist.assert_called_once_with()
    results = validation_results.select.return_value.cache.return_value
    local_writer.assert_called_once_with("output", results)
    results.unpersist.assert_called_once_with()


def test_event_is_serializable_by_real_metrics_publisher(qa_rows):
    # Arrange: preserve a snapshot to detect accidental mutation of the shared event schema.
    original_schema = vars(QAChecksSchema())
    fields = qa_rows[0].copy()
    fields["load_timestamp"] = str(fields["load_timestamp"])
    event = QAChecksMetric(**fields)
    with patch("spark_pipeline.utils.publish_metrics.boto3.client") as client:
        # Keep the real serializer; only replace the AWS client so no SNS request is sent.
        publisher = MetricsPublisher(topic_arn=METRICS_ARN)

        # Act
        publisher.publish_event("Analytics Validation Metric Event", event)
    message = client.return_value.publish.call_args.kwargs
    # Decode the SNS JSON envelope first, then the event JSON stored under "default".
    payload = json.loads(json.loads(message["Message"])["default"])

    # Assert
    client.return_value.publish.assert_called_once()
    assert message["TopicArn"] == METRICS_ARN
    assert message["Subject"] == "Analytics Validation Metric Event"
    assert message["MessageStructure"] == "json"
    assert payload == {**fields, "event_schema": original_schema}
    assert event.event_schema == vars(QAChecksSchema()) == original_schema
    assert original_schema["table_name"] == "qa_validation_check_metrics_upsert"
    assert original_schema["schema"] == "metrics"
    assert original_schema["write_operation"] == "upsert"
    assert original_schema["table_schema"]["additional_metadata"] == "jsonb"
    assert original_schema["table_schema"]["load_timestamp"] == "timestamp"
    assert "load_ts" not in payload
    assert "load_ts" not in original_schema["table_schema"]
    assert json.loads(payload["additional_metadata"]) == {
        "booking_ids": ["123"], "observed": 0, "missing": None,
    }


@pytest.mark.parametrize("failure, releases_cached_results", [
    ("select", False), ("cache", False), ("publisher", False),
    ("write", True), ("collect", True), ("publish", True),
])
def test_cleanup_and_propagation_at_each_infrastructure_stage(failure, releases_cached_results, local_writer, qa_rows):
    # Arrange: distinguish raw validation results from the selected/cached publishing rows.
    # Inject one failure per case so the assertions can check cleanup at that stage.
    spark, validation_results, results, publisher = Mock(), Mock(), Mock(), Mock()
    factory = Mock(return_value=publisher)
    validation_results.select.return_value.cache.return_value = results
    results.collect.return_value = [Mock(asDict=Mock(return_value=qa_rows[0].copy()))]
    operations = {
        "select": validation_results.select,
        "cache": validation_results.select.return_value.cache,
        "write": local_writer,
        "publisher": factory,
        "collect": results.collect,
        "publish": publisher.publish_event,
    }
    operations[failure].side_effect = RuntimeError("backend unavailable")
    with (
        patch.object(task.F, "upper"),
        patch.object(task, "run_analytics_validation_checks", return_value=validation_results),
        patch.object(task, "MetricsPublisher", factory),
    ):
        # Act
        with pytest.raises(RuntimeError) as error:
            task.publish_analytics_validation(spark, "input", "During", RUN, METRICS_ARN, "output")

    # Assert: raw results always release. Publisher construction is currently outside
    # the inner finally, so its failure does not release the selected/cached results.
    assert str(error.value) == "backend unavailable"
    validation_results.unpersist.assert_called_once_with()
    if releases_cached_results:
        results.unpersist.assert_called_once_with()
    else:
        results.unpersist.assert_not_called()
    if failure in ("select", "cache", "publisher"):
        local_writer.assert_not_called()
    if failure != "publish":
        publisher.publish_event.assert_not_called()


@pytest.mark.parametrize("failure", ["read", "normalization", "projection", "checks"])
def test_input_errors_propagate_without_publishing(failure, local_writer):
    # Arrange: fail during input reading, normalization, projection or check evaluation.
    spark = Mock()
    with (
        patch.object(task.F, "upper"),
        patch.object(task, "run_analytics_validation_checks") as checks,
        patch.object(task, "MetricsPublisher") as publisher,
    ):
        operation = {
            "read": spark.read.parquet,
            "normalization": spark.read.parquet.return_value.withColumn,
            "projection": spark.read.parquet.return_value.withColumn.return_value.select,
            "checks": checks,
        }[failure]
        operation.side_effect = RuntimeError("invalid input")

        # Act
        with pytest.raises(RuntimeError) as error:
            task.publish_analytics_validation(spark, "input", "During", RUN, METRICS_ARN, "output")

    # Assert: invalid input must propagate, not be converted into a QA event or trigger SNS setup.
    assert str(error.value) == "invalid input"
    publisher.assert_not_called()
    local_writer.assert_not_called()
    if failure != "checks":
        checks.assert_not_called()


class TestEntrypoint:
    ARGS = [
        "--measurement-campaign-reporting-path", "s3://bucket/mcr",
        "--campaign-period", "Post",
        "--correlation-id", RUN,
        "--metrics-topic-arn", METRICS_ARN,
        "--output-path", "s3://bucket/qa_validation_checks/run-1",
    ]

    @patch.object(task, "publish_analytics_validation")
    def test_parses_arguments_and_ignores_unrelated_dag_arguments(self, mock_publish):
        # Arrange
        spark = Mock()

        # Act: shared DAG arguments may be present, but only analytics arguments are forwarded.
        task.entrypoint(spark=spark, command_line_args=self.ARGS + ["--unused-dag-arg", "x"])

        # Assert
        mock_publish.assert_called_once_with(
            spark=spark,
            measurement_campaign_reporting_path="s3://bucket/mcr",
            campaign_period="Post",
            correlation_id=RUN,
            metrics_topic_arn=METRICS_ARN,
            output_path="s3://bucket/qa_validation_checks/run-1",
        )

    @pytest.mark.parametrize("argument_index", range(0, len(ARGS), 2))
    def test_missing_argument_raises(self, argument_index):
        # Arrange: remove both a required flag and its value, leaving other pairs valid.
        spark = Mock()
        args = self.ARGS[:argument_index] + self.ARGS[argument_index + 2:]
        with patch.object(task, "publish_analytics_validation") as publish:
            # Act
            with pytest.raises(ArgumentParserError) as error:
                task.entrypoint(spark=spark, command_line_args=args)

        # Assert
        assert "required" in str(error.value)
        assert self.ARGS[argument_index] in str(error.value)
        publish.assert_not_called()

    def test_invalid_campaign_period_raises(self):
        # Arrange: replace only the campaign-period value; combined periods are not CLI options.
        spark = Mock()
        args = self.ARGS[:3] + ["During+Post"] + self.ARGS[4:]
        with patch.object(task, "publish_analytics_validation") as publish:
            # Act
            with pytest.raises(ArgumentParserError) as error:
                task.entrypoint(spark=spark, command_line_args=args)

        # Assert
        assert "invalid choice" in str(error.value)
        publish.assert_not_called()
