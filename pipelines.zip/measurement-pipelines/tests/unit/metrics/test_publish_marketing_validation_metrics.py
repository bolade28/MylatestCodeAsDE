import json
from datetime import date
from unittest import mock
from unittest.mock import MagicMock

import pytest
from chispa import assert_df_equality
from pyspark.sql import SparkSession

from spark_pipeline.common.variables import BaselineModellingOutputConfig
from spark_pipeline.metrics.baseline_validation_metrics.marketing_validation_metrics import (
    build_impression_metrics_df,
    build_signal_metrics_df,
    build_spend_metrics_df,
    check_marketing_budget_range,
    check_marketing_impressions_budget_signal,
    check_marketing_impressions_range,
    check_value_range,
    publish_marketing_validation_metrics,
    resolve_modelling_channels,
    run_all_marketing_checks,
)
from spark_pipeline.schemas.validation_metrics_schema import ValidationMetrics

METRICS_SCHEMA = ValidationMetrics.METRICS_SCHEMA
SIGNAL_METRICS_SCHEMA = ValidationMetrics.SIGNAL_METRICS_SCHEMA
BASELINE_SCHEMA = ValidationMetrics.BASELINE_SCHEMA
CAMPAIGN_SCHEMA = ValidationMetrics.CAMPAIGN_SCHEMA
RESOLVE_CHANNELS_SCHEMA = ValidationMetrics.RESOLVE_CHANNELS_SCHEMA
RANGE_CHECK_SCHEMA = ValidationMetrics.RANGE_CHECK_SCHEMA
SIGNAL_CHECK_SCHEMA = ValidationMetrics.SIGNAL_CHECK_SCHEMA
ALL_CHECKS_SCHEMA = ValidationMetrics.ALL_CHECKS_SCHEMA
DEFAULT_EXCLUDED_TYPES = ["EXTERNAL", "SALES", "VALUE INDEX", "PROMOTIONAL DISCOUNT", "PLANOGRAM"]


@pytest.fixture
def minimal_config():
    """Minimal BaselineModellingOutputConfig with just a few marketing metrics."""
    config = BaselineModellingOutputConfig.__new__(BaselineModellingOutputConfig)
    config.primary_metrics = [
        ("OFFSITE", "META", "TOTAL", "IMPRESSIONS", "Y", "N"),
        ("OFFSITE", "META", "TOTAL", "INTERNALS_MEDIA_SPEND", "N", "Y"),
        ("INSTORE", "INSTORE", "TOTAL", "EXPOSED_CUSTOMERS", "Y", "N"),
        ("INSTORE", "INSTORE", "TOTAL", "TOTAL_MEDIA_COST", "N", "Y"),
        ("EXTERNAL", "HOLIDAYS", "TOTAL", "HOLIDAY_FLAG", "Y", "N"),
        ("SALES", "SALES", "TOTAL", "TOTAL_SALES", "Y", "N"),
    ]
    config.min_impressions_threshold = 0
    config.max_impressions_threshold = 2_000_000
    config.min_spend_threshold = 0.0
    config.max_spend_threshold = 50_000.0
    config.validation_excluded_marketing_types = DEFAULT_EXCLUDED_TYPES
    return config


class TestBuildSignalMetricsDf:

    def test_returns_impression_and_spend_rows_excluding_non_marketing_types(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: impression and spend metrics included; EXTERNAL/SALES types excluded
        # Arrange
        expected = spark_session.createDataFrame(
            [
                ("OFFSITE", "META", "impressions", "IMPRESSIONS"),
                ("INSTORE", "INSTORE", "impressions", "EXPOSED_CUSTOMERS"),
                ("OFFSITE", "META", "spend", "INTERNALS_MEDIA_SPEND"),
                ("INSTORE", "INSTORE", "spend", "TOTAL_MEDIA_COST"),
            ],
            schema=SIGNAL_METRICS_SCHEMA,
        )

        # Act
        actual = build_signal_metrics_df(spark_session, minimal_config)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_returns_empty_df_when_no_metrics_flagged(self, spark_session: SparkSession):
        # Scenario: no is_imp/is_inv=Y entries; empty DataFrame returned
        # Arrange
        config = BaselineModellingOutputConfig.__new__(BaselineModellingOutputConfig)
        config.primary_metrics = [
            ("EXTERNAL", "HOLIDAYS", "TOTAL", "HOLIDAY_FLAG", "N", "N"),
        ]
        config.validation_excluded_marketing_types = DEFAULT_EXCLUDED_TYPES
        expected = spark_session.createDataFrame([], schema=SIGNAL_METRICS_SCHEMA)

        # Act
        actual = build_signal_metrics_df(spark_session, config)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)

    def test_excludes_all_non_marketing_types(self, spark_session: SparkSession):
        # Scenario: all entries are excluded types; empty DataFrame returned
        # Arrange
        config = BaselineModellingOutputConfig.__new__(BaselineModellingOutputConfig)
        config.primary_metrics = [
            ("EXTERNAL", "X", "TOTAL", "METRIC_A", "Y", "N"),
            ("SALES", "X", "TOTAL", "METRIC_B", "N", "Y"),
            ("VALUE INDEX", "X", "TOTAL", "METRIC_C", "Y", "N"),
            ("PROMOTIONAL DISCOUNT", "X", "TOTAL", "METRIC_D", "N", "Y"),
            ("PLANOGRAM", "X", "TOTAL", "METRIC_E", "Y", "N"),
        ]
        config.validation_excluded_marketing_types = DEFAULT_EXCLUDED_TYPES
        expected = spark_session.createDataFrame([], schema=SIGNAL_METRICS_SCHEMA)

        # Act
        actual = build_signal_metrics_df(spark_session, config)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestBuildImpressionMetricsDf:

    def test_returns_impression_metrics_and_dv360_youtube(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: is_imp=Y metrics returned with DV360_YOUTUBE always appended
        # Arrange
        expected = spark_session.createDataFrame(
            [
                ("OFFSITE", "META", "IMPRESSIONS"),
                ("INSTORE", "INSTORE", "EXPOSED_CUSTOMERS"),
                ("OFFSITE", "DV360_YOUTUBE", "IMPRESSIONS"),
            ],
            schema=METRICS_SCHEMA,
        )

        # Act
        actual = build_impression_metrics_df(spark_session, minimal_config)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_dv360_youtube_always_present_even_with_no_other_impression_metrics(
        self, spark_session: SparkSession
    ):
        # Scenario: no is_imp=Y entries; only hardcoded DV360_YOUTUBE row returned
        # Arrange
        config = BaselineModellingOutputConfig.__new__(BaselineModellingOutputConfig)
        config.primary_metrics = [
            ("OFFSITE", "META", "TOTAL", "INTERNALS_MEDIA_SPEND", "N", "Y"),
        ]
        config.validation_excluded_marketing_types = DEFAULT_EXCLUDED_TYPES
        expected = spark_session.createDataFrame(
            [("OFFSITE", "DV360_YOUTUBE", "IMPRESSIONS")],
            schema=METRICS_SCHEMA,
        )

        # Act
        actual = build_impression_metrics_df(spark_session, config)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_excludes_non_marketing_types(self, spark_session: SparkSession):
        # Scenario: EXTERNAL is excluded; only OFFSITE/META and DV360_YOUTUBE present
        # Arrange
        config = BaselineModellingOutputConfig.__new__(BaselineModellingOutputConfig)
        config.primary_metrics = [
            ("EXTERNAL", "HOLIDAYS", "TOTAL", "HOLIDAY_FLAG", "Y", "N"),
            ("OFFSITE", "META", "TOTAL", "IMPRESSIONS", "Y", "N"),
        ]
        config.validation_excluded_marketing_types = DEFAULT_EXCLUDED_TYPES
        expected = spark_session.createDataFrame(
            [
                ("OFFSITE", "META", "IMPRESSIONS"),
                ("OFFSITE", "DV360_YOUTUBE", "IMPRESSIONS"),
            ],
            schema=METRICS_SCHEMA,
        )

        # Act
        actual = build_impression_metrics_df(spark_session, config)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)


class TestBuildSpendMetricsDf:

    def test_returns_spend_metrics_only(self, spark_session: SparkSession, minimal_config):
        # Scenario: is_inv=Y metrics returned; impression-only metrics excluded
        # Arrange
        expected = spark_session.createDataFrame(
            [
                ("OFFSITE", "META", "INTERNALS_MEDIA_SPEND"),
                ("INSTORE", "INSTORE", "TOTAL_MEDIA_COST"),
            ],
            schema=METRICS_SCHEMA,
        )

        # Act
        actual = build_spend_metrics_df(spark_session, minimal_config)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_returns_empty_df_when_no_spend_metrics(self, spark_session: SparkSession):
        # Scenario: no is_inv=Y entries; empty DataFrame returned
        # Arrange
        config = BaselineModellingOutputConfig.__new__(BaselineModellingOutputConfig)
        config.primary_metrics = [
            ("OFFSITE", "META", "TOTAL", "IMPRESSIONS", "Y", "N"),
        ]
        config.validation_excluded_marketing_types = DEFAULT_EXCLUDED_TYPES
        expected = spark_session.createDataFrame([], schema=METRICS_SCHEMA)

        # Act
        actual = build_spend_metrics_df(spark_session, config)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestResolveModellingChannels:

    def test_instore_maps_to_both_instore_variants(self, spark_session: SparkSession):
        # Scenario: INSTORE type maps to both INSTORE/INSTORE and IN-STORE/IN-STORE pairs
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), ["INSTORE"], [])],
            schema=CAMPAIGN_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), "INSTORE", "INSTORE"),
                ("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), "IN-STORE", "IN-STORE"),
            ],
            schema=RESOLVE_CHANNELS_SCHEMA,
        )

        # Act
        actual = resolve_modelling_channels(campaign_df)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_in_store_maps_to_both_instore_variants(self, spark_session: SparkSession):
        # Scenario: IN-STORE type maps to both IN-STORE/IN-STORE and INSTORE/INSTORE pairs
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), ["IN-STORE"], [])],
            schema=CAMPAIGN_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), "IN-STORE", "IN-STORE"),
                ("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), "INSTORE", "INSTORE"),
            ],
            schema=RESOLVE_CHANNELS_SCHEMA,
        )

        # Act
        actual = resolve_modelling_channels(campaign_df)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_coupon_at_till_maps_to_targeted_media(self, spark_session: SparkSession):
        # Scenario: COUPON-AT-TILL maps to TARGETED MEDIA / COUPON AT TILL
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), ["COUPON-AT-TILL"], [])],
            schema=CAMPAIGN_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), "TARGETED MEDIA", "COUPON AT TILL")],
            schema=RESOLVE_CHANNELS_SCHEMA,
        )

        # Act
        actual = resolve_modelling_channels(campaign_df)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_onsite_maps_to_gol_and_ecoupon(self, spark_session: SparkSession):
        # Scenario: ONSITE maps to ONSITE/ONSITE-GOL and ONSITE/ECOUPON
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), ["ONSITE"], [])],
            schema=CAMPAIGN_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), "ONSITE", "ONSITE-GOL"),
                ("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), "ONSITE", "ECOUPON"),
            ],
            schema=RESOLVE_CHANNELS_SCHEMA,
        )

        # Act
        actual = resolve_modelling_channels(campaign_df)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_offsite_meta_subchannel_maps_to_meta(self, spark_session: SparkSession):
        # Scenario: OFFSITE with Meta subchannel maps to OFFSITE/META
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), "OFFSITE", "META")],
            schema=RESOLVE_CHANNELS_SCHEMA,
        )

        # Act
        actual = resolve_modelling_channels(campaign_df)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_offsite_youtube_subchannel_maps_to_youtube(self, spark_session: SparkSession):
        # Scenario: OFFSITE with YouTube subchannel maps to OFFSITE/YOUTUBE
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), ["OFFSITE"], ["YouTube Video"])],
            schema=CAMPAIGN_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), "OFFSITE", "YOUTUBE")],
            schema=RESOLVE_CHANNELS_SCHEMA,
        )

        # Act
        actual = resolve_modelling_channels(campaign_df)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_unknown_offsite_subchannel_is_excluded(self, spark_session: SparkSession):
        # Scenario: OFFSITE with unrecognised subchannel produces no rows
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), ["OFFSITE"], ["UnknownNetwork"])],
            schema=CAMPAIGN_SCHEMA,
        )
        expected = spark_session.createDataFrame([], schema=RESOLVE_CHANNELS_SCHEMA)

        # Act
        actual = resolve_modelling_channels(campaign_df)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)

    def test_unrecognised_marketing_type_is_excluded(self, spark_session: SparkSession):
        # Scenario: unknown marketing type produces no rows
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 3, 31), ["TV"], [])],
            schema=CAMPAIGN_SCHEMA,
        )
        expected = spark_session.createDataFrame([], schema=RESOLVE_CHANNELS_SCHEMA)

        # Act
        actual = resolve_modelling_channels(campaign_df)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestCheckValueRange:

    def test_no_violations_returns_empty_df(self, spark_session: SparkSession):
        # Scenario: all metric values within [min, max]; no warnings produced
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 1000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "IMPRESSIONS", 500.0),
            ],
            schema=BASELINE_SCHEMA,
        )
        lookup_df = spark_session.createDataFrame(
            [("OFFSITE", "META", "IMPRESSIONS")], schema=METRICS_SCHEMA
        )
        expected = spark_session.createDataFrame([], schema=RANGE_CHECK_SCHEMA)

        # Act
        actual = check_value_range(baseline_df, lookup_df, min_threshold=0.0, max_threshold=2_000_000.0)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)

    def test_negative_value_raises_violation(self, spark_session: SparkSession):
        # Scenario: metric value below min_threshold triggers a HIGH-severity warning
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", -100.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "IMPRESSIONS", 500.0),
            ],
            schema=BASELINE_SCHEMA,
        )
        lookup_df = spark_session.createDataFrame(
            [("OFFSITE", "META", "IMPRESSIONS")], schema=METRICS_SCHEMA
        )
        expected = spark_session.createDataFrame(
            [(
                "BrandA", "CatA", "OFFSITE", "META", "IMPRESSIONS", 1,
                [{"week": "2024-01-01", "value": -100.0}],
                -100.0, -100.0, "HIGH",
                "OFFSITE/META IMPRESSIONS has 1 week(s) with values outside [0.0, 2000000.0] (min=-100.00, max=-100.00)",
            )],
            schema=RANGE_CHECK_SCHEMA,
        )

        # Act
        actual = check_value_range(baseline_df, lookup_df, min_threshold=0.0, max_threshold=2_000_000.0)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_value_above_max_raises_violation(self, spark_session: SparkSession):
        # Scenario: metric values above max_threshold; out_of_range_weeks and max_value correct
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 3_000_000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "IMPRESSIONS", 2_500_000.0),
            ],
            schema=BASELINE_SCHEMA,
        )
        lookup_df = spark_session.createDataFrame(
            [("OFFSITE", "META", "IMPRESSIONS")], schema=METRICS_SCHEMA
        )
        expected = spark_session.createDataFrame(
            [(
                "BrandA", "CatA", "OFFSITE", "META", "IMPRESSIONS", 2,
                [
                    {"week": "2024-01-01", "value": 3_000_000.0},
                    {"week": "2024-01-08", "value": 2_500_000.0},
                ],
                2_500_000.0, 3_000_000.0, "HIGH",
                "OFFSITE/META IMPRESSIONS has 2 week(s) with values outside [0.0, 2000000.0] (min=2500000.00, max=3000000.00)",
            )],
            schema=RANGE_CHECK_SCHEMA,
        )

        # Act
        actual = check_value_range(baseline_df, lookup_df, min_threshold=0.0, max_threshold=2_000_000.0)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_null_values_are_skipped(self, spark_session: SparkSession):
        # Scenario: null metric_value is not treated as a range violation
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", None)],
            schema=BASELINE_SCHEMA,
        )
        lookup_df = spark_session.createDataFrame(
            [("OFFSITE", "META", "IMPRESSIONS")], schema=METRICS_SCHEMA
        )
        expected = spark_session.createDataFrame([], schema=RANGE_CHECK_SCHEMA)

        # Act
        actual = check_value_range(baseline_df, lookup_df, min_threshold=0.0, max_threshold=2_000_000.0)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)

    def test_metric_not_in_lookup_is_excluded(self, spark_session: SparkSession):
        # Scenario: metric absent from lookup DataFrame is ignored even if out-of-range
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "CLICKS", -1.0)],
            schema=BASELINE_SCHEMA,
        )
        lookup_df = spark_session.createDataFrame(
            [("OFFSITE", "META", "IMPRESSIONS")], schema=METRICS_SCHEMA
        )
        expected = spark_session.createDataFrame([], schema=RANGE_CHECK_SCHEMA)

        # Act
        actual = check_value_range(baseline_df, lookup_df, min_threshold=0.0, max_threshold=2_000_000.0)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)

    def test_message_format_contains_thresholds_and_stats(self, spark_session: SparkSession):
        # Scenario: warning message includes channel, metric name, thresholds, and observed values
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", -50.0)],
            schema=BASELINE_SCHEMA,
        )
        lookup_df = spark_session.createDataFrame(
            [("OFFSITE", "META", "IMPRESSIONS")], schema=METRICS_SCHEMA
        )
        expected = spark_session.createDataFrame(
            [(
                "BrandA", "CatA", "OFFSITE", "META", "IMPRESSIONS", 1,
                [{"week": "2024-01-01", "value": -50.0}],
                -50.0, -50.0, "HIGH",
                "OFFSITE/META IMPRESSIONS has 1 week(s) with values outside [0.0, 2000000.0] (min=-50.00, max=-50.00)",
            )],
            schema=RANGE_CHECK_SCHEMA,
        )

        # Act
        actual = check_value_range(baseline_df, lookup_df, min_threshold=0.0, max_threshold=2_000_000.0)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)


class TestCheckMarketingImpressionsBudgetSignal:

    def test_no_zero_signal_returns_empty_df(self, spark_session: SparkSession, minimal_config):
        # Scenario: all campaign weeks have positive signal; no warnings produced
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 28), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 10000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "IMPRESSIONS", 8000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "INTERNALS_MEDIA_SPEND", 5000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "INTERNALS_MEDIA_SPEND", 4000.0),
            ],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame([], schema=SIGNAL_CHECK_SCHEMA)

        # Act
        actual = check_marketing_impressions_budget_signal(
            spark_session, campaign_df, baseline_df, config=minimal_config
        )

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)

    def test_zero_impressions_in_campaign_week_returns_warning(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: one campaign week with zero impressions triggers a HIGH-severity warning
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "IMPRESSIONS", 5000.0),
            ],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [(
                "BrandA", "CatA", "OFFSITE", "META", "impressions", 1, 2, "HIGH",
                "OFFSITE/META has zero impressions signal in 1/2 campaign weeks",
            )],
            schema=SIGNAL_CHECK_SCHEMA,
        )

        # Act
        actual = check_marketing_impressions_budget_signal(
            spark_session, campaign_df, baseline_df, config=minimal_config
        )

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_no_matching_campaign_channels_returns_empty_df(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: campaign uses an unresolvable type; inner join produces no rows
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["TV"], [])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0)],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame([], schema=SIGNAL_CHECK_SCHEMA)

        # Act
        actual = check_marketing_impressions_budget_signal(
            spark_session, campaign_df, baseline_df, config=minimal_config
        )

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)

    def test_out_of_campaign_date_range_weeks_are_ignored(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: zero-signal week outside campaign date range is not flagged
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 8), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0),  # before campaign
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "IMPRESSIONS", 5000.0),  # in campaign
            ],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame([], schema=SIGNAL_CHECK_SCHEMA)

        # Act
        actual = check_marketing_impressions_budget_signal(
            spark_session, campaign_df, baseline_df, config=minimal_config
        )

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestCheckMarketingImpressionsRange:

    def test_impressions_within_range_returns_empty_df(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: impression value within [0, 2_000_000]; no warnings produced
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 100_000.0)],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame([], schema=RANGE_CHECK_SCHEMA)

        # Act
        actual = check_marketing_impressions_range(spark_session, baseline_df, config=minimal_config)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)

    def test_negative_impression_value_raises_warning(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: negative impression value triggers a HIGH-severity warning
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", -1.0)],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [(
                "BrandA", "CatA", "OFFSITE", "META", "IMPRESSIONS", 1,
                [{"week": "2024-01-01", "value": -1.0}],
                -1.0, -1.0, "HIGH",
                "OFFSITE/META IMPRESSIONS has 1 week(s) with values outside [0.0, 2000000.0] (min=-1.00, max=-1.00)",
            )],
            schema=RANGE_CHECK_SCHEMA,
        )

        # Act
        actual = check_marketing_impressions_range(spark_session, baseline_df, config=minimal_config)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_uses_default_config_when_none_provided(self, spark_session: SparkSession):
        # Scenario: config=None falls back to default thresholds without error
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 500_000.0)],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame([], schema=RANGE_CHECK_SCHEMA)

        # Act
        actual = check_marketing_impressions_range(spark_session, baseline_df, config=None)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestCheckMarketingBudgetRange:

    def test_spend_within_range_returns_empty_df(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: spend value within [0.0, 50_000]; no warnings produced
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "INTERNALS_MEDIA_SPEND", 10_000.0)],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame([], schema=RANGE_CHECK_SCHEMA)

        # Act
        actual = check_marketing_budget_range(spark_session, baseline_df, config=minimal_config)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)

    def test_spend_above_max_raises_warning(self, spark_session: SparkSession, minimal_config):
        # Scenario: spend value above max_spend_threshold triggers a HIGH-severity warning
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "INTERNALS_MEDIA_SPEND", 99_999.0)],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [(
                "BrandA", "CatA", "OFFSITE", "META", "INTERNALS_MEDIA_SPEND", 1,
                [{"week": "2024-01-01", "value": 99_999.0}],
                99_999.0, 99_999.0, "HIGH",
                "OFFSITE/META INTERNALS_MEDIA_SPEND has 1 week(s) with values outside [0.0, 50000.0] (min=99999.00, max=99999.00)",
            )],
            schema=RANGE_CHECK_SCHEMA,
        )

        # Act
        actual = check_marketing_budget_range(spark_session, baseline_df, config=minimal_config)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_negative_spend_raises_warning(self, spark_session: SparkSession, minimal_config):
        # Scenario: negative spend value triggers a warning with correct min_value
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "INSTORE", "INSTORE", date(2024, 1, 1), "TOTAL_MEDIA_COST", -500.0)],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame(
            [(
                "BrandA", "CatA", "INSTORE", "INSTORE", "TOTAL_MEDIA_COST", 1,
                [{"week": "2024-01-01", "value": -500.0}],
                -500.0, -500.0, "HIGH",
                "INSTORE/INSTORE TOTAL_MEDIA_COST has 1 week(s) with values outside [0.0, 50000.0] (min=-500.00, max=-500.00)",
            )],
            schema=RANGE_CHECK_SCHEMA,
        )

        # Act
        actual = check_marketing_budget_range(spark_session, baseline_df, config=minimal_config)

        # Assert
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)

    def test_uses_default_config_when_none_provided(self, spark_session: SparkSession):
        # Scenario: config=None falls back to default thresholds without error
        # Arrange
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "INSTORE", "INSTORE", date(2024, 1, 1), "TOTAL_MEDIA_COST", 100.0)],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame([], schema=RANGE_CHECK_SCHEMA)

        # Act
        actual = check_marketing_budget_range(spark_session, baseline_df, config=None)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestRunAllMarketingChecks:

    def test_returns_warnings_from_all_three_checks(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: data triggering each check; all three check_name values present in output
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "IMPRESSIONS", 3_000_000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "INTERNALS_MEDIA_SPEND", 99_999.0),
            ],
            schema=BASELINE_SCHEMA,
        )
        expected_check_names = spark_session.createDataFrame(
            [("marketing_signal_check",), ("impressions_range_check",), ("budget_range_check",)],
            schema="check_name string",
        )

        # Act
        actual = run_all_marketing_checks(spark_session, campaign_df, baseline_df, minimal_config)

        # Assert
        assert_df_equality(
            actual.select("check_name").distinct(),
            expected_check_names,
            ignore_row_order=True,
            ignore_nullable=True,
        )

    def test_unified_schema_columns_present(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: output DataFrame contains all required unified schema columns
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0)],
            schema=BASELINE_SCHEMA,
        )

        # Act
        actual = run_all_marketing_checks(spark_session, campaign_df, baseline_df, minimal_config)

        # Assert
        assert set(actual.columns) == {f.name for f in ALL_CHECKS_SCHEMA.fields}

    def test_metadata_is_valid_json(self, spark_session: SparkSession, minimal_config):
        # Scenario: metadata column is a valid JSON string for every warning row
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0)],
            schema=BASELINE_SCHEMA,
        )

        # Act
        rows = run_all_marketing_checks(spark_session, campaign_df, baseline_df, minimal_config).collect()

        # Assert
        for row in rows:
            parsed = json.loads(row["metadata"])
            assert isinstance(parsed, dict)

    def test_metadata_includes_threshold_range_for_each_check(
        self, spark_session: SparkSession, minimal_config
    ):
        # Scenario: each warning metadata payload includes the threshold range used by the check
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "IMPRESSIONS", 3_000_000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "INTERNALS_MEDIA_SPEND", 99_999.0),
            ],
            schema=BASELINE_SCHEMA,
        )

        # Act
        rows = run_all_marketing_checks(spark_session, campaign_df, baseline_df, minimal_config).collect()
        metadata_by_check = {row["check_name"]: json.loads(row["metadata"]) for row in rows}

        # Assert
        assert metadata_by_check["marketing_signal_check"]["threshold_range"] == [0, 0]
        assert metadata_by_check["impressions_range_check"]["threshold_range"] == [
            minimal_config.min_impressions_threshold,
            minimal_config.max_impressions_threshold,
        ]
        assert metadata_by_check["budget_range_check"]["threshold_range"] == [
            minimal_config.min_spend_threshold,
            minimal_config.max_spend_threshold,
        ]

    def test_no_warnings_returns_empty_df(self, spark_session: SparkSession, minimal_config):
        # Scenario: clean data with no violations; union of all checks is empty
        # Arrange
        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 10_000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "IMPRESSIONS", 8_000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "INTERNALS_MEDIA_SPEND", 5_000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "INTERNALS_MEDIA_SPEND", 4_000.0),
            ],
            schema=BASELINE_SCHEMA,
        )
        expected = spark_session.createDataFrame([], schema=ALL_CHECKS_SCHEMA)

        # Act
        actual = run_all_marketing_checks(spark_session, campaign_df, baseline_df, minimal_config)

        # Assert
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestPublishMarketingValidationMetrics:

    @mock.patch(
        "spark_pipeline.metrics.baseline_validation_metrics.marketing_validation_metrics.MetricsPublisher"
    )
    def test_range_event_keeps_zero_value_and_moves_thresholds_to_metadata(
        self, mock_publisher_class, spark_session: SparkSession, minimal_config
    ):
        # Scenario: range-check event keeps value=0, publishes threshold_range in metadata,
        # and omits out_of_range_week_dates metadata.
        # Arrange
        mock_publisher = MagicMock()
        mock_publisher_class.return_value = mock_publisher

        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 3_000_000.0)],
            schema=BASELINE_SCHEMA,
        )

        # Act
        publish_marketing_validation_metrics(
            spark=spark_session,
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
            metrics_topic_arn="arn:aws:sns:us-east-1:123456789:test",
            correlation_id="corr-thresholds",
            config=minimal_config,
        )

        # Assert
        assert mock_publisher.publish_event.call_count == 1
        event = mock_publisher.publish_event.call_args_list[0][1]["event"]
        metadata = json.loads(event.metadata)
        assert event.value == 0
        assert metadata["threshold_range"] == [
            minimal_config.min_impressions_threshold,
            minimal_config.max_impressions_threshold,
        ]
        assert "out_of_range_week_dates" not in metadata

    @mock.patch(
        "spark_pipeline.metrics.baseline_validation_metrics.marketing_validation_metrics.MetricsPublisher"
    )
    def test_publishes_one_event_per_warning(
        self, mock_publisher_class, spark_session: SparkSession, minimal_config
    ):
        # Scenario: one warning row results in one publish_event call
        # Arrange
        mock_publisher = MagicMock()
        mock_publisher_class.return_value = mock_publisher

        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0)],
            schema=BASELINE_SCHEMA,
        )

        # Act
        publish_marketing_validation_metrics(
            spark=spark_session,
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
            metrics_topic_arn="arn:aws:sns:us-east-1:123456789:test",
            correlation_id="corr-001",
            config=minimal_config,
        )

        # Assert
        assert mock_publisher.publish_event.call_count >= 1
        call_kwargs = mock_publisher.publish_event.call_args_list[0][1]
        assert call_kwargs["message_subject"] == "Baseline Validation Metrics Event"
        event = call_kwargs["event"]
        assert event.channel_name == "META"

    @mock.patch(
        "spark_pipeline.metrics.baseline_validation_metrics.marketing_validation_metrics.MetricsPublisher"
    )
    def test_signal_event_keeps_zero_value_and_includes_threshold_range_metadata(
        self, mock_publisher_class, spark_session: SparkSession, minimal_config
    ):
        # Scenario: signal warnings still publish value=0 while metadata includes threshold_range
        # Arrange
        mock_publisher = MagicMock()
        mock_publisher_class.return_value = mock_publisher

        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0)],
            schema=BASELINE_SCHEMA,
        )

        # Act
        publish_marketing_validation_metrics(
            spark=spark_session,
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
            metrics_topic_arn="arn:aws:sns:us-east-1:123456789:test",
            correlation_id="corr-signal-thresholds",
            config=minimal_config,
        )

        # Assert
        event = mock_publisher.publish_event.call_args_list[0][1]["event"]
        assert event.value == 0
        assert json.loads(event.metadata)["threshold_range"] == [0, 0]

    @mock.patch(
        "spark_pipeline.metrics.baseline_validation_metrics.marketing_validation_metrics.MetricsPublisher"
    )
    def test_correlation_id_included_in_metadata(
        self, mock_publisher_class, spark_session: SparkSession, minimal_config
    ):
        # Scenario: correlation_id is included in the published event metadata JSON
        # Arrange
        mock_publisher = MagicMock()
        mock_publisher_class.return_value = mock_publisher

        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0)],
            schema=BASELINE_SCHEMA,
        )

        # Act
        publish_marketing_validation_metrics(
            spark=spark_session,
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
            metrics_topic_arn="arn:aws:sns:us-east-1:123456789:test",
            correlation_id="corr-xyz",
            config=minimal_config,
        )

        # Assert
        event = mock_publisher.publish_event.call_args_list[0][1]["event"]
        metadata = json.loads(event.metadata)
        assert metadata["correlation_id"] == "corr-xyz"
        assert metadata["channel_name"] == "META"
        assert event.channel_name == "META"

    @mock.patch(
        "spark_pipeline.metrics.baseline_validation_metrics.marketing_validation_metrics.MetricsPublisher"
    )
    def test_publish_failure_does_not_raise(
        self, mock_publisher_class, spark_session: SparkSession, minimal_config
    ):
        # Scenario: publish_event raising an exception is caught; function completes normally
        # Arrange
        mock_publisher = MagicMock()
        mock_publisher.publish_event.side_effect = RuntimeError("SNS unavailable")
        mock_publisher_class.return_value = mock_publisher

        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 0.0)],
            schema=BASELINE_SCHEMA,
        )

        # Act & Assert — should not propagate the exception
        publish_marketing_validation_metrics(
            spark=spark_session,
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
            metrics_topic_arn="arn:aws:sns:us-east-1:123456789:test",
            correlation_id="corr-001",
            config=minimal_config,
        )

    @mock.patch(
        "spark_pipeline.metrics.baseline_validation_metrics.marketing_validation_metrics.MetricsPublisher"
    )
    def test_no_warnings_means_no_publish_calls(
        self, mock_publisher_class, spark_session: SparkSession, minimal_config
    ):
        # Scenario: no violations; publish_event is never called
        # Arrange
        mock_publisher = MagicMock()
        mock_publisher_class.return_value = mock_publisher

        campaign_df = spark_session.createDataFrame(
            [("BrandA", "CatA", date(2024, 1, 1), date(2024, 1, 14), ["OFFSITE"], ["Meta Paid Social"])],
            schema=CAMPAIGN_SCHEMA,
        )
        baseline_df = spark_session.createDataFrame(
            [
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "IMPRESSIONS", 10_000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "IMPRESSIONS", 8_000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 1), "INTERNALS_MEDIA_SPEND", 5_000.0),
                ("BrandA", "CatA", "OFFSITE", "META", date(2024, 1, 8), "INTERNALS_MEDIA_SPEND", 4_000.0),
            ],
            schema=BASELINE_SCHEMA,
        )

        # Act
        publish_marketing_validation_metrics(
            spark=spark_session,
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
            metrics_topic_arn="arn:aws:sns:us-east-1:123456789:test",
            correlation_id="corr-001",
            config=minimal_config,
        )

        # Assert
        mock_publisher.publish_event.assert_not_called()
