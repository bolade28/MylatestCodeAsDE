from chispa.dataframe_comparer import assert_df_equality
from pyspark.sql import Row, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from spark_pipeline.common.variables import Severity
from spark_pipeline.schemas.pipeline_summary import PipelineSummaryMetricsSchema
from spark_pipeline.metrics.pipeline_summary.incrementality_layer_summary import (
    get_calibration_audit_details,
    get_features_overview,
    get_incrementality_output_results,
    get_ucm_details,
    incrementality_layer_summary,
)

CORRELATION_ID = "68849197-d2c9-4976-a408-5ad30f56b33e"
SOURCE_NAME = "baseline_modelling_dataset"

INPUT_SCHEMA = PipelineSummaryMetricsSchema.input_schema
FP_SCHEMA = PipelineSummaryMetricsSchema.fp_schema
OUTPUT_SCHEMA = PipelineSummaryMetricsSchema.pipeline_summary_metric_schema

CALIBRATION_SCHEMA = PipelineSummaryMetricsSchema.calibration_output_schema
CALIBRATION_AUDIT_SCHEMA = PipelineSummaryMetricsSchema.calibration_audit_schema
UCM_OUTPUT_SCHEMA = PipelineSummaryMetricsSchema.ucm_output_schema
UCM_BASE_SCHEMA = PipelineSummaryMetricsSchema.ucm_base_schema


def _make_input_row(**kwargs) -> Row:
    defaults = dict(
        variable_cd="PAC_POT_693_OFF_MET_TOT_CLI",
        marketing_type_name="OFFSITE",
        marketing_channel_name="META",
        marketing_sub_channel_name="TOTAL",
        metric_name="CLICKS",
        metric_value=0.0,
    )
    defaults.update(kwargs)
    return Row(**defaults)


# Columns to compare excluding load_timestamp (current_timestamp) and metadata (checked separately)
_STABLE_COLS = ["correlation_id", "name", "data_group", "data_sources", "severity"]


def test_get_features_overview_returns_expected_columns(spark_session: SparkSession):
    # Arrange
    input_df = spark_session.createDataFrame([_make_input_row()], schema=INPUT_SCHEMA)

    # Act
    result = get_features_overview(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name=SOURCE_NAME,
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(
            correlation_id=CORRELATION_ID,
            name=f"features_overview_{SOURCE_NAME}",
            data_group="features_overview",
            data_sources=SOURCE_NAME,
            severity=Severity.HIGH.value,
        )],
        schema=T.StructType([OUTPUT_SCHEMA[c] for c in _STABLE_COLS]),
    )
    assert_df_equality(result.select(_STABLE_COLS), expected, ignore_row_order=True, ignore_nullable=True)


def test_get_features_overview_scalar_fields(spark_session: SparkSession):
    # Arrange
    input_df = spark_session.createDataFrame([_make_input_row()], schema=INPUT_SCHEMA)

    # Act
    result = get_features_overview(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name=SOURCE_NAME,
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(
            correlation_id=CORRELATION_ID,
            name=f"features_overview_{SOURCE_NAME}",
            data_group="features_overview",
            data_sources=SOURCE_NAME,
            severity=Severity.HIGH.value,
        )],
        schema=T.StructType([OUTPUT_SCHEMA[c] for c in _STABLE_COLS]),
    )
    assert_df_equality(result.select(_STABLE_COLS), expected, ignore_row_order=True, ignore_nullable=True)


def test_get_features_overview_metadata_contains_aggregates(spark_session: SparkSession):
    # Arrange — two rows for the same groupBy key so row_count=2 and sum is verified
    rows = [
        _make_input_row(metric_value=1.0),
        _make_input_row(metric_value=3.0),
    ]
    input_df = spark_session.createDataFrame(rows, schema=INPUT_SCHEMA)

    # Act — parse metadata JSON into columns for structured comparison
    result = (
        get_features_overview(df=input_df, correlation_id=CORRELATION_ID, source_name=SOURCE_NAME)
        .select(F.from_json(
            F.col("metadata"),
            "features_overview ARRAY<STRUCT<variable_cd: STRING, marketing_type_name: STRING, "
            "marketing_channel_name: STRING, marketing_sub_channel_name: STRING, "
            "metric_name: STRING, row_count: BIGINT, sum_metric_value: DOUBLE>>",
        ).alias("m"))
        .select(F.explode("m.features_overview").alias("f"))
        .select("f.*")
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(variable_cd="PAC_POT_693_OFF_MET_TOT_CLI", marketing_type_name="OFFSITE",
             marketing_channel_name="META", marketing_sub_channel_name="TOTAL",
             metric_name="CLICKS", row_count=2, sum_metric_value=4.0)],
        schema=T.StructType([
            T.StructField("variable_cd", T.StringType(), True),
            T.StructField("marketing_type_name", T.StringType(), True),
            T.StructField("marketing_channel_name", T.StringType(), True),
            T.StructField("marketing_sub_channel_name", T.StringType(), True),
            T.StructField("metric_name", T.StringType(), True),
            T.StructField("row_count", T.LongType(), True),
            T.StructField("sum_metric_value", T.DoubleType(), True),
        ]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_features_overview_groups_by_variable_dimensions(spark_session: SparkSession):
    # Arrange — two distinct variable groups → both captured in a single output row's metadata
    rows = [
        _make_input_row(variable_cd="VAR_A", marketing_channel_name="META", metric_value=1.0),
        _make_input_row(variable_cd="VAR_B", marketing_channel_name="YOUTUBE", metric_value=2.0),
    ]
    input_df = spark_session.createDataFrame(rows, schema=INPUT_SCHEMA)

    # Act
    result = get_features_overview(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name=SOURCE_NAME,
    )

    # Assert — one summary row total, both variable groups are in metadata
    assert result.count() == 1


def test_get_features_overview_custom_value_col(spark_session: SparkSession):
    # Arrange — feature-prioritisation dataset uses variable_importance_rank
    input_df = spark_session.createDataFrame([_make_fp_row(variable_importance_rank=5.0)], schema=FP_SCHEMA)

    # Act — parse metadata JSON for structured comparison
    result = (
        get_features_overview(
            df=input_df,
            correlation_id=CORRELATION_ID,
            source_name="feature_prioritisation",
            value_col="variable_importance_rank",
        )
        .select(F.from_json(
            F.col("metadata"),
            "features_overview ARRAY<STRUCT<sum_metric_value: DOUBLE>>",
        ).alias("m"))
        .select(F.explode("m.features_overview").alias("f"))
        .select("f.sum_metric_value")
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(sum_metric_value=5.0)],
        schema=T.StructType([T.StructField("sum_metric_value", T.DoubleType(), True)]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_features_overview_custom_severity(spark_session: SparkSession):
    # Arrange
    input_df = spark_session.createDataFrame([_make_input_row()], schema=INPUT_SCHEMA)

    # Act
    result = get_features_overview(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name=SOURCE_NAME,
        severity=Severity.LOW,
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(severity=Severity.LOW.value)],
        schema=T.StructType([OUTPUT_SCHEMA["severity"]]),
    )
    assert_df_equality(result.select("severity"), expected, ignore_row_order=True, ignore_nullable=True)


def test_get_features_overview_filters_out_external_marketing_type(spark_session: SparkSession):
    # Arrange — one EXTERNAL row (should be dropped) and one non-external row
    rows = [
        _make_input_row(marketing_type_name="EXTERNAL", variable_cd="EXT_VAR"),
        _make_input_row(marketing_type_name="OFFSITE", variable_cd="OFF_VAR"),
    ]
    input_df = spark_session.createDataFrame(rows, schema=INPUT_SCHEMA)

    # Act — only OFFSITE row survives; check via data_sources column
    result = get_features_overview(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name=SOURCE_NAME,
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(data_sources=SOURCE_NAME)],
        schema=T.StructType([OUTPUT_SCHEMA["data_sources"]]),
    )
    assert_df_equality(result.select("data_sources"), expected, ignore_row_order=True, ignore_nullable=True)


def test_get_features_overview_filters_external_case_insensitive(spark_session: SparkSession):
    # Arrange — lowercase "external" must also be filtered
    rows = [
        _make_input_row(marketing_type_name="external", variable_cd="ext_var"),
        _make_input_row(marketing_type_name="External", variable_cd="ext_var2"),
    ]
    input_df = spark_session.createDataFrame(rows, schema=INPUT_SCHEMA)

    # Act
    result = get_features_overview(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name=SOURCE_NAME,
    )

    # Assert — all rows filtered → one row with empty features_overview list
    assert result.count() == 1
    features = (
        result
        .select(F.from_json(F.col("metadata"), "features_overview ARRAY<STRUCT<variable_cd: STRING>>").alias("m"))
        .select("m.features_overview")
        .collect()[0][0]
    )
    assert features == []


def test_get_features_overview_all_external_returns_empty(spark_session: SparkSession):
    # Arrange — all rows are EXTERNAL
    rows = [
        _make_input_row(marketing_type_name="EXTERNAL", variable_cd="TOT_TOT_TOT_EXT_SPO_6_N"),
        _make_input_row(marketing_type_name="EXTERNAL", variable_cd="TOT_TOT_TOT_EXT_HOL_EAS_HOL"),
    ]
    input_df = spark_session.createDataFrame(rows, schema=INPUT_SCHEMA)

    # Act
    result = get_features_overview(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name=SOURCE_NAME,
    )

    # Assert — all rows are EXTERNAL → one row with empty features_overview list
    assert result.count() == 1
    features = (
        result
        .select(F.from_json(F.col("metadata"), "features_overview ARRAY<STRUCT<variable_cd: STRING>>").alias("m"))
        .select("m.features_overview")
        .collect()[0][0]
    )
    assert features == []


def test_get_features_overview_empty_input_returns_empty(spark_session: SparkSession):
    # Arrange
    input_df = spark_session.createDataFrame([], schema=INPUT_SCHEMA)

    # Act
    result = get_features_overview(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name=SOURCE_NAME,
    )

    # Assert — empty input → one row with empty features_overview list
    assert result.count() == 1
    features = (
        result
        .select(F.from_json(F.col("metadata"), "features_overview ARRAY<STRUCT<variable_cd: STRING>>").alias("m"))
        .select("m.features_overview")
        .collect()[0][0]
    )
    assert features == []


def _make_fp_row(**kwargs) -> Row:
    defaults = dict(
        variable_cd="PAC_POT_693_OFF_MET_TOT_CLI",
        marketing_type_name="OFFSITE",
        marketing_channel_name="META",
        marketing_sub_channel_name="TOTAL",
        metric_name="CLICKS",
        variable_importance_rank=3.0,
    )
    defaults.update(kwargs)
    return Row(**defaults)


def _make_ucm_output_row(**kwargs) -> Row:
    defaults = dict(
        week_start_dt=None,
        super_category_name="SOFT DRINKS",
        unique_brand_name="DIET COKE",
        cluster_num="69E7574F16D05F396FF99E6C",
        iteration="level_var:_set_1",
        modelling_type="UCM",
        metric_name="sales",
        best_iteration="Y",
        metric_value=1000.0,
        rsq=0.92,
        wsmape=0.08,
        baseline_perc=None,
        load_ts=None,
        job_run_id=None,
    )
    defaults.update(kwargs)
    return Row(**defaults)


def _make_ucm_base_row(**kwargs) -> Row:
    defaults = dict(
        wdate=None,
        modelling_cluster="DIET COKE | COCA COLA~SOFT DRINKS~69E7574F16D05F396FF99E6C",
        iteration="level_var:_set_1",
        variable="level",
        value=889301.05,
        time_stamp=None,
        load_ts=None,
    )
    defaults.update(kwargs)
    return Row(**defaults)


def _make_calibration_row(**kwargs) -> Row:
    defaults = dict(
        run_date=None,
        correlation_id=CORRELATION_ID,
        load_ts=None,
        unique_brand_name="BRAND_A",
        super_category_name="CATEGORY",
        sub_category_name="SUB_CATEGORY",
        metric_name="ucm_incrementality",
        metric_value=100.0,
    )
    defaults.update(kwargs)
    return Row(**defaults)


def _make_calibration_audit_row(**kwargs) -> Row:
    defaults = dict(
        run_date=None,
        correlation_id=CORRELATION_ID,
        load_ts=None,
        unique_brand_name="BRAND_A",
        super_category_name="CATEGORY",
        sub_category_name="SUB_CATEGORY",
        marketing_type="OFFSITE",
        mean_log_uplift=0.1,
        var_log_uplift=0.01,
        count_campaigns=5,
        distribution_type="normal",
        shift_parameter=0.0,
        rev_similarity_percentile=0.75,
        scaling_factor=1.0,
        sample_median=0.1,
        sample_mode=0.1,
        z_score=1.5,
        channel_prior_failures=0,
    )
    defaults.update(kwargs)
    return Row(**defaults)


# --- get_incrementality_output_results ---

def test_get_incrementality_output_results_returns_expected_scalar_fields(spark_session: SparkSession):
    # Arrange — one row per metric for a single brand
    rows = [
        _make_calibration_row(metric_name="ucm_incrementality", metric_value=100.0),
        _make_calibration_row(metric_name="bypass_incrementality", metric_value=20.0),
        _make_calibration_row(metric_name="during_incrementality", metric_value=10.0),
        _make_calibration_row(metric_name="adjusted_calibrated_incrementality", metric_value=130.0),
    ]
    input_df = spark_session.createDataFrame(rows, schema=CALIBRATION_SCHEMA)

    # Act
    result = get_incrementality_output_results(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name="incremental_shrinkage",
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(
            correlation_id=CORRELATION_ID,
            name="incrementality_output_results_incremental_shrinkage",
            data_group="incrementality_output_results",
            data_sources="incremental_shrinkage",
            severity=Severity.HIGH.value,
        )],
        schema=T.StructType([OUTPUT_SCHEMA[c] for c in _STABLE_COLS]),
    )
    assert_df_equality(result.select(_STABLE_COLS), expected, ignore_row_order=True, ignore_nullable=True)


def test_get_incrementality_output_results_metadata_contains_all_metrics(spark_session: SparkSession):
    # Arrange
    rows = [
        _make_calibration_row(metric_name="ucm_incrementality", metric_value=100.0),
        _make_calibration_row(metric_name="bypass_incrementality", metric_value=20.0),
        _make_calibration_row(metric_name="during_incrementality", metric_value=10.0),
        _make_calibration_row(metric_name="adjusted_calibrated_incrementality", metric_value=130.0),
        _make_calibration_row(metric_name="calibrated_incrementality", metric_value=120.0),
    ]
    input_df = spark_session.createDataFrame(rows, schema=CALIBRATION_SCHEMA)

    # Act — parse metadata JSON into columns
    result = (
        get_incrementality_output_results(
            df=input_df,
            correlation_id=CORRELATION_ID,
            source_name="incremental_shrinkage",
        )
        .select(F.from_json(
            F.col("metadata"),
            "unique_brand_name STRING, "
            "total_ucm_booking_period_incrementality DOUBLE, "
            "total_calibrated_incrementality DOUBLE, "
            "total_bypass_incrementality DOUBLE, "
            "total_during_incrementality DOUBLE, "
            "total_adjusted_calibrated_incrementality DOUBLE",
        ).alias("m"))
        .select("m.*")
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(
            unique_brand_name="BRAND_A",
            total_ucm_booking_period_incrementality=100.0,
            total_calibrated_incrementality=120.0,
            total_bypass_incrementality=20.0,
            total_during_incrementality=10.0,
            total_adjusted_calibrated_incrementality=130.0,
        )],
        schema=T.StructType([
            T.StructField("unique_brand_name", T.StringType(), True),
            T.StructField("total_ucm_booking_period_incrementality", T.DoubleType(), True),
            T.StructField("total_calibrated_incrementality", T.DoubleType(), True),
            T.StructField("total_bypass_incrementality", T.DoubleType(), True),
            T.StructField("total_during_incrementality", T.DoubleType(), True),
            T.StructField("total_adjusted_calibrated_incrementality", T.DoubleType(), True),
        ]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_incrementality_output_results_one_row_per_brand(spark_session: SparkSession):
    # Arrange — two brands, each with the same set of metrics
    rows = [
        _make_calibration_row(unique_brand_name="BRAND_A", metric_name="ucm_incrementality", metric_value=100.0),
        _make_calibration_row(unique_brand_name="BRAND_B", metric_name="ucm_incrementality", metric_value=200.0),
    ]
    input_df = spark_session.createDataFrame(rows, schema=CALIBRATION_SCHEMA)

    # Act
    result = get_incrementality_output_results(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name="incremental_shrinkage",
    )

    # Assert — two rows, one per brand
    assert result.count() == 2


def test_get_incrementality_output_results_sums_metric_values_per_brand(spark_session: SparkSession):
    # Arrange — two rows for the same brand and metric → values should be summed
    rows = [
        _make_calibration_row(unique_brand_name="BRAND_A", metric_name="ucm_incrementality", metric_value=60.0),
        _make_calibration_row(unique_brand_name="BRAND_A", metric_name="ucm_incrementality", metric_value=40.0),
    ]
    input_df = spark_session.createDataFrame(rows, schema=CALIBRATION_SCHEMA)

    # Act
    result = (
        get_incrementality_output_results(
            df=input_df,
            correlation_id=CORRELATION_ID,
            source_name="incremental_shrinkage",
        )
        .select(F.from_json(
            F.col("metadata"),
            "total_ucm_booking_period_incrementality DOUBLE",
        ).alias("m"))
        .select("m.total_ucm_booking_period_incrementality")
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(total_ucm_booking_period_incrementality=100.0)],
        schema=T.StructType([T.StructField("total_ucm_booking_period_incrementality", T.DoubleType(), True)]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_incrementality_output_results_null_for_absent_metric(spark_session: SparkSession):
    # Arrange — only ucm_incrementality present; bypass is absent → should be null in metadata
    rows = [_make_calibration_row(metric_name="ucm_incrementality", metric_value=100.0)]
    input_df = spark_session.createDataFrame(rows, schema=CALIBRATION_SCHEMA)

    # Act
    result = (
        get_incrementality_output_results(
            df=input_df,
            correlation_id=CORRELATION_ID,
            source_name="incremental_shrinkage",
        )
        .select(F.from_json(
            F.col("metadata"),
            "total_bypass_incrementality DOUBLE",
        ).alias("m"))
        .select("m.total_bypass_incrementality")
    )

    # Assert — absent metric column is null
    expected = spark_session.createDataFrame(
        [Row(total_bypass_incrementality=None)],
        schema=T.StructType([T.StructField("total_bypass_incrementality", T.DoubleType(), True)]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_incrementality_output_results_custom_severity(spark_session: SparkSession):
    # Arrange
    rows = [_make_calibration_row()]
    input_df = spark_session.createDataFrame(rows, schema=CALIBRATION_SCHEMA)

    # Act
    result = get_incrementality_output_results(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name="incremental_shrinkage",
        severity=Severity.LOW,
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(severity=Severity.LOW.value)],
        schema=T.StructType([OUTPUT_SCHEMA["severity"]]),
    )
    assert_df_equality(result.select("severity"), expected, ignore_row_order=True, ignore_nullable=True)


def test_get_incrementality_output_results_empty_input_returns_empty(spark_session: SparkSession):
    # Arrange
    input_df = spark_session.createDataFrame([], schema=CALIBRATION_SCHEMA)

    # Act
    result = get_incrementality_output_results(
        df=input_df,
        correlation_id=CORRELATION_ID,
        source_name="incremental_shrinkage",
    )

    # Assert
    expected = spark_session.createDataFrame([], schema=OUTPUT_SCHEMA)
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


# --- get_ucm_details ---

def test_get_ucm_details_returns_expected_scalar_fields(spark_session: SparkSession):
    # Arrange
    ucm_output_df = spark_session.createDataFrame(
        [_make_ucm_output_row()], schema=UCM_OUTPUT_SCHEMA
    )
    ucm_base_df = spark_session.createDataFrame(
        [_make_ucm_base_row(variable="level", value=889301.05)],
        schema=UCM_BASE_SCHEMA,
    )

    # Act
    result = get_ucm_details(
        ucm_output_data_df=ucm_output_df,
        ucm_base_data_df=ucm_base_df,
        correlation_id=CORRELATION_ID,
        source_name="ucm_output",
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(
            correlation_id=CORRELATION_ID,
            name="ucm_details_ucm_output",
            data_group="ucm_details",
            data_sources="ucm_output",
            severity=Severity.HIGH.value,
        )],
        schema=T.StructType([OUTPUT_SCHEMA[c] for c in _STABLE_COLS]),
    )
    assert_df_equality(result.select(_STABLE_COLS), expected, ignore_row_order=True, ignore_nullable=True)


def test_get_ucm_details_metadata_contains_metrics_and_hyperparams(spark_session: SparkSession):
    # Arrange — one row per hyperparameter variable plus one feature
    ucm_output_df = spark_session.createDataFrame(
        [_make_ucm_output_row(rsq=0.92, wsmape=0.08)], schema=UCM_OUTPUT_SCHEMA
    )
    ucm_base_rows = [
        _make_ucm_base_row(variable="level", value=889301.05),
        _make_ucm_base_row(variable="cycle", value=None),
        _make_ucm_base_row(variable="level_base", value=889301.05),
        _make_ucm_base_row(variable="sof_die_69e_sal_sal_tot_to2", value=1071804.69),
    ]
    ucm_base_df = spark_session.createDataFrame(ucm_base_rows, schema=UCM_BASE_SCHEMA)

    # Act — parse metadata JSON for structured comparison
    result = (
        get_ucm_details(
            ucm_output_data_df=ucm_output_df,
            ucm_base_data_df=ucm_base_df,
            correlation_id=CORRELATION_ID,
            source_name="ucm_output",
        )
        .select(F.from_json(
            F.col("metadata"),
            "rsq DOUBLE, wsmape DOUBLE, iteration STRING, level DOUBLE, cycle DOUBLE, level_base DOUBLE",
        ).alias("m"))
        .select("m.*")
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(rsq=0.92, wsmape=0.08, iteration="level_var:_set_1", level=889301.05, cycle=None, level_base=889301.05)],
        schema=T.StructType([
            T.StructField("rsq", T.DoubleType(), True),
            T.StructField("wsmape", T.DoubleType(), True),
            T.StructField("iteration", T.StringType(), True),
            T.StructField("level", T.DoubleType(), True),
            T.StructField("cycle", T.DoubleType(), True),
            T.StructField("level_base", T.DoubleType(), True),
        ]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_ucm_details_distinct_features_in_metadata(spark_session: SparkSession):
    # Arrange — two rows for same feature (different wdate) → should appear once in distinct_features
    ucm_output_df = spark_session.createDataFrame(
        [_make_ucm_output_row()], schema=UCM_OUTPUT_SCHEMA
    )
    ucm_base_rows = [
        _make_ucm_base_row(variable="level", value=889301.05),
        _make_ucm_base_row(variable="sof_die_69e_sal_sal_tot_to2", value=1071804.69),
        _make_ucm_base_row(variable="sof_die_69e_sal_sal_tot_to2", value=1256393.14),
    ]
    ucm_base_df = spark_session.createDataFrame(ucm_base_rows, schema=UCM_BASE_SCHEMA)

    # Act — check distinct_features array length
    result = (
        get_ucm_details(
            ucm_output_data_df=ucm_output_df,
            ucm_base_data_df=ucm_base_df,
            correlation_id=CORRELATION_ID,
            source_name="ucm_output",
        )
        .select(F.from_json(
            F.col("metadata"),
            "distinct_features ARRAY<STRUCT<variable: STRING, value: DOUBLE>>",
        ).alias("m"))
        .select(F.size("m.distinct_features").alias("feature_count"))
    )

    # Assert — one distinct feature (sof_die_69e_sal_sal_tot_to2)
    expected = spark_session.createDataFrame(
        [Row(feature_count=1)],
        schema=T.StructType([T.StructField("feature_count", T.IntegerType(), True)]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_ucm_details_filters_best_iteration_only(spark_session: SparkSession):
    # Arrange — one best_iteration=Y row and one N row; only Y should contribute
    ucm_output_rows = [
        _make_ucm_output_row(best_iteration="Y", rsq=0.92, wsmape=0.08),
        _make_ucm_output_row(best_iteration="N", rsq=0.50, wsmape=0.40),
    ]
    ucm_output_df = spark_session.createDataFrame(ucm_output_rows, schema=UCM_OUTPUT_SCHEMA)
    ucm_base_df = spark_session.createDataFrame(
        [_make_ucm_base_row(variable="level", value=100.0)], schema=UCM_BASE_SCHEMA
    )

    # Act
    result = (
        get_ucm_details(
            ucm_output_data_df=ucm_output_df,
            ucm_base_data_df=ucm_base_df,
            correlation_id=CORRELATION_ID,
            source_name="ucm_output",
        )
        .select(F.from_json(F.col("metadata"), "rsq DOUBLE, wsmape DOUBLE").alias("m"))
        .select("m.*")
    )

    # Assert — rsq/wsmape from the Y row only
    expected = spark_session.createDataFrame(
        [Row(rsq=0.92, wsmape=0.08)],
        schema=T.StructType([
            T.StructField("rsq", T.DoubleType(), True),
            T.StructField("wsmape", T.DoubleType(), True),
        ]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_ucm_details_custom_severity(spark_session: SparkSession):
    # Arrange
    ucm_output_df = spark_session.createDataFrame(
        [_make_ucm_output_row()], schema=UCM_OUTPUT_SCHEMA
    )
    ucm_base_df = spark_session.createDataFrame(
        [_make_ucm_base_row()], schema=UCM_BASE_SCHEMA
    )

    # Act
    result = get_ucm_details(
        ucm_output_data_df=ucm_output_df,
        ucm_base_data_df=ucm_base_df,
        correlation_id=CORRELATION_ID,
        source_name="ucm_output",
        severity=Severity.LOW,
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(severity=Severity.LOW.value)],
        schema=T.StructType([OUTPUT_SCHEMA["severity"]]),
    )
    assert_df_equality(result.select("severity"), expected, ignore_row_order=True, ignore_nullable=True)


def test_get_ucm_details_empty_ucm_output_returns_no_metrics(spark_session: SparkSession):
    # Arrange — empty inputs; Spark's agg() on an empty DataFrame still produces one null row.
    ucm_output_df = spark_session.createDataFrame([], schema=UCM_OUTPUT_SCHEMA)
    ucm_base_df = spark_session.createDataFrame([], schema=UCM_BASE_SCHEMA)

    # Act
    result = get_ucm_details(
        ucm_output_data_df=ucm_output_df,
        ucm_base_data_df=ucm_base_df,
        correlation_id=CORRELATION_ID,
        source_name="ucm_output",
    )

    # Assert — one row produced with null rsq/wsmape in metadata
    parsed = (
        result
        .select(F.from_json(F.col("metadata"), "rsq DOUBLE, wsmape DOUBLE").alias("m"))
        .select("m.rsq", "m.wsmape")
    )
    assert parsed.count() == 1
    row = parsed.first()
    assert row["rsq"] is None
    assert row["wsmape"] is None


# --- get_calibration_audit_details ---

def test_get_calibration_audit_details_returns_expected_scalar_fields(spark_session: SparkSession):
    # Arrange
    audit_df = spark_session.createDataFrame([_make_calibration_audit_row()], schema=CALIBRATION_AUDIT_SCHEMA)

    # Act
    result = get_calibration_audit_details(
        df=audit_df,
        correlation_id=CORRELATION_ID,
        source_name="calibration_audit",
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(
            correlation_id=CORRELATION_ID,
            name="calibration_details_calibration_audit",
            data_group="calibration_details",
            data_sources="calibration_audit",
            severity=Severity.HIGH.value,
        )],
        schema=T.StructType([OUTPUT_SCHEMA[c] for c in _STABLE_COLS]),
    )
    assert_df_equality(result.select(_STABLE_COLS), expected, ignore_row_order=True, ignore_nullable=True)


def test_get_calibration_audit_details_metadata_contains_all_fields(spark_session: SparkSession):
    # Arrange — one row with known values
    audit_df = spark_session.createDataFrame(
        [_make_calibration_audit_row(
            marketing_type="OFFSITE",
            mean_log_uplift=0.25,
            var_log_uplift=0.04,
            count_campaigns=10,
            distribution_type="normal",
            shift_parameter=0.5,
            rev_similarity_percentile=0.80,
            scaling_factor=1.2,
            sample_median=0.3,
            sample_mode=0.2,
            z_score=2.0,
            channel_prior_failures=1,
        )],
        schema=CALIBRATION_AUDIT_SCHEMA,
    )

    # Act — parse calibration_details array from metadata
    metadata_schema = """
        calibration_details ARRAY<STRUCT<
            marketing_type: STRING,
            mean_log_uplift: DOUBLE,
            var_log_uplift: DOUBLE,
            count_campaigns: LONG,
            distribution_type: STRING,
            shift_parameter: DOUBLE,
            rev_similarity_percentile: DOUBLE,
            scaling_factor: DOUBLE,
            sample_median: DOUBLE,
            sample_mode: DOUBLE,
            z_score: DOUBLE,
            channel_prior_failures: LONG
        >>
    """
    result = (
        get_calibration_audit_details(
            df=audit_df,
            correlation_id=CORRELATION_ID,
            source_name="calibration_audit",
        )
        .select(F.from_json(F.col("metadata"), metadata_schema).alias("m"))
        .select(F.col("m.calibration_details")[0].alias("item"))
        .select("item.*")
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(
            marketing_type="OFFSITE",
            mean_log_uplift=0.25,
            var_log_uplift=0.04,
            count_campaigns=10,
            distribution_type="normal",
            shift_parameter=0.5,
            rev_similarity_percentile=0.80,
            scaling_factor=1.2,
            sample_median=0.3,
            sample_mode=0.2,
            z_score=2.0,
            channel_prior_failures=1,
        )],
        schema=T.StructType([
            T.StructField("marketing_type", T.StringType(), True),
            T.StructField("mean_log_uplift", T.DoubleType(), True),
            T.StructField("var_log_uplift", T.DoubleType(), True),
            T.StructField("count_campaigns", T.LongType(), True),
            T.StructField("distribution_type", T.StringType(), True),
            T.StructField("shift_parameter", T.DoubleType(), True),
            T.StructField("rev_similarity_percentile", T.DoubleType(), True),
            T.StructField("scaling_factor", T.DoubleType(), True),
            T.StructField("sample_median", T.DoubleType(), True),
            T.StructField("sample_mode", T.DoubleType(), True),
            T.StructField("z_score", T.DoubleType(), True),
            T.StructField("channel_prior_failures", T.LongType(), True),
        ]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_calibration_audit_details_collects_all_rows(spark_session: SparkSession):
    # Arrange — three marketing types; all three should appear in calibration_details
    rows = [
        _make_calibration_audit_row(marketing_type="OFFSITE"),
        _make_calibration_audit_row(marketing_type="ONSITE"),
        _make_calibration_audit_row(marketing_type="INSTORE"),
    ]
    audit_df = spark_session.createDataFrame(rows, schema=CALIBRATION_AUDIT_SCHEMA)

    # Act — check array length in metadata
    result = (
        get_calibration_audit_details(
            df=audit_df,
            correlation_id=CORRELATION_ID,
            source_name="calibration_audit",
        )
        .select(
            F.size(
                F.from_json(
                    F.col("metadata"),
                    "calibration_details ARRAY<STRUCT<marketing_type: STRING>>",
                ).getField("calibration_details")
            ).alias("detail_count")
        )
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(detail_count=3)],
        schema=T.StructType([T.StructField("detail_count", T.IntegerType(), True)]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_calibration_audit_details_produces_single_output_row(spark_session: SparkSession):
    # Arrange — multiple audit rows collapse into one summary row
    rows = [
        _make_calibration_audit_row(marketing_type="OFFSITE"),
        _make_calibration_audit_row(marketing_type="ONSITE"),
    ]
    audit_df = spark_session.createDataFrame(rows, schema=CALIBRATION_AUDIT_SCHEMA)

    # Act
    result = get_calibration_audit_details(
        df=audit_df,
        correlation_id=CORRELATION_ID,
        source_name="calibration_audit",
    )

    # Assert — always exactly one output row regardless of input size
    assert result.count() == 1


def test_get_calibration_audit_details_custom_severity(spark_session: SparkSession):
    # Arrange
    audit_df = spark_session.createDataFrame([_make_calibration_audit_row()], schema=CALIBRATION_AUDIT_SCHEMA)

    # Act
    result = get_calibration_audit_details(
        df=audit_df,
        correlation_id=CORRELATION_ID,
        source_name="calibration_audit",
        severity=Severity.LOW,
    )

    # Assert
    expected = spark_session.createDataFrame(
        [Row(severity=Severity.LOW.value)],
        schema=T.StructType([OUTPUT_SCHEMA["severity"]]),
    )
    assert_df_equality(result.select("severity"), expected, ignore_row_order=True, ignore_nullable=True)


def test_get_calibration_audit_details_empty_input_produces_one_null_row(spark_session: SparkSession):
    # Arrange — Spark agg() on empty DataFrame always yields one row with null aggregate values
    audit_df = spark_session.createDataFrame([], schema=CALIBRATION_AUDIT_SCHEMA)

    # Act
    result = get_calibration_audit_details(
        df=audit_df,
        correlation_id=CORRELATION_ID,
        source_name="calibration_audit",
    )

    # Assert — one row; calibration_details array is empty (collect_list on empty = [])
    assert result.count() == 1
    parsed = (
        result
        .select(
            F.size(
                F.from_json(
                    F.col("metadata"),
                    "calibration_details ARRAY<STRUCT<marketing_type: STRING>>",
                ).getField("calibration_details")
            ).alias("detail_count")
        )
    )
    assert parsed.first()["detail_count"] == 0


def _make_ucm_dfs(spark_session: SparkSession):
    """Return minimal valid ucm_output_df and ucm_base_df for summary tests."""
    ucm_output_df = spark_session.createDataFrame(
        [_make_ucm_output_row()], schema=UCM_OUTPUT_SCHEMA
    )
    ucm_base_df = spark_session.createDataFrame(
        [_make_ucm_base_row(variable="level", value=100.0)], schema=UCM_BASE_SCHEMA
    )
    return ucm_output_df, ucm_base_df


def test_incrementality_layer_summary_unions_all_sources(spark_session: SparkSession):
    # Arrange
    modelling_df = spark_session.createDataFrame([_make_input_row()], schema=INPUT_SCHEMA)
    fp_df = spark_session.createDataFrame([_make_fp_row()], schema=FP_SCHEMA)
    calibration_df = spark_session.createDataFrame([_make_calibration_row()], schema=CALIBRATION_SCHEMA)
    calibration_audit_df = spark_session.createDataFrame([_make_calibration_audit_row()], schema=CALIBRATION_AUDIT_SCHEMA)
    ucm_output_df, ucm_base_df = _make_ucm_dfs(spark_session)

    # Act
    result = incrementality_layer_summary(
        modelling_df=modelling_df,
        fp_df=fp_df,
        calibration_df=calibration_df,
        calibration_audit_df=calibration_audit_df,
        ucm_output_data_df=ucm_output_df,
        ucm_base_data_df=ucm_base_df,
        correlation_id=CORRELATION_ID,
    )

    # Assert — one row per source
    expected = spark_session.createDataFrame(
        [
            Row(data_sources="baseline_modelling_dataset"),
            Row(data_sources="feature_prioritisation"),
            Row(data_sources="incremental_shrinkage"),
            Row(data_sources="ucm_output"),
            Row(data_sources="calibration_audit"),
        ],
        schema=T.StructType([OUTPUT_SCHEMA["data_sources"]]),
    )
    assert_df_equality(result.select("data_sources"), expected, ignore_row_order=True, ignore_nullable=True)


def test_incrementality_layer_summary_correct_names(spark_session: SparkSession):
    # Arrange
    modelling_df = spark_session.createDataFrame([_make_input_row()], schema=INPUT_SCHEMA)
    fp_df = spark_session.createDataFrame([_make_fp_row()], schema=FP_SCHEMA)
    calibration_df = spark_session.createDataFrame([_make_calibration_row()], schema=CALIBRATION_SCHEMA)
    calibration_audit_df = spark_session.createDataFrame([_make_calibration_audit_row()], schema=CALIBRATION_AUDIT_SCHEMA)
    ucm_output_df, ucm_base_df = _make_ucm_dfs(spark_session)

    # Act
    result = incrementality_layer_summary(
        modelling_df=modelling_df,
        fp_df=fp_df,
        calibration_df=calibration_df,
        calibration_audit_df=calibration_audit_df,
        ucm_output_data_df=ucm_output_df,
        ucm_base_data_df=ucm_base_df,
        correlation_id=CORRELATION_ID,
    )

    # Assert
    expected = spark_session.createDataFrame(
        [
            Row(name="features_overview_baseline_modelling_dataset"),
            Row(name="features_overview_feature_prioritisation"),
            Row(name="incrementality_output_results_incremental_shrinkage"),
            Row(name="ucm_details_ucm_output"),
            Row(name="calibration_details_calibration_audit"),
        ],
        schema=T.StructType([OUTPUT_SCHEMA["name"]]),
    )
    assert_df_equality(result.select("name"), expected, ignore_row_order=True, ignore_nullable=True)


def test_incrementality_layer_summary_data_groups_per_source(spark_session: SparkSession):
    # Arrange
    modelling_df = spark_session.createDataFrame([_make_input_row()], schema=INPUT_SCHEMA)
    fp_df = spark_session.createDataFrame([_make_fp_row()], schema=FP_SCHEMA)
    calibration_df = spark_session.createDataFrame([_make_calibration_row()], schema=CALIBRATION_SCHEMA)
    calibration_audit_df = spark_session.createDataFrame([_make_calibration_audit_row()], schema=CALIBRATION_AUDIT_SCHEMA)
    ucm_output_df, ucm_base_df = _make_ucm_dfs(spark_session)

    # Act
    result = incrementality_layer_summary(
        modelling_df=modelling_df,
        fp_df=fp_df,
        calibration_df=calibration_df,
        calibration_audit_df=calibration_audit_df,
        ucm_output_data_df=ucm_output_df,
        ucm_base_data_df=ucm_base_df,
        correlation_id=CORRELATION_ID,
    )

    # Assert — features_overview for modelling/fp; incrementality_output_results for calibration; ucm_details for ucm; calibration_details for audit
    expected = spark_session.createDataFrame(
        [
            Row(data_group="features_overview"),
            Row(data_group="features_overview"),
            Row(data_group="incrementality_output_results"),
            Row(data_group="ucm_details"),
            Row(data_group="calibration_details"),
        ],
        schema=T.StructType([OUTPUT_SCHEMA["data_group"]]),
    )
    assert_df_equality(result.select("data_group"), expected, ignore_row_order=True, ignore_nullable=True)


def test_incrementality_layer_summary_external_rows_excluded(spark_session: SparkSession):
    # Arrange — modelling_df contains one valid and one EXTERNAL row; fp_df and calibration_df have one valid row each
    modelling_rows = [
        _make_input_row(marketing_type_name="OFFSITE", variable_cd="VAR_A"),
        _make_input_row(marketing_type_name="EXTERNAL", variable_cd="EXT_VAR"),
    ]
    modelling_df = spark_session.createDataFrame(modelling_rows, schema=INPUT_SCHEMA)
    fp_df = spark_session.createDataFrame([_make_fp_row()], schema=FP_SCHEMA)
    calibration_df = spark_session.createDataFrame([_make_calibration_row()], schema=CALIBRATION_SCHEMA)
    calibration_audit_df = spark_session.createDataFrame([_make_calibration_audit_row()], schema=CALIBRATION_AUDIT_SCHEMA)
    ucm_output_df, ucm_base_df = _make_ucm_dfs(spark_session)

    # Act
    result = incrementality_layer_summary(
        modelling_df=modelling_df,
        fp_df=fp_df,
        calibration_df=calibration_df,
        calibration_audit_df=calibration_audit_df,
        ucm_output_data_df=ucm_output_df,
        ucm_base_data_df=ucm_base_df,
        correlation_id=CORRELATION_ID,
    )

    # Assert — five sources present; EXTERNAL filtered only from modelling side
    expected = spark_session.createDataFrame(
        [
            Row(data_sources="baseline_modelling_dataset"),
            Row(data_sources="feature_prioritisation"),
            Row(data_sources="incremental_shrinkage"),
            Row(data_sources="ucm_output"),
            Row(data_sources="calibration_audit"),
        ],
        schema=T.StructType([OUTPUT_SCHEMA["data_sources"]]),
    )
    assert_df_equality(result.select("data_sources"), expected, ignore_row_order=True, ignore_nullable=True)


def test_incrementality_layer_summary_empty_inputs_produces_ucm_null_row(spark_session: SparkSession):
    # Arrange — all inputs empty.
    # get_features_overview uses a double-aggregation (.groupBy(...).agg(...).agg(collect_list(...))),
    # so it yields 1 row with an empty list even on empty input — one row for modelling and one for fp.
    # get_incrementality_output_results uses groupBy+pivot which yields 0 rows on empty input.
    # get_ucm_details and get_calibration_audit_details each yield 1 null row (global agg on empty).
    # Total: 4 rows.
    modelling_df = spark_session.createDataFrame([], schema=INPUT_SCHEMA)
    fp_df = spark_session.createDataFrame([], schema=FP_SCHEMA)
    calibration_df = spark_session.createDataFrame([], schema=CALIBRATION_SCHEMA)
    calibration_audit_df = spark_session.createDataFrame([], schema=CALIBRATION_AUDIT_SCHEMA)
    ucm_output_df = spark_session.createDataFrame([], schema=UCM_OUTPUT_SCHEMA)
    ucm_base_df = spark_session.createDataFrame([], schema=UCM_BASE_SCHEMA)

    # Act
    result = incrementality_layer_summary(
        modelling_df=modelling_df,
        fp_df=fp_df,
        calibration_df=calibration_df,
        calibration_audit_df=calibration_audit_df,
        ucm_output_data_df=ucm_output_df,
        ucm_base_data_df=ucm_base_df,
        correlation_id=CORRELATION_ID,
    )

    # Assert — 4 rows: features_overview (x2), ucm_details (x1), calibration_details (x1)
    assert result.count() == 4
    data_groups = {row["data_group"] for row in result.collect()}
    assert data_groups == {"features_overview", "ucm_details", "calibration_details"}
