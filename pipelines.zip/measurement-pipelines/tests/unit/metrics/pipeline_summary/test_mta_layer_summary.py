from chispa.dataframe_comparer import assert_df_equality
from pyspark.sql import DataFrame, Row, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
import pytest

from spark_pipeline.common.variables import Severity
from spark_pipeline.metrics.pipeline_summary.mta_layer_summary import (
    get_lift_details,
    get_user_journey_metrics,
    mta_layer_summary,
)
from spark_pipeline.schemas.pipeline_summary import PipelineSummaryMetricsSchema

CORRELATION_ID = "68849197-d2c9-4976-a408-5ad30f56b33e"
OUTPUT_SCHEMA = PipelineSummaryMetricsSchema.pipeline_summary_metric_schema
_STABLE_COLS = ["correlation_id", "name", "data_group", "data_sources", "severity"]

USER_JOURNEY_SCHEMA = T.StructType([
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("loyalty_id", T.StringType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("userjourney_id", T.StringType(), True),
    T.StructField("transaction_key", T.StringType(), True),
    T.StructField("net_sales_amt", T.DoubleType(), True),
])

MTA_RESULT_SCHEMA = T.StructType([
    T.StructField("journey_type", T.StringType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("normalized_weights", T.DoubleType(), True),
])

SKU_LEVEL_SCHEMA = T.StructType([
    T.StructField("attributed_sales_amt", T.DoubleType(), True),
])


def _make_user_journey_row(**kwargs) -> Row:
    defaults = {
        "booking_id": "BOOKING_1",
        "loyalty_id": "USER_1",
        "channel_name": "EMAIL",
        "subchannel_name": "MARKETING_EMAIL",
        "userjourney_id": "JOURNEY_1",
        "transaction_key": "TXN_1",
        "net_sales_amt": 100.0,
    }
    defaults.update(kwargs)
    return Row(**defaults)


def _make_mta_result_row(**kwargs) -> Row:
    defaults = {
        "journey_type": "offer",
        "channel_name": "EMAIL",
        "subchannel_name": "MARKETING_EMAIL",
        "normalized_weights": 0.5,
    }
    defaults.update(kwargs)
    return Row(**defaults)


def _make_sku_level_attributed_sales_row(**kwargs) -> Row:
    defaults = {
        "attributed_sales_amt": 100.0,
    }
    defaults.update(kwargs)
    return Row(**defaults)


# --- Fixtures for default single-row DataFrames ---

@pytest.fixture
def default_offer_df(spark_session: SparkSession):
    """Fixture: default single-row offer DataFrame."""
    return spark_session.createDataFrame([_make_user_journey_row()], schema=USER_JOURNEY_SCHEMA)


@pytest.fixture
def default_brand_df(spark_session: SparkSession):
    """Fixture: default single-row brand DataFrame."""
    return spark_session.createDataFrame([_make_user_journey_row()], schema=USER_JOURNEY_SCHEMA)


@pytest.fixture
def default_mta_result_df(spark_session: SparkSession):
    """Fixture: default single-row MTA result DataFrame."""
    return spark_session.createDataFrame([_make_mta_result_row()], schema=MTA_RESULT_SCHEMA)


@pytest.fixture
def default_sku_level_offer_df(spark_session: SparkSession):
    """Fixture: default single-row SKU-level offer attributed sales DataFrame."""
    return spark_session.createDataFrame([_make_sku_level_attributed_sales_row()], schema=SKU_LEVEL_SCHEMA)


@pytest.fixture
def default_sku_level_brand_df(spark_session: SparkSession):
    """Fixture: default single-row SKU-level brand attributed sales DataFrame."""
    return spark_session.createDataFrame([_make_sku_level_attributed_sales_row()], schema=SKU_LEVEL_SCHEMA)


def test_mta_layer_summary_single_row_output(
    spark_session: SparkSession,
    default_offer_df: DataFrame,
    default_brand_df: DataFrame,
    default_mta_result_df: DataFrame,
    default_sku_level_offer_df: DataFrame,
    default_sku_level_brand_df: DataFrame,
):
    """Test that mta_layer_summary produces exactly one output row from default inputs."""
    result = mta_layer_summary(
        offer_adg_df=default_offer_df,
        brand_adg_df=default_brand_df,
        mta_result_df=default_mta_result_df,
        sku_level_attributed_sales_offer_df=default_sku_level_offer_df,
        sku_level_attributed_sales_brand_df=default_sku_level_brand_df,
        correlation_id=CORRELATION_ID,
    )

    assert result.count() == 1


def test_mta_layer_summary_correct_columns_and_values(
    spark_session: SparkSession,
    default_offer_df: DataFrame,
    default_brand_df: DataFrame,
    default_mta_result_df: DataFrame,
    default_sku_level_offer_df: DataFrame,
    default_sku_level_brand_df: DataFrame,
):
    """Test that output has correct stable columns (correlation_id, name, data_group, etc.) and severity level."""
    result = mta_layer_summary(
        offer_adg_df=default_offer_df,
        brand_adg_df=default_brand_df,
        mta_result_df=default_mta_result_df,
        sku_level_attributed_sales_offer_df=default_sku_level_offer_df,
        sku_level_attributed_sales_brand_df=default_sku_level_brand_df,
        correlation_id=CORRELATION_ID,
    )

    expected = spark_session.createDataFrame(
        [
            Row(
                correlation_id=CORRELATION_ID,
                name="mta_layer_summary",
                data_group="mta_layer_summary",
                data_sources="user_journey_offer,user_journey_brand,attribution_model_results,sku_level_attributed_sales_offer,sku_level_attributed_sales_brand",
                severity=Severity.HIGH.value,
            )
        ],
        schema=T.StructType([OUTPUT_SCHEMA[c] for c in _STABLE_COLS]),
    )
    assert_df_equality(result.select(_STABLE_COLS), expected, ignore_row_order=True, ignore_nullable=True)


def test_mta_layer_summary_consolidates_all_metrics_into_metadata(spark_session: SparkSession):
    """Test that metadata JSON correctly aggregates all offer/brand/SKU metrics with exact values.

    Scenario: Multiple journeys (J1, J2 for offer with different sales amounts; J3 for brand).
    Verify: Offer totals = max per journey aggregated (100, 200), Brand = 150, SKU offer = 150+250,
            Brand SKU = 200. All arrays populated with correct channel/weight/loyalty data.
    """
    offer_rows = [
        _make_user_journey_row(
            loyalty_id="USER_1",
            channel_name="EMAIL",
            subchannel_name="MARKETING_EMAIL",
            userjourney_id="J1",
            net_sales_amt=100.0,
        ),
        _make_user_journey_row(
            loyalty_id="USER_2",
            channel_name="EMAIL",
            subchannel_name="MARKETING_EMAIL",
            userjourney_id="J2",
            net_sales_amt=200.0,
        ),
    ]
    brand_rows = [
        _make_user_journey_row(
            loyalty_id="USER_3",
            channel_name="SMS",
            subchannel_name="MARKETING_SMS",
            userjourney_id="J3",
            net_sales_amt=150.0,
        )
    ]
    offer_df = spark_session.createDataFrame(offer_rows, schema=USER_JOURNEY_SCHEMA)
    brand_df = spark_session.createDataFrame(brand_rows, schema=USER_JOURNEY_SCHEMA)
    mta_result_df = spark_session.createDataFrame(
        [
            _make_mta_result_row(
                journey_type="offer",
                channel_name="EMAIL",
                subchannel_name="MARKETING_EMAIL",
                normalized_weights=0.5,
            ),
            _make_mta_result_row(
                journey_type="brand",
                channel_name="SMS",
                subchannel_name="MARKETING_SMS",
                normalized_weights=0.8,
            ),
        ],
        schema=MTA_RESULT_SCHEMA,
    )
    sku_level_offer_df = spark_session.createDataFrame(
        [
            _make_sku_level_attributed_sales_row(attributed_sales_amt=150.0),
            _make_sku_level_attributed_sales_row(attributed_sales_amt=250.0),
        ],
        schema=SKU_LEVEL_SCHEMA,
    )
    sku_level_brand_df = spark_session.createDataFrame(
        [_make_sku_level_attributed_sales_row(attributed_sales_amt=200.0)],
        schema=SKU_LEVEL_SCHEMA,
    )

    result = mta_layer_summary(
        offer_adg_df=offer_df,
        brand_adg_df=brand_df,
        mta_result_df=mta_result_df,
        sku_level_attributed_sales_offer_df=sku_level_offer_df,
        sku_level_attributed_sales_brand_df=sku_level_brand_df,
        correlation_id=CORRELATION_ID,
    )

    # Parse complete JSON metadata and assert entire structure
    metadata = result.select(
        F.from_json(
            F.col("metadata"),
            "user_journey_offer ARRAY<STRUCT<channel_name: STRING, subchannel_name: STRING, count_distinct_loyalty_ids: LONG, sum_exposed_sales: DOUBLE>>, "
            "user_journey_brand ARRAY<STRUCT<channel_name: STRING, subchannel_name: STRING, count_distinct_loyalty_ids: LONG, sum_exposed_sales: DOUBLE>>, "
            "lift_details_offer ARRAY<STRUCT<channel_name: STRING, subchannel_name: STRING, sum_channel_weights: DOUBLE>>, "
            "lift_details_brand ARRAY<STRUCT<channel_name: STRING, subchannel_name: STRING, sum_channel_weights: DOUBLE>>, "
            "sum_net_sales_amt_user_journey_offer DOUBLE, "
            "sum_net_sales_amt_user_journey_brand DOUBLE, "
            "sum_attributed_sales_amt_sku_level_offer DOUBLE, "
            "sum_attributed_sales_amt_sku_level_brand DOUBLE",
        ).alias("m")
    ).collect()[0][0]

    # Verify totals are correctly aggregated
    assert metadata["sum_net_sales_amt_user_journey_offer"] == 300.0  # max(100, 200)
    assert metadata["sum_net_sales_amt_user_journey_brand"] == 150.0  # max(150)
    assert metadata["sum_attributed_sales_amt_sku_level_offer"] == 400.0  # 150 + 250
    assert metadata["sum_attributed_sales_amt_sku_level_brand"] == 200.0

    # Verify offer journey structure: exactly one EMAIL channel
    assert len(metadata["user_journey_offer"]) == 1
    offer_row = metadata["user_journey_offer"][0]
    assert offer_row.channel_name == "EMAIL"
    assert offer_row.subchannel_name == "MARKETING_EMAIL"
    assert offer_row.count_distinct_loyalty_ids == 2  # USER_1 and USER_2
    assert offer_row.sum_exposed_sales == 300.0  # 100 + 200 (max per journey: 100 + 200)

    # Verify brand journey structure: exactly one SMS channel
    assert len(metadata["user_journey_brand"]) == 1
    brand_row = metadata["user_journey_brand"][0]
    assert brand_row.channel_name == "SMS"
    assert brand_row.subchannel_name == "MARKETING_SMS"
    assert brand_row.count_distinct_loyalty_ids == 1  # USER_3
    assert brand_row.sum_exposed_sales == 150.0

    # Verify lift details offer: exactly one EMAIL channel
    assert len(metadata["lift_details_offer"]) == 1
    offer_lift = metadata["lift_details_offer"][0]
    assert offer_lift.channel_name == "EMAIL"
    assert offer_lift.subchannel_name == "MARKETING_EMAIL"
    assert offer_lift.sum_channel_weights == 0.5

    # Verify lift details brand: exactly one SMS channel
    assert len(metadata["lift_details_brand"]) == 1
    brand_lift = metadata["lift_details_brand"][0]
    assert brand_lift.channel_name == "SMS"
    assert brand_lift.subchannel_name == "MARKETING_SMS"
    assert brand_lift.sum_channel_weights == 0.8


def test_mta_layer_summary_custom_severity_and_case_insensitive_journey_filter(spark_session: SparkSession):
    """Test that custom severity is applied and journey_type filtering is case-insensitive.

    Scenario: Mix of OFFER (uppercase), bRaNd (mixed case), and other (excluded) journey types.
    Verify: Severity=LOW applied, lift_details_offer contains only EMAIL (no AFFILIATE),
            lift_details_brand contains only SMS (no AFFILIATE).
    """
    offer_df = spark_session.createDataFrame([_make_user_journey_row()], schema=USER_JOURNEY_SCHEMA)
    brand_df = spark_session.createDataFrame(
        [
            _make_user_journey_row(
                channel_name="SMS",
                subchannel_name="MARKETING_SMS",
                userjourney_id="J2",
            )
        ],
        schema=USER_JOURNEY_SCHEMA,
    )
    mta_result_df = spark_session.createDataFrame(
        [
            _make_mta_result_row(
                journey_type="OFFER",
                channel_name="EMAIL",
                subchannel_name="MARKETING_EMAIL",
                normalized_weights=0.5,
            ),
            _make_mta_result_row(
                journey_type="bRaNd",
                channel_name="SMS",
                subchannel_name="MARKETING_SMS",
                normalized_weights=0.3,
            ),
            _make_mta_result_row(
                journey_type="other",
                channel_name="AFFILIATE",
                subchannel_name="PARTNER",
                normalized_weights=1.0,
            ),
        ],
        schema=MTA_RESULT_SCHEMA,
    )
    sku_level_offer_df = spark_session.createDataFrame([_make_sku_level_attributed_sales_row()], schema=SKU_LEVEL_SCHEMA)
    sku_level_brand_df = spark_session.createDataFrame([_make_sku_level_attributed_sales_row()], schema=SKU_LEVEL_SCHEMA)

    result = mta_layer_summary(
        offer_adg_df=offer_df,
        brand_adg_df=brand_df,
        mta_result_df=mta_result_df,
        sku_level_attributed_sales_offer_df=sku_level_offer_df,
        sku_level_attributed_sales_brand_df=sku_level_brand_df,
        correlation_id=CORRELATION_ID,
        severity=Severity.LOW,
    )

    expected_severity = spark_session.createDataFrame(
        [Row(severity=Severity.LOW.value)],
        schema=T.StructType([OUTPUT_SCHEMA["severity"]]),
    )
    assert_df_equality(result.select("severity"), expected_severity, ignore_row_order=True, ignore_nullable=True)

    metadata = result.select(
        F.from_json(
            F.col("metadata"),
            "lift_details_offer ARRAY<STRUCT<channel_name: STRING, subchannel_name: STRING>>, "
            "lift_details_brand ARRAY<STRUCT<channel_name: STRING, subchannel_name: STRING>>",
        ).alias("m")
    )

    metadata_row = metadata.collect()[0][0]
    lift_offer_details = metadata_row["lift_details_offer"]
    lift_brand_details = metadata_row["lift_details_brand"]

    # Verify offer lift details structure: only EMAIL, no AFFILIATE
    expected_offer_lift = [
        Row(channel_name="EMAIL", subchannel_name="MARKETING_EMAIL")
    ]
    actual_offer_lift = [
        Row(channel_name=row.channel_name, subchannel_name=row.subchannel_name)
        for row in lift_offer_details
    ]
    assert actual_offer_lift == expected_offer_lift

    # Verify brand lift details structure: only SMS, no AFFILIATE
    expected_brand_lift = [
        Row(channel_name="SMS", subchannel_name="MARKETING_SMS")
    ]
    actual_brand_lift = [
        Row(channel_name=row.channel_name, subchannel_name=row.subchannel_name)
        for row in lift_brand_details
    ]
    assert actual_brand_lift == expected_brand_lift


def test_mta_layer_summary_sets_zero_totals_for_empty_sales_inputs(spark_session: SparkSession):
    """Test that all totals and arrays are zero/empty when input DataFrames are empty.

    Scenario: No offer, brand, mta_result, or SKU-level rows provided.
    Verify: All scalar totals = 0.0, all arrays (journey, lift_details) have len==0.
    """
    empty_user_journey_df = spark_session.createDataFrame([], schema=USER_JOURNEY_SCHEMA)
    empty_mta_result_df = spark_session.createDataFrame([], schema=MTA_RESULT_SCHEMA)
    empty_sku_level_df = spark_session.createDataFrame([], schema=SKU_LEVEL_SCHEMA)

    result = mta_layer_summary(
        offer_adg_df=empty_user_journey_df,
        brand_adg_df=empty_user_journey_df,
        mta_result_df=empty_mta_result_df,
        sku_level_attributed_sales_offer_df=empty_sku_level_df,
        sku_level_attributed_sales_brand_df=empty_sku_level_df,
        correlation_id=CORRELATION_ID,
    )

    # Parse complete JSON and verify all fields are zero and arrays are empty
    metadata = result.select(
        F.from_json(
            F.col("metadata"),
            "user_journey_offer ARRAY<STRUCT<channel_name: STRING, subchannel_name: STRING, count_distinct_loyalty_ids: LONG, sum_exposed_sales: DOUBLE>>, "
            "user_journey_brand ARRAY<STRUCT<channel_name: STRING, subchannel_name: STRING, count_distinct_loyalty_ids: LONG, sum_exposed_sales: DOUBLE>>, "
            "lift_details_offer ARRAY<STRUCT<channel_name: STRING, subchannel_name: STRING, sum_channel_weights: DOUBLE>>, "
            "lift_details_brand ARRAY<STRUCT<channel_name: STRING, subchannel_name: STRING, sum_channel_weights: DOUBLE>>, "
            "sum_net_sales_amt_user_journey_offer DOUBLE, "
            "sum_net_sales_amt_user_journey_brand DOUBLE, "
            "sum_attributed_sales_amt_sku_level_offer DOUBLE, "
            "sum_attributed_sales_amt_sku_level_brand DOUBLE",
        ).alias("m")
    ).collect()[0][0]

    # Verify scalar totals are zero
    assert metadata["sum_net_sales_amt_user_journey_offer"] == 0.0
    assert metadata["sum_net_sales_amt_user_journey_brand"] == 0.0
    assert metadata["sum_attributed_sales_amt_sku_level_offer"] == 0.0
    assert metadata["sum_attributed_sales_amt_sku_level_brand"] == 0.0

    # Verify all arrays are empty
    assert len(metadata["user_journey_offer"]) == 0
    assert len(metadata["user_journey_brand"]) == 0
    assert len(metadata["lift_details_offer"]) == 0
    assert len(metadata["lift_details_brand"]) == 0


# ---  unit tests for get_user_journey_metrics ---

def test_get_user_journey_metrics_returns_tuple_of_total_and_dataframe(spark_session: SparkSession):
    """Test that get_user_journey_metrics returns (float total, DataFrame with journey array).

    Scenario: Three rows with two journeys where J1 has duplicate transaction rows (TXN_1 with 150, 150)
        and J2 has one transaction (TXN_2 with 200).
    Verify: Total = 350.0 (deduplicated transaction totals: dedup(TXN_1)=150 plus TXN_2=200),
            journey DataFrame has alias column,
            alias column contains array of structs with channel_name and subchannel_name.
    """
    rows = [
        _make_user_journey_row(userjourney_id="J1", transaction_key="TXN_1", net_sales_amt=150.0),
        _make_user_journey_row(userjourney_id="J1", transaction_key="TXN_1", net_sales_amt=150.0),
        _make_user_journey_row(userjourney_id="J2", transaction_key="TXN_2", net_sales_amt=200.0),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_SCHEMA)

    total_sales, journey_df = get_user_journey_metrics(df, "my_alias")

    # Verify return type and value
    assert isinstance(total_sales, float)
    assert total_sales == 350.0  # deduped transaction total: 150 + 200

    # Verify alias column exists and contains array of journey structures
    assert "my_alias" in journey_df.columns
    journey_data = journey_df.select(F.explode(F.col("my_alias")).alias("f")).select("f.*").columns
    assert "channel_name" in journey_data
    assert "subchannel_name" in journey_data


def test_get_user_journey_metrics_groups_by_channel_and_subchannel(spark_session: SparkSession):
    """Test that journey metrics are grouped by channel and subchannel.

    Scenario: Two rows with different channels (EMAIL, SMS).
    Verify: Output DataFrame contains exactly one row per channel grouping when exploded.
    """
    rows = [
        _make_user_journey_row(
            loyalty_id="USER_1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL",
            userjourney_id="J1", net_sales_amt=100.0,
        ),
        _make_user_journey_row(
            loyalty_id="USER_2", channel_name="SMS", subchannel_name="MARKETING_SMS",
            userjourney_id="J2", net_sales_amt=50.0,
        ),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_SCHEMA)

    _, journey_df = get_user_journey_metrics(df, "overview")
    result = (
        journey_df
        .select(F.explode(F.col("overview")).alias("f"))
        .select("f.channel_name", "f.subchannel_name")
    )

    expected = spark_session.createDataFrame(
        [
            Row(channel_name="EMAIL", subchannel_name="MARKETING_EMAIL"),
            Row(channel_name="SMS", subchannel_name="MARKETING_SMS"),
        ],
        schema=T.StructType([
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
        ]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_get_user_journey_metrics_deduplicates_repeated_transaction_rows(spark_session: SparkSession):
    """Test that repeated rows for the same journey+transaction are counted once in totals.

    Scenario: J1 has duplicated TXN_1 rows (100, 100) and one TXN_2 row (50).
    Verify: Total sales = 150.0 after deduplication; exposed sales for EMAIL is 150.0.
    """
    rows = [
        _make_user_journey_row(
            loyalty_id="USER_1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL",
            userjourney_id="J1", transaction_key="TXN_1", net_sales_amt=100.0,
        ),
        _make_user_journey_row(
            loyalty_id="USER_1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL",
            userjourney_id="J1", transaction_key="TXN_1", net_sales_amt=100.0,
        ),
        _make_user_journey_row(
            loyalty_id="USER_1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL",
            userjourney_id="J1", transaction_key="TXN_2", net_sales_amt=50.0,
        ),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_SCHEMA)

    total, journey_df = get_user_journey_metrics(df, "journey_data")

    result = journey_df.select(F.explode(F.col("journey_data")).alias("j")).select("j.*").collect()

    assert total == 150.0
    assert len(result) == 1
    assert result[0].sum_exposed_sales == 150.0


def test_get_user_journey_metrics_filters_null_and_blank_subchannels(spark_session: SparkSession):
    """Test that rows with null or blank subchannel_name are excluded.

    Scenario: Three rows—one valid EMAIL, one SMS with empty string, one APP with null.
    Verify: Only EMAIL row appears in output (null/blank subchannels filtered).
    """
    rows = [
        _make_user_journey_row(
            loyalty_id="USER_1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL",
            userjourney_id="J1", net_sales_amt=100.0,
        ),
        _make_user_journey_row(
            loyalty_id="USER_2", channel_name="SMS", subchannel_name="",
            userjourney_id="J2", net_sales_amt=50.0,
        ),
        _make_user_journey_row(
            loyalty_id="USER_3", channel_name="APP", subchannel_name=None,
            userjourney_id="J3", net_sales_amt=75.0,
        ),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_SCHEMA)

    _, journey_df = get_user_journey_metrics(df, "overview")
    result = (
        journey_df
        .select(F.explode(F.col("overview")).alias("f"))
        .select("f.channel_name")
    )

    expected = spark_session.createDataFrame(
        [Row(channel_name="EMAIL")],
        schema=T.StructType([T.StructField("channel_name", T.StringType(), True)]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


# --- unit tests for aggregate_lift_details ---

def test_aggregate_lift_details_uses_provided_col_alias(spark_session: SparkSession):
    """Test that get_lift_details creates output column with provided alias name.

    Scenario: Call get_lift_details with custom alias 'my_lift_alias'.
    Verify: Output DataFrame has 'my_lift_alias' column containing lift detail structures.
    """
    df = spark_session.createDataFrame([_make_mta_result_row()], schema=MTA_RESULT_SCHEMA)

    result = get_lift_details(df, "offer", "my_lift_alias")

    # Verify alias column exists and contains valid lift detail structures
    assert "my_lift_alias" in result.columns
    lift_data = result.select(F.explode(F.col("my_lift_alias")).alias("f")).select("f.*").columns
    assert "channel_name" in lift_data
    assert "subchannel_name" in lift_data
    assert "sum_channel_weights" in lift_data


def test_aggregate_lift_details_filters_by_journey_type_case_insensitive(spark_session: SparkSession):
    """Test that lift_details filtering by journey_type is case-insensitive.

    Scenario: Three rows with OFFER (uppercase), brand (lowercase), other (should exclude).
    Verify: get_lift_details(df, 'offer') returns only OFFER row (case-insensitive match).
    """
    rows = [
        _make_mta_result_row(journey_type="OFFER", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", normalized_weights=0.5),
        _make_mta_result_row(journey_type="brand", channel_name="SMS", subchannel_name="MARKETING_SMS", normalized_weights=0.3),
        _make_mta_result_row(journey_type="other", channel_name="APP", subchannel_name="PUSH", normalized_weights=1.0),
    ]
    df = spark_session.createDataFrame(rows, schema=MTA_RESULT_SCHEMA)

    offer_result = (
        get_lift_details(df, "offer", "lift")
        .select(F.explode(F.col("lift")).alias("f"))
        .select("f.*")
    )

    expected = spark_session.createDataFrame(
        [Row(channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", sum_channel_weights=0.5)],
        schema=T.StructType([
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("sum_channel_weights", T.DoubleType(), True),
        ]),
    )
    assert_df_equality(offer_result, expected, ignore_row_order=True, ignore_nullable=True)


def test_aggregate_lift_details_sums_weights_by_channel_and_subchannel(spark_session: SparkSession):
    """Test that normalized_weights are aggregated (summed) per channel/subchannel pair.

    Scenario: Three offer rows—EMAIL appears twice (0.4, 0.3), SMS once (0.2).
    Verify: Aggregated result has EMAIL with sum_channel_weights=0.7, SMS=0.2.
    """
    rows = [
        _make_mta_result_row(journey_type="offer", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", normalized_weights=0.4),
        _make_mta_result_row(journey_type="offer", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", normalized_weights=0.3),
        _make_mta_result_row(journey_type="offer", channel_name="SMS", subchannel_name="MARKETING_SMS", normalized_weights=0.2),
    ]
    df = spark_session.createDataFrame(rows, schema=MTA_RESULT_SCHEMA)

    result = (
        get_lift_details(df, "offer", "lift")
        .select(F.explode(F.col("lift")).alias("f"))
        .select("f.*")
    )

    expected = spark_session.createDataFrame(
        [
            Row(channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", sum_channel_weights=0.7),
            Row(channel_name="SMS", subchannel_name="MARKETING_SMS", sum_channel_weights=0.2),
        ],
        schema=T.StructType([
            T.StructField("channel_name", T.StringType(), True),
            T.StructField("subchannel_name", T.StringType(), True),
            T.StructField("sum_channel_weights", T.DoubleType(), True),
        ]),
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


# --- Edge Case Tests ---

def test_get_user_journey_metrics_counts_null_and_blank_loyalty_ids_separately(spark_session: SparkSession):
    """Test that countDistinct treats null loyalty_ids and blank strings as distinct values.

    Scenario: Three rows with loyalty_id values: "USER_1", None (null), and "" (blank string).
    Verify: countDistinct returns 2 (null is excluded by countDistinct, blank string counted as value).
    """
    rows = [
        _make_user_journey_row(loyalty_id="USER_1", userjourney_id="J1", net_sales_amt=100.0),
        _make_user_journey_row(loyalty_id=None, userjourney_id="J1", net_sales_amt=100.0),
        _make_user_journey_row(loyalty_id="", userjourney_id="J1", net_sales_amt=100.0),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_SCHEMA)

    # Arrange
    total, journey_df = get_user_journey_metrics(df, "journey_data")

    # Act
    result = journey_df.select(F.explode(F.col("journey_data")).alias("j")).select("j.*").collect()

    # Assert: countDistinct excludes NULL but counts blank strings
    assert len(result) == 1
    assert result[0].count_distinct_loyalty_ids == 2  # "USER_1" and ""
    assert result[0].sum_exposed_sales == 100.0


def test_get_user_journey_metrics_handles_duplicate_journey_channel_rows(spark_session: SparkSession):
    """Test that duplicate campaign rows for the same user+transaction are deduplicated before summing.

    Scenario: Three rows—USER_1 has two identical rows for J1/TXN_1 (net_sales=100),
        USER_2 has one distinct row for J1/TXN_2 (net_sales=200).
    Verify: 2 distinct loyalty IDs; sum_exposed_sales = 100 + 200 = 300 (USER_1 counted once).
    """
    rows = [
        _make_user_journey_row(loyalty_id="USER_1", userjourney_id="J1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", transaction_key="TXN_1", net_sales_amt=100.0),
        _make_user_journey_row(loyalty_id="USER_1", userjourney_id="J1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", transaction_key="TXN_1", net_sales_amt=100.0),
        _make_user_journey_row(loyalty_id="USER_2", userjourney_id="J1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", transaction_key="TXN_2", net_sales_amt=200.0),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_SCHEMA)

    # Arrange
    total, journey_df = get_user_journey_metrics(df, "journey_data")

    # Act
    result = journey_df.select(F.explode(F.col("journey_data")).alias("j")).select("j.*").collect()

    # Assert: USER_1's duplicate row collapsed; sum = 100 (USER_1) + 200 (USER_2) = 300
    assert len(result) == 1
    assert result[0].count_distinct_loyalty_ids == 2
    assert result[0].sum_exposed_sales == 300.0


def test_aggregate_lift_details_handles_mixed_case_journey_type(spark_session: SparkSession):
    """Test that journey_type filtering is case-insensitive via F.lower().

    Scenario: Four rows with journey_types: "OFFER", "offer", "Offer", "brand".
    Verify: Filter for 'offer' matches all case variations and returns 3 rows.
    """
    rows = [
        _make_mta_result_row(journey_type="OFFER", channel_name="EMAIL", normalized_weights=0.3),
        _make_mta_result_row(journey_type="offer", channel_name="SMS", normalized_weights=0.4),
        _make_mta_result_row(journey_type="Offer", channel_name="APP", normalized_weights=0.2),
        _make_mta_result_row(journey_type="brand", channel_name="EMAIL", normalized_weights=0.1),
    ]
    df = spark_session.createDataFrame(rows, schema=MTA_RESULT_SCHEMA)

    # Arrange + Act
    result = (
        get_lift_details(df, "offer", "lift")
        .select(F.explode(F.col("lift")).alias("f"))
        .select("f.*")
    )

    # Assert: All three case variations of 'offer' matched
    channels = result.select("channel_name").distinct().collect()
    assert len(channels) == 3
    assert set(row.channel_name for row in channels) == {"EMAIL", "SMS", "APP"}


def test_get_user_journey_metrics_with_null_net_sales_amt(spark_session: SparkSession):
    """Test that null net_sales_amt values are handled by sum() (nulls ignored, not summed to zero).

    Scenario: Three rows for journey J1 across three distinct transaction keys: TXN_1=100, TXN_2=null, TXN_3=200.
    Verify: Total = 300.0 (null transaction ignored by sum); sum_exposed_sales = 300.0.
    """
    rows = [
        _make_user_journey_row(userjourney_id="J1", transaction_key="TXN_1", net_sales_amt=100.0),
        _make_user_journey_row(userjourney_id="J1", transaction_key="TXN_2", net_sales_amt=None),
        _make_user_journey_row(userjourney_id="J1", transaction_key="TXN_3", net_sales_amt=200.0),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_SCHEMA)

    # Arrange + Act
    total, journey_df = get_user_journey_metrics(df, "journey_data")

    # Assert: sum() ignores null; TXN_1 + TXN_3 = 300.0
    assert total == 300.0
    result = journey_df.select(F.explode(F.col("journey_data")).alias("j")).select("j.*").collect()
    assert len(result) == 1
    assert result[0].sum_exposed_sales == 300.0


def test_aggregate_lift_details_with_null_normalized_weights(spark_session: SparkSession):
    """Test that null normalized_weights are handled by sum() (nulls ignored, potential data loss).

    Scenario: Three rows for offer with normalized_weights: 0.4, null, 0.1.
    Verify: Sum = 0.5 (null silently ignored, which could hide missing data issues).
    """
    rows = [
        _make_mta_result_row(journey_type="offer", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", normalized_weights=0.4),
        _make_mta_result_row(journey_type="offer", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", normalized_weights=None),
        _make_mta_result_row(journey_type="offer", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL", normalized_weights=0.1),
    ]
    df = spark_session.createDataFrame(rows, schema=MTA_RESULT_SCHEMA)

    # Arrange + Act
    result = (
        get_lift_details(df, "offer", "lift")
        .select(F.explode(F.col("lift")).alias("f"))
        .select("f.*")
    )

    # Assert: sum() ignores null (0.4 + 0.1 = 0.5)
    assert result.count() == 1
    row = result.collect()[0]
    assert row.channel_name == "EMAIL"
    assert row.sum_channel_weights == 0.5


def test_get_user_journey_metrics_with_all_null_net_sales(spark_session: SparkSession):
    """Test that all null net_sales_amt results in total=0.0 and journey sum=null (nulls propagate in aggregations).

    Scenario: Two rows for journey J1, both with net_sales_amt=null.
    Verify: Total = 0.0 (sum of nulls is null, coalesced by 'or 0.0'); journey sum_exposed_sales = null (sum ignores nulls).
    """
    rows = [
        _make_user_journey_row(userjourney_id="J1", net_sales_amt=None),
        _make_user_journey_row(userjourney_id="J1", net_sales_amt=None),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_SCHEMA)

    # Arrange + Act
    total, journey_df = get_user_journey_metrics(df, "journey_data")

    # Assert: total coalesced to 0.0, but journey sum_exposed_sales is null (sum of nulls is null)
    assert total == 0.0
    result = journey_df.select(F.explode(F.col("journey_data")).alias("j")).select("j.*").collect()
    assert len(result) == 1
    assert result[0].sum_exposed_sales is None


def test_mta_layer_summary_edge_case_null_values_in_multiple_inputs(spark_session: SparkSession):
    """Test that mta_layer_summary handles null values gracefully across all input DataFrames.

    Scenario: Offer with null net_sales_amt, MTA result with null normalized_weights.
    Verify: Output still completes successfully with proper null handling in aggregations.
    """
    offer_rows = [
        _make_user_journey_row(loyalty_id="USER_1", net_sales_amt=None),
        _make_user_journey_row(loyalty_id="USER_1", net_sales_amt=100.0),
    ]
    offer_df = spark_session.createDataFrame(offer_rows, schema=USER_JOURNEY_SCHEMA)
    brand_df = spark_session.createDataFrame([_make_user_journey_row()], schema=USER_JOURNEY_SCHEMA)

    mta_rows = [
        _make_mta_result_row(journey_type="offer", normalized_weights=None),
        _make_mta_result_row(journey_type="offer", normalized_weights=0.5),
    ]
    mta_df = spark_session.createDataFrame(mta_rows, schema=MTA_RESULT_SCHEMA)

    sku_offer_df = spark_session.createDataFrame([_make_sku_level_attributed_sales_row()], schema=SKU_LEVEL_SCHEMA)
    sku_brand_df = spark_session.createDataFrame([_make_sku_level_attributed_sales_row()], schema=SKU_LEVEL_SCHEMA)

    # Arrange + Act
    result = mta_layer_summary(
        offer_adg_df=offer_df,
        brand_adg_df=brand_df,
        mta_result_df=mta_df,
        sku_level_attributed_sales_offer_df=sku_offer_df,
        sku_level_attributed_sales_brand_df=sku_brand_df,
        correlation_id=CORRELATION_ID,
    )

    # Assert: Completes successfully, output has 1 row
    assert result.count() == 1
    row = result.collect()[0]
    assert row.correlation_id == CORRELATION_ID
    assert row.severity == Severity.HIGH.value


# --- Tests for subchannel-level transaction deduplication ---

def test_get_user_journey_metrics_deduplicates_transaction_within_subchannel(spark_session: SparkSession):
    """Test that the same transaction appearing multiple times per subchannel is counted once.

    Scenario: TXN_1 (net_sales=16) appears 3 times for USER_1/J1/EMAIL — one row per campaign touchpoint.
    Verify: sum_exposed_sales for EMAIL = 16 (not 48); total_sales = 16.
    """
    rows = [
        _make_user_journey_row(
            loyalty_id="USER_1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL",
            userjourney_id="J1", transaction_key="TXN_1", net_sales_amt=16.0,
        ),
        _make_user_journey_row(
            loyalty_id="USER_1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL",
            userjourney_id="J1", transaction_key="TXN_1", net_sales_amt=16.0,
        ),
        _make_user_journey_row(
            loyalty_id="USER_1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL",
            userjourney_id="J1", transaction_key="TXN_1", net_sales_amt=16.0,
        ),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_SCHEMA)

    total, journey_df = get_user_journey_metrics(df, "journey_data")

    result = journey_df.select(F.explode(F.col("journey_data")).alias("j")).select("j.*").collect()

    assert total == 16.0
    assert len(result) == 1
    assert result[0].sum_exposed_sales == 16.0
    assert result[0].count_distinct_loyalty_ids == 1


def test_get_user_journey_metrics_counts_transaction_once_per_subchannel_independently(spark_session: SparkSession):
    """Test that a transaction appearing in two subchannels contributes its sales to each subchannel separately.

    Scenario: TXN_1 (net_sales=100) for USER_1/J1 appears once under EMAIL and once under SMS.
    Verify: EMAIL.sum_exposed_sales = 100, SMS.sum_exposed_sales = 100 (not split or doubled globally).
    """
    rows = [
        _make_user_journey_row(
            loyalty_id="USER_1", channel_name="EMAIL", subchannel_name="MARKETING_EMAIL",
            userjourney_id="J1", transaction_key="TXN_1", net_sales_amt=100.0,
        ),
        _make_user_journey_row(
            loyalty_id="USER_1", channel_name="SMS", subchannel_name="MARKETING_SMS",
            userjourney_id="J1", transaction_key="TXN_1", net_sales_amt=100.0,
        ),
    ]
    df = spark_session.createDataFrame(rows, schema=USER_JOURNEY_SCHEMA)

    _, journey_df = get_user_journey_metrics(df, "journey_data")

    result = (
        journey_df
        .select(F.explode(F.col("journey_data")).alias("j"))
        .select("j.channel_name", "j.subchannel_name", "j.sum_exposed_sales")
        .orderBy("channel_name")
        .collect()
    )

    assert len(result) == 2
    email_row = next(r for r in result if r.channel_name == "EMAIL")
    sms_row = next(r for r in result if r.channel_name == "SMS")
    assert email_row.sum_exposed_sales == 100.0
    assert sms_row.sum_exposed_sales == 100.0
