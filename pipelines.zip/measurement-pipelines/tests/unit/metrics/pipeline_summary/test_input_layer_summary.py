from datetime import date, timedelta

from chispa import assert_df_equality
from pyspark.sql import SparkSession
from pyspark.sql import types as T

from spark_pipeline.common.variables import (
    BaselineProcessedData
)
from spark_pipeline.metrics.pipeline_summary.input_layer_summary import (
    build_campaign_booking_media_channel_df,
    build_campaign_details_metrics_df,
    build_marketing_details_df,
    build_product_details_df,
    has_empty_campaign_details_inputs,
    input_layer_summary,
)

# ---------------------------------------------------------------------------
# Shared schemas
# ---------------------------------------------------------------------------

_UNIFIED_CAMPAIGN_SCHEMA = T.StructType([
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("campaign_start_dt", T.StringType(), True),
    T.StructField("campaign_end_dt", T.StringType(), True),
    T.StructField("post_campaign_dt", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("media_spend_amt", T.DoubleType(), True),
    T.StructField("unique_brand_name", T.StringType(), True),
    T.StructField("super_category_name", T.StringType(), True),
])

_PRODUCT_DETAILS_RAW_SCHEMA = T.StructType([
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("item_cd", T.StringType(), True),
    T.StructField("sku_name", T.StringType(), True),
    T.StructField("product_type", T.StringType(), True),
    T.StructField("brand_name", T.StringType(), True),
    T.StructField("unique_brand_name", T.StringType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("load_ts", T.StringType(), True),
    T.StructField("sales_amt", T.DoubleType(), True),
])

_BASELINE_MODELLING_SCHEMA = T.StructType([
    T.StructField("week_start_dt", T.StringType(), True),
    T.StructField("super_category_name", T.StringType(), True),
    T.StructField("unique_brand_name", T.StringType(), True),
    T.StructField("cluster_num", T.StringType(), True),
    T.StructField("marketing_type_name", T.StringType(), True),
    T.StructField("marketing_channel_name", T.StringType(), True),
    T.StructField("marketing_sub_channel_name", T.StringType(), True),
    T.StructField("metric_name", T.StringType(), True),
    T.StructField("metric_value", T.DoubleType(), True),
    T.StructField("variable_cd", T.StringType(), True),
    T.StructField("load_ts", T.StringType(), True),
])

_BOOKING_MEDIA_CHANNEL_SCHEMA = T.StructType([
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("store_cd_list", T.StringType(), True),
])

_CAMPAIGN_DETAILS_METRICS_SCHEMA = T.StructType([
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("campaign_start_date", T.StringType(), True),
    T.StructField("campaign_end_date", T.StringType(), True),
    T.StructField("post_campaign_date", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("media_spend_amt", T.DoubleType(), True),
    T.StructField("unique_brand_name", T.StringType(), True),
    T.StructField("super_category_name", T.StringType(), True),
    T.StructField("correlation_id", T.StringType(), True),
])

_PRODUCT_DETAILS_OUTPUT_SCHEMA = T.StructType([
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("item_cd", T.StringType(), True),
    T.StructField("sku_name", T.StringType(), True),
    T.StructField("product_type", T.StringType(), True),
    T.StructField("brand_name", T.StringType(), True),
    T.StructField("unique_brand_name", T.StringType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("load_ts", T.StringType(), True),
    T.StructField("sales_amt", T.DoubleType(), True),
    T.StructField("correlation_id", T.StringType(), True),
])

# ---------------------------------------------------------------------------
# Shared constants
# ---------------------------------------------------------------------------

_BOOKING_ID = "BK-001"
_CAMPAIGN_ID = "CAMP-001"
_CORRELATION_ID = "corr-abc"
_BRAND = "Brand Alpha"
_SUPER_CAT = "Beverages"
_CAMPAIGN_START = date(2024, 6, 1)
_CAMPAIGN_END = date(2024, 6, 30)
_POST_CAMPAIGN = date(2024, 7, 14)
_WEEK_BEFORE_CAMPAIGN = str(_CAMPAIGN_START - timedelta(weeks=1))
_SALES_CONFIG = BaselineProcessedData.sales_data_config


# ---------------------------------------------------------------------------
# Builder helpers
# ---------------------------------------------------------------------------

def _make_unified_campaign_row(
    booking_id=_BOOKING_ID,
    campaign_id=_CAMPAIGN_ID,
    brand=_BRAND,
    super_cat=_SUPER_CAT,
    spend=100.0,
):
    return (
        booking_id,
        campaign_id,
        str(_CAMPAIGN_START),
        str(_CAMPAIGN_END),
        str(_POST_CAMPAIGN),
        "Digital",
        spend,
        brand,
        super_cat,
    )


def _make_product_row(
    booking_id=_BOOKING_ID,
    campaign_id=_CAMPAIGN_ID,
    brand=_BRAND,
    product_type="Offer",
    sku_name="SKU-1",
    item_cd="ITEM-1",
    load_ts=None,
    sales_amt=500.0,
):
    load_ts = load_ts or str(_CAMPAIGN_START - timedelta(weeks=1))
    return (booking_id, campaign_id, item_cd, sku_name, product_type, brand, brand, "Online", load_ts, sales_amt)


def _make_baseline_row(
    brand=_BRAND,
    super_cat=_SUPER_CAT,
    metric_name=_SALES_CONFIG["metric_name"],
    marketing_type=_SALES_CONFIG["marketing_type_name"],
    marketing_channel=_SALES_CONFIG["marketing_channel_name"],
    metric_value=1000.0,
    week_start_dt=None,
):
    week_start_dt = week_start_dt or _WEEK_BEFORE_CAMPAIGN
    return (
        week_start_dt,
        super_cat,
        brand,
        "C1",
        marketing_type,
        marketing_channel,
        "TOTAL",
        metric_name,
        metric_value,
        None,
        None,
    )


def _make_campaign_details_metrics_df(spark_session, brand=_BRAND, super_cat=_SUPER_CAT):
    rows = [(_CAMPAIGN_ID, _BOOKING_ID, str(_CAMPAIGN_START), str(_CAMPAIGN_END), str(_POST_CAMPAIGN), "Digital", 100.0, brand, super_cat, _CORRELATION_ID)]
    return spark_session.createDataFrame(rows, schema=_CAMPAIGN_DETAILS_METRICS_SCHEMA)


# ---------------------------------------------------------------------------
# has_empty_campaign_details_inputs
# ---------------------------------------------------------------------------

def test_has_empty_campaign_details_inputs_returns_false_when_all_have_rows(spark_session: SparkSession):
    # Arrange
    schema = T.StructType([T.StructField("id", T.StringType(), True)])
    non_empty = spark_session.createDataFrame([("a",)], schema=schema)

    # Act
    result = has_empty_campaign_details_inputs(non_empty, non_empty, non_empty)

    # Assert
    assert result is False


def test_has_empty_campaign_details_inputs_returns_true_when_campaign_details_empty(spark_session: SparkSession):
    # Arrange
    schema = T.StructType([T.StructField("id", T.StringType(), True)])
    non_empty = spark_session.createDataFrame([("a",)], schema=schema)
    empty = spark_session.createDataFrame([], schema=schema)

    # Act / Assert
    assert has_empty_campaign_details_inputs(empty, non_empty, non_empty) is True


def test_has_empty_campaign_details_inputs_returns_true_when_product_details_empty(spark_session: SparkSession):
    # Arrange
    schema = T.StructType([T.StructField("id", T.StringType(), True)])
    non_empty = spark_session.createDataFrame([("a",)], schema=schema)
    empty = spark_session.createDataFrame([], schema=schema)

    # Act / Assert
    assert has_empty_campaign_details_inputs(non_empty, empty, non_empty) is True


def test_has_empty_campaign_details_inputs_returns_true_when_marketing_details_empty(spark_session: SparkSession):
    # Arrange
    schema = T.StructType([T.StructField("id", T.StringType(), True)])
    non_empty = spark_session.createDataFrame([("a",)], schema=schema)
    empty = spark_session.createDataFrame([], schema=schema)

    # Act / Assert
    assert has_empty_campaign_details_inputs(non_empty, non_empty, empty) is True


# ---------------------------------------------------------------------------
# build_campaign_details_metrics_df
# ---------------------------------------------------------------------------

def test_build_campaign_details_metrics_df_happy_path(spark_session: SparkSession):
    # Arrange
    unified_campaign_df = spark_session.createDataFrame(
        [_make_unified_campaign_row()],
        schema=_UNIFIED_CAMPAIGN_SCHEMA,
    )
    expected = spark_session.createDataFrame(
        [(_CAMPAIGN_ID, _BOOKING_ID, str(_CAMPAIGN_START), str(_CAMPAIGN_END), str(_POST_CAMPAIGN), "Digital", 100.0, _BRAND, _SUPER_CAT, _CORRELATION_ID)],
        schema=_CAMPAIGN_DETAILS_METRICS_SCHEMA,
    )

    # Act
    result = build_campaign_details_metrics_df(unified_campaign_df, _BOOKING_ID, _CORRELATION_ID)

    # Assert
    assert_df_equality(result, expected, ignore_nullable=True)


def test_build_campaign_details_metrics_df_filters_other_booking_ids(spark_session: SparkSession):
    # Arrange
    unified_campaign_df = spark_session.createDataFrame(
        [
            _make_unified_campaign_row(booking_id=_BOOKING_ID),
            _make_unified_campaign_row(booking_id="OTHER-BK"),
        ],
        schema=_UNIFIED_CAMPAIGN_SCHEMA,
    )
    expected = spark_session.createDataFrame(
        [(_CAMPAIGN_ID, _BOOKING_ID, str(_CAMPAIGN_START), str(_CAMPAIGN_END), str(_POST_CAMPAIGN), "Digital", 100.0, _BRAND, _SUPER_CAT, _CORRELATION_ID)],
        schema=_CAMPAIGN_DETAILS_METRICS_SCHEMA,
    )

    # Act
    result = build_campaign_details_metrics_df(unified_campaign_df, _BOOKING_ID, _CORRELATION_ID)

    # Assert
    assert_df_equality(result, expected, ignore_nullable=True)


def test_build_campaign_details_metrics_df_empty_input(spark_session: SparkSession):
    # Arrange
    empty_df = spark_session.createDataFrame([], schema=_UNIFIED_CAMPAIGN_SCHEMA)
    expected = spark_session.createDataFrame([], schema=_CAMPAIGN_DETAILS_METRICS_SCHEMA)

    # Act
    result = build_campaign_details_metrics_df(empty_df, _BOOKING_ID, _CORRELATION_ID)

    # Assert
    assert_df_equality(result, expected, ignore_nullable=True)


# ---------------------------------------------------------------------------
# build_product_details_df
# ---------------------------------------------------------------------------

def test_build_product_details_df_happy_path(spark_session: SparkSession):
    # Arrange
    load_ts = str(_CAMPAIGN_START - timedelta(weeks=1))
    product_raw_df = spark_session.createDataFrame(
        [_make_product_row(load_ts=load_ts)],
        schema=_PRODUCT_DETAILS_RAW_SCHEMA,
    )
    expected = spark_session.createDataFrame(
        [(_CAMPAIGN_ID, _BOOKING_ID, "ITEM-1", "SKU-1", "Offer", _BRAND, _BRAND, "Online", load_ts, 500.0, _CORRELATION_ID)],
        schema=_PRODUCT_DETAILS_OUTPUT_SCHEMA,
    )

    # Act
    result = build_product_details_df(product_raw_df, _BOOKING_ID, _CORRELATION_ID)

    # Assert
    assert_df_equality(result, expected, ignore_nullable=True)


def test_build_product_details_df_falls_back_to_null_when_no_sales_column(spark_session: SparkSession):
    # Arrange
    schema_no_sales = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("item_cd", T.StringType(), True),
        T.StructField("sku_name", T.StringType(), True),
        T.StructField("product_type", T.StringType(), True),
        T.StructField("brand_name", T.StringType(), True),
        T.StructField("unique_brand_name", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("load_ts", T.StringType(), True),
    ])
    load_ts = str(_CAMPAIGN_START)
    product_raw_df = spark_session.createDataFrame(
        [(_BOOKING_ID, _CAMPAIGN_ID, "I1", "SKU-1", "Offer", _BRAND, _BRAND, "Online", load_ts)],
        schema=schema_no_sales,
    )
    expected = spark_session.createDataFrame(
        [(_CAMPAIGN_ID, _BOOKING_ID, "I1", "SKU-1", "Offer", _BRAND, _BRAND, "Online", load_ts, None, _CORRELATION_ID)],
        schema=_PRODUCT_DETAILS_OUTPUT_SCHEMA,
    )

    # Act
    result = build_product_details_df(product_raw_df, _BOOKING_ID, _CORRELATION_ID)

    # Assert
    assert_df_equality(result, expected, ignore_nullable=True)


def test_build_product_details_df_empty_input(spark_session: SparkSession):
    # Arrange
    empty_df = spark_session.createDataFrame([], schema=_PRODUCT_DETAILS_RAW_SCHEMA)
    expected = spark_session.createDataFrame([], schema=_PRODUCT_DETAILS_OUTPUT_SCHEMA)

    # Act
    result = build_product_details_df(empty_df, _BOOKING_ID, _CORRELATION_ID)

    # Assert
    assert_df_equality(result, expected, ignore_nullable=True)


# ---------------------------------------------------------------------------
# build_marketing_details_df
# ---------------------------------------------------------------------------

_MARKETING_DETAILS_OUTPUT_SCHEMA = T.StructType([
    T.StructField("week_start_dt", T.StringType(), True),
    T.StructField("super_category_name", T.StringType(), True),
    T.StructField("unique_brand_name", T.StringType(), True),
    T.StructField("cluster_num", T.StringType(), True),
    T.StructField("marketing_type_name", T.StringType(), True),
    T.StructField("marketing_channel_name", T.StringType(), True),
    T.StructField("marketing_sub_channel_name", T.StringType(), True),
    T.StructField("metric_name", T.StringType(), True),
    T.StructField("metric_value", T.DoubleType(), True),
    T.StructField("variable_cd", T.StringType(), True),
    T.StructField("load_ts", T.StringType(), True),
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("campaign_start_date", T.StringType(), True),
    T.StructField("campaign_end_date", T.StringType(), True),
    T.StructField("correlation_id", T.StringType(), True),
])


def test_build_marketing_details_df_includes_sales_rows(spark_session: SparkSession):
    # Arrange
    baseline_df = spark_session.createDataFrame(
        [_make_baseline_row()],
        schema=_BASELINE_MODELLING_SCHEMA,
    )
    campaign_details_df = _make_campaign_details_metrics_df(spark_session)
    expected = spark_session.createDataFrame(
        [(
            _WEEK_BEFORE_CAMPAIGN,
            _SUPER_CAT.lower(),
            _BRAND.lower(),
            "C1",
            _SALES_CONFIG["marketing_type_name"].lower(),
            _SALES_CONFIG["marketing_channel_name"],
            "TOTAL",
            _SALES_CONFIG["metric_name"].lower(),
            1000.0,
            None,
            None,
            _CAMPAIGN_ID,
            _BOOKING_ID,
            str(_CAMPAIGN_START),
            str(_CAMPAIGN_END),
            _CORRELATION_ID,
        )],
        schema=_MARKETING_DETAILS_OUTPUT_SCHEMA,
    )

    # Act
    result = build_marketing_details_df(baseline_df, _BOOKING_ID, campaign_details_df)

    # Assert
    assert_df_equality(result, expected, ignore_nullable=True, ignore_column_order=True)


def test_build_marketing_details_df_excludes_rows_outside_date_window(spark_session: SparkSession):
    # Arrange: sales row dated after campaign start — must be excluded
    future_week = str(_CAMPAIGN_START + timedelta(weeks=1))
    baseline_df = spark_session.createDataFrame(
        [_make_baseline_row(week_start_dt=future_week)],
        schema=_BASELINE_MODELLING_SCHEMA,
    )
    campaign_details_df = _make_campaign_details_metrics_df(spark_session)
    expected = spark_session.createDataFrame([], schema=_MARKETING_DETAILS_OUTPUT_SCHEMA)

    # Act
    result = build_marketing_details_df(baseline_df, _BOOKING_ID, campaign_details_df)

    # Assert
    assert_df_equality(
        result.select(*_MARKETING_DETAILS_OUTPUT_SCHEMA.fieldNames()),
        expected,
        ignore_nullable=True,
    )


def test_build_marketing_details_df_excludes_unmatched_brand(spark_session: SparkSession):
    # Arrange: sales row for a brand not in campaign — inner join produces no rows
    baseline_df = spark_session.createDataFrame(
        [_make_baseline_row(brand="Other Brand")],
        schema=_BASELINE_MODELLING_SCHEMA,
    )
    campaign_details_df = _make_campaign_details_metrics_df(spark_session)
    expected = spark_session.createDataFrame([], schema=_MARKETING_DETAILS_OUTPUT_SCHEMA)

    # Act
    result = build_marketing_details_df(baseline_df, _BOOKING_ID, campaign_details_df)

    # Assert
    assert_df_equality(
        result.select(*_MARKETING_DETAILS_OUTPUT_SCHEMA.fieldNames()),
        expected,
        ignore_nullable=True,
    )


def test_build_marketing_details_df_normalises_brand_case_for_join(spark_session: SparkSession):
    # Arrange: brand casing differs between baseline and campaign — normalisation must resolve it
    baseline_df = spark_session.createDataFrame(
        [_make_baseline_row(brand=_BRAND.upper())],
        schema=_BASELINE_MODELLING_SCHEMA,
    )
    campaign_details_df = _make_campaign_details_metrics_df(spark_session, brand=_BRAND.lower())
    expected = spark_session.createDataFrame(
        [(
            _SALES_CONFIG["metric_name"].lower(),
            1000.0
        )],
        schema=T.StructType([
            T.StructField("metric_name", T.StringType(), True),
            T.StructField("metric_value", T.DoubleType(), True),
        ]),
    )

    # Act
    result = build_marketing_details_df(baseline_df, _BOOKING_ID, campaign_details_df)

    # Assert
    assert_df_equality(result.select("metric_name", "metric_value"), expected, ignore_nullable=True)


def test_build_marketing_details_df_empty_baseline(spark_session: SparkSession):
    # Arrange
    empty_df = spark_session.createDataFrame([], schema=_BASELINE_MODELLING_SCHEMA)
    campaign_details_df = _make_campaign_details_metrics_df(spark_session)
    expected = spark_session.createDataFrame([], schema=_MARKETING_DETAILS_OUTPUT_SCHEMA)

    # Act
    result = build_marketing_details_df(empty_df, _BOOKING_ID, campaign_details_df)

    # Assert
    assert_df_equality(
        result.select(*_MARKETING_DETAILS_OUTPUT_SCHEMA.fieldNames()),
        expected,
        ignore_nullable=True,
    )


# ---------------------------------------------------------------------------
# build_campaign_booking_media_channel_df
# ---------------------------------------------------------------------------

def test_build_campaign_booking_media_channel_df_filters_to_matching_campaigns(spark_session: SparkSession):
    # Arrange
    raw_df = spark_session.createDataFrame(
        [
            (_CAMPAIGN_ID, _BOOKING_ID, "S1,S2"),
            ("OTHER-CAMP", "OTHER-BK", "S3"),
        ],
        schema=_BOOKING_MEDIA_CHANNEL_SCHEMA,
    )
    campaign_details_df = _make_campaign_details_metrics_df(spark_session)
    expected = spark_session.createDataFrame(
        [(_CAMPAIGN_ID, _BOOKING_ID, "S1,S2")],
        schema=_BOOKING_MEDIA_CHANNEL_SCHEMA,
    )

    # Act
    result = build_campaign_booking_media_channel_df(raw_df, campaign_details_df)

    # Assert
    assert_df_equality(result, expected, ignore_nullable=True)


def test_build_campaign_booking_media_channel_df_empty_input(spark_session: SparkSession):
    # Arrange
    empty_df = spark_session.createDataFrame([], schema=_BOOKING_MEDIA_CHANNEL_SCHEMA)
    campaign_details_df = _make_campaign_details_metrics_df(spark_session)
    expected = spark_session.createDataFrame([], schema=_BOOKING_MEDIA_CHANNEL_SCHEMA)

    # Act
    result = build_campaign_booking_media_channel_df(empty_df, campaign_details_df)

    # Assert
    assert_df_equality(result, expected, ignore_nullable=True)


# ---------------------------------------------------------------------------
# input_layer_summary — integration-level
# ---------------------------------------------------------------------------

def _make_full_inputs(spark_session):
    unified_campaign_df = spark_session.createDataFrame(
        [_make_unified_campaign_row()],
        schema=_UNIFIED_CAMPAIGN_SCHEMA,
    )
    product_raw_df = spark_session.createDataFrame(
        [_make_product_row()],
        schema=_PRODUCT_DETAILS_RAW_SCHEMA,
    )
    baseline_df = spark_session.createDataFrame(
        [_make_baseline_row()],
        schema=_BASELINE_MODELLING_SCHEMA,
    )
    booking_media_df = spark_session.createDataFrame(
        [(_CAMPAIGN_ID, _BOOKING_ID, "S1,S2,S3")],
        schema=_BOOKING_MEDIA_CHANNEL_SCHEMA,
    )
    return unified_campaign_df, product_raw_df, baseline_df, booking_media_df


def test_input_layer_summary_returns_one_canonical_row(spark_session: SparkSession):
    # Arrange
    unified_campaign_df, product_raw_df, baseline_df, booking_media_df = _make_full_inputs(spark_session)
    expected = spark_session.createDataFrame(
        [(_CORRELATION_ID, "campaign_details", "campaign_details")],
        schema=T.StructType([
            T.StructField("correlation_id", T.StringType(), True),
            T.StructField("name", T.StringType(), True),
            T.StructField("data_group", T.StringType(), True),
        ]),
    )

    # Act
    result = input_layer_summary(
        unified_campaign_df=unified_campaign_df,
        product_details_raw_df=product_raw_df,
        baseline_modelling_dataset_df=baseline_df,
        campaign_booking_media_channel_raw_df=booking_media_df,
        booking_id=_BOOKING_ID,
        correlation_id=_CORRELATION_ID,
    )

    # Assert
    assert result is not None
    assert_df_equality(
        result.select("correlation_id", "name", "data_group"),
        expected,
        ignore_nullable=True,
    )


def test_input_layer_summary_returns_none_when_campaign_details_empty(spark_session: SparkSession):
    # Arrange: non-existent booking_id so campaign_details_metrics_df is empty
    unified_campaign_df, product_raw_df, baseline_df, booking_media_df = _make_full_inputs(spark_session)

    # Act
    result = input_layer_summary(
        unified_campaign_df=unified_campaign_df,
        product_details_raw_df=product_raw_df,
        baseline_modelling_dataset_df=baseline_df,
        campaign_booking_media_channel_raw_df=booking_media_df,
        booking_id="NONEXISTENT",
        correlation_id=_CORRELATION_ID,
    )

    # Assert
    assert result is None


def test_input_layer_summary_sales_uses_normalised_brand_for_join(spark_session: SparkSession):
    """Regression: unique_brand_name case mismatch between product_details and marketing_details
    must not suppress offer_sales_amt_104w / brand_sales_amt_104w in the canonical output."""
    # Arrange: product uses mixed-case brand; baseline (sales) uses uppercase brand
    unified_campaign_df = spark_session.createDataFrame(
        [_make_unified_campaign_row(brand=_BRAND)],
        schema=_UNIFIED_CAMPAIGN_SCHEMA,
    )
    product_raw_df = spark_session.createDataFrame(
        [_make_product_row(brand=_BRAND, product_type="Offer")],
        schema=_PRODUCT_DETAILS_RAW_SCHEMA,
    )
    baseline_df = spark_session.createDataFrame(
        [_make_baseline_row(brand=_BRAND.upper(), metric_value=2500.0)],
        schema=_BASELINE_MODELLING_SCHEMA,
    )
    booking_media_df = spark_session.createDataFrame(
        [(_CAMPAIGN_ID, _BOOKING_ID, "S1")],
        schema=_BOOKING_MEDIA_CHANNEL_SCHEMA,
    )
    expected = spark_session.createDataFrame(
        [(_CORRELATION_ID, "campaign_details")],
        schema=T.StructType([
            T.StructField("correlation_id", T.StringType(), True),
            T.StructField("name", T.StringType(), True),
        ]),
    )

    # Act
    result = input_layer_summary(
        unified_campaign_df=unified_campaign_df,
        product_details_raw_df=product_raw_df,
        baseline_modelling_dataset_df=baseline_df,
        campaign_booking_media_channel_raw_df=booking_media_df,
        booking_id=_BOOKING_ID,
        correlation_id=_CORRELATION_ID,
    )

    # Assert
    assert result is not None
    assert_df_equality(
        result.select("correlation_id", "name"),
        expected,
        ignore_nullable=True,
    )
