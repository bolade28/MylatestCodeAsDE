from datetime import date, timedelta
import json
from unittest import mock
from unittest.mock import MagicMock

from chispa import assert_df_equality
from pyspark.sql import SparkSession

from spark_pipeline.common.variables import (
    BaselineModellingOutputConfig,
    BaselineProcessedData,
    CampaignDurations,
)
from spark_pipeline.metrics.baseline_validation_metrics.sales_validation_metrics import (
    _check_sales_near_zero_in_period,
    _calculate_sales_medians,
    _combine_sales_isolated_extremes,
    _format_sales_distribution_outlier_warnings,
    _resolve_validation_metric_value,
    check_during_run_near_zero_sales,
    check_post_run_near_zero_sales,
    check_sales_distribution_outliers,
    check_sales_near_zero_weeks,
    check_sales_zero_streaks,
    filter_sales_baseline_dataset,
    publish_sales_validation_metrics,
    run_all_sales_checks,
    select_recent_sales_window,
)
from spark_pipeline.schemas.validation_metrics_schema import ValidationMetrics

SALES_BASELINE_SCHEMA = ValidationMetrics.SALES_BASELINE_SCHEMA
SALES_CAMPAIGN_SCHEMA = ValidationMetrics.SALES_CAMPAIGN_SCHEMA
SALES_ZERO_STREAK_SCHEMA = ValidationMetrics.SALES_ZERO_STREAK_SCHEMA
SALES_NEAR_ZERO_SCHEMA = ValidationMetrics.SALES_NEAR_ZERO_SCHEMA
SALES_OUTLIER_SCHEMA = ValidationMetrics.SALES_OUTLIER_SCHEMA
SALES_PERIOD_CHECK_SCHEMA = ValidationMetrics.SALES_PERIOD_CHECK_SCHEMA
SALES_ALL_CHECKS_SCHEMA = ValidationMetrics.SALES_ALL_CHECKS_SCHEMA

_BASE_DATE = date(2024, 1, 1)
_SALES_CONFIG = BaselineProcessedData.sales_data_config
_CAMPAIGN_SELECTION_WITHOUT_POST_COLUMNS = [
    "unique_brand_name",
    "super_category_name",
    "min_campaign_start_dt",
    "max_campaign_end_dt",
]


def _sales_validation_config() -> BaselineModellingOutputConfig:
    config = BaselineModellingOutputConfig()
    config.sales_validation_lookback_weeks = 104
    config.sales_zero_streak_warning_weeks = 4
    config.sales_near_zero_threshold = 0.01
    config.sales_outlier_multiplier = 3.0
    return config


def _sales_rows(values, brand="BRANDA", category="CATA", cluster="C1", start_dt=_BASE_DATE):
    return [
        (
            brand,
            category,
            cluster,
            _SALES_CONFIG["marketing_type_name"],
            _SALES_CONFIG["marketing_channel_name"],
            start_dt + timedelta(weeks=index),
            _SALES_CONFIG["metric_name"],
            float(value),
        )
        for index, value in enumerate(values)
    ]


def _campaign_row(start_index, end_index, post_index=None, brand="BRANDA", category="CATA"):
    return (
        brand,
        category,
        _BASE_DATE + timedelta(weeks=start_index),
        _BASE_DATE + timedelta(weeks=end_index),
        _BASE_DATE + timedelta(weeks=(post_index if post_index is not None else end_index)),
    )


def _campaign_row_without_post(start_index, end_index, brand="BRANDA", category="CATA"):
    return (
        brand,
        category,
        _BASE_DATE + timedelta(weeks=start_index),
        _BASE_DATE + timedelta(weeks=end_index),
    )


class TestResolveValidationMetricValue:

    def test_returns_longest_zero_streak_for_zero_streak_check(self):
        # Arrange: create metadata for a zero-streak warning with a meaningful streak length.
        metadata = {"longest_zero_sales_streak": 4}

        # Act: resolve the primary event value for the zero-streak check.
        actual = _resolve_validation_metric_value("sales_zero_streak_check", metadata)

        # Assert: verify that the longest zero streak is exposed as the event value.
        assert actual == "4"

    def test_returns_near_zero_week_count_for_near_zero_checks(self):
        # Arrange: create metadata with a near-zero week count shared by the near-zero checks.
        metadata = {"near_zero_weeks": 2}

        # Act: resolve the event values for the generic, During, and Post near-zero checks.
        actual_values = {
            _resolve_validation_metric_value("near_zero_sales_check", metadata),
            _resolve_validation_metric_value("during_period_near_zero_check", metadata),
            _resolve_validation_metric_value("post_period_near_zero_check", metadata),
        }

        # Assert: verify that each near-zero variant uses the near-zero week count.
        assert actual_values == {"2"}

    def test_returns_combined_outlier_count_for_distribution_check(self):
        # Arrange: create metadata with both median-band and isolated-extreme warning counts.
        metadata = {
            "median_outlier_weeks": 2,
            "isolated_extreme_weeks": 1,
        }

        # Act: resolve the event value for the distribution-outlier check.
        actual = _resolve_validation_metric_value("sales_distribution_outlier_check", metadata)

        # Assert: verify that the published value is the total number of flagged weeks/extremes.
        assert actual == "3"

    def test_returns_zero_for_unknown_check_name(self):
        # Arrange: create metadata for a check that has no special value mapping.
        metadata = {"some_other_metric": 99}

        # Act: resolve the event value for an unknown check name.
        actual = _resolve_validation_metric_value("unknown_check", metadata)

        # Assert: verify that unknown checks fall back to the default zero value.
        assert actual == "0"


class TestFilterSalesBaselineDataset:

    def test_filters_down_to_total_sales_only(self, spark_session: SparkSession):
        # Arrange: build a mixed baseline dataset containing one valid TOTAL_SALES row and two rows for other metrics.
        mixed_rows = [
            *_sales_rows([10.0]),
            ("BRANDA", "CATA", "C1", "SALES", "SALES", _BASE_DATE, "BASE_UNIT_PRICE_AMT", 2.0),
            ("BRANDA", "CATA", "C1", "OFFSITE", "META", _BASE_DATE, "IMPRESSIONS", 100.0),
        ]
        baseline_df = spark_session.createDataFrame(mixed_rows, schema=SALES_BASELINE_SCHEMA)
        expected = spark_session.createDataFrame(_sales_rows([10.0]), schema=SALES_BASELINE_SCHEMA)

        # Act: keep only the sales rows used by the validation checks.
        actual = filter_sales_baseline_dataset(baseline_df)

        # Assert: verify that only the TOTAL_SALES / SALES / SALES row remains.
        assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)


class TestCheckSalesZeroStreaks:

    def test_warns_when_recent_window_contains_four_week_zero_streak(self, spark_session: SparkSession):
        # Arrange: create a recent 104-week series with one run of four consecutive zero-sales weeks.
        config = _sales_validation_config()
        values = ([12.0] * 40) + ([0.0] * 4) + ([15.0] * 60)
        baseline_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        recent_sales_df = select_recent_sales_window(filter_sales_baseline_dataset(baseline_df), config=config)

        # Act: run the zero-streak validation for the recent sales window.
        rows = check_sales_zero_streaks(recent_sales_df, config=config).collect()

        # Assert: verify that the series is flagged once with the expected streak length and severity.
        assert len(rows) == 1
        row = rows[0]
        metadata = json.loads(row["metadata"])
        assert row["check_name"] == "sales_zero_streak_check"
        assert row["severity"] == "MEDIUM"
        assert metadata["longest_zero_sales_streak"] == 4
        assert len(metadata["zero_sales_week_dates"]) == 4

    def test_ignores_zero_streaks_outside_latest_104_weeks(self, spark_session: SparkSession):
        # Arrange: create a long series where the only four-week zero streak falls before the recent lookback window.
        config = _sales_validation_config()
        values = ([0.0] * 4) + ([14.0] * 106)
        baseline_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        recent_sales_df = select_recent_sales_window(filter_sales_baseline_dataset(baseline_df), config=config)
        expected = spark_session.createDataFrame([], schema=SALES_ALL_CHECKS_SCHEMA)

        # Act: run the zero-streak validation on the recent portion of the series.
        actual = check_sales_zero_streaks(recent_sales_df, config=config)

        # Assert: verify that no warnings are produced because the old streak is out of scope.
        assert_df_equality(actual, expected, ignore_nullable=True)

    def test_does_not_warn_when_zero_weeks_are_not_consecutive(self, spark_session: SparkSession):
        # Arrange: create a recent series with several zero weeks separated by non-zero weeks.
        config = _sales_validation_config()
        values = ([18.0] * 20) + [0.0, 18.0, 0.0, 18.0, 0.0, 18.0, 0.0] + ([18.0] * 77)
        baseline_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        recent_sales_df = select_recent_sales_window(filter_sales_baseline_dataset(baseline_df), config=config)
        expected = spark_session.createDataFrame([], schema=SALES_ALL_CHECKS_SCHEMA)

        # Act: run the zero-streak validation on the series with broken-up zero weeks.
        actual = check_sales_zero_streaks(recent_sales_df, config=config)

        # Assert: verify that no warning is raised because the zero weeks never form a long enough streak.
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestCheckSalesNearZeroWeeks:

    def test_warns_when_a_single_week_is_close_to_zero(self, spark_session: SparkSession):
        # Arrange: create a recent series with one weekly TOTAL_SALES value inside the near-zero threshold.
        config = _sales_validation_config()
        values = ([20.0] * 20) + [0.005] + ([20.0] * 83)
        baseline_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        recent_sales_df = select_recent_sales_window(filter_sales_baseline_dataset(baseline_df), config=config)

        # Act: run the near-zero sales check for the recent sales window.
        rows = check_sales_near_zero_weeks(recent_sales_df, config=config).collect()

        # Assert: verify that the suspicious week is surfaced with a MEDIUM-severity warning.
        assert len(rows) == 1
        row = rows[0]
        metadata = json.loads(row["metadata"])
        assert row["check_name"] == "near_zero_sales_check"
        assert row["severity"] == "MEDIUM"
        assert metadata["near_zero_weeks"] == 1
        assert metadata["near_zero_week_dates"][0]["value"] == 0.005

    def test_returns_empty_when_all_weeks_are_comfortably_above_threshold(self, spark_session: SparkSession):
        # Arrange: create a series where every week stays well above the near-zero threshold.
        config = _sales_validation_config()
        values = [20.0] * 104
        baseline_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        recent_sales_df = select_recent_sales_window(filter_sales_baseline_dataset(baseline_df), config=config)
        expected = spark_session.createDataFrame([], schema=SALES_ALL_CHECKS_SCHEMA)

        # Act: run the near-zero sales check on the stable series.
        actual = check_sales_near_zero_weeks(recent_sales_df, config=config)

        # Assert: verify that no warning rows are returned.
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestCheckSalesDistributionOutliers:

    def test_calculate_sales_medians_returns_one_row_per_series(self, spark_session: SparkSession):
        # Arrange: create one sales series whose median is easy to verify by inspection.
        baseline_df = spark_session.createDataFrame(
            _sales_rows([10.0, 10.0, 12.0, 14.0, 16.0]),
            schema=SALES_BASELINE_SCHEMA,
        )
        sales_df = filter_sales_baseline_dataset(baseline_df)

        # Act: calculate the approximate median for the sales series.
        rows = _calculate_sales_medians(sales_df).collect()

        # Assert: verify that one median row is returned and the median value is correct.
        assert len(rows) == 1
        assert rows[0]["median_sales"] == 12.0

    def test_combine_sales_isolated_extremes_merges_high_and_low_flags(self, spark_session: SparkSession):
        # Arrange: build one high extreme row and one low extreme row for the same sales series.
        high_isolated_df = spark_session.createDataFrame([
            (
                "BRANDA",
                "CATA",
                "C1",
                _SALES_CONFIG["marketing_type_name"],
                _SALES_CONFIG["marketing_channel_name"],
                _SALES_CONFIG["metric_name"],
                1,
                [{"week": "2024-01-01", "value": 35.0}],
            ),
        ], schema="""
            unique_brand_name string,
            super_category_name string,
            cluster_num string,
            marketing_type_name string,
            marketing_channel_name string,
            metric_name string,
            isolated_extreme_weeks int,
            isolated_extreme_week_dates array<struct<week:string,value:double>>
        """)
        low_isolated_df = spark_session.createDataFrame([
            (
                "BRANDA",
                "CATA",
                "C1",
                _SALES_CONFIG["marketing_type_name"],
                _SALES_CONFIG["marketing_channel_name"],
                _SALES_CONFIG["metric_name"],
                1,
                [{"week": "2024-01-08", "value": 0.5}],
            ),
        ], schema=high_isolated_df.schema)

        # Act: combine the high-side and low-side isolated-extreme rows.
        rows = _combine_sales_isolated_extremes(high_isolated_df, low_isolated_df).collect()

        # Assert: verify that the series is collapsed to one row with both weeks included.
        assert len(rows) == 1
        row = rows[0]
        assert row["isolated_extreme_weeks"] == 2
        assert [week["week"] for week in row["isolated_extreme_week_dates"]] == ["2024-01-01", "2024-01-08"]

    def test_format_sales_distribution_outlier_warnings_creates_shared_warning_schema(self, spark_session: SparkSession):
        # Arrange: create one detailed distribution-warning row ready for final formatting.
        config = _sales_validation_config()
        distribution_details_df = spark_session.createDataFrame([
            (
                "BRANDA",
                "CATA",
                "C1",
                _SALES_CONFIG["marketing_type_name"],
                _SALES_CONFIG["marketing_channel_name"],
                _SALES_CONFIG["metric_name"],
                10.0,
                2,
                [{"week": "2024-01-01", "value": 35.0}],
                1,
                [{"week": "2024-01-08", "value": 0.5}],
                "MEDIUM",
                "example message",
            ),
        ], schema=SALES_OUTLIER_SCHEMA)

        # Act: convert the detailed row into the shared warning-event output shape.
        rows = _format_sales_distribution_outlier_warnings(distribution_details_df, config).collect()

        # Assert: verify that the warning row keeps the key fields and stores detailed values inside metadata.
        assert len(rows) == 1
        row = rows[0]
        metadata = json.loads(row["metadata"])
        assert row["check_name"] == "sales_distribution_outlier_check"
        assert row["message"] == "example message"
        assert metadata["median_sales"] == 10.0
        assert metadata["isolated_extreme_weeks"] == 1

    def test_warns_for_median_band_outliers_and_isolated_extremes(self, spark_session: SparkSession):
        # Arrange: create a series with one very high week and one very low week relative to the median.
        config = _sales_validation_config()
        values = ([10.0] * 101) + [35.0, 0.5, 10.0]
        baseline_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        recent_sales_df = select_recent_sales_window(filter_sales_baseline_dataset(baseline_df), config=config)

        # Act: run the distribution-outlier checks on the recent sales window.
        rows = check_sales_distribution_outliers(recent_sales_df, config=config).collect()

        # Assert: verify that the function returns one formatted warning row whose metadata captures both outlier rules.
        assert len(rows) == 1
        row = rows[0]
        metadata = json.loads(row["metadata"])
        assert row["check_name"] == "sales_distribution_outlier_check"
        assert row["severity"] == "MEDIUM"
        assert metadata["median_sales"] == 10.0
        assert metadata["median_outlier_weeks"] == 2
        assert metadata["isolated_extreme_weeks"] == 2
        assert metadata["threshold_range"] == [1 / config.sales_outlier_multiplier, config.sales_outlier_multiplier]

    def test_returns_empty_for_a_stable_sales_series(self, spark_session: SparkSession):
        # Arrange: create a series with consistent weekly sales and no obvious outliers.
        config = _sales_validation_config()
        values = [10.0] * 104
        baseline_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        recent_sales_df = select_recent_sales_window(filter_sales_baseline_dataset(baseline_df), config=config)
        expected = spark_session.createDataFrame([], schema=SALES_ALL_CHECKS_SCHEMA)

        # Act: run the distribution-outlier checks on the stable series.
        actual = check_sales_distribution_outliers(recent_sales_df, config=config)

        # Assert: verify that no formatted warning rows are emitted for a stable series.
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestCheckSalesNearZeroInPeriod:

    def test_returns_warning_for_near_zero_week_inside_supplied_period(self, spark_session: SparkSession):
        # Arrange: create one near-zero week inside the supplied period and another week outside it.
        config = _sales_validation_config()
        sales_df = spark_session.createDataFrame(
            _sales_rows(([20.0] * 9) + [0.005] + ([20.0] * 10)),
            schema=SALES_BASELINE_SCHEMA,
        )
        filtered_sales_df = filter_sales_baseline_dataset(sales_df)
        periods_df = spark_session.createDataFrame([
            (
                "BRANDA",
                "CATA",
                _BASE_DATE + timedelta(weeks=8),
                _BASE_DATE + timedelta(weeks=12),
                "custom_period",
            ),
        ], schema="""
            unique_brand_name string,
            super_category_name string,
            period_start_dt date,
            period_end_dt date,
            period_type string
        """)

        # Act: run the shared period helper against the supplied custom window.
        rows = _check_sales_near_zero_in_period(
            filtered_sales_df,
            periods_df,
            config=config,
            severity="HIGH",
        ).collect()

        # Assert: verify that the in-period near-zero week is returned with the supplied period label and severity.
        assert len(rows) == 1
        row = rows[0]
        assert row["period_type"] == "custom_period"
        assert row["near_zero_weeks"] == 1
        assert row["near_zero_week_dates"][0]["week"] == str(_BASE_DATE + timedelta(weeks=9))
        assert row["severity"] == "HIGH"

    def test_returns_empty_when_no_near_zero_weeks_fall_inside_period(self, spark_session: SparkSession):
        # Arrange: create stable weekly sales values across a supplied period window.
        config = _sales_validation_config()
        sales_df = spark_session.createDataFrame(
            _sales_rows([20.0] * 20),
            schema=SALES_BASELINE_SCHEMA,
        )
        filtered_sales_df = filter_sales_baseline_dataset(sales_df)
        periods_df = spark_session.createDataFrame([
            (
                "BRANDA",
                "CATA",
                _BASE_DATE + timedelta(weeks=5),
                _BASE_DATE + timedelta(weeks=12),
                "custom_period",
            ),
        ], schema="""
            unique_brand_name string,
            super_category_name string,
            period_start_dt date,
            period_end_dt date,
            period_type string
        """)
        expected = spark_session.createDataFrame([], schema=SALES_PERIOD_CHECK_SCHEMA)

        # Act: run the shared period helper for a period that contains no near-zero sales weeks.
        actual = _check_sales_near_zero_in_period(
            filtered_sales_df,
            periods_df,
            config=config,
            severity="HIGH",
        )

        # Assert: verify that the helper returns no warning rows.
        assert_df_equality(actual, expected, ignore_nullable=True)


class TestCampaignPeriodChecks:

    def test_during_run_only_counts_near_zero_weeks_inside_campaign_dates(self, spark_session: SparkSession):
        # Arrange: place one near-zero week outside the campaign window and another inside it.
        config = _sales_validation_config()
        values = ([20.0] * 80) + [0.005] + ([20.0] * 9) + [0.005] + ([20.0] * 13)
        sales_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        campaign_df = spark_session.createDataFrame([
            _campaign_row(start_index=88, end_index=92, post_index=96),
        ], schema=SALES_CAMPAIGN_SCHEMA)

        # Act: run the During-period near-zero check using the campaign window from campaign selection.
        rows = check_during_run_near_zero_sales(filter_sales_baseline_dataset(sales_df), campaign_df, config=config).collect()

        # Assert: verify that only the in-campaign near-zero week is reported.
        assert len(rows) == 1
        row = rows[0]
        metadata = json.loads(row["metadata"])
        assert row["check_name"] == "during_period_near_zero_check"
        assert metadata["period_type"] == "during_campaign"
        assert metadata["near_zero_weeks"] == 1
        assert metadata["near_zero_week_dates"][0]["week"] == str(_BASE_DATE + timedelta(weeks=90))
        assert row["severity"] == "HIGH"

    def test_post_run_uses_campaign_start_from_campaign_selection(self, spark_session: SparkSession):
        # Arrange: create one near-zero week before campaign start and one inside the post-validation window.
        config = _sales_validation_config()
        values = ([20.0] * 87) + [0.005] + ([20.0] * 6) + [0.005] + ([20.0] * 10)
        sales_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        campaign_df = spark_session.createDataFrame([
            _campaign_row(start_index=88, end_index=92, post_index=96),
        ], schema=SALES_CAMPAIGN_SCHEMA)

        # Act: run the Post-period near-zero check without any during_start_date override.
        rows = check_post_run_near_zero_sales(
            filter_sales_baseline_dataset(sales_df),
            campaign_df,
            config=config,
        ).collect()

        # Assert: verify that validation starts from min_campaign_start_dt and ignores the pre-campaign near-zero week.
        assert len(rows) == 1
        row = rows[0]
        metadata = json.loads(row["metadata"])
        assert row["check_name"] == "post_period_near_zero_check"
        assert metadata["period_type"] == "during_and_post_campaign"
        assert metadata["near_zero_weeks"] == 1
        assert metadata["near_zero_week_dates"][0]["week"] == str(_BASE_DATE + timedelta(weeks=94))
        assert row["severity"] == "HIGH"

    def test_post_run_falls_back_to_campaign_end_when_post_end_column_is_missing(self, spark_session: SparkSession):
        # Arrange: build campaign selection data without max_post_campaign_dt and place one near-zero week inside the campaign window.
        config = _sales_validation_config()
        values = ([20.0] * 90) + [0.005] + ([20.0] * 13)
        sales_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        campaign_df = spark_session.createDataFrame(
            [_campaign_row_without_post(start_index=88, end_index=92)],
            schema=_CAMPAIGN_SELECTION_WITHOUT_POST_COLUMNS,
        )

        # Act: run the Post-period near-zero check using the fallback end-date logic.
        rows = check_post_run_near_zero_sales(
            filter_sales_baseline_dataset(sales_df),
            campaign_df,
            config=config,
        ).collect()

        # Assert: verify that the check still works and treats max_campaign_end_dt as the period end.
        assert len(rows) == 1
        row = rows[0]
        metadata = json.loads(row["metadata"])
        assert metadata["period_end_dt"] == str(_BASE_DATE + timedelta(weeks=92))
        assert metadata["near_zero_weeks"] == 1
        assert row["severity"] == "HIGH"


class TestRunAllSalesChecks:

    def test_includes_post_period_check_when_campaign_duration_matches_post_label(self, spark_session: SparkSession):
        # Arrange: build a Post run where one near-zero week falls inside the combined during-plus-post window.
        config = _sales_validation_config()
        values = ([20.0] * 93) + [0.005] + ([20.0] * 10)
        baseline_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        campaign_df = spark_session.createDataFrame([
            _campaign_row(start_index=88, end_index=92, post_index=96),
        ], schema=SALES_CAMPAIGN_SCHEMA)

        # Act: run all checks for a Post campaign duration.
        actual = run_all_sales_checks(
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
            campaign_duration=CampaignDurations.CAMPAIGN_DURATION_POST,
            config=config,
        )

        # Assert: verify that the unified output includes the Post-period-specific check.
        assert set(actual.columns) == {field.name for field in SALES_ALL_CHECKS_SCHEMA.fields}
        assert "post_period_near_zero_check" in {
            row["check_name"] for row in actual.select("check_name").distinct().collect()
        }

    def test_includes_during_period_check_when_campaign_duration_is_during(self, spark_session: SparkSession):
        # Arrange: build a During run with one near-zero week inside the campaign dates.
        config = _sales_validation_config()
        values = ([20.0] * 90) + [0.005] + ([20.0] * 13)
        baseline_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        campaign_df = spark_session.createDataFrame([
            _campaign_row(start_index=88, end_index=92, post_index=96),
        ], schema=SALES_CAMPAIGN_SCHEMA)

        # Act: run all checks for a During campaign duration.
        actual = run_all_sales_checks(
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
            campaign_duration=CampaignDurations.CAMPAIGN_DURATION_DURING,
            config=config,
        )

        # Assert: verify that the During-period-specific check is included in the unified output.
        assert "during_period_near_zero_check" in {
            row["check_name"] for row in actual.select("check_name").distinct().collect()
        }

    def test_omits_period_specific_checks_when_campaign_duration_is_missing(self, spark_session: SparkSession):
        # Arrange: build input data that would only trigger the period-specific checks if a campaign duration were supplied.
        config = _sales_validation_config()
        values = ([20.0] * 90) + [0.005] + ([20.0] * 13)
        baseline_df = spark_session.createDataFrame(_sales_rows(values), schema=SALES_BASELINE_SCHEMA)
        campaign_df = spark_session.createDataFrame([
            _campaign_row(start_index=88, end_index=92, post_index=96),
        ], schema=SALES_CAMPAIGN_SCHEMA)

        # Act: run all checks without a campaign duration label.
        actual = run_all_sales_checks(
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
            campaign_duration=None,
            config=config,
        )

        # Assert: verify that no During or Post-specific checks are added to the output.
        assert {
            row["check_name"] for row in actual.select("check_name").distinct().collect()
        }.isdisjoint({"during_period_near_zero_check", "post_period_near_zero_check"})


class TestPublishSalesValidationMetrics:

    @mock.patch(
        "spark_pipeline.metrics.baseline_validation_metrics.sales_validation_metrics.MetricsPublisher"
    )
    def test_publishes_cluster_metadata_and_unique_name(
        self,
        mock_publisher_class,
        spark_session: SparkSession,
    ):
        # Arrange: build campaign selection and baseline inputs directly as DataFrames for the current publish API.
        mock_publisher = MagicMock()
        mock_publisher_class.return_value = mock_publisher
        baseline_df = spark_session.createDataFrame(
            _sales_rows(([20.0] * 20) + [0.005] + ([20.0] * 83)),
            schema=SALES_BASELINE_SCHEMA,
        )
        campaign_df = spark_session.createDataFrame([
            _campaign_row(start_index=88, end_index=92, post_index=96),
        ], schema=SALES_CAMPAIGN_SCHEMA)

        # Act: publish validation warnings from the DataFrame inputs.
        publish_sales_validation_metrics(
            metrics_topic_arn="arn:aws:sns:eu-west-1:123456789:test",
            correlation_id="corr-sales-001",
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
        )

        # Assert: verify that at least one event is published and that cluster metadata is included in the payload.
        assert mock_publisher.publish_event.call_count >= 1
        event = mock_publisher.publish_event.call_args_list[0][1]["event"]
        metadata = json.loads(event.metadata)
        assert metadata["cluster_num"] == "C1"
        assert metadata["correlation_id"] == "corr-sales-001"
        assert event.channel_name == _SALES_CONFIG["marketing_channel_name"]
        assert "C1" in event.name
        assert event.value == "1"

    @mock.patch(
        "spark_pipeline.metrics.baseline_validation_metrics.sales_validation_metrics.MetricsPublisher"
    )
    def test_does_not_publish_when_no_sales_warnings_are_found(
        self,
        mock_publisher_class,
        spark_session: SparkSession,
    ):
        # Arrange: build stable sales data directly as DataFrames so the publish function should find no warnings.
        mock_publisher = MagicMock()
        mock_publisher_class.return_value = mock_publisher
        baseline_df = spark_session.createDataFrame(
            _sales_rows([20.0] * 104),
            schema=SALES_BASELINE_SCHEMA,
        )
        campaign_df = spark_session.createDataFrame([
            _campaign_row(start_index=88, end_index=92, post_index=96),
        ], schema=SALES_CAMPAIGN_SCHEMA)

        # Act: publish validation warnings from the warning-free DataFrame inputs.
        publish_sales_validation_metrics(
            metrics_topic_arn="arn:aws:sns:eu-west-1:123456789:test",
            correlation_id="corr-sales-002",
            campaign_selection_df=campaign_df,
            baseline_modelling_dataset_df=baseline_df,
        )

        # Assert: verify that no publish call is made because the input produces no warnings.
        assert mock_publisher.publish_event.call_count == 0
