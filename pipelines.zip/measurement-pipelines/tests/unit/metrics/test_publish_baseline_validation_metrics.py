import json
from datetime import date, timedelta
from decimal import Decimal
from unittest.mock import MagicMock, patch

import pytest
from pyspark.sql import Row, SparkSession

from spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics import (
    check_feature_sense_checks,
    check_no_nulls_after_imputation,
    check_pre_imputation_nulls_in_non_marketing_features,
    check_non_zero_during_campaign_period,
    check_zero_null_week_count,
    check_spike_outliers,
)
from spark_pipeline.schemas.baseline_modelling_dataset import BaselineModellingDataset
from spark_pipeline.schemas.baseline_processed_data.baseline_processed_data import ProcessedData
from spark_pipeline.schemas.campaign_selection import CampaignSelection
from spark_pipeline.utils.baseline_events import BaselineValidationMetrics


@pytest.fixture(scope="module")
def processed_schema():
    return ProcessedData.validation_metrics_input_schema


# ---- pre-imputation null check tests ----

def test_pre_imputation_no_nulls(spark_session: SparkSession, processed_schema):
    """No event is published when non-marketing features are clean before imputation."""
    data = [
        Row(
            week_start_dt=date(2023, 1, 1),
            metric_value=Decimal("99.00"),
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="SALES",
            marketing_channel_name="SALES",
            marketing_sub_channel_name="TOTAL",
            metric_name="TOTAL_SALES",
        )
    ]
    df = spark_session.createDataFrame(data, processed_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher

        check_pre_imputation_nulls_in_non_marketing_features(df, "corr-pre-1", "arn:aws:sns:eu-west-1:123:dummy")

        mock_publisher_cls.assert_not_called()
        mock_publisher.publish_event.assert_not_called()


def test_pre_imputation_nulls_present(spark_session: SparkSession, processed_schema):
    """A single HIGH severity event is published when a non-marketing feature has nulls."""
    data = [
        Row(
            week_start_dt=date(2023, 1, 1),
            metric_value=None,  # unexpected null in SALES feature
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="SALES",
            marketing_channel_name="SALES",
            marketing_sub_channel_name="TOTAL",
            metric_name="TOTAL_SALES",
        ),
        Row(
            week_start_dt=date(2023, 1, 8),
            metric_value=Decimal("50.00"),
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="SALES",
            marketing_channel_name="SALES",
            marketing_sub_channel_name="TOTAL",
            metric_name="TOTAL_SALES",
        ),
    ]
    df = spark_session.createDataFrame(data, processed_schema)
    topic_arn = "arn:aws:sns:eu-west-1:123:dummy"

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher

        check_pre_imputation_nulls_in_non_marketing_features(df, "corr-pre-2", topic_arn)

        mock_publisher_cls.assert_called_once_with(topic_arn=topic_arn)
        mock_publisher.publish_event.assert_called_once()
        call_kwargs = mock_publisher.publish_event.call_args
        event = call_kwargs.kwargs["event"] if call_kwargs.kwargs else call_kwargs[1]["event"]

        assert isinstance(event, BaselineValidationMetrics)
        assert event.severity == "HIGH"
        assert event.name == "pre_imputation_null_check_non_marketing_features"
        assert event.type == "null_check"
        assert event.correlation_id == "corr-pre-2"
        metadata = json.loads(event.metadata)
        pattern = metadata["affected_patterns"][0]
        assert pattern["marketing_type_name"] == "SALES"
        assert pattern["null_counts"]["metric_value"] == 1


def test_pre_imputation_skips_marketing_features(spark_session: SparkSession, processed_schema):
    """No event is published when nulls only exist in marketing features (OFFSITE etc.)."""
    data = [
        Row(
            week_start_dt=date(2023, 1, 1),
            metric_value=None,  # null in OFFSITE — expected, should be ignored
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="OFFSITE",
            marketing_channel_name="META",
            marketing_sub_channel_name="TOTAL",
            metric_name="impressions",
        )
    ]
    df = spark_session.createDataFrame(data, processed_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher

        check_pre_imputation_nulls_in_non_marketing_features(df, "corr-pre-3", "arn:aws:sns:eu-west-1:123:dummy")

        mock_publisher_cls.assert_not_called()
        mock_publisher.publish_event.assert_not_called()


# ---- post-imputation null check tests ----

def test_check_no_nulls_after_imputation_no_nulls(spark_session: SparkSession, processed_schema):
    """No event is published when the DataFrame has no nulls after imputation."""
    data = [
        Row(
            week_start_dt=date(2023, 1, 1),
            metric_value=Decimal("100.00"),
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="TYPE1",
            marketing_channel_name="CHANNELA",
            marketing_sub_channel_name="SUBA",
            metric_name="SALES",
        )
    ]
    df = spark_session.createDataFrame(data, processed_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher

        check_no_nulls_after_imputation(df, "corr-123", "arn:aws:sns:eu-west-1:123:dummy")

        mock_publisher_cls.assert_not_called()
        mock_publisher.publish_event.assert_not_called()


def test_check_no_nulls_after_imputation_nulls_present(spark_session: SparkSession, processed_schema):
    """A single HIGH severity event is published when nulls are found after imputation."""
    data = [
        Row(
            week_start_dt=date(2023, 1, 1),
            metric_value=None,  # intentional null — imputation missed this
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="TYPE1",
            marketing_channel_name="CHANNELA",
            marketing_sub_channel_name="SUBA",
            metric_name="SALES",
        ),
        Row(
            week_start_dt=date(2023, 1, 8),
            metric_value=Decimal("50.00"),
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="TYPE1",
            marketing_channel_name="CHANNELA",
            marketing_sub_channel_name="SUBA",
            metric_name="SALES",
        ),
    ]
    df = spark_session.createDataFrame(data, processed_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher
        topic_arn = "arn:aws:sns:eu-west-1:123:dummy"

        check_no_nulls_after_imputation(df, "corr-456", topic_arn)

        mock_publisher_cls.assert_called_once_with(topic_arn=topic_arn)
        mock_publisher.publish_event.assert_called_once()
        call_kwargs = mock_publisher.publish_event.call_args
        event = call_kwargs.kwargs["event"] if call_kwargs.kwargs else call_kwargs[1]["event"]

        assert isinstance(event, BaselineValidationMetrics)
        assert event.severity == "HIGH"
        assert event.name == "post_imputation_null_check"
        assert event.type == "null_check"
        assert event.correlation_id == "corr-456"
        metadata = json.loads(event.metadata)
        assert "metric_value" in metadata["null_columns"]
        assert metadata["null_columns"]["metric_value"] == 1


def test_check_no_nulls_after_imputation_empty_dataframe(spark_session: SparkSession, processed_schema):
    """No event is published and no error is raised when the DataFrame is empty."""
    df = spark_session.createDataFrame([], processed_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher

        check_no_nulls_after_imputation(df, "corr-empty", "arn:aws:sns:eu-west-1:123:dummy")

        mock_publisher_cls.assert_not_called()
        mock_publisher.publish_event.assert_not_called()


# ---- feature sense check tests ----

_TOPIC = "arn:aws:sns:eu-west-1:123:dummy"
_BASE_DATE = date(2022, 1, 3)  # a Monday


def _week_rows(metric_name, n_weeks, metric_value=1.0):
    """Build n_weeks rows with distinct week_start_dt values for a given metric."""
    return [
        Row(
            week_start_dt=_BASE_DATE + timedelta(weeks=i),
            metric_value=Decimal(str(metric_value)),
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="EXTERNAL",
            marketing_channel_name="EXTERNAL",
            marketing_sub_channel_name="EXTERNAL",
            metric_name=metric_name,
        )
        for i in range(n_weeks)
    ]


def test_sense_checks_all_pass(spark_session: SparkSession, processed_schema):
    """No event is published when weather/economic metrics have 104 weeks and discounts are in range."""
    data = (
        _week_rows("AVERAGE_TEMPERATURE", 104)
        + _week_rows("CPI_INDEX", 104)
        + _week_rows("DISCOUNT_PERC", 104, metric_value=50.0)
    )
    df = spark_session.createDataFrame(data, processed_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher

        check_feature_sense_checks(df, "corr-sense-1", _TOPIC)

        mock_publisher_cls.assert_not_called()
        mock_publisher.publish_event.assert_not_called()


def test_sense_checks_weather_insufficient_weeks(spark_session: SparkSession, processed_schema):
    """A week_coverage event is published when a weather metric has fewer than 104 weeks."""
    data = _week_rows("AVERAGE_TEMPERATURE", 50)
    df = spark_session.createDataFrame(data, processed_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher

        check_feature_sense_checks(df, "corr-sense-2", _TOPIC)

        mock_publisher_cls.assert_called_once_with(topic_arn=_TOPIC)
        mock_publisher.publish_event.assert_called_once()
        event = mock_publisher.publish_event.call_args.kwargs["event"]
        assert event.name == "feature_sense_check"
        assert event.type == "week_coverage"
        assert event.severity == "HIGH"
        assert event.value == "50"
        assert json.loads(event.metadata)["metric_name"] == "AVERAGE_TEMPERATURE"


def test_sense_checks_economic_insufficient_weeks(spark_session: SparkSession, processed_schema):
    """A week_coverage event is published when an economic metric has fewer than 104 weeks."""
    data = _week_rows("UNEMPLOYEMENT_INDEX", 30)
    df = spark_session.createDataFrame(data, processed_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher

        check_feature_sense_checks(df, "corr-sense-3", _TOPIC)

        mock_publisher_cls.assert_called_once_with(topic_arn=_TOPIC)
        mock_publisher.publish_event.assert_called_once()
        event = mock_publisher.publish_event.call_args.kwargs["event"]
        assert event.type == "week_coverage"
        assert event.value == "30"
        assert json.loads(event.metadata)["metric_name"] == "UNEMPLOYEMENT_INDEX"


def test_sense_checks_discount_out_of_range(spark_session: SparkSession, processed_schema):
    """A range_check event is published when a discount metric has values outside [0, 100]."""
    data = [
        Row(
            week_start_dt=_BASE_DATE,
            metric_value=Decimal("150.0"),  # out of range
            super_category_name="CATA",
            unique_brand_name="BRANDX",
            cluster_num="C1",
            marketing_type_name="PROMOTIONAL DISCOUNT",
            marketing_channel_name="PROMO",
            marketing_sub_channel_name="PROMO",
            metric_name="DISCOUNT_PERC",
        )
    ]
    df = spark_session.createDataFrame(data, processed_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher

        check_feature_sense_checks(df, "corr-sense-4", _TOPIC)

        mock_publisher_cls.assert_called_once_with(topic_arn=_TOPIC)
        mock_publisher.publish_event.assert_called_once()
        event = mock_publisher.publish_event.call_args.kwargs["event"]
        assert event.type == "range_check"
        assert event.value == "1"
        assert json.loads(event.metadata)["metric_name"] == "DISCOUNT_PERC"


def test_sense_checks_non_targeted_metrics_ignored(spark_session: SparkSession, processed_schema):
    """Metrics not in any sense-check set are silently ignored even if they have few weeks."""
    data = _week_rows("TOTAL_SALES_VOLUME", 5)  # not in any sense-check constant
    df = spark_session.createDataFrame(data, processed_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = MagicMock()
        mock_publisher_cls.return_value = mock_publisher

        check_feature_sense_checks(df, "corr-sense-5", _TOPIC)

        mock_publisher_cls.assert_not_called()
        mock_publisher.publish_event.assert_not_called()


# ---- ADS schema used by checks 4, 5, 6 ----

@pytest.fixture(scope="module")
def ads_schema():
    return BaselineModellingDataset.baseline_modelling_validation_ads_schema


@pytest.fixture(scope="module")
def campaign_schema():
    return CampaignSelection.campaign_selection_dates_schema


# ---- Check 4: non-zero during campaign period ----

def test_check_non_zero_during_campaign_period_no_warning(spark_session: SparkSession, ads_schema, campaign_schema):
    """No event published when all features have non-zero values during the campaign period."""
    ads_data = [Row(
        week_start_dt=date(2023, 6, 5),
        unique_brand_name="BRANDX", super_category_name="CATA", cluster_num="1",
        marketing_type_name="OFFSITE", marketing_channel_name="META",
        variable_cd="cat_brx_1_off_met_tot_imp", metric_value=1000.0,
    )]
    campaign_data = [Row(
        unique_brand_name="BRANDX", super_category_name="CATA",
        min_campaign_start_dt=date(2023, 6, 1), max_campaign_end_dt=date(2023, 6, 30),
    )]
    ads_df = spark_session.createDataFrame(ads_data, ads_schema)
    campaign_df = spark_session.createDataFrame(campaign_data, campaign_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_cls:
        check_non_zero_during_campaign_period(ads_df, campaign_df, "corr-4-ok", _TOPIC)
        mock_cls.assert_not_called()


def test_check_non_zero_during_campaign_period_raises_warning(spark_session: SparkSession, ads_schema, campaign_schema):
    """HIGH event published when a non-excluded feature is all-zero during campaign weeks."""
    ads_data = [Row(
        week_start_dt=date(2023, 6, 5),
        unique_brand_name="BRANDX", super_category_name="CATA", cluster_num="1",
        marketing_type_name="OFFSITE", marketing_channel_name="META",
        variable_cd="cat_brx_1_off_met_tot_imp", metric_value=0.0,
    )]
    campaign_data = [Row(
        unique_brand_name="BRANDX", super_category_name="CATA",
        min_campaign_start_dt=date(2023, 6, 1), max_campaign_end_dt=date(2023, 6, 30),
    )]
    ads_df = spark_session.createDataFrame(ads_data, ads_schema)
    campaign_df = spark_session.createDataFrame(campaign_data, campaign_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_cls:
        mock_publisher = MagicMock()
        mock_cls.return_value = mock_publisher

        check_non_zero_during_campaign_period(ads_df, campaign_df, "corr-4-fail", _TOPIC)

        mock_cls.assert_called_once_with(topic_arn=_TOPIC)
        mock_publisher.publish_event.assert_called_once()
        event = mock_publisher.publish_event.call_args.kwargs["event"]
        assert event.name == "ads_non_zero_campaign_period_check|META|cat_brx_1_off_met_tot_imp"
        assert event.severity == "HIGH"
        assert event.type == "zero_check"
        assert event.channel_name == "META"
        metadata = json.loads(event.metadata)
        assert metadata["variable_cd"] == "cat_brx_1_off_met_tot_imp"
        assert metadata["campaign_weeks_checked"] == 1


def test_check_non_zero_during_campaign_period_excludes_discount(spark_session: SparkSession, ads_schema, campaign_schema):
    """No event published when zero values are in excluded PROMOTIONAL DISCOUNT features."""
    ads_data = [Row(
        week_start_dt=date(2023, 6, 5),
        unique_brand_name="BRANDX", super_category_name="CATA", cluster_num="1",
        marketing_type_name="PROMOTIONAL DISCOUNT", marketing_channel_name="DISCOUNT",
        variable_cd="cat_brx_1_pro_dis_tot_dsc", metric_value=0.0,
    )]
    campaign_data = [Row(
        unique_brand_name="BRANDX", super_category_name="CATA",
        min_campaign_start_dt=date(2023, 6, 1), max_campaign_end_dt=date(2023, 6, 30),
    )]
    ads_df = spark_session.createDataFrame(ads_data, ads_schema)
    campaign_df = spark_session.createDataFrame(campaign_data, campaign_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_cls:
        check_non_zero_during_campaign_period(ads_df, campaign_df, "corr-4-excl", _TOPIC)
        mock_cls.assert_not_called()


# ---- Check 5: zero/null week count ----

def test_check_zero_null_week_count_no_warning(spark_session: SparkSession, ads_schema):
    """No event published when all features have <= 50 zero/null weeks."""
    ads_data = [
        Row(
            week_start_dt=date(2023, 1, 1) + timedelta(weeks=i),
            unique_brand_name="BRANDX", super_category_name="CATA", cluster_num="1",
            marketing_type_name="OFFSITE", marketing_channel_name="META",
            variable_cd="cat_brx_1_off_met_tot_imp",
            metric_value=0.0 if i < 10 else 100.0,
        )
        for i in range(52)
    ]
    ads_df = spark_session.createDataFrame(ads_data, ads_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_cls:
        check_zero_null_week_count(ads_df, "corr-5-ok", _TOPIC)
        mock_cls.assert_not_called()


def test_check_zero_null_week_count_raises_warning(spark_session: SparkSession, ads_schema):
    """HIGH event published when a feature has more than 50 zero/null weeks."""
    ads_data = [
        Row(
            week_start_dt=date(2023, 1, 1) + timedelta(weeks=i),
            unique_brand_name="BRANDX", super_category_name="CATA", cluster_num="1",
            marketing_type_name="OFFSITE", marketing_channel_name="META",
            variable_cd="cat_brx_1_off_met_tot_imp",
            metric_value=0.0,
        )
        for i in range(104)
    ]
    ads_df = spark_session.createDataFrame(ads_data, ads_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_cls:
        mock_publisher = MagicMock()
        mock_cls.return_value = mock_publisher

        check_zero_null_week_count(ads_df, "corr-5-fail", _TOPIC)

        mock_cls.assert_called_once_with(topic_arn=_TOPIC)
        mock_publisher.publish_event.assert_called_once()
        event = mock_publisher.publish_event.call_args.kwargs["event"]
        assert event.name == "ads_zero_null_week_count_check|META|cat_brx_1_off_met_tot_imp"
        assert event.severity == "HIGH"
        assert event.channel_name == "META"
        metadata = json.loads(event.metadata)
        assert metadata["variable_cd"] == "cat_brx_1_off_met_tot_imp"
        assert metadata["zero_null_weeks"] == 104
        assert metadata["threshold"] > 0


# ---- Check 6: spike/outlier detection ----

def test_check_spike_outliers_no_warning(spark_session: SparkSession, ads_schema):
    """No event published when all values are within 3x of median."""
    ads_data = [
        Row(
            week_start_dt=date(2023, 1, 1) + timedelta(weeks=i),
            unique_brand_name="BRANDX", super_category_name="CATA", cluster_num="1",
            marketing_type_name="OFFSITE", marketing_channel_name="META",
            variable_cd="cat_brx_1_off_met_tot_imp",
            metric_value=100.0,
        )
        for i in range(10)
    ]
    ads_df = spark_session.createDataFrame(ads_data, ads_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_cls:
        check_spike_outliers(ads_df, "corr-6-ok", _TOPIC)
        mock_cls.assert_not_called()


def test_check_spike_outliers_raises_warning(spark_session: SparkSession, ads_schema):
    """HIGH event published when a single week is >= 3x above the median."""
    base_rows = [
        Row(
            week_start_dt=date(2023, 1, 1) + timedelta(weeks=i),
            unique_brand_name="BRANDX", super_category_name="CATA", cluster_num="1",
            marketing_type_name="OFFSITE", marketing_channel_name="META",
            variable_cd="cat_brx_1_off_met_tot_imp",
            metric_value=100.0,
        )
        for i in range(9)
    ]
    spike_row = Row(
        week_start_dt=date(2023, 3, 13),
        unique_brand_name="BRANDX", super_category_name="CATA", cluster_num="1",
        marketing_type_name="OFFSITE", marketing_channel_name="META",
        variable_cd="cat_brx_1_off_met_tot_imp",
        metric_value=500.0,  # 5x the median of 100
    )
    ads_df = spark_session.createDataFrame(base_rows + [spike_row], ads_schema)

    with patch("spark_pipeline.metrics.baseline_validation_metrics.baseline_validation_metrics.MetricsPublisher") as mock_cls:
        mock_publisher = MagicMock()
        mock_cls.return_value = mock_publisher

        check_spike_outliers(ads_df, "corr-6-fail", _TOPIC)

        mock_cls.assert_called_once_with(topic_arn=_TOPIC)
        mock_publisher.publish_event.assert_called_once()
        event = mock_publisher.publish_event.call_args.kwargs["event"]
        assert event.name == "ads_spike_outlier_check|META|cat_brx_1_off_met_tot_imp"
        assert event.severity == "HIGH"
        assert event.type == "spike_check"
        assert event.channel_name == "META"
        metadata = json.loads(event.metadata)
        assert metadata["variable_cd"] == "cat_brx_1_off_met_tot_imp"
        assert metadata["spike_weeks"] == 1
        assert "spike_ratio" in metadata
