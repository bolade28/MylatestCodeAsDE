from unittest import mock
from unittest.mock import Mock

from spark_pipeline.metrics.publish_mta_metrics import entrypoint, publish_mta_metrics


@mock.patch("spark_pipeline.metrics.publish_mta_metrics.SlackMessenger")
@mock.patch("spark_pipeline.metrics.publish_mta_metrics.publish_reach_engagement_detail_metrics")
@mock.patch("spark_pipeline.metrics.publish_mta_metrics.publish_campaign_reporting_metrics")
def test_publish_mta_metrics_orchestrates_all_publishers(
    mock_campaign_reporting,
    mock_reach_detail,
    mock_slack_messenger,
):
    spark = Mock()
    measurement_campaign_reporting_df = Mock()
    reach_engagement_detail_df = Mock()
    measurement_campaign_reporting_selected_df = Mock()
    reach_engagement_selected_df = Mock()
    measurement_campaign_reporting_df.select.return_value = measurement_campaign_reporting_selected_df
    reach_engagement_detail_df.select.return_value = reach_engagement_selected_df
    spark.read.parquet.side_effect = [
        measurement_campaign_reporting_df,
        reach_engagement_detail_df,
    ]
    mock_campaign_reporting.return_value = 10
    mock_reach_detail.return_value = 30

    publish_mta_metrics(
        spark=spark,
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        reach_engagement_detail_path="s3://bucket/reach_engagement_reporting",
        correlation_id="corr-123",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
        run_date="2026-04-29",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    mock_campaign_reporting.assert_called_once_with(
        measurement_campaign_reporting_df=measurement_campaign_reporting_selected_df,
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )
    mock_reach_detail.assert_called_once_with(
        reach_engagement_detail_df=reach_engagement_selected_df,
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-123",
    )

    slack_instance = mock_slack_messenger.return_value
    slack_instance.send_message.assert_called_once()
    payload = slack_instance.send_message.call_args[1]["data"]
    assert payload["Total rows generated for measurement campaign reporting"] == 10
    assert payload["Total rows generated for measurement booking reach engagement detail"] == 30


@mock.patch("spark_pipeline.metrics.publish_mta_metrics.publish_mta_metrics")
def test_entrypoint_parses_new_reach_engagement_arguments(
    mock_publish_mta_metrics,
):
    spark = Mock()
    args = [
        "--measurement-campaign-reporting-path",
        "s3://bucket/measurement_campaign_reporting",
        "--reach-engagement-detail-path",
        "s3://bucket/reach_engagement_reporting",
        "--metrics-topic-arn",
        "arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        "--correlation-id",
        "corr-123",
        "--slack-topic-arn",
        "arn:aws:sns:eu-west-1:123456789012:slack-topic",
        "--run-date",
        "2026-04-29",
    ]

    entrypoint(spark=spark, command_line_args=args)

    mock_publish_mta_metrics.assert_called_once_with(
        spark=spark,
        measurement_campaign_reporting_path="s3://bucket/measurement_campaign_reporting",
        reach_engagement_detail_path="s3://bucket/reach_engagement_reporting",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
        correlation_id="corr-123",
        slack_topic_arn="arn:aws:sns:eu-west-1:123456789012:slack-topic",
        run_date="2026-04-29",
    )
