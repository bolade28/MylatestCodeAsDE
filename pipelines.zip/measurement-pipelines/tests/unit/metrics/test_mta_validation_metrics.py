from unittest import mock
import json
import pytest

from datetime import datetime
from chispa import assert_df_equality
from pyspark.sql import Row
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    DoubleType,
    TimestampType,
)
from spark_pipeline.common.variables import (
    ChannelSalesRatioConfig,
    ConversionRateThresholdsConfig,
    MtaValidationConfig,
    RecalibrationFactorsConfig,
    Severity,
)
import spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics
from spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics import (
    evaluate_channel_ratio_thresholds,
    get_brand_channel_incremental_totals,
    get_channel_incremental_iroas,
    get_channel_unit_ratios,
)
from spark_pipeline.schemas.mta_attribution_model import AttributionModel
from spark_pipeline.schemas.baseline_attribution_integration.unified_baseline_attribution_integration import (
    UnifiedBaselineAttributionIntegration,
)
from spark_pipeline.schemas.validation_metrics_schema import ValidationMetrics
from spark_pipeline.utils.mta_events import MTAValidationMetricSchema


TOPIC_ARN = "arn:aws:sns:eu-west-1:123456789012:test-topic"
CORR_ID = "test-corr-id"
PATCH_TARGET = "spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher"
ROAS_SCHEMA = ValidationMetrics.ROAS_VALIDATION_SCHEMA
INCREMENTAL_SALES_IROAS_SCHEMA = ValidationMetrics.INCREMENTAL_SALES_IROAS_SCHEMA


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_conversion_rate_thresholds_no_breach_when_below_thresholds(
    mock_publisher_class,
    spark_session,
):
    """
    Test that no metrics are published when all conversion rates are below thresholds.

    Creates test data with conversion rates BELOW the thresholds for offsite (8.5% < 10%),
    onsite (9.0% < 10%), and instore variants (25%, 28% < 30%). Verifies that MetricsPublisher
    is not instantiated when no breaches occur.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("conversion_rate", DoubleType(), True),
        StructField("channel_name", StringType(), True),
        StructField("subchannel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            marketing_type="offsite",
            conversion_rate=8.5,
            channel_name="Meta",
            subchannel_name="Facebook",
            load_ts=datetime(2023, 1, 1),
        ),
        Row(
            campaign_id="campaign-2",
            booking_id="booking-2",
            marketing_type="onsite",
            conversion_rate=9.0,
            channel_name="Email",
            subchannel_name="Newsletter",
            load_ts=datetime(2023, 1, 2),
        ),
        Row(
            campaign_id="campaign-3",
            booking_id="booking-3",
            marketing_type="instore",
            conversion_rate=25.0,
            channel_name="Instore",
            subchannel_name="Signage",
            load_ts=datetime(2023, 1, 3),
        ),
        Row(
            campaign_id="campaign-4",
            booking_id="booking-4",
            marketing_type="in-store",
            conversion_rate=28.0,
            channel_name="Instore",
            subchannel_name="Displays",
            load_ts=datetime(2023, 1, 4),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = ConversionRateThresholdsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=df,
        thresholds_config=config,
        instore_variants=config.instore_variants,
        correlation_id="corr-123",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    mock_publisher_class.assert_not_called()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_conversion_rate_thresholds_with_breach_when_above_thresholds(
    mock_publisher_class,
    spark_session,
):
    """
    Test that metrics are published when conversion rates exceed the thresholds.

    Creates test data with conversion rates ABOVE the thresholds for offsite (12% > 10%),
    onsite (12% > 10%), and instore variants (35%, 33% > 30%). Verifies that MetricsPublisher
    is instantiated when breaches occur.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("conversion_rate", DoubleType(), True),
        StructField("channel_name", StringType(), True),
        StructField("subchannel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            marketing_type="offsite",
            conversion_rate=12.0,
            channel_name="Meta",
            subchannel_name="Facebook",
            load_ts=datetime(2023, 1, 1),
        ),
        Row(
            campaign_id="campaign-2",
            booking_id="booking-2",
            marketing_type="onsite",
            conversion_rate=12.0,
            channel_name="Email",
            subchannel_name="Newsletter",
            load_ts=datetime(2023, 1, 2),
        ),
        Row(
            campaign_id="campaign-3",
            booking_id="booking-3",
            marketing_type="instore",
            conversion_rate=35.0,
            channel_name="Instore",
            subchannel_name="Signage",
            load_ts=datetime(2023, 1, 3),
        ),
        Row(
            campaign_id="campaign-4",
            booking_id="booking-4",
            marketing_type="in-store",
            conversion_rate=33.0,
            channel_name="Instore",
            subchannel_name="Displays",
            load_ts=datetime(2023, 1, 4),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = ConversionRateThresholdsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=df,
        thresholds_config=config,
        instore_variants=config.instore_variants,
        correlation_id="corr-1011",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    mock_publisher_class.assert_called_once()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_conversion_rate_thresholds_handles_mixed_case_marketing_types(
    mock_publisher_class,
    spark_session,
):
    """
    Test that marketing types with mixed case are handled correctly and aggregated by group.

    Creates 6 campaigns across 5 unique groups (marketing_type/channel/subchannel):
    - Group 1: offsite/Meta/Facebook - 2 campaigns with OFFSITE and OfFsItE variants
    - Group 2: onsite/Email/Newsletter - 1 campaign with ONSITE
    - Group 3: onsite/Website/Banner - 1 campaign with OnSiTe
    - Group 4: instore/Instore/Signage - 1 campaign with INSTORE
    - Group 5: instore/Instore/POS - 1 campaign with In-Store variant

    Verifies that all mixed case variants are normalized and aggregated correctly,
    resulting in 5 publish_event calls (one per unique group).
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("conversion_rate", DoubleType(), True),
        StructField("channel_name", StringType(), True),
        StructField("subchannel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            marketing_type="OFFSITE",
            conversion_rate=12.0,
            channel_name="Meta",
            subchannel_name="Facebook",
            load_ts=datetime(2023, 1, 1),
        ),
        Row(
            campaign_id="campaign-2",
            booking_id="booking-2",
            marketing_type="OfFsItE",
            conversion_rate=11.0,
            channel_name="Meta",
            subchannel_name="Facebook",
            load_ts=datetime(2023, 1, 2),
        ),
        Row(
            campaign_id="campaign-3",
            booking_id="booking-3",
            marketing_type="ONSITE",
            conversion_rate=15.0,
            channel_name="Email",
            subchannel_name="Newsletter",
            load_ts=datetime(2023, 1, 3),
        ),
        Row(
            campaign_id="campaign-4",
            booking_id="booking-4",
            marketing_type="OnSiTe",
            conversion_rate=13.0,
            channel_name="Website",
            subchannel_name="Banner",
            load_ts=datetime(2023, 1, 4),
        ),
        Row(
            campaign_id="campaign-5",
            booking_id="booking-5",
            marketing_type="INSTORE",
            conversion_rate=35.0,
            channel_name="Instore",
            subchannel_name="Signage",
            load_ts=datetime(2023, 1, 5),
        ),
        Row(
            campaign_id="campaign-6",
            booking_id="booking-6",
            marketing_type="In-Store",
            conversion_rate=32.0,
            channel_name="Instore",
            subchannel_name="POS",
            load_ts=datetime(2023, 1, 6),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = ConversionRateThresholdsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=df,
        thresholds_config=config,
        instore_variants=config.instore_variants,
        correlation_id="corr-123",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    mock_publisher_class.assert_called_once()
    publisher_instance = mock_publisher_class.return_value
    assert publisher_instance.publish_event.call_count == 5


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_conversion_rate_thresholds_instore_variants_both_detected(
    mock_publisher_class,
    spark_session,
):
    """
    Test that both 'instore' and 'in-store' variants are detected and aggregated correctly.

    Creates 4 campaigns with both instore variants, where 2 breach the threshold and 2 don't:
    - Group 1: instore/Instore/Signage - 1 campaign above threshold (35%)
    - Group 2: instore/Instore/Display - 1 campaign above threshold (33%)
    - Non-breach: instore/Instore/POS - 1 campaign below threshold (29%)
    - Non-breach: instore/Instore/Aisle - 1 campaign below threshold (28%)

    Verifies that both variants are normalized to 'instore' and only the 2 breach groups
    result in publish_event calls.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("conversion_rate", DoubleType(), True),
        StructField("channel_name", StringType(), True),
        StructField("subchannel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            marketing_type="instore",
            conversion_rate=35.0,
            channel_name="Instore",
            subchannel_name="Signage",
            load_ts=datetime(2023, 1, 1),
        ),
        Row(
            campaign_id="campaign-2",
            booking_id="booking-2",
            marketing_type="in-store",
            conversion_rate=33.0,
            channel_name="Instore",
            subchannel_name="Display",
            load_ts=datetime(2023, 1, 2),
        ),
        Row(
            campaign_id="campaign-3",
            booking_id="booking-3",
            marketing_type="instore",
            conversion_rate=29.0,
            channel_name="Instore",
            subchannel_name="POS",
            load_ts=datetime(2023, 1, 3),
        ),
        Row(
            campaign_id="campaign-4",
            booking_id="booking-4",
            marketing_type="in-store",
            conversion_rate=28.0,
            channel_name="Instore",
            subchannel_name="Aisle",
            load_ts=datetime(2023, 1, 4),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = ConversionRateThresholdsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=df,
        thresholds_config=config,
        instore_variants=config.instore_variants,
        correlation_id="corr-456",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    mock_publisher_class.assert_called_once()
    publisher_instance = mock_publisher_class.return_value
    assert publisher_instance.publish_event.call_count == 2


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_conversion_rate_thresholds_publishes_correct_number_of_events(
    mock_publisher_class,
    spark_session,
):
    """
    Test that publish_event is called once per aggregated group.

    Creates 5 campaigns across 5 unique groups (marketing_type/channel/subchannel),
    all exceeding their respective thresholds. Verifies that exactly 5 aggregated
    events are published (one per unique group).
    """

    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("conversion_rate", DoubleType(), True),
        StructField("channel_name", StringType(), True),
        StructField("subchannel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row("campaign-1", "booking-1", "offsite", 15.0, "Meta", "Facebook", datetime(2023, 1, 1)),
        Row("campaign-2", "booking-2", "offsite", 12.0, "Google", "Search", datetime(2023, 1, 2)),
        Row("campaign-3", "booking-3", "onsite", 14.0, "Email", "Newsletter", datetime(2023, 1, 3)),
        Row("campaign-4", "booking-4", "onsite", 11.0, "Website", "Banner", datetime(2023, 1, 4)),
        Row("campaign-5", "booking-5", "instore", 35.0, "Instore", "Signage", datetime(2023, 1, 5)),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = ConversionRateThresholdsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=df,
        thresholds_config=config,
        instore_variants=config.instore_variants,
        correlation_id="corr-123",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    publisher_instance = mock_publisher_class.return_value
    assert publisher_instance.publish_event.call_count == 5


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_conversion_rate_thresholds_generates_unique_names_correctly(
    mock_publisher_class,
    spark_session,
):
    """
    Test that aggregated unique names are generated in the correct format.

    Creates 2 campaigns in different groups and verifies that unique names follow the format:
    'conversion_rate_validation_summary|{marketing_type}|{subchannel_name}'

    Events are sorted by marketing_type_lower, so 'instore' appears before 'offsite'.
    """

    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("conversion_rate", DoubleType(), True),
        StructField("channel_name", StringType(), True),
        StructField("subchannel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row("camp-123", "book-456", "offsite", 15.0, "Meta", "Facebook", datetime(2023, 1, 1)),
        Row("camp-789", "book-101", "instore", 35.0, "Instore", "Display", datetime(2023, 1, 2)),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = ConversionRateThresholdsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=df,
        thresholds_config=config,
        instore_variants=config.instore_variants,
        correlation_id="corr-999",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    publisher_instance = mock_publisher_class.return_value
    call_args_list = publisher_instance.publish_event.call_args_list

    first_event = call_args_list[0][1]['event']
    assert first_event.name == "conversion_rate_validation_summary|instore|Display"

    second_event = call_args_list[1][1]['event']
    assert second_event.name == "conversion_rate_validation_summary|offsite|Facebook"


@pytest.mark.parametrize("partitions", [1, 3])
def test_agg_validate_conversion_rate_thresholds_selects_stable_tied_examples(spark_session, partitions):
    """Equal rates retain the first ten booking IDs regardless of input partitioning."""
    reporting_df = spark_session.range(12).select(
        F.lit("campaign").alias("campaign_id"),
        F.format_string("%02d", F.lit(11) - F.col("id")).alias("booking_id"),
        F.lit("offsite").alias("marketing_type"),
        F.lit(15.0).alias("conversion_rate"),
        F.lit("Meta").alias("channel_name"),
        F.lit("Instagram").alias("subchannel_name"),
        F.lit(datetime(2023, 1, 1)).alias("load_ts"),
    ).repartition(partitions)
    expected_df = spark_session.range(10).select(
        F.lit(15.0).alias("conversion_rate"),
        F.lit("campaign").alias("campaign_id"),
        F.format_string("%02d", F.col("id")).alias("booking_id"),
    )
    config = ConversionRateThresholdsConfig()

    summaries = spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.agg_validate_conversion_rate_thresholds(
        reporting_df, config, config.instore_variants,
    )
    result = summaries.select(F.explode(F.col("top_examples")).alias("example")).select("example.*")

    assert_df_equality(result, expected_df, ignore_nullable=True, ignore_row_order=True)


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_conversion_rate_thresholds_event_has_correct_attributes(
    mock_publisher_class,
    spark_session,
):
    """
    Test that aggregated event has all required attributes with correct values.

    Creates 2 campaigns in the same group (offsite/Meta/Instagram) and verifies that
    the published event contains correct correlation_id, type, severity, breach_count,
    statistics (max, min conversion rates), threshold value, and top_examples.
    """

    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("conversion_rate", DoubleType(), True),
        StructField("channel_name", StringType(), True),
        StructField("subchannel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    test_timestamp = datetime(2023, 5, 15, 10, 30, 45)
    data = [
        Row("camp-abc", "book-xyz", "offsite", 15.5, "Meta", "Instagram", test_timestamp),
        Row("camp-def", "book-123", "offsite", 12.3, "Meta", "Instagram", test_timestamp),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = ConversionRateThresholdsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=df,
        thresholds_config=config,
        instore_variants=config.instore_variants,
        correlation_id="corr-unique-123",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    publisher_instance = mock_publisher_class.return_value
    event = publisher_instance.publish_event.call_args_list[0][1]['event']
    metadata = json.loads(event.metadata)

    assert event.correlation_id == "corr-unique-123"
    assert event.type == "conversion_rate_validation"
    assert event.severity == "HIGH"
    assert metadata["marketing_type"] == "offsite"
    assert event.channel_name == "Meta"
    assert metadata["subchannel_name"] == "Instagram"
    assert metadata["breach_count"] == 2
    assert metadata["max_conversion_rate"] == 15.5
    assert metadata["min_conversion_rate"] == 12.3
    assert int(event.value) == 2
    assert metadata["threshold_value"] == 10.0
    assert len(metadata["top_examples"]) == 2
    assert metadata["load_ts"] == str(test_timestamp)


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_conversion_rate_thresholds_uses_correct_message_subject(
    mock_publisher_class,
    spark_session,
):
    """
    Test that the message subject is correct for aggregated violations.

    Verifies that the message subject is 'Conversion Rate Threshold Violations Detected'.
    """

    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("conversion_rate", DoubleType(), True),
        StructField("channel_name", StringType(), True),
        StructField("subchannel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row("campaign-1", "booking-1", "offsite", 15.0, "Meta", "Facebook", datetime(2023, 1, 1)),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = ConversionRateThresholdsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=df,
        thresholds_config=config,
        instore_variants=config.instore_variants,
        correlation_id="corr-123",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    publisher_instance = mock_publisher_class.return_value
    call_args = publisher_instance.publish_event.call_args_list[0]
    assert call_args[1]['message_subject'] == "Conversion Rate Threshold Violations Detected"


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_conversion_rate_thresholds_preserves_original_marketing_type_case(
    mock_publisher_class,
    spark_session,
):
    """
    Test that original marketing_type case is preserved in aggregated events.

    Creates campaigns with different case variants (OFFSITE, OnSiTe, In-Store) and verifies
    that the original casing is deterministically selected using F.min() for display.
    Each campaign has a unique subchannel to create separate groups.
    """

    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("conversion_rate", DoubleType(), True),
        StructField("channel_name", StringType(), True),
        StructField("subchannel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row("campaign-1", "booking-1", "OFFSITE", 15.0, "Meta", "Facebook", datetime(2023, 1, 1)),
        Row("campaign-2", "booking-2", "OnSiTe", 14.0, "Email", "Newsletter", datetime(2023, 1, 2)),
        Row("campaign-3", "booking-3", "In-Store", 35.0, "Instore", "Display", datetime(2023, 1, 3)),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = ConversionRateThresholdsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=df,
        thresholds_config=config,
        instore_variants=config.instore_variants,
        correlation_id="corr-123",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    publisher_instance = mock_publisher_class.return_value
    call_args_list = publisher_instance.publish_event.call_args_list

    metadata_0 = json.loads(call_args_list[0][1]['event'].metadata)
    metadata_1 = json.loads(call_args_list[1][1]['event'].metadata)
    metadata_2 = json.loads(call_args_list[2][1]['event'].metadata)

    assert metadata_0["marketing_type"] == "In-Store"
    assert metadata_1["marketing_type"] == "OFFSITE"
    assert metadata_2["marketing_type"] == "OnSiTe"


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_conversion_rate_thresholds_comment_format_is_correct(
    mock_publisher_class,
    spark_session,
):
    """
    Test that aggregated comment is formatted correctly with statistics.

    Creates 3 campaigns across 2 groups:
    - Group 1: offsite/Meta/Facebook - 2 campaigns (15.567%, 12.123%)
    - Group 2: instore/Instore/Display - 1 campaign (35.123%)

    Verifies that comments include breach_count, marketing_type/subchannel, max/min/threshold
    percentages formatted to 2 decimal places.
    """

    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("conversion_rate", DoubleType(), True),
        StructField("channel_name", StringType(), True),
        StructField("subchannel_name", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row("campaign-1", "booking-1", "offsite", 15.567, "Meta", "Facebook", datetime(2023, 1, 1)),
        Row("campaign-2", "booking-2", "offsite", 12.123, "Meta", "Facebook", datetime(2023, 1, 2)),
        Row("campaign-3", "booking-3", "instore", 35.123, "Instore", "Display", datetime(2023, 1, 3)),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = ConversionRateThresholdsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_conversion_rate_thresholds(
        conversion_rate_threshold_df=df,
        thresholds_config=config,
        instore_variants=config.instore_variants,
        correlation_id="corr-123",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    publisher_instance = mock_publisher_class.return_value
    call_args_list = publisher_instance.publish_event.call_args_list

    comment_0 = call_args_list[0][1]['event'].comment
    assert "1 campaigns exceeded threshold" in comment_0
    assert "instore/Display" in comment_0
    assert "Max: 35.12%" in comment_0
    assert "Threshold: 30.00%" in comment_0

    comment_1 = call_args_list[1][1]['event'].comment
    assert "2 campaigns exceeded threshold" in comment_1
    assert "offsite/Facebook" in comment_1
    assert "Max: 15.57%" in comment_1
    assert "Threshold: 10.00%" in comment_1


# Recalibration Factor Threshold Tests
@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_recalibration_factor_thresholds_no_breach_when_within_valid_range(
    mock_publisher_class,
    spark_session,
):
    """
    Test that no metrics are published when recalibration factors are within valid ranges.

    For all offsite channels, including Meta, the valid range is > 0.00 and <= 1.00.
    For non-offsite channels: valid value is exactly 1.00

    Creates test data with valid recalibration factors and verifies that
    MetricsPublisher is not instantiated when no breaches occur.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("channel_name", StringType(), True),
        StructField("channel_name_lower", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("recalibration_factor", DoubleType(), True),
        StructField("run_type", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            channel_name="Meta",
            channel_name_lower="meta",
            marketing_type="offsite",
            recalibration_factor=0.16,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 1),
        ),
        Row(
            campaign_id="campaign-2",
            booking_id="booking-2",
            channel_name="YouTube",
            channel_name_lower="youtube",
            marketing_type="offsite",
            recalibration_factor=0.85,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 2),
        ),
        Row(
            campaign_id="campaign-3",
            booking_id="booking-3",
            channel_name="DV360",
            channel_name_lower="dv360",
            marketing_type="offsite",
            recalibration_factor=0.50,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 3),
        ),
        Row(
            campaign_id="campaign-4",
            booking_id="booking-4",
            channel_name="Email",
            channel_name_lower="email",
            marketing_type="onsite",
            recalibration_factor=1.00,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 4),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = RecalibrationFactorsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=df,
        recalibration_config=config,
        correlation_id="corr-123",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    mock_publisher_class.assert_not_called()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_recalibration_factor_thresholds_with_offsite_breach_too_high(
    mock_publisher_class,
    spark_session,
):
    """
    Test that metrics are published when offsite channel recalibration factors exceed max threshold.

    Creates test data where offsite channels have recalibration_factor > 1.00.
    Verifies that MetricsPublisher is called for the breach.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("channel_name", StringType(), True),
        StructField("channel_name_lower", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("recalibration_factor", DoubleType(), True),
        StructField("run_type", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            channel_name="Meta",
            channel_name_lower="meta",
            marketing_type="offsite",
            recalibration_factor=1.25,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 1),
        ),
        Row(
            campaign_id="campaign-2",
            booking_id="booking-2",
            channel_name="YouTube",
            channel_name_lower="youtube",
            marketing_type="offsite",
            recalibration_factor=1.50,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 2),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = RecalibrationFactorsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=df,
        recalibration_config=config,
        correlation_id="corr-456",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    mock_publisher_class.assert_called_once()
    publisher_instance = mock_publisher_class.return_value
    assert publisher_instance.publish_event.call_count >= 1


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_recalibration_factor_thresholds_with_offsite_breach_too_low(
    mock_publisher_class,
    spark_session,
):
    """
    Test that metrics are published when offsite channel recalibration factors are <= 0.00.

    Creates test data where offsite channels have recalibration_factor <= 0.00.
    Verifies that MetricsPublisher is called for the breach.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("channel_name", StringType(), True),
        StructField("channel_name_lower", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("recalibration_factor", DoubleType(), True),
        StructField("run_type", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            channel_name="Meta",
            channel_name_lower="meta",
            marketing_type="offsite",
            recalibration_factor=0.00,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 1),
        ),
        Row(
            campaign_id="campaign-2",
            booking_id="booking-2",
            channel_name="DV360",
            channel_name_lower="dv360",
            marketing_type="offsite",
            recalibration_factor=-0.10,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 2),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = RecalibrationFactorsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=df,
        recalibration_config=config,
        correlation_id="corr-789",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    mock_publisher_class.assert_called_once()
    publisher_instance = mock_publisher_class.return_value
    assert publisher_instance.publish_event.call_count >= 1


@pytest.mark.parametrize("meta_factor", [0.01719430576038334, 0.16, 0.85, 1.0])
@pytest.mark.parametrize("meta_channel", ["Meta", "Social"])
@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_recalibration_factor_thresholds_allows_dynamic_meta_factor_in_range(
    mock_publisher_class,
    spark_session,
    meta_factor,
    meta_channel,
):
    """
    Legacy and dynamic Meta factors within bounds are valid under either channel label.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("channel_name", StringType(), True),
        StructField("channel_name_lower", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("recalibration_factor", DoubleType(), True),
        StructField("run_type", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            channel_name=meta_channel,
            channel_name_lower=meta_channel.lower(),
            marketing_type="offsite",
            recalibration_factor=meta_factor,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 1),
        ),
        Row(
            campaign_id="campaign-2",
            booking_id="booking-2",
            channel_name="YouTube",
            channel_name_lower="youtube",
            marketing_type="offsite",
            recalibration_factor=0.85,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 2),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = RecalibrationFactorsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=df,
        recalibration_config=config,
        correlation_id="corr-meta-factor",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    mock_publisher_class.assert_not_called()


@pytest.mark.parametrize("factor", [0.0, -0.1, 1.000001])
def test_agg_validate_recalibration_factor_thresholds_rejects_invalid_offsite_factors(
    spark_session,
    factor,
):
    """Meta and other offsite channels retain the same strict factor bounds."""
    config = RecalibrationFactorsConfig()
    reporting_df = spark_session.createDataFrame(
        [
            (channel, "booking-1", channel, "offsite", factor, datetime(2023, 1, 1))
            for channel in ("Meta", "Social", "YouTube")
        ],
        "campaign_id STRING, booking_id STRING, channel_name STRING, "
        "marketing_type STRING, recalibration_factor DOUBLE, load_ts TIMESTAMP",
    )

    result = (
        spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics
        .agg_validate_recalibration_factor_thresholds(reporting_df, config)
    )
    expected_threshold = (
        f"<= {config.offsite_recalibration_min_threshold}"
        if factor <= config.offsite_recalibration_min_threshold
        else f"> {config.offsite_recalibration_max_threshold}"
    )
    summaries = result.collect()

    assert {row.channel_name for row in summaries} == {"Meta", "Social", "YouTube"}
    assert all(row.threshold_breached == expected_threshold for row in summaries)
    assert all(row.breach_count == 1 for row in summaries)


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_recalibration_factor_thresholds_with_non_offsite_breach(
    mock_publisher_class,
    spark_session,
):
    """
    Test that metrics are published when non-offsite channels have recalibration_factor != 1.00.

    Creates test data where non-offsite channels (Email, Instore) have recalibration_factor != 1.00.
    Verifies that MetricsPublisher is called for breaches.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("channel_name", StringType(), True),
        StructField("channel_name_lower", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("recalibration_factor", DoubleType(), True),
        StructField("run_type", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            channel_name="Email",
            channel_name_lower="email",
            marketing_type="onsite",
            recalibration_factor=0.85,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 1),
        ),
        Row(
            campaign_id="campaign-2",
            booking_id="booking-2",
            channel_name="Instore",
            channel_name_lower="instore",
            marketing_type="instore",
            recalibration_factor=1.10,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 2),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = RecalibrationFactorsConfig()

    breach_count = spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=df,
        recalibration_config=config,
        correlation_id="corr-non-offsite",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    # Both channels have factors != 1.00, so should detect 2 breach groups
    assert breach_count == 2
    mock_publisher_class.assert_called_once()
    publisher_instance = mock_publisher_class.return_value
    assert publisher_instance.publish_event.call_count == 2


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_recalibration_factor_thresholds_aggregates_by_channel_and_threshold_type(
    mock_publisher_class,
    spark_session,
):
    """
    Test that breaches are aggregated correctly by channel and threshold type.

    Creates multiple campaigns with different breach types (too high vs too low)
    for the same channel, and verifies they are aggregated into separate groups.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("channel_name", StringType(), True),
        StructField("channel_name_lower", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("recalibration_factor", DoubleType(), True),
        StructField("run_type", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        # Meta channel with factor too high
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            channel_name="Meta",
            channel_name_lower="meta",
            marketing_type="offsite",
            recalibration_factor=1.25,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 1),
        ),
        Row(
            campaign_id="campaign-2",
            booking_id="booking-2",
            channel_name="Meta",
            channel_name_lower="meta",
            marketing_type="offsite",
            recalibration_factor=1.30,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 2),
        ),
        # Meta channel with factor too low
        Row(
            campaign_id="campaign-3",
            booking_id="booking-3",
            channel_name="Meta",
            channel_name_lower="meta",
            marketing_type="offsite",
            recalibration_factor=0.00,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 3),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = RecalibrationFactorsConfig()

    breach_count = spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=df,
        recalibration_config=config,
        correlation_id="corr-agg-test",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    # Should have 2 breach groups: Meta with > 1.00 and Meta with <= 0.00
    assert breach_count == 2
    publisher_instance = mock_publisher_class.return_value
    assert publisher_instance.publish_event.call_count == 2


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_recalibration_factor_thresholds_event_has_correct_attributes(
    mock_publisher_class,
    spark_session,
):
    """
    Test that the published event has all required attributes with correct values.

    Verifies correlation_id, type, severity, breach details, and metadata structure.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("channel_name", StringType(), True),
        StructField("channel_name_lower", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("recalibration_factor", DoubleType(), True),
        StructField("run_type", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    test_timestamp = datetime(2023, 5, 15, 10, 30, 45)
    data = [
        Row(
            campaign_id="camp-abc",
            booking_id="book-xyz",
            channel_name="Meta",
            channel_name_lower="meta",
            marketing_type="offsite",
            recalibration_factor=1.25,
            run_type="Pollen",
            load_ts=test_timestamp,
        ),
        Row(
            campaign_id="camp-def",
            booking_id="book-123",
            channel_name="Meta",
            channel_name_lower="meta",
            marketing_type="offsite",
            recalibration_factor=1.15,
            run_type="Pollen",
            load_ts=test_timestamp,
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = RecalibrationFactorsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=df,
        recalibration_config=config,
        correlation_id="corr-unique-456",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    publisher_instance = mock_publisher_class.return_value
    event = publisher_instance.publish_event.call_args_list[0][1]["event"]
    metadata = json.loads(event.metadata)

    assert event.correlation_id == "corr-unique-456"
    assert event.type == "recalibration_factor_validation"
    assert event.severity == "HIGH"
    assert event.channel_name == "Meta"
    assert metadata["channel_name"] == "Meta"
    assert metadata["breach_count"] == 2
    assert metadata["max_recalibration_factor"] == 1.25
    assert metadata["min_recalibration_factor"] == 1.15
    assert int(event.value) == 2
    assert len(metadata["top_examples"]) == 2
    assert metadata["load_ts"] == str(test_timestamp)


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_recalibration_factor_thresholds_uses_correct_message_subject(
    mock_publisher_class,
    spark_session,
):
    """
    Test that the message subject is correct for recalibration factor violations.

    Verifies that the message subject is 'Recalibration Factor Threshold Violations Detected'.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("channel_name", StringType(), True),
        StructField("channel_name_lower", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("recalibration_factor", DoubleType(), True),
        StructField("run_type", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        Row(
            campaign_id="campaign-1",
            booking_id="booking-1",
            channel_name="YouTube",
            channel_name_lower="youtube",
            marketing_type="offsite",
            recalibration_factor=1.50,
            run_type="Pollen",
            load_ts=datetime(2023, 1, 1),
        ),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = RecalibrationFactorsConfig()

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=df,
        recalibration_config=config,
        correlation_id="corr-subject-test",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    publisher_instance = mock_publisher_class.return_value
    call_args = publisher_instance.publish_event.call_args_list[0]
    assert call_args[1]["message_subject"] == "Recalibration Factor Threshold Violations Detected"


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_validate_recalibration_factor_thresholds_returns_correct_breach_count(
    mock_publisher_class,
    spark_session,
):
    """
    Test that the function returns the correct number of breach groups.

    Creates campaigns across multiple channels and verifies the returned breach count
    matches the number of unique channel/threshold_breached combinations.
    """
    schema = StructType([
        StructField("campaign_id", StringType(), True),
        StructField("booking_id", StringType(), True),
        StructField("channel_name", StringType(), True),
        StructField("channel_name_lower", StringType(), True),
        StructField("marketing_type", StringType(), True),
        StructField("recalibration_factor", DoubleType(), True),
        StructField("run_type", StringType(), True),
        StructField("load_ts", TimestampType(), True),
    ])

    data = [
        # Meta with > 1.00
        Row("camp-1", "book-1", "Meta", "meta", "offsite", 1.25, "Pollen", datetime(2023, 1, 1)),
        Row("camp-2", "book-2", "Meta", "meta", "offsite", 1.30, "Pollen", datetime(2023, 1, 2)),
        # YouTube with <= 0.00
        Row("camp-3", "book-3", "YouTube", "youtube", "offsite", 0.00, "Pollen", datetime(2023, 1, 3)),
        # DV360 with > 1.00
        Row("camp-4", "book-4", "DV360", "dv360", "offsite", 1.10, "Pollen", datetime(2023, 1, 4)),
    ]

    df = spark_session.createDataFrame(data, schema)
    config = RecalibrationFactorsConfig()

    breach_count = spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.validate_recalibration_factor_thresholds(
        measurement_campaign_reporting_df=df,
        recalibration_config=config,
        correlation_id="corr-count-test",
        metrics_topic_arn="arn:aws:sns:eu-west-1:123456789012:metrics-topic",
    )

    # 3 unique groups: Meta/>1.00, YouTube/<=0.00, DV360/>1.00
    assert breach_count == 3


# check_channel_sales_ratio tests
def test_get_channel_unit_ratios_aggregates_before_dividing(spark_session):
    """Channel ratios use summed inputs, excluding null channels and nonpositive conversion totals."""
    reporting_df = spark_session.range(6).select(
        F.when(F.col("id") < 2, "A").when(F.col("id") == 2, "B")
        .when(F.col("id") == 3, "C").when(F.col("id") == 5, "D").alias("channel_name"),
        F.when(F.col("id") < 2, 6.0).when(F.col("id") == 2, 1.0)
        .when(F.col("id") == 3, 4.0).when(F.col("id") == 4, 5.0).alias("attributed_recalibrated_units_qty"),
        F.when(F.col("id") == 0, 1.0).when(F.col("id") == 1, 3.0)
        .when(F.col("id") == 2, 0.0).when(F.col("id") == 3, -1.0)
        .otherwise(2.0).alias("conversions_recalibrated"),
    )
    expected_df = spark_session.range(2).select(
        F.when(F.col("id") == 0, "A").otherwise("D").alias("channel_name"),
        F.when(F.col("id") == 0, 12.0).alias("total_recalibrated_units"),
        F.when(F.col("id") == 0, 4.0).otherwise(2.0).alias("total_conversions"),
        F.when(F.col("id") == 0, 3.0).alias("channel_sales_ratio"),
    )

    result = get_channel_unit_ratios(reporting_df)

    assert_df_equality(result, expected_df, ignore_nullable=True, ignore_row_order=True)


@pytest.mark.parametrize("rates,maximum,median,absolute_flags,median_flags", [
    ([1.5, 4.5, 2.0], 4.0, 2.0, [False, True, False], [False, True, False]),
    ([1.4, 2.0, 2.6], 2.6, 2.0, [False, False, False], [False, False, False]),
    ([-2.0, -1.0, 4.0], 4.0, -1.0, [False, False, False], [False, False, False]),
    ([0.0], 4.0, 0.0, [False], [False]),
    ([None], 4.0, None, [False], [False]),
    ([], 4.0, None, [], []),
])
def test_evaluate_channel_ratio_thresholds_preserves_boundaries(
    spark_session, rates, maximum, median, absolute_flags, median_flags,
):
    """Custom limits retain inclusive boundaries and suppress median alerts for nonpositive or missing medians."""
    ratio_values = F.array(*[F.lit(value).cast("double") for value in rates]).cast("array<double>")
    index = F.col("id").cast("int") + 1
    reporting_df = spark_session.range(len(rates)).select(
        F.col("id").cast("string").alias("channel_name"),
        F.element_at(ratio_values, index).alias("channel_sales_ratio"),
    )
    channel_index = F.col("channel_name").cast("int") + 1
    expected_df = reporting_df.select(
        F.col("channel_name"), F.col("channel_sales_ratio"),
        F.lit(median).cast("double").alias("median_ratio"),
        F.element_at(F.array(*[F.lit(value) for value in absolute_flags]).cast("array<boolean>"), channel_index)
        .alias("absolute_breach"),
        F.element_at(F.array(*[F.lit(value) for value in median_flags]).cast("array<boolean>"), channel_index)
        .alias("median_breach"),
    )
    config = ChannelSalesRatioConfig(higher_unit_ratio_warning=maximum, median_ratio_deviation_threshold=0.30)

    result = evaluate_channel_ratio_thresholds(reporting_df, config).select(*expected_df.columns)

    assert_df_equality(result, expected_df, ignore_nullable=True, ignore_row_order=True)


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_check_channel_sales_ratio_absolute_threshold_breach(mock_publisher_class, spark_session):
    """Test when a channel breaches both Check 1 (>4.0) and Check 2 (±30% median deviation).

    With realistic channel variance: Search has high ratio (4.5), Social/Email are lower (1.5/2.0).
    Median = 2.0, bounds = [1.4, 2.6]. Search (4.5) breaches both checks, so 2 events published.
    """
    mock_publisher = mock_publisher_class.return_value

    # Test data with realistic channel variance - Search significantly outperforms others
    test_data = [
        Row(channel_name="Social", attributed_recalibrated_units_qty=150.0, conversions_recalibrated=100.0),  # Ratio = 1.5
        Row(channel_name="Search", attributed_recalibrated_units_qty=450.0, conversions_recalibrated=100.0),  # Ratio = 4.5, breaches both checks
        Row(channel_name="Email", attributed_recalibrated_units_qty=200.0, conversions_recalibrated=100.0),  # Ratio = 2.0
    ]

    # Create DataFrame with the test data
    df = spark_session.createDataFrame(
        test_data,
        schema="channel_name STRING, attributed_recalibrated_units_qty DOUBLE, conversions_recalibrated DOUBLE"
    )

    # Call the function being tested
    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_sales_ratio(
        df,
        "corr-id-123",
        "arn:aws:sns:eu-west-1:123456789012:metrics-topic"  # Mock SNS topic
    )

    # Verify MetricsPublisher.publish_event was called twice:
    # - Check 1: Search (4.5) > 4.0 threshold
    # - Check 2: Search (4.5) > 2.6 (upper bound of [1.4, 2.6])
    assert mock_publisher.publish_event.call_count == 2


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_check_channel_sales_ratio_median_deviation_breach(mock_publisher_class, spark_session):
    """Test Check 2: Channel ratio deviating ±30% from median triggers warning."""
    mock_publisher = mock_publisher_class.return_value

    # Test data where one channel deviates more than 30% from the median
    # Ratios: [1.5, 1.5, 2.2] -> median = 1.5, bounds = [1.05, 1.95]
    # Email (2.2) is 47% above median, exceeding ±30% threshold
    test_data = [
        Row(channel_name="Social", attributed_recalibrated_units_qty=150.0, conversions_recalibrated=100.0),  # Ratio = 1.5
        Row(channel_name="Search", attributed_recalibrated_units_qty=150.0, conversions_recalibrated=100.0),  # Ratio = 1.5
        Row(channel_name="Email", attributed_recalibrated_units_qty=220.0, conversions_recalibrated=100.0),   # Ratio = 2.2 (47% above median, breaches)
    ]

    df = spark_session.createDataFrame(
        test_data,
        schema="channel_name STRING, attributed_recalibrated_units_qty DOUBLE, conversions_recalibrated DOUBLE"
    )

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_sales_ratio(
        df,
        "corr-id-456",
        "arn:aws:sns:eu-west-1:123456789012:metrics-topic"  # Mock SNS topic
    )

    # Verify MetricsPublisher.publish_event was called for Email (deviation breach)
    mock_publisher.publish_event.assert_called_once()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_check_channel_sales_ratio_no_breach(mock_publisher_class, spark_session):
    """
    Test to check when there is no breach in channel ratio, no event is published.
    """
    mock_publisher = mock_publisher_class.return_value

    # Test data where no channel breaches any threshold
    # Median = 1.5, bounds = [1.05, 1.95] for ±30% deviation
    # All ratios within bounds and below 4.0 threshold
    test_data = [
        Row(channel_name="Social", attributed_recalibrated_units_qty=150.0, conversions_recalibrated=100.0),  # Ratio = 1.5
        Row(channel_name="Search", attributed_recalibrated_units_qty=160.0, conversions_recalibrated=100.0),  # Ratio = 1.6
        Row(channel_name="Email", attributed_recalibrated_units_qty=140.0, conversions_recalibrated=100.0),  # Ratio = 1.4
    ]

    df = spark_session.createDataFrame(
        test_data,
        schema="channel_name STRING, attributed_recalibrated_units_qty DOUBLE, conversions_recalibrated DOUBLE"
    )

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_sales_ratio(
        df,
        "corr-id-789",
        "arn:aws:sns:eu-west-1:123456789012:metrics-topic"  # Mock SNS topic
    )

    # Verify MetricsPublisher.publish_event was not called
    mock_publisher.publish_event.assert_not_called()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_check_channel_sales_median_deviation_no_breach(mock_publisher_class, spark_session):
    """Test to check when there is no breach in channel deviation from the median, no event is published."""
    mock_publisher = mock_publisher_class.return_value

    # Test data where all channels are within 30% deviation from the median
    test_data = [
        Row(channel_name="Social", attributed_recalibrated_units_qty=115.0, conversions_recalibrated=100.0),  # Ratio = 1.15 (Median)
        Row(channel_name="Search", attributed_recalibrated_units_qty=130.0, conversions_recalibrated=100.0),  # Ratio = 1.3 (13% above median)
        Row(channel_name="Email", attributed_recalibrated_units_qty=90.0, conversions_recalibrated=100.0),  # Ratio = 0.9 (22% below median)
    ]

    df = spark_session.createDataFrame(
        test_data,
        schema="channel_name STRING, attributed_recalibrated_units_qty DOUBLE, conversions_recalibrated DOUBLE"
    )

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_sales_ratio(
        df,
        "corr-id-101",
        "arn:aws:sns:eu-west-1:123456789012:metrics-topic"  # Mock SNS topic
    )

    # Verify MetricsPublisher.publish_event was not called
    mock_publisher.publish_event.assert_not_called()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_check_channel_sales_ratio_zero_conversions_filtered(mock_publisher_class, spark_session):
    """Channels with 0 conversions are filtered out before checks."""
    test_data = [
        Row(channel_name="Search", attributed_recalibrated_units_qty=100.0, conversions_recalibrated=50.0),
        Row(channel_name="Display", attributed_recalibrated_units_qty=200.0, conversions_recalibrated=0.0),
    ]
    df = spark_session.createDataFrame(test_data, schema="channel_name STRING, attributed_recalibrated_units_qty DOUBLE, conversions_recalibrated DOUBLE")

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_sales_ratio(df, CORR_ID, TOPIC_ARN)

    mock_publisher_class.return_value.publish_event.assert_not_called()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_check_channel_sales_ratio_both_checks_breach_same_channel(mock_publisher_class, spark_session):
    """Channel with ratio >4.0 AND deviating ±30% publishes 2 events."""
    test_data = [
        Row(channel_name="Search", attributed_recalibrated_units_qty=100.0, conversions_recalibrated=50.0),  # ratio = 2.0
        Row(channel_name="Display", attributed_recalibrated_units_qty=500.0, conversions_recalibrated=100.0),  # ratio = 5.0 > 4.0 AND >1.30*median
    ]
    df = spark_session.createDataFrame(test_data, schema="channel_name STRING, attributed_recalibrated_units_qty DOUBLE, conversions_recalibrated DOUBLE")

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_sales_ratio(df, CORR_ID, TOPIC_ARN)

    # Should publish 2 events for Display: one for Check 1 (>4.0), one for Check 2 (deviation)
    events = mock_publisher_class.return_value.publish_event.call_args_list
    assert len(events) == 2
    event_names = {e[1]['event'].name for e in events}
    assert "channel_sales_ratio_absolute_check|Display" in event_names
    assert "channel_sales_ratio_median_check|Display" in event_names


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_check_channel_sales_ratio_median_deviation_breach_upper(mock_publisher_class, spark_session):
    """Channel ratio > median * 1.30 triggers Check 2 warning."""
    test_data = [
        Row(channel_name="Search", attributed_recalibrated_units_qty=200.0, conversions_recalibrated=100.0),  # ratio = 2.0
        Row(channel_name="Display", attributed_recalibrated_units_qty=150.0, conversions_recalibrated=100.0),  # ratio = 1.5, median ≈ 1.75
        Row(channel_name="Social", attributed_recalibrated_units_qty=500.0, conversions_recalibrated=100.0),  # ratio = 5.0, outlier > upper bound
    ]
    df = spark_session.createDataFrame(test_data, schema="channel_name STRING, attributed_recalibrated_units_qty DOUBLE, conversions_recalibrated DOUBLE")

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_sales_ratio(df, CORR_ID, TOPIC_ARN)

    # Should publish: Check 2 (Social exceeds ±30%), not Check 1 (5.0 > 4.0 is also breach, so both)
    assert mock_publisher_class.return_value.publish_event.call_count >= 1


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_check_channel_sales_ratio_median_deviation_breach_lower(mock_publisher_class, spark_session):
    """Channel ratio < median * 0.70 triggers Check 2 warning."""
    test_data = [
        Row(channel_name="Search", attributed_recalibrated_units_qty=200.0, conversions_recalibrated=100.0),  # ratio = 2.0
        Row(channel_name="Display", attributed_recalibrated_units_qty=190.0, conversions_recalibrated=100.0),  # ratio = 1.9
        Row(channel_name="Social", attributed_recalibrated_units_qty=50.0, conversions_recalibrated=100.0),  # ratio = 0.5, outlier < lower bound
    ]
    df = spark_session.createDataFrame(test_data, schema="channel_name STRING, attributed_recalibrated_units_qty DOUBLE, conversions_recalibrated DOUBLE")

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_sales_ratio(df, CORR_ID, TOPIC_ARN)

    # Should publish Check 2 for Social (below lower bound)
    assert mock_publisher_class.return_value.publish_event.call_count >= 1


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_media_spend_check_threshold_breach(mock_publisher_class, spark_session):
    """Test that channels with media spend below the threshold, trigger a warning event."""
    mock_publisher = mock_publisher_class.return_value

    # Test data where one channel is below threshold (50.0)
    test_data = [
        Row(channel_name="Search", media_spend_amt=30.0),  # Below threshold of 50.0
        Row(channel_name="Display", media_spend_amt=100.0),  # Above threshold
    ]

    df = spark_session.createDataFrame(
        test_data,
        schema="channel_name STRING, media_spend_amt DOUBLE"
    )

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.media_spend_check(
        df,
        "corr-id-999",
        "arn:aws:sns:eu-west-1:123456789012:metrics-topic"
    )

    # Verify MetricsPublisher.publish_event was called: 1 warning for Search
    assert mock_publisher.publish_event.call_count == 1


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_media_spend_check_no_breach_when_all_above_threshold(mock_publisher_class, spark_session):
    """Test that no event is published when all channels are at or above threshold."""
    mock_publisher = mock_publisher_class.return_value

    # Test data where all channels are at or above threshold (50.0)
    test_data = [
        Row(channel_name="Search", media_spend_amt=50.0),  # At threshold
        Row(channel_name="Display", media_spend_amt=100.0),  # Above threshold
    ]

    df = spark_session.createDataFrame(
        test_data,
        schema="channel_name STRING, media_spend_amt DOUBLE"
    )

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.media_spend_check(
        df,
        "corr-id-1000",
        "arn:aws:sns:eu-west-1:123456789012:metrics-topic"
    )

    # No events should be published (no breaches)
    assert mock_publisher.publish_event.call_count == 0


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_media_spend_check_multiple_below_threshold(mock_publisher_class, spark_session):
    """Test that when there are multiple channels at below the threshold, each triggers a separate event."""
    mock_publisher = mock_publisher_class.return_value

    # Test data where multiple channels are below threshold (50.0)
    test_data = [
        Row(channel_name="Search", media_spend_amt=20.0),  # Below threshold
        Row(channel_name="Email", media_spend_amt=40.0),  # Below threshold
        Row(channel_name="Display", media_spend_amt=100.0),  # Above threshold
    ]

    df = spark_session.createDataFrame(
        test_data,
        schema="channel_name STRING, media_spend_amt DOUBLE"
    )

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.media_spend_check(
        df,
        "corr-id-1001",
        "arn:aws:sns:eu-west-1:123456789012:metrics-topic"
    )

    # Two events should be published: 2 warnings (Search, Email)
    assert mock_publisher.publish_event.call_count == 2


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_media_spend_check_nulls(mock_publisher_class, spark_session):
    """Test that channels with null media spend do not trigger events."""
    mock_publisher = mock_publisher_class.return_value

    # Test data where one channel has null media spend
    test_data = [
        Row(channel_name="Search", media_spend_amt=None),  # Null value
        Row(channel_name="Display", media_spend_amt=100.0),  # Above threshold
    ]

    df = spark_session.createDataFrame(
        test_data,
        schema="channel_name STRING, media_spend_amt DOUBLE"
    )

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.media_spend_check(
        df,
        "corr-id-1002",
        "arn:aws:sns:eu-west-1:123456789012:metrics-topic"
    )

    # No events should be published (null values aggregated, no breaches)
    assert mock_publisher.publish_event.call_count == 0


def _select_fields(source_schema: StructType, field_names: tuple[str, ...]) -> StructType:
    source_fields = {field.name: field for field in source_schema.fields}
    return StructType([source_fields[name] for name in field_names])


ATTRIBUTION_SCHEMA = _select_fields(
    AttributionModel.schema,
    ("userjourney_id", "channel_name", "normalized_weights", "isconversion"),
)

WEIGHT_SCHEMA = _select_fields(
    AttributionModel.schema,
    ("userjourney_id", "normalized_weights", "isconversion"),
)

REPORTING_SCHEMA = _select_fields(
    UnifiedBaselineAttributionIntegration.schema,
    ("channel_name", "attributed_sales_amt", "attributed_recalibrated_units_qty"),
)


def make_attribution_df(spark: SparkSession, rows):
    return spark.createDataFrame([Row(**r) for r in rows], schema=ATTRIBUTION_SCHEMA)


def make_reporting_df(spark: SparkSession, rows):
    return spark.createDataFrame([Row(**r) for r in rows], schema=REPORTING_SCHEMA)


def make_weight_df(spark: SparkSession, rows):
    return spark.createDataFrame([Row(**r) for r in rows], schema=WEIGHT_SCHEMA)


def published_events(mock_pub) -> list:
    return [
        c[1]["event"] if c.kwargs else c[0][1]
        for c in mock_pub.return_value.publish_event.call_args_list
    ]


def single_event(mock_pub) -> MTAValidationMetricSchema:
    mock_pub.assert_called_once_with(topic_arn=TOPIC_ARN)
    call = mock_pub.return_value.publish_event.call_args
    return call[1]["event"] if call.kwargs else call[0][1]


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_all_weights_sum_to_one_publishes_no_event(
    mock_publisher_class,
    spark_session,
):
    rows = [
        {"userjourney_id": "j1", "normalized_weights": 0.6, "isconversion": 1},
        {"userjourney_id": "j1", "normalized_weights": 0.4, "isconversion": 1},
        {"userjourney_id": "j2", "normalized_weights": 1.0, "isconversion": 1},
    ]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_normalized_weight_distribution(make_weight_df(spark_session, rows), CORR_ID, TOPIC_ARN)

    mock_publisher_class.return_value.publish_event.assert_not_called()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_single_failing_journey_publishes_high(
    mock_publisher_class,
    spark_session,
):
    rows = [
        {"userjourney_id": "j1", "normalized_weights": 0.5, "isconversion": 1},
        {"userjourney_id": "j1", "normalized_weights": 0.45, "isconversion": 1},
        {"userjourney_id": "j2", "normalized_weights": 1.0, "isconversion": 1},
    ]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_normalized_weight_distribution(make_weight_df(spark_session, rows), CORR_ID, TOPIC_ARN)

    event = single_event(mock_publisher_class)
    assert event.severity == Severity.HIGH
    assert event.value == "1"
    assert json.loads(event.metadata)["failing_journey_count"] == 1


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_multiple_failing_journeys_publishes_high(
    mock_publisher_class,
    spark_session,
):
    rows = [
        {"userjourney_id": "j1", "normalized_weights": 0.5, "isconversion": 1},
        {"userjourney_id": "j2", "normalized_weights": 0.8, "isconversion": 1},
        {"userjourney_id": "j3", "normalized_weights": 1.0, "isconversion": 1},
    ]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_normalized_weight_distribution(make_weight_df(spark_session, rows), CORR_ID, TOPIC_ARN)

    event = single_event(mock_publisher_class)
    assert event.severity == Severity.HIGH
    assert event.value == "2"


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_difference_at_tolerance_boundary_is_caught(
    mock_publisher_class,
    spark_session,
):
    rows = [{"userjourney_id": "j1", "normalized_weights": 1.0 + 1e-5, "isconversion": 1}]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_normalized_weight_distribution(make_weight_df(spark_session, rows), CORR_ID, TOPIC_ARN)

    assert single_event(mock_publisher_class).severity == Severity.HIGH


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_difference_below_tolerance_passes(
    mock_publisher_class,
    spark_session,
):
    rows = [{"userjourney_id": "j1", "normalized_weights": 1.0 + 5e-6, "isconversion": 1}]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_normalized_weight_distribution(make_weight_df(spark_session, rows), CORR_ID, TOPIC_ARN)

    mock_publisher_class.return_value.publish_event.assert_not_called()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_failure_metadata_contains_min_max_weight_sum(
    mock_publisher_class,
    spark_session,
):
    rows = [
        {"userjourney_id": "j1", "normalized_weights": 0.7, "isconversion": 1},
        {"userjourney_id": "j2", "normalized_weights": 1.2, "isconversion": 1},
        {"userjourney_id": "j3", "normalized_weights": 1.0, "isconversion": 1},
    ]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_normalized_weight_distribution(make_weight_df(spark_session, rows), CORR_ID, TOPIC_ARN)

    metadata = json.loads(single_event(mock_publisher_class).metadata)
    assert metadata["min_weight_sum"] == pytest.approx(0.7, abs=1e-9)
    assert metadata["max_weight_sum"] == pytest.approx(1.2, abs=1e-9)


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_publishes_both_check_names_when_ranks_diverge(
    mock_publisher_class,
    spark_session,
):
    attr_rows = [
        {"userjourney_id": "j1", "channel_name": "YouTube", "normalized_weights": 0.9, "isconversion": 1},
        {"userjourney_id": "j2", "channel_name": "Meta", "normalized_weights": 0.5, "isconversion": 1},
        {"userjourney_id": "j3", "channel_name": "DV360", "normalized_weights": 0.2, "isconversion": 1},
    ]
    rep_rows = [
        {"channel_name": "DV360", "attributed_sales_amt": 500.0, "attributed_recalibrated_units_qty": 490},
        {"channel_name": "Meta", "attributed_sales_amt": 300.0, "attributed_recalibrated_units_qty": 290},
        {"channel_name": "YouTube", "attributed_sales_amt": 100.0, "attributed_recalibrated_units_qty": 90},
    ]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_contribution_distribution(
        make_attribution_df(spark_session, attr_rows),
        make_reporting_df(spark_session, rep_rows),
        CORR_ID, TOPIC_ARN,
    )

    events = published_events(mock_publisher_class)
    assert len(events) == 2
    names = {e.name for e in events}
    assert MtaValidationConfig.CONTRIBUTION_VS_SALES_CHECK_NAME in names
    assert MtaValidationConfig.CONTRIBUTION_VS_RECALIBRATED_UNITS_CHECK_NAME in names


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_perfect_rank_agreement_publishes_no_event(
    mock_publisher_class,
    spark_session,
):
    attr_rows = [
        {"userjourney_id": "j1", "channel_name": "YouTube", "normalized_weights": 0.9, "isconversion": 1},
        {"userjourney_id": "j2", "channel_name": "Meta", "normalized_weights": 0.5, "isconversion": 1},
        {"userjourney_id": "j3", "channel_name": "DV360", "normalized_weights": 0.2, "isconversion": 1},
    ]
    rep_rows = [
        {"channel_name": "YouTube", "attributed_sales_amt": 500.0, "attributed_recalibrated_units_qty": 490},
        {"channel_name": "Meta", "attributed_sales_amt": 300.0, "attributed_recalibrated_units_qty": 290},
        {"channel_name": "DV360", "attributed_sales_amt": 100.0, "attributed_recalibrated_units_qty": 90},
    ]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_contribution_distribution(
        make_attribution_df(spark_session, attr_rows),
        make_reporting_df(spark_session, rep_rows),
        CORR_ID, TOPIC_ARN,
    )

    mock_publisher_class.return_value.publish_event.assert_not_called()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_inverted_ranks_produce_high(
    mock_publisher_class,
    spark_session,
):
    attr_rows = [
        {"userjourney_id": "j1", "channel_name": "YouTube", "normalized_weights": 0.9, "isconversion": 1},
        {"userjourney_id": "j2", "channel_name": "Meta", "normalized_weights": 0.5, "isconversion": 1},
        {"userjourney_id": "j3", "channel_name": "DV360", "normalized_weights": 0.2, "isconversion": 1},
    ]
    rep_rows = [
        {"channel_name": "DV360", "attributed_sales_amt": 500.0, "attributed_recalibrated_units_qty": 490},
        {"channel_name": "Meta", "attributed_sales_amt": 300.0, "attributed_recalibrated_units_qty": 290},
        {"channel_name": "YouTube", "attributed_sales_amt": 100.0, "attributed_recalibrated_units_qty": 90},
    ]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_contribution_distribution(
        make_attribution_df(spark_session, attr_rows),
        make_reporting_df(spark_session, rep_rows),
        CORR_ID, TOPIC_ARN,
    )

    for event in published_events(mock_publisher_class):
        assert event.severity == Severity.HIGH, f"Expected HIGH, got {event.severity} for {event.name}"
        assert float(event.value) < MtaValidationConfig.SPEARMAN_HIGH_THRESHOLD


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_single_channel_produces_no_events(
    mock_publisher_class,
    spark_session,
):
    attr_rows = [{"userjourney_id": "j1", "channel_name": "Meta", "normalized_weights": 1.0, "isconversion": 1}]
    rep_rows = [{"channel_name": "Meta", "attributed_sales_amt": 500.0, "attributed_recalibrated_units_qty": 490}]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_contribution_distribution(
        make_attribution_df(spark_session, attr_rows),
        make_reporting_df(spark_session, rep_rows),
        CORR_ID, TOPIC_ARN,
    )

    mock_publisher_class.return_value.publish_event.assert_not_called()


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_metadata_contains_per_channel_ranks(
    mock_publisher_class,
    spark_session,
):
    attr_rows = [
        {"userjourney_id": "j1", "channel_name": "Meta", "normalized_weights": 0.7, "isconversion": 1},
        {"userjourney_id": "j2", "channel_name": "DV360", "normalized_weights": 0.3, "isconversion": 1},
    ]
    rep_rows = [
        {"channel_name": "Meta", "attributed_sales_amt": 400.0, "attributed_recalibrated_units_qty": 390},
        {"channel_name": "DV360", "attributed_sales_amt": 200.0, "attributed_recalibrated_units_qty": 190},
    ]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_contribution_distribution(
        make_attribution_df(spark_session, attr_rows),
        make_reporting_df(spark_session, rep_rows),
        CORR_ID, TOPIC_ARN,
    )

    for event in published_events(mock_publisher_class):
        metadata = json.loads(event.metadata)
        assert "channel_ranks" in metadata
        names = {r["channel_name"] for r in metadata["channel_ranks"]}
        assert names == {"Meta", "DV360"}


@mock.patch("spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.MetricsPublisher")
def test_rho_value_is_stored_in_event(
    mock_publisher_class,
    spark_session,
):
    attr_rows = [
        {"userjourney_id": "j1", "channel_name": "Meta", "normalized_weights": 0.7, "isconversion": 1},
        {"userjourney_id": "j2", "channel_name": "DV360", "normalized_weights": 0.3, "isconversion": 1},
    ]
    rep_rows = [
        {"channel_name": "Meta", "attributed_sales_amt": 400.0, "attributed_recalibrated_units_qty": 390},
        {"channel_name": "DV360", "attributed_sales_amt": 200.0, "attributed_recalibrated_units_qty": 190},
    ]

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_channel_contribution_distribution(
        make_attribution_df(spark_session, attr_rows),
        make_reporting_df(spark_session, rep_rows),
        CORR_ID, TOPIC_ARN,
    )

    for event in published_events(mock_publisher_class):
        rho = float(event.value)
        assert -1.0 <= rho <= 1.0


def make_roas_df(spark: SparkSession, rows):
    return spark.createDataFrame(rows, schema=ROAS_SCHEMA)


@mock.patch(PATCH_TARGET)
def test_check_roas_thresholds_no_breach_when_below_threshold(
    mock_publisher_class,
    spark_session,
):
    """
    Test that no event is published when all ROAS values are below 50.0.
    """
    rows = [
        Row(campaign_id="camp-1", booking_id="book-1", channel_name="Meta", subchannel_name="Facebook",
            roas_exposed=10.0, media_spend_amt=1000.0, load_ts=datetime(2024, 1, 1)),
        Row(campaign_id="camp-2", booking_id="book-2", channel_name="DV360", subchannel_name="Display",
            roas_exposed=49.99, media_spend_amt=500.0, load_ts=datetime(2024, 1, 2)),
    ]
    df = make_roas_df(spark_session, rows)

    result = spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_roas_thresholds(df, CORR_ID, TOPIC_ARN)

    assert result == 0
    mock_publisher_class.assert_not_called()


@mock.patch(PATCH_TARGET)
def test_check_roas_thresholds_breach_when_above_threshold(
    mock_publisher_class,
    spark_session,
):
    """
    Test that one event is published when a ROAS value exceeds 50.0.
    """
    rows = [
        Row(campaign_id="camp-1", booking_id="book-1", channel_name="Meta", subchannel_name="Facebook",
            roas_exposed=75.0, media_spend_amt=100.0, load_ts=datetime(2024, 1, 1)),
    ]
    df = make_roas_df(spark_session, rows)

    result = spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_roas_thresholds(df, CORR_ID, TOPIC_ARN)

    assert result == 1
    mock_publisher_class.assert_called_once()
    mock_publisher_class.return_value.publish_event.assert_called_once()


@mock.patch(PATCH_TARGET)
def test_check_roas_thresholds_groups_by_channel_subchannel(
    mock_publisher_class,
    spark_session,
):
    """
    Test that breaches in different channel/subchannel groups produce separate events.
    """
    rows = [
        Row(campaign_id="camp-1", booking_id="book-1", channel_name="Meta", subchannel_name="Facebook",
            roas_exposed=60.0, media_spend_amt=100.0, load_ts=datetime(2024, 1, 1)),
        Row(campaign_id="camp-2", booking_id="book-2", channel_name="Meta", subchannel_name="Facebook",
            roas_exposed=80.0, media_spend_amt=50.0, load_ts=datetime(2024, 1, 2)),
        Row(campaign_id="camp-3", booking_id="book-3", channel_name="DV360", subchannel_name="Display",
            roas_exposed=55.0, media_spend_amt=200.0, load_ts=datetime(2024, 1, 3)),
    ]
    df = make_roas_df(spark_session, rows)

    result = spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_roas_thresholds(df, CORR_ID, TOPIC_ARN)

    assert result == 2
    assert mock_publisher_class.return_value.publish_event.call_count == 2


@mock.patch(PATCH_TARGET)
def test_check_roas_thresholds_event_attributes(
    mock_publisher_class,
    spark_session,
):
    """
    Test that the published event carries correct correlation_id, type, severity,
    breach_count, max/min ROAS, threshold value, and breach_examples.
    """
    test_ts = datetime(2024, 3, 15, 9, 0, 0)
    rows = [
        Row(campaign_id="camp-A", booking_id="book-X", channel_name="Meta", subchannel_name="Instagram",
            roas_exposed=120.0, media_spend_amt=80.0, load_ts=test_ts),
        Row(campaign_id="camp-B", booking_id="book-Y", channel_name="Meta", subchannel_name="Instagram",
            roas_exposed=65.5, media_spend_amt=120.0, load_ts=test_ts),
    ]
    df = make_roas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_roas_thresholds(df, CORR_ID, TOPIC_ARN)

    event = mock_publisher_class.return_value.publish_event.call_args[1]["event"]
    metadata = json.loads(event.metadata)

    assert event.correlation_id == CORR_ID
    assert event.type == "roas_validation"
    assert event.severity == "HIGH"
    assert event.channel_name == "Meta"
    assert metadata["subchannel_name"] == "Instagram"
    assert metadata["breach_count"] == 2
    assert metadata["max_roas"] == pytest.approx(120.0)
    assert metadata["min_roas"] == pytest.approx(65.5)
    assert metadata["threshold_value"] == 50.0
    assert int(event.value) == 2
    assert len(metadata["breach_examples"]) == 2


@mock.patch(PATCH_TARGET)
def test_check_roas_thresholds_event_name_format(
    mock_publisher_class,
    spark_session,
):
    """
    Test that event name follows the format
    'roas_threshold_validation_summary|{channel_name}|{subchannel_name}'.
    """
    rows = [
        Row(campaign_id="camp-1", booking_id="book-1", channel_name="YouTube", subchannel_name="Pre-Roll",
            roas_exposed=99.0, media_spend_amt=300.0, load_ts=datetime(2024, 1, 1)),
    ]
    df = make_roas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_roas_thresholds(df, CORR_ID, TOPIC_ARN)

    event = mock_publisher_class.return_value.publish_event.call_args[1]["event"]
    assert event.name == "roas_threshold_validation_summary|YouTube|Pre-Roll"


@mock.patch(PATCH_TARGET)
def test_check_roas_thresholds_uses_correct_message_subject(
    mock_publisher_class,
    spark_session,
):
    """
    Test that the message subject matches MtaValidationConfig.MESSAGE_SUBJECT.
    """
    rows = [
        Row(campaign_id="camp-1", booking_id="book-1", channel_name="Meta", subchannel_name="Facebook",
            roas_exposed=200.0, media_spend_amt=50.0, load_ts=datetime(2024, 1, 1)),
    ]
    df = make_roas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_roas_thresholds(df, CORR_ID, TOPIC_ARN)

    call_kwargs = mock_publisher_class.return_value.publish_event.call_args[1]
    assert call_kwargs["message_subject"] == MtaValidationConfig.MESSAGE_SUBJECT


@mock.patch(PATCH_TARGET)
def test_check_roas_thresholds_null_roas_is_ignored(
    mock_publisher_class,
    spark_session,
):
    """
    Test that rows with NULL roas_exposed are skipped and do not trigger a breach.
    """
    rows = [
        Row(campaign_id="camp-1", booking_id="book-1", channel_name="Meta", subchannel_name="Facebook",
            roas_exposed=None, media_spend_amt=100.0, load_ts=datetime(2024, 1, 1)),
        Row(campaign_id="camp-2", booking_id="book-2", channel_name="Meta", subchannel_name="Facebook",
            roas_exposed=30.0, media_spend_amt=100.0, load_ts=datetime(2024, 1, 2)),
    ]
    df = make_roas_df(spark_session, rows)

    result = spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_roas_thresholds(df, CORR_ID, TOPIC_ARN)

    assert result == 0
    mock_publisher_class.assert_not_called()


@mock.patch(PATCH_TARGET)
def test_check_roas_thresholds_returns_zero_with_empty_dataframe(
    mock_publisher_class,
    spark_session,
):
    """
    Test that an empty DataFrame results in 0 breaches and no events published.
    """
    df = spark_session.createDataFrame([], schema=ROAS_SCHEMA)

    result = spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_roas_thresholds(df, CORR_ID, TOPIC_ARN)

    assert result == 0
    mock_publisher_class.assert_not_called()


@mock.patch(PATCH_TARGET)
def test_check_roas_thresholds_comment_format(
    mock_publisher_class,
    spark_session,
):
    """
    Test that the breach comment includes channel, subchannel, breach count,
    max/min ROAS values, and threshold formatted to 2 decimal places.
    """
    rows = [
        Row(campaign_id="camp-1", booking_id="book-1", channel_name="Meta", subchannel_name="Facebook",
            roas_exposed=123.456, media_spend_amt=50.0, load_ts=datetime(2024, 1, 1)),
        Row(campaign_id="camp-2", booking_id="book-2", channel_name="Meta", subchannel_name="Facebook",
            roas_exposed=51.789, media_spend_amt=80.0, load_ts=datetime(2024, 1, 2)),
    ]
    df = make_roas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_roas_thresholds(df, CORR_ID, TOPIC_ARN)

    event = mock_publisher_class.return_value.publish_event.call_args[1]["event"]
    assert "2 campaign(s) exceeded ROAS threshold" in event.comment
    assert "Meta/Facebook" in event.comment
    assert "Max: 123.46" in event.comment
    assert "Min: 51.79" in event.comment
    assert "Threshold: 50.0" in event.comment


@mock.patch(PATCH_TARGET)
def test_check_roas_thresholds_events_ordered_by_channel_subchannel(
    mock_publisher_class,
    spark_session,
):
    """
    Test that published events are ordered by channel_name then subchannel_name.
    """
    rows = [
        Row(campaign_id="camp-1", booking_id="book-1", channel_name="YouTube", subchannel_name="Bumper",
            roas_exposed=60.0, media_spend_amt=100.0, load_ts=datetime(2024, 1, 1)),
        Row(campaign_id="camp-2", booking_id="book-2", channel_name="Meta", subchannel_name="Facebook",
            roas_exposed=70.0, media_spend_amt=200.0, load_ts=datetime(2024, 1, 2)),
        Row(campaign_id="camp-3", booking_id="book-3", channel_name="DV360", subchannel_name="Display",
            roas_exposed=55.0, media_spend_amt=300.0, load_ts=datetime(2024, 1, 3)),
    ]
    df = make_roas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_roas_thresholds(df, CORR_ID, TOPIC_ARN)

    events = published_events(mock_publisher_class)
    channel_subchannel_pairs = [
        (json.loads(e.metadata)["channel_name"], json.loads(e.metadata)["subchannel_name"])
        for e in events
    ]
    assert channel_subchannel_pairs == sorted(channel_subchannel_pairs)


def incremental_sales_vs_iroas_df(spark: SparkSession, rows):
    return spark.createDataFrame(rows, schema=INCREMENTAL_SALES_IROAS_SCHEMA)


@pytest.mark.parametrize("empty_input", [False, True])
def test_incremental_iroas_helpers_recalculate_from_summed_inputs(spark_session, empty_input):
    """Brand/channel and channel totals recalculate iROAS from sums, not individual ratios; empty input remains empty."""
    rows = [] if empty_input else [
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=100.0,
            media_spend_amt=20.0, iroas_exposed=5.0, attributed_recalibrated_sales_amt=200.0),
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=100.0,
            media_spend_amt=80.0, iroas_exposed=1.25, attributed_recalibrated_sales_amt=300.0),
        Row(unique_brand_name="Brand2", channel_name="Meta", incremental_sales_amt_exposed=300.0,
            media_spend_amt=100.0, iroas_exposed=3.0, attributed_recalibrated_sales_amt=1000.0),
        Row(unique_brand_name="Brand3", channel_name=None, incremental_sales_amt_exposed=1000.0,
            media_spend_amt=100.0, iroas_exposed=10.0, attributed_recalibrated_sales_amt=2000.0),
    ]
    reporting_df = incremental_sales_vs_iroas_df(spark_session, rows)
    expected_brand_totals = spark_session.range(0 if empty_input else 2).select(
        F.when(F.col("id") == 0, "Brand1").otherwise("Brand2").alias("unique_brand_name"),
        F.lit("Meta").alias("channel_name"),
        F.when(F.col("id") == 0, 200.0).otherwise(300.0).alias("total_incremental_sales"),
        F.when(F.col("id") == 0, 500.0).otherwise(1000.0).alias("total_attributed_sales"),
        F.lit(100.0).alias("total_media_spend"),
        F.when(F.col("id") == 0, 2.0).otherwise(3.0).alias("total_iroas"),
    )
    expected_channel_totals = spark_session.range(0 if empty_input else 1).select(
        F.lit("Meta").alias("channel_name"), F.lit(500.0).alias("total_incremental_sales"),
        F.lit(200.0).alias("total_media_spend"), F.lit(2.5).alias("total_iroas"),
    )

    brand_totals = get_brand_channel_incremental_totals(reporting_df)
    channel_totals = get_channel_incremental_iroas(brand_totals)

    assert_df_equality(brand_totals, expected_brand_totals, ignore_nullable=True, ignore_row_order=True)
    assert_df_equality(channel_totals, expected_channel_totals, ignore_nullable=True)


@mock.patch(PATCH_TARGET)
def test_check_incremental_sales_iroas_no_breaches_returns_zero(mock_publisher_class, spark_session):
    """Test that no events published when all checks pass."""
    rows = [
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=400.0, media_spend_amt=100.0, iroas_exposed=4.0, attributed_recalibrated_sales_amt=500.0),
        Row(unique_brand_name="Brand1", channel_name="DV360", incremental_sales_amt_exposed=250.0, media_spend_amt=100.0, iroas_exposed=2.5, attributed_recalibrated_sales_amt=300.0)
    ]
    df = incremental_sales_vs_iroas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_incremental_sales_iroas(df, CORR_ID, TOPIC_ARN)

    # No events should be published
    mock_publisher_class.return_value.publish_event.assert_not_called()

    assert mock_publisher_class.return_value.publish_event.call_count == 0


@mock.patch(PATCH_TARGET)
def test_check_incremental_sales_iroas_breaches_publish_events(mock_publisher_class, spark_session):
    """Test that breaches in incremental sales vs iROAS checks publish events.

    Display breaches Check #3: iROAS (25.0) exceeds threshold (20.0) with sufficient spend (100.0).
    """
    rows = [
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=400.0, media_spend_amt=100.0, iroas_exposed=4.0, attributed_recalibrated_sales_amt=500.0),
        Row(unique_brand_name="Brand1", channel_name="DV360", incremental_sales_amt_exposed=250.0, media_spend_amt=100.0, iroas_exposed=2.5, attributed_recalibrated_sales_amt=300.0),
        Row(unique_brand_name="Brand1", channel_name="Display", incremental_sales_amt_exposed=2500.0, media_spend_amt=100.0, iroas_exposed=25.0, attributed_recalibrated_sales_amt=5000.0)  # iROAS breach only: 2500/100 = 25 > 20, but 2500 < 5000
    ]
    df = incremental_sales_vs_iroas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_incremental_sales_iroas(df, CORR_ID, TOPIC_ARN)

    # Should publish 1 event for iROAS breach in Display channel
    events = published_events(mock_publisher_class)
    assert len(events) == 1
    event_names = {e.name for e in events}
    assert "iroas_validation|Display" in event_names


@mock.patch(PATCH_TARGET)
def test_incremental_exceeds_attributed_breach(mock_publisher_class, spark_session):
    """Test that channels where incremental_sales > attributed_sales trigger a breach event."""
    rows = [
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=600.0, media_spend_amt=100.0, iroas_exposed=6.0, attributed_recalibrated_sales_amt=500.0),  # incremental > attributed
        Row(unique_brand_name="Brand1", channel_name="DV360", incremental_sales_amt_exposed=250.0, media_spend_amt=100.0, iroas_exposed=2.5, attributed_recalibrated_sales_amt=300.0)
    ]
    df = incremental_sales_vs_iroas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_incremental_sales_iroas(df, CORR_ID, TOPIC_ARN)

    # Should publish 1 event for Meta channel where incremental exceeds attributed
    events = published_events(mock_publisher_class)
    assert len(events) == 1
    event_names = {e.name for e in events}
    assert "incremental_vs_attributed|Brand1|Meta" in event_names


@mock.patch(PATCH_TARGET)
def test_multiple_breach_types_published_together(mock_publisher_class, spark_session):
    """
    Integration test: function detects and publishes multiple breach types in one run.

    Data with incremental breach + iROAS breach + non-negative breach
    Assert that 3 events are published (one per check)
    """

    rows = [
        # Check #2 + #3 breach: incremental >= attributed AND iROAS > 20 (2100/100 = 21)
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=2100.0, media_spend_amt=100.0, iroas_exposed=21.0, attributed_recalibrated_sales_amt=500.0),
        # Check #1 breach: negative incremental
        Row(unique_brand_name="Brand1", channel_name="DV360", incremental_sales_amt_exposed=-50.0, media_spend_amt=100.0, iroas_exposed=-0.5, attributed_recalibrated_sales_amt=100.0),
        # No breach: iROAS < 20 (1000/100 = 10.0 < 20)
        Row(unique_brand_name="Brand1", channel_name="Display", incremental_sales_amt_exposed=1000.0, media_spend_amt=100.0, iroas_exposed=10.0, attributed_recalibrated_sales_amt=5000.0)
    ]
    df = incremental_sales_vs_iroas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_incremental_sales_iroas(df, CORR_ID, TOPIC_ARN)

    events = published_events(mock_publisher_class)
    assert len(events) == 3  # 3 breaches: Meta (Check #2+#3), DV360 (Check #1), no Display breach
    event_names = {e.name for e in events}
    assert "incremental_vs_attributed|Brand1|Meta" in event_names  # Check #2 (brand-channel level)
    assert "iroas_validation|Meta" in event_names                    # Check #3 (channel level)
    assert "non_negative_validation|DV360" in event_names            # Check #1 (channel level)


@mock.patch(PATCH_TARGET)
def test_iroas_not_breached_with_low_spend(mock_publisher_class, spark_session):
    """
    Test that iROAS breaches are not published when media spend is below the threshold.
    """
    rows = [
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=400.0, media_spend_amt=10.0, iroas_exposed=40.0, attributed_recalibrated_sales_amt=500.0),  # iROAS breach but low spend
        Row(unique_brand_name="Brand1", channel_name="DV360", incremental_sales_amt_exposed=250.0, media_spend_amt=100.0, iroas_exposed=2.5, attributed_recalibrated_sales_amt=300.0)
    ]
    df = incremental_sales_vs_iroas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_incremental_sales_iroas(df, CORR_ID, TOPIC_ARN)

    # No events should be published since Meta's spend is below threshold
    mock_publisher_class.return_value.publish_event.assert_not_called()


@mock.patch(PATCH_TARGET)
def test_iroas_threshold_breach_with_high_spend(mock_publisher_class, spark_session):
    """
    Test that iROAS breaches are published when media spend exceeds the threshold.
    """
    rows = [
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=2100.0, media_spend_amt=100.0, iroas_exposed=21.0, attributed_recalibrated_sales_amt=10000.0),  # iROAS breach only: 2100/100 = 21 > 20 with spend > 50, but 2100 < 10000
        Row(unique_brand_name="Brand1", channel_name="DV360", incremental_sales_amt_exposed=250.0, media_spend_amt=100.0, iroas_exposed=2.5, attributed_recalibrated_sales_amt=300.0)
    ]
    df = incremental_sales_vs_iroas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_incremental_sales_iroas(df, CORR_ID, TOPIC_ARN)

    # One event should be published for Meta channel
    events = published_events(mock_publisher_class)
    assert len(events) == 1
    event_names = {e.name for e in events}
    assert "iroas_validation|Meta" in event_names  # Check #3 (channel level)


@mock.patch(PATCH_TARGET)
def test_multiple_breaches_same_channel(mock_publisher_class, spark_session):
    """
    Test that a single channel breaching multiple checks publishes separate events.

    Meta aggregates across multiple campaigns:
    - Campaign 1: incremental=3200, iroas=32.0, attributed=500, spend=100
    - Campaign 2: incremental=410, iroas=5.1, attributed=200, spend=80

    After aggregation: incremental=3610 >= attributed=700 (Check #2 breach)
                       iroas=20.06, spend=180 (Check #3 breach: 20.06 > 20 with spend > 50)
    """
    rows = [
        # Campaign 1: incremental=3200, spend=100, attributed=500
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=3200.0, media_spend_amt=100.0, iroas_exposed=32.0, attributed_recalibrated_sales_amt=500.0),
        # Campaign 2: incremental=410, spend=80, attributed=200
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=410.0, media_spend_amt=80.0, iroas_exposed=5.125, attributed_recalibrated_sales_amt=200.0),
    ]
    df = incremental_sales_vs_iroas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_incremental_sales_iroas(df, CORR_ID, TOPIC_ARN)

    events = published_events(mock_publisher_class)
    assert len(events) == 2  # Check #2 (incremental 3610 >= attributed 700) and Check #3 (iROAS 3610/180 = 20.05 > 20)
    event_names = {e.name for e in events}
    assert "incremental_vs_attributed|Brand1|Meta" in event_names  # Check #2 (brand-channel level)
    assert "iroas_validation|Meta" in event_names                    # Check #3 (channel level)


@mock.patch(PATCH_TARGET)
def test_event_metadata_format(mock_publisher_class, spark_session):
    """
    Test that the event metadata contains the expected keys and values for breaches.
    """
    rows = [
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=600.0, media_spend_amt=100.0, iroas_exposed=6.0, attributed_recalibrated_sales_amt=500.0),
        Row(unique_brand_name="Brand1", channel_name="DV360", incremental_sales_amt_exposed=-50.0, media_spend_amt=100.0, iroas_exposed=-0.5, attributed_recalibrated_sales_amt=100.0),
    ]
    df = incremental_sales_vs_iroas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_incremental_sales_iroas(df, CORR_ID, TOPIC_ARN)

    events = published_events(mock_publisher_class)
    for event in events:
        metadata = json.loads(event.metadata)
        assert "channel_name" in metadata
        # Check #2 (incremental_vs_attributed) includes brand and attributed_sales
        if event.type == "incremental_vs_attributed":
            assert "unique_brand_name" in metadata
            assert "total_attributed_sales" in metadata
        # Check #1 (non_negative_validation) is channel-level only
        elif event.type == "non_negative_validation":
            assert "unique_brand_name" not in metadata
            assert "total_attributed_sales" not in metadata


@mock.patch(PATCH_TARGET)
def test_null_channel_name_is_filtered_out(mock_publisher_class, spark_session):
    """
    Test that rows with null channel_name are filtered out and don't trigger breaches.
    """
    rows = [
        Row(unique_brand_name="Brand1", channel_name=None, incremental_sales_amt_exposed=-50.0, media_spend_amt=100.0, iroas_exposed=-0.5, attributed_recalibrated_sales_amt=100.0),
        Row(unique_brand_name="Brand1", channel_name="Meta", incremental_sales_amt_exposed=400.0, media_spend_amt=100.0, iroas_exposed=4.0, attributed_recalibrated_sales_amt=500.0),
    ]
    df = incremental_sales_vs_iroas_df(spark_session, rows)

    spark_pipeline.metrics.mta_validation_metrics.mta_validation_metrics.check_incremental_sales_iroas(df, CORR_ID, TOPIC_ARN)

    # No events should be published (null channel filtered, Meta has no breaches)
    mock_publisher_class.return_value.publish_event.assert_not_called()
