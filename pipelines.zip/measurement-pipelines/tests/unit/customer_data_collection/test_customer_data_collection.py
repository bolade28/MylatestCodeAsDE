import os
from datetime import date, datetime
from decimal import Decimal

import pytest
from chispa.dataframe_comparer import assert_df_equality
from pyspark.sql import Row, SparkSession
from pyspark.sql import types as T

import spark_pipeline.customer_data_collection.customer_data_collection as _cdc_module
from spark_pipeline.common.variables import EventName
from spark_pipeline.customer_data_collection.customer_data_collection import (
    apply_date_window_filter,
    create_empty_customer_data_collection_df,
    get_filtered_campaign_execution,
    prepare_customer_data_collection,
    validate_offer_surpassed_brand_flag,
)
from spark_pipeline.schemas.customer_data_collection import CustomerDataCollection


def mce_row(**kwargs) -> Row:
    defaults = dict(
        campaign_id="camp-001",
        booking_id="booking-001",
        job_bag_number="jb-001",
        marketing_type="display",
        channel_name="Fins - Main Estate",
        subchannel_name="Main Estate",
        campaign_name="test-campaign",
        campaign_start_dt=date(2026, 1, 1),
        campaign_end_dt=date(2026, 1, 31),
        campaign_duration="4 weeks",
        job_status="in-progress",
        load_ts=datetime(2026, 1, 20, 0, 0, 0),
        job_run_id="run-001",
        overlapping_campaign_flag=False,
        marketing_hierarchy_cd="HIER-001",
    )
    defaults.update(kwargs)
    return Row(**defaults)


def cdc_row(**kwargs) -> Row:
    defaults = dict(
        loyalty_id="cust-001",
        transaction_key="NA",
        event_dt=datetime(2026, 1, 15, 10, 0, 0),
        event_ts=datetime(2026, 1, 15, 10, 0, 0),
        marketing_type="display",
        channel_name="Fins - Main Estate",
        subchannel_name="Main Estate",
        campaign_name="test-campaign",
        campaign_id="camp-001",
        event_name="touchpoint",
        booking_id="booking-001",
        load_ts=datetime(2026, 1, 20, 0, 0, 0),
        item_cd="item-001",
        product_type="Offer",
        unique_brand_name="brand-001",
        net_sales_amt=Decimal("0.0000"),
        units_qty=0,
        job_run_id="run-001",
        purchase_type="",
    )
    defaults.update(kwargs)
    return Row(**defaults)


# ---------------------------------------------------------------------------
# create_empty_customer_data_collection_df
# ---------------------------------------------------------------------------
def test_create_empty_returns_empty_dataframe_with_correct_schema(spark_session: SparkSession):
    """Returns a zero-row DataFrame whose schema matches CustomerDataCollection.schema."""
    # Act
    result = create_empty_customer_data_collection_df(spark_session)

    # Assert
    expected = spark_session.createDataFrame([], CustomerDataCollection.schema)
    assert_df_equality(result, expected, ignore_nullable=True)


# ---------------------------------------------------------------------------
# get_filtered_campaign_execution
# ---------------------------------------------------------------------------
def test_dtp_returns_all_campaigns_unfiltered(spark_session: SparkSession, tmp_dir: str):
    """
    DTP path skips the hierarchy join entirely — every MCE row is returned,
    including rows whose marketing_hierarchy_cd has no match in hierarchy.
    """
    # Arrange
    rows = [
        mce_row(campaign_id="camp-001", marketing_hierarchy_cd="HIER-001"),
        mce_row(campaign_id="camp-002", marketing_hierarchy_cd="HIER-999"),
    ]
    mce_path = os.path.join(tmp_dir, "mce")
    spark_session.createDataFrame(rows, CustomerDataCollection.campaign_execution_schema).write.parquet(mce_path)

    # Act
    result = get_filtered_campaign_execution(
        spark=spark_session,
        measurement_campaign_execution_path=mce_path,
        run_type="DTP",
        measurement_marketing_channel_hierarchy_path=None,
    )

    # Assert — both campaigns present
    expected = spark_session.createDataFrame(rows, CustomerDataCollection.campaign_execution_schema)
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True)


def test_pollen_returns_only_campaigns_matching_hierarchy(spark_session: SparkSession, tmp_dir: str):
    """
    Pollen path inner-joins MCE with hierarchy — only campaigns whose
    marketing_hierarchy_cd appears in the hierarchy table are kept.
    """
    # Arrange
    mce_rows = [
        mce_row(campaign_id="camp-001", marketing_hierarchy_cd="HIER-001"),
        mce_row(campaign_id="camp-002", marketing_hierarchy_cd="HIER-999"),
    ]
    mce_path = os.path.join(tmp_dir, "mce")
    hierarchy_path = os.path.join(tmp_dir, "hierarchy")
    spark_session.createDataFrame(mce_rows, CustomerDataCollection.campaign_execution_schema).write.parquet(mce_path)
    spark_session.createDataFrame(
        [Row(marketing_hierarchy_cd="HIER-001")], CustomerDataCollection.hierarchy_schema
    ).write.parquet(hierarchy_path)

    # Act
    result = get_filtered_campaign_execution(
        spark=spark_session,
        measurement_campaign_execution_path=mce_path,
        run_type="Pollen",
        measurement_marketing_channel_hierarchy_path=hierarchy_path,
    )

    # Assert — only camp-001 survived the inner join
    expected = spark_session.createDataFrame(
        [mce_row(campaign_id="camp-001", marketing_hierarchy_cd="HIER-001")],
        CustomerDataCollection.campaign_execution_schema,
    )
    # Re-select to normalise column order (join moves the join key to position 0)
    assert_df_equality(
        result.select(expected.columns),
        expected,
        ignore_row_order=True,
        ignore_nullable=True,
    )


def test_pollen_raises_when_hierarchy_path_is_none(spark_session: SparkSession, tmp_dir: str):
    """Pollen requires a hierarchy path. ValueError raised when it is absent."""
    # Arrange
    mce_path = os.path.join(tmp_dir, "mce")
    spark_session.createDataFrame([mce_row()], CustomerDataCollection.campaign_execution_schema).write.parquet(mce_path)

    # Act / Assert
    with pytest.raises(ValueError, match="measurement_marketing_channel_hierarchy_path"):
        get_filtered_campaign_execution(
            spark=spark_session,
            measurement_campaign_execution_path=mce_path,
            run_type="Pollen",
            measurement_marketing_channel_hierarchy_path=None,
        )


# ---------------------------------------------------------------------------
# apply_date_window_filter
# ---------------------------------------------------------------------------

def test_events_within_date_window_are_kept(spark_session: SparkSession):
    """An event whose event_ts falls within [start, end] of a non-overlapping campaign is kept."""
    # Arrange
    cdc_df = spark_session.createDataFrame(
        [cdc_row(event_ts=datetime(2026, 1, 15, 10, 0, 0))],
        CustomerDataCollection.channel_data_schema,
    )
    campaign_df = spark_session.createDataFrame(
        [Row(overlapping_campaign_flag=False,
             campaign_start_dt=date(2026, 1, 1),
             campaign_end_dt=date(2026, 1, 31))],
        CustomerDataCollection.date_window_schema,
    )

    # Act
    result = apply_date_window_filter(cdc_df, campaign_df)

    # Assert — one row, unchanged values
    assert_df_equality(result, cdc_df, ignore_row_order=True, ignore_nullable=True, ignore_column_order=True)


def test_events_before_date_window_are_excluded(spark_session: SparkSession):
    """An event before campaign_start_dt is excluded from the output."""
    # Arrange
    cdc_df = spark_session.createDataFrame(
        [cdc_row(event_ts=datetime(2025, 12, 31, 23, 59, 59))],
        CustomerDataCollection.channel_data_schema,
    )
    campaign_df = spark_session.createDataFrame(
        [Row(overlapping_campaign_flag=False,
             campaign_start_dt=date(2026, 1, 1),
             campaign_end_dt=date(2026, 1, 31))],
        CustomerDataCollection.date_window_schema,
    )

    # Act
    result = apply_date_window_filter(cdc_df, campaign_df)

    # Assert — no rows returned
    expected = spark_session.createDataFrame([], CustomerDataCollection.channel_data_schema)
    assert_df_equality(result, expected, ignore_nullable=True, ignore_column_order=True)


def test_events_after_date_window_are_excluded(spark_session: SparkSession):
    """An event after campaign_end_dt is excluded from the output."""
    # Arrange
    cdc_df = spark_session.createDataFrame(
        [cdc_row(event_ts=datetime(2026, 2, 1, 0, 0, 1))],
        CustomerDataCollection.channel_data_schema,
    )
    campaign_df = spark_session.createDataFrame(
        [Row(overlapping_campaign_flag=False,
             campaign_start_dt=date(2026, 1, 1),
             campaign_end_dt=date(2026, 1, 31))],
        CustomerDataCollection.date_window_schema,
    )

    # Act
    result = apply_date_window_filter(cdc_df, campaign_df)

    # Assert — no rows returned
    expected = spark_session.createDataFrame([], CustomerDataCollection.channel_data_schema)
    assert_df_equality(result, expected, ignore_nullable=True, ignore_column_order=True)


def test_overlapping_campaign_dates_do_not_widen_window(spark_session: SparkSession):
    """
    Overlapping campaigns (flag=True) are excluded from the date-window calculation.
    An event inside the overlapping range but outside the non-overlapping range is dropped.
    """
    # Arrange
    # non-overlapping window: Jan 10–20
    # overlapping campaign widens to Jan 1–31 — must be ignored
    # event at Jan 5 falls in overlapping range only → must be excluded
    # event at Jan 15 falls in non-overlapping range → must be kept
    cdc_df = spark_session.createDataFrame(
        [
            cdc_row(loyalty_id="cust-A", event_ts=datetime(2026, 1, 5, 12, 0, 0)),
            cdc_row(loyalty_id="cust-B", event_ts=datetime(2026, 1, 15, 12, 0, 0)),
        ],
        CustomerDataCollection.channel_data_schema,
    )
    campaign_df = spark_session.createDataFrame(
        [
            Row(overlapping_campaign_flag=False,
                campaign_start_dt=date(2026, 1, 10),
                campaign_end_dt=date(2026, 1, 20)),
            Row(overlapping_campaign_flag=True,
                campaign_start_dt=date(2026, 1, 1),
                campaign_end_dt=date(2026, 1, 31)),
        ],
        CustomerDataCollection.date_window_schema,
    )

    # Act
    result = apply_date_window_filter(cdc_df, campaign_df)

    # Assert — only cust-B (Jan 15) is retained
    expected = spark_session.createDataFrame(
        [cdc_row(loyalty_id="cust-B", event_ts=datetime(2026, 1, 15, 12, 0, 0))],
        CustomerDataCollection.channel_data_schema,
    )
    assert_df_equality(result, expected, ignore_row_order=True, ignore_nullable=True, ignore_column_order=True)


def test_validate_does_not_raise_when_brand_exceeds_offer(spark_session: SparkSession):
    """Brand >= Offer for all campaigns passes without raising; DataFrame is unchanged."""
    # Arrange
    data = [
        Row(product_type="Offer", net_sales_amt=100, campaign_id="C1"),
        Row(product_type="Brand", net_sales_amt=200, campaign_id="C1"),
    ]
    input_df = spark_session.createDataFrame(data)
    expected_df = spark_session.createDataFrame(data)

    # Act
    validate_offer_surpassed_brand_flag(input_df)

    # Assert — validation is non-mutating
    assert_df_equality(input_df, expected_df, ignore_row_order=True)


def test_validate_raises_when_offer_exceeds_brand(spark_session: SparkSession):
    """ValueError raised when offer_sales > brand_sales and both row types are present."""
    # Arrange
    data = [
        Row(product_type="Offer", net_sales_amt=300, campaign_id="C1"),
        Row(product_type="Brand", net_sales_amt=100, campaign_id="C1"),
    ]
    df = spark_session.createDataFrame(data)

    # Act / Assert
    with pytest.raises(ValueError, match="Data quality check failed"):
        validate_offer_surpassed_brand_flag(df)


# ---------------------------------------------------------------------------
# prepare_customer_data_collection
# ---------------------------------------------------------------------------

def _write_channel_parquet(spark: SparkSession, path: str, rows: list) -> None:
    spark.createDataFrame(rows, CustomerDataCollection.channel_data_schema).write.parquet(path)


def _write_mce_parquet(spark: SparkSession, path: str, rows: list) -> None:
    spark.createDataFrame(rows, CustomerDataCollection.campaign_execution_schema).write.parquet(path)


def _call_prepare(spark, tmp_dir, youtube_rows, mce_rows=None, run_type="DTP"):
    """Write parquet files and call prepare_customer_data_collection, returning the result."""
    youtube_path = os.path.join(tmp_dir, "youtube")
    mce_path = os.path.join(tmp_dir, "mce")
    nonexistent = os.path.join(tmp_dir, "nonexistent_channel")

    _write_channel_parquet(spark, youtube_path, youtube_rows)
    _write_mce_parquet(spark, mce_path, mce_rows or [mce_row()])

    return prepare_customer_data_collection(
        spark=spark,
        youtube_data=youtube_path,
        dv360_data=nonexistent,
        citrus_data=nonexistent,
        instore_data=nonexistent,
        meta_data=nonexistent,
        magazine_data=nonexistent,
        ecoupon_data=nonexistent,
        coupon_at_till_data=nonexistent,
        measurement_campaign_execution_path=mce_path,
        output_path="s3://test-bucket/output",
        run_date="2026-01-20",
        correlation_id="test-run-001",
        slack_topic_arn="arn:aws:sns:eu-west-1:123:test",
        run_type=run_type,
    )


def test_prepare_passes_through_transaction_event_name(
    spark_session: SparkSession, tmp_dir: str, monkeypatch
):
    """
    Upstream already sends event_name as 'transaction'; the pipeline passes it
    through unchanged.
    """
    monkeypatch.setattr(_cdc_module, "spark_s3_overwrite", lambda path, df: None)

    # Arrange
    channel_row = Row(
        loyalty_id="cust-001", transaction_key="txn-001",
        event_dt=datetime(2026, 1, 15, 11, 0, 0),
        event_ts=datetime(2026, 1, 15, 11, 0, 0),
        marketing_type="", channel_name="In-store", subchannel_name="TXN",
        campaign_name="test-campaign", campaign_id="camp-001",
        event_name=EventName.TRANSACTION.value,
        booking_id="booking-001", load_ts=datetime(2026, 1, 10, 0, 0, 0),
        item_cd="item-001", product_type="Offer", unique_brand_name="brand-001",
        net_sales_amt=Decimal("10.0000"), units_qty=1, job_run_id="run-001",
        purchase_type="In-store",
    )

    # Act
    result = _call_prepare(spark_session, tmp_dir, [channel_row])

    # Assert — event_name is passed through unchanged
    actual_names = result.select("event_name")
    expected_names = spark_session.createDataFrame(
        [Row(event_name=EventName.TRANSACTION.value)],
        T.StructType([T.StructField("event_name", T.StringType(), True)]),
    )
    assert_df_equality(actual_names, expected_names, ignore_row_order=True)


def test_prepare_passes_through_purchase_type_and_channel_fields(
    spark_session: SparkSession, tmp_dir: str, monkeypatch
):
    """
    Upstream now supplies purchase_type directly and event_name is already
    'transaction' or 'touchpoint'. The pipeline passes all fields through unchanged.
    """
    monkeypatch.setattr(_cdc_module, "spark_s3_overwrite", lambda path, df: None)

    # Arrange
    purchase_row = Row(
        loyalty_id="cust-001", transaction_key="txn-001",
        event_dt=datetime(2026, 1, 15, 11, 0, 0),
        event_ts=datetime(2026, 1, 15, 11, 0, 0),
        marketing_type="display", channel_name="In-store", subchannel_name="TXN",
        campaign_name="test-campaign", campaign_id="camp-001",
        event_name=EventName.TRANSACTION.value,
        booking_id="booking-001", load_ts=datetime(2026, 1, 10, 0, 0, 0),
        item_cd="item-001", product_type="Offer", unique_brand_name="brand-001",
        net_sales_amt=Decimal("5.0000"), units_qty=1, job_run_id="run-001",
        purchase_type="In-store",
    )
    touchpoint_row = Row(
        loyalty_id="cust-001", transaction_key="NA",
        event_dt=datetime(2026, 1, 15, 10, 0, 0),
        event_ts=datetime(2026, 1, 15, 10, 0, 0),
        marketing_type="display", channel_name="Fins - Main Estate",
        subchannel_name="Main Estate",
        campaign_name="test-campaign", campaign_id="camp-001",
        event_name=EventName.TOUCHPOINT.value,
        booking_id="booking-001", load_ts=datetime(2026, 1, 10, 0, 0, 0),
        item_cd="item-001", product_type="Offer", unique_brand_name="brand-001",
        net_sales_amt=Decimal("0.0000"), units_qty=0, job_run_id="run-001",
        purchase_type="",
    )

    # Act
    result = _call_prepare(spark_session, tmp_dir, [purchase_row, touchpoint_row])

    actual = result.select(
        "event_name", "purchase_type", "channel_name",
        "subchannel_name", "marketing_type", "campaign_id",
    )
    # Assert — all fields passed through from upstream unchanged
    expected = spark_session.createDataFrame(
        [
            Row(
                event_name=EventName.TRANSACTION.value,
                purchase_type="In-store",
                channel_name="In-store",
                subchannel_name="TXN",
                marketing_type="display",
                campaign_id="camp-001",
            ),
            Row(
                event_name=EventName.TOUCHPOINT.value,
                purchase_type="",
                channel_name="Fins - Main Estate",
                subchannel_name="Main Estate",
                marketing_type="display",
                campaign_id="camp-001",
            ),
        ],
        CustomerDataCollection.purchase_fields_schema,
    )
    assert_df_equality(actual, expected, ignore_row_order=True, ignore_nullable=True)
