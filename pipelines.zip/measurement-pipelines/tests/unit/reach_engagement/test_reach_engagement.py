import pytest
from pyspark.sql import types as T
from pyspark.sql import DataFrame, SparkSession, functions as F
from datetime import datetime, date
from unittest.mock import patch, Mock
import json
import uuid

from spark_pipeline.reach_engagement.reach_engagement import (
    fetch_in_progress_campaigns, get_latest_data_for_campaigns,
    calculate_reach, meta_processor, youtube_processor, citrus_processor,
    process_all_campaigns, entrypoint, prepare_reach_engagement)

from spark_pipeline.reach_engagement.data_quality import (
    JoinValidationError,
    DiagnosticMessage, DiagnosticQuery,
    spark_df_to_prettytable)

from spark_pipeline.schemas.reach_engagement import ReachEngagementSchema


def create_test_df(spark, data, schema):
    return spark.createDataFrame(data, schema)


def test_calculate_reach(spark_session):
    """
    Tests the calculate_reach_optimized function with multiple scenarios.
    """
    # Define schemas for the input DataFrames

    spark = spark_session

    journey_data_schema = T.StructType([
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("isconversion", T.IntegerType(), True),
        T.StructField("net_sales_amt", T.DoubleType(), True),
        T.StructField("booking_id", T.StringType(), True)
    ])

    input_df_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
    ])

    # Sample journey data covering multiple campaigns and scenarios
    journey_data_rows = [
        # Campaign 1: Digital with sales and conversions
        ("Instore", "CAMP001", "Meta", "Facebook", "LID001", "J1", 1, 50.00, "BID001"),
        ("Instore", "CAMP001", "Meta", "Facebook", "LID001", "J16", 0, 0.00, "BID001"),
        ("In-store", "CAMP001", "Meta", "Instagram", "LID002", "J15", 1, 75.50, "BID001"),
        # Campaign 2: Ecoupons with sales and conversions, special subchannel logic
        ("Meta", "CAMP002", "Email", "eCoupon", "LID003", "J14", 0, 100.00, "BID002"),
        ("Meta", "CAMP002", "Email", "eCoupon", "LID003", "J13", 1, 0.00, "BID002"),
        ("Meta", "CAMP002", "Email", "eCoupon", "LID004", "J11", 0, 20.00, "BID002"),
        # Campaign 3: Digital with no conversions, only reach and sales
        ("Youtube", "CAMP003", "Google", "Search", "LID005", "J1", 1, 150.00, "BID003"),
        ("In-store", "CAMP003", "Google", "Search", "LID006", "J1", 1, 25.00, "BID003"),
        # Campaign 4: In-store, no subchannel name, no sales
        ("Gol", "CAMP004", "In-store", "In-store", "LID007", "J12", 0, 0.00, "BID004"),
        ("NA", "CAMP005", "In-store", "eCoupons", "LID008", "J1", 1, 0.00, "BID006"),
    ]

    # Sample input_df with multiple campaigns to be processed
    input_df_rows = [
        ("CAMP001", "Digital", "Meta"),
        ("CAMP002", "eCoupons", "Email"),
        ("CAMP003", "Digital", "Google"),
        ("CAMP004", "In-store", "In-store"),
        ("CAMP005", "In-store", "eCoupons")
    ]

    journey_df = spark.createDataFrame(journey_data_rows, journey_data_schema)
    input_df = spark.createDataFrame(input_df_rows, input_df_schema)

    # Call the function with a specific group_by_column
    group_by_column = "subchannel_name"
    result_df = calculate_reach(journey_df, input_df, group_by_column)

    # Convert to a list of dictionaries for easier comparison
    result_rows = [row.asDict() for row in result_df.collect()]

    # Expected output based on the logic
    # Note: the order might not be guaranteed, so we will sort for comparison
    expected_rows = [
        {'campaign_id': 'CAMP001', 'channel_name': 'Meta', 'subchannel_name': 'Facebook', 'reach': 1, 'clicks': 0, 'impressions': 0, 'sales': 50.00, 'conversions': 2, 'booking_id': 'BID001', 'marketing_type': 'Digital'},
        {'campaign_id': 'CAMP001', 'channel_name': 'Meta', 'subchannel_name': 'Instagram', 'reach': 1, 'clicks': 0, 'impressions': 0, 'sales': 75.50, 'conversions': 1, 'booking_id': 'BID001', 'marketing_type': 'Digital'},
        {'campaign_id': 'CAMP002', 'channel_name': 'Email', 'subchannel_name': 'eCoupon', 'reach': 2, 'clicks': 0, 'impressions': 0, 'sales': 120.00, 'conversions': 3, 'booking_id': 'BID002', 'marketing_type': 'eCoupons'},
        {'campaign_id': 'CAMP003', 'channel_name': 'Google', 'subchannel_name': 'Search', 'reach': 2, 'clicks': 0, 'impressions': 0, 'sales': 175.00, 'conversions': 1, 'booking_id': 'BID003', 'marketing_type': 'Digital'},
        {'campaign_id': 'CAMP004', 'channel_name': 'In-store', 'subchannel_name': 'In-store', 'reach': 1, 'clicks': 0, 'impressions': 0, 'sales': 0.00, 'conversions': 1, 'booking_id': 'BID004', 'marketing_type': 'In-store'}
    ]

    # Sort both lists of dictionaries for a stable comparison
    sorted_result = sorted(result_rows, key=lambda x: x['campaign_id'] + str(x.get('subchannel_name')))
    sorted_expected = sorted(expected_rows, key=lambda x: x['campaign_id'] + str(x.get('subchannel_name')))

    # Assert that the output matches the expected data
    assert sorted_result == sorted_expected


def test_fetch_in_progress_campaigns_basic(spark_session):
    """Test basic functionality with in-progress campaigns"""
    spark = spark_session
    # Create test data
    schema = F.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_duration", T.IntegerType()),
        T.StructField("job_status", T.StringType())
    ])

    data = [
        ("B001", 30, "In-progress"),
        ("B002", 45, "Completed"),
        ("B003", 60, "In-progress")
    ]
    df = spark.createDataFrame(data, schema)

    # Call function
    result = fetch_in_progress_campaigns(df)

    # Verify results
    results = result.collect()
    assert len(results) == 3
    assert {row.booking_id for row in results} == {"B001", "B002", "B003"}
    assert result.columns == ["booking_id", "campaign_duration"]


def test_fetch_in_progress_campaigns_empty(spark_session):
    """Test error handling when no in-progress campaigns exist"""
    spark = spark_session
    schema = F.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_duration", T.IntegerType()),
        T.StructField("job_status", T.StringType())
    ])

    data = []
    df = spark.createDataFrame(data, schema)

    # Verify exception is raised
    with pytest.raises(ValueError) as excinfo:
        fetch_in_progress_campaigns(df)
    assert "no campaign found to execute the model" in str(excinfo.value)


def test_get_latest_data_basic_case(spark_session):
    """Test basic functionality with both duration and no-duration cases"""
    spark = spark_session
    # Create test data
    data_schema = T.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_duration", T.IntegerType()),
        T.StructField("load_ts", T.TimestampType()),
        T.StructField("data_value", T.StringType())
    ])

    data_rows = [
        ("B001", 30, datetime(2023, 1, 1, 10, 0, 0), "A"),
        ("B001", 30, datetime(2023, 1, 2, 11, 0, 0), "B"),
        ("B002", None, datetime(2023, 1, 1, 9, 0, 0), "C"),
        ("B002", None, datetime(2023, 1, 3, 12, 0, 0), "D"),
        ("B003", 45, datetime(2023, 1, 1, 8, 0, 0), "E")
    ]
    data_df = spark.createDataFrame(data_rows, schema=data_schema)

    # Create in-progress campaigns
    in_progress_schema = T.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_duration", T.IntegerType())
    ])

    in_progress_rows = [
        ("B001", 30),  # With duration
        ("B002", None),  # Without duration
        ("B003", 45)  # With duration
    ]
    in_progress_df = spark.createDataFrame(in_progress_rows, schema=in_progress_schema)

    # Call function
    result = get_latest_data_for_campaigns(data_df, in_progress_df)
    results = result.orderBy("booking_id").collect()

    # Verify results
    assert len(results) == 3
    assert results[0]["booking_id"] == "B001" and results[0]["data_value"] == "A"
    assert results[1]["booking_id"] == "B001" and results[1]["data_value"] == "B"
    assert results[2]["booking_id"] == "B003" and results[2]["data_value"] == "E"


def test_missing_required_columns(spark_session):
    """Test error handling when required columns are missing"""
    spark = spark_session
    data_df = spark.createDataFrame([], T.StructType([]))
    in_progress_df = spark.createDataFrame([("B001",)], ["booking_id"])  # Missing campaign_duration

    with pytest.raises(ValueError) as excinfo:
        get_latest_data_for_campaigns(data_df, in_progress_df)
    assert "missing required columns" in str(excinfo.value)


def test_meta_processor_basic_case(spark_session):
    """Test basic functionality with complete data"""
    spark = spark_session
    # Create test schemas
    campaign_sat_schema = T.StructType([
        T.StructField("digital_trading_campaign_nk1", T.StringType()),
        T.StructField("JOB_BAG_ID", T.StringType())
    ])

    campaign_link_schema = T.StructType([
        T.StructField("digital_trading_campaign_nk1", T.StringType()),
        T.StructField("digital_trading_campaign_channel_nk1", T.StringType())
    ])

    insights_schema = T.StructType([
        T.StructField("digital_trading_campaign_nk1", T.StringType()),
        T.StructField("reporting_start_dt", T.DateType()),
        T.StructField("reporting_end_dt", T.DateType()),
        T.StructField("digital_trading_insight_id", T.StringType()),
        T.StructField("digital_trading_lineitem_nk1", T.StringType()),
        T.StructField("record_arrival_ts", T.TimestampType()),
        T.StructField("measures", T.StringType())
    ])

    unified_schema = T.StructType([
        T.StructField("job_bag_number", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("campaign_start_dt", T.DateType()),
        T.StructField("campaign_end_dt", T.DateType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("booking_id", T.StringType()),
        T.StructField("subchannel_name", T.StringType())
    ])

    # Create test data
    campaign_sat_data = [("NK1_001", "JOB001")]
    campaign_link_data = [("NK1_001", "CH_NK1_001")]

    measures_data = """
    {
        "conversion": {
            "acquired": 2,
            "instore": 2,
            "lapsed": 0,
            "online": 0,
            "percentage": 0,
            "retained": 0,
            "totals": 2
        },
        "engagement": {
            "comments": 0,
            "post_engagements": 0,
            "post_reactions": 0,
            "shares": 0
        },
        "externals": {
            "cpa": 0,
            "media_spend": 0
        },
        "internals": {
            "cpa": 0,
            "cpm_actual": 0,
            "cpm_booked": 7.5,
            "media_spend": 0
        },
        "sales": {
            "instore": 6,
            "online": 0,
            "spend_per_customer": 3,
            "total": 6
        },
        "summary": {
            "clicks": 10,
            "conversionRate": null,
            "ctr": 0,
            "frequency": 0,
            "impressions": 0,
            "reach": 100
        },
        "video": {
            "cost_per_completed_view": 0,
            "video_completed_views": 0,
            "video_completion_rate": 0,
            "video_views": 0
        }
    }
    """

    measures_dict = {
        "conversion": {"acquired": 2, "instore": 2, "lapsed": 0, "online": 0, "percentage": 0, "retained": 0, "totals": 2},
        "engagement": {"comments": 0, "post_engagements": 0, "post_reactions": 0, "shares": 0},
        "externals": {"cpa": 0, "media_spend": 0},
        "internals": {"cpa": 0, "cpm_actual": 0, "cpm_booked": 7.5, "media_spend": 0},
        "sales": {"instore": 6, "online": 0, "spend_per_customer": 3, "total": 6},
        "summary": {"clicks": 0, "conversionRate": None, "ctr": 0, "frequency": 0, "impressions": 0, "reach": 0},
        "video": {"cost_per_completed_view": 0, "video_completed_views": 0, "video_completion_rate": 0, "video_views": 0}
    }

    # Convert dict to JSON string
    measures_data = json.dumps(measures_dict)

    insights_data = [
        ("CH_NK1_001", date(2023, 1, 1), date(2023, 1, 31), "INSIGHT_001", "LINE_001",
         datetime(2023, 2, 1, 10, 0, 0), measures_data)  # <-- JSON string here
    ]

    unified_data = [
        ("JOB001", "Meta", date(2023, 1, 1), date(2023, 1, 31), "Digital", "BOOK001", "Facebook")
    ]

    # Create DataFrames
    campaign_sat_df = create_test_df(spark, campaign_sat_data, campaign_sat_schema)
    campaign_link_df = create_test_df(spark, campaign_link_data, campaign_link_schema)
    insights_df = create_test_df(spark, insights_data, insights_schema)
    unified_df = create_test_df(spark, unified_data, unified_schema)

    # Process data
    result = meta_processor(campaign_sat_df, campaign_link_df, insights_df, unified_df)
    results = result.collect()

    # Verify results
    assert len(results) == 1
    row = results[0]
    assert row["campaign_id"] == "JOB001"
    assert row["reach"] == 0
    assert row["clicks"] == 0
    assert row["impressions"] == 0
    assert row["sales"] == 6
    assert row["conversions"] == 2
    assert row["media_spend_amt"] == 0
    assert row["channel_name"] == "Meta"
    assert row["subchannel_name"] == "Facebook"


def test_youtube_processor_multiple_campaigns(spark_session):
    """Test with multiple campaigns and verify exact expected output"""
    spark = spark_session
    # Input Schemas
    media_schema = T.StructType([
        T.StructField("jobbag_id", T.StringType()),
        T.StructField("line_item_id", T.StringType()),
        T.StructField("clicks", T.LongType()),
        T.StructField("impressions", T.LongType()),
        T.StructField("total_conversions", T.LongType()),
        T.StructField("campaign_date", T.DateType()),
        T.StructField("run_at", T.TimestampType()),
        T.StructField("revenue", T.DoubleType()),
        T.StructField("device_type", T.StringType()),
        T.StructField("time_of_day", T.StringType()),
    ])

    order_schema = T.StructType([
        T.StructField("line_item_id", T.StringType()),
        T.StructField("total_reach", T.LongType()),
        T.StructField("country", T.StringType()),
        T.StructField("date_from", T.DateType()),
        T.StructField("date_until", T.DateType())
    ])

    unified_schema = T.StructType([
        T.StructField("campaign_id", T.StringType()),
        T.StructField("job_bag_number", T.StringType()),
        T.StructField("campaign_start_dt", T.DateType()),
        T.StructField("campaign_end_dt", T.DateType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("booking_id", T.StringType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("subchannel_name", T.StringType())
    ])

    # Test Data (3 unified campaigns)
    unified_data = [
        # Matching campaign
        ("10", "JOB001", date(2023, 1, 1), date(2023, 1, 31),
         "YouTube", "BOOK001", "Digital", "YouTube|TrueView"),
        # Non-matching date range
        ("30", "JOB002", date(2023, 2, 1), date(2023, 2, 28),
         "YouTube", "BOOK002", "Digital", "YouTube|Bumper"),
        # Matching dates but no media data
        ("40", "JOB003", date(2023, 1, 1), date(2023, 1, 31),
         "YouTube", "BOOK003", "Performance", "YouTube|Discovery")
    ]

    media_data = [
        ("JOB001", "LINE001", 100, 1000, 10, date(2023, 1, 15),
         datetime(2023, 1, 16, 10, 0, 0), 500.0, "iPhone16", "10:00"),
        ("JOB001", "LINE001", 50, 500, 5, date(2023, 1, 16),
         datetime(2023, 1, 17, 11, 0, 0), 250.0, "Samsung Galaxy", "20:00")
    ]

    order_data = [
        ("LINE001", 5000, "GB", date(2023, 1, 1), date(2023, 1, 31))
    ]

    floodlight_data = [
        ("LINE001", 100.0, date(2023, 1, 15)),
        ("LINE001", 150.0, date(2023, 1, 16))
    ]

    # Create DataFrames
    media_df = create_test_df(spark, media_data, media_schema)
    order_df = create_test_df(spark, order_data, order_schema)
    floodlight_df = create_test_df(spark, floodlight_data,
                                   T.StructType([
                                       T.StructField("line_item_id", T.StringType()),
                                       T.StructField("spend", T.DoubleType()),
                                       T.StructField("campaign_date", T.DateType())
                                   ]))
    unified_df = create_test_df(spark, unified_data, unified_schema)

    # Process data
    result = youtube_processor(media_df, order_df, floodlight_df, unified_df)

    # Define EXPECTED OUTPUT Schema
    expected_schema = T.StructType([
        T.StructField("campaign_id", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("reach", T.LongType()),
        T.StructField("clicks", T.LongType()),
        T.StructField("impressions", T.LongType()),
        T.StructField("sales", T.LongType()),
        T.StructField("conversions", T.LongType()),
        T.StructField("booking_id", T.StringType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("media_spend_amt", T.LongType())
    ])

    # Expected Data - only JOB001 should appear with aggregated values
    expected_data = [
        (
            "JOB001",                    # campaign_id
            "YouTube",                   # channel_name
            "YouTube",                   # subchannel_name (after cleaning)
            5000,                        # reach (from order data)
            150,                         # clicks (100 + 50)
            1500,                        # impressions (1000 + 500)
            0,                           # sales
            15,                          # conversions (10 + 5)
            "BOOK001",                   # booking_id
            "Digital",                   # marketing_type
            750                          # media_spend_amt (500 + 250)
        )
    ]

    expected_df = create_test_df(spark, expected_data, expected_schema)

    # 2. Collect and compare data
    result_data = sorted(result.collect(), key=lambda x: x["campaign_id"])
    expected_data = expected_df.collect()

    assert len(result_data) == len(expected_data)

    # 3. Compare each field for the single expected row
    result_row = result_data[0]
    expected_row = expected_data[0]

    assert result_row["campaign_id"] == expected_row["campaign_id"]
    assert result_row["channel_name"] == expected_row["channel_name"]
    assert result_row["subchannel_name"] == expected_row["subchannel_name"]
    assert result_row["reach"] == expected_row["reach"]
    assert result_row["clicks"] == expected_row["clicks"]
    assert result_row["impressions"] == expected_row["impressions"]
    assert result_row["sales"] == expected_row["sales"]
    assert result_row["conversions"] == expected_row["conversions"]
    assert result_row["booking_id"] == expected_row["booking_id"]
    assert result_row["marketing_type"] == expected_row["marketing_type"]
    assert result_row["media_spend_amt"] == expected_row["media_spend_amt"]


@pytest.fixture
def sample_dataframes(spark_session, camp_request_link_schema):
    # Schema for camp_request_link_df
    spark = spark_session
    camp_request_link_df = spark.createDataFrame([
        (
            "CAMP1",
            date(2025, 8, 1),
            100.0, 2, 1000, 50
        ),
        (
            "CAMP1",
            date(2025, 8, 3),
            200.0, 3, 1500, 70
        ),
    ], schema=camp_request_link_schema)

    # Schema for unified_campaign_df
    unified_campaign_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("job_bag_number", T.StringType(), True)
    ])

    unified_campaign_df = spark.createDataFrame([
        (
            "CAMP1",
            date(2025, 8, 1),
            date(2025, 8, 5),
            "Online", "B001", "Promo", "J001"
        )
    ], schema=unified_campaign_schema)

    # Schema for campaign_citcam_sat_df
    campaign_citcam_sat_schema = T.StructType([
        T.StructField("campaign_placements", T.StringType(), True),
        T.StructField("advertising_campaign_nk1", T.StringType(), True)
    ])

    campaign_citcam_sat_df = spark.createDataFrame([
        ("Main-Sub1", "CAMP1"),
    ], schema=campaign_citcam_sat_schema)

    # Schema for user_journey_data_filtered
    user_journey_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True)
    ])

    user_journey_data_filtered = spark.createDataFrame([
        ("CAMP1", "B001", "Online", "Sub1", "L001"),
        ("CAMP1", "B001", "Online", "Sub1", "L002"),
    ], schema=user_journey_schema)

    return camp_request_link_df, unified_campaign_df, campaign_citcam_sat_df, user_journey_data_filtered


@pytest.fixture
def measurement_campaign_execution_data(spark_session):
    """Create test data for measurement_campaign_execution_df"""
    schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("job_status", T.StringType(), True),
        T.StructField("LOAD_TS", T.TimestampType(), True)
    ])

    data = [
        ("BOOK_001", "During", "In-progress", datetime(2024, 1, 15, 10, 0, 0)),
        ("BOOK_002", "During", "In-progress", datetime(2024, 1, 15, 11, 0, 0)),
        ("BOOK_003", "During", "Completed", datetime(2024, 1, 14, 9, 0, 0)),
        ("BOOK_004", "After", "In-progress", datetime(2024, 1, 15, 12, 0, 0))
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def user_journey_offer_data(spark_session):
    """Create test data for user_journey_offer_df"""
    schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("isconversion", T.IntegerType(), True),
        T.StructField("net_sales_amt", T.DoubleType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_type", T.StringType(), True),
    ])

    data = [
        ("BOOK_001", "During", "CAMP_001", "USER_001", "JOURNEY_001", 1, 150.0, "Meta", "Facebook", datetime(2024, 1, 15, 10, 0, 0), "instore"),
        ("BOOK_001", "During", "CAMP_001", "USER_002", "JOURNEY_002", 0, 0.0, "Meta", "Instagram", datetime(2024, 1, 15, 10, 0, 0), "onsite"),
        ("BOOK_002", "During", "CAMP_002", "USER_003", "JOURNEY_003", 1, 200.0, "YouTube", "Video", datetime(2024, 1, 15, 11, 0, 0), "offsite"),
        ("BOOK_002", "During", "CAMP_003", "USER_004", "JOURNEY_004", 0, 0.0, "Coupon at Till", "Digital", datetime(2024, 1, 15, 11, 0, 0), "targeted_media")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def unified_campaign_data(spark_session):
    """Create test data for unified_campaign_df"""
    schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("LOAD_TS", T.TimestampType(), True)
    ])

    data = [
        ("CAMP_001", "BOOK_001", "Meta", "Facebook", "Social", 1000.0, date(2024, 1, 10), date(2024, 1, 20), "JOB_001", datetime(2024, 1, 15, 10, 0, 0)),
        ("CAMP_002", "BOOK_002", "YouTube", "Video", "Digital", 2000.0, date(2024, 1, 12), date(2024, 1, 22), "JOB_002", datetime(2024, 1, 15, 11, 0, 0)),
        ("CAMP_003", "BOOK_002", "Coupon at Till", "Digital", "In-store", 500.0, date(2024, 1, 11), date(2024, 1, 21), "JOB_003", datetime(2024, 1, 15, 11, 0, 0))
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def digital_trading_campaign_sat_data(spark_session):
    """Create test data for digital_trading_campaign_sat_df (Meta)"""
    schema = T.StructType([
        T.StructField("digital_trading_campaign_nk1", T.StringType(), True),
        T.StructField("JOB_BAG_ID", T.StringType(), True)
    ])

    data = [
        ("CAMP_001", "JOB_001"),
        ("CAMP_002", "JOB_002")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def digital_trading_campaign_link_data(spark_session):
    """Create test data for digital_trading_campaign_link_df (Meta)"""
    schema = T.StructType([
        T.StructField("digital_trading_campaign_nk1", T.StringType(), True),
        T.StructField("digital_trading_campaign_channel_nk1", T.StringType(), True)
    ])

    data = [
        ("CAMP_001", "CHANNEL_001"),
        ("CAMP_002", "CHANNEL_002")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def digital_trading_lineitem_insight_data(spark_session):
    """Create test data for digital_trading_lineitem_facebook_insight_df (Meta)"""
    schema = T.StructType([
        T.StructField("digital_trading_campaign_nk1", T.StringType(), True),
        T.StructField("reporting_start_dt", T.DateType(), True),
        T.StructField("reporting_end_dt", T.DateType(), True),
        T.StructField("record_arrival_ts", T.TimestampType(), True),
        T.StructField("digital_trading_insight_id", T.StringType(), True),
        T.StructField("digital_trading_lineitem_nk1", T.StringType(), True),
        T.StructField("measures", T.MapType(T.StringType(), T.MapType(T.StringType(), T.StringType())), True)
    ])

    # Create nested map structure for measures
    measures_data = {
        "summary": {"reach": "1000", "clicks": "50", "impressions": "5000"},
        "sales": {"total": "1500"},
        "conversion": {"totals": "25"},
        "internals": {"media_spend": "800"}
    }

    data = [
        ("CHANNEL_001", date(2024, 1, 10), date(2024, 1, 20), datetime(2024, 1, 15, 10, 0, 0), "INSIGHT_001", "LINE_001", measures_data),
        ("CHANNEL_002", date(2024, 1, 12), date(2024, 1, 22), datetime(2024, 1, 15, 11, 0, 0), "INSIGHT_002", "LINE_002", measures_data)
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def dv360_media_report_data(spark_session):
    """Create test data for dv360_media_report_df (YouTube)"""
    schema = T.StructType([
        T.StructField("jobbag_id", T.StringType(), True),
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("time_of_day", T.StringType(), True),
        T.StructField("device_type", T.StringType(), True),
        T.StructField("clicks", T.IntegerType(), True),
        T.StructField("impressions", T.IntegerType(), True),
        T.StructField("total_conversions", T.IntegerType(), True),
        T.StructField("revenue", T.DoubleType(), True),
        T.StructField("run_at", T.TimestampType(), True),
        T.StructField("subchannel_name", T.StringType(), True)
    ])

    data = [
        ("JOB_002", "LINE_002", date(2024, 1, 15), "Morning", "Mobile", 30, 3000, 10, 1200.0, datetime(2024, 1, 15, 11, 0, 0), "YouTube|Video"),
        ("JOB_002", "LINE_002", date(2024, 1, 16), "Evening", "Desktop", 20, 2000, 5, 800.0, datetime(2024, 1, 16, 11, 0, 0), "YouTube|Premium")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def dv360_order_report_data(spark_session):
    """Create test data for dv360_order_report_df (YouTube)"""
    schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("date_from", T.DateType(), True),
        T.StructField("date_until", T.DateType(), True),
        T.StructField("country", T.StringType(), True),
        T.StructField("total_reach", T.IntegerType(), True)
    ])

    data = [
        ("LINE_002", date(2024, 1, 12), date(2024, 1, 22), "GB", 800),
        ("LINE_003", date(2024, 1, 12), date(2024, 1, 22), "US", 1200)
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def dv360_floodlight_report_data(spark_session):
    """Create test data for dv360_floodlight_report_df (YouTube)"""
    schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("spend", T.DoubleType(), True)
    ])

    data = [
        ("LINE_002", date(2024, 1, 15), 600.0),
        ("LINE_002", date(2024, 1, 16), 400.0)
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def camp_request_link_data(spark_session, camp_request_link_schema):
    """Create test data for camp_request_link_df (Citrus)"""
    data = [
        ("CAMP_004", date(2024, 1, 15), 300.0, 5, 1000, 25)
    ]

    return spark_session.createDataFrame(data, camp_request_link_schema)


@pytest.fixture
def campaign_citcam_sat_data(spark_session):
    """Create test data for campaign_citcam_sat_df (Citrus)"""
    schema = T.StructType([
        T.StructField("advertising_campaign_nk1", T.StringType(), True),
        T.StructField("campaign_placements", T.StringType(), True)
    ])

    data = [
        ("CAMP_004", "GOL-Display")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def meta_campaign_data(spark_session):
    """Create test data for campaign_citcam_sat_df (Citrus)"""
    schema = T.StructType([
        T.StructField("loyalty_id", T.StringType(), True)
    ])

    data = [
        ("CAMP_004",)
    ]
    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def mock_processors():
    """Mock the individual processor functions"""
    with patch('spark_pipeline.reach_engagement.reach_engagement.meta_processor') as mock_meta, \
            patch('spark_pipeline.reach_engagement.reach_engagement.youtube_processor') as mock_youtube, \
            patch('spark_pipeline.reach_engagement.reach_engagement.citrus_processor') as mock_citrus, \
            patch('spark_pipeline.reach_engagement.reach_engagement.calculate_reach') as mock_calculate_reach, \
            patch('spark_pipeline.reach_engagement.reach_engagement.fetch_in_progress_campaigns') as mock_fetch_campaigns, \
            patch('spark_pipeline.reach_engagement.reach_engagement.get_latest_data_for_campaigns') as mock_get_latest:

        yield {
            'meta_processor': mock_meta,
            'youtube_processor': mock_youtube,
            'citrus_processor': mock_citrus,
            'calculate_reach': mock_calculate_reach,
            'fetch_in_progress_campaigns': mock_fetch_campaigns,
            'get_latest_data_for_campaigns': mock_get_latest
        }


def create_mock_processor_outputs(spark_session):
    """Create mock outputs for each processor"""
    base_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("reach", T.IntegerType(), True),
        T.StructField("clicks", T.IntegerType(), True),
        T.StructField("impressions", T.IntegerType(), True),
        T.StructField("sales", T.DoubleType(), True),
        T.StructField("conversions", T.IntegerType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True)
    ])

    meta_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("reach", T.IntegerType(), True),
        T.StructField("clicks", T.IntegerType(), True),
        T.StructField("impressions", T.IntegerType(), True),
        T.StructField("sales", T.DoubleType(), True),
        T.StructField("conversions", T.IntegerType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("media_spend_amt", T.IntegerType(), True)
    ])

    # meta_schema = base_schema.add(T.StructField("media_spend_amt", T.IntegerType(), True))

    # Meta processor output
    meta_data = [
        ("CAMP_001", "Meta", "Meta", 1000, 50, 5000, 1500.0, 25, "BOOK_001", "Offsite", 800)
    ]
    meta_df = spark_session.createDataFrame(meta_data, meta_schema)

    # youtube_schema = base_schema.add(T.StructField("media_spend_amt", T.IntegerType(), True))
    youtube_schema = meta_schema
    # YouTube processor output
    youtube_data = [
        ("CAMP_002", "YouTube", "Video", 800, 50, 5000, 1000.0, 15, "BOOK_002", "Offsite", 1200)
    ]
    youtube_df = spark_session.createDataFrame(youtube_data, youtube_schema)

    # In-store processor output (calculate_reach)
    instore_data = [
        ("CAMP_005", "Magazine", "Print", 500, None, None, 300.0, 8, "BOOK_003", "In-store")
    ]
    instore_df = spark_session.createDataFrame(instore_data, base_schema)

    # Citrus processor output
    citrus_data = [
        ("CAMP_004", "GOL", "Display", 600, 30, 2000, 400.0, 12, "BOOK_001", "Digital")
    ]
    citrus_df = spark_session.createDataFrame(citrus_data, base_schema)

    # Coupon processor output (calculate_reach)
    coupon_data = [
        ("CAMP_003", "Coupon at Till", "Digital", 300, None, None, 100.0, 5, "BOOK_002", "In-store")
    ]
    coupon_df = spark_session.createDataFrame(coupon_data, base_schema)

    return {
        'meta': meta_df,
        'youtube': youtube_df,
        'instore': instore_df,
        'citrus': citrus_df,
        'coupon': coupon_df
    }

# ---------------------------------------------------------------------
#                         SHARED HELPERS
# ---------------------------------------------------------------------


USER_JOURNEY_SCHEMA = T.StructType([
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("campaign_duration", T.StringType(), True),
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("loyalty_id", T.StringType(), True),
    T.StructField("userjourney_id", T.StringType(), True),
    T.StructField("isconversion", T.IntegerType(), True),
    T.StructField("net_sales_amt", T.DoubleType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("load_ts", T.TimestampType(), True),
    T.StructField("marketing_type", T.StringType(), True)
])

UNIFIED_CAMPAIGN_SCHEMA = T.StructType([
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("marketing_type", T.StringType(), True),
    T.StructField("media_spend_amt", T.DoubleType(), True),
    T.StructField("campaign_start_dt", T.DateType(), True),
    T.StructField("campaign_end_dt", T.DateType(), True),
    T.StructField("job_bag_number", T.StringType(), True),
    T.StructField("load_ts", T.TimestampType(), True)
])

# ---------------------------------------------------------------------
#                     PARAMETERIZED DATA SETS
# ---------------------------------------------------------------------

USER_JOURNEY_DATASETS = {
    "offsite_only": [
        ("BOOK_001", "During", "CAMP_001", "USER_001", "J1", 1, 150.0,
         "Meta", "Meta", datetime(2024, 1, 15, 10), "offsite"),
        ("BOOK_001", "During", "CAMP_001", "USER_002", "J2", 0, 0.0,
         "Meta", "Instagram", datetime(2024, 1, 15, 10), "offsite"),
        ("BOOK_002", "During", "CAMP_002", "USER_003", "J3", 1, 200.0,
         "Display", "DV360", datetime(2024, 1, 15, 11), "offsite"),
    ],
    "mixed_marketing_type": [
        ("BOOK_001", "During", "CAMP_001", "USER_001", "J1", 1, 150.0,
         "Meta", "Meta", datetime(2024, 1, 15, 10), "offsite"),
        ("BOOK_001", "During", "CAMP_001", "USER_002", "J2", 0, 0.0,
         "Meta", "Instagram", datetime(2024, 1, 15, 10), "offsite"),
        ("BOOK_002", "During", "CAMP_002", "USER_003", "J3", 1, 200.0,
         "Coupon at Till", "Digital", datetime(2024, 1, 15, 11), "In-store")
    ],
    "non_offsite_only": [
        ("BOOK_002", "During", "CAMP_002", "USER_003", "J3", 1, 200.0,
         "Coupon at Till", "Digital", datetime(2024, 1, 15, 11), "In-store")
    ],
}

UNIFIED_CAMPAIGN_DATASETS = {
    "offsite_only": [
        ("CAMP_001", "BOOK_001", "Meta", "Meta", "offsite", 1000.0,
         date(2024, 1, 10), date(2024, 1, 20), "JOB_001",
         datetime(2024, 1, 15, 10)),
        ("CAMP_002", "BOOK_002", "Display", "DV360", "offsite", 2000.0,
         date(2024, 1, 10), date(2024, 1, 20), "JOB_001",
         datetime(2024, 1, 15, 10)),
    ],
    "mixed_marketing_type": [
        ("CAMP_001", "BOOK_001", "Meta", "Meta", "offsite", 1000.0,
         date(2024, 1, 10), date(2024, 1, 20), "JOB_001",
         datetime(2024, 1, 15, 10)),
        ("CAMP_002", "BOOK_002", "Display", "DV360", "offsite", 2000.0,
         date(2024, 1, 10), date(2024, 1, 20), "JOB_001",
         datetime(2024, 1, 15, 10)),
        ("CAMP_003", "BOOK_002", "Coupon at Till", "Digital", "In-store",
         500.0, date(2024, 1, 11), date(2024, 1, 21), "JOB_003",
         datetime(2024, 1, 15, 11))
    ],
    "non_offsite_only": [
        ("CAMP_003", "BOOK_002", "Coupon at Till", "Digital", "In-store",
         500.0, date(2024, 1, 11), date(2024, 1, 21), "JOB_003",
         datetime(2024, 1, 15, 11))
    ],
}


def create_df(spark, schema, rows):
    return spark.createDataFrame(rows, schema)

# ---------------------------------------------------------------------
#                   PARAMETERIZED FIXTURE FACTORIES
# ---------------------------------------------------------------------


@pytest.fixture
def user_journey_data_factory(spark_session):
    def _create(data):
        return create_df(spark_session, USER_JOURNEY_SCHEMA, data)
    return _create


@pytest.fixture
def unified_campaign_data_factory(spark_session):
    def _create(data):
        return create_df(spark_session, UNIFIED_CAMPAIGN_SCHEMA, data)
    return _create


@pytest.mark.parametrize(
    "dataset_key",
    ["offsite_only", "mixed_marketing_type", "non_offsite_only"]
)
def test_process_all_campaigns_variations(
    spark_session,
    measurement_campaign_execution_data,
    digital_trading_campaign_sat_data,
    digital_trading_campaign_link_data,
    digital_trading_lineitem_insight_data,
    dv360_media_report_data,
    dv360_order_report_data,
    dv360_floodlight_report_data,
    camp_request_link_data,
    campaign_citcam_sat_data,
    meta_campaign_data,
    mock_processors,
    user_journey_data_factory,
    unified_campaign_data_factory,
    dataset_key
):
    # Build DataFrames for this scenario
    user_journey_df = user_journey_data_factory(
        USER_JOURNEY_DATASETS[dataset_key]
    )
    unified_campaign_dtf = unified_campaign_data_factory(
        UNIFIED_CAMPAIGN_DATASETS[dataset_key]
    )

    # Mock processor behaviours
    mock_outputs = create_mock_processor_outputs(spark_session)
    mock_processors['fetch_in_progress_campaigns'].return_value = create_df(
        spark_session,
        T.StructType([
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("campaign_duration", T.StringType(), True),
        ]),
        [("BOOK_001", "During"), ("BOOK_002", "During")]
    )
    mock_processors['get_latest_data_for_campaigns'].return_value = user_journey_df
    mock_processors['meta_processor'].return_value = mock_outputs["meta"]
    mock_processors['youtube_processor'].return_value = mock_outputs["youtube"]
    mock_processors['citrus_processor'].return_value = mock_outputs["citrus"]

    def reach_side_effect(journey, campaigns, group_by_column=None, *args, **kwargs):
        group = group_by_column if group_by_column is not None else (args[2] if len(args) > 2 else None)
        return (mock_outputs["instore"]
                if group == "marketing_type"
                else mock_outputs["coupon"])

    mock_processors["calculate_reach"].side_effect = reach_side_effect

    correlation_id = str(uuid.uuid4())

    # Execute function
    result_df = process_all_campaigns(
        measurement_campaign_execution_data,
        user_journey_df,
        digital_trading_campaign_sat_data,
        digital_trading_campaign_link_data,
        digital_trading_lineitem_insight_data,
        dv360_media_report_data,
        dv360_order_report_data,
        dv360_floodlight_report_data,
        camp_request_link_data,
        campaign_citcam_sat_data,
        meta_campaign_data,
        unified_campaign_dtf,
        correlation_id
    )

    # Validations
    assert isinstance(result_df, DataFrame)
    assert result_df.count() > 0

    result_df.show(truncate=False)

    expected_columns = {
        "campaign_id", "channel_name", "subchannel_name", "reach_cnt",
        "dedup_campaign_reach", "clicks_cnt", "impressions_cnt",
        "sales_amt", "conversions_cnt", "booking_id", "marketing_type",
        "media_spend_amt", "engagement_ctr_pct", "load_ts", "job_run_id"
    }
    assert expected_columns.issubset(result_df.columns)

    # Check load_ts populated
    assert (result_df.filter(F.col("load_ts").isNotNull()).count() ==
            result_df.count())

    # Job run ID check
    job_run_values = [
        row["job_run_id"]
        for row in result_df.select("job_run_id").distinct().collect()
    ]
    assert job_run_values == [correlation_id]

    # Conditional processor usage
    if unified_campaign_dtf.filter(
        F.col("channel_name").rlike("(?i)meta")
    ).count() > 0:
        mock_processors["meta_processor"].assert_called_once()
    else:
        mock_processors["meta_processor"].assert_not_called()

    youtube_count = unified_campaign_dtf.filter(
        F.col("channel_name").rlike("(?i)youtube")
    ).count()
    if youtube_count > 0:
        mock_processors["youtube_processor"].assert_called()
    else:
        mock_processors["youtube_processor"].assert_not_called()


def test_entrypoint_invocation_point(spark_session):
    with patch(
            "spark_pipeline.reach_engagement.reach_engagement.prepare_reach_engagement") as mock_prepare:
        args = [
            "--measurement-campaign-execution-path", "s3a://input/measurement_campaign_execution",
            "--digital-trading-campaign-dmfbca-sat-path", "s3a://input/digital_trading_campaign_sat",
            "--digital-trading-campaign-channel-dmfbca-link-path", "s3a://input/digital_trading_campaign_link",
            "--digital-trading-lineitem-insight-dmfbin-link-path", "s3a://input/digital_trading_lineitem_facebook_insight_path",
            "--media-report-path", "s3a://input/media_report",
            "--unique-reach-lineitem-report-path", "s3a://input/unique_reach_lineitem_report",
            "--floodlight-report-path", "s3a://input/floodlight_report",
            "--user-journey-offer-path", "s3a://input/user_journey_offer",
            "--advertising-campaign-request-realised-link-path", "s3a://input/advertise_request_realised",
            "--advertising-campaign-citcam-sat-path", "s3a://input/advertising_campaign_citcam_sat",
            "--meta-data-path", "s3a://input/meta_data_path",
            "--unified-campaigns-path", "s3a://input/unified_campaign",
            "--output-reporting-path", "s3a://output/reach_engagement_reporting",
            "--correlation-id", "mock-correlation",
            "--run-date", "2024-12-31",
            "--run-type", "test128",
            "--slack-topic-arn", "reach_engagement_topic_arn",
        ]
        entrypoint(spark_session, command_line_args=args)

        mock_prepare.assert_called_once_with(
            spark=spark_session,
            measurement_campaign_execution_path="s3a://input/measurement_campaign_execution",
            user_journey_offer_path="s3a://input/user_journey_offer",
            unified_campaigns_path="s3a://input/unified_campaign",
            digital_trading_campaign_dmfbca_sat_path="s3a://input/digital_trading_campaign_sat",
            digital_trading_campaign_channel_dmfbca_link_path="s3a://input/digital_trading_campaign_link",
            digital_trading_lineitem_insight_dmfbin_link_path="s3a://input/digital_trading_lineitem_facebook_insight_path",
            media_report_path="s3a://input/media_report",
            unique_reach_lineitem_report_path="s3a://input/unique_reach_lineitem_report",
            floodlight_report_path="s3a://input/floodlight_report",
            advertising_campaign_request_realised_link_path="s3a://input/advertise_request_realised",
            advertising_campaign_citcam_sat_path="s3a://input/advertising_campaign_citcam_sat",
            meta_data_path="s3a://input/meta_data_path",
            output_reporting_path="s3a://output/reach_engagement_reporting",
            correlation_id="mock-correlation",
            run_date="2024-12-31",
            run_type="test128",
            slack_topic_arn="reach_engagement_topic_arn",
        )


@pytest.fixture
def mock_spark():
    """Create a mock SparkSession."""
    spark = Mock(spec=SparkSession)
    spark.read = Mock()
    spark.read.parquet = Mock()
    return spark


@pytest.fixture
def mock_dataframes():
    """Create mock DataFrames for all input sources."""
    dfs = {}

    # Create mock DataFrames with proper chaining support
    for df_name in [
        'measurement_campaign_execution',
        'digital_trading_campaign_dmfbca_sat',
        'digital_trading_campaign_channel_dmfbca_link',
        'digital_trading_lineitem_facebook_insight',
        'media_report',
        'unique_reach_lineitem_report',
        'floodlight_report',
        'user_journey_offer',
        'advertising_campaign_request_realised_link',
        'advertising_campaign_citcam_sat',
        'unified_campaign',
        'meta_campaigns'
    ]:
        mock_df = Mock(spec=DataFrame)
        mock_df.select.return_value = mock_df
        mock_df.selectExpr.return_value = mock_df
        mock_df.withColumn.return_value = mock_df
        mock_df.write = Mock()
        mock_df.write.mode.return_value = mock_df.write
        mock_df.write.parquet = Mock()
        dfs[df_name] = mock_df

    return dfs


@pytest.fixture
def test_paths():
    """Provide test S3 paths."""
    return {
        'measurement_campaign_execution_path': 's3://test/measurement_campaign_execution/',
        'user_journey_offer_path': 's3://test/user_journey_offer/',
        'unified_campaigns_path': 's3://test/unified_campaigns/',
        'digital_trading_campaign_dmfbca_sat_path': 's3://test/digital_trading_campaign_dmfbca_sat/',
        'digital_trading_campaign_channel_dmfbca_link_path': 's3://test/digital_trading_campaign_channel_dmfbca_link/',
        'digital_trading_lineitem_insight_dmfbin_link_path': 's3://test/digital_trading_lineitem_insight_dmfbin_link/',
        'media_report_path': 's3://test/media_report/',
        'unique_reach_lineitem_report_path': 's3://test/unique_reach_lineitem_report/',
        'floodlight_report_path': 's3://test/floodlight_report/',
        'advertising_campaign_request_realised_link_path': 's3://test/advertising_campaign_request_realised_link/',
        'advertising_campaign_citcam_sat_path': 's3://test/advertising_campaign_citcam_sat/',
        'output_reporting_path': 's3://test/output_reporting/',
        'meta_data_path': 's3://test/meta_data/',
        'correlation_id': 'test-correlation-123',
        'run_date': '2024-01-01',
        'run_type': 'daily',
        'slack_topic_arn': 'arn:aws:sns:us-east-1:123456789:test-topic'
    }


@patch('spark_pipeline.reach_engagement.reach_engagement.spark_s3_overwrite')
@patch('spark_pipeline.reach_engagement.reach_engagement.SlackMessenger')
@patch('spark_pipeline.reach_engagement.reach_engagement.process_all_campaigns')
@patch('spark_pipeline.reach_engagement.reach_engagement.datetime')
def test_prepare_reach_engagement_success(
    mock_datetime,
    mock_process_campaigns,
    mock_slack_messenger,
    _,
    mock_spark,
    mock_dataframes,
    test_paths
):
    """Test successful execution of prepare_reach_engagement."""
    # Setup
    from spark_pipeline.reach_engagement.reach_engagement import prepare_reach_engagement
    # Mock datetime
    mock_now = datetime(2024, 1, 1, 12, 0, 0)
    mock_datetime.now.return_value = mock_now

    # Setup spark.read.parquet to return appropriate mock DataFrames
    def get_mock_df(path):
        if 'measurement_campaign_execution' in path:
            return mock_dataframes['measurement_campaign_execution']
        elif 'user_journey_offer' in path:
            return mock_dataframes['user_journey_offer']
        elif 'unified_campaigns' in path:
            return mock_dataframes['unified_campaign']
        elif 'digital_trading_campaign_dmfbca_sat' in path:
            return mock_dataframes['digital_trading_campaign_dmfbca_sat']
        elif 'digital_trading_campaign_channel_dmfbca_link' in path:
            return mock_dataframes['digital_trading_campaign_channel_dmfbca_link']
        elif 'digital_trading_lineitem_insight_dmfbin_link' in path:
            return mock_dataframes['digital_trading_lineitem_facebook_insight']
        elif 'media_report' in path:
            return mock_dataframes['media_report']
        elif 'unique_reach_lineitem_report' in path:
            return mock_dataframes['unique_reach_lineitem_report']
        elif 'floodlight_report' in path:
            return mock_dataframes['floodlight_report']
        elif 'advertising_campaign_request_realised_link' in path:
            return mock_dataframes['advertising_campaign_request_realised_link']
        elif 'advertising_campaign_citcam_sat' in path:
            return mock_dataframes['advertising_campaign_citcam_sat']
        elif 'meta_data' in path:
            return mock_dataframes['meta_campaigns']
        return Mock(spec=DataFrame)

    mock_spark.read.parquet.side_effect = get_mock_df

    # Mock booking_ids collection
    mock_dataframes['measurement_campaign_execution'].first.return_value = {
        'booking_ids': ['BOOK-001', 'BOOK-002']
    }

    # Mock process_all_campaigns return value
    mock_result_df = Mock(spec=DataFrame)
    mock_result_df.withColumn.return_value = mock_result_df
    mock_result_df.select.return_value = mock_result_df
    mock_result_df.write = Mock()
    mock_result_df.write.mode.return_value = mock_result_df.write
    mock_result_df.write.parquet = Mock()
    mock_process_campaigns.return_value = mock_result_df

    # Execute
    result = prepare_reach_engagement(
        mock_spark,
        **test_paths
    )

    # Assertions
    assert result == mock_result_df
    mock_process_campaigns.assert_called_once()
    mock_slack_messenger.assert_called_once_with(
        topic_arn=test_paths['slack_topic_arn'],
        correlation_id=test_paths['correlation_id']
    )


@patch('spark_pipeline.reach_engagement.reach_engagement.SlackMessenger')
@patch('spark_pipeline.reach_engagement.reach_engagement.process_all_campaigns')
def test_prepare_reach_engagement_with_value_error(
    mock_process_campaigns,
    mock_slack_messenger,
    mock_spark,
    mock_dataframes,
    test_paths
):
    """Test handling of ValueError from process_all_campaigns."""
    from spark_pipeline.reach_engagement.reach_engagement import prepare_reach_engagement
    # Setup

    def get_mock_df(path):
        if 'measurement_campaign_execution' in path:
            return mock_dataframes['measurement_campaign_execution']
        elif 'meta_data' in path:
            return mock_dataframes['meta_campaigns']
        return Mock(spec=DataFrame)

    mock_spark.read.parquet.side_effect = get_mock_df

    # Mock booking_ids
    mock_dataframes['measurement_campaign_execution'].first.return_value = {
        'booking_ids': ['BOOK-001']
    }

    # Mock process_all_campaigns to raise ValueError
    error_message = "Invalid campaign data"
    mock_process_campaigns.side_effect = ValueError(error_message)

    # Mock SlackMessenger instance
    mock_messenger_instance = Mock()
    mock_slack_messenger.return_value = mock_messenger_instance

    # Execute and Assert
    with pytest.raises(ValueError, match=error_message):
        prepare_reach_engagement(
            mock_spark,
            **test_paths
        )

    # Verify Slack notification was sent
    mock_messenger_instance.send_message.assert_called_once()
    call_args = mock_messenger_instance.send_message.call_args
    assert "Reach Engagement failure" in call_args[1]['text']
    assert test_paths['correlation_id'] in call_args[1]['text']


@patch('spark_pipeline.reach_engagement.reach_engagement.spark_s3_overwrite')
@patch('spark_pipeline.reach_engagement.reach_engagement.SlackMessenger')
@patch('spark_pipeline.reach_engagement.reach_engagement.process_all_campaigns')
def test_prepare_reach_engagement_meta_data_file_not_found(
    mock_process_campaigns,
    mock_slack_messenger,
    _,
    mock_spark,
    mock_dataframes,
    test_paths,
    capsys
):
    """Test handling when meta_data file is not found."""
    from spark_pipeline.reach_engagement.reach_engagement import prepare_reach_engagement
    # Setup
    call_count = [0]

    def get_mock_df(path):
        if 'meta_data' in path:
            raise FileNotFoundError(f"No such file: {path}")
        call_count[0] += 1
        if call_count[0] == 1:
            return mock_dataframes['measurement_campaign_execution']
        return Mock(spec=DataFrame)

    mock_spark.read.parquet.side_effect = get_mock_df

    # Mock booking_ids
    mock_dataframes['measurement_campaign_execution'].first.return_value = {
        'booking_ids': ['BOOK-001']
    }

    # Mock successful processing
    mock_result_df = Mock(spec=DataFrame)
    mock_result_df.withColumn.return_value = mock_result_df
    mock_result_df.select.return_value = mock_result_df
    mock_result_df.write = Mock()
    mock_result_df.write.mode.return_value = mock_result_df.write
    mock_process_campaigns.return_value = mock_result_df

    # Execute
    _ = prepare_reach_engagement(
        mock_spark,
        **test_paths
    )

    # Verify error message was printed
    captured = capsys.readouterr()
    assert "Error: File not found" in captured.out
    assert test_paths['meta_data_path'] in captured.out

    # Verify process_all_campaigns was called with None for meta_campaigns_df
    args = mock_process_campaigns.call_args[0]
    assert args[10] is None  # meta_campaigns_df should be None


@patch('spark_pipeline.reach_engagement.reach_engagement.spark_s3_overwrite')
@patch('spark_pipeline.reach_engagement.reach_engagement.SlackMessenger')
@patch('spark_pipeline.reach_engagement.reach_engagement.process_all_campaigns')
def test_prepare_reach_engagement_empty_booking_ids(
    mock_process_campaigns,
    mock_slack_messenger,
    _,
    mock_spark,
    mock_dataframes,
    test_paths
):
    """Test handling when booking_ids list is empty."""
    from spark_pipeline.reach_engagement.reach_engagement import prepare_reach_engagement

    # Create the mock for the collect_set result
    mock_collect_result = Mock(spec=DataFrame)

    # Explicitly create a mock function for first() that returns a dict
    def mock_first():
        return {'booking_ids': None}

    mock_collect_result.first = mock_first

    # Create the measurement_campaign_execution mock
    measurement_execution_mock = Mock(spec=DataFrame)

    # Track which select call this is
    select_calls = []

    def mce_select(*args, **kwargs):
        select_calls.append((args, kwargs))
        # First call: column selection returns self
        # Second call: collect_set returns mock_collect_result
        if len(select_calls) == 1:
            return measurement_execution_mock
        else:
            return mock_collect_result

    measurement_execution_mock.select = mce_select

    # Configure spark.read.parquet
    def get_mock_df(path):
        if 'measurement_campaign_execution' in path:
            return measurement_execution_mock

        # Return generic mocks for other paths
        generic_mock = Mock(spec=DataFrame)
        generic_mock.select = Mock(return_value=generic_mock)
        return generic_mock

    mock_spark.read.parquet = Mock(side_effect=get_mock_df)

    # Mock successful processing
    mock_result_df = Mock(spec=DataFrame)
    mock_result_df.withColumn = Mock(return_value=mock_result_df)
    mock_result_df.select = Mock(return_value=mock_result_df)
    mock_result_df.write = Mock()
    mock_result_df.write.mode = Mock(return_value=mock_result_df.write)
    mock_result_df.write.parquet = Mock()
    mock_process_campaigns.return_value = mock_result_df

    # Execute
    result = prepare_reach_engagement(
        mock_spark,
        **test_paths
    )

    # Verify
    assert result == mock_result_df
    assert mock_process_campaigns.called

    # Verify that select was called twice on measurement_campaign_execution
    assert len(select_calls) == 2
    print(f"Select was called {len(select_calls)} times")


@patch('spark_pipeline.reach_engagement.reach_engagement.spark_s3_overwrite')
@patch('spark_pipeline.reach_engagement.reach_engagement.SlackMessenger')
@patch('spark_pipeline.reach_engagement.reach_engagement.process_all_campaigns')
def test_prepare_reach_engagement_verifies_column_selection(
    mock_process_campaigns,
    mock_slack_messenger,
    _,
    mock_spark,
    mock_dataframes,
    test_paths
):
    """Test that correct columns are selected from each DataFrame."""
    from spark_pipeline.reach_engagement.reach_engagement import prepare_reach_engagement

    # Setup
    mock_dfs = {}
    for name, df in mock_dataframes.items():
        mock_dfs[name] = df

    # Create specific mocks for measurement_campaign_execution to handle multiple select calls
    measurement_execution_mock = Mock(spec=DataFrame)

    # Mock for the booking_ids collection
    mock_collect_result = Mock(spec=DataFrame)
    mock_collect_result.first.return_value = {'booking_ids': ['BOOK-001']}

    # Track select calls
    select_call_count = [0]
    original_select_calls = []

    def mce_select_side_effect(*args, **kwargs):
        select_call_count[0] += 1
        # Store the arguments for verification
        original_select_calls.append((args, kwargs))

        if select_call_count[0] == 1:
            # First call: selecting columns - return self for chaining
            return measurement_execution_mock
        else:
            # Second call: F.collect_set - return the collect result
            return mock_collect_result

    measurement_execution_mock.select.side_effect = mce_select_side_effect

    # Do the same for digital_trading_campaign_dmfbca_sat
    digital_trading_sat_mock = Mock(spec=DataFrame)
    digital_trading_sat_calls = []

    def dt_select_side_effect(*args, **kwargs):
        digital_trading_sat_calls.append((args, kwargs))
        return digital_trading_sat_mock

    digital_trading_sat_mock.select.side_effect = dt_select_side_effect

    def get_mock_df(path):
        if 'measurement_campaign_execution' in path:
            return measurement_execution_mock
        elif 'digital_trading_campaign_dmfbca_sat' in path:
            return digital_trading_sat_mock
        # For all other paths, return a generic mock
        mock = Mock(spec=DataFrame)
        mock.select.return_value = mock
        return mock

    mock_spark.read.parquet.side_effect = get_mock_df

    mock_result_df = Mock(spec=DataFrame)
    mock_result_df.withColumn.return_value = mock_result_df
    mock_result_df.select.return_value = mock_result_df
    mock_result_df.write = Mock()
    mock_result_df.write.mode.return_value = mock_result_df.write
    mock_result_df.write.parquet = Mock()
    mock_process_campaigns.return_value = mock_result_df

    # Execute
    prepare_reach_engagement(mock_spark, **test_paths)

    # Verify select was called on measurement_campaign_execution_df with correct columns
    # The first select call should have the column names
    assert len(original_select_calls) >= 1
    first_call_args = original_select_calls[0][0]
    assert first_call_args == (
        "campaign_id",
        "booking_id",
        "marketing_type",
        "campaign_duration",
        "job_status"
    )

    # Verify select was called on digital_trading_campaign_dmfbca_sat_df
    assert len(digital_trading_sat_calls) >= 1
    dt_call_args = digital_trading_sat_calls[0][0]
    assert dt_call_args == (
        "digital_trading_campaign_nk1",
        "digital_trading_campaign_nk3",
        "record_arrival_ts",
        "campaign_name",
        "job_bag_id"
    )


@patch('spark_pipeline.reach_engagement.reach_engagement.spark_s3_overwrite')
@patch('spark_pipeline.reach_engagement.reach_engagement.SlackMessenger')
@patch('spark_pipeline.reach_engagement.reach_engagement.process_all_campaigns')
@patch('spark_pipeline.reach_engagement.reach_engagement.datetime')
def test_prepare_reach_engagement_output_columns(
    mock_datetime,
    mock_process_campaigns,
    mock_slack_messenger,
    _,
    mock_spark,
    mock_dataframes,
    test_paths
):
    """Test that output DataFrames contain correct columns."""
    # from spark_pipeline.reach_engagement.reach_engagement import prepare_reach_engagement

    # Setup
    mock_now = datetime(2024, 1, 1, 12, 0, 0)
    mock_datetime.now.return_value = mock_now

    # Mock the parquet read for all paths
    def get_mock_df(path):
        mock_df = Mock(spec=DataFrame)
        mock_df.select.return_value = mock_df
        return mock_df

    mock_spark.read.parquet.side_effect = get_mock_df

    # Create a new mock for measurement_campaign_execution that handles both select calls
    measurement_execution_mock = Mock(spec=DataFrame)
    measurement_execution_mock.select.return_value = measurement_execution_mock
    measurement_execution_mock.first.return_value = {'booking_ids': []}

    # Override the mock_spark.read.parquet for measurement_campaign_execution specifically
    original_side_effect = mock_spark.read.parquet.side_effect

    def custom_parquet_read(path):
        if 'measurement_campaign_execution' in path:
            return measurement_execution_mock
        return original_side_effect(path)

    mock_spark.read.parquet.side_effect = custom_parquet_read

    # Mock the result of process_all_campaigns
    mock_result_df = Mock(spec=DataFrame)
    mock_result_df.withColumn.return_value = mock_result_df
    mock_result_df.select.return_value = mock_result_df
    mock_result_df.write = Mock()
    mock_result_df.write.mode.return_value = mock_result_df.write
    mock_result_df.write.parquet = Mock()
    mock_process_campaigns.return_value = mock_result_df

    # Execute
    prepare_reach_engagement(mock_spark, **test_paths)

    # Verify output columns for reporting output (includes dedup_campaign_reach)
    expected_reporting_columns = [
        "campaign_id",
        "channel_name",
        "subchannel_name",
        "marketing_type",
        "booking_id",
        "reach_cnt",
        "dedup_campaign_reach",
        "clicks_cnt",
        "impressions_cnt",
        "sales_amt",
        "conversions_cnt",
        "media_spend_amt",
        "engagement_ctr_pct",
        "load_ts",
        "job_run_id",
        "run_type",
        "dag_run_ts",
    ]

    # Get the select calls
    select_calls = mock_result_df.select.call_args_list
    assert len(select_calls) == 1

    # Should be for reporting output
    assert select_calls[0][0] == tuple(expected_reporting_columns)


##################################################


@pytest.fixture
def unified_campaign_schema():
    """Schema for unified campaign data"""
    return T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
    ])


@pytest.fixture
def campaign_citcam_sat_schema():
    """Schema for campaign citcam sat data"""
    return T.StructType([
        T.StructField("advertising_campaign_nk1", T.StringType(), True),
        T.StructField("campaign_placements", T.StringType(), True),
    ])


@pytest.fixture
def user_journey_schema():
    """Schema for user journey data"""
    return T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True),
    ])


@pytest.fixture
def camp_request_link_schema():
    """Schema for campaign request link data"""
    return ReachEngagementSchema.camp_request_link_schema


@pytest.fixture
def sample_camp_request_link_data(spark_session, camp_request_link_schema):
    """Create sample campaign request link data"""
    data = [
        ("C001", date(2024, 1, 15), 100.0, 5, 1000, 50),
        ("C001", date(2024, 1, 15), 80.0, 3, 800, 40),
        ("C002", date(2024, 2, 10), 200.0, 10, 2000, 100),
    ]
    return spark_session.createDataFrame(data, camp_request_link_schema)


@pytest.fixture
def sample_unified_campaign_data(spark_session, unified_campaign_schema):
    """Create sample unified campaign data"""
    data = [
        ("C001", date(2024, 1, 1), date(2024, 1, 31), "Channel1", "B001", "Digital", "JB001"),
        ("C002", date(2024, 2, 1), date(2024, 2, 28), "Channel2", "B002", "Social", "JB002"),
    ]
    return spark_session.createDataFrame(data, unified_campaign_schema)


@pytest.fixture
def sample_campaign_citcam_sat_data(spark_session, campaign_citcam_sat_schema):
    """Create sample campaign citcam sat data"""
    data = [
        ("C001", "CITRUS-Subchannel1"),
        ("C002", "CITRUS-Subchannel2"),
    ]
    return spark_session.createDataFrame(data, campaign_citcam_sat_schema)


@pytest.fixture
def sample_user_journey_data(spark_session, user_journey_schema):
    """Create sample user journey data"""
    data = [
        ("C001", "B001", "Channel1", "Subchannel1", "L001"),
        ("C001", "B001", "Channel1", "Subchannel1", "L002"),
        ("C001", "B001", "Channel1", "Subchannel1", "L001"),  # Duplicate
        ("C002", "B002", "Channel2", "Subchannel2", "L003"),
        ("C002", "B002", "Channel2", "Subchannel2", "L004"),
    ]
    return spark_session.createDataFrame(data, user_journey_schema)


def test_citrus_processor_happy_path(
    spark_session,
    sample_camp_request_link_data,
    sample_unified_campaign_data,
    sample_campaign_citcam_sat_data,
    sample_user_journey_data
):
    """Test the happy path with valid data"""
    result = citrus_processor(
        sample_camp_request_link_data,
        sample_unified_campaign_data,
        sample_campaign_citcam_sat_data,
        sample_user_journey_data
    )

    # Verify result is not empty
    assert result.count() > 0

    # Verify schema contains expected columns
    expected_columns = [
        "campaign_id", "channel_name", "subchannel_name", "reach",
        "clicks", "impressions", "sales", "conversions",
        "booking_id", "marketing_type"
    ]
    assert result.columns == expected_columns

    # Verify data types
    result_df = result.collect()
    assert len(result_df) == 2  # Two campaigns

    # Check campaign C001
    c001_row = [r for r in result_df if r.campaign_id == "C001"][0]
    assert c001_row.channel_name == "Channel1"
    assert c001_row.subchannel_name == "Subchannel1"
    assert c001_row.reach == 2  # L001 and L002
    assert c001_row.clicks == 90
    assert c001_row.impressions == 1800
    assert c001_row.sales == 180.0
    assert c001_row.conversions == 8
    assert c001_row.booking_id == "B001"
    assert c001_row.marketing_type == "Digital"


def test_citrus_processor_date_filtering(
    spark_session,
    camp_request_link_schema,
    unified_campaign_schema,
    campaign_citcam_sat_schema,
    user_journey_schema
):
    """Test that records outside campaign date range are filtered out"""
    # Create data with dates outside campaign range
    camp_request_data = [
        ("C001", date(2023, 12, 15), 100.0, 5, 1000, 50),
        ("C001", date(2024, 1, 15), 200.0, 10, 2000, 100),
        ("C001", date(2024, 2, 15), 50.0, 2, 500, 25),
    ]
    camp_request_df = spark_session.createDataFrame(camp_request_data, camp_request_link_schema)

    unified_data = [
        ("C001", date(2024, 1, 1), date(2024, 1, 31), "Channel1", "B001", "Digital", "JB001"),
    ]
    unified_df = spark_session.createDataFrame(unified_data, unified_campaign_schema)

    citcam_data = [("C001", "CITRUS-Subchannel1")]
    citcam_df = spark_session.createDataFrame(citcam_data, campaign_citcam_sat_schema)

    journey_data = [("C001", "B001", "Channel1", "Subchannel1", "L001")]
    journey_df = spark_session.createDataFrame(journey_data, user_journey_schema)

    result = citrus_processor(camp_request_df, unified_df, citcam_df, journey_df)

    result_row = result.collect()[0]
    # Should only have values from the record within range (Jan 15)
    assert result_row.sales == 200.0
    assert result_row.conversions == 10
    assert result_row.impressions == 2000
    assert result_row.clicks == 100


def test_citrus_processor_reach_calculation(
    spark_session,
    camp_request_link_schema,
    unified_campaign_schema,
    campaign_citcam_sat_schema,
    user_journey_schema
):
    """Test reach calculation with distinct loyalty IDs"""
    camp_request_data = [
        ("C001", date(2024, 1, 15), 100.0, 5, 1000, 50),
    ]
    camp_request_df = spark_session.createDataFrame(camp_request_data, camp_request_link_schema)

    unified_data = [
        ("C001", date(2024, 1, 1), date(2024, 1, 31), "Channel1", "B001", "Digital", "JB001"),
    ]
    unified_df = spark_session.createDataFrame(unified_data, unified_campaign_schema)

    citcam_data = [("C001", "CITRUS-Subchannel1")]
    citcam_df = spark_session.createDataFrame(citcam_data, campaign_citcam_sat_schema)

    # Multiple entries with duplicate loyalty IDs
    journey_data = [
        ("C001", "B001", "Channel1", "Subchannel1", "L001"),
        ("C001", "B001", "Channel1", "Subchannel1", "L002"),
        ("C001", "B001", "Channel1", "Subchannel1", "L003"),
        ("C001", "B001", "Channel1", "Subchannel1", "L001"),  # Duplicate
        ("C001", "B001", "Channel1", "Subchannel1", "L002"),  # Duplicate
    ]
    journey_df = spark_session.createDataFrame(journey_data, user_journey_schema)

    result = citrus_processor(camp_request_df, unified_df, citcam_df, journey_df)

    result_row = result.collect()[0]
    assert result_row.reach == 3  # Only L001, L002, L003 (distinct)


def test_citrus_processor_aggregation(
    spark_session,
    camp_request_link_schema,
    unified_campaign_schema,
    campaign_citcam_sat_schema,
    user_journey_schema
):
    """Test aggregation of multiple records for same campaign"""
    # Multiple records for same campaign
    camp_request_data = [
        ("C001", date(2024, 1, 15), 100.0, 5, 1000, 50),
        ("C001", date(2024, 1, 20), 200.0, 10, 2000, 100),
    ]
    camp_request_df = spark_session.createDataFrame(camp_request_data, camp_request_link_schema)

    unified_data = [
        ("C001", date(2024, 1, 1), date(2024, 1, 31), "Channel1", "B001", "Digital", "JB001"),
    ]
    unified_df = spark_session.createDataFrame(unified_data, unified_campaign_schema)

    citcam_data = [("C001", "CITRUS-Subchannel1")]
    citcam_df = spark_session.createDataFrame(citcam_data, campaign_citcam_sat_schema)

    journey_data = [("C001", "B001", "Channel1", "Subchannel1", "L001")]
    journey_df = spark_session.createDataFrame(journey_data, user_journey_schema)

    result = citrus_processor(camp_request_df, unified_df, citcam_df, journey_df)

    result_row = result.collect()[0]
    # Values should be summed
    assert result_row.sales == 300.0  # 100 + 200
    assert result_row.conversions == 15  # 5 + 10
    assert result_row.impressions == 3000  # 1000 + 2000
    assert result_row.clicks == 150  # 50 + 100


def test_citrus_processor_empty_join_raises_error(
    spark_session,
    camp_request_link_schema,
    unified_campaign_schema,
    campaign_citcam_sat_schema,
    user_journey_schema
):
    """Test that JoinValidationError is raised when join produces no results"""
    # Create data where campaign IDs don't match
    camp_request_data = [
        ("C999", date(2024, 1, 15), 100.0, 5, 1000, 50),
    ]
    camp_request_df = spark_session.createDataFrame(camp_request_data, camp_request_link_schema)

    unified_data = [
        ("C001", date(2024, 1, 1), date(2024, 1, 31), "Channel1", "B001", "Digital", "JB001"),
    ]

    # Create DataFrame
    unified_df = spark_session.createDataFrame(unified_data, unified_campaign_schema)

    citcam_data = [("C001", "CITRUS-Subchannel1")]
    citcam_df = spark_session.createDataFrame(citcam_data, campaign_citcam_sat_schema)

    journey_data = [("C001", "B001", "Channel1", "Subchannel1", "L001")]
    journey_df = spark_session.createDataFrame(journey_data, user_journey_schema)

    heading = "Citrus latest_records JOIN VALIDATION FAILED - No rows fetched."
    join_query = DiagnosticQuery.CITRUS_RECORDS_JOIN_QUERY.value

    # Generate expected result manually
    left_table_str = spark_df_to_prettytable(camp_request_df.distinct())
    right_table_str = spark_df_to_prettytable(unified_df.distinct())

    expected_result = (
        f"{heading}\n"
        f"{'=' * 80}\n"
        f"\n{join_query}\n"
        f"\nLeft_df left_table:\n{left_table_str}\n"
        f"\nRight_df right_table:\n{right_table_str}\n"
    ) + DiagnosticMessage.CITRUS_RECORDS_FAILURE_SUGGESTION.value

    with pytest.raises(JoinValidationError, match=expected_result):
        _ = citrus_processor(
            camp_request_df,
            unified_df,
            citcam_df,
            journey_df
        )
