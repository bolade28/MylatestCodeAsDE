import pytest
from pyspark.sql import types as T
from spark_pipeline.reach_engagement.re_utils import calculate_combined_reach, join_completed_campaigns, join_ongoing_campaigns


@pytest.fixture
def schema():
    """Define schema for test DataFrames."""
    return T.StructType([
        T.StructField("LOYALTY_ID", T.StringType(), True)
    ])


def test_basic_overlap(spark_session, schema):
    """Test basic case with some overlap between Meta and instore."""
    spark = spark_session
    # Meta has IDs: Loyalty_ID_1, Loyalty_ID_2, Loyalty_ID_3, Loyalty_ID_4 (4 total)
    meta_data = [("Loyalty_ID_1",), ("Loyalty_ID_2",), ("Loyalty_ID_3",), ("Loyalty_ID_4",)]
    meta_df = spark.createDataFrame(meta_data, schema)

    # Instore has IDs: Loyalty_ID_3, Loyalty_ID_4, Loyalty_ID_5, Loyalty_ID_6 (4 total)
    instore_data = [("Loyalty_ID_3",), ("Loyalty_ID_4",), ("Loyalty_ID_5",), ("Loyalty_ID_6",)]
    instore_df = spark.createDataFrame(instore_data, schema)

    offsite_reach = {"Meta": 10000}

    result = calculate_combined_reach(meta_df, instore_df, offsite_reach)

    assert result["meta_loyalty_id_count"] == 4
    assert result["instore_loyalty_id_count"] == 4
    assert result["overlap_count"] == 2  # Loyalty_ID_3 and Loyalty_ID_4 overlap
    assert result["unique_in_meta"] == 2  # Loyalty_ID_1 and Loyalty_ID_2
    assert result["unique_in_instore"] == 2  # Loyalty_ID_5 and Loyalty_ID_6
    assert result["union_loyalty_ids"] == 4  # Loyalty_ID_1, Loyalty_ID_2, Loyalty_ID_5, Loyalty_ID_6
    assert result["meta_reported_reach"] == 10000
    assert result["overlap_rate"] == 0.5  # 2/4
    assert result["exposure_only_to_meta"] == 5000.0  # 10000 * 0.5
    assert result["reach_estimate"] == 5004.0  # 4 + 5000
    assert result["reach_estimate_rounded"] == 5004


def test_no_overlap(spark_session, schema):
    """Test case where there is no overlap."""
    spark = spark_session
    meta_data = [("Loyalty_ID_1",), ("Loyalty_ID_2",), ("Loyalty_ID_3",)]
    meta_df = spark.createDataFrame(meta_data, schema)

    instore_data = [("Loyalty_ID_4",), ("Loyalty_ID_5",), ("Loyalty_ID_6",)]
    instore_df = spark.createDataFrame(instore_data, schema)

    offsite_reach = {"Meta": 5000}

    result = calculate_combined_reach(meta_df, instore_df, offsite_reach)

    assert result["meta_loyalty_id_count"] == 3
    assert result["instore_loyalty_id_count"] == 3
    assert result["overlap_count"] == 0
    assert result["unique_in_meta"] == 3
    assert result["unique_in_instore"] == 3
    assert result["union_loyalty_ids"] == 6
    assert result["overlap_rate"] == 0.0
    assert result["exposure_only_to_meta"] == 5000.0  # 5000 * 1.0
    assert result["reach_estimate"] == 5003.0  # 3 + 5000


def test_complete_overlap(spark_session, schema):
    """Test case where all IDs overlap."""
    spark = spark_session
    meta_data = [("Loyalty_ID_1",), ("Loyalty_ID_2",), ("Loyalty_ID_3",)]
    meta_df = spark.createDataFrame(meta_data, schema)

    instore_data = [("Loyalty_ID_1",), ("Loyalty_ID_2",), ("Loyalty_ID_3",)]
    instore_df = spark.createDataFrame(instore_data, schema)

    offsite_reach = {"Meta": 8000}

    result = calculate_combined_reach(meta_df, instore_df, offsite_reach)

    assert result["meta_loyalty_id_count"] == 3
    assert result["instore_loyalty_id_count"] == 3
    assert result["overlap_count"] == 3
    assert result["unique_in_meta"] == 0
    assert result["unique_in_instore"] == 0
    assert result["union_loyalty_ids"] == 0
    assert result["overlap_rate"] == 1.0
    assert result["exposure_only_to_meta"] == 0.0  # 8000 * 0
    assert result["reach_estimate"] == 3.0  # 3 + 0


def test_empty_meta_df(spark_session, schema):
    """Test case with empty Meta DataFrame."""
    spark = spark_session
    meta_df = spark.createDataFrame([], schema)

    instore_data = [("Loyalty_ID_1",), ("Loyalty_ID_2",), ("Loyalty_ID_3",)]
    instore_df = spark.createDataFrame(instore_data, schema)

    offsite_reach = {"Meta": 1000}

    result = calculate_combined_reach(meta_df, instore_df, offsite_reach)

    assert result["meta_loyalty_id_count"] == 0
    assert result["instore_loyalty_id_count"] == 3
    assert result["overlap_count"] == 0
    assert result["overlap_rate"] == 0.0  # Handles division by zero
    assert result["reach_estimate"] == 1003.0  # 1000 + 3


def test_empty_instore_df(spark_session, schema):
    """Test case with empty instore DataFrame."""
    spark = spark_session

    meta_data = [("Loyalty_ID_1",), ("Loyalty_ID_2",), ("Loyalty_ID_3",)]
    meta_df = spark.createDataFrame(meta_data, schema)

    instore_df = spark.createDataFrame([], schema)

    offsite_reach = {"Meta": 2000}

    result = calculate_combined_reach(meta_df, instore_df, offsite_reach)

    assert result["meta_loyalty_id_count"] == 3
    assert result["instore_loyalty_id_count"] == 0
    assert result["overlap_count"] == 0
    assert result["unique_in_meta"] == 3
    assert result["unique_in_instore"] == 0
    assert result["overlap_rate"] == 0.0
    assert result["reach_estimate"] == 2000.0  # 0 + 2000


def test_join_completed_campaigns(spark_session):
    """
    Test the join_completed_campaigns function for completed campaigns.
    """
    # Mock data for meta_job_bag_join
    meta_job_bag_join = spark_session.createDataFrame([
        ("campaign_1", "2025-12-01", "2025-12-15"),
        ("campaign_2", "2025-12-10", "2025-12-20")
    ], ["digital_trading_campaign_channel_nk1", "campaign_start_dt", "campaign_end_dt"])

    # Mock data for meta_insights_with_measures
    meta_insights_with_measures = spark_session.createDataFrame([
        ("campaign_1", "2025-12-01", "2025-12-15"),
        ("campaign_3", "2025-12-05", "2025-12-10")
    ], ["digital_trading_campaign_nk1", "reporting_start_dt", "reporting_end_dt"])

    # Call the function
    result = join_completed_campaigns(meta_job_bag_join, meta_insights_with_measures)

    # Assert the result
    assert result.count() == 1
    assert result.collect()[0]["digital_trading_campaign_channel_nk1"] == "campaign_1"


def test_join_ongoing_campaigns(spark_session):
    """
    Test the join_ongoing_campaigns function for ongoing campaigns.
    """
    # Mock data for meta_job_bag_join
    meta_job_bag_join = spark_session.createDataFrame([
        ("campaign_1", "2025-12-01", "2025-12-15"),
        ("campaign_2", "2025-12-10", "2025-12-20")
    ], ["digital_trading_campaign_channel_nk1", "campaign_start_dt", "campaign_end_dt"])

    # Mock data for meta_insights_with_measures
    meta_insights_with_measures = spark_session.createDataFrame([
        ("campaign_1", "2025-12-01", "2025-12-10"),
        ("campaign_1", "2025-12-01", "2025-12-15"),
        ("campaign_2", "2025-12-10", "2025-12-15")
    ], ["digital_trading_campaign_nk1", "reporting_start_dt", "reporting_end_dt"])

    # Call the function
    result = join_ongoing_campaigns(meta_job_bag_join, meta_insights_with_measures)

    # Assert the result
    assert result.count() == 2
    assert result.filter(result.digital_trading_campaign_channel_nk1 == "campaign_1").count() == 1
    assert result.filter(result.digital_trading_campaign_channel_nk1 == "campaign_2").count() == 1
