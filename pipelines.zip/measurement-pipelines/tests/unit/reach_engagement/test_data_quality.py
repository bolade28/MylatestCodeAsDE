import pytest
from spark_pipeline.reach_engagement.data_quality import (
    spark_df_to_prettytable, validate_joins,
    validate_media_spend_amt)
from pyspark.sql import types as T


@pytest.fixture
def sample_left_df(spark_session):
    """Create sample left DataFrame for testing"""
    spark = spark_session
    data = [("A", 1), ("B", 2), ("C", 3)]
    schema = T.StructType([
        T.StructField("id", T.StringType(), True),
        T.StructField("value", T.IntegerType(), True)
    ])
    return spark.createDataFrame(data, schema)


@pytest.fixture
def sample_right_df(spark_session):
    """Create sample right DataFrame for testing"""
    spark = spark_session
    data = [("A", 100), ("B", 200), ("D", 400)]
    schema = T.StructType([
        T.StructField("id", T.StringType(), True),
        T.StructField("amount", T.IntegerType(), True)
    ])
    return spark.createDataFrame(data, schema)


@pytest.fixture
def sample_bad_rows_df(spark_session):
    """Create sample right DataFrame for testing"""
    spark = spark_session
    data = [("A", 100), ("B", 200), ("D", 400)]
    schema = T.StructType([
        T.StructField("id", T.StringType(), True),
        T.StructField("media_spend_amt", T.IntegerType(), True)
    ])
    return spark.createDataFrame(data, schema)


def test_validate_joins_basic_functionality(sample_left_df, sample_right_df):
    """Test basic functionality and compare expected vs actual output"""
    # Test inputs
    join_query = "SELECT * FROM left_table l JOIN right_table r ON l.id = r.id"
    heading = "Join Validation Report"

    # Call the function
    actual_result = validate_joins(
        left_df=sample_left_df,
        right_df=sample_right_df,
        join_query=join_query,
        left_df_name="left_table",
        right_df_name="right_table",
        heading=heading
    )

    # Generate expected result manually
    left_table_str = spark_df_to_prettytable(sample_left_df.distinct())
    right_table_str = spark_df_to_prettytable(sample_right_df.distinct())

    expected_result = (
        f"{heading}\n"
        f"{'=' * 80}\n"
        f"\n{join_query}\n"
        f"\nLeft_df left_table:\n{left_table_str}\n"
        f"\nRight_df right_table:\n{right_table_str}\n"
    )

    # Compare expected vs actual
    assert actual_result == expected_result


def test_validate_media_spend_amt(sample_bad_rows_df):
    """Test basic functionality and compare expected vs actual output"""
    # Test inputs
    derived = "revenue"
    heading = "Diagnosis for media_spend_amt"

    # Call the function
    actual_result = validate_media_spend_amt(
        bad_rows=sample_bad_rows_df,
        heading=heading,
        derived=derived
    )

    # Generate expected result manually
    bad_rows_table = spark_df_to_prettytable(sample_bad_rows_df.distinct())

    expected_result = (
        f"{'=' * 80}\n"
        f"{heading}\n"
        f"media_spend_amt is calculated by suming the value {derived}\n"
        f"\n{bad_rows_table}\n"
        f"{'=' * 80}\n"
    )

    # Compare expected vs actual
    assert actual_result == expected_result
