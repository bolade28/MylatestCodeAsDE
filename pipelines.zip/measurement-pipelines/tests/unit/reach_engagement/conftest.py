import pytest
from unittest.mock import patch
from pyspark import SparkContext


@pytest.fixture(autouse=True)
def _patch_jvm_functions_when_no_spark():
    """Automatically patch PySpark functions that require an active SparkContext.

    Only activates when no SparkContext is running (i.e. mock-based tests).
    Real Spark integration tests are unaffected.
    """
    if SparkContext._active_spark_context is None:
        with patch("pyspark.sql.functions.collect_set"), \
             patch("pyspark.sql.functions.lit"):
            yield
    else:
        yield
