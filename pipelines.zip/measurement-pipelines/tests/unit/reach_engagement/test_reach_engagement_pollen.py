import pytest
from pyspark.sql import types as T
from pyspark.sql import DataFrame, functions as F, Row
from chispa import assert_df_equality
from datetime import datetime, date
from unittest.mock import patch, Mock
from pyspark.sql import SparkSession
import json
import uuid

from spark_pipeline.reach_engagement.reach_engagement_pollen import (
    fetch_in_progress_campaigns, get_latest_data_for_campaigns,
    calculate_reach, meta_processor, youtube_and_dv360_processor, citrus_processor,
    process_all_campaigns, entrypoint, prepare_reach_engagement)

from spark_pipeline.reach_engagement.data_quality import (
    JoinValidationError)

from spark_pipeline.schemas.reach_engagement import ReachEngagementSchema


def create_test_df(spark, data, schema):
    return spark.createDataFrame(data, schema)


@pytest.fixture
def mock_spark():
    """Create a mock SparkSession."""
    spark = Mock(spec=SparkSession)
    spark.read = Mock()
    spark.read.parquet = Mock()
    return spark


def test_calculate_reach(spark_session):
    """
    Tests the calculate_reach_optimized function with multiple scenarios.
    """
    # Define schemas for the input DataFrames

    spark = spark_session

    journey_data_schema = T.StructType([
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("isconversion", T.IntegerType(), True),
        T.StructField("net_sales_amt", T.DoubleType(), True),
        T.StructField("booking_id", T.StringType(), True)
    ])

    input_df_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True),
    ])

    # Sample journey data covering multiple campaigns and scenarios
    journey_data_rows = [
        # Campaign 1: Digital with sales and conversions
        ("Instore", "CAMP001", "Meta", "Facebook", "LID001", "J1", 1, 50.00, "BID001"),
        ("Instore", "CAMP001", "Meta", "Facebook", "LID001", "J16", 0, 0.00, "BID001"),
        ("In-store", "CAMP001", "Meta", "Instagram", "LID002", "J15", 1, 75.50, "BID001"),
        # Campaign 2: Ecoupons with sales and conversions, special subchannel logic
        ("Meta", "CAMP002", "Email", "eCoupon", "LID003", "J14", 0, 100.00, "BID002"),
        ("Meta", "CAMP002", "Email", "eCoupon", "LID003", "J13", 1, 0.00, "BID002"),
        ("Meta", "CAMP002", "Email", "eCoupon", "LID004", "J11", 0, 20.00, "BID002"),
        # Campaign 3: Digital with no conversions, only reach and sales
        ("Youtube", "CAMP003", "Google", "Search", "LID005", "J1", 1, 150.00, "BID003"),
        ("In-store", "CAMP003", "Google", "Search", "LID006", "J1", 1, 25.00, "BID003"),
        # Campaign 4: In-store, no subchannel name, no sales
        ("Gol", "CAMP004", "In-store", "In-store", "LID007", "J12", 0, 0.00, "BID004"),
        ("NA", "CAMP005", "In-store", "eCoupons", "LID008", "J1", 1, 0.00, "BID006"),
    ]

    # Sample input_df with multiple campaigns to be processed
    input_df_rows = [
        ("CAMP001", "Digital", "Meta", "3009"),
        ("CAMP002", "eCoupons", "Email", "4013"),
        ("CAMP003", "Digital", "Google", "3001"),
        ("CAMP004", "In-store", "In-store", "2001"),
        ("CAMP005", "In-store", "eCoupons", "4013")
    ]

    journey_df = spark.createDataFrame(journey_data_rows, journey_data_schema)
    input_df = spark.createDataFrame(input_df_rows, input_df_schema)

    # Call the function with a specific group_by_column
    group_by_column = "booking_id"
    subchannel_hierarchy_codes = {
        'ecoupons': ['4013'],
        'coupon_at_till': ['2050', '2051']
    }
    result_df = calculate_reach(journey_df, input_df, group_by_column, subchannel_hierarchy_codes)

    # Convert to a list of dictionaries for easier comparison
    result_rows = [row.asDict() for row in result_df.collect()]

    # Expected output based on the logic
    # Note: the order might not be guaranteed, so we will sort for comparison
    # Note: Coupon channels (ecoupons, coupon_at_till) will have None for subchannel_name
    # because they are grouped differently (without subchannel_name in the groupBy)
    expected_rows = [
        {'campaign_id': 'CAMP001', 'channel_name': 'Meta', 'subchannel_name': 'Facebook', 'reach': 1, 'clicks': 0, 'impressions': 0, 'sales': 50.00, 'conversions': 2, 'booking_id': 'BID001', 'marketing_type': 'Digital'},
        {'campaign_id': 'CAMP001', 'channel_name': 'Meta', 'subchannel_name': 'Instagram', 'reach': 1, 'clicks': 0, 'impressions': 0, 'sales': 75.50, 'conversions': 1, 'booking_id': 'BID001', 'marketing_type': 'Digital'},
        {'campaign_id': 'CAMP002', 'channel_name': 'Email', 'subchannel_name': None, 'reach': 2, 'clicks': 0, 'impressions': 0, 'sales': 120.00, 'conversions': 3, 'booking_id': 'BID002', 'marketing_type': 'eCoupons'},
        {'campaign_id': 'CAMP003', 'channel_name': 'Google', 'subchannel_name': 'Search', 'reach': 2, 'clicks': 0, 'impressions': 0, 'sales': 175.00, 'conversions': 1, 'booking_id': 'BID003', 'marketing_type': 'Digital'},
        {'campaign_id': 'CAMP004', 'channel_name': 'In-store', 'subchannel_name': 'In-store', 'reach': 1, 'clicks': 0, 'impressions': 0, 'sales': 0.00, 'conversions': 1, 'booking_id': 'BID004', 'marketing_type': 'In-store'}
    ]

    # Sort both lists of dictionaries for a stable comparison
    sorted_result = sorted(result_rows, key=lambda x: x['campaign_id'] + str(x.get('subchannel_name')))
    sorted_expected = sorted(expected_rows, key=lambda x: x['campaign_id'] + str(x.get('subchannel_name')))

    # Assert that the output matches the expected data
    assert sorted_result == sorted_expected

# @pytest.mark.skip("Ignore for now")


def test_fetch_in_progress_campaigns_basic(spark_session):
    """Test basic functionality with in-progress campaigns"""
    spark = spark_session
    # Create test data
    schema = F.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_duration", T.IntegerType()),
        T.StructField("job_status", T.StringType())
    ])

    data = [
        ("B001", 30, "In-progress"),
        ("B002", 45, "Completed"),
        ("B003", 60, "In-progress")
    ]
    df = spark.createDataFrame(data, schema)

    # Call function
    result = fetch_in_progress_campaigns(df)

    # Verify results
    results = result.collect()
    assert len(results) == 3
    assert {row.booking_id for row in results} == {"B001", "B002", "B003"}
    assert result.columns == ["booking_id", "campaign_duration"]


def test_fetch_in_progress_campaigns_empty(spark_session):
    """Test error handling when no in-progress campaigns exist"""
    spark = spark_session
    schema = F.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_duration", T.IntegerType()),
        T.StructField("job_status", T.StringType())
    ])

    data = []
    df = spark.createDataFrame(data, schema)

    # Verify exception is raised
    with pytest.raises(ValueError) as excinfo:
        fetch_in_progress_campaigns(df)
    assert "no campaign found to execute the model" in str(excinfo.value)


def test_get_latest_data_basic_case(spark_session):
    """Test basic functionality with both duration and no-duration cases"""
    spark = spark_session
    # Create test data
    data_schema = T.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_duration", T.IntegerType()),
        T.StructField("load_ts", T.TimestampType()),
        T.StructField("data_value", T.StringType())
    ])

    data_rows = [
        ("B001", 30, datetime(2023, 1, 1, 10, 0, 0), "A"),
        ("B001", 30, datetime(2023, 1, 2, 11, 0, 0), "B"),
        ("B002", None, datetime(2023, 1, 1, 9, 0, 0), "C"),
        ("B002", None, datetime(2023, 1, 3, 12, 0, 0), "D"),
        ("B003", 45, datetime(2023, 1, 1, 8, 0, 0), "E")
    ]
    data_df = spark.createDataFrame(data_rows, schema=data_schema)

    # Create in-progress campaigns
    in_progress_schema = T.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_duration", T.IntegerType())
    ])

    in_progress_rows = [
        ("B001", 30),  # With duration
        ("B002", None),  # Without duration
        ("B003", 45)  # With duration
    ]
    in_progress_df = spark.createDataFrame(in_progress_rows, schema=in_progress_schema)

    # Call function
    result = get_latest_data_for_campaigns(data_df, in_progress_df)
    results = result.orderBy("booking_id").collect()

    # Verify results
    assert len(results) == 3
    assert results[0]["booking_id"] == "B001" and results[0]["data_value"] == "A"
    assert results[1]["booking_id"] == "B001" and results[1]["data_value"] == "B"
    assert results[2]["booking_id"] == "B003" and results[2]["data_value"] == "E"


def test_missing_required_columns(spark_session):
    """Test error handling when required columns are missing"""
    spark = spark_session
    data_df = spark.createDataFrame([], T.StructType([]))
    in_progress_df = spark.createDataFrame([("B001",)], ["booking_id"])  # Missing campaign_duration

    with pytest.raises(ValueError) as excinfo:
        get_latest_data_for_campaigns(data_df, in_progress_df)
    assert "missing required columns" in str(excinfo.value)


# @pytest.mark.skip("Ignore for now")
def test_meta_processor_basic_case(spark_session):
    """Test basic functionality with complete data"""
    spark = spark_session

    campaign_link_schema = T.StructType([
        T.StructField("digital_trading_campaign_nk1", T.StringType()),
        T.StructField("digital_trading_campaign_channel_nk1", T.StringType())
    ])

    insights_schema = T.StructType([
        T.StructField("digital_trading_campaign_nk1", T.StringType()),
        T.StructField("reporting_start_dt", T.DateType()),
        T.StructField("reporting_end_dt", T.DateType()),
        T.StructField("digital_trading_insight_id", T.StringType()),
        T.StructField("digital_trading_lineitem_nk1", T.StringType()),
        T.StructField("record_arrival_ts", T.TimestampType()),
        T.StructField("measures", T.StringType())
    ])

    unified_schema = T.StructType([
        T.StructField("campaign_id", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("campaign_start_dt", T.DateType()),
        T.StructField("campaign_end_dt", T.DateType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("booking_id", T.StringType()),
        T.StructField("subchannel_name", T.StringType())
    ])

    # Create test data
    campaign_link_data = [("NK1_001", "CH_NK1_001")]

    measures_data = """
    {
        "conversion": {
            "acquired": 2,
            "instore": 2,
            "lapsed": 0,
            "online": 0,
            "percentage": 0,
            "retained": 0,
            "totals": 2
        },
        "engagement": {
            "comments": 0,
            "post_engagements": 0,
            "post_reactions": 0,
            "shares": 0
        },
        "externals": {
            "cpa": 0,
            "media_spend": 0
        },
        "internals": {
            "cpa": 0,
            "cpm_actual": 0,
            "cpm_booked": 7.5,
            "media_spend": 0
        },
        "sales": {
            "instore": 6,
            "online": 0,
            "spend_per_customer": 3,
            "total": 6
        },
        "summary": {
            "clicks": 10,
            "conversionRate": null,
            "ctr": 0,
            "frequency": 0,
            "impressions": 0,
            "reach": 100
        },
        "video": {
            "cost_per_completed_view": 0,
            "video_completed_views": 0,
            "video_completion_rate": 0,
            "video_views": 0
        }
    }
    """

    measures_dict = {
        "conversion": {"acquired": 2, "instore": 2, "lapsed": 0, "online": 0, "percentage": 0, "retained": 0, "totals": 2},
        "engagement": {"comments": 0, "post_engagements": 0, "post_reactions": 0, "shares": 0},
        "externals": {"cpa": 0, "media_spend": 0},
        "internals": {"cpa": 0, "cpm_actual": 0, "cpm_booked": 7.5, "media_spend": 0},
        "sales": {"instore": 6, "online": 0, "spend_per_customer": 3, "total": 6},
        "summary": {"clicks": 0, "conversionRate": None, "ctr": 0, "frequency": 0, "impressions": 0, "reach": 0},
        "video": {"cost_per_completed_view": 0, "video_completed_views": 0, "video_completion_rate": 0, "video_views": 0}
    }

    # Convert dict to JSON string
    measures_data = json.dumps(measures_dict)

    insights_data = [
        ("CH_NK1_001", date(2023, 1, 1), date(2023, 1, 31), "INSIGHT_001", "LINE_001",
         datetime(2023, 2, 1, 10, 0, 0), measures_data)  # <-- JSON string here
    ]

    unified_data = [
        ("CH_NK1_001", "Meta", date(2023, 1, 1), date(2023, 1, 31), "Digital", "BOOK001", "Facebook")
    ]

    # Create DataFrames
    campaign_link_df = create_test_df(spark, campaign_link_data, campaign_link_schema)
    insights_df = create_test_df(spark, insights_data, insights_schema)
    unified_df = create_test_df(spark, unified_data, unified_schema)
    campaign_complete = True  # Add this argument

    # Process data
    result = meta_processor(campaign_link_df, insights_df, unified_df, campaign_complete=campaign_complete)

    results = result.collect()

    # Verify results
    assert len(results) == 1
    row = results[0]
    assert row["campaign_id"] == "CH_NK1_001"
    assert row["reach"] == 0
    assert row["clicks"] == 0
    assert row["impressions"] == 0
    assert row["sales"] == 6
    assert row["conversions"] == 2
    assert row["media_spend_amt"] == 0
    assert row["channel_name"] == "Meta"
    assert row["subchannel_name"] == "Facebook"


def test_youtube_processor_multiple_campaigns(spark_session):
    """Test with multiple campaigns and verify exact expected output"""
    spark = spark_session

    media_schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("insertion_order_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("clicks", T.StringType(), True),
        T.StructField("impressions", T.StringType(), True),
        T.StructField("total_conversions", T.StringType(), True),
        T.StructField("revenue", T.StringType(), True),
        T.StructField("run_at", T.TimestampType(), True),
    ])

    order_schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("date_from", T.DateType(), True),
        T.StructField("date_until", T.DateType(), True),
        T.StructField("total_reach", T.StringType(), True),
        T.StructField("country", T.StringType(), True),
    ])

    unified_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
    ])

    floodlight_schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("spend", T.StringType(), True),
    ])

    # Test Data (3 unified campaigns)
    unified_data = [
        ("CAMP_001", date(2024, 1, 10), date(2024, 1, 31), "YouTube", "BOOK_001", "Awareness", "TrueView"),
        ("CAMP_002", date(2024, 2, 1), date(2024, 2, 28), "YouTube", "BOOK_002", "Consideration", "Bumper"),
        ("CAMP_001", date(2024, 1, 10), date(2024, 1, 31), "YouTube", "BOOK_001", "Awareness", "NewView"),
    ]

    media_data = [
        ("LINE_001", "CAMP_001", "CAMP_001", date(2024, 1, 15), "100", "5000", "10", "1500.50", datetime(2024, 1, 15, 10, 0)),
        ("LINE_001", "CAMP_001", "CAMP_001", date(2024, 1, 16), "150", "6000", "15", "2000.75", datetime(2024, 1, 16, 10, 0)),
        ("LINE_002", "CAMP_001", "CAMP_001", date(2024, 1, 15), "200", "8000", "20", "3000.00", datetime(2024, 1, 15, 10, 0)),
        ("LINE_003", "CAMP_002", "CAMP_002", date(2024, 2, 10), "50", "2000", "5", "500.00", datetime(2024, 2, 10, 10, 0)),
    ]

    order_data = [
        ("LINE_001", date(2024, 1, 10), date(2024, 1, 31), "10000", "GB"),
        ("LINE_002", date(2024, 1, 10), date(2024, 1, 31), "15000", "GB"),
        ("LINE_003", date(2024, 2, 1), date(2024, 2, 28), "5000", "GB"),
        ("LINE_004", date(2024, 1, 10), date(2024, 1, 31), "8000", "US"),  # Different country
    ]

    floodlight_data = [
        ("LINE_001", date(2024, 1, 15), "5000.50"),
        ("LINE_001", date(2024, 1, 20), "3000.25"),
        ("LINE_002", date(2024, 1, 18), "7500.00"),
        ("LINE_003", date(2024, 2, 15), "2000.00"),
    ]

    # Create DataFrames
    media_df = create_test_df(spark, media_data, media_schema)
    order_df = create_test_df(spark, order_data, order_schema)
    floodlight_df = create_test_df(spark, floodlight_data, floodlight_schema)
    unified_df = create_test_df(spark, unified_data, unified_schema)

    # Process data
    result = youtube_and_dv360_processor(media_df, order_df, floodlight_df, unified_df, channel_type='youtube')

    # Define EXPECTED OUTPUT Schema
    expected_schema = T.StructType([
        T.StructField("campaign_id", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("reach", T.LongType()),
        T.StructField("clicks", T.LongType()),
        T.StructField("impressions", T.LongType()),
        T.StructField("sales", T.DoubleType()),
        T.StructField("conversions", T.LongType()),
        T.StructField("booking_id", T.StringType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("media_spend_amt", T.DoubleType())
    ])

    expected_data = [
        ("CAMP_001", "YouTube", "NewView", 25000, 300, 13000, 31001.5, 30, "BOOK_001", "Awareness", 4500.0),
        ("CAMP_001", "YouTube", "TrueView", 25000, 300, 13000, 31001.5, 30, "BOOK_001", "Awareness", 4500.0),
        ("CAMP_002", "YouTube", "Bumper", 5000, 50, 2000, 2000.0, 5, "BOOK_002", "Consideration", 500.0)
    ]
    expected_df = create_test_df(spark, expected_data, expected_schema)
    # 2. Collect and compare data
    result_data = sorted(result.collect(), key=lambda x: x["campaign_id"])
    expected_data = expected_df.collect()
    assert len(result_data) == len(expected_data)

    assert_df_equality(
        result,
        expected_df
    )


def test_youtube_processor_no_match_on_campaign_id(spark_session):
    """Test with multiple campaigns and verify exact expected output"""
    spark = spark_session

    media_schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("insertion_order_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("clicks", T.StringType(), True),
        T.StructField("impressions", T.StringType(), True),
        T.StructField("total_conversions", T.StringType(), True),
        T.StructField("revenue", T.StringType(), True),
        T.StructField("run_at", T.TimestampType(), True),
    ])

    order_schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("date_from", T.DateType(), True),
        T.StructField("date_until", T.DateType(), True),
        T.StructField("total_reach", T.StringType(), True),
        T.StructField("country", T.StringType(), True),
    ])

    unified_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
    ])

    floodlight_schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("spend", T.StringType(), True),
    ])

    # Test Data (3 unified campaigns)
    unified_data = [
        ("CAMP_001", date(2024, 1, 10), date(2024, 1, 31), "YouTube", "BOOK_001", "Awareness", "TrueView"),
        ("CAMP_002", date(2024, 2, 1), date(2024, 2, 28), "YouTube", "BOOK_002", "Consideration", "Bumper"),
    ]

    # This should use insertion_order_id to join instead of campaign_id in the case where campaign_id does not match
    media_data = [
        ("LINE_001", "NA", "CAMP_001", date(2024, 1, 15), "100", "5000", "10", "1500.50", datetime(2024, 1, 15, 10, 0)),
        ("LINE_001", "NA", "CAMP_001", date(2024, 1, 16), "150", "6000", "15", "2000.75", datetime(2024, 1, 16, 10, 0)),
        ("LINE_002", "NA", "CAMP_001", date(2024, 1, 15), "200", "8000", "20", "3000.00", datetime(2024, 1, 15, 10, 0)),
        ("LINE_003", "NA", "CAMP_002", date(2024, 2, 10), "50", "2000", "5", "500.00", datetime(2024, 2, 10, 10, 0)),
    ]

    order_data = [
        ("LINE_001", date(2024, 1, 10), date(2024, 1, 31), "10000", "GB"),
        ("LINE_002", date(2024, 1, 10), date(2024, 1, 31), "15000", "GB"),
        ("LINE_003", date(2024, 2, 1), date(2024, 2, 28), "5000", "GB"),
        ("LINE_004", date(2024, 1, 10), date(2024, 1, 31), "8000", "US"),  # Different country
    ]

    floodlight_data = [
        ("LINE_001", date(2024, 1, 15), "5000.50"),
        ("LINE_001", date(2024, 1, 20), "3000.25"),
        ("LINE_002", date(2024, 1, 18), "7500.00"),
        ("LINE_003", date(2024, 2, 15), "2000.00"),
    ]

    # Create DataFrames
    media_df = create_test_df(spark, media_data, media_schema)
    order_df = create_test_df(spark, order_data, order_schema)
    floodlight_df = create_test_df(spark, floodlight_data, floodlight_schema)
    unified_df = create_test_df(spark, unified_data, unified_schema)

    # Process data
    result = youtube_and_dv360_processor(media_df, order_df, floodlight_df, unified_df, channel_type='youtube')

    # Define EXPECTED OUTPUT Schema
    expected_schema = T.StructType([
        T.StructField("campaign_id", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("reach", T.LongType()),
        T.StructField("clicks", T.LongType()),
        T.StructField("impressions", T.LongType()),
        T.StructField("sales", T.DoubleType()),
        T.StructField("conversions", T.LongType()),
        T.StructField("booking_id", T.StringType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("media_spend_amt", T.DoubleType())
    ])

    expected_data = [
        ("CAMP_001", "YouTube", "TrueView", 25000, 300, 13000, 15500.75, 30, "BOOK_001", "Awareness", 4500.0),
        ("CAMP_002", "YouTube", "Bumper", 5000, 50, 2000, 2000.0, 5, "BOOK_002", "Consideration", 500.0),
    ]

    expected_df = create_test_df(spark, expected_data, expected_schema)

    # 2. Collect and compare data
    result_data = sorted(result.collect(), key=lambda x: x["campaign_id"])
    expected_data = expected_df.collect()

    assert len(result_data) == len(expected_data)

    assert_df_equality(
        result,
        expected_df
    )


def test_dv360_processor_multiple_campaigns(spark_session):
    """Test with multiple campaigns and verify exact expected output"""
    spark = spark_session

    media_schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("insertion_order_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("clicks", T.StringType(), True),
        T.StructField("impressions", T.StringType(), True),
        T.StructField("total_conversions", T.StringType(), True),
        T.StructField("revenue", T.StringType(), True),
        T.StructField("run_at", T.TimestampType(), True),
    ])

    order_schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("date_from", T.DateType(), True),
        T.StructField("date_until", T.DateType(), True),
        T.StructField("total_reach", T.StringType(), True),
        T.StructField("country", T.StringType(), True),
    ])

    unified_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
    ])

    floodlight_schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("spend", T.StringType(), True),
    ])

    # Test Data (3 unified campaigns)
    unified_data = [
        ("CAMP_001", date(2024, 1, 10), date(2024, 1, 31), "YouTube", "BOOK_001", "Awareness", "TrueView"),
        ("CAMP_002", date(2024, 2, 1), date(2024, 2, 28), "YouTube", "BOOK_002", "Consideration", "Bumper"),
    ]

    media_data = [
        ("LINE_001", "CAMP_001", "CAMP_001", date(2024, 1, 15), "100", "5000", "10", "1500.50", datetime(2024, 1, 15, 10, 0)),
        ("LINE_001", "CAMP_001", "CAMP_001", date(2024, 1, 16), "150", "6000", "15", "2000.75", datetime(2024, 1, 16, 10, 0)),
        ("LINE_002", "CAMP_001", "CAMP_001", date(2024, 1, 15), "200", "8000", "20", "3000.00", datetime(2024, 1, 15, 10, 0)),
        ("LINE_003", "CAMP_002", "CAMP_002", date(2024, 2, 10), "50", "2000", "5", "500.00", datetime(2024, 2, 10, 10, 0)),
    ]

    order_data = [
        ("LINE_001", date(2024, 1, 10), date(2024, 1, 31), "10000", "GB"),
        ("LINE_002", date(2024, 1, 10), date(2024, 1, 31), "15000", "GB"),
        ("LINE_003", date(2024, 2, 1), date(2024, 2, 28), "5000", "GB"),
        ("LINE_004", date(2024, 1, 10), date(2024, 1, 31), "8000", "US"),  # Different country
    ]

    floodlight_data = [
        ("LINE_001", date(2024, 1, 15), "5000.50"),
        ("LINE_001", date(2024, 1, 20), "3000.25"),
        ("LINE_002", date(2024, 1, 18), "7500.00"),
        ("LINE_003", date(2024, 2, 15), "2000.00"),
    ]

    # Create DataFrames
    media_df = create_test_df(spark, media_data, media_schema)
    order_df = create_test_df(spark, order_data, order_schema)
    floodlight_df = create_test_df(spark, floodlight_data, floodlight_schema)
    unified_df = create_test_df(spark, unified_data, unified_schema)

    # Process data
    result = youtube_and_dv360_processor(media_df, order_df, floodlight_df, unified_df, channel_type='dv360')

    # Define EXPECTED OUTPUT Schema
    expected_schema = T.StructType([
        T.StructField("campaign_id", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("reach", T.LongType()),
        T.StructField("clicks", T.LongType()),
        T.StructField("impressions", T.LongType()),
        T.StructField("sales", T.DoubleType()),
        T.StructField("conversions", T.LongType()),
        T.StructField("booking_id", T.StringType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("media_spend_amt", T.DoubleType())
    ])

    expected_data = [
        ("CAMP_001", "YouTube", "TrueView", 25000, 300, 13000, 15500.75, 30, "BOOK_001", "Awareness", 4500.0),
        ("CAMP_002", "YouTube", "Bumper", 5000, 50, 2000, 2000.0, 5, "BOOK_002", "Consideration", 500.0),
    ]

    expected_df = create_test_df(spark, expected_data, expected_schema)

    # 2. Collect and compare data
    result_data = sorted(result.collect(), key=lambda x: x["campaign_id"])
    expected_data = expected_df.collect()

    assert len(result_data) == len(expected_data)

    assert_df_equality(
        result,
        expected_df
    )


@pytest.fixture
def sample_dataframes(spark_session, camp_request_link_schema):
    # Schema for camp_request_link_df
    spark = spark_session

    camp_request_link_df = spark.createDataFrame([
        (
            "CAMP1",
            date(2025, 8, 1),
            datetime(2025, 8, 2, 10, 0, 0),
            100.0, 2, 1000, 50
        ),
        (
            "CAMP1",
            date(2025, 8, 3),
            datetime(2025, 8, 3, 12, 0, 0),
            200.0, 3, 1500, 70
        ),
    ], schema=camp_request_link_schema)

    # Schema for unified_campaign_df
    unified_campaign_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True)
    ])

    unified_campaign_df = spark.createDataFrame([
        (
            "CAMP1",
            date(2025, 8, 1),
            date(2025, 8, 5),
            "Online", "B001", "Promo", "J001", "HIER_001"
        )
    ], schema=unified_campaign_schema)

    # Schema for campaign_citcam_sat_df
    campaign_citcam_sat_schema = T.StructType([
        T.StructField("campaign_placements", T.StringType(), True),
        T.StructField("advertising_campaign_nk1", T.StringType(), True)
    ])

    campaign_citcam_sat_df = spark.createDataFrame([
        ("Sponsored Products-Sainsburys Cross Sell", "CAMP1"),
    ], schema=campaign_citcam_sat_schema)

    # Schema for user_journey_data_filtered
    user_journey_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True)
    ])

    user_journey_data_filtered = spark.createDataFrame([
        ("CAMP1", "B001", "Online", "sponsored products - sainsburys cross sell", "L001"),
        ("CAMP1", "B001", "Online", "sponsored products - sainsburys cross sell", "L002"),
    ], schema=user_journey_schema)

    map_df_schema = T.StructType([
        T.StructField("mapping_type", T.StringType(), True),
        T.StructField("media_placement", T.StringType(), True),
        T.StructField("marketing_subchannel", T.StringType(), True),
        T.StructField("load_ts", T.DateType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("media_provider", T.StringType(), True),
        T.StructField("media_type", T.StringType(), True),
        T.StructField("media_subtype", T.StringType(), True),
        T.StructField("store_type", T.StringType(), True),
        T.StructField("template_type", T.StringType(), True),
        T.StructField("store_location", T.StringType(), True),
        T.StructField("channel_type", T.StringType(), True),
        T.StructField("technical_metadata", T.StringType(), True),

    ])

    map_df = spark.createDataFrame([
        ("INTERACTION_EVENT", "Sponsored Products-Sainsburys Cross Sell", "sponsored products - sainsburys cross sell", date(2025, 8, 1), 'onsite', 'ad', 'gol', 'citrus', 'new', 'temp', '62', 'sponsored', '{"record_deleted_flag": "N", "LOAD_USER": "userB", "LOAD_TS": "2025-11-02T10:00:00Z"}')
    ], schema=map_df_schema)

    return camp_request_link_df, unified_campaign_df, campaign_citcam_sat_df, user_journey_data_filtered, map_df


@pytest.fixture
def measurement_campaign_execution_data(spark_session):
    """Create test data for measurement_campaign_execution_df"""
    schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("job_status", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True)
    ])

    data = [
        ("BOOK_001", "CAMP_001", "During", "In-progress", datetime(2024, 1, 15, 10, 0, 0)),
        ("BOOK_002", "CAMP_002", "During", "In-progress", datetime(2024, 1, 15, 11, 0, 0)),
        ("BOOK_003", "CAMP_003", "During", "Completed", datetime(2024, 1, 14, 9, 0, 0)),
        ("BOOK_004", "CAMP_004", "After", "In-progress", datetime(2024, 1, 15, 12, 0, 0))
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def user_journey_offer_data(spark_session):
    """Create test data for user_journey_offer_df"""
    schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("isconversion", T.IntegerType(), True),
        T.StructField("net_sales_amt", T.DoubleType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_type", T.StringType(), True)
    ])

    data = [
        ("BOOK_001", "During", "CAMP_001", "USER_001", "JOURNEY_001", 1, 150.0, "Meta", "Meta", datetime(2024, 1, 15, 10, 0, 0), "instore"),
        ("BOOK_001", "During", "CAMP_001", "USER_002", "JOURNEY_002", 0, 0.0, "Meta", "Instagram", datetime(2024, 1, 15, 10, 0, 0), "onsite"),
        ("BOOK_002", "During", "CAMP_002", "USER_003", "JOURNEY_003", 1, 200.0, "YouTube", "Video", datetime(2024, 1, 15, 11, 0, 0), "offsite"),
        ("BOOK_002", "During", "CAMP_003", "USER_004", "JOURNEY_004", 0, 0.0, "Coupon at Till", "Digital", datetime(2024, 1, 15, 11, 0, 0), "targeted_media")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def unified_campaign_data(spark_session):
    """Create test data for unified_campaign_df"""
    schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True)
    ])

    data = [
        ("CAMP_001", "BOOK_001", "Meta", "Meta", "Social", 1000.0, date(2024, 1, 10), date(2024, 1, 20), "JOB_001", datetime(2024, 1, 15, 10, 0, 0), "3009"),
        ("CAMP_002", "BOOK_002", "YouTube", "Video", "Digital", 2000.0, date(2024, 1, 12), date(2024, 1, 22), "JOB_002", datetime(2024, 1, 15, 11, 0, 0), "3014"),
        ("CAMP_003", "BOOK_002", "Coupon at Till", "Digital", "In-store", 500.0, date(2024, 1, 11), date(2024, 1, 21), "JOB_003", datetime(2024, 1, 15, 11, 0, 0), "2050")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def user_journey_offer_data_offsite_only(spark_session):
    """Create test data for user_journey_offer_df"""
    schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("isconversion", T.IntegerType(), True),
        T.StructField("net_sales_amt", T.DoubleType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_type", T.StringType(), True)
    ])

    data = [
        ("BOOK_001", "During", "CAMP_001", "USER_001", "JOURNEY_001", 1, 150.0, "Meta", "Meta", datetime(2024, 1, 15, 10, 0, 0), "offsite"),
        ("BOOK_001", "During", "CAMP_001", "USER_002", "JOURNEY_002", 0, 0.0, "Meta", "Instagram", datetime(2024, 1, 15, 10, 0, 0), "offsite"),
        ("BOOK_002", "During", "CAMP_002", "USER_003", "JOURNEY_003", 1, 200.0, "Display", "Display - DV360", datetime(2024, 1, 15, 11, 0, 0), "offsite"),
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def user_journey_offer_data_mixed_marketing_type(spark_session):
    """Create test data for user_journey_offer_df"""
    schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("isconversion", T.IntegerType(), True),
        T.StructField("net_sales_amt", T.DoubleType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_type", T.StringType(), True)
    ])

    data = [
        ("BOOK_001", "During", "CAMP_001", "USER_001", "JOURNEY_001", 1, 150.0, "Meta", "Meta", datetime(2024, 1, 15, 10, 0, 0), "offsite"),
        ("BOOK_001", "During", "CAMP_001", "USER_002", "JOURNEY_002", 0, 0.0, "Meta", "Instagram", datetime(2024, 1, 15, 10, 0, 0), "offsite"),
        ("BOOK_002", "During", "CAMP_002", "USER_003", "JOURNEY_003", 1, 200.0, "Coupon at Till", "Digital", datetime(2024, 1, 15, 11, 0, 0), "In-store")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def user_journey_offer_data_non_offsite_marketing_type(spark_session):
    """Create test data for user_journey_offer_df"""
    schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True),
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True),
        T.StructField("userjourney_id", T.StringType(), True),
        T.StructField("isconversion", T.IntegerType(), True),
        T.StructField("net_sales_amt", T.DoubleType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_type", T.StringType(), True)
    ])

    data = [
        ("BOOK_002", "During", "CAMP_002", "USER_003", "JOURNEY_003", 1, 200.0, "Coupon at Till", "Digital", datetime(2024, 1, 15, 11, 0, 0), "In-store")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def unified_campaign_data_offsite_only(spark_session):
    """Create test data for unified_campaign_df"""
    schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True)
    ])

    data = [
        ("CAMP_001", "BOOK_001", "Meta", "Meta", "offsite", 1000.0, date(2024, 1, 10), date(2024, 1, 20), "JOB_001", datetime(2024, 1, 15, 10, 0, 0), "3009"),
        ("CAMP_002", "BOOK_002", "Display", "Display - DV360", "offsite", 2000.0, date(2024, 1, 10), date(2024, 1, 20), "JOB_001", datetime(2024, 1, 15, 10, 0, 0), "3001"),
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def unified_campaign_data_mixed_marketing_type(spark_session):
    """Create test data for unified_campaign_df"""
    schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True)
    ])

    data = [
        ("CAMP_001", "BOOK_001", "Meta", "Meta", "offsite", 1000.0, date(2024, 1, 10), date(2024, 1, 20), "JOB_001", datetime(2024, 1, 15, 10, 0, 0), "3009"),
        ("CAMP_002", "BOOK_002", "Display", "Display - DV360", "offsite", 2000.0, date(2024, 1, 10), date(2024, 1, 20), "JOB_001", datetime(2024, 1, 15, 10, 0, 0), "3001"),
        ("CAMP_003", "BOOK_002", "Coupon at Till", "Digital", "In-store", 500.0, date(2024, 1, 11), date(2024, 1, 21), "JOB_003", datetime(2024, 1, 15, 11, 0, 0), "2050")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def unified_campaign_data_non_offsite_marketing_type(spark_session):
    """Create test data for unified_campaign_df"""
    schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("media_spend_amt", T.DoubleType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("job_bag_number", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("marketing_hierarchy_cd", T.StringType(), True)
    ])

    data = [
        ("CAMP_002", "BOOK_002", "Coupon at Till", "Digital", "In-store", 500.0, date(2024, 1, 11), date(2024, 1, 21), "JOB_003", datetime(2024, 1, 15, 11, 0, 0), "2050")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def digital_trading_campaign_link_data(spark_session):
    """Create test data for digital_trading_campaign_link_df (Meta)"""
    schema = T.StructType([
        T.StructField("digital_trading_campaign_nk1", T.StringType(), True),
        T.StructField("digital_trading_campaign_channel_nk1", T.StringType(), True)
    ])

    data = [
        ("CAMP_001", "CHANNEL_001"),
        ("CAMP_002", "CHANNEL_002")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def digital_trading_lineitem_insight_data(spark_session):
    """Create test data for digital_trading_lineitem_facebook_insight_df (Meta)"""
    schema = T.StructType([
        T.StructField("digital_trading_campaign_nk1", T.StringType(), True),
        T.StructField("reporting_start_dt", T.DateType(), True),
        T.StructField("reporting_end_dt", T.DateType(), True),
        T.StructField("record_arrival_ts", T.TimestampType(), True),
        T.StructField("digital_trading_insight_id", T.StringType(), True),
        T.StructField("digital_trading_lineitem_nk1", T.StringType(), True),
        T.StructField("measures", T.MapType(T.StringType(), T.MapType(T.StringType(), T.StringType())), True)
    ])

    # Create nested map structure for MEASURES
    measures_data = {
        "summary": {"reach": "1000", "clicks": "50", "impressions": "5000"},
        "sales": {"total": "1500"},
        "conversion": {"totals": "25"},
        "internals": {"media_spend": "800"}
    }

    data = [
        ("CHANNEL_001", date(2024, 1, 10), date(2024, 1, 20), datetime(2024, 1, 15, 10, 0, 0), "INSIGHT_001", "LINE_001", measures_data),
        ("CHANNEL_002", date(2024, 1, 12), date(2024, 1, 22), datetime(2024, 1, 15, 11, 0, 0), "INSIGHT_002", "LINE_002", measures_data)
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def dv360_media_report_data(spark_session):
    """Create test data for dv360_media_report_df (YouTube)"""
    schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("time_of_day", T.StringType(), True),
        T.StructField("device_type", T.StringType(), True),
        T.StructField("clicks", T.IntegerType(), True),
        T.StructField("impressions", T.IntegerType(), True),
        T.StructField("total_conversions", T.IntegerType(), True),
        T.StructField("revenue", T.DoubleType(), True),
        T.StructField("run_at", T.TimestampType(), True),
        T.StructField("subchannel_name", T.StringType(), True)
    ])

    data = [
        ("JOB_002", "LINE_002", date(2024, 1, 15), "Morning", "Mobile", 30, 3000, 10, 1200.0, datetime(2024, 1, 15, 11, 0, 0), "YouTube|Video"),
        ("JOB_002", "LINE_002", date(2024, 1, 16), "Evening", "Desktop", 20, 2000, 5, 800.0, datetime(2024, 1, 16, 11, 0, 0), "YouTube|Premium")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def map_df(spark_session):
    map_df_schema = T.StructType([
        T.StructField("mapping_type", T.StringType(), True),
        T.StructField("media_placement", T.StringType(), True),
        T.StructField("marketing_subchannel", T.StringType(), True),
        T.StructField("load_ts", T.DateType(), True),
        T.StructField("marketing_channel", T.StringType(), True),
        T.StructField("media_provider", T.StringType(), True),
        T.StructField("media_type", T.StringType(), True),
        T.StructField("media_subtype", T.StringType(), True),
        T.StructField("store_type", T.StringType(), True),
        T.StructField("template_type", T.StringType(), True),
        T.StructField("store_location", T.StringType(), True),
        T.StructField("channel_type", T.StringType(), True),
        T.StructField("technical_metadata", T.StringType(), True),

    ])
    df = spark_session.createDataFrame([
        ("INTERACTION_EVENT", "Main-Sub1", "Sub1", date(2025, 8, 1), 'onsite', 'ad', 'gol', 'citrus', 'new', 'temp', '62', 'sponsored', '{"RECORD_DELETED_FLAG": "Y", "LOAD_USER": "userB", "LOAD_TS": "2025-11-02T10:00:00Z"}')
    ], schema=map_df_schema)

    return df


@pytest.fixture
def dv360_order_report_data(spark_session):
    """Create test data for dv360_order_report_df (YouTube)"""
    schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("date_from", T.DateType(), True),
        T.StructField("date_until", T.DateType(), True),
        T.StructField("country", T.StringType(), True),
        T.StructField("total_reach", T.IntegerType(), True)
    ])

    data = [
        ("LINE_002", date(2024, 1, 12), date(2024, 1, 22), "GB", 800),
        ("LINE_003", date(2024, 1, 12), date(2024, 1, 22), "US", 1200)
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def dv360_floodlight_report_data(spark_session):
    """Create test data for dv360_floodlight_report_df (YouTube)"""
    schema = T.StructType([
        T.StructField("line_item_id", T.StringType(), True),
        T.StructField("campaign_date", T.DateType(), True),
        T.StructField("spend", T.DoubleType(), True)
    ])

    data = [
        ("LINE_002", date(2024, 1, 15), 600.0),
        ("LINE_002", date(2024, 1, 16), 400.0)
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def camp_request_link_data(spark_session, camp_request_link_schema):
    """Create test data for camp_request_link_df (Citrus)"""

    data = [
        ("CAMP_004", date(2024, 1, 15), 300.0, 5, 1000, 25)
    ]

    return spark_session.createDataFrame(data, camp_request_link_schema)


@pytest.fixture
def campaign_citcam_sat_data(spark_session):
    """Create test data for campaign_citcam_sat_df (Citrus)"""
    schema = T.StructType([
        T.StructField("advertising_campaign_nk1", T.StringType(), True),
        T.StructField("campaign_placements", T.StringType(), True)
    ])

    data = [
        ("CAMP_004", "GOL-Display")
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def meta_campaign_data(spark_session):
    """Create test data for campaign_citcam_sat_df (Citrus)"""
    schema = T.StructType([
        T.StructField("loyalty_id", T.StringType(), True)
    ])

    data = [
        ("CAMP_004",)
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def measurement_marketing_hierarchy_df(spark_session):
    """Create test data for measurement marketing channel hierarchy"""
    schema = T.StructType([
        T.StructField("marketing_hierarchy_cd", T.StringType(), False),
        T.StructField("mapping_type", T.StringType(), True),
        T.StructField("marketing_channel", T.StringType(), False),
        T.StructField("marketing_subchannel", T.StringType(), True),
        T.StructField("media_type", T.StringType(), True),
        T.StructField("channel_type", T.StringType(), True),
        T.StructField("in_scope_flag", T.BooleanType(), False),
        T.StructField("measurement_campaign_ready", T.BooleanType(), False),
    ])

    data = [
        ("MH001", "CHANNEL", "meta", "social", "DISPLAY", "offsite", True, True),
        ("MH002", "CHANNEL", "youtube", "video", "VIDEO", "offsite", True, True),
        ("MH003", "CHANNEL", "google", "search", "SEARCH", "offsite", False, True),
        ("MH004", "CHANNEL", "citrus", "retail", "DISPLAY", "offsite", True, True),
    ]

    return spark_session.createDataFrame(data, schema)


@pytest.fixture
def subchannel_hierarchy_codes():
    """Fixture for subchannel hierarchy codes dictionary

    Note: Values are strings to match the marketing_hierarchy_cd column type
    and to work with the .lower() calls in the production code.
    """
    return {
        'ecoupons': ['4013'],
        'dv360': ['3001'],
        'meta': ['3009'],
        'youtube': ['3014'],
        'coupon_at_till': ['2050', '2051']
    }


@pytest.fixture
def mock_processors():
    """Mock the individual processor functions"""
    with patch('spark_pipeline.reach_engagement.reach_engagement_pollen.meta_processor') as mock_meta, \
            patch('spark_pipeline.reach_engagement.reach_engagement_pollen.youtube_and_dv360_processor') as mock_youtube, \
            patch('spark_pipeline.reach_engagement.reach_engagement_pollen.citrus_processor') as mock_citrus, \
            patch('spark_pipeline.reach_engagement.reach_engagement_pollen.calculate_reach') as mock_calculate_reach, \
            patch('spark_pipeline.reach_engagement.reach_engagement_pollen.fetch_in_progress_campaigns') as mock_fetch_campaigns, \
            patch('spark_pipeline.reach_engagement.reach_engagement_pollen.get_latest_data_for_campaigns') as mock_get_latest:

        yield {
            'meta_processor': mock_meta,
            'youtube_and_dv360_processor': mock_youtube,
            'citrus_processor': mock_citrus,
            'calculate_reach': mock_calculate_reach,
            'fetch_in_progress_campaigns': mock_fetch_campaigns,
            'get_latest_data_for_campaigns': mock_get_latest,
        }


def create_mock_processor_outputs(spark_session):
    """Create mock outputs for each processor"""
    base_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("reach", T.IntegerType(), True),
        T.StructField("clicks", T.IntegerType(), True),
        T.StructField("impressions", T.IntegerType(), True),
        T.StructField("sales", T.DoubleType(), True),
        T.StructField("conversions", T.IntegerType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True)
    ])

    meta_schema = T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("reach", T.IntegerType(), True),
        T.StructField("clicks", T.IntegerType(), True),
        T.StructField("impressions", T.IntegerType(), True),
        T.StructField("sales", T.DoubleType(), True),
        T.StructField("conversions", T.IntegerType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("media_spend_amt", T.IntegerType(), True)
    ])

    # Meta processor output
    meta_data = [
        ("CAMP_001", "Meta", "Meta", 1000, 50, 5000, 1500.0, 25, "BOOK_001", "Offsite", 800)
    ]
    meta_df = spark_session.createDataFrame(meta_data, meta_schema)

    # youtube_schema = base_schema.add(T.StructField("MEDIA_SPEND_AMT", T.IntegerType(), True))
    youtube_schema = meta_schema
    # YouTube processor output
    youtube_data = [
        ("CAMP_002", "YouTube", "Video", 800, 50, 5000, 1000.0, 15, "BOOK_002", "Offsite", 1200)
    ]
    youtube_df = spark_session.createDataFrame(youtube_data, youtube_schema)

    # In-store processor output (calculate_reach)
    instore_data = [
        ("CAMP_005", "Magazine", "Print", 500, None, None, 300.0, 8, "BOOK_003", "In-store")
    ]
    instore_df = spark_session.createDataFrame(instore_data, base_schema)

    # Citrus processor output
    citrus_data = [
        ("CAMP_004", "GOL", "Display", 600, 30, 2000, 400.0, 12, "BOOK_001", "Digital")
    ]
    citrus_df = spark_session.createDataFrame(citrus_data, base_schema)

    # Coupon processor output (calculate_reach)
    coupon_data = [
        ("CAMP_003", "Coupon at Till", "Digital", 300, None, None, 100.0, 5, "BOOK_002", "In-store")
    ]
    coupon_df = spark_session.createDataFrame(coupon_data, base_schema)

    return {
        'meta': meta_df,
        'youtube': youtube_df,
        'instore': instore_df,
        'citrus': citrus_df,
        'coupon': coupon_df
    }


def test_process_all_campaigns_success(spark_session, measurement_campaign_execution_data,
                                       user_journey_offer_data, unified_campaign_data,
                                       digital_trading_campaign_link_data,
                                       digital_trading_lineitem_insight_data,
                                       dv360_media_report_data, dv360_order_report_data,
                                       dv360_floodlight_report_data, camp_request_link_data,
                                       campaign_citcam_sat_data, meta_campaign_data,
                                       mock_processors, map_df, measurement_marketing_hierarchy_df):
    """Test successful execution of process_all_campaigns"""

    # Setup mock returns
    mock_outputs = create_mock_processor_outputs(spark_session)

    # Configure mock fetch_in_progress_campaigns
    in_progress_mock_data = [("BOOK_001", "During"), ("BOOK_002", "During")]
    in_progress_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True)
    ])
    in_progress_df = spark_session.createDataFrame(in_progress_mock_data, in_progress_schema)
    mock_processors['fetch_in_progress_campaigns'].return_value = in_progress_df

    # Configure mock get_latest_data_for_campaigns
    mock_processors['get_latest_data_for_campaigns'].return_value = user_journey_offer_data

    # Configure processor mocks
    mock_processors['meta_processor'].return_value = mock_outputs['meta']
    mock_processors['youtube_and_dv360_processor'].return_value = mock_outputs['youtube']
    mock_processors['citrus_processor'].return_value = mock_outputs['citrus']

    # Mock calculate_reach to return different data for different calls
    def calculate_reach_side_effect(journey_data, campaigns_df, group_by_column, subchannel_hierarchy_codes=None):
        if group_by_column == "marketing_type":
            return mock_outputs['instore']
        else:  # subchannel_name
            return mock_outputs['coupon']

    mock_processors['calculate_reach'].side_effect = calculate_reach_side_effect

    # Generate correlation ID
    correlation_id = str(uuid.uuid4())

    # Subchannel hierarchy codes
    subchannel_hierarchy_codes = {
        'ecoupons': ['4013'],
        'dv360': ['3001'],
        'meta': ['3009'],
        'youtube': ['3014'],
        'coupon_at_till': ['2050', '2051']
    }

    # Execute the function
    result_df = process_all_campaigns(
        measurement_campaign_execution_data,
        user_journey_offer_data,
        digital_trading_campaign_link_data,
        digital_trading_lineitem_insight_data,
        dv360_media_report_data,
        dv360_order_report_data,
        dv360_floodlight_report_data,
        camp_request_link_data,
        campaign_citcam_sat_data,
        meta_campaign_data,
        unified_campaign_data,
        correlation_id,
        map_df,
        measurement_marketing_hierarchy_df,
        campaign_complete=True,
        subchannel_hierarchy_codes=subchannel_hierarchy_codes
    )

    # Assertions
    assert result_df is not None
    assert isinstance(result_df, DataFrame)
    assert (result_df.count() == 2)

    # Check that result has expected columns
    expected_columns = [
        "campaign_id", "channel_name", "subchannel_name", "reach_cnt",
        "clicks_cnt", "impressions_cnt", "sales_amt", "conversions_cnt",
        "booking_id", "marketing_type", "media_spend_amt", "engagement_ctr_pct",
        "load_ts", "job_run_id", "marketing_hierarchy_cd"
    ]

    result_columns = result_df.columns
    for col in expected_columns:
        assert col in result_columns, f"Missing expected column: {col}"

    # --- DEDUPLICATE REACH COLUMN CHECKS ---
    # Check that dedup_campaign_reach column exists
    assert "dedup_campaign_reach" in result_columns, "dedup_campaign_reach column missing"

    # Verify row count (should have combined data from all processors)
    result_count = result_df.count()
    assert result_count > 0, "Result DataFrame should not be empty"

    # Verify JOB_RUN_ID is set correctly
    job_run_ids = result_df.select("JOB_RUN_ID").distinct().collect()
    assert len(job_run_ids) == 1
    assert job_run_ids[0]["JOB_RUN_ID"] == correlation_id

    # Verify LOAD_TS is populated
    load_ts_count = result_df.filter(F.col("LOAD_TS").isNotNull()).count()
    assert load_ts_count == result_count, "All rows should have LOAD_TS populated"

    # Verify processors were called with correct arguments
    mock_processors['fetch_in_progress_campaigns'].assert_called_once_with(measurement_campaign_execution_data)
    mock_processors['get_latest_data_for_campaigns'].assert_called_once()

    # Verify calculate_reach not called (for coupon)
    assert mock_processors['calculate_reach'].call_count == 0

    # Verify youtube_and_dv360_processor called once for YouTube campaign (CAMP_002)
    assert mock_processors['youtube_and_dv360_processor'].call_count == 1

    # Verify meta_processor called once for Meta campaign (CAMP_001)
    assert mock_processors['meta_processor'].call_count == 1


@pytest.mark.parametrize(
    "user_journey_fixture, unified_campaign_fixture",
    [
        ("user_journey_offer_data_offsite_only", "unified_campaign_data_offsite_only"),
        ("user_journey_offer_data_mixed_marketing_type", "unified_campaign_data_mixed_marketing_type"),
        ("user_journey_offer_data_non_offsite_marketing_type", "unified_campaign_data_non_offsite_marketing_type"),
    ]
)
def test_process_all_campaigns_variations(
    spark_session,
    measurement_campaign_execution_data,
    digital_trading_campaign_link_data,
    digital_trading_lineitem_insight_data,
    dv360_media_report_data,
    dv360_order_report_data,
    dv360_floodlight_report_data,
    camp_request_link_data,
    campaign_citcam_sat_data,
    meta_campaign_data,
    map_df,
    measurement_marketing_hierarchy_df,
    subchannel_hierarchy_codes,
    mock_processors,
    request,
    user_journey_fixture,
    unified_campaign_fixture
):
    """Test process_all_campaigns with various user journey and campaign data."""

    # Get the fixture values dynamically
    user_journey_df = request.getfixturevalue(user_journey_fixture)
    unified_campaign_df = request.getfixturevalue(unified_campaign_fixture)

    # Setup mock returns
    mock_outputs = create_mock_processor_outputs(spark_session)

    # Configure mock fetch_in_progress_campaigns
    in_progress_mock_data = [("BOOK_001", "During"), ("BOOK_002", "During")]
    in_progress_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True)
    ])
    in_progress_df = spark_session.createDataFrame(in_progress_mock_data, in_progress_schema)
    mock_processors['fetch_in_progress_campaigns'].return_value = in_progress_df

    # Configure mock get_latest_data_for_campaigns
    mock_processors['get_latest_data_for_campaigns'].return_value = user_journey_df

    # Configure processor mocks
    mock_processors['meta_processor'].return_value = mock_outputs['meta']
    mock_processors['youtube_and_dv360_processor'].return_value = mock_outputs['youtube']
    mock_processors['citrus_processor'].return_value = mock_outputs['citrus']

    def calculate_reach_side_effect(journey_data, campaigns_df, group_by_column, subchannel_hierarchy_codes=None):
        if group_by_column == "marketing_type":
            return mock_outputs['instore']
        else:
            return mock_outputs['coupon']

    mock_processors['calculate_reach'].side_effect = calculate_reach_side_effect

    # Generate correlation ID
    correlation_id = str(uuid.uuid4())

    # Execute the function
    result_df = process_all_campaigns(
        measurement_campaign_execution_data,
        user_journey_df,
        digital_trading_campaign_link_data,
        digital_trading_lineitem_insight_data,
        dv360_media_report_data,
        dv360_order_report_data,
        dv360_floodlight_report_data,
        camp_request_link_data,
        campaign_citcam_sat_data,
        meta_campaign_data,
        unified_campaign_df,
        correlation_id,
        map_df,
        measurement_marketing_hierarchy_df,
        campaign_complete=True,
        subchannel_hierarchy_codes=subchannel_hierarchy_codes
    )

    # Assertions
    assert result_df is not None
    assert isinstance(result_df, DataFrame)

    expected_columns = [
        "campaign_id", "channel_name", "subchannel_name", "reach_cnt",
        "clicks_cnt", "impressions_cnt", "sales_amt", "conversions_cnt",
        "booking_id", "marketing_type", "media_spend_amt", "engagement_ctr_pct",
        "load_ts", "job_run_id", "marketing_hierarchy_cd"
    ]
    result_columns = result_df.columns
    for col in expected_columns:
        assert col in result_columns, f"Missing expected column: {col}"

    assert "dedup_campaign_reach" in result_columns, "dedup_campaign_reach column missing"

    distinct_marketing_types = [
        row["marketing_type"].lower()
        for row in result_df.select(
            F.lower(F.col("marketing_type")).alias("marketing_type")
        ).distinct().collect()
    ]
    offsite_only = len(distinct_marketing_types) == 1 and distinct_marketing_types[0] == "offsite"
    if offsite_only:
        for row in result_df.collect():
            assert row["dedup_campaign_reach"] == row["reach_cnt"], (
                f"dedup_campaign_reach ({row['dedup_campaign_reach']}) != reach_cnt ({row['reach_cnt']}) for row: {row}"
            )

    result_count = result_df.count()
    assert result_count > 0, "Result DataFrame should not be empty"

    job_run_ids = result_df.select("JOB_RUN_ID").distinct().collect()
    assert len(job_run_ids) == 1
    assert job_run_ids[0]["JOB_RUN_ID"] == correlation_id

    load_ts_count = result_df.filter(F.col("LOAD_TS").isNotNull()).count()
    assert load_ts_count == result_count, "All rows should have LOAD_TS populated"

    mock_processors['fetch_in_progress_campaigns'].assert_called_once_with(measurement_campaign_execution_data)
    mock_processors['get_latest_data_for_campaigns'].assert_called_once()


def assert_reach_engagement_result(result_df, correlation_id):
    """Common assertions for reach engagement result DataFrame."""
    assert result_df is not None
    assert isinstance(result_df, DataFrame)

    expected_columns = [
        "campaign_id", "channel_name", "subchannel_name", "reach_cnt",
        "clicks_cnt", "impressions_cnt", "sales_amt", "conversions_cnt",
        "booking_id", "marketing_type", "media_spend_amt", "engagement_ctr_pct",
        "load_ts", "job_run_id", "marketing_hierarchy_cd"
    ]
    result_columns = result_df.columns
    for col in expected_columns:
        assert col in result_columns, f"Missing expected column: {col}"

    assert "dedup_campaign_reach" in result_columns, "dedup_campaign_reach column missing"

    result_count = result_df.count()
    assert result_count > 0, "Result DataFrame should not be empty"

    job_run_ids = result_df.select("JOB_RUN_ID").distinct().collect()
    assert len(job_run_ids) == 1
    assert job_run_ids[0]["JOB_RUN_ID"] == correlation_id

    load_ts_count = result_df.filter(F.col("LOAD_TS").isNotNull()).count()
    assert load_ts_count == result_count, "All rows should have LOAD_TS populated"

    # Offsite-only dedup check (case-insensitive)
    distinct_marketing_types = [
        row["marketing_type"].lower()
        for row in result_df.select(
            F.lower(F.col("marketing_type")).alias("marketing_type")
        ).distinct().collect()
    ]
    offsite_only = len(distinct_marketing_types) == 1 and distinct_marketing_types[0] == "offsite"
    if offsite_only:
        for row in result_df.collect():
            assert row["dedup_campaign_reach"] == row["reach_cnt"], (
                f"dedup_campaign_reach ({row['dedup_campaign_reach']}) != reach_cnt ({row['reach_cnt']}) for row: {row}"
            )


@pytest.mark.parametrize(
    "user_journey_fixture, unified_campaign_fixture",
    [
        ("user_journey_offer_data_offsite_only", "unified_campaign_data_offsite_only"),
        ("user_journey_offer_data_mixed_marketing_type", "unified_campaign_data_mixed_marketing_type"),
        ("user_journey_offer_data_non_offsite_marketing_type", "unified_campaign_data_non_offsite_marketing_type"),
    ]
)
def test_process_all_campaigns_variations_1(
    spark_session,
    measurement_campaign_execution_data,
    digital_trading_campaign_link_data,
    digital_trading_lineitem_insight_data,
    dv360_media_report_data,
    dv360_order_report_data,
    dv360_floodlight_report_data,
    camp_request_link_data,
    campaign_citcam_sat_data,
    meta_campaign_data,
    map_df,
    measurement_marketing_hierarchy_df,
    subchannel_hierarchy_codes,
    mock_processors,
    request,
    user_journey_fixture,
    unified_campaign_fixture
):
    """Test process_all_campaigns with various user journey and campaign data."""

    user_journey_df = request.getfixturevalue(user_journey_fixture)
    unified_campaign_dtf = request.getfixturevalue(unified_campaign_fixture)
    mock_outputs = create_mock_processor_outputs(spark_session)

    # Setup mocks
    in_progress_mock_data = [("BOOK_001", "During"), ("BOOK_002", "During")]
    in_progress_schema = T.StructType([
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("campaign_duration", T.StringType(), True)
    ])
    in_progress_df = spark_session.createDataFrame(in_progress_mock_data, in_progress_schema)
    mock_processors['fetch_in_progress_campaigns'].return_value = in_progress_df
    mock_processors['get_latest_data_for_campaigns'].return_value = user_journey_df
    mock_processors['meta_processor'].return_value = mock_outputs['meta']
    mock_processors['youtube_and_dv360_processor'].return_value = mock_outputs['youtube']
    mock_processors['citrus_processor'].return_value = mock_outputs['citrus']

    def calculate_reach_side_effect(journey_data, campaigns_df, group_by_column, subchannel_hierarchy_codes=None):
        if group_by_column == "marketing_type":
            return mock_outputs['instore']
        else:
            return mock_outputs['coupon']
    mock_processors['calculate_reach'].side_effect = calculate_reach_side_effect

    correlation_id = str(uuid.uuid4())

    result_df = process_all_campaigns(
        measurement_campaign_execution_data,
        user_journey_df,
        digital_trading_campaign_link_data,
        digital_trading_lineitem_insight_data,
        dv360_media_report_data,
        dv360_order_report_data,
        dv360_floodlight_report_data,
        camp_request_link_data,
        campaign_citcam_sat_data,
        meta_campaign_data,
        unified_campaign_dtf,
        correlation_id,
        map_df,
        measurement_marketing_hierarchy_df,
        campaign_complete=True,
        subchannel_hierarchy_codes=subchannel_hierarchy_codes
    )

    assert_reach_engagement_result(result_df, correlation_id)

    mock_processors['fetch_in_progress_campaigns'].assert_called_once_with(measurement_campaign_execution_data)
    mock_processors['get_latest_data_for_campaigns'].assert_called_once()

# ---------------------------------------------------------------------
#                         SHARED HELPERS
# ---------------------------------------------------------------------


USER_JOURNEY_SCHEMA = T.StructType([
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("campaign_duration", T.StringType(), True),
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("loyalty_id", T.StringType(), True),
    T.StructField("userjourney_id", T.StringType(), True),
    T.StructField("isconversion", T.IntegerType(), True),
    T.StructField("net_sales_amt", T.DoubleType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("load_ts", T.TimestampType(), True),
    T.StructField("marketing_type", T.StringType(), True)
])

UNIFIED_CAMPAIGN_SCHEMA = T.StructType([
    T.StructField("campaign_id", T.StringType(), True),
    T.StructField("booking_id", T.StringType(), True),
    T.StructField("channel_name", T.StringType(), True),
    T.StructField("subchannel_name", T.StringType(), True),
    T.StructField("marketing_type", T.StringType(), True),
    T.StructField("media_spend_amt", T.DoubleType(), True),
    T.StructField("campaign_start_dt", T.DateType(), True),
    T.StructField("campaign_end_dt", T.DateType(), True),
    T.StructField("job_bag_number", T.StringType(), True),
    T.StructField("load_ts", T.TimestampType(), True),
    T.StructField("marketing_hierarchy_cd", T.StringType(), True)
])

# ---------------------------------------------------------------------
#                     PARAMETERIZED DATA SETS
# ---------------------------------------------------------------------

USER_JOURNEY_DATASETS = {
    "offsite_only": [
        ("BOOK_001", "During", "CAMP_001", "USER_001", "J1", 1, 150.0,
         "Meta", "Meta", datetime(2024, 1, 15, 10), "offsite"),
        ("BOOK_001", "During", "CAMP_001", "USER_002", "J2", 0, 0.0,
         "Meta", "Instagram", datetime(2024, 1, 15, 10), "offsite"),
        ("BOOK_002", "During", "CAMP_002", "USER_003", "J3", 1, 200.0,
         "Display", "DV360", datetime(2024, 1, 15, 11), "offsite"),
    ],
    "mixed_marketing_type": [
        ("BOOK_001", "During", "CAMP_001", "USER_001", "J1", 1, 150.0,
         "Meta", "Meta", datetime(2024, 1, 15, 10), "offsite"),
        ("BOOK_001", "During", "CAMP_001", "USER_002", "J2", 0, 0.0,
         "Meta", "Instagram", datetime(2024, 1, 15, 10), "offsite"),
        ("BOOK_002", "During", "CAMP_002", "USER_003", "J3", 1, 200.0,
         "Coupon at Till", "Digital", datetime(2024, 1, 15, 11), "In-store")
    ],
    "non_offsite_only": [
        ("BOOK_002", "During", "CAMP_002", "USER_003", "J3", 1, 200.0,
         "Coupon at Till", "Digital", datetime(2024, 1, 15, 11), "In-store")
    ],
}

UNIFIED_CAMPAIGN_DATASETS = {
    "offsite_only": [
        ("CAMP_001", "BOOK_001", "Meta", "Meta", "offsite", 1000.0,
         date(2024, 1, 10), date(2024, 1, 20), "JOB_001",
         datetime(2024, 1, 15, 10), "3009"),
        ("CAMP_002", "BOOK_002", "Display", "DV360", "offsite", 2000.0,
         date(2024, 1, 10), date(2024, 1, 20), "JOB_001",
         datetime(2024, 1, 15, 10), "3001"),
    ],
    "mixed_marketing_type": [
        ("CAMP_001", "BOOK_001", "Meta", "Meta", "offsite", 1000.0,
         date(2024, 1, 10), date(2024, 1, 20), "JOB_001",
         datetime(2024, 1, 15, 10), "3009"),
        ("CAMP_002", "BOOK_002", "Display", "DV360", "offsite", 2000.0,
         date(2024, 1, 10), date(2024, 1, 20), "JOB_001",
         datetime(2024, 1, 15, 10), "3001"),
        ("CAMP_002", "BOOK_002", "Coupon at Till", "Digital", "In-store",
         500.0, date(2024, 1, 11), date(2024, 1, 21), "JOB_003",
         datetime(2024, 1, 15, 11), "2050")
    ],
    "non_offsite_only": [
        ("CAMP_002", "BOOK_002", "Coupon at Till", "Digital", "In-store",
         500.0, date(2024, 1, 11), date(2024, 1, 21), "JOB_003",
         datetime(2024, 1, 15, 11), "2050")
    ],
}


def create_df(spark, schema, rows):
    return spark.createDataFrame(rows, schema)

# ---------------------------------------------------------------------
#                   PARAMETERIZED FIXTURE FACTORIES
# ---------------------------------------------------------------------


@pytest.fixture
def user_journey_data_factory(spark_session):
    def _create(data):
        return create_df(spark_session, USER_JOURNEY_SCHEMA, data)
    return _create


@pytest.fixture
def unified_campaign_data_factory(spark_session):
    def _create(data):
        return create_df(spark_session, UNIFIED_CAMPAIGN_SCHEMA, data)
    return _create


@pytest.mark.parametrize(
    "dataset_key",
    ["offsite_only", "mixed_marketing_type", "non_offsite_only"]
)
def test_process_all_campaigns_variations_2(
    spark_session,
    measurement_campaign_execution_data,
    digital_trading_campaign_link_data,
    digital_trading_lineitem_insight_data,
    dv360_media_report_data,
    dv360_order_report_data,
    dv360_floodlight_report_data,
    camp_request_link_data,
    campaign_citcam_sat_data,
    meta_campaign_data,
    map_df,
    measurement_marketing_hierarchy_df,
    subchannel_hierarchy_codes,
    mock_processors,
    user_journey_data_factory,
    unified_campaign_data_factory,
    dataset_key
):
    # Build DataFrames for this scenario
    user_journey_df = user_journey_data_factory(
        USER_JOURNEY_DATASETS[dataset_key]
    )
    unified_campaign_dtf = unified_campaign_data_factory(
        UNIFIED_CAMPAIGN_DATASETS[dataset_key]
    )

    # Mock processor behaviours
    mock_outputs = create_mock_processor_outputs(spark_session)
    mock_processors['fetch_in_progress_campaigns'].return_value = create_df(
        spark_session,
        T.StructType([
            T.StructField("booking_id", T.StringType(), True),
            T.StructField("campaign_duration", T.StringType(), True),
        ]),
        [("BOOK_001", "During"), ("BOOK_002", "During")]
    )
    mock_processors['get_latest_data_for_campaigns'].return_value = user_journey_df
    mock_processors['meta_processor'].return_value = mock_outputs["meta"]
    mock_processors['youtube_and_dv360_processor'].return_value = mock_outputs["youtube"]
    mock_processors['citrus_processor'].return_value = mock_outputs["citrus"]

    def reach_side_effect(journey, campaigns, group, subchannel_hierarchy_codes=None):
        return (mock_outputs["instore"]
                if group == "marketing_type"
                else mock_outputs["coupon"])

    mock_processors["calculate_reach"].side_effect = reach_side_effect

    correlation_id = str(uuid.uuid4())

    # Execute function
    result_df = process_all_campaigns(
        measurement_campaign_execution_data,
        user_journey_df,
        digital_trading_campaign_link_data,
        digital_trading_lineitem_insight_data,
        dv360_media_report_data,
        dv360_order_report_data,
        dv360_floodlight_report_data,
        camp_request_link_data,
        campaign_citcam_sat_data,
        meta_campaign_data,
        unified_campaign_dtf,
        correlation_id,
        map_df,
        measurement_marketing_hierarchy_df,
        campaign_complete=True,
        subchannel_hierarchy_codes=subchannel_hierarchy_codes
    )

    # Validations
    assert isinstance(result_df, DataFrame)
    assert result_df.count() > 0

    expected_columns = {
        "campaign_id", "channel_name", "subchannel_name", "reach_cnt",
        "dedup_campaign_reach", "clicks_cnt", "impressions_cnt",
        "sales_amt", "conversions_cnt", "booking_id", "marketing_type",
        "media_spend_amt", "engagement_ctr_pct", "load_ts", "job_run_id"
    }
    assert expected_columns.issubset(result_df.columns)

    # Check load_ts populated
    assert (result_df.filter(F.col("load_ts").isNotNull()).count() ==
            result_df.count())

    # Job run ID check
    job_run_values = [
        row["job_run_id"]
        for row in result_df.select("job_run_id").distinct().collect()
    ]
    assert job_run_values == [correlation_id]

    # Conditional processor usage
    if unified_campaign_dtf.filter(
        F.col("channel_name").rlike("(?i)meta")
    ).count() > 0:
        mock_processors["meta_processor"].assert_called_once()
    else:
        mock_processors["meta_processor"].assert_not_called()

    youtube_or_dv360_count = unified_campaign_dtf.filter(
        F.col("channel_name").rlike("(?i)youtube|dv360|display")
    ).count()
    if youtube_or_dv360_count > 0:
        mock_processors["youtube_and_dv360_processor"].assert_called()
    else:
        mock_processors["youtube_and_dv360_processor"].assert_not_called()


def test_entrypoint_invocation_point(spark_session, tmp_path, measurement_marketing_hierarchy_df):
    # Create hierarchy test data file
    hierarchy_path = str(tmp_path / "hierarchy")
    measurement_marketing_hierarchy_df.write.mode("overwrite").parquet(hierarchy_path)

    with patch(
            "spark_pipeline.reach_engagement.reach_engagement_pollen.prepare_reach_engagement") as mock_prepare:
        args = [
            "--measurement-campaign-execution-path", "s3a://input/measurement_campaign_execution",
            "--digital-trading-campaign-channel-dmfbca-link-path", "s3a://input/digital_trading_campaign_link",
            "--digital-trading-campaign-insight-dmfbin-link-path", "s3a://input/digital_trading_campaign_insight_path",  # Changed
            "--media-report-path", "s3a://input/media_report",
            "--unique-reach-lineitem-report-path", "s3a://input/unique_reach_lineitem_report",
            "--floodlight-report-path", "s3a://input/floodlight_report",
            "--user-journey-offer-path", "s3a://input/user_journey_offer",
            "--advertising-campaign-request-realised-link-path", "s3a://input/advertise_request_realised",
            "--advertising-campaign-citcam-sat-path", "s3a://input/advertising_campaign_citcam_sat",
            "--meta-data-path", "s3a://input/meta_data_path",
            "--unified-campaigns-path", "s3a://input/unified_campaign",
            "--output-reporting-path", "s3a://output/reach_engagement_reporting",
            "--correlation-id", "mock-correlation",
            "--run-date", "2024-12-31",
            "--marketing-media-hierarchy-mkthrc-ref-path", "s3a://input/marketing_media_hierarchy_mkthrc_ref_path",
            "--measurement-marketing-channel-hierarchy-path", hierarchy_path,
            "--slack-topic-arn", "reach_engagement_topic_arn",
            "--campaign-complete", "True",
            "--subchannel-hierarchy-codes", '{"ecoupons": ["4013"], "dv360": ["3001"], "meta": ["3009"], "youtube": ["3014"], "coupon_at_till": ["2050", "2051"]}'
        ]
        entrypoint(spark_session, command_line_args=args)

        mock_prepare.assert_called_once_with(
            spark=spark_session,
            measurement_campaign_execution_path="s3a://input/measurement_campaign_execution",
            user_journey_offer_path="s3a://input/user_journey_offer",
            unified_campaigns_path="s3a://input/unified_campaign",
            digital_trading_campaign_channel_dmfbca_link_path="s3a://input/digital_trading_campaign_link",
            digital_trading_campaign_insight_dmfbin_link_path="s3a://input/digital_trading_campaign_insight_path",  # Changed
            media_report_path="s3a://input/media_report",
            unique_reach_lineitem_report_path="s3a://input/unique_reach_lineitem_report",
            floodlight_report_path="s3a://input/floodlight_report",
            advertising_campaign_request_realised_link_path="s3a://input/advertise_request_realised",
            advertising_campaign_citcam_sat_path="s3a://input/advertising_campaign_citcam_sat",
            meta_data_path="s3a://input/meta_data_path",
            output_reporting_path="s3a://output/reach_engagement_reporting",
            correlation_id="mock-correlation",
            run_date="2024-12-31",
            marketing_media_hierarchy_mkthrc_ref_path="s3a://input/marketing_media_hierarchy_mkthrc_ref_path",
            measurement_marketing_channel_hierarchy_path=hierarchy_path,
            slack_topic_arn="reach_engagement_topic_arn",
            campaign_complete=True,
            subchannel_hierarchy_codes={"ecoupons": ["4013"], "dv360": ["3001"], "meta": ["3009"], "youtube": ["3014"], "coupon_at_till": ["2050", "2051"]}
        )


@pytest.fixture
def mock_dataframes():
    """Create mock DataFrames for all input sources."""
    def create_mock_df(columns):
        mock_df = Mock(spec=DataFrame)
        mock_df.select = Mock(return_value=mock_df)
        mock_df.write = Mock()
        mock_df.write.mode = Mock(return_value=mock_df.write)
        mock_df.write.parquet = Mock()
        return mock_df

    return {
        'measurement_campaign_execution': create_mock_df([
            "campaign_id", "booking_id", "marketing_type",
            "campaign_duration", "job_status"
        ]),
        'digital_trading_campaign_channel': create_mock_df([
            "digital_trading_campaign_nk1", "digital_trading_campaign_nk3"
        ]),
        'digital_trading_lineitem_facebook': create_mock_df([
            "digital_trading_campaign_nk1", "measures"
        ]),
        'media_report': create_mock_df([
            "campaign_id", "clicks", "impressions"
        ]),
        'unique_reach_lineitem_report': create_mock_df([
            "line_item_id", "total_reach"
        ]),
        'floodlight_report': create_mock_df([
            "campaign_date", "total_conversions"
        ]),
        'user_journey_offer': create_mock_df([
            "campaign_id", "isconversion"
        ]),
        'advertising_campaign_request': create_mock_df([
            "advertising_campaign_nk1", "sales_revenue_amt"
        ]),
        'advertising_campaign_citcam': create_mock_df([
            "advertising_campaign_nk1", "campaign_name"
        ]),
        'unified_campaign': create_mock_df([
            "campaign_id", "media_spend_amt"
        ]),
        'map': create_mock_df([
            "media_placement", "marketing_channel"
        ]),
        'meta_campaigns': create_mock_df([
            "loyalty_id"
        ]),
        'hierarchy': create_mock_df([
            "marketing_hierarchy_cd", "mapping_type", "marketing_channel", "marketing_subchannel",
            "media_type", "channel_type", "in_scope_flag", "measurement_campaign_ready"
        ]),
        'reach_engagement': create_mock_df([
            "campaign_id", "reach_cnt", "clicks_cnt"
        ])
    }


@pytest.fixture
def test_params():
    """Common test parameters."""
    return {
        'measurement_campaign_execution_path': 's3://bucket/measurement/',
        'user_journey_offer_path': 's3://bucket/user_journey/',
        'unified_campaigns_path': 's3://bucket/unified/',
        'digital_trading_campaign_channel_dmfbca_link_path': 's3://bucket/dt_campaign/',
        'digital_trading_campaign_insight_dmfbin_link_path': 's3://bucket/dt_insight/',  # Changed key
        'media_report_path': 's3://bucket/media_report/',
        'unique_reach_lineitem_report_path': 's3://bucket/unique_reach/',
        'floodlight_report_path': 's3://bucket/floodlight/',
        'advertising_campaign_request_realised_link_path': 's3://bucket/ad_request/',
        'advertising_campaign_citcam_sat_path': 's3://bucket/citcam/',
        'meta_data_path': 's3://bucket/meta/',
        'output_reporting_path': 's3://bucket/output_reporting/',
        'correlation_id': 'test-correlation-123',
        'run_date': '2024-01-01',
        'marketing_media_hierarchy_mkthrc_ref_path': 's3://bucket/hierarchy/',
        'measurement_marketing_channel_hierarchy_path': 's3://bucket/measurement_hierarchy/',
        'slack_topic_arn': 'arn:aws:sns:us-east-1:123456789:slack-topic'
    }


@patch("spark_pipeline.reach_engagement.reach_engagement_pollen.spark_s3_overwrite")
@patch("spark_pipeline.utils.spark_s3_safe_write.s3")
@patch('spark_pipeline.reach_engagement.re_utils.calculate_combined_reach')
@patch('spark_pipeline.utils.slack_utils.SlackMessenger')
@patch('spark_pipeline.reach_engagement.reach_engagement_pollen.process_all_campaigns')
def test_prepare_reach_engagement_success(
    mock_process_campaigns,
    mock_slack_messenger,
    mock_calculate_reach,
    mock_s3_client,
    mock_s3_overwrite,
    mock_spark,
    mock_dataframes,
    test_params
):
    """Test successful execution of prepare_reach_engagement."""

    # Setup spark.read.parquet to return appropriate mock DataFrames
    mock_spark.read.parquet = Mock(side_effect=[
        mock_dataframes['measurement_campaign_execution'],
        mock_dataframes['digital_trading_campaign_channel'],
        mock_dataframes['digital_trading_lineitem_facebook'],
        mock_dataframes['media_report'],
        mock_dataframes['unique_reach_lineitem_report'],
        mock_dataframes['floodlight_report'],
        mock_dataframes['user_journey_offer'],
        mock_dataframes['advertising_campaign_request'],
        mock_dataframes['advertising_campaign_citcam'],
        mock_dataframes['unified_campaign'],
        mock_dataframes['map'],
        mock_dataframes['hierarchy'],
        mock_dataframes['meta_campaigns']
    ])

    # Mock collect_set for booking_ids
    mock_first_result = {'booking_ids': ['booking1', 'booking2']}
    mock_dataframes['measurement_campaign_execution'].first = Mock(
        return_value=mock_first_result
    )

    # Mock process_all_campaigns to return a DataFrame
    mock_process_campaigns.return_value = mock_dataframes['reach_engagement']

    # Add subchannel_hierarchy_codes to test_params
    subchannel_hierarchy_codes = {
        'ecoupons': ['4013'],
        'dv360': ['3001'],
        'meta': ['3009'],
        'youtube': ['3014'],
        'coupon_at_till': ['2050', '2051']
    }

    # Execute
    result = prepare_reach_engagement(
        spark=mock_spark,
        **test_params,
        campaign_complete=True,
        subchannel_hierarchy_codes=subchannel_hierarchy_codes
    )

    # Assertions
    assert result is not None
    assert mock_spark.read.parquet.call_count == 13
    mock_process_campaigns.assert_called_once()

    # Ensure spark_s3_overwrite was called once (reporting only)
    assert mock_s3_overwrite.call_count == 1

    # Check that correct path was passed to spark_s3_overwrite
    mock_s3_overwrite.assert_any_call(test_params['output_reporting_path'], mock_dataframes['reach_engagement'].select.return_value)


@patch("spark_pipeline.reach_engagement.reach_engagement_pollen.spark_s3_overwrite")
@patch("spark_pipeline.utils.spark_s3_safe_write.s3")
@patch('spark_pipeline.utils.slack_utils.SlackMessenger')
@patch('spark_pipeline.reach_engagement.reach_engagement_pollen.process_all_campaigns')
def test_prepare_reach_engagement_with_missing_meta_file(
    mock_process_campaigns,
    mock_slack_messenger,
    mock_s3_client,
    mock_s3_overwrite,
    mock_spark,
    mock_dataframes,
    test_params,
    capsys
):
    me_df = mock_dataframes['measurement_campaign_execution']
    me_df.select = Mock(return_value=me_df)
    me_df.first = Mock(return_value=Row(booking_ids=['booking1']))

    # Correctly route parquet reads to the right mocks
    def side_effect_parquet(path):
        if path == test_params['meta_data_path']:
            raise FileNotFoundError(f"File not found: {path}")

        # Explicit mapping (most reliable)
        mapping = {
            test_params['measurement_campaign_execution_path']: mock_dataframes['measurement_campaign_execution'],
            test_params['user_journey_offer_path']: mock_dataframes['user_journey_offer'],
            test_params['unified_campaigns_path']: mock_dataframes['unified_campaign'],
            test_params['digital_trading_campaign_channel_dmfbca_link_path']: mock_dataframes['digital_trading_campaign_channel'],
            test_params['digital_trading_campaign_insight_dmfbin_link_path']: mock_dataframes['digital_trading_lineitem_facebook'],  # Changed key
            test_params['media_report_path']: mock_dataframes['media_report'],
            test_params['unique_reach_lineitem_report_path']: mock_dataframes['unique_reach_lineitem_report'],
            test_params['floodlight_report_path']: mock_dataframes['floodlight_report'],
            test_params['advertising_campaign_request_realised_link_path']: mock_dataframes['advertising_campaign_request'],
            test_params['advertising_campaign_citcam_sat_path']: mock_dataframes['advertising_campaign_citcam'],
            test_params['marketing_media_hierarchy_mkthrc_ref_path']: mock_dataframes['map'],
            test_params['measurement_marketing_channel_hierarchy_path']: mock_dataframes['hierarchy'],
        }

        return mapping.get(path, Mock(spec=DataFrame))

    mock_spark.read.parquet = Mock(side_effect=side_effect_parquet)

    # process_all_campaigns output
    mock_process_campaigns.return_value = mock_dataframes['reach_engagement']

    # Add subchannel_hierarchy_codes
    subchannel_hierarchy_codes = {
        'ecoupons': ['4013'],
        'dv360': ['3001'],
        'meta': ['3009'],
        'youtube': ['3014'],
        'coupon_at_till': ['2050', '2051']
    }

    # RUN
    _ = prepare_reach_engagement(
        spark=mock_spark,
        **test_params,
        campaign_complete=True,
        subchannel_hierarchy_codes=subchannel_hierarchy_codes
    )

    captured = capsys.readouterr()
    assert "Error: File not found" in captured.out
    assert "Completed parquet read attempt" in captured.out

    # Ensure meta_campaigns_df = None
    args = mock_process_campaigns.call_args[0]
    assert args[9] is None


@pytest.fixture
def camp_request_link_schema():
    """Schema for campaign request link data"""
    return ReachEngagementSchema.camp_request_link_schema


@pytest.fixture
def unified_campaign_schema():
    """Schema for unified campaign data"""
    return T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("campaign_start_dt", T.DateType(), True),
        T.StructField("campaign_end_dt", T.DateType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("marketing_type", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
    ])


@pytest.fixture
def campaign_citcam_sat_schema():
    """Schema for campaign citcam sat data"""
    return T.StructType([
        T.StructField("advertising_campaign_nk1", T.StringType(), True),
        T.StructField("campaign_placements", T.StringType(), True),
    ])


@pytest.fixture
def user_journey_schema():
    """Schema for user journey data"""
    return T.StructType([
        T.StructField("campaign_id", T.StringType(), True),
        T.StructField("booking_id", T.StringType(), True),
        T.StructField("channel_name", T.StringType(), True),
        T.StructField("subchannel_name", T.StringType(), True),
        T.StructField("loyalty_id", T.StringType(), True),
    ])


@pytest.fixture
def map_df_schema():
    """Schema for mapping dataframe"""
    return T.StructType([
        T.StructField("mapping_type", T.StringType(), True),
        T.StructField("channel_type", T.StringType(), True),
        T.StructField("media_provider", T.StringType(), True),
        T.StructField("media_type", T.StringType(), True),
        T.StructField("media_subtype", T.StringType(), True),
        T.StructField("store_type", T.StringType(), True),
        T.StructField("store_location", T.StringType(), True),
        T.StructField("template_type", T.StringType(), True),
        T.StructField("media_placement", T.StringType(), True),
        T.StructField("marketing_subchannel", T.StringType(), True),
        T.StructField("load_ts", T.TimestampType(), True),
        T.StructField("technical_metadata", T.StringType(), True),
    ])


@pytest.fixture
def sample_camp_request_link_data(spark_session, camp_request_link_schema):
    """Create sample campaign request link data"""
    data = [
        ("C001", date(2024, 1, 15), 100.0, 5, 1000, 50),
        ("C001", date(2024, 1, 15), 80.0, 3, 800, 40),
        ("C002", date(2024, 2, 10), 200.0, 10, 2000, 100),
    ]
    return spark_session.createDataFrame(data, camp_request_link_schema)


@pytest.fixture
def sample_unified_campaign_data(spark_session, unified_campaign_schema):
    """Create sample unified campaign data"""
    data = [
        ("C001", date(2024, 1, 1), date(2024, 1, 31), "Channel1", "B001", "Digital", "OldSubchannel"),
        ("C002", date(2024, 2, 1), date(2024, 2, 28), "Channel2", "B002", "Social", "OldSubchannel2"),
    ]
    return spark_session.createDataFrame(data, unified_campaign_schema)


@pytest.fixture
def sample_campaign_citcam_sat_data(spark_session, campaign_citcam_sat_schema):
    """Create sample campaign citcam sat data"""
    data = [
        ("C001", "CITRUS-sponsored products - argos search app"),
        ("C002", "CITRUS-Subchannel2"),
    ]
    return spark_session.createDataFrame(data, campaign_citcam_sat_schema)


@pytest.fixture
def sample_user_journey_data(spark_session, user_journey_schema):
    """Create sample user journey data"""
    data = [
        ("C001", "B001", "Channel1", "sponsored products - argos search app", "L001"),
        ("C001", "B001", "Channel1", "sponsored products - argos search app", "L002"),
        ("C001", "B001", "Channel1", "sponsored products - argos search app", "L001"),
        ("C001", "B001", "Channel1", "sponsored products - argos search app", "L001"),
        ("C002", "B002", "Channel2", "Subchannel2", "L003"),
        ("C002", "B002", "Channel2", "Subchannel2", "L004"),
    ]
    return spark_session.createDataFrame(data, user_journey_schema)


@pytest.fixture
def sample_map_df_data(spark_session, map_df_schema):
    """Create sample mapping data"""
    data = [
        ("INTERACTION_EVENT", "CT1", "MP1", "MT1", "MST1", "ST1", "SL1", "TT1",
         "PREFIX-sponsored products - argos search app", "sponsored products - argos search app", datetime(2024, 1, 1, 10, 0, 0),
         '{"record_deleted_flag": "N"}'),
        ("INTERACTION_EVENT", "CT1", "MP1", "MT1", "MST1", "ST1", "SL1", "TT1",
         "PREFIX-sponsored products - argos search app", "sponsored products - argos search app", datetime(2024, 1, 1, 9, 0, 0),
         '{"record_deleted_flag": "N"}'),
        ("INTERACTION_EVENT", "CT2", "MP2", "MT2", "MST2", "ST2", "SL2", "TT2",
         "PREFIX-Subchannel2", "Subchannel2", datetime(2024, 1, 1, 10, 0, 0),
         '{"record_deleted_flag": "N"}'),
    ]
    return spark_session.createDataFrame(data, map_df_schema)


def test_citrus_processor_campaign_request_filtered_no_matching_error(
    spark_session,
    camp_request_link_schema,
    unified_campaign_schema,
    campaign_citcam_sat_schema,
    user_journey_schema,
    map_df_schema,
    measurement_marketing_hierarchy_df
):
    """Test citrus_processor raises JoinValidationError
    when filtered campaign requests have no matching mapping records"""
    camp_request_data = [
        ("C001", date(2024, 1, 15), 150.0, 7, 1500, 75),
        ("C001", date(2024, 1, 15), 100.0, 5, 1000, 50),
    ]
    camp_request_df = spark_session.createDataFrame(camp_request_data, camp_request_link_schema)

    unified_data = [
        ("C001", date(2024, 1, 1), date(2024, 1, 31), "Channel1", "B001", "Digital", "Sub1"),
    ]
    unified_df = spark_session.createDataFrame(unified_data, unified_campaign_schema)

    citcam_data = [("C001", "CITRUS-sponsored products - argos search app")]
    citcam_df = spark_session.createDataFrame(citcam_data, campaign_citcam_sat_schema)

    journey_data = [("C001", "B001", "Channel1", "sponsored products - argos search app", "L001")]
    journey_df = spark_session.createDataFrame(journey_data, user_journey_schema)

    map_data = [
        ("INTERACTION_EVENT", "CT1", "MP1", "MT1", "MST1", "ST1", "SL1", "TT1",
         "sponsored products - argos search app", "sponsored products - argos search app", datetime(2024, 1, 1, 10, 0, 0),
         '{"record_deleted_flag": "N"}'),
    ]
    map_df = spark_session.createDataFrame(map_data, map_df_schema)

    with pytest.raises(JoinValidationError):
        citrus_processor(camp_request_df, unified_df, citcam_df, journey_df, map_df, measurement_marketing_hierarchy_df)
