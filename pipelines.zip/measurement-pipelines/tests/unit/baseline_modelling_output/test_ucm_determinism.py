"""
Test that ucm_model_runner produces identical results when called multiple times
with the same input data. This is a pure pandas test - no Spark needed.
"""
import numpy as np
import pandas as pd
from itertools import product

from spark_pipeline.baseline_modelling_output_ucm.ucm_ml_functions import ucm_model_runner_factory


# ── Synthetic data helpers ────────────────────────────────────────────────────

N_WEEKS = 104
DATES = pd.date_range("2022-01-03", periods=N_WEEKS, freq="W-MON")
CLUSTER = "brand_a~dairy~1"
DEPENDENT = "nec_total_sales_aaaaaaaaaaaaaaaaa"   # 32 chars
MARKETING_VAR = "nec_tv_spend_aaaaaaaaaaaaaaaaaa"  # 32 chars
EXT_VAR = "nec_price_index_aaaaaaaaaaaaaaaa"       # 32 chars
VAR_LEN = 27


def _make_pdf() -> pd.DataFrame:
    """
    Build a minimal long-format pandas DataFrame that mimics what applyInPandas
    receives for one (modelling_cluster, Iteration_Number) group.

    Columns required by ucm_model_runner:
        modelling_cluster, wdate, variable, value,
        level_variance, cycle, cycle_period_bounds,
        Iteration_Number, variable_list, ext_variable_list
    """
    rng = np.random.default_rng(42)  # fixed seed for reproducible synthetic data only

    sales = 1000 + np.cumsum(rng.normal(0, 10, N_WEEKS))
    tv = np.abs(rng.normal(50, 15, N_WEEKS))
    price = 1.0 + rng.normal(0, 0.05, N_WEEKS)

    rows = []
    for i, d in enumerate(DATES):
        base = dict(
            modelling_cluster=CLUSTER,
            wdate=d,
            level_variance=0.5,
            cycle=False,
            cycle_period_bounds=[],
            Iteration_Number="iter_1-set_1",
            variable_list=[MARKETING_VAR, EXT_VAR],
            ext_variable_list=[EXT_VAR],
        )
        rows.append({**base, "variable": DEPENDENT, "value": sales[i]})
        rows.append({**base, "variable": f"{MARKETING_VAR}_010500", "value": tv[i]})
        rows.append({**base, "variable": f"{EXT_VAR}_001000", "value": price[i]})

    return pd.DataFrame(rows)


def _make_runner():
    return ucm_model_runner_factory(
        dependent=DEPENDENT,
        constant_sigma2_level="sigma2.level",
        constant_sigma2_trend="sigma2.trend",
        marketing_variables_list=["nec_tv"],
        negative_factors_list=["nec_price"],
        var_len=len(MARKETING_VAR),
        all_combinations=list(product([1], [50], [0])),  # single APL combo: key="010500"
    )


# ── Tests ─────────────────────────────────────────────────────────────────────

def test_ucm_model_runner_is_deterministic():
    """
    Run the model runner 4 times with identical input and assert all outputs match.
    """
    pdf = _make_pdf()
    runner = _make_runner()

    results = [runner(pdf.copy()) for _ in range(4)]

    # All runs must produce the same selected variables
    selected = [r["selected_variables"].iloc[0] for r in results]
    assert len(set(selected)) == 1, (
        f"Selected variables differ across runs:\n{selected}"
    )

    # All runs must produce identical estimates (within float tolerance)
    ref = results[0]["estimate"].values
    for i, r in enumerate(results[1:], start=1):
        np.testing.assert_allclose(
            r["estimate"].values, ref, rtol=1e-6,
            err_msg=f"Run {i} estimates differ from run 0"
        )

    # All runs must produce identical level_std smoothed values
    ref_level = results[0]["level_std"].iloc[0]
    for i, r in enumerate(results[1:], start=1):
        assert r["level_std"].iloc[0] == ref_level, (
            f"Run {i} level_std differs from run 0"
        )

    ref_slope = results[0]["slope_std"].iloc[0]
    for i, r in enumerate(results[1:], start=1):
        assert r["slope_std"].iloc[0] == ref_slope, f"Run {i} slope_std differs from run 0"

    ref_pvalue = results[0]["pvalue_zdist"].values
    for i, r in enumerate(results[1:], start=1):
        np.testing.assert_allclose(r["pvalue_zdist"].values, ref_pvalue, rtol=1e-6)


def test_ucm_model_runner_selected_variables_stable():
    """
    Verify the same APL combination is chosen regardless of invocation order.
    """
    pdf = _make_pdf()
    runner = _make_runner()

    run_a = runner(pdf.copy())
    run_b = runner(pdf.copy())

    assert run_a["selected_variables"].iloc[0] == run_b["selected_variables"].iloc[0]


def test_ucm_model_runner_deterministic_across_row_orders():
    pdf = _make_pdf()
    runner = _make_runner()

    shuffled = pdf.sample(frac=1, random_state=99).reset_index(drop=True)

    result_original = runner(pdf.copy())
    result_shuffled = runner(shuffled)

    assert result_original["selected_variables"].iloc[0] == result_shuffled["selected_variables"].iloc[0]
    np.testing.assert_allclose(
        result_original["estimate"].values,
        result_shuffled["estimate"].values,
        rtol=1e-6,
    )
