from pyspark.sql import SparkSession


def build_marketing_contribution_filter_inputs(spark_session: SparkSession):
    """Builds consistent mock DataFrames for marketing_contribution_filter unit tests."""
    ucm_fin_summary = spark_session.createDataFrame(
        [
            ("Iteration:1", "cluster_a", "ons_ons_media", -1.0),
            ("Iteration:2", "cluster_b", "ons_ons_media", 0.3),
            ("Iteration:3", "cluster_c", "random_variable", -0.8),
        ],
        ["Iteration_Number", "modelling_cluster", "variable_apl", "estimate"],
    )

    ucm_base_data_fixed = spark_session.createDataFrame(
        [
            ("Iteration:1", "cluster_a", "row_a"),
            ("Iteration:2", "cluster_b", "row_b"),
            ("Iteration:3", "cluster_c", "row_c"),
        ],
        ["Iteration_Number", "modelling_cluster", "marker"],
    )

    ucm_base_long = spark_session.createDataFrame(
        [
            ("Iteration:1", "cluster_a", "long_a"),
            ("Iteration:2", "cluster_b", "long_b"),
            ("Iteration:3", "cluster_c", "long_c"),
        ],
        ["Iteration_Number", "modelling_cluster", "marker"],
    )

    model_metrics = spark_session.createDataFrame(
        [
            ("Iteration:1", "cluster_a", 0.1),
            ("Iteration:2", "cluster_b", 0.2),
            ("Iteration:3", "cluster_c", 0.3),
        ],
        ["Iteration_Number", "modelling_cluster", "metric"],
    )

    best_iteration_df = spark_session.createDataFrame(
        [
            ("Iteration:1", "cluster_a", 10),
            ("Iteration:2", "cluster_b", 20),
            ("Iteration:3", "cluster_c", 30),
        ],
        ["Iteration_Number", "modelling_cluster", "rank"],
    )

    return ucm_fin_summary, ucm_base_data_fixed, ucm_base_long, model_metrics, best_iteration_df


def get_params_with_patterns(patterns):
    return {
        "DEFAULT": {
            "negative_marketing_variable_patterns": patterns,
        }
    }
