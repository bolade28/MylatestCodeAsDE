from pyspark.sql import SparkSession
from chispa.dataframe_comparer import assert_df_equality

from spark_pipeline.baseline_modelling_output_ucm.ucm_utils import marketing_contribution_filter
from tests.unit.baseline_modelling_output.ucm_utils_test_data import (
    build_marketing_contribution_filter_inputs,
    get_params_with_patterns,
)


def _assert_iteration_cluster_pairs_equal(actual_df, expected_pairs, spark_session: SparkSession):
    expected_df = spark_session.createDataFrame(
        list(expected_pairs),
        ["Iteration_Number", "modelling_cluster"],
    )

    actual_normalized = (
        actual_df
        .select("Iteration_Number", "modelling_cluster")
        .distinct()
        .orderBy("Iteration_Number", "modelling_cluster")
    )

    expected_normalized = expected_df.orderBy("Iteration_Number", "modelling_cluster")

    assert_df_equality(actual_normalized, expected_normalized)


def test_marketing_contribution_filter_removes_negative_marketing_iterations(spark_session: SparkSession):
    (
        ucm_fin_summary,
        ucm_base_data_fixed,
        ucm_base_long,
        model_metrics,
        best_iteration_df,
    ) = build_marketing_contribution_filter_inputs(spark_session)

    params = get_params_with_patterns(["ons_ons_"])

    (
        ucm_fin_summary_filtered,
        ucm_base_data_fixed_filtered,
        ucm_base_long_filtered,
        model_metrics_filtered,
        best_iteration_df_filtered,
    ) = marketing_contribution_filter(
        ucm_fin_summary,
        ucm_base_data_fixed,
        ucm_base_long,
        model_metrics,
        best_iteration_df,
        params,
    )

    expected_pairs = {("Iteration:2", "cluster_b"), ("Iteration:3", "cluster_c")}

    _assert_iteration_cluster_pairs_equal(ucm_fin_summary_filtered, expected_pairs, spark_session)
    _assert_iteration_cluster_pairs_equal(ucm_base_data_fixed_filtered, expected_pairs, spark_session)
    _assert_iteration_cluster_pairs_equal(ucm_base_long_filtered, expected_pairs, spark_session)
    _assert_iteration_cluster_pairs_equal(model_metrics_filtered, expected_pairs, spark_session)
    _assert_iteration_cluster_pairs_equal(best_iteration_df_filtered, expected_pairs, spark_session)


def test_marketing_contribution_filter_returns_original_when_all_iterations_negative(spark_session: SparkSession):
    ucm_fin_summary = spark_session.createDataFrame(
        [
            ("Iteration:1", "cluster_a", "ons_ons_media", -1.0),
            ("Iteration:2", "cluster_b", "off_you_display", -0.2),
        ],
        ["Iteration_Number", "modelling_cluster", "variable_apl", "estimate"],
    )

    ucm_base_data_fixed = spark_session.createDataFrame(
        [("Iteration:1", "cluster_a"), ("Iteration:2", "cluster_b")],
        ["Iteration_Number", "modelling_cluster"],
    )
    ucm_base_long = ucm_base_data_fixed
    model_metrics = ucm_base_data_fixed
    best_iteration_df = ucm_base_data_fixed

    params = get_params_with_patterns(["ons_ons_", "off_you_"])

    result = marketing_contribution_filter(
        ucm_fin_summary,
        ucm_base_data_fixed,
        ucm_base_long,
        model_metrics,
        best_iteration_df,
        params,
    )

    expected_pairs = {("Iteration:1", "cluster_a"), ("Iteration:2", "cluster_b")}

    for df in result:
        _assert_iteration_cluster_pairs_equal(df, expected_pairs, spark_session)


def test_marketing_contribution_filter_returns_original_when_patterns_not_configured(spark_session: SparkSession):
    (
        ucm_fin_summary,
        ucm_base_data_fixed,
        ucm_base_long,
        model_metrics,
        best_iteration_df,
    ) = build_marketing_contribution_filter_inputs(spark_session)

    params = get_params_with_patterns([])

    result = marketing_contribution_filter(
        ucm_fin_summary,
        ucm_base_data_fixed,
        ucm_base_long,
        model_metrics,
        best_iteration_df,
        params,
    )

    expected_pairs = {
        ("Iteration:1", "cluster_a"),
        ("Iteration:2", "cluster_b"),
        ("Iteration:3", "cluster_c"),
    }

    for df in result:
        _assert_iteration_cluster_pairs_equal(df, expected_pairs, spark_session)
