from datetime import datetime, timedelta
from pyspark.sql import Row
import math


def to_date(date: str) -> datetime.date:
    return datetime.strptime(date, "%Y-%m-%d").date()


def generate_seasonal_data(start_date: str, initial_value: float, peak_value: float):
    start_date = to_date(start_date)
    data = []
    weeks_in_half_year = 26
    weeks_in_year = 52
    amplitude = (peak_value - initial_value) / 2  # Calculate amplitude for the sine wave

    for week in range(104):  # 52 weeks per year * 2 years
        week_date = start_date + timedelta(weeks=week)
        # Calculate the sine wave value for the current week
        if week % weeks_in_year < weeks_in_half_year:
            current_value = initial_value + amplitude * math.sin(math.pi * (week % weeks_in_half_year) / weeks_in_half_year)
        else:
            current_value = initial_value + amplitude * math.sin(math.pi * (weeks_in_year - (week % weeks_in_year)) / weeks_in_half_year)

        data.append(Row(
            week_date=week_date,
            unique_brand="brand1",
            super_category_name="cat1",
            cluster="cluster1",
            value=current_value
        ))

    return data
