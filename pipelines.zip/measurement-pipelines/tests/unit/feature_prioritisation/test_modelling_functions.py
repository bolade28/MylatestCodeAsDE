import pytest
from pyspark.sql import Row
from chispa import assert_df_equality
from spark_pipeline.schemas.feature_prioritisation import FeaturePrioritisation
from spark_pipeline.utils.feature_prioritisation.modelling_functions import create_correlation_processor, \
    apply_min_max_scaling, run_ml_models, feature_prioritization_ensemble
from tests.unit.feature_prioritisation.helper_functions import to_date
import random


@pytest.mark.usefixtures("spark_session")
def test_create_correlation_processor(spark_session):
    # Define test data
    test_data = [
        Row(group_key="group1", feature1=1.0, feature2=2.0, feature3=3.0, cluster1=4.0, cluster2=5.0),
        Row(group_key="group1", feature1=2.0, feature2=3.0, feature3=4.0, cluster1=5.0, cluster2=6.0),
        Row(group_key="group2", feature1=3.0, feature2=4.0, feature3=5.0, cluster1=6.0, cluster2=7.0),
        Row(group_key="group2", feature1=4.0, feature2=5.0, feature3=6.0, cluster1=7.0, cluster2=8.0),
    ]
    input_df = spark_session.createDataFrame(test_data, schema=FeaturePrioritisation.correlation_test_input_schema)

    # Define dependent variables and schema
    list_of_dependent_vars = ["cluster1", "cluster2"]
    correlation_schema = FeaturePrioritisation.correlation_schema

    # Create correlation processor
    processor = create_correlation_processor(list_of_dependent_vars, correlation_schema)

    # Apply the processor
    result_df = processor(input_df)

    # Test data has a linear relationship, so we expect perfect correlation, this is a santity check
    expected_data = [
        Row(feature="feature1", cluster="cluster1", correlation=1.0, group_key="group1"),
        Row(feature="feature2", cluster="cluster1", correlation=1.0, group_key="group1"),
        Row(feature="feature3", cluster="cluster1", correlation=1.0, group_key="group1"),
        Row(feature="feature1", cluster="cluster2", correlation=1.0, group_key="group1"),
        Row(feature="feature2", cluster="cluster2", correlation=1.0, group_key="group1"),
        Row(feature="feature3", cluster="cluster2", correlation=1.0, group_key="group1"),
        Row(feature="feature1", cluster="cluster1", correlation=1.0, group_key="group2"),
        Row(feature="feature2", cluster="cluster1", correlation=1.0, group_key="group2"),
        Row(feature="feature3", cluster="cluster1", correlation=1.0, group_key="group2"),
        Row(feature="feature1", cluster="cluster2", correlation=1.0, group_key="group2"),
        Row(feature="feature2", cluster="cluster2", correlation=1.0, group_key="group2"),
        Row(feature="feature3", cluster="cluster2", correlation=1.0, group_key="group2"),
    ]
    expected_df = spark_session.createDataFrame(expected_data, schema=correlation_schema)

    assert_df_equality(result_df, expected_df)


# ToDo Add a schema to the test data
@pytest.mark.usefixtures("spark_session")
def test_apply_min_max_scaling(spark_session):
    test_data = [
        Row(DATE="2024-02-05", group_key="QUAKER|PEPSICO~HOT BEVERAGES~CL3", VARIABLE="TOT_TOT_TOT_EXT_BCI_TOT_BCI",
            VALUE=50.0),
        Row(DATE="2024-02-06", group_key="QUAKER|PEPSICO~HOT BEVERAGES~CL3", VARIABLE="TOT_TOT_TOT_EXT_BCI_TOT_BCI",
            VALUE=100.0),
        Row(DATE="2024-02-07", group_key="QUAKER|PEPSICO~HOT BEVERAGES~CL3", VARIABLE="TOT_TOT_TOT_EXT_BCI_TOT_BCI",
            VALUE=75.0)
    ]
    input_df = spark_session.createDataFrame(test_data)

    # Apply Min-Max scaling
    scaled_df = apply_min_max_scaling(input_df, group_cols=["group_key"], value_col="VALUE", feature_range=(0.0, 1.0))

    expected_data = [
        Row(DATE="2024-02-05", group_key="QUAKER|PEPSICO~HOT BEVERAGES~CL3", VARIABLE="TOT_TOT_TOT_EXT_BCI_TOT_BCI",
            VALUE=0.0),
        Row(DATE="2024-02-06", group_key="QUAKER|PEPSICO~HOT BEVERAGES~CL3", VARIABLE="TOT_TOT_TOT_EXT_BCI_TOT_BCI",
            VALUE=1.0),
        Row(DATE="2024-02-07", group_key="QUAKER|PEPSICO~HOT BEVERAGES~CL3", VARIABLE="TOT_TOT_TOT_EXT_BCI_TOT_BCI",
            VALUE=0.5),
    ]
    expected_df = spark_session.createDataFrame(expected_data)

    # Assert equality using chispa
    assert_df_equality(scaled_df, expected_df, ignore_nullable=True)


@pytest.mark.usefixtures("spark_session")
def test_run_ml_models(spark_session):
    # Set random seed for the random variations in my feature generation
    random.seed(7)
    # Create 52 weeks of data with 3 features
    input_data = []

    for week in range(52):
        # Create date string for current week
        month = (week // 4) + 1  # Roughly 4 weeks per month
        day = (week % 4) * 7 + 1
        if month > 12:
            month = 12
            day = min(day, 28)
        date_str = f"2023-{month:02d}-{day:02d}"

        # Feature 1: very strong positive correlation with target all models will rank this first
        # Target increases with time so feature 1 follows very closely
        target_value = 10 + week * 0.5 + random.uniform(-0.1, 0.1)
        feature1_value = target_value * 0.95 + random.uniform(-0.05, 0.05)

        # Feature 2: Strong negative correlation with target this will be ranked 2nd of 3rd by tree based models
        # Feature 2 decreases greatly as target increases (Sometimes tree based models struggle with negative correlations)
        feature2_value = 50 - week * 0.8 + random.uniform(-0.8, 0.8)

        # Feature 3: Non-linear relationship, the tree models will do well here but the lasso model will struggle
        normalized_week = week / 52.0  # Normalize to 0-1 range
        feature3_value = 25 + 15 * (normalized_week ** 2) + random.uniform(-0.3, 0.3)

        # Feature 4: Very weak correlation with target all models will rank this last
        # Feature 4 is mostly random noise
        feature4_value = 15 + week * 0.01 + random.uniform(-3.0, 3.0)

        # Add data rows for this week
        input_data.extend([
            Row(date=to_date(date_str),
                group_key="group1~cluster1~C1",
                variable="feature1",
                value=feature1_value),
            Row(date=to_date(date_str),
                group_key="group1~cluster1~C1",
                variable="feature2",
                value=feature2_value),
            Row(date=to_date(date_str),
                group_key="group1~cluster1~C1",
                variable="feature3",
                value=feature3_value),
            Row(date=to_date(date_str),
                group_key="group1~cluster1~C1",
                variable="feature4",
                value=feature4_value),
            Row(date=to_date(date_str),
                group_key="group1~cluster1~C1",
                variable="C1",
                value=target_value),
        ])

    input_df = spark_session.createDataFrame(input_data, schema=FeaturePrioritisation.pre_processed_output_schema)

    class MockConfig:
        class EnsembleConfig:
            random_forest_random_state = 42
            random_forest_n_estimators = 1000
            random_forest_max_depth = 3
            xgboost_random_state = 42
            xgboost_n_estimators = 50
            xgboost_max_depth = 3
            lasso_cross_validation_k_fold = 5
            lasso_random_state = 42

        ensemble_config = EnsembleConfig()

    fp_config = MockConfig()

    # Run the function
    list_of_dependent_vars = ["C1"]
    run_models_udf = run_ml_models(list_of_dependent_vars, FeaturePrioritisation.model_outputs_schema, fp_config)
    result_df = run_models_udf(input_df)

    # Assert the output is not empty
    assert result_df.count() > 0, "Output DataFrame should not be empty"

    # Convert to pandas for easier analysis
    result_pandas = result_df.toPandas()

    # Print results for analysis in case of failure
    print("\n=== Model Results Analysis ===")
    print(result_pandas.to_string(index=False))

    print("\n=== Feature Rankings ===")
    print("Random Forest Rankings:")
    rf_sorted = result_pandas.sort_values('rf_rank')
    for _, row in rf_sorted.iterrows():
        print(f"  {row['feature']}: Rank {row['rf_rank']}, Importance {row['rf_importance']:.4f}")

    print("\nXGBoost Rankings:")
    xgb_sorted = result_pandas.sort_values('xgb_rank')
    for _, row in xgb_sorted.iterrows():
        print(f"  {row['feature']}: Rank {row['xgb_rank']}, Importance {row['xgb_importance']:.4f}")

    print("\nLasso Rankings:")
    lasso_sorted = result_pandas.sort_values('lasso_rank')
    for _, row in lasso_sorted.iterrows():
        print(f"  {row['feature']}: Rank {row['lasso_rank']}, Importance {row['lasso_importance']:.4f}")

    # Verify we have 3 features
    assert result_df.count() == 4, f"Expected 4 features, got {result_df.count()}"

    # Verify all features are present
    features = set(result_pandas['feature'].tolist())
    expected_features = {'feature1', 'feature2', 'feature3', 'feature4'}
    assert features == expected_features, f"Expected features {expected_features}, got {features}"

    # Verify rankings are distinct (1, 2, 3, 4 for each model)
    # Due to non-linear relationships and random data the lasso model will not rank them all, we use max in ranking function
    # So both features that are unranked (0 value) will have a rank of 4
    for model in ['rf', 'xgb', 'lasso']:
        ranks = sorted(result_pandas[f'{model}_rank'].tolist())
        if model != 'lasso':
            expected_ranks = [1, 2, 3, 4]
        else:
            expected_ranks = [1, 2, 4, 4]
        assert ranks == expected_ranks, f"{model} ranks should be [1, 2, 3, 4], got {ranks}"

    # Verify importance values are all positive (or zero)
    for model in ['rf', 'xgb', 'lasso']:
        importances = result_pandas[f'{model}_importance'].tolist()
        assert all(imp >= 0 for imp in importances), f"{model} importances should be >= 0"

    # Expected ranking based on data pattern:
    # Feature1: Very strong positive correlation (0.95x target + tiny noise) → Rank 1
    # Feature2: Strong negative correlation (decreases as target increases) → Rank 2 or 3
    # Feature3: Non-linear → Rank 2 for tree models, but may not be ranked by Lasso
    # Feature4: Very weak correlation (mostly random noise) → Rank 4

    feature1_row = result_pandas[result_pandas['feature'] == 'feature1'].iloc[0]
    feature2_row = result_pandas[result_pandas['feature'] == 'feature2'].iloc[0]
    feature3_row = result_pandas[result_pandas['feature'] == 'feature3'].iloc[0]
    feature4_row = result_pandas[result_pandas['feature'] == 'feature4'].iloc[0]

    # Check that feature1 has highest importance for most models (should be rank 1)
    assert feature1_row['rf_rank'] == 1, f"Feature1 should be rank 1 for RF, got {feature1_row['rf_rank']}"
    assert feature1_row['xgb_rank'] == 1, f"Feature1 should be rank 1 for XGB, got {feature1_row['xgb_rank']}"
    assert feature1_row['lasso_rank'] == 1, f"Feature1 should be rank 1 for Lasso, got {feature1_row['lasso_rank']}"

    # Check that feature4 has lowest importance for most models (should be rank 4)
    assert feature4_row['rf_rank'] == 4, f"Feature4 should be rank 4 for RF, got {feature3_row['rf_rank']}"
    assert feature4_row['xgb_rank'] == 4, f"Feature4 should be rank 4 for XGB, got {feature3_row['xgb_rank']}"
    assert feature4_row['lasso_rank'] == 4, f"Feature4 should be rank 4 for Lasso, got {feature3_row['lasso_rank']}"

    # Check specific model cases
    # Feature 2 is another linear relationship so lasso should rank it 2nd
    assert feature2_row['lasso_rank'] == 2
    # Feature 2 and 3 both have strong relationships, but feature 2 is linear and feature 3 is non-linear
    # Depending on the random variation, feature 2 may be ranked 2nd or 3rd
    assert (feature2_row['rf_rank'] == 3 or feature2_row['rf_rank'] == 2) and (feature3_row['rf_rank'] == 3 or feature3_row['rf_rank'] == 2)
    assert (feature2_row['xgb_rank'] == 3 or feature2_row['xgb_rank'] == 2) and (feature3_row['xgb_rank'] == 3 or feature3_row['xgb_rank'] == 2)
    # Feature 3 is non-linear so lasso hasn't ranked it
    assert feature3_row['lasso_rank'] == 4

    # Verify metrics not all zeros
    metrics = ['rf_mae', 'rf_mape', 'rf_r2', 'xgb_mae', 'xgb_mape', 'xgb_r2', 'lasso_mae', 'lasso_mape', 'lasso_r2']
    for metric in metrics:
        values = result_pandas[metric].tolist()
        # At least some metrics should be non-zero
        assert not all(v == 0 for v in values), f"All {metric} values are zero, models may not be working"

    # Test that cluster and group_key are set correctly
    assert all(result_pandas['cluster'] == 'C1'), "All cluster values should be 'C1'"
    assert all(result_pandas['group_key'] == 'group1~cluster1~C1'), "All group_key values should match input"

    # Test edge case: Empty input DataFrame
    empty_df = spark_session.createDataFrame([], input_df.schema)
    empty_result_df = run_models_udf(empty_df)

    # Assert the output is empty for empty input
    assert empty_result_df.count() == 0, "Output should be empty for empty input"

    print("\n=== All tests passed! ===")


# ToDo need to make a few edits
@pytest.mark.usefixtures("spark_session")
def test_feature_prioritization_ensemble(spark_session):
    # Set random seed for reproducibility
    random.seed(42)

    # Create mock input data (internal features + target variable)
    input_data = []
    # Create 26 weeks worth of test data
    for week in range(26):
        month = (week // 4) + 1
        day = (week % 4) * 7 + 1
        if month > 12:
            month = 12
            day = min(day, 28)
        date_str = f"2023-{month:02d}-{day:02d}"

        # Create target variable
        target_value = 10 + week * 0.5 + random.uniform(-0.1, 0.1)

        # Create internal features
        internal_feature1 = target_value * 0.9 + random.uniform(-0.1, 0.1)
        internal_feature2 = 30 - week * 0.3 + random.uniform(-0.5, 0.5)

        input_data.extend([
            Row(date=to_date(date_str),
                group_key="group1~cluster1~C1",
                variable="internal_feature1",
                value=internal_feature1),
            Row(date=to_date(date_str),
                group_key="group1~cluster1~C1",
                variable="internal_feature2",
                value=internal_feature2),
            Row(date=to_date(date_str),
                group_key="group1~cluster1~C1",
                variable="C1",
                value=target_value),
        ])

    input_df = spark_session.createDataFrame(input_data, schema=FeaturePrioritisation.pre_processed_output_schema)

    # Create mock external variables data
    external_data = []
    for week in range(26):
        month = (week // 4) + 1
        day = (week % 4) * 7 + 1
        if month > 12:
            month = 12
            day = min(day, 28)
        date_str = f"2023-{month:02d}-{day:02d}"

        # Create external features
        external_feature1 = 20 + week * 0.4 + random.uniform(-0.2, 0.2)
        external_feature2 = 40 - week * 0.6 + random.uniform(-0.3, 0.3)

        external_data.extend([
            Row(date=to_date(date_str),
                group_key="group1~cluster1~C1",
                variable="external_feature1",
                value=external_feature1),
            Row(date=to_date(date_str),
                group_key="group1~cluster1~C1",
                variable="external_feature2",
                value=external_feature2),
        ])

    non_external_vars_df_x = spark_session.createDataFrame(external_data, schema=FeaturePrioritisation.pre_processed_output_schema)

    # Create mock correlation data
    corr_data = [
        Row(feature="internal_feature1", cluster="C1", correlation_score=0.85, group_key="group1~cluster1~C1"),
        Row(feature="internal_feature2", cluster="C1", correlation_score=0.65, group_key="group1~cluster1~C1"),
        Row(feature="external_feature1", cluster="C1", correlation_score=0.75, group_key="group1~cluster1~C1"),
        Row(feature="external_feature2", cluster="C1", correlation_score=0.55, group_key="group1~cluster1~C1"),
    ]

    corr_schema = FeaturePrioritisation.correlation_schema

    corr_df = spark_session.createDataFrame(corr_data, schema=corr_schema)

    # Create mock configuration
    class MockConfig:
        class EnsembleConfig:
            # Model parameters
            random_forest_random_state = 42
            random_forest_n_estimators = 100
            random_forest_max_depth = 3
            xgboost_random_state = 42
            xgboost_n_estimators = 50
            xgboost_max_depth = 3
            lasso_cross_validation_k_fold = 5
            lasso_random_state = 42

            # Ensemble weights
            rf_weight = 0.4
            xgb_weight = 0.3
            lasso_weight = 0.3

        ensemble_config = EnsembleConfig()

    fp_config = MockConfig()

    # Define input parameters
    list_of_dependent_vars = ["C1"]
    model_schema = FeaturePrioritisation.model_outputs_schema

    # Run the function
    result_df = feature_prioritization_ensemble(
        list_of_dependent_vars=list_of_dependent_vars,
        input_df=input_df,
        non_external_vars_df_x=non_external_vars_df_x,
        corr_df=corr_df,
        model_schema=model_schema,
        fp_config=fp_config
    )

    # Assert the output is not empty
    assert result_df.count() > 0, "Output DataFrame should not be empty"

    # Convert to pandas for easier analysis
    result_pandas = result_df.toPandas()

    # Print results for analysis in case of failure
    print("\n=== Feature Prioritization Ensemble Results ===")
    print(result_pandas.to_string(index=False))

    print("\n=== Final Rankings ===")
    final_sorted = result_pandas.sort_values('final_rank')
    for _, row in final_sorted.iterrows():
        print(f"  {row['feature']}: Final Rank {row['final_rank']}, Calculated Rank {row['calculated_rank']:.4f}")

    # Verify we have 4 features (2 internal + 2 external)
    assert result_df.count() == 4, f"Expected 4 features, got {result_df.count()}"

    # Verify all expected features are present
    features = set(result_pandas['feature'].tolist())
    expected_features = {'internal_feature1', 'internal_feature2', 'external_feature1', 'external_feature2'}
    assert features == expected_features, f"Expected features {expected_features}, got {features}"

    # Verify final rankings are distinct (1, 2, 3, 4)
    final_ranks = sorted(result_pandas['final_rank'].tolist())
    expected_ranks = [1, 2, 3, 4]
    assert final_ranks == expected_ranks, f"Final ranks should be [1, 2, 3, 4], got {final_ranks}"

    # Verify calculated_rank column exists and contains reasonable values
    assert 'calculated_rank' in result_pandas.columns, "calculated_rank column should exist"
    calculated_ranks = result_pandas['calculated_rank'].tolist()
    assert all(isinstance(rank, (int, float)) for rank in calculated_ranks), "All calculated ranks should be numeric"
    assert all(rank > 0 for rank in calculated_ranks), "All calculated ranks should be positive"

    # Verify correlation scores are joined correctly
    assert 'correlation' in result_pandas.columns, "correlation column should exist"
    correlation_scores = result_pandas['correlation'].tolist()
    assert all(score is not None for score in correlation_scores), "All correlation scores should be populated"

    # Verify ensemble weights are applied correctly
    # The calculated_rank should be a weighted combination of individual model ranks
    weights = fp_config.ensemble_config
    for _, row in result_pandas.iterrows():
        expected_calc_rank = (
            row['rf_rank'] * weights.rf_weight +
            row['xgb_rank'] * weights.xgb_weight +
            row['lasso_rank'] * weights.lasso_weight
        )
        assert abs(row['calculated_rank'] - expected_calc_rank) < 0.001, \
            f"Calculated rank mismatch for {row['feature']}: expected {expected_calc_rank}, got {row['calculated_rank']}"

    # Verify that final_rank is ordered by calculated_rank (ascending)
    sorted_by_calc = result_pandas.sort_values('calculated_rank')
    sorted_by_final = result_pandas.sort_values('final_rank')
    assert sorted_by_calc['feature'].tolist() == sorted_by_final['feature'].tolist(), \
        "Final rank should be ordered by calculated rank"

    # Verify all required columns are present
    required_columns = [
        'feature', 'cluster', 'group_key', 'correlation',
        'rf_rank', 'xgb_rank', 'lasso_rank', 'rf_importance', 'xgb_importance', 'lasso_importance',
        'rf_mae', 'rf_mape', 'rf_r2', 'xgb_mae', 'xgb_mape', 'xgb_r2',
        'lasso_mae', 'lasso_mape', 'lasso_r2', 'calculated_rank', 'final_rank'
    ]
    for col in required_columns:
        assert col in result_pandas.columns, f"Required column {col} missing from output"

    # Verify cluster and group_key are set correctly
    assert all(result_pandas['cluster'] == 'C1'), "All cluster values should be 'C1'"
    assert all(result_pandas['group_key'] == 'group1~cluster1~C1'), "All group_key values should match input"

    # Verify model performance metrics are not all zeros
    metrics = ['rf_mae', 'rf_mape', 'rf_r2', 'xgb_mae', 'xgb_mape', 'xgb_r2', 'lasso_mae', 'lasso_mape', 'lasso_r2']
    for metric in metrics:
        values = result_pandas[metric].tolist()
        assert not all(v == 0 for v in values), f"All {metric} values are zero, models may not be working"

    # Test with different ensemble weights
    print("\n=== Testing Different Ensemble Weights ===")
    fp_config.ensemble_config.rf_weight = 0.6
    fp_config.ensemble_config.xgb_weight = 0.2
    fp_config.ensemble_config.lasso_weight = 0.2

    result_df_different_weights = feature_prioritization_ensemble(
        list_of_dependent_vars=list_of_dependent_vars,
        input_df=input_df,
        non_external_vars_df_x=non_external_vars_df_x,
        corr_df=corr_df,
        model_schema=model_schema,
        fp_config=fp_config
    )

    result_pandas_different = result_df_different_weights.toPandas()

    # Verify that different weights produce different calculated ranks
    original_calc_ranks = result_pandas['calculated_rank'].tolist()
    new_calc_ranks = result_pandas_different['calculated_rank'].tolist()
    assert original_calc_ranks != new_calc_ranks, "Different ensemble weights should produce different calculated ranks"

    # Test edge case: Empty correlation dataframe
    print("\n=== Testing Edge Case: Empty Correlation Data ===")
    empty_corr_df = spark_session.createDataFrame([], corr_schema)

    result_df_empty_corr = feature_prioritization_ensemble(
        list_of_dependent_vars=list_of_dependent_vars,
        input_df=input_df,
        non_external_vars_df_x=non_external_vars_df_x,
        corr_df=empty_corr_df,
        model_schema=model_schema,
        fp_config=fp_config
    )

    # Should still work but correlation_score will be null
    assert result_df_empty_corr.count() > 0, "Should still produce results with empty correlation data"

    # Test edge case: Empty external variables
    print("\n=== Testing Edge Case: Empty External Variables ===")
    empty_non_external_df = spark_session.createDataFrame([], FeaturePrioritisation.pre_processed_output_schema)

    result_df_empty_external = feature_prioritization_ensemble(
        list_of_dependent_vars=list_of_dependent_vars,
        input_df=input_df,
        non_external_vars_df_x=empty_non_external_df,
        corr_df=corr_df,
        model_schema=model_schema,
        fp_config=fp_config
    )

    # Should work with only internal features
    result_pandas_empty_external = result_df_empty_external.toPandas()
    assert result_df_empty_external.count() == 2, "Should have 2 features (only internal) when external is empty"

    internal_features_only = set(result_pandas_empty_external['feature'].tolist())
    expected_internal_only = {'internal_feature1', 'internal_feature2'}
    assert internal_features_only == expected_internal_only, \
        f"Expected only internal features {expected_internal_only}, got {internal_features_only}"

    print("\n=== All ensemble tests passed! ===")
