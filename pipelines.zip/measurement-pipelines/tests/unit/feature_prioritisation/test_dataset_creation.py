from datetime import datetime

import pytest
from chispa import assert_df_equality
from pyspark.sql import Row

from spark_pipeline.schemas.feature_prioritisation import FeaturePrioritisation
from spark_pipeline.utils.feature_prioritisation.dataset_creation import initial_dataset_creation, \
    dataset_variable_creation, dataset_preprocessing
from tests.unit.feature_prioritisation.helper_functions import to_date


fp_config_mock = type("MockConfig", (), {
    "seasonality_index_window_length": 3,
    "seasonality_index_min_threshold": 0.1,
    "seasonality_index_strict_threshold": 0.2,
    "seasonality_index_name": "seasonality_index",
    "seasonality_primary_metric": "Y",
    "seasonality_investment_metric": "N",
    "seasonality_index_pea_name": "seasonality_pea",
    "seasonality_index_dip_name": "seasonality_dip",
    "dependent_variable": "sales",
    "peak_dummy_name": "peak_dummy",
    "dip_dummy_name": "dip_dummy",
    "ucm_pass_no": "set_1",
    "std_dev_control_index_name": "std_dev_control",
    "std_dev_primary_metric": "Y",
    "std_dev_investment_metric": "N",
    "week_start_control_index_name": "week_start_control",
    "week_start_primary_metric": "Y",
    "week_start_investment_metric": "N",
    "external_marketing_type_names": ['EXTERNAL', 'PROMOTIONAL DISCOUNT', 'VALUE INDEX'],
    "external_metric": ['BASE_UNIT_PRICE_AMT']
})


@pytest.mark.usefixtures("spark_session")
def test_initial_dataset_creation(spark_session):
    # Create test data for baseline_modelling_dataset
    baseline_modelling_data = [
        Row(
            week_start_dt=to_date("2023-01-01"),
            super_category_name="CategoryA",
            unique_brand_name="BrandA",
            cluster_num="Cluster1",
            variable_cd="VarA",
            marketing_type_name="TypeA",
            marketing_channel_name="SALES",
            marketing_sub_channel_name="SubChannelA",
            metric_name="TOTAL_SALES",
            metric_value=100.0,
            job_run_id="Job1",
        ),
        Row(
            week_start_dt=to_date("2023-01-08"),
            super_category_name="CategoryB",
            unique_brand_name="BrandB",
            cluster_num="Cluster2",
            variable_cd="VarB",
            marketing_type_name="TypeB",
            marketing_channel_name="SALES",
            marketing_sub_channel_name="SubChannelB",
            metric_name="TOTAL_SALES",
            metric_value=200.0,
            job_run_id="Job2",
        ),
        Row(
            week_start_dt=to_date("2023-01-15"),
            super_category_name="CategoryC",
            unique_brand_name="BrandC",
            cluster_num="Cluster3",
            variable_cd="VarC",
            marketing_type_name="TypeC",
            marketing_channel_name="OTHER",
            marketing_sub_channel_name="SubChannelC",
            metric_name="OTHER_METRIC",
            metric_value=300.0,
            job_run_id="Job3",
        ),
    ]
    baseline_modelling_dataset = spark_session.createDataFrame(baseline_modelling_data, schema=FeaturePrioritisation.baseline_input_dataset_schema)

    # Create test data for primary_metric_df
    primary_metric_data = [
        Row(
            marketing_type_name="TypeA",
            marketing_channel_name="SALES",
            marketing_sub_channel_name="SubChannelA",
            metric_name="TOTAL_SALES",
            primary_metric_cd="PrimaryA",
            investment_metric_cd="InvestmentA"
        ),
        Row(
            marketing_type_name="TypeB",
            marketing_channel_name="SALES",
            marketing_sub_channel_name="SubChannelB",
            metric_name="TOTAL_SALES",
            primary_metric_cd="PrimaryB",
            investment_metric_cd="InvestmentB"
        )
    ]
    primary_metric_df = spark_session.createDataFrame(primary_metric_data, schema=FeaturePrioritisation.primary_metric_schema)

    # Define modeling period
    model_start_date = "2023-01-01"
    model_end_date = "2023-01-10"

    # Call the function
    fp_input_y_df, baseline_modelling_df = initial_dataset_creation(
        baseline_modelling_dataset,
        primary_metric_df,
        model_start_date,
        model_end_date
    )

    # Only get weeks within the model period, checking if the y valuyes are correct
    expected_fp_input_y_data = [
        Row(
            week_start_date=to_date("2023-01-01"),
            super_category_name="CategoryA",
            unique_brand="BrandA",
            final_cluster="Cluster1",
            feature_prioritization_y=100.0
        ),
        Row(
            week_start_date=to_date("2023-01-08"),
            super_category_name="CategoryB",
            unique_brand="BrandB",
            final_cluster="Cluster2",
            feature_prioritization_y=200.0
        ),
    ]
    expected_fp_input_y_df = spark_session.createDataFrame(expected_fp_input_y_data)
    assert_df_equality(fp_input_y_df, expected_fp_input_y_df)

    # Check if the joined DataFrame has the correct columns and values
    expected_baseline_modelling_data = [
        Row(
            week_start_date=to_date("2023-01-01"),
            super_category_name="CategoryA",
            unique_brand="BrandA",
            cluster="Cluster1",
            variable="VarA",
            marketing_type="TypeA",
            marketing_channel="SALES",
            marketing_sub_channel="SubChannelA",
            metric="TOTAL_SALES",
            value=100.0,
            job_id="Job1",
            primary_metric="PrimaryA",
            investment_metric="InvestmentA"
        ),
        Row(
            week_start_date=to_date("2023-01-08"),
            super_category_name="CategoryB",
            unique_brand="BrandB",
            cluster="Cluster2",
            variable="VarB",
            marketing_type="TypeB",
            marketing_channel="SALES",
            marketing_sub_channel="SubChannelB",
            metric="TOTAL_SALES",
            value=200.0,
            job_id="Job2",
            primary_metric="PrimaryB",
            investment_metric="InvestmentB"
        ),
    ]
    expected_baseline_modelling_df = spark_session.createDataFrame(expected_baseline_modelling_data)
    assert_df_equality(baseline_modelling_df, expected_baseline_modelling_df, ignore_row_order=True, ignore_column_order=True)


@pytest.mark.usefixtures("spark_session")
def test_dataset_variable_creation(spark_session):
    load_ts = datetime.strptime("2023-07-17 10:00:00", "%Y-%m-%d %H:%M:%S")

    # These will get filtered as sales data and flag a peak to test the control variable creation
    sales_data = [
        Row(week_date=datetime(2023, 1, 1).date(), unique_brand="brand1", super_category_name="DAIRY", cluster="cluster1",
            value=v, job_id="test_job_001", load_ts=load_ts, marketing_type="internal", marketing_channel="SALES",
            marketing_sub_channel="TOTAL", metric="TOTAL_SALES", variable="SALES_TOT",
            primary_metric="Y", investment_metric="N"
            )
        for v in [1.0, 5.0, 10.0, 15.0, 20.0, 25.0, 100.0]  # spike triggers peak
    ]

    # Will get picked up as an external factor
    external_row = Row(
        week_date=datetime(2023, 7, 10).date(), unique_brand="TOTAL", super_category_name="TOTAL", cluster="TOTAL",
        value=7.0, job_id="external_job_001", load_ts=load_ts, marketing_type="EXTERNAL", marketing_channel="FUEL PRICES",
        marketing_sub_channel="TOTAL", metric="ULSD_PENCE_PER_LITRE", variable="TOT_TOT_TOT_EXT_FUE_TOT_UL2",
        primary_metric="Y", investment_metric="N"
    )

    # Will get picked up as metric (BASE_UNIT_PRICE_AMT)
    internal_row = Row(
        week_date=datetime(2023, 11, 27).date(), unique_brand="DORITOS|PEPSICO", super_category_name="CRISPS & SNACKS", cluster="CL1",
        value=8.0, job_id="internal_job_001", load_ts=load_ts, marketing_type="offsite", marketing_channel="META",
        marketing_sub_channel="TOTAL", metric="BASE_UNIT_PRICE_AMT", variable="CRI_MIN_CL2_SAL_SAL_TOT_BA1",
        primary_metric="Y", investment_metric="N"
    )

    # Combine all inputs
    input_rows = sales_data + [external_row, internal_row]
    input_df = spark_session.createDataFrame(input_rows, schema=FeaturePrioritisation.intermediate_input_dataset_schema)

    # Run function under test
    external_df, internal_df = dataset_variable_creation(input_df, fp_config_mock)

    # Assertions
    external_rows = external_df.select("variable").collect()
    internal_rows = internal_df.select("variable", "metric").collect()

    # Convert to Python structures
    external_vars = [r.variable for r in external_rows]
    internal_vars = [r.variable for r in internal_rows]
    internal_vars_lower = {v.lower() for v in internal_vars}
    internal_metrics = [r.metric for r in internal_rows]

    # --- Assertions ---
    # External rows must include the fuel variable and there should be only one row
    assert external_vars.count("TOT_TOT_TOT_EXT_FUE_TOT_UL2") == 1
    assert len(external_vars) == 1

    # Internal should contain peak_dummy variable from std dev spike
    assert "PEAK_DUMMY" in internal_vars

    # Internal should contain the weekly control variables
    for v in (
            "NEC_XXX_XXX_XXX_XXX_PE1_DUM",
            "NEC_XXX_XXX_XXX_XXX_PE2_DUM",
            "NEC_XXX_XXX_XXX_XXX_PE3_DUM",
            "NEC_XXX_XXX_XXX_XXX_PE4_DUM",
    ):
        assert v in internal_vars

    # Internal should NOT contain seasonality variables
    assert "seasonality_pea" not in internal_vars_lower
    assert "seasonality_dip" not in internal_vars_lower

    # Internal should contain the BASE_UNIT_PRICE_AMT metric
    assert internal_metrics.count("BASE_UNIT_PRICE_AMT") == 1

    # Control test
    assert len(external_vars) > 0
    assert len(internal_vars) > 0


@pytest.mark.usefixtures("spark_session")
def test_dataset_preprocessing(spark_session):
    # Define input data for input_df_y
    input_df_y_data = [
        Row(week_start_date=to_date("2024-02-05"), unique_brand="BRAND1", super_category_name="CATEGORY1", final_cluster="CLUSTER1", feature_prioritization_y=100.0),
        Row(week_start_date=to_date("2024-02-06"), unique_brand="BRAND1", super_category_name="CATEGORY1", final_cluster="CLUSTER1", feature_prioritization_y=200.0),
        Row(week_start_date=to_date("2024-02-05"), unique_brand="BRAND2", super_category_name="CATEGORY2", final_cluster="CLUSTER2", feature_prioritization_y=300.0),
    ]
    input_df_y = spark_session.createDataFrame(input_df_y_data, schema=FeaturePrioritisation.pre_processed_input_y_schema)

    # Define input data for external_vars_df
    external_vars_data = [
        Row(date=to_date("2024-02-05"), unique_brand="BRAND1", super_category_name="CATEGORY1", cluster="CLUSTER1", variable="VAR1", value=10.0),
        Row(date=to_date("2024-02-06"), unique_brand="BRAND1", super_category_name="CATEGORY1", cluster="CLUSTER1", variable="VAR1", value=20.0),
        Row(date=to_date("2024-02-05"), unique_brand="BRAND2", super_category_name="CATEGORY2", cluster="CLUSTER2", variable="VAR2", value=30.0),
    ]
    external_vars_df = spark_session.createDataFrame(external_vars_data, schema=FeaturePrioritisation.pre_processed_input_x_schema)

    # Define input data for non_external_vars_df
    non_external_vars_data = [
        Row(date=to_date("2024-02-05"), unique_brand="BRAND1", super_category_name="CATEGORY1", cluster="CLUSTER1", variable="VAR3", value=40.0),
        Row(date=to_date("2024-02-06"), unique_brand="BRAND1", super_category_name="CATEGORY1", cluster="CLUSTER1", variable="VAR3", value=50.0),
        Row(date=to_date("2024-02-05"), unique_brand="BRAND2", super_category_name="CATEGORY2", cluster="CLUSTER2", variable="VAR4", value=60.0),
    ]
    non_external_vars_df = spark_session.createDataFrame(non_external_vars_data, schema=FeaturePrioritisation.pre_processed_input_x_schema)

    # Define input data for cluster_df, which filters the data
    cluster_data = [
        Row(modelling_cluster_list="BRAND1~CATEGORY1~CLUSTER1"),
        Row(modelling_cluster_list="BRAND2~CATEGORY2~CLUSTER2"),
    ]
    cluster_df = spark_session.createDataFrame(cluster_data)

    # Ignore correlation_df for this test as it's tested separately
    list_of_dependent_vars, input_df_final, non_external_vars_scaled, _ = dataset_preprocessing(
        input_df_y, external_vars_df, non_external_vars_df, cluster_df
    )
    non_external_vars_scaled.show(10, False)

    expected_list_of_dependent_vars = ["CLUSTER1", "CLUSTER2"]

    expected_input_df_final_data = [
        Row(date=to_date("2024-02-05"), group_key="BRAND1~CATEGORY1~CLUSTER1", variable="VAR1", value=0.0),
        Row(date=to_date("2024-02-06"), group_key="BRAND1~CATEGORY1~CLUSTER1", variable="VAR1", value=1.0),
        Row(date=to_date("2024-02-05"), group_key="BRAND1~CATEGORY1~CLUSTER1", variable="VAR2", value=0.0),
        Row(date=to_date("2024-02-06"), group_key="BRAND1~CATEGORY1~CLUSTER1", variable="VAR2", value=0.0),
        Row(date=to_date("2024-02-05"), group_key="BRAND1~CATEGORY1~CLUSTER1", variable="CLUSTER1", value=0.0),
        Row(date=to_date("2024-02-06"), group_key="BRAND1~CATEGORY1~CLUSTER1", variable="CLUSTER1", value=1.0),
        Row(date=to_date("2024-02-05"), group_key="BRAND2~CATEGORY2~CLUSTER2", variable="VAR1", value=0.0),
        Row(date=to_date("2024-02-05"), group_key="BRAND2~CATEGORY2~CLUSTER2", variable="VAR2", value=0.0),
        Row(date=to_date("2024-02-05"), group_key="BRAND2~CATEGORY2~CLUSTER2", variable="CLUSTER2", value=0.0),
    ]
    expected_input_df_final = spark_session.createDataFrame(expected_input_df_final_data, schema=FeaturePrioritisation.pre_processed_output_schema)

    expected_non_external_vars_scaled_data = [
        Row(date=to_date("2024-02-05"), unique_brand="BRAND1", super_category_name="CATEGORY1", cluster="CLUSTER1", group_key="BRAND1~CATEGORY1~CLUSTER1", variable="VAR3", value=0.0),
        Row(date=to_date("2024-02-06"), unique_brand="BRAND1", super_category_name="CATEGORY1", cluster="CLUSTER1", group_key="BRAND1~CATEGORY1~CLUSTER1", variable="VAR3", value=1.0),
        Row(date=to_date("2024-02-05"), unique_brand="BRAND2", super_category_name="CATEGORY2", cluster="CLUSTER2", group_key="BRAND2~CATEGORY2~CLUSTER2", variable="VAR4", value=0.0),
    ]
    expected_non_external_vars_scaled = spark_session.createDataFrame(expected_non_external_vars_scaled_data, schema=FeaturePrioritisation.pre_processed_external_output_schema)

    # Assert outputs
    assert list_of_dependent_vars == expected_list_of_dependent_vars
    assert_df_equality(input_df_final, expected_input_df_final, ignore_nullable=True, ignore_row_order=True)
    assert_df_equality(non_external_vars_scaled, expected_non_external_vars_scaled, ignore_nullable=True, ignore_row_order=True, ignore_column_order=True)
