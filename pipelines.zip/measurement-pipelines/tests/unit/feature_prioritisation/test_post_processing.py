import pytest
from pyspark.sql import Row
from chispa import assert_df_equality

from spark_pipeline.schemas.feature_prioritisation import FeaturePrioritisation
from spark_pipeline.utils.feature_prioritisation.dataset_post_processing import (
    fp_data_post_processing,
    fp_final_output,
    fix_control_variable_hierarchy,
)


@pytest.mark.usefixtures("spark_session")
def test_fp_data_post_processing(spark_session):
    from pyspark.sql import Row
    from chispa import assert_df_equality

    # Input DataFrame
    input_data = [
        Row(
            feature="feature1", cluster="C1", group_key="group1~cluster1~C1",
            rf_importance=0.5, rf_rank=1, xgb_importance=0.4, xgb_rank=2,
            lasso_importance=0.3, lasso_rank=3, rf_mae=0.1, rf_mape=0.2,
            rf_r2=0.9, xgb_mae=0.2, xgb_mape=0.3, xgb_r2=0.8, lasso_mae=0.3,
            lasso_mape=0.4, lasso_r2=0.7, correlation=0.6, calculated_rank=1.0,
            final_rank=1
        ),
        Row(
            feature="feature2", cluster="C1", group_key="group1~cluster1~C1",
            rf_importance=0.3, rf_rank=2, xgb_importance=0.2, xgb_rank=3,
            lasso_importance=0.1, lasso_rank=4, rf_mae=0.2, rf_mape=0.3,
            rf_r2=0.8, xgb_mae=0.3, xgb_mape=0.4, xgb_r2=0.7, lasso_mae=0.4,
            lasso_mape=0.5, lasso_r2=0.6, correlation=0.4, calculated_rank=2.0,
            final_rank=2
        ),
        Row(
            feature="festive_feature", cluster="C1", group_key="group1~cluster1~C1",
            rf_importance=0.1, rf_rank=3, xgb_importance=0.1, xgb_rank=4,
            lasso_importance=0.1, lasso_rank=5, rf_mae=0.3, rf_mape=0.4,
            rf_r2=0.7, xgb_mae=0.4, xgb_mape=0.5, xgb_r2=0.6, lasso_mae=0.5,
            lasso_mape=0.6, lasso_r2=0.5, correlation=0.2, calculated_rank=3.0,
            final_rank=3
        ),
    ]
    input_df = spark_session.createDataFrame(input_data, schema=FeaturePrioritisation.fp_data_post_processing_input_schema)

    # Behavior follows; Standardizes column names (strips spaces).
    #     Removes any rows related to 'festive' features.
    #     Renames 'CLUSTER' to 'FINAL_CLUSTER' if present.
    #     Recomputes FINAL_RANK using row_number per group_key.
    expected_data = [
        Row(
            feature="feature1", final_cluster="C1", group_key="group1~cluster1~C1",
            rf_importance=0.5, rf_rank=1, xgb_importance=0.4, xgb_rank=2,
            lasso_importance=0.3, lasso_rank=3, rf_mae=0.1, rf_mape=0.2,
            rf_r2=0.9, xgb_mae=0.2, xgb_mape=0.3, xgb_r2=0.8, lasso_mae=0.3,
            lasso_mape=0.4, lasso_r2=0.7, correlation=0.6, calculated_rank=1.0,
            final_rank=1
        ),
        Row(
            feature="feature2", final_cluster="C1", group_key="group1~cluster1~C1",
            rf_importance=0.3, rf_rank=2, xgb_importance=0.2, xgb_rank=3,
            lasso_importance=0.1, lasso_rank=4, rf_mae=0.2, rf_mape=0.3,
            rf_r2=0.8, xgb_mae=0.3, xgb_mape=0.4, xgb_r2=0.7, lasso_mae=0.4,
            lasso_mape=0.5, lasso_r2=0.6, correlation=0.4, calculated_rank=2.0,
            final_rank=2
        ),
    ]
    expected_df = spark_session.createDataFrame(expected_data, schema=FeaturePrioritisation.fp_data_post_processing_output_schema)

    # Run the function
    result_df = fp_data_post_processing(input_df)

    # Assert equality
    assert_df_equality(result_df, expected_df, ignore_nullable=True, ignore_column_order=True)


# ToDo Add schema's and more test examples to this test
@pytest.mark.usefixtures("spark_session")
def test_fp_final_output(spark_session):
    # Input FP result data
    fp_result_data = [
        Row(
            feature="feature1", final_cluster="C1", group_key="brand1~super_cat_1~C1",
            rf_importance=0.5, rf_rank=1, xgb_importance=0.4, xgb_rank=2,
            lasso_importance=0.3, lasso_rank=3, rf_mae=0.1, rf_mape=0.2,
            rf_r2=0.9, xgb_mae=0.2, xgb_mape=0.3, xgb_r2=0.8, lasso_mae=0.3,
            lasso_mape=0.4, lasso_r2=0.7, correlation=0.6, calculated_rank=1.0,
            final_rank=1
        ),
        Row(
            feature="feature2", final_cluster="C1", group_key="brand1~super_cat_1~C1",
            rf_importance=0.3, rf_rank=2, xgb_importance=0.2, xgb_rank=3,
            lasso_importance=0.1, lasso_rank=4, rf_mae=0.2, rf_mape=0.3,
            rf_r2=0.8, xgb_mae=0.3, xgb_mape=0.4, xgb_r2=0.7, lasso_mae=0.4,
            lasso_mape=0.5, lasso_r2=0.6, correlation=0.4, calculated_rank=2.0,
            final_rank=2
        ),
    ]
    fp_result_df = spark_session.createDataFrame(fp_result_data)

    master_data = [
        Row(
            week_start_date="2023-01-01", unique_brand="brand1", cluster="C1",
            marketing_type="type1", marketing_channel="channel1",
            marketing_sub_channel="sub1", metric="metric1",
            value=100.0, variable="feature1"
        ),
        Row(
            week_start_date="2023-01-01", unique_brand="brand1", cluster="C1",
            marketing_type="type2", marketing_channel="channel2",
            marketing_sub_channel="sub2", metric="metric2",
            value=200.0, variable="feature2"
        ),
    ]
    master_df = spark_session.createDataFrame(master_data)

    # Expected output
    expected_data = [
        Row(
            super_category_name="super_cat_1", unique_brand_name="brand1", cluster_num="C1",
            variable_cd="FEATURE1", variable_importance_rank=1,
            marketing_type_name="type1", marketing_channel_name="channel1",
            marketing_sub_channel_name="sub1", metric_name="metric1"
        ),
        Row(
            super_category_name="super_cat_1", unique_brand_name="brand1", cluster_num="C1",
            variable_cd="FEATURE2", variable_importance_rank=2,
            marketing_type_name="type2", marketing_channel_name="channel2",
            marketing_sub_channel_name="sub2", metric_name="metric2"
        ),
    ]
    expected_df = spark_session.createDataFrame(expected_data, schema=FeaturePrioritisation.output_schema)

    # Run the function
    result_df = fp_final_output(fp_result_df, master_df)

    # Assert equality
    assert_df_equality(result_df, expected_df, ignore_nullable=True, ignore_column_order=True)


# ToDo This test does assess the function but it uses trival data, that is unlikely to be found in the data, so it needs updating with a better example
@pytest.mark.usefixtures("spark_session")
def test_fix_control_variable_hierarchy(spark_session):
    # Input DataFrame
    input_data = [
        Row(variable_cd="nec_xxx_xxx_xxx_xxx_pea_dum", marketing_type_name=None, marketing_channel_name=None, marketing_sub_channel_name=None, metric_name=None),
        Row(variable_cd="nec_xxx_xxx_xxx_xxx_pe1_dum", marketing_type_name=None, marketing_channel_name=None, marketing_sub_channel_name=None, metric_name=None),
        Row(variable_cd="other_variable", marketing_type_name="type1", marketing_channel_name="channel1", marketing_sub_channel_name="sub1", metric_name="metric1"),
    ]
    input_df = spark_session.createDataFrame(input_data)

    # Expected DataFrame
    expected_data = [
        Row(variable_cd="nec_xxx_xxx_xxx_xxx_pea_dum", marketing_type_name="STD DEV DUMMY", marketing_channel_name="STD DEV DUMMY", marketing_sub_channel_name="TOTAL", metric_name="STD DEV DUMMY"),
        Row(variable_cd="nec_xxx_xxx_xxx_xxx_pe1_dum", marketing_type_name="WEEK START DUMMY", marketing_channel_name="WEEK START DUMMY", marketing_sub_channel_name="TOTAL", metric_name="WEEK START DUMMY"),
        Row(variable_cd="other_variable", marketing_type_name="type1", marketing_channel_name="channel1", marketing_sub_channel_name="sub1", metric_name="metric1"),
    ]
    expected_df = spark_session.createDataFrame(expected_data)

    # Run the function
    result_df = fix_control_variable_hierarchy(input_df)

    # Assert equality
    assert_df_equality(result_df, expected_df, ignore_nullable=True, ignore_column_order=True)
