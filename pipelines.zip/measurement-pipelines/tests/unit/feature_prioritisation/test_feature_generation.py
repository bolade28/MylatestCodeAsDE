from datetime import datetime

import pytest
from pyspark.sql import Row
from pyspark.sql import functions as F

from chispa import assert_df_equality
from spark_pipeline.utils.feature_prioritisation.feature_generation import (
    seasonality_index_creator,
    std_dev_control_creator_all,
    week_start_control_creator_all,
    identify_peaks_and_dips_std_by_group,
    list_independent_ext_factors,
    melt_dataframe
)
from spark_pipeline.schemas.feature_prioritisation import FeaturePrioritisation
from tests.unit.feature_prioritisation.helper_functions import generate_seasonal_data, to_date

fp_config_mock = type("MockConfig", (), {
    "seasonality_index_window_length": 3,
    "seasonality_index_min_threshold": 0.1,
    "seasonality_index_strict_threshold": 0.2,
    "seasonality_index_name": "seasonality_index",
    "seasonality_primary_metric": "primary_metric",
    "seasonality_investment_metric": "investment_metric",
    "seasonality_index_pea_name": "seasonality_pea",
    "seasonality_index_dip_name": "seasonality_dip",
    "dependent_variable": "sales",
    "peak_dummy_name": "peak_dummy",
    "dip_dummy_name": "dip_dummy",
    "ucm_pass_no": "set_1",
    "std_dev_control_index_name": "std_dev_control",
    "std_dev_primary_metric": "std_dev_primary",
    "std_dev_investment_metric": "std_dev_investment",
    "week_start_control_index_name": "week_start_control",
    "week_start_primary_metric": "week_start_primary",
    "week_start_investment_metric": "week_start_investment",
    "external_marketing_type_names": ["type1", "type2"],
    "external_metric": ["metric1", "metric2"]
})


@pytest.mark.usefixtures("spark_session")
def test_seasonality_index_creator(spark_session):

    # Generate seasonal data for two years starting from 2023-01-01
    data = generate_seasonal_data("2023-01-01", initial_value=20.0, peak_value=1000.0)

    input_df = spark_session.createDataFrame(data, schema=FeaturePrioritisation.sales_schema)
    result_df = seasonality_index_creator(input_df, fp_config_mock)

    # First we check if the results have the expected number of rows per week
    assert result_df.filter(F.col("week_date") == F.to_date(F.lit("2023-01-01"))).count() == 2
    # The data is based on a sine wave from the initial_value to the peak_value
    # Based on this we can expect different behaviours, at the start there should be a peak and no dip
    negative_case = (
        result_df.filter(
            (F.col("week_date") == F.to_date(F.lit("2023-01-08"))) &
            (F.col("variable") == "seasonality_dip")
        )
        .select("value")
        .first()["value"]
    )
    positive_case = (
        result_df.filter(
            (F.col("week_date") == F.to_date(F.lit("2023-01-08"))) &
            (F.col("variable") == "seasonality_pea")
        )
        .select("value")
        .first()["value"]
    )
    assert negative_case == 0 and positive_case == 1


@pytest.mark.usefixtures("spark_session")
def test_std_dev_control_creator_all(spark_session):
    load_ts = datetime.strptime("2023-07-17 10:00:00", "%Y-%m-%d %H:%M:%S")

    data = [
        Row(
            week_date=datetime.strptime("2023-01-01", "%Y-%m-%d").date(),
            unique_brand="brand1",
            super_category_name="cat1",
            cluster="cluster1",
            value=1.0,
            job_id="test_job_001",
            load_ts=load_ts
        ),
        Row(
            week_date=datetime.strptime("2023-01-01", "%Y-%m-%d").date(),
            unique_brand="brand1",
            super_category_name="cat1",
            cluster="cluster1",
            value=5.0,
            job_id="test_job_001",
            load_ts=load_ts
        ),
        Row(
            week_date=datetime.strptime("2023-01-01", "%Y-%m-%d").date(),
            unique_brand="brand1",
            super_category_name="cat1",
            cluster="cluster1",
            value=10.0,
            job_id="test_job_001",
            load_ts=load_ts
        ),
        Row(
            week_date=datetime.strptime("2023-01-01", "%Y-%m-%d").date(),
            unique_brand="brand1",
            super_category_name="cat1",
            cluster="cluster1",
            value=15.0,
            job_id="test_job_001",
            load_ts=load_ts
        ),
        Row(
            week_date=datetime.strptime("2023-01-01", "%Y-%m-%d").date(),
            unique_brand="brand1",
            super_category_name="cat1",
            cluster="cluster1",
            value=20.0,
            job_id="test_job_001",
            load_ts=load_ts
        ),
        Row(
            week_date=datetime.strptime("2023-01-01", "%Y-%m-%d").date(),
            unique_brand="brand1",
            super_category_name="cat1",
            cluster="cluster1",
            value=25.0,
            job_id="test_job_001",
            load_ts=load_ts
        ),
        Row(
            week_date=datetime.strptime("2023-01-01", "%Y-%m-%d").date(),
            unique_brand="brand1",
            super_category_name="cat1",
            cluster="cluster1",
            value=100.0,  # spike in the value will trigger a peak
            job_id="test_job_001",
            load_ts=load_ts
        ),
    ]

    input_df = spark_session.createDataFrame(data, schema=FeaturePrioritisation.sales_schema_with_meta_data)

    result_df = std_dev_control_creator_all(input_df, fp_config_mock)

    aggregated_row = (
        result_df
        .groupBy("week_date")
        .agg(F.sum("value").alias("total_value"))
        .orderBy("week_date")
        .first()
    )

    assert aggregated_row["total_value"] == 1, "Expected peak_dummy=1 not found for 2023-01-01"


@pytest.mark.usefixtures("spark_session")
def test_empty_week_start_control_creator_all(spark_session):

    input_df = spark_session.createDataFrame([], schema=FeaturePrioritisation.sales_schema)
    result_df = week_start_control_creator_all(input_df, fp_config_mock)

    assert result_df.count() == 0


@pytest.mark.usefixtures("spark_session")
def test_week_start_control_creator_all(spark_session):
    load_ts = datetime.strptime("2023-07-17 10:00:00", "%Y-%m-%d %H:%M:%S")

    data = [
        Row(week_date=to_date("2023-01-01"), unique_brand="brand1", super_category_name="cat1", cluster="cluster1", value=100.0, job_id="test_job_001", load_ts=load_ts),
        Row(week_date=to_date("2023-01-08"), unique_brand="brand1", super_category_name="cat1", cluster="cluster1", value=110.0, job_id="test_job_001", load_ts=load_ts),
    ]
    input_df = spark_session.createDataFrame(data, schema=FeaturePrioritisation.sales_schema_with_meta_data)
    result_df = week_start_control_creator_all(input_df, fp_config_mock)

    expected_data = [
        Row(week_date=to_date("2023-01-01"), super_category_name="cat1", unique_brand="brand1", cluster="cluster1",
            variable="nec_xxx_xxx_xxx_xxx_pe1_dum", value=1,
            marketing_type="week_start_control", marketing_channel="week_start_control",
            marketing_sub_channel="week_start_control",
            metric="week_start_control", primary_metric="week_start_primary", investment_metric="week_start_investment",
            job_id="test_job_001", load_ts=load_ts),
        Row(week_date=to_date("2023-01-01"), super_category_name="cat1", unique_brand="brand1", cluster="cluster1",
            variable="nec_xxx_xxx_xxx_xxx_pe2_dum", value=0,
            marketing_type="week_start_control", marketing_channel="week_start_control",
            marketing_sub_channel="week_start_control",
            metric="week_start_control", primary_metric="week_start_primary", investment_metric="week_start_investment",
            job_id="test_job_001", load_ts=load_ts),
        Row(week_date=to_date("2023-01-01"), super_category_name="cat1", unique_brand="brand1", cluster="cluster1",
            variable="nec_xxx_xxx_xxx_xxx_pe3_dum", value=0,
            marketing_type="week_start_control", marketing_channel="week_start_control",
            marketing_sub_channel="week_start_control",
            metric="week_start_control", primary_metric="week_start_primary", investment_metric="week_start_investment",
            job_id="test_job_001", load_ts=load_ts),
        Row(week_date=to_date("2023-01-01"), super_category_name="cat1", unique_brand="brand1", cluster="cluster1",
            variable="nec_xxx_xxx_xxx_xxx_pe4_dum", value=0,
            marketing_type="week_start_control", marketing_channel="week_start_control",
            marketing_sub_channel="week_start_control",
            metric="week_start_control", primary_metric="week_start_primary", investment_metric="week_start_investment",
            job_id="test_job_001", load_ts=load_ts),

        Row(week_date=to_date("2023-01-08"), super_category_name="cat1", unique_brand="brand1", cluster="cluster1",
            variable="nec_xxx_xxx_xxx_xxx_pe1_dum", value=0,
            marketing_type="week_start_control", marketing_channel="week_start_control",
            marketing_sub_channel="week_start_control",
            metric="week_start_control", primary_metric="week_start_primary", investment_metric="week_start_investment",
            job_id="test_job_001", load_ts=load_ts),
        Row(week_date=to_date("2023-01-08"), super_category_name="cat1", unique_brand="brand1", cluster="cluster1",
            variable="nec_xxx_xxx_xxx_xxx_pe2_dum", value=1,
            marketing_type="week_start_control", marketing_channel="week_start_control",
            marketing_sub_channel="week_start_control",
            metric="week_start_control", primary_metric="week_start_primary", investment_metric="week_start_investment",
            job_id="test_job_001", load_ts=load_ts),
        Row(week_date=to_date("2023-01-08"), super_category_name="cat1", unique_brand="brand1", cluster="cluster1",
            variable="nec_xxx_xxx_xxx_xxx_pe3_dum", value=0,
            marketing_type="week_start_control", marketing_channel="week_start_control",
            marketing_sub_channel="week_start_control",
            metric="week_start_control", primary_metric="week_start_primary", investment_metric="week_start_investment",
            job_id="test_job_001", load_ts=load_ts),
        Row(week_date=to_date("2023-01-08"), super_category_name="cat1", unique_brand="brand1", cluster="cluster1",
            variable="nec_xxx_xxx_xxx_xxx_pe4_dum", value=0,
            marketing_type="week_start_control", marketing_channel="week_start_control",
            marketing_sub_channel="week_start_control",
            metric="week_start_control", primary_metric="week_start_primary", investment_metric="week_start_investment",
            job_id="test_job_001", load_ts=load_ts),
    ]

    expected_df = spark_session.createDataFrame(expected_data, schema=result_df.schema)
    assert_df_equality(result_df, expected_df)


@pytest.mark.usefixtures("spark_session")
def test_identify_peaks_and_dips_std_by_group(spark_session):
    data = [
        Row(week_date=to_date("2023-01-01"), unique_brand="brand1", super_category_name="cat1", cluster="cluster1", value=100.0),
        Row(week_date=to_date("2023-01-08"), unique_brand="brand1", super_category_name="cat1", cluster="cluster1", value=110.0),
    ]
    input_df = spark_session.createDataFrame(data, schema=FeaturePrioritisation.sales_schema)
    result_df = identify_peaks_and_dips_std_by_group(input_df, "value", "peak_dummy", "dip_dummy", "set_3", ["unique_brand", "super_category_name", "cluster"])

    expected_data = [
        Row(week_date=to_date("2023-01-01"), unique_brand="brand1", super_category_name="cat1", cluster="cluster1", value=100.0, peak_dummy=0, dip_dummy=0),
        Row(week_date=to_date("2023-01-08"), unique_brand="brand1", super_category_name="cat1", cluster="cluster1", value=110.0, peak_dummy=0, dip_dummy=0),
    ]
    expected_df = spark_session.createDataFrame(expected_data, schema=result_df.schema)

    assert_df_equality(result_df, expected_df)


@pytest.mark.usefixtures("spark_session")
def test_list_independent_ext_factors(spark_session):
    data = [
        Row(variable="type1", marketing_type="type1", metric="metric1"),
        Row(variable="type2", marketing_type="type2", metric="metric2"),
    ]
    input_df = spark_session.createDataFrame(data, schema=FeaturePrioritisation.list_independent_ext_factors_schema)
    result_df = list_independent_ext_factors(input_df, fp_config_mock)

    expected_data = [
        Row(variable="type1"),
        Row(variable="type2"),
    ]
    expected_df = spark_session.createDataFrame(expected_data, schema=result_df.schema)
    assert_df_equality(result_df, expected_df)


@pytest.mark.usefixtures("spark_session")
def test_melt_dataframe(spark_session):
    data = [
        Row(date=to_date("2023-01-01"), group_key="group1", col1=100, col2=200),
        Row(date=to_date("2023-01-08"), group_key="group1", col1=110, col2=210),
    ]
    input_df = spark_session.createDataFrame(data, schema=FeaturePrioritisation.melt_test_schema)
    result_df = melt_dataframe(input_df)

    expected_data = [
        Row(date=to_date("2023-01-01"), group_key="group1", variable="col1", value=100),
        Row(date=to_date("2023-01-01"), group_key="group1", variable="col2", value=200),
        Row(date=to_date("2023-01-08"), group_key="group1", variable="col1", value=110),
        Row(date=to_date("2023-01-08"), group_key="group1", variable="col2", value=210),
    ]
    expected_df = spark_session.createDataFrame(expected_data, schema=result_df.schema)
    assert_df_equality(result_df, expected_df)
