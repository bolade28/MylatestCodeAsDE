from datetime import date
from tempfile import mkdtemp
import shutil
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest
from mockito import when, ANY, mock, unstub
from pyspark.sql import SparkSession

from spark_pipeline.utils import slack_utils

# Constants for patching validation checks (patch where they're imported, not original module)
CHECK_0 = "spark_pipeline.metrics.publish_mta_validation.publish_user_journey_validation_metric"
CHECK_1 = "spark_pipeline.metrics.publish_mta_validation.validate_and_publish_metrics"
CHECK_2 = "spark_pipeline.metrics.publish_mta_validation.check_normalized_weight_distribution"
CHECK_3 = "spark_pipeline.metrics.publish_mta_validation.check_channel_sales_ratio"
CHECK_4 = "spark_pipeline.metrics.publish_mta_validation.media_spend_check"
CHECK_5 = "spark_pipeline.metrics.publish_mta_validation.check_channel_contribution_distribution"
CHECK_6 = "spark_pipeline.metrics.publish_mta_validation.check_roas_thresholds"
CHECK_7 = "spark_pipeline.metrics.publish_mta_validation.check_incremental_sales_iroas"


def _get_spark_session() -> SparkSession:
    return (
        SparkSession
        .builder
        .appName("testing")
        .master("local[2]")
        .config("spark.sql.caseSensitive", "false")  # Allow case-insensitive column matching
        .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
        .config("spark.executorEnv.PYTHONHASHSEED", 0)
        .config("spark.sql.shuffle.partitions", 1)
        .config("spark.sql.autoBroadcastJoinThreshold", -1)
        .config("spark.driver.memory", "2g")
        .config("spark.sql.session.timeZone", "Europe/London")
        .config("spark.driver.host", "localhost")
        .getOrCreate()
    )


@pytest.fixture(scope="session")
def spark_session(request):
    spark = _get_spark_session()
    request.addfinalizer(lambda: spark.stop())
    yield spark


@pytest.fixture(scope="function")
def tmp_dir():
    output_dir = mkdtemp()
    yield output_dir
    shutil.rmtree(output_dir)


@pytest.fixture(scope="function")
def stub_messenger():
    mock_messenger = mock()
    when(slack_utils).SlackMessenger(ANY, ANY).thenReturn(mock_messenger)
    yield mock_messenger
    unstub()


@pytest.fixture(scope="module")
def run_date_fixture():
    return date(2021, 1, 1)


@pytest.fixture(scope='function')
def aws_credentials(monkeypatch):
    """Mocked AWS Credentials for moto."""
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "testing")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "testing")
    monkeypatch.setenv("AWS_SECURITY_TOKEN", "testing")
    monkeypatch.setenv("AWS_SESSION_TOKEN", "testing")
    monkeypatch.setenv("AWS_DEFAULT_REGION", "us-east-1")


@pytest.fixture
def mock_spark():
    """
    Mock SparkSession with pre-configured dataframe chains for S3 reads.
    Returns: spark mock, measurement_campaign_reporting_df mock, selected_measurement_df mock
    """
    spark = Mock()
    attribution_df = Mock()
    measurement_campaign_reporting_df = Mock()
    attribution_selected = Mock()
    measurement_campaign_reporting_selected = Mock()

    attribution_df.select.return_value = attribution_selected
    attribution_selected.filter.return_value = attribution_selected
    attribution_selected.cache.return_value = attribution_selected

    measurement_campaign_reporting_df.select.return_value = measurement_campaign_reporting_selected
    measurement_campaign_reporting_selected.cache.return_value = measurement_campaign_reporting_selected

    spark.read.parquet.side_effect = [
        attribution_df,
        measurement_campaign_reporting_df,
        Mock(),  # unified_campaign_df (for incremental_sales_iroas_df join)
        Mock(),  # brand_journey_df
        Mock(),  # offer_journey_df
        Mock(),  # second read of measurement_campaign_reporting (incremental_sales_iroas_df)
        Mock(),  # unified_campaign parquet read inside join
    ]
    return spark, measurement_campaign_reporting_df, measurement_campaign_reporting_selected


@pytest.fixture
def all_checks_patched():
    with (
        patch(CHECK_0, return_value=0) as m0,
        patch(CHECK_1, return_value=0) as m1,
        patch(CHECK_2, return_value=0) as m2,
        patch(CHECK_3, return_value=0) as m3,
        patch(CHECK_4, return_value=0) as m4,
        patch(CHECK_5, return_value=0) as m5,
        patch(CHECK_6, return_value=0) as m6,
        patch(CHECK_7, return_value=0) as m7,
        patch("spark_pipeline.metrics.publish_mta_validation.get_stdout_logger") as ml,
        patch("spark_pipeline.metrics.publish_mta_validation.SlackMessenger") as ms,
        patch("spark_pipeline.metrics.publish_mta_validation.F.broadcast", side_effect=lambda df: df),
    ):
        yield SimpleNamespace(c0=m0, c1=m1, c2=m2, c3=m3, c4=m4, c5=m5, c6=m6, c7=m7, logger=ml, slack=ms)


@pytest.fixture
def campaign_details_mocks():
    """
    Fixture that patches dependencies for publish_pipeline_summary tests.
    Eliminates need for @mock.patch decorators in test functions.
    Returns namespace with: logger, slack_messenger, metrics_publisher,
    load_parquet_dataset, input_summary
    """
    with (
        patch("spark_pipeline.metrics.publish_pipeline_summary.get_stdout_logger") as mock_logger,
        patch("spark_pipeline.metrics.publish_pipeline_summary.SlackMessenger") as mock_slack,
        patch("spark_pipeline.metrics.publish_pipeline_summary.MetricsPublisher") as mock_publisher,
        patch("spark_pipeline.metrics.publish_pipeline_summary.load_parquet_dataset") as mock_load_parquet_dataset,
        patch("spark_pipeline.metrics.publish_pipeline_summary.input_layer_summary") as mock_input_summary,
    ):
        yield SimpleNamespace(
            logger=mock_logger,
            slack_messenger=mock_slack,
            metrics_publisher=mock_publisher,
            load_parquet_dataset=mock_load_parquet_dataset,
            input_summary=mock_input_summary,
        )
