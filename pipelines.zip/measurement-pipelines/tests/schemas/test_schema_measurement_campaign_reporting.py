from pyspark.sql import types as T


class McrCombineBaselineMtaMockData:
    """Projected input schemas for combine_baseline_mta tests."""

    PRE_MTA = T.StructType([
        T.StructField("journey_type", T.StringType()),
        T.StructField("userjourney_id", T.StringType()),
        T.StructField("loyalty_id", T.StringType()),
        T.StructField("booking_id", T.StringType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("campaign_id", T.StringType()),
        T.StructField("campaign_duration", T.StringType()),
        T.StructField("event_name", T.StringType()),
        T.StructField("transaction_key", T.StringType()),
        T.StructField("isconversion", T.IntegerType()),
    ])

    SLAS = T.StructType([
        T.StructField("journey_type", T.StringType()),
        T.StructField("userjourney_id", T.StringType()),
        T.StructField("booking_id", T.StringType()),
        T.StructField("marketing_type", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("campaign_id", T.StringType()),
        T.StructField("campaign_duration", T.StringType()),
        T.StructField("recalibration_factor", T.DoubleType()),
        T.StructField("attributed_recalibrated_units_qty", T.DoubleType()),
        T.StructField("attributed_units_qty", T.DoubleType()),
        T.StructField("attributed_recalibrated_sales_amt", T.DoubleType()),
        T.StructField("attributed_sales_amt", T.DoubleType()),
        T.StructField("isconversion", T.IntegerType()),
        T.StructField("normalized_weights", T.DoubleType()),
    ])

    CME = T.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("campaign_id", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("campaign_start_dt", T.TimestampType()),
        T.StructField("campaign_end_dt", T.TimestampType()),
        T.StructField("overlapping_campaign_flag", T.BooleanType()),
    ])

    IC = T.StructType([
        T.StructField("unique_brand_name", T.StringType()),
        T.StructField("super_category_name", T.StringType()),
        T.StructField("sub_category_name", T.StringType()),
        T.StructField("metric_name", T.StringType()),
        T.StructField("metric_value", T.DoubleType()),
    ])

    BP = T.StructType([
        T.StructField("week_start_dt", T.TimestampType()),
        T.StructField("metric_name", T.StringType()),
        T.StructField("metric_value", T.DoubleType()),
    ])

    UC_POLLEN = T.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("job_bag_number", T.StringType()),
        T.StructField("campaign_id", T.StringType()),
        T.StructField("campaign_name", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("media_spend_amt", T.DoubleType()),
        T.StructField("super_category_name", T.StringType()),
        T.StructField("sub_category_name", T.StringType()),
        T.StructField("is_multi_channel", T.BooleanType()),
        T.StructField("marketing_hierarchy_cd", T.StringType()),
    ])

    UC_DTP = T.StructType([
        T.StructField("booking_id", T.StringType()),
        T.StructField("job_bag_number", T.StringType()),
        T.StructField("campaign_id", T.StringType()),
        T.StructField("campaign_name", T.StringType()),
        T.StructField("channel_name", T.StringType()),
        T.StructField("subchannel_name", T.StringType()),
        T.StructField("media_spend_amt", T.DoubleType()),
        T.StructField("super_category_name", T.StringType()),
        T.StructField("sub_category_name", T.StringType()),
        T.StructField("is_multi_channel", T.BooleanType()),
    ])
