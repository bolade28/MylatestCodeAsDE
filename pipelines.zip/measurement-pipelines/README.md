# measurement-pipelines

## Prerequisites:

- Java 8
- Python 3.11
- Python libraries (see requirements.txt and dev-requirements.txt)


## Setting up a local Python environment
To setup local Python environment, use the repository [krang-python-env](https://github.com/JSainsburyPLC/krang-python-env)

You may name your Python environment `measurement-pipelines` or choose any name you prefer. Make sure to select the Python version specified above.

After creating the environment, activate it using pyenv:

    pyenv activate measurement-pipelines

Once the environment is activated, install all project dependencies:

    make install

To ensure all unit tests run successfully, you will also need to install `libomp`:

    brew install libomp

## Python Dependencies


We use [pip-tools](https://github.com/jazzband/pip-tools) to manage our
Python dependencies. To add a new Python dependency, add the package to
requirements.in or dev-requirements.in, then run:

    make update-deps

This will update both requirements.txt and dev-requirements.txt. To install the updated dependencies, ensure your environment is activated, then run:

    make install

## PySpark Coding Standards

All PRs must follow the PySpark coding standards defined [here](https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/1891336318/PySpark+coding+standards)

These guidelines are in place to ensure consistency, maintainability, and efficiency across our data pipelines.

PRs that do not adhere to these standards may be subject to review comments or rejection. Please review the guidelines carefully before submitting your changes.

## Local build and deployment

To build measurement pipelines locally, create a file named `dev_deploy.sh` at the root of your repository.

Once the file is created, paste the following content into it:


```#!/bin/bash

PIPELINES_HASH=some_pipeline_hash

# Check if logged into AWS with measurement-dev profile
if ! aws sts get-caller-identity --profile measurement-dev &> /dev/null; then
    echo "Error: Not logged into AWS"
    echo "Please run: aws-azure-login login --profile measurement-dev --mode=gui"
    exit 1
fi

echo "AWS authentication verified for measurement-dev profile"

./deploy.sh $PIPELINES_HASH deploy

echo ""
echo "PIPELINES_HASH  "$PIPELINES_HASH
```

Ensure that `PIPELINES_HASH` does not have any spaces.
Save the file and then use your terminal to run (this needs to be done only once):

    chmod +x dev_deploy.sh

You can now deploy measurement pipelines to AWS using a custom pipeline commit hash. This allows you to test and run a specific version of the measurement pipeline.

Update the deployment script by replacing `some_pipeline_hash` with your desired pipeline commit hash.

Before running the deployment, make sure you are logged in to the AWS CLI and activated your python environment.

To run the deployment:

    ./dev_deploy

Once the deployment completes successfully, you can use this pipelines commit hash value to run your DAG via measurement-dags.

## Testing

To run local tests, first activate pyenv environment:

If your environment is named measurement-pipelines, run:

    pyenv activate measurement-pipelines

Then to run the tests, do:

    pytest -s

In case you want to run only some of the tests from command line, you can use `-k` with a pattern, e.g.:

    # runs only matching test files such as "test_step_5_kafka_producer.py" & others
    pytest -s -o "testpaths=tests" -k step_5_kafka

To get test coverage locally run:

      pip install pytest-cov
      pytest --cov-report term --cov=./ tests/

Note that due to how PySpark works locally, you might need to do:

    export SPARK_LOCAL_IP=127.0.0.1

before running the unit tests. This is due to Spark UI wanting to start
some kind of http server on some port, which it fails to do unless it knows
it's on localhost, or something.


## Using EMR Notebooks

### Snowflake


Easily connect your EMR notebook to Snowflake using the `sf_service_connector` [package](https://github.com/sainsburys-tech/sf_service_connector).


In your EMR notebook, configure your notebook's environment by running this in the first cell of your notebook:

```python
%%configure -f
  {
    "conf": {
      "spark.pyspark.python": "/usr/bin/python3.11"
    }
  }
```

This gives you access to extra packages so you don't have to install them in your notebook manually. Such as:

- boto3
- botocore
- cryptograph
- pandas
- pyarrow
- chispa
- mlflow
- scikit-learn
- statsmodels

In addition to this this also gives you access to SfConnector

You should now be able to connect to Snowflake and load data directly into your notebook.

By default, `SfConnector` uses the `WHS_PROD_UP_CUSTOMER_SNOWPARK` warehouse. You can specify a different warehouse if needed.

```python
from sf_service_connector.sql.sf_connector import SfConnector

# Connect using the default warehouse
sf = SfConnector()

# Or specify a warehouse
sf = SfConnector(warehouse="your_warehouse_name")

# Run a SQL query and get a DataFrame
sql = """
SELECT ITEM_CD, ITEM_NAME, ITEM_SHORT_NAME, SUPER_CAT_CD, SUPER_CAT_NAME
FROM db.schema.table_name
"""
df = sf.sql_to_df(sql=sql)
df.show(truncate=False)
```

### Running Your Custom Pipeline Version in EMR Notebook

When you want to test your own modifications to the pipelines repository in an EMR notebook, follow these steps:

#### Step 1: Deploy Your Custom Pipeline

First, build and deploy your custom pipeline version:

```bash
cd measurement-pipelines
./package.sh
./deploy.sh NUP-XXXX deploy  # Replace NUP-XXXX with your unique identifier
```

or use
```bash
dev_deploy.sh
```

This creates a wheel file at: `s3://measurement-dev-artefacts/pipelines/NUP-XXXX/measurement_pipelines-1.0-py3-none-any.whl`


#### Step 2: Configure Your EMR Notebook

In the **first cell** of your EMR notebook, configure the Spark session to use your custom pipeline:

```python
%%configure -f
{
    "conf": {
        "spark.pyspark.python": "/usr/bin/python3.11"
    },
    "pyFiles": ["s3://measurement-dev-artefacts/pipelines/NUP-XXXX/measurement_pipelines-1.0-py3-none-any.whl"]
}
```

**Replace `NUP-XXXX`** with your actual pipeline hash (e.g., `NUP-11722`)

> ⚠️ **Note**: The `%%configure -f` command will restart your Spark session, so run this before any other code.

#### Step 3: Import and Use Your Custom Functions

After the session restarts, you can import any functions from your custom pipeline:

```python
# Import specific functions from your pipeline
from spark_pipeline.sku_cluster_mapping.special_sku_flagging import get_easter_spike_skus
from spark_pipeline.sku_cluster_mapping.special_sku_flagging import sku_cluster_mapping

# Use your custom functions
easter_skus = get_easter_spike_skus(spark_df)
cluster_mapping = sku_cluster_mapping(spark_df)


```

#### Troubleshooting

- **Import errors**: Ensure your pipeline hash is correct and the wheel file exists in S3
- **Session issues**: Remember that `%%configure -f` restarts the session - run it first

#### Example: Complete Workflow

```python
# Cell 1: Configure with your custom pipeline
%%configure -f
{
    "conf": {
        "spark.pyspark.python": "/usr/bin/python3.11"
    },
    "pyFiles": ["s3://measurement-dev-artefacts/pipelines/NUP-11722/measurement_pipelines-1.0-py3-none-any.whl"]
}

# Cell 2: Import and test your functions
from spark_pipeline.sku_cluster_mapping.special_sku_flagging import get_easter_spike_skus

# Cell 3: Use your custom pipeline
result = get_easter_spike_skus(
    sales_data=sales_data,
    config_params=config_params,
    offer_skus,offer_skus
    )
result.show()
```

## Measurement Initiative Sizing (Copilot Skill and Agent)

- **Skill** - [.github/skills/measurement-initiative-sizing/SKILL.md](.github/skills/measurement-initiative-sizing/SKILL.md) defines how Measurement initiatives are sized: Engineering build in engineer-sprints plus an integration and validation allowance, converted to squad-sprints and a t-shirt size (XS-XL), with a separate Data Science size, elapsed delivery and confidence level.
- **Evidence** - the skill investigates `measurement-pipelines` (this repo), [measurement-dags](https://github.com/sainsburys-tech/measurement-dags) (including the SQL ingestion templates in `dags/templates/sql`), `measurement-terraform`, Jira and the NUP Confluence space, rather than estimating from Jira wording alone.
- **Agent** - [.github/agents/measurement-estimation-batch.agent.md](.github/agents/measurement-estimation-batch.agent.md) applies the skill to each initiative in a batch and publishes the results to your personal Confluence space as a `Measurement Estimation D/M/YYYY` folder with a summary page and one estimate page per initiative.
- **Prerequisites** - an Atlassian MCP server named `atlassian` in your VS Code `mcp.json`, configured for Jira and Confluence with read and write access, and a GitHub MCP server named `github` with access to the `sainsburys-tech` repositories.
- **Reruns** - each run creates a new uniquely named folder and never overwrites an earlier batch unless you explicitly ask it to update one.

### How to use the skill

Use the skill to size a single initiative. The estimate comes back in chat and nothing is published to Confluence.

1. Open Copilot Chat in VS Code and select **Agent** mode.
2. Type `/measurement-initiative-sizing` followed by the Jira key or URL, for example:

   ```
   /measurement-initiative-sizing NMEDAG-600
   ```

   If the slash command doesn't appear, type this instead:

   ```
   Use the measurement-initiative-sizing skill to estimate NMEDAG-600
   ```

3. Wait for Copilot to finish investigating; it replies with the full estimate.

### How to use the agent

Use the agent to size several initiatives in one go and publish the results to Confluence.

- Open Copilot Chat in VS Code and select `measurement-estimation-batch` from the agent picker.
- Give it Jira keys, Jira URLs or a planning page, and optionally a batch name, for example: `Estimate the JPDs listed on NMEDAG-600 and NMEDAG-83. Name this batch "Q2 Planning"`.
- The agent runs the skill for each initiative, creates a `Measurement Estimation D/M/YYYY` folder in your personal Confluence space with a summary page and one page per initiative, and shows the summary table in chat.
