#! /usr/bin/env bash

set -e

# should already be installed by bootstrap action 1 so this should be not needed
while true; do
  sudo yum install -y git && \
  break;
done

aws s3 cp "$1" .

while true; do
  sudo pip-3.11 install -r requirements.txt && \
  break;
done
