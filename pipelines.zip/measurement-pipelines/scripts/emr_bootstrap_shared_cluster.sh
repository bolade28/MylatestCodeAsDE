#! /usr/bin/env bash

# assigns a value of latest to PIPELINES_VERSION if no argument is provided
PIPELINES_VERSION="${1:-latest}"

set -e

# should already be installed by bootstrap action 1 so this should be not needed
while true; do
  sudo yum install -y git && \
  break;
done

aws s3 cp s3://measurement-dev-artefacts/pipelines/${PIPELINES_VERSION}/requirements.txt .
aws s3 cp s3://measurement-dev-artefacts/pipelines/${PIPELINES_VERSION}/measurement_pipelines-1.0-py3-none-any.whl ./
aws s3 cp s3://measurement-dev-artefacts/shared-cluster/sf_service_connector-1.3.5-py3-none-any.whl ./

while true; do
  sudo pip-3.11 install -r requirements.txt && \
  sudo pip-3.11 install ./sf_service_connector-1.3.5-py3-none-any.whl && \
  sudo pip-3.11 install boto3 && \
  sudo pip-3.11 install botocore && \
  sudo pip-3.11 install cryptography && \
  sudo pip-3.11 install pandas && \
  sudo pip-3.11 install pyarrow && \
  sudo pip-3.11 install chispa==0.11.1 && \
  sudo pip-3.11 install mlflow==3.1.4 && \
  sudo pip-3.11 install scikit-learn==1.7.1 && \
  sudo pip-3.11 install statsmodels==0.14.5 && \
  break;
done
