#!/bin/bash

# $1: the cron specified time to execute the aws emr terminate-clusters command, e.g. "0 21 * * *" at 9pm any day
# only installs this cronjob on master node - we only need to make one api call using the aws s3 cli
if grep isMaster /mnt/var/lib/info/instance.json | grep false;
then
    echo "This is not master node,exiting"
    exit 0
fi
echo "This is master, continuing to execute script"

# The cluster id seems to get updated if this command executes too quickly
# e.g. this command put a value of
# j-2F2UXTMYKWP9O for the cluster id but the cluster was actually called
# j-3F2UXTMYKWP9O on the console

sleep 60

clusterId=$(cat /mnt/var/lib/info/job-flow.json | jq -r ".jobFlowId")
sudo tee -a /etc/crontab >/dev/null <<<"$1 hadoop /usr/local/bin/aws emr terminate-clusters --cluster-ids $clusterId >/tmp/terminate-cluster-request.log 2>&1"
