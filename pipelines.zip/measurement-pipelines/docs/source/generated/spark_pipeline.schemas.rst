spark\_pipeline.schemas package
===============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   spark_pipeline.schemas.baseline_attribution_integration
   spark_pipeline.schemas.baseline_processed_data

Submodules
----------

spark\_pipeline.schemas.attribution\_model\_dataset module
----------------------------------------------------------

.. automodule:: spark_pipeline.schemas.attribution_model_dataset
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.attribution\_pre\_requisite module
----------------------------------------------------------

.. automodule:: spark_pipeline.schemas.attribution_pre_requisite
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.baseline\_attribution\_integration\_sku\_level module
-----------------------------------------------------------------------------

.. automodule:: spark_pipeline.schemas.baseline_attribution_integration_sku_level
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.baseline\_modelling\_dataset module
-----------------------------------------------------------

.. automodule:: spark_pipeline.schemas.baseline_modelling_dataset
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.baseline\_modelling\_output\_ucm module
---------------------------------------------------------------

.. automodule:: spark_pipeline.schemas.baseline_modelling_output_ucm
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.baseline\_modelling\_shrinkage module
-------------------------------------------------------------

.. automodule:: spark_pipeline.schemas.baseline_modelling_shrinkage
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.campaign\_decay\_rate module
----------------------------------------------------

.. automodule:: spark_pipeline.schemas.campaign_decay_rate
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.campaign\_product\_type module
------------------------------------------------------

.. automodule:: spark_pipeline.schemas.campaign_product_type
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.campaign\_selection module
--------------------------------------------------

.. automodule:: spark_pipeline.schemas.campaign_selection
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.customer\_data\_collection module
---------------------------------------------------------

.. automodule:: spark_pipeline.schemas.customer_data_collection
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.etl module
----------------------------------

.. automodule:: spark_pipeline.schemas.etl
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.feature\_prioritisation module
------------------------------------------------------

.. automodule:: spark_pipeline.schemas.feature_prioritisation
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.measurement\_campaign\_reporting module
---------------------------------------------------------------

.. automodule:: spark_pipeline.schemas.measurement_campaign_reporting
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.mta\_attribution\_model module
------------------------------------------------------

.. automodule:: spark_pipeline.schemas.mta_attribution_model
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.new\_launch\_estimation\_sch module
-----------------------------------------------------------

.. automodule:: spark_pipeline.schemas.new_launch_estimation_sch
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.previous\_baseline\_modelling\_output module
--------------------------------------------------------------------

.. automodule:: spark_pipeline.schemas.previous_baseline_modelling_output
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.previous\_sku\_cluster\_mapping module
--------------------------------------------------------------

.. automodule:: spark_pipeline.schemas.previous_sku_cluster_mapping
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.reach\_engagement module
------------------------------------------------

.. automodule:: spark_pipeline.schemas.reach_engagement
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.refactoring module
------------------------------------------

.. automodule:: spark_pipeline.schemas.refactoring
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.sales\_data\_transaction module
-------------------------------------------------------

.. automodule:: spark_pipeline.schemas.sales_data_transaction
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.sku\_cluster\_mapping module
----------------------------------------------------

.. automodule:: spark_pipeline.schemas.sku_cluster_mapping
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.sku\_level\_attribution module
------------------------------------------------------

.. automodule:: spark_pipeline.schemas.sku_level_attribution
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.three\_letter\_coding module
----------------------------------------------------

.. automodule:: spark_pipeline.schemas.three_letter_coding
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.user\_journey module
--------------------------------------------

.. automodule:: spark_pipeline.schemas.user_journey
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.schemas.validation\_metrics\_schema module
----------------------------------------------------------

.. automodule:: spark_pipeline.schemas.validation_metrics_schema
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: spark_pipeline.schemas
   :members:
   :show-inheritance:
   :undoc-members:
