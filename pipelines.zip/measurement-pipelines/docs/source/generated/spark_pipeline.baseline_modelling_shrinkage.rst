spark\_pipeline.baseline\_modelling\_shrinkage package
======================================================

Submodules
----------

spark\_pipeline.baseline\_modelling\_shrinkage.incremental\_shrinkage module
----------------------------------------------------------------------------

.. automodule:: spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage
   :members:
   :show-inheritance:
   :undoc-members:

spark\_pipeline.baseline\_modelling\_shrinkage.incremental\_shrinkage\_helper module
------------------------------------------------------------------------------------

.. automodule:: spark_pipeline.baseline_modelling_shrinkage.incremental_shrinkage_helper
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: spark_pipeline.baseline_modelling_shrinkage
   :members:
   :show-inheritance:
   :undoc-members:
