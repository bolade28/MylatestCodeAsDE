spark\_pipeline.customer\_data\_collection package
==================================================

Submodules
----------

spark\_pipeline.customer\_data\_collection.customer\_data\_collection module
----------------------------------------------------------------------------

.. automodule:: spark_pipeline.customer_data_collection.customer_data_collection
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: spark_pipeline.customer_data_collection
   :members:
   :show-inheritance:
   :undoc-members:
