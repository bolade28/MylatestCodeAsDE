spark\_pipeline package
=======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   spark_pipeline.attribution_model_dataset
   spark_pipeline.attribution_model_results
   spark_pipeline.attribution_pre_requisite
   spark_pipeline.base_price_data
   spark_pipeline.baseline_attribution_integration
   spark_pipeline.baseline_forecasting_call
   spark_pipeline.baseline_modelling_dataset
   spark_pipeline.baseline_modelling_output_ucm
   spark_pipeline.baseline_modelling_shrinkage
   spark_pipeline.baseline_processed_data
   spark_pipeline.campaign_selection
   spark_pipeline.common
   spark_pipeline.customer_data_collection
   spark_pipeline.dv360_normalise
   spark_pipeline.extension
   spark_pipeline.fb_campaign_normalized
   spark_pipeline.feature_prioritisation
   spark_pipeline.measurement_campaign_reporting
   spark_pipeline.metrics
   spark_pipeline.reach_engagement
   spark_pipeline.schemas
   spark_pipeline.sku_cluster_mapping
   spark_pipeline.sku_level_attribution
   spark_pipeline.three_letter_coding
   spark_pipeline.user_journey
   spark_pipeline.utils
   spark_pipeline.youtube_normalise

Module contents
---------------

.. automodule:: spark_pipeline
   :members:
   :show-inheritance:
   :undoc-members:
