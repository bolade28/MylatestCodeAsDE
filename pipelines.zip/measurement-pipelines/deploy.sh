#!/bin/bash

# Manually deploys packaged measurement pipelines code to S3.
# Example: './deploy.sh kran-2021 deploy' deploys to s3://measurement-dev-artefacts/pipelines/nup-2021

set -e

BASE_PATH=s3://measurement-dev-artefacts/pipelines

DEPLOY_PATH=$BASE_PATH/$1

if [[ $# == 0 ]];
then
	echo "Usage: $0 directory deploy"
	exit 1
fi

if [[ $2 == "deploy" ]];
then
	./package.sh
	aws s3 cp ./dist/ $DEPLOY_PATH --recursive --profile measurement-dev
else
	./package.sh
	aws s3 cp ./dist/ $DEPLOY_PATH --recursive --profile measurement-dev --dryrun
	echo -e "Run '$0 $1 deploy' to deploy files to: $DEPLOY_PATH"
fi
