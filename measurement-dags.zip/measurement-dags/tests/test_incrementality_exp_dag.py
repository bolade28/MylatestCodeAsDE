import importlib
from unittest import mock


def _reload_dag():
    mod = importlib.import_module("incrementality_exp_dag")
    importlib.reload(mod)
    return mod


def _patches(platform="docker"):
    return {
        "airflow.sdk.Variable.get": mock.patch("airflow.sdk.Variable.get", return_value="dev"),
        "get_airflow_platform": mock.patch("helpers.setup.get_airflow_platform", return_value=platform),
        "load_experiments": mock.patch("helpers.experiments.load_experiments", return_value=[]),
        "exp_setup": mock.patch("task_groups.exp_setup.task_group", return_value=mock.MagicMock()),
        "start": mock.patch("task_groups.metadata_and_slack_alert.task_group_start", return_value=mock.MagicMock()),
        "end": mock.patch("task_groups.metadata_and_slack_alert.task_group_completed", return_value=mock.MagicMock()),
        "config_val": mock.patch("task_groups.exp_config_validation.config_validation", return_value=mock.MagicMock()),
        "launch": mock.patch("helpers.emr.launch_cluster", return_value=mock.MagicMock()),
        "terminate": mock.patch("helpers.emr.terminate_cluster", return_value=mock.MagicMock()),
        "cluster_id": mock.patch("helpers.xcom.get_cluster_id", return_value=mock.MagicMock()),
    }


def test_incrementality_exp_dag_import_and_instantiation():
    """Verifies incrementality_exp_dag module can be imported and DAG instantiated with expected metadata."""
    p = _patches()
    with p["airflow.sdk.Variable.get"], p["get_airflow_platform"], p["load_experiments"], \
         p["exp_setup"], p["start"], p["end"], p["config_val"], p["launch"], p["terminate"], p["cluster_id"]:
        mod = _reload_dag()
        dag = mod.incrementality_exp_dag()

    assert hasattr(mod, "incrementality_exp_dag")
    assert callable(mod.incrementality_exp_dag)
    assert dag.dag_id == "incrementality_exp_dag"
    assert dag.schedule is None


def test_incrementality_exp_dag_skips_when_not_docker():
    """Verifies setup task group is NOT called when not running on Docker platform."""
    p = _patches(platform="ec2")
    with p["airflow.sdk.Variable.get"], p["get_airflow_platform"], p["load_experiments"], \
         p["exp_setup"] as mock_setup, p["start"], p["end"], p["config_val"], p["launch"], p["terminate"], p["cluster_id"]:
        mod = _reload_dag()
        mod.incrementality_exp_dag()

    # When not on Docker, the DAG returns early — exp_setup should never be called
    mock_setup.assert_not_called()


def test_incrementality_exp_dag_loads_experiments():
    """Verifies experiments are loaded from the expected config file path."""
    p = _patches()
    with p["airflow.sdk.Variable.get"], p["get_airflow_platform"], p["load_experiments"] as mock_load, \
         p["exp_setup"], p["start"], p["end"], p["config_val"], p["launch"], p["terminate"], p["cluster_id"]:
        mod = _reload_dag()
        mod.incrementality_exp_dag()

    mock_load.assert_any_call("trials/incrementality_experiments.json")
    assert mock_load.call_count >= 1


def test_incrementality_exp_dag_has_pipelines_hash_param():
    """Verifies DAG exposes the pipelines_hash param."""
    p = _patches()
    with p["airflow.sdk.Variable.get"], p["get_airflow_platform"], p["load_experiments"], \
         p["exp_setup"], p["start"], p["end"], p["config_val"], p["launch"], p["terminate"], p["cluster_id"]:
        mod = _reload_dag()
        dag = mod.incrementality_exp_dag()

    assert "pipelines_hash" in dag.params
