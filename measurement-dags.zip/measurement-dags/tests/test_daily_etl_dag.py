import importlib
from unittest import mock


def test_daily_etl_dag_import_and_instantiation():
    """Verifies daily ETL DAG module can be imported and DAG instantiated with expected metadata."""
    # Arrange
    with mock.patch("task_groups.daily_etl_setup.task_group", return_value=mock.MagicMock()) as mock_setup, mock.patch(
        "task_groups.daily_etl_operations.task_group",
        return_value=mock.MagicMock(),
    ) as mock_ops:
        # Act: import/reload module and instantiate DAG factory output.
        mod = importlib.import_module("daily_etl_dag")
        importlib.reload(mod)
        dag = mod.daily_etl_dag()

    # Assert: verify factory contract, DAG metadata, and dependent task-group invocation.
    assert hasattr(mod, "daily_etl_dag")
    assert callable(mod.daily_etl_dag)
    assert dag.dag_id == "daily_etl_dag"
    assert dag.catchup is False
    assert "daily_etl" in dag.tags
    assert mock_setup.call_count >= 1
    assert mock_ops.call_count >= 1
