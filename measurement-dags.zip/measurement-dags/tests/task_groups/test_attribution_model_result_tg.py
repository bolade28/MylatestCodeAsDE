"""Tests for attribution_model_result task group.

This test suite verifies the behavior of the attribution_model_result task group,
including task group assembly, branching logic, and trigger rules.
"""

from unittest import mock
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE


def test_attribution_model_result_task_group_returns_task_group(test_dag):
    """Verifies model_result task group is created with the expected group id."""
    # Arrange: mock result step factory and run type
    with mock.patch("task_groups.attribution_model_result.attribution_model_results"), \
         mock.patch("task_groups.attribution_model_result.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_result

        # Act: create task group
        tg = attribution_model_result.task_group()

        # Assert: verify task group properties
        assert tg is not None
        assert tg.group_id == "model_result"


def test_attribution_model_result_creates_all_four_tasks(test_dag):
    """Verifies four result tasks are created for DTP and Pollen offer/brand paths."""
    # Arrange: mock result step factory
    with mock.patch("task_groups.attribution_model_result.attribution_model_results") as mock_amr, \
         mock.patch("task_groups.attribution_model_result.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_result

        # Act: create task group
        attribution_model_result.task_group()

        # Assert: verify four tasks are created
        assert mock_amr.tasks.call_count == 4


def test_attribution_model_result_journey_types(test_dag):
    """Verifies task definitions include both DTP and Pollen pipeline run types."""
    # Arrange: mock result step factory
    with mock.patch("task_groups.attribution_model_result.attribution_model_results") as mock_amr, \
         mock.patch("task_groups.attribution_model_result.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_result

        # Act: create task group
        attribution_model_result.task_group()

        # Assert: verify both run types are represented
        calls = mock_amr.tasks.call_args_list
        # Extract pipeline_run_type from kwargs if present, otherwise from second positional arg
        run_types = [c.kwargs.get("pipeline_run_type") or (c.args[1] if len(c.args) > 1 else None) for c in calls]

        assert DTP_RUN_TYPE in run_types
        assert POLLEN_RUN_TYPE in run_types


def test_attribution_model_result_finish_trigger_rule(test_dag):
    """Verifies finish operator uses NONE_FAILED_MIN_ONE_SUCCESS trigger rule."""
    # Arrange: mock result step factory
    with mock.patch("task_groups.attribution_model_result.attribution_model_results"), \
         mock.patch("task_groups.attribution_model_result.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_result

        # Act: create task group
        tg = attribution_model_result.task_group()

        # Assert: verify finish task trigger rule
        finish_task = [t for t in tg if "finish" in t.task_id]
        assert len(finish_task) >= 1
        assert finish_task[0].trigger_rule == TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS


def test_attribution_model_result_invalid_pipeline_type_handling(test_dag):
    """Verifies branch operator handles unexpected pipeline type gracefully."""
    # Arrange: mock with invalid pipeline type
    with mock.patch("task_groups.attribution_model_result.attribution_model_results"), \
         mock.patch("task_groups.attribution_model_result.pipeline_run_type", return_value="UNKNOWN_TYPE"), \
         mock.patch("task_groups.attribution_model_result.decide_pollen_dtp") as mock_decide:

        mock_decide.return_value = None

        from task_groups import attribution_model_result

        # Act: create task group with invalid type
        tg = attribution_model_result.task_group()

        # Assert: task group still constructs successfully
        assert tg is not None
        assert tg.group_id == "model_result"


def test_attribution_model_result_total_task_count(test_dag):
    """Verifies the task group contains all expected control and data tasks."""
    # Arrange: mock result step factory
    with mock.patch("task_groups.attribution_model_result.attribution_model_results"), \
         mock.patch("task_groups.attribution_model_result.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_result

        # Act: create task group
        tg = attribution_model_result.task_group()

        # Assert: verify minimum task count
        task_count = len(list(tg))
        assert task_count >= 3
