from unittest.mock import patch

import pendulum
import pytest
from airflow import DAG


@pytest.fixture(autouse=True)
def mock_get_environment():
    """Auto-mocked environment for all task group tests."""
    with patch("task_groups.slack_alert.get_environment", return_value="dev"), \
         patch("task_groups.validation_tasks.validation_slack_alerts.get_environment", return_value="dev"):
        yield


@pytest.fixture
def test_dag():
    """Provides a standard DAG context for all task group tests."""
    dag = DAG("test_dag", schedule=None, start_date=pendulum.datetime(2024, 1, 1))
    with dag:
        yield dag
