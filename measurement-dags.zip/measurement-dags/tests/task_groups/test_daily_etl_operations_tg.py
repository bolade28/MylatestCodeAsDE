from unittest import mock

import pendulum
import pytest
from airflow import DAG
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator

from helpers.constants import DEV, PROD
from task_groups import daily_etl_operations


def test_post_campaign_period_branch_operator_contract(test_dag):
    """Verifies post-campaign-period TaskGroup configures expected branch operator and arguments."""
    # Arrange
    with mock.patch(
        "task_groups.daily_etl_operations.MeasurementSnowflakeOperator",
        side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=test_dag),
    ), mock.patch(
        "task_groups.daily_etl_operations.get_table",
        return_value="table::post_campaign_period",
    ), mock.patch(
        "task_groups.daily_etl_operations.get_ci",
        return_value="ci-1",
    ):
        # Act: build only the post-campaign-period task group with deterministic dependencies.
        tg = daily_etl_operations.post_campaign_period()

    # Assert: verify branch operator type and templated branch inputs.
    assert tg.group_id == "post_campaign_period"
    tasks_by_id = {task.task_id: task for task in tg}
    branch_task = tasks_by_id["post_campaign_period.do_post_campaign_period_or_not"]
    assert isinstance(branch_task, BranchPythonOperator)
    assert branch_task.op_args == ["{{ data_interval_end | ds }}", "table::post_campaign_period"]


def test_do_post_campaign_period_or_not_branches_correctly():
    """Verifies post-campaign branch callable returns the correct downstream task id for true/false outcomes."""
    # Arrange
    with mock.patch("task_groups.daily_etl_operations.check_if_we_should_run_post_campaign_period", return_value=True):
        # Act
        result = daily_etl_operations._do_post_campaign_period_or_not("2026-01-01", "post_campaign_period")

    # Assert
    assert (
        result == "daily_etl.unified_campaign.unified_campaign_prereq.post_campaign_period.run_post_campaign_period_sql"
    )

    # Arrange
    with mock.patch("task_groups.daily_etl_operations.check_if_we_should_run_post_campaign_period", return_value=False):
        # Act
        result = daily_etl_operations._do_post_campaign_period_or_not("2026-01-01", "post_campaign_period")

    # Assert
    assert result == "daily_etl.unified_campaign.unified_campaign_prereq.post_campaign_period.skip"


def test_daily_etl_task_group_constructs_with_stubbed_operators(test_dag):
    """Verifies daily ETL task group structure and key dependencies with lightweight real operators."""
    # Arrange
    model_dates = {
        "start_date": "2023-01-01",
        "end_date": "2023-12-31",
    }
    tables = {
        "measurement_unified_campaign_pollen_daily_etl": "table::measurement_unified_campaign_pollen_daily_etl",
        "measurement_unified_campaign_pollen_prod_evaluation": "table::measurement_unified_campaign_pollen_prod_evaluation",
        "measurement_unified_campaign_pollen_test_booking_prod": "table::measurement_unified_campaign_pollen_test_booking_prod",
    }

    with mock.patch(
        "task_groups.daily_etl_operations.MeasurementSnowflakeOperator",
        side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=test_dag),
    ), mock.patch(
        "task_groups.daily_etl_operations.EmptyOperator",
        side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=test_dag),
    ), mock.patch(
        "task_groups.daily_etl_operations.BranchPythonOperator",
        side_effect=lambda **kw: BranchPythonOperator(task_id=kw["task_id"], python_callable=kw["python_callable"], op_args=kw.get("op_args", []), dag=test_dag),
    ), mock.patch(
        "task_groups.daily_etl_operations.unified_campaign",
        return_value=EmptyOperator(task_id="unified_campaign", dag=test_dag),
    ), mock.patch(
        "task_groups.daily_etl_operations.legacy_brand_registry_alert.task_group",
        return_value=EmptyOperator(task_id="legacy_brand_registry_alert", dag=test_dag),
    ), mock.patch(
        "task_groups.daily_etl_operations.get_environment",
        return_value=DEV,
    ), mock.patch(
        "task_groups.daily_etl_operations.get_ci",
        return_value="ci-1",
    ), mock.patch(
        "task_groups.daily_etl_operations.get_model_start_end_dates",
        side_effect=lambda key: model_dates[key],
    ), mock.patch(
        "task_groups.daily_etl_operations.get_table",
        side_effect=lambda key: tables[key],
    ):
        # Act: build the full daily_etl task group with patched heavy dependencies.
        tg = daily_etl_operations.task_group()

    # Assert: task group should be created successfully with expected id and key task wiring.
    assert tg.group_id == "daily_etl"
    tasks_by_id = {task.task_id: task for task in tg}
    assert "daily_etl.create_campaign_product_type" in tasks_by_id
    assert "daily_etl.create_campaign_product_type_new_brand_logic" in tasks_by_id
    assert "daily_etl.transactions_table" in tasks_by_id
    assert "daily_etl.update_run_incrementality_column" in tasks_by_id

    update_task = tasks_by_id["daily_etl.update_run_incrementality_column"]
    assert "daily_etl.create_campaign_product_type_new_brand_logic" in update_task.upstream_task_ids
    assert "daily_etl.transactions_table" in update_task.upstream_task_ids

    new_brand_logic_task = tasks_by_id["daily_etl.create_campaign_product_type_new_brand_logic"]
    assert "daily_etl.create_campaign_product_type" in new_brand_logic_task.upstream_task_ids


@pytest.mark.parametrize("environment, expected_is_prod", [(DEV, False), (PROD, True)])
def test_daily_etl_pollen_operators_pass_prod_emulation_params(environment, expected_is_prod):
    """Verifies unified campaign pollen SQL operator receives emulate/is_prod params for Jinja filtering."""
    def _build_task_group_and_collect_operator_calls(environment, dag):
        # Arrange: keep operator construction lightweight while capturing all SQL operator inputs.
        operator_calls = []

        def _operator_stub(**kwargs):
            operator_calls.append(kwargs)
            return EmptyOperator(task_id=kwargs["task_id"], dag=dag)

        model_dates = {
            "start_date": "2023-01-01",
            "end_date": "2023-12-31",
        }
        tables = {
            "measurement_unified_campaign_pollen_daily_etl": "table::measurement_unified_campaign_pollen_daily_etl",
            "measurement_unified_campaign_pollen_test_booking_prod": "table::measurement_unified_campaign_pollen_test_booking_prod",
        }

        with mock.patch(
            "task_groups.daily_etl_operations.MeasurementSnowflakeOperator",
            side_effect=_operator_stub,
        ), mock.patch(
            "task_groups.daily_etl_operations.EmptyOperator",
            side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=dag),
        ), mock.patch(
            "task_groups.daily_etl_operations.unified_campaign",
            return_value=EmptyOperator(task_id="unified_campaign", dag=dag),
        ), mock.patch(
            "task_groups.daily_etl_operations.legacy_brand_registry_alert.task_group",
            return_value=EmptyOperator(task_id="legacy_brand_registry_alert", dag=dag),
        ), mock.patch(
            "task_groups.daily_etl_operations.get_environment",
            return_value=environment,
        ), mock.patch(
            "task_groups.daily_etl_operations.get_ci",
            return_value="ci-1",
        ), mock.patch(
            "task_groups.daily_etl_operations.get_model_start_end_dates",
            side_effect=lambda key: model_dates[key],
        ), mock.patch(
            "task_groups.daily_etl_operations.get_table",
            side_effect=lambda key: tables[key],
        ):
            with dag:
                # Act
                daily_etl_operations.task_group()

        return {call["task_id"]: call for call in operator_calls}

    # Arrange + Act: build task group with specified environment and capture operator calls.
    scenario_dag = DAG(
        dag_id=f"test_daily_etl_{environment.lower()}",
        schedule=None,
        start_date=pendulum.datetime(2024, 1, 1),
    )
    by_task_id = _build_task_group_and_collect_operator_calls(environment, scenario_dag)

    # Assert: verify params are set correctly for this environment.
    assert "load_unified_campaign_pollen" in by_task_id, f"tasks found: {list(by_task_id)}"
    daily_task = by_task_id["load_unified_campaign_pollen"]
    assert daily_task["sql"] == "unified_campaign/unified_campaign_pollen_insert.sql"
    assert daily_task["params"]["table"] == "table::measurement_unified_campaign_pollen_daily_etl"
    assert daily_task["params"]["emulate_prod_env"] is False
    assert daily_task["params"]["is_prod"] is expected_is_prod


@pytest.mark.parametrize("environment, expect_linked", [(DEV, True), (PROD, False)])
def test_daily_etl_pollen_prod_test_bookings_dependency_is_dev_only(environment, expect_linked, test_dag):
    """Verifies prod-test-bookings task is only linked in dependency chain for non-prod environments."""

    # Arrange
    model_dates = {
        "start_date": "2023-01-01",
        "end_date": "2023-12-31",
    }
    tables = {
        "measurement_unified_campaign_pollen_daily_etl": "table::measurement_unified_campaign_pollen_daily_etl",
        "measurement_unified_campaign_pollen_test_booking_prod": "table::measurement_unified_campaign_pollen_test_booking_prod",
    }

    with mock.patch(
        "task_groups.daily_etl_operations.MeasurementSnowflakeOperator",
        side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=test_dag),
    ), mock.patch(
        "task_groups.daily_etl_operations.EmptyOperator",
        side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=test_dag),
    ), mock.patch(
        "task_groups.daily_etl_operations.unified_campaign",
        return_value=EmptyOperator(task_id="unified_campaign", dag=test_dag),
    ), mock.patch(
        "task_groups.daily_etl_operations.legacy_brand_registry_alert.task_group",
        return_value=EmptyOperator(task_id="legacy_brand_registry_alert", dag=test_dag),
    ), mock.patch(
        "task_groups.daily_etl_operations.get_environment",
        return_value=environment,
    ), mock.patch(
        "task_groups.daily_etl_operations.get_ci",
        return_value="ci-1",
    ), mock.patch(
        "task_groups.daily_etl_operations.get_model_start_end_dates",
        side_effect=lambda key: model_dates[key],
    ), mock.patch(
        "task_groups.daily_etl_operations.get_table",
        side_effect=lambda key: tables[key],
    ):
        # Act
        tg = daily_etl_operations.task_group()

    # Assert
    assert tg.group_id == "daily_etl"
    tasks_by_id = {task.task_id: task for task in tg}
    campaign_product_type_task_id = "daily_etl.create_campaign_product_type"
    campaign_product_type = tasks_by_id[campaign_product_type_task_id]
    has_prod_test_merge_upstream = any(
        "merge_unified_campaign_pollen_prod_test_bookings" in task_id
        for task_id in campaign_product_type.upstream_task_ids
    )

    if expect_linked:
        assert has_prod_test_merge_upstream
    else:
        assert not has_prod_test_merge_upstream
