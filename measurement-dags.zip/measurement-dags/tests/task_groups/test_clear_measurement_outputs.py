from unittest.mock import patch

from task_groups import clear_measurement_outputs
from helpers.constants import DAGSMetrics, DeploymentStatus
from helpers.metrics import publish_metric_update, WriteOperation


def test_task_group_contains_delete_and_metadata_tasks(test_dag):
    """Verify task-group construction and the unconditional deletion dependency chain."""
    with patch("airflow.sdk.Variable.get", return_value="dev"):
        task_group = clear_measurement_outputs.task_group()

    task_ids = {task.task_id for task in task_group}
    assert task_ids == {
        "remove_measurement_outputs.remove_measurement_outputs",
        "remove_measurement_outputs.update_metadata_snowflake",
        "remove_measurement_outputs.update_metadata_postgres",
        "remove_measurement_outputs.deletion_alert",
    }

    remove_outputs = next(
        task for task in task_group
        if task.task_id == "remove_measurement_outputs.remove_measurement_outputs"
    )
    update_metadata_snowflake = next(
        task for task in task_group
        if task.task_id == "remove_measurement_outputs.update_metadata_snowflake"
    )
    update_metadata_postgres = next(
        task for task in task_group
        if task.task_id == "remove_measurement_outputs.update_metadata_postgres"
    )
    deletion_alert = next(
        task for task in task_group
        if task.task_id == "remove_measurement_outputs.deletion_alert"
    )
    assert update_metadata_snowflake in remove_outputs.downstream_list
    assert update_metadata_postgres in update_metadata_snowflake.downstream_list
    assert deletion_alert in update_metadata_postgres.downstream_list


def test_update_metadata_postgres_patches_deployment_status(test_dag):
    """Verify the postgres update task targets pipelines_metadata with deployment_status=deleted."""
    with patch("airflow.sdk.Variable.get", return_value="dev"):
        task_group = clear_measurement_outputs.task_group()

    update_metadata_postgres = next(
        task for task in task_group
        if task.task_id == "remove_measurement_outputs.update_metadata_postgres"
    )

    assert update_metadata_postgres.op_kwargs["table_name"] == "pipelines_metadata"
    assert update_metadata_postgres.op_kwargs["name"] == DAGSMetrics.PIPELINES_METADATA.value
    assert update_metadata_postgres.op_kwargs["updates"] == {"deployment_status": DeploymentStatus.DELETED.value}


def test_publish_metric_update_emits_update_event():
    """Verify the emitted event carries the requested update and write operation."""
    with patch("helpers.metrics.SNS"), patch("helpers.metrics.MetricsPublisher") as mock_publisher_cls:
        mock_publisher = mock_publisher_cls.return_value

        publish_metric_update(
            correlation_id="cid-123",
            table_name="pipelines_metadata",
            name=DAGSMetrics.PIPELINES_METADATA.value,
            updates={"deployment_status": DeploymentStatus.DELETED.value},
        )

    event = mock_publisher.publish_to_sns.call_args.args[0]
    assert event["correlation_id"] == "cid-123"
    assert event["deployment_status"] == DeploymentStatus.DELETED.value
    assert event["event_schema"]["table_name"] == "pipelines_metadata"
    assert event["event_schema"]["write_operation"] == WriteOperation.UPDATE.value
