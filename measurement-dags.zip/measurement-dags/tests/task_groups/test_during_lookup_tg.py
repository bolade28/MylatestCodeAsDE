from unittest import mock

from airflow.providers.standard.operators.python import BranchPythonOperator

from task_groups import during_lookup


def test_task_group_resolves_ci_and_checks_brand_logic(test_dag):
    with mock.patch('airflow.sdk.Variable.get', return_value='dev'):
        task_group = during_lookup.task_group()

    task_ids = [task.task_id for task in task_group]
    assert 'brand_logic_lookup.check_brand_logic_result' in task_ids
    assert isinstance(next(task for task in task_group if task.task_id.endswith('check_brand_logic_result')), BranchPythonOperator)


def test_check_brand_logic_result_routes_to_alert_for_inconsistent_logic():
    with mock.patch('task_groups.during_lookup.check_brand_logic_consistency', return_value=False):
        result = during_lookup.check_brand_logic_result('booking-1', 'during-ci', 'metadata-table')

    assert result == 'campaign_validations_post.brand_logic_inconsistent.slack_alert_campaign_skip_brand_logic'


def test_check_brand_logic_result_routes_to_booking_validation_for_consistent_logic():
    with mock.patch('task_groups.during_lookup.check_brand_logic_consistency', return_value=True):
        result = during_lookup.check_brand_logic_result('booking-1', 'during-ci', 'metadata-table')

    assert result == 'campaign_validations_post.booking_id_validate.check_booking_id'
