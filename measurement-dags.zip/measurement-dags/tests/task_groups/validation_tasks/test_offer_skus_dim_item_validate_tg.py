from unittest import mock

from task_groups.validation_tasks import offer_skus_dim_item_validate


def test_task_group_contains_check_and_branch_tasks(test_dag):
    tg = offer_skus_dim_item_validate.task_group(parent_group_id='campaign_validations')
    task_ids = [t.task_id for t in tg]

    assert 'offer_skus_dim_item_validate.check_offer_skus_in_dim_item' in task_ids
    assert 'offer_skus_dim_item_validate.campaigns_qualification_check' in task_ids


def test_decide_to_continue_when_all_skus_exist():
    ti = mock.MagicMock()
    ti.xcom_pull.return_value = []

    result = offer_skus_dim_item_validate._decide_to_continue_or_skip(
        parent_group_id='campaign_validations',
        task_instance=ti,
    )

    assert result == 'campaign_validations.media_spend_campaign_validate.check_media_spend_data'


def test_decide_to_skip_when_sku_missing_from_dim_item():
    ti = mock.MagicMock()
    ti.xcom_pull.return_value = [('1001', '1002')]

    result = offer_skus_dim_item_validate._decide_to_continue_or_skip(
        parent_group_id='campaign_validations',
        task_instance=ti,
    )

    assert result == 'campaign_validations.campaign_skip_alert_missing_dim_item_skus.prepare_alert_message'
