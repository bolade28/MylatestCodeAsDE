from unittest import mock

from task_groups.validation_tasks import validations


def test_task_group_during_builds_expected_tasks(test_dag):
    with mock.patch("airflow.sdk.Variable.get", return_value="dev"):
        tg = validations.task_group()

    task_ids = [t.task_id for t in tg]
    assert "campaign_validations.validation_complete" in task_ids
    assert "campaign_validations.qualified_campaigns.qualified_campaigns_list" in task_ids


def test_task_group_post_builds_expected_tasks_including_brand_logic(test_dag):
    with mock.patch("airflow.sdk.Variable.get", return_value="dev"):
        tg = validations.task_group_post()

    task_ids = [t.task_id for t in tg]
    assert "campaign_validations_post.validation_complete" in task_ids
    assert "campaign_validations_post.brand_logic_lookup.check_brand_logic_result" in task_ids
    assert "campaign_validations_post.brand_logic_inconsistent.skip_pipeline" in task_ids
    assert "campaign_validations_post.booking_id_validate.check_booking_id" in task_ids
