from unittest import mock

from task_groups.validation_tasks import campaign_skip_alert_missing_dim_item_skus


def test_task_group_contains_alert_and_skip_tasks(test_dag):
    with mock.patch('airflow.sdk.Variable.get', return_value='dev'):
        tg = campaign_skip_alert_missing_dim_item_skus.task_group(parent_group_id='campaign_validations')

    assert tg.group_id == 'campaign_skip_alert_missing_dim_item_skus'
    task_ids = [t.task_id for t in tg]
    assert 'campaign_skip_alert_missing_dim_item_skus.prepare_alert_message' in task_ids
    assert 'campaign_skip_alert_missing_dim_item_skus.slack_alert_campaign_skip_missing_dim_item_skus' in task_ids
    assert 'campaign_skip_alert_missing_dim_item_skus.skip_pipeline' in task_ids


def test_get_alert_message_contains_missing_skus_and_booking_ids():
    ti = mock.MagicMock()
    correlation_id = 'ci-123'
    pipeline_hash = 'hash-123'
    booking_id = 'booking-1'
    missing_skus = ['1001', '1002']

    def xcom_pull(task_ids, key=None):
        if task_ids == 'setup_tasks.configure_correlation_id':
            return correlation_id
        if task_ids == 'setup_tasks.configure_pipelines_version':
            return pipeline_hash
        if task_ids == 'campaign_validations.offer_skus_dim_item_validate.check_offer_skus_in_dim_item':
            return [(booking_id, sku) for sku in missing_skus]
        return None

    ti.xcom_pull.side_effect = xcom_pull

    message = campaign_skip_alert_missing_dim_item_skus._get_alert_message(
        parent_group_id='campaign_validations',
        task_instance=ti,
    )

    assert message.strip().startswith(':red_circle: :owl: *Pipeline Skipped*')
    assert f'*Correlation ID:* `{correlation_id}`' in message
    assert f'*Booking IDs:* `{booking_id}`' in message
    assert f'*Pipeline Hash:* `{pipeline_hash}`' in message

    expected_missing_skus = ', '.join(f'`{sku}`' for sku in missing_skus)
    assert f'*Missing Offer SKUs:* {expected_missing_skus}' in message


def test_mark_validation_failed_pushes_xcom():
    ti = mock.MagicMock()
    campaign_skip_alert_missing_dim_item_skus._mark_validation_failed(task_instance=ti)
    ti.xcom_push.assert_called_once_with(key='validation_failed', value=True)
