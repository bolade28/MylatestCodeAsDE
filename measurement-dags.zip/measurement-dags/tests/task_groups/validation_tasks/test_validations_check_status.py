from unittest import mock

from task_groups.validation_tasks import validations


def _ti_with_markers(**markers):
    """Build a mock task_instance whose xcom_pull returns markers keyed by task_ids."""
    ti = mock.MagicMock()

    def xcom_pull(task_ids, key):
        return markers.get(task_ids)

    ti.xcom_pull.side_effect = xcom_pull
    return ti


def test_check_validation_status_continues_when_brand_logic_validation_passes():
    ti = _ti_with_markers()
    result = validations.check_validation_status(
        parent_group_id='campaign_validations_post',
        evaluation_phase='post',
        task_instance=ti,
    )
    assert result == 'start_checkpoint'


def test_check_validation_status_fails_when_brand_logic_alert_triggered():
    ti = _ti_with_markers(**{
        'campaign_validations_post.brand_logic_inconsistent.skip_pipeline': True,
    })
    result = validations.check_validation_status(
        parent_group_id='campaign_validations_post',
        evaluation_phase='post',
        task_instance=ti,
    )
    assert result == 'validation_failed'


def test_check_validation_status_ignores_brand_logic_marker_for_during_dag():
    """The brand-logic alert only exists in campaign_validations_post; during's parent_group_id must not check it."""
    ti = _ti_with_markers(**{
        'campaign_validations.brand_logic_inconsistent.skip_pipeline': True,
    })
    result = validations.check_validation_status(
        parent_group_id='campaign_validations',
        task_instance=ti,
    )
    assert result == 'start_checkpoint'
