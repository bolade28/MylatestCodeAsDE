from unittest import mock

import pytest

from helpers.constants import DTP_RUN_TYPE, FileExists, POLLEN_RUN_TYPE, PROD
from helpers.xcom import get_booking_reference_date
from task_groups.validation_tasks import config_validation


def test_config_setup_includes_booking_reference_date(test_dag):
    with mock.patch(
        "task_groups.validation_tasks.config_validation.get_environment",
        return_value="dev",
    ):
        config_validation.task_group()

    assert "config_and_validation.config_setup.configure_booking_reference_date" in test_dag.task_ids
    assert "config_and_validation.config_setup.resolve_during_correlation_id" not in test_dag.task_ids
    assert "config_and_validation.config_setup.resolve_previous_paths" not in test_dag.task_ids


def test_config_setup_post_includes_during_resolution_tasks(test_dag):
    with mock.patch(
        "task_groups.validation_tasks.config_validation.get_environment",
        return_value="dev",
    ):
        config_validation.task_group(evaluation_phase=config_validation.EvaluationPhase.POST)

    assert "config_and_validation.config_setup.resolve_during_correlation_id" in test_dag.task_ids
    assert "config_and_validation.config_setup.resolve_previous_paths" in test_dag.task_ids


def test_validate_artifact_exists_raises_when_missing():
    # Act / Assert: missing artifact should fail fast and stop pipeline setup.
    with pytest.raises(ValueError, match="Pipelines deployment not found"):
        config_validation.validate_artifact_exists.function(
            file_exists_result=FileExists.NO.value,
            pipelines_version="abc123",
            env="dev",
        )


def test_validate_artifact_exists_succeeds_when_present():
    # Act: validate artifact existence for present deployment marker.
    config_validation.validate_artifact_exists.function(
        file_exists_result=FileExists.YES.value,
        pipelines_version="abc123",
        env="dev",
    )


@pytest.mark.parametrize(
    "experiment_flag,environment",
    [
        (False, "dev"),
        (True, PROD),
    ],
)
def test_validate_existing_campaign_data_skips_in_non_experiment_or_prod(
    experiment_flag,
    environment,
):
    # Arrange: set environment/experiment combinations that should skip existing-data lookup.
    with mock.patch("task_groups.validation_tasks.config_validation.get_environment", return_value=environment), mock.patch(
        "task_groups.validation_tasks.config_validation.check_campaign_data_exists"
    ) as mock_check:
        # Act: run existing-data validation for the given scenario.
        result = config_validation.validate_existing_campaign_data.function(
            experiment_flag=experiment_flag,
            table="my_table",
            booking_id="123",
            run_type=POLLEN_RUN_TYPE,
            evaluation_phase="during",
        )

    # Assert: both scenarios should return None and avoid Snowflake lookup.
    assert result is None
    mock_check.assert_not_called()


def test_validate_existing_campaign_data_raises_when_parquet_exists():
    # Arrange: simulate existing campaign with parquet already present in S3.
    with mock.patch("task_groups.validation_tasks.config_validation.get_environment", return_value="dev"), mock.patch(
        "task_groups.validation_tasks.config_validation.check_campaign_data_exists",
        return_value="existing-cid",
    ), mock.patch(
        "task_groups.validation_tasks.config_validation.parquet_files_exist",
        return_value=True,
    ):
        # Act / Assert: existing parquet data should raise to prevent duplicate experimentation output.
        with pytest.raises(ValueError, match="Experimentation data already exists in S3"):
            config_validation.validate_existing_campaign_data.function(
                experiment_flag=True,
                table="my_table",
                booking_id="123",
                run_type=POLLEN_RUN_TYPE,
                evaluation_phase="during",
            )


def test_validate_existing_campaign_data_allows_when_existing_cid_but_no_files():
    # Arrange: simulate existing campaign id but no parquet data in S3.
    with mock.patch("task_groups.validation_tasks.config_validation.get_environment", return_value="dev"), mock.patch(
        "task_groups.validation_tasks.config_validation.check_campaign_data_exists",
        return_value="existing-cid",
    ), mock.patch(
        "task_groups.validation_tasks.config_validation.parquet_files_exist",
        return_value=False,
    ):
        # Act: run existing-data validation.
        result = config_validation.validate_existing_campaign_data.function(
            experiment_flag=True,
            table="my_table",
            booking_id="123",
            run_type=DTP_RUN_TYPE,
            evaluation_phase="during",
        )

    # Assert: stale Snowflake id without parquet should be allowed.
    assert result is None


def test_validate_existing_campaign_data_allows_when_no_existing_campaign():
    # Arrange: simulate no matching existing campaign in Snowflake.
    with mock.patch("task_groups.validation_tasks.config_validation.get_environment", return_value="dev"), mock.patch(
        "task_groups.validation_tasks.config_validation.check_campaign_data_exists",
        return_value=None,
    ), mock.patch("task_groups.validation_tasks.config_validation.parquet_files_exist") as mock_parquet:
        # Act: run existing-data validation.
        result = config_validation.validate_existing_campaign_data.function(
            experiment_flag=True,
            table="my_table",
            booking_id="123",
            run_type=POLLEN_RUN_TYPE,
            evaluation_phase="during",
        )

    # Assert: no existing data should proceed and skip parquet lookup.
    assert result is None
    mock_parquet.assert_not_called()


def test_fetch_booking_name_from_snowflake_for_pollen():
    # Arrange: mock Snowflake returning a pollen booking name.
    fake_hook = mock.Mock()
    fake_hook.get_records.return_value = [("Booking Name",)]

    with mock.patch("task_groups.validation_tasks.config_validation.SnowflakeHook", return_value=fake_hook):
        # Act: fetch booking name for pollen run.
        result = config_validation.fetch_booking_name_from_snowflake.function(
            booking_id="B1",
            run_type=POLLEN_RUN_TYPE,
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
        )

    # Assert: verify value and flexible SQL intent checks (column + predicate).
    assert result == "Booking Name"
    fake_hook.get_records.assert_called_once()
    call_args = fake_hook.get_records.call_args
    query = call_args.args[0] if call_args.args else call_args.kwargs.get("sql")
    assert query is not None
    normalized_query = " ".join(query.split()).lower()
    assert "select distinct booking_name" in normalized_query
    assert "booking_id = 'b1'" in normalized_query


def test_fetch_booking_name_from_snowflake_for_dtp():
    # Arrange: mock Snowflake returning a DTP campaign name.
    fake_hook = mock.Mock()
    fake_hook.get_records.return_value = [("Campaign Name",)]

    with mock.patch("task_groups.validation_tasks.config_validation.SnowflakeHook", return_value=fake_hook):
        # Act: fetch booking name for DTP run.
        result = config_validation.fetch_booking_name_from_snowflake.function(
            booking_id="JB1",
            run_type=DTP_RUN_TYPE,
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
        )

    # Assert: verify value and flexible SQL intent checks (column + predicate).
    assert result == "Campaign Name"
    fake_hook.get_records.assert_called_once()
    call_args = fake_hook.get_records.call_args
    query = call_args.args[0] if call_args.args else call_args.kwargs.get("sql")
    assert query is not None
    normalized_query = " ".join(query.split()).lower()
    assert "select distinct campaign_name" in normalized_query
    assert "job_bag_number = 'jb1'" in normalized_query


@pytest.mark.parametrize(
    "result_rows,expected",
    [
        ([], None),
        ([(None,)], None),
    ],
)
def test_fetch_booking_name_from_snowflake_returns_none_for_empty_or_null(result_rows, expected):
    # Arrange: simulate empty and NULL row cases from Snowflake.
    fake_hook = mock.Mock()
    fake_hook.get_records.return_value = result_rows

    with mock.patch("task_groups.validation_tasks.config_validation.SnowflakeHook", return_value=fake_hook):
        # Act: fetch booking name for pollen run.
        value = config_validation.fetch_booking_name_from_snowflake.function(
            booking_id="B1",
            run_type=POLLEN_RUN_TYPE,
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
        )

    # Assert: both edge cases should resolve to None.
    assert value is expected


def test_fetch_booking_name_from_snowflake_returns_none_for_unknown_run_type():
    # Arrange: unknown run_type should not query Snowflake.
    fake_hook = mock.Mock()
    with mock.patch("task_groups.validation_tasks.config_validation.SnowflakeHook", return_value=fake_hook):
        # Act: fetch booking name for unsupported run type.
        value = config_validation.fetch_booking_name_from_snowflake.function(
            booking_id="B1",
            run_type="unknown",
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
        )

    # Assert: unsupported run type returns None and makes no DB call.
    assert value is None
    fake_hook.get_records.assert_not_called()


def test_validate_campaign_end_date_passed_skips_in_dev():
    with mock.patch(
        "task_groups.validation_tasks.config_validation.get_environment",
        return_value="dev",
    ), mock.patch(
        "task_groups.validation_tasks.config_validation.has_campaign_ended"
    ) as mock_check:
        result = config_validation.validate_campaign_end_date_passed.function(
            table="POLLEN_TABLE",
            booking_id="booking_1",
            run_date="2026-07-06",
            evaluation_phase="during",
        )

    # Assert: dev should return None without querying Snowflake.
    assert result is None
    mock_check.assert_not_called()


def test_validate_campaign_end_date_passed_passes_when_no_future_campaigns_in_prod():
    with mock.patch(
        "task_groups.validation_tasks.config_validation.get_environment",
        return_value=PROD,
    ), mock.patch(
        "task_groups.validation_tasks.config_validation.has_campaign_ended",
        return_value=(True, ""),
    ):
        result = config_validation.validate_campaign_end_date_passed.function(
            table="POLLEN_TABLE",
            booking_id="booking_1",
            run_date="2026-07-06",
            evaluation_phase="during",
        )

    # Assert: no future campaigns should pass silently.
    assert result is None


def test_validate_campaign_end_date_passed_raises_for_future_during_campaign_in_prod():
    with mock.patch(
        "task_groups.validation_tasks.config_validation.get_environment",
        return_value=PROD,
    ), mock.patch(
        "task_groups.validation_tasks.config_validation.has_campaign_ended",
        return_value=(False, "booking_1"),
    ):
        with pytest.raises(ValueError, match="is still live"):
            config_validation.validate_campaign_end_date_passed.function(
                table="POLLEN_TABLE",
                booking_id="booking_1",
                run_date="2026-07-06",
                evaluation_phase="during",
            )


def test_validate_campaign_end_date_passed_raises_for_future_post_campaign_in_prod():
    with mock.patch(
        "task_groups.validation_tasks.config_validation.get_environment",
        return_value=PROD,
    ), mock.patch(
        "task_groups.validation_tasks.config_validation.has_campaign_ended",
        return_value=(False, "booking_1"),
    ):
        with pytest.raises(ValueError, match="is still live"):
            config_validation.validate_campaign_end_date_passed.function(
                table="POLLEN_TABLE",
                booking_id="booking_1",
                run_date="2026-07-06",
                evaluation_phase="post",
            )


def test_validate_campaign_end_date_passed_includes_booking_id_in_error():
    with mock.patch(
        "task_groups.validation_tasks.config_validation.get_environment",
        return_value=PROD,
    ), mock.patch(
        "task_groups.validation_tasks.config_validation.has_campaign_ended",
        return_value=(False, "booking_abc"),
    ):
        with pytest.raises(ValueError, match="booking_abc"):
            config_validation.validate_campaign_end_date_passed.function(
                table="POLLEN_TABLE",
                booking_id="booking_abc",
                run_date="2026-07-06",
                evaluation_phase="during",
            )


def test_validate_campaign_end_date_passed_calls_check_with_correct_args():
    with mock.patch(
        "task_groups.validation_tasks.config_validation.get_environment",
        return_value=PROD,
    ), mock.patch(
        "task_groups.validation_tasks.config_validation.has_campaign_ended",
        return_value=(True, ""),
    ) as mock_check:
        config_validation.validate_campaign_end_date_passed.function(
            table="POLLEN_TABLE",
            booking_id="booking_1",
            run_date="2026-07-06",
            evaluation_phase="during",
        )

    # Assert: helper must be called with exactly the inputs passed in.
    mock_check.assert_called_once_with(
        booking_id="booking_1",
        table="POLLEN_TABLE",
        run_date="2026-07-06",
        evaluation_phase="during",
    )


def test_validate_campaign_end_date_passed_raises_for_multiple_future_campaigns():
    with mock.patch(
        "task_groups.validation_tasks.config_validation.get_environment",
        return_value=PROD,
    ), mock.patch(
        "task_groups.validation_tasks.config_validation.has_campaign_ended",
        return_value=(False, "booking_1"),
    ):
        with pytest.raises(ValueError) as exc_info:
            config_validation.validate_campaign_end_date_passed.function(
                table="POLLEN_TABLE",
                booking_id="booking_1, booking_2",
                run_date="2026-07-06",
                evaluation_phase="during",
            )

    error_msg = str(exc_info.value)
    assert "booking_1" in error_msg


@pytest.mark.parametrize(
    "evaluation_phase,expected_label",
    [
        ("during", "is still live"),
        ("post", "is still live"),
    ],
)
def test_validate_campaign_end_date_passed_error_label_matches_phase(evaluation_phase, expected_label):
    with mock.patch(
        "task_groups.validation_tasks.config_validation.get_environment",
        return_value=PROD,
    ), mock.patch(
        "task_groups.validation_tasks.config_validation.has_campaign_ended",
        return_value=(False, "booking_1"),
    ):
        with pytest.raises(ValueError, match=expected_label):
            config_validation.validate_campaign_end_date_passed.function(
                table="POLLEN_TABLE",
                booking_id="booking_1",
                run_date="2026-07-06",
                evaluation_phase=evaluation_phase,
            )


@mock.patch("task_groups.validation_tasks.config_validation.resolve_booking_reference_date", return_value="2025-03-15")
def test_configure_booking_reference_date_normalizes_bookings_and_delegates(
    resolve_booking_reference_date: mock.MagicMock,
):
    result = config_validation.configure_booking_reference_date.function(
        booking_ids="158454025, 584245948",
        booking_table="ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR",
        run_type="Pollen",
    )

    assert result == "2025-03-15"
    resolve_booking_reference_date.assert_called_once_with(
        booking_ids=["158454025", "584245948"],
        booking_table="ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR",
        fallback_booking_table=None,
    )


@mock.patch("task_groups.validation_tasks.config_validation.resolve_booking_reference_date", return_value="2025-03-15")
def test_configure_booking_reference_date_passes_fallback_table(
    resolve_booking_reference_date: mock.MagicMock,
):
    result = config_validation.configure_booking_reference_date.function(
        booking_ids="158454025",
        booking_table="ADW_DEV.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR",
        fallback_booking_table="ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR",
        run_type="Pollen",
    )

    assert result == "2025-03-15"
    resolve_booking_reference_date.assert_called_once_with(
        booking_ids=["158454025"],
        booking_table="ADW_DEV.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR",
        fallback_booking_table="ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR",
    )


@mock.patch("task_groups.validation_tasks.config_validation.resolve_booking_reference_date")
def test_configure_booking_reference_date_skips_non_pollen_runs(resolve_booking_reference_date: mock.MagicMock):
    result = config_validation.configure_booking_reference_date.function(
        booking_ids="job-bag-1",
        booking_table="SOME_TABLE",
        run_type="DTP",
    )

    assert result is None
    resolve_booking_reference_date.assert_not_called()


def test_get_booking_reference_date_returns_jinja_template():
    result = get_booking_reference_date()

    assert "config_and_validation.config_setup.configure_booking_reference_date" in result
    assert 'task_instance.xcom_pull' in result
    assert 'key="return_value"' in result
    assert result.startswith('{%-')
    assert result.endswith('-%}')
