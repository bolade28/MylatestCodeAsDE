from unittest import mock

from task_groups.validation_tasks import campaign_skip_alert_brand_logic


def test_task_group_contains_alert_and_skip_tasks(test_dag):
    with mock.patch("airflow.sdk.Variable.get", return_value="dev"):
        tg = campaign_skip_alert_brand_logic.task_group()

    assert tg.group_id == "brand_logic_inconsistent"
    task_ids = [t.task_id for t in tg]
    assert "brand_logic_inconsistent.slack_alert_campaign_skip_brand_logic" in task_ids
    assert "brand_logic_inconsistent.skip_pipeline" in task_ids


def test_get_post_campaign_alert_message_mentions_legacy_correlation():
    message = campaign_skip_alert_brand_logic.get_post_campaign_alert_message(ci="ci-123")
    assert "ci-123" in message
    assert "legacy during_correlation_id" in message


def test_mark_validation_failed_pushes_xcom():
    ti = mock.MagicMock()
    campaign_skip_alert_brand_logic._mark_validation_failed(task_instance=ti)
    ti.xcom_push.assert_called_once_with(key='validation_failed', value=True)
