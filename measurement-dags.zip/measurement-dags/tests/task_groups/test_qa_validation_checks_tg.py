from unittest import mock

import pytest
from airflow.providers.standard.operators.empty import EmptyOperator

from helpers.constants import CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST
from helpers.emr import EmrAddAndWatchStep
from task_groups.metric_tasks import analytics_validation_checks, hypercare_validation_checks, qa_validation_checks


@pytest.mark.parametrize('campaign_duration', [CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST])
def test_qa_validation_group_nesting_and_dependencies(test_dag, campaign_duration):
    with (
        mock.patch.object(
            hypercare_validation_checks.hypercare_validation_checks,
            'tasks',
            side_effect=lambda **kwargs: EmptyOperator(task_id='HypercareValidationChecks'),
        ) as hypercare,
        mock.patch.object(
            analytics_validation_checks.analytics_validation_checks,
            'tasks',
            side_effect=lambda **kwargs: EmptyOperator(task_id='AnalyticsValidationChecks'),
        ) as analytics,
    ):
        upstream = EmptyOperator(task_id='mta_metrics')
        downstream = EmptyOperator(task_id='pipeline_summary')
        group = qa_validation_checks.task_group(campaign_duration=campaign_duration)
        upstream >> group >> downstream

    hypercare.assert_called_once_with(campaign_duration=campaign_duration)
    analytics.assert_called_once_with(campaign_duration=campaign_duration)
    assert set(group.children) == {
        'qa_validation_checks.hypercare_validation_checks',
        'qa_validation_checks.analytics_validation_checks',
    }
    assert upstream.downstream_task_ids == {
        'qa_validation_checks.hypercare_validation_checks.HypercareValidationChecks',
        'qa_validation_checks.analytics_validation_checks.AnalyticsValidationChecks',
    }
    assert downstream.upstream_task_ids == {
        'qa_validation_checks.hypercare_validation_checks.HypercareValidationChecks',
        'qa_validation_checks.analytics_validation_checks.AnalyticsValidationChecks',
    }


def test_qa_validation_constructs_real_emr_tasks(test_dag):
    with mock.patch('helpers.emr.get_environment', return_value='dev'):
        group = qa_validation_checks.task_group(campaign_duration=CAMPAIGN_DURATION_POST)

    expected_task_ids = {
        'qa_validation_checks.hypercare_validation_checks.HypercareValidationChecks',
        'qa_validation_checks.analytics_validation_checks.AnalyticsValidationChecks',
    }
    for task_id in expected_task_ids:
        task = test_dag.get_task(task_id)
        assert isinstance(task, EmrAddAndWatchStep)
        assert task.trigger_rule == 'all_success'
    assert {task.task_id for task in group.get_leaves()} == expected_task_ids
