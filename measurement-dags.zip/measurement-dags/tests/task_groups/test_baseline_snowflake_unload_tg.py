from unittest import mock

import pendulum
from airflow import DAG
from airflow.providers.standard.operators.empty import EmptyOperator

from task_groups.snowflake_unload_tasks import baseline_snowflake_unload


def collect_operator_calls(task_group_builder, dag) -> dict:
    """Builds the task group with lightweight stubs and captures SQL operator inputs."""
    operator_calls = []

    def _operator_stub(**kwargs):
        operator_calls.append(kwargs)
        return EmptyOperator(task_id=kwargs["task_id"], dag=dag)

    with mock.patch(
        "task_groups.snowflake_unload_tasks.baseline_snowflake_unload.MeasurementSnowflakeOperator",
        side_effect=_operator_stub,
    ), mock.patch(
        "task_groups.snowflake_unload_tasks.baseline_snowflake_unload.EmptyOperator",
        side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=dag),
    ):
        with dag:
            task_group_builder()

    return {call["task_id"]: call for call in operator_calls}


def test_temp_unified_product_receives_brand_time_reference():
    """The SQL resolves items from dim_item_hist, so it needs the brand reference date."""
    dag = DAG(
        dag_id="test_baseline_snowflake_unload_brand_time_reference",
        schedule=None,
        start_date=pendulum.datetime(2024, 1, 1),
    )

    by_task_id = collect_operator_calls(baseline_snowflake_unload.task_group, dag)
    params = by_task_id["unload_temp_unified_product"]["params"]

    assert "configure_booking_reference_date" in params["brand_time_reference"]
    assert "correlation_id" in params


def test_fact_sales_transaction_item_receives_brand_time_reference():
    """The SQL resolves items from dim_item_hist, so it needs the brand reference date."""
    dag = DAG(
        dag_id="test_additional_sales_data_transaction_brand_time_reference",
        schedule=None,
        start_date=pendulum.datetime(2024, 1, 1),
    )

    by_task_id = collect_operator_calls(
        baseline_snowflake_unload.additional_sales_data_transaction_task_group,
        dag,
    )
    params = by_task_id["unload_fact_sales_transaction_item"]["params"]

    assert "configure_booking_reference_date" in params["brand_time_reference"]
