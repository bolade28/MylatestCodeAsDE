from unittest import mock

from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import CAMPAIGN_DURATION_DURING, DTP_RUN_TYPE, POLLEN_RUN_TYPE
from task_groups import customer_data_collection


def _build_customer_data_collection_task(test_dag, *args, **kwargs):
    run_type = kwargs.get("pipeline_run_type")
    if run_type is None:
        assert args, "Expected pipeline_run_type as positional or keyword argument"
        run_type = args[0]
    return EmptyOperator(task_id=f"CustomerDataCollection_{run_type}", dag=test_dag)


def _build_task_group(test_dag):
    with mock.patch(
        "task_groups.customer_data_collection.customer_data_collection.tasks",
        side_effect=lambda *args, **kwargs: _build_customer_data_collection_task(test_dag, *args, **kwargs),
    ), mock.patch(
        "task_groups.customer_data_collection.instore_data_pollen.tasks",
        side_effect=lambda **kwargs: EmptyOperator(task_id="InStoreDataPollen", dag=test_dag),
    ), mock.patch(
        "task_groups.customer_data_collection.pipeline_run_type",
        return_value="templated-run-type",
    ):
        return customer_data_collection.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)


def test_customer_data_collection_task_group_shape(test_dag):
    """Verifies customer data collection task group contains expected control, branch and engagement tasks."""
    # Act: build the task group with step factories patched to deterministic task ids.
    tg = _build_task_group(test_dag)

    # Assert: verify expected control, branch, engagement and both run-type tasks exist.
    assert tg.group_id == "customer_data_collection"

    task_ids = {t.task_id for t in tg}
    assert "customer_data_collection.start" in task_ids
    assert "customer_data_collection.finish" in task_ids
    assert "customer_data_collection.run_dtp_or_pollen_customer_data_collection" in task_ids
    assert "customer_data_collection.customer_engagement.InStoreDataPollen" in task_ids
    assert f"customer_data_collection.CustomerDataCollection_{DTP_RUN_TYPE}" in task_ids
    assert f"customer_data_collection.CustomerDataCollection_{POLLEN_RUN_TYPE}" in task_ids


def test_customer_data_collection_branch_task_and_trigger_rule(test_dag):
    """Verifies the Pollen branch runs customer engagement before Pollen customer data collection."""
    # Act: build the task group with a fixed templated run type.
    tg = _build_task_group(test_dag)

    # Assert: validate branch arguments, Pollen ordering and finish trigger-rule behavior.
    tasks_by_id = {task.task_id: task for task in tg}
    branch_task = tasks_by_id["customer_data_collection.run_dtp_or_pollen_customer_data_collection"]
    instore_task = tasks_by_id["customer_data_collection.customer_engagement.InStoreDataPollen"]
    pollen_task = tasks_by_id[f"customer_data_collection.CustomerDataCollection_{POLLEN_RUN_TYPE}"]
    finish_task = tasks_by_id["customer_data_collection.finish"]

    assert isinstance(branch_task, BranchPythonOperator)
    assert branch_task.op_args == [
        "templated-run-type",
        f"CustomerDataCollection_{DTP_RUN_TYPE}",
        "customer_engagement.InStoreDataPollen",
        "customer_data_collection",
    ]
    assert instore_task.upstream_task_ids == {"customer_data_collection.run_dtp_or_pollen_customer_data_collection"}
    assert pollen_task.upstream_task_ids == {"customer_data_collection.customer_engagement.InStoreDataPollen"}
    assert finish_task.trigger_rule == TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS
