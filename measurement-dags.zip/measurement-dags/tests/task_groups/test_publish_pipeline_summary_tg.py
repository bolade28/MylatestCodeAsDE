from unittest import mock

from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE
from task_groups.metric_tasks import publish_pipeline_summary


def _build_pipeline_summary_step(test_dag, *args, **kwargs):
    step_name = kwargs.get("step_name")
    if step_name is None:
        assert args, "Expected step_name as positional or keyword argument"
        step_name = args[0]
    return EmptyOperator(task_id=step_name, dag=test_dag)


def test_publish_pipeline_summary_task_group_shape(test_dag):
    """Verifies publish pipeline summary task group contains expected control, branch, and run-type tasks."""
    with mock.patch(
        "task_groups.metric_tasks.publish_pipeline_summary.publish_pipeline_summary.tasks",
        side_effect=lambda *args, **kwargs: _build_pipeline_summary_step(test_dag, *args, **kwargs),
    ):
        tg = publish_pipeline_summary.task_group(pipeline_run_type="templated-run-type")

    assert tg.group_id == "publish_pipeline_summary"

    task_ids = {task.task_id for task in tg}
    assert "publish_pipeline_summary.start" in task_ids
    assert "publish_pipeline_summary.finish" in task_ids
    assert "publish_pipeline_summary.run_dtp_or_pollen_pipeline_summary" in task_ids
    assert "publish_pipeline_summary.PublishPipelineSummary" in task_ids
    assert "publish_pipeline_summary.PublishPipelineSummaryPollen" in task_ids


def test_publish_pipeline_summary_branch_args_and_step_calls(test_dag):
    """Verifies branch operator args, finish trigger rule, and both summary step invocations."""
    with mock.patch(
        "task_groups.metric_tasks.publish_pipeline_summary.publish_pipeline_summary.tasks",
        side_effect=lambda *args, **kwargs: _build_pipeline_summary_step(test_dag, *args, **kwargs),
    ) as mock_tasks:
        tg = publish_pipeline_summary.task_group(pipeline_run_type="templated-run-type")

    assert mock_tasks.call_count == 2
    mock_tasks.assert_any_call(
        step_name="PublishPipelineSummary",
        pipeline_run_type=DTP_RUN_TYPE,
        executors=8,
    )
    mock_tasks.assert_any_call(
        step_name="PublishPipelineSummaryPollen",
        pipeline_run_type=POLLEN_RUN_TYPE,
        executors=8,
    )

    tasks_by_id = {task.task_id: task for task in tg}
    branch_task = tasks_by_id["publish_pipeline_summary.run_dtp_or_pollen_pipeline_summary"]
    finish_task = tasks_by_id["publish_pipeline_summary.finish"]

    assert isinstance(branch_task, BranchPythonOperator)
    assert branch_task.op_args == [
        "templated-run-type",
        "PublishPipelineSummary",
        "PublishPipelineSummaryPollen",
        "publish_pipeline_summary",
    ]
    assert finish_task.trigger_rule == TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS


def test_publish_pipeline_summary_task_group_is_callable(test_dag):
    """Verifies task_group is callable."""
    assert callable(publish_pipeline_summary.task_group)
