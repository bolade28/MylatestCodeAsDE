from unittest import mock

from airflow.providers.standard.operators.empty import EmptyOperator

from task_groups import exp_config_validation


def test_exp_config_validation_task_group_wiring(test_dag):
    """Verifies upload and validation task chain is created in experiment config task group."""
    # Arrange
    with mock.patch(
        "task_groups.exp_config_validation.LocalFilesystemToS3Operator",
        side_effect=lambda **kwargs: EmptyOperator(task_id=kwargs["task_id"]),
    ), mock.patch(
        "task_groups.exp_config_validation.experiments.get_experiments_config",
        side_effect=lambda **_: EmptyOperator(task_id="get_experiment_config"),
    ), mock.patch(
        "task_groups.exp_config_validation.experiments.validate_experiment_config",
        side_effect=lambda **_: EmptyOperator(task_id="validate_experiment_config"),
    ), mock.patch(
        "task_groups.exp_config_validation.experiments.validate_parquet_data_exists",
        side_effect=lambda **_: EmptyOperator(task_id="validate_parquet_data_exists"),
    ):
        # Act: build the upload-and-validate task group with lightweight operator stubs.
        tg = exp_config_validation.config_validation("/tmp/exp.json")

    # Assert: verify all expected tasks are present in the pipeline chain.
    assert tg.group_id == "upload_and_validate_config"
    task_ids = {task.task_id for task in tg}
    assert "upload_and_validate_config.upload_config_to_s3" in task_ids
    assert "upload_and_validate_config.get_experiment_config" in task_ids
    assert "upload_and_validate_config.validate_experiment_config" in task_ids
    assert "upload_and_validate_config.validate_parquet_data_exists" in task_ids


def test_exp_config_validation_passes_expected_inputs(test_dag):
    """Verifies experiment config task group passes expected inputs to upload and validation calls."""
    # Arrange
    with mock.patch(
        "task_groups.exp_config_validation.LocalFilesystemToS3Operator",
        side_effect=lambda **kwargs: EmptyOperator(task_id=kwargs["task_id"]),
    ) as mock_upload, mock.patch(
        "task_groups.exp_config_validation.experiments.get_experiments_config",
        side_effect=lambda **_: EmptyOperator(task_id="get_experiment_config"),
    ) as mock_get_config, mock.patch(
        "task_groups.exp_config_validation.experiments.validate_experiment_config",
        side_effect=lambda **_: EmptyOperator(task_id="validate_experiment_config"),
    ) as mock_validate_config, mock.patch(
        "task_groups.exp_config_validation.experiments.validate_parquet_data_exists",
        side_effect=lambda **_: EmptyOperator(task_id="validate_parquet_data_exists"),
    ) as mock_validate_data:
        # Act: build task group to capture call arguments passed to each helper.
        exp_config_validation.config_validation("/tmp/my-config.json")

    # Assert: validate filename, overwrite flag, and config-path propagation across helpers.
    assert mock_upload.call_args.kwargs["filename"] == "/tmp/my-config.json"
    assert mock_upload.call_args.kwargs["replace"] is True
    assert "experiment_config" in mock_upload.call_args.kwargs["dest_key"]
    assert "experiment_config" in mock_get_config.call_args.kwargs["experiment_config_path"]
    assert "experiment_config" in mock_validate_config.call_args.kwargs["experiment_config_path"]
    assert "experiment_config" in mock_validate_data.call_args.kwargs["experiment_config_path"]
