from unittest import mock

from task_groups import legacy_brand_registry_alert


def test_task_group_contains_branch_alert_and_ok_tasks(test_dag):
    with mock.patch("airflow.sdk.Variable.get", return_value="dev"):
        tg = legacy_brand_registry_alert.task_group()

    task_ids = [t.task_id for t in tg]
    assert "legacy_brand_registry_alert.check_legacy_registry_row_count" in task_ids
    assert "legacy_brand_registry_alert.slack_alert_legacy_brand_registry_empty" in task_ids
    assert "legacy_brand_registry_alert.legacy_registry_still_needed" in task_ids


def test_check_legacy_registry_row_count_branches_to_alert_when_empty():
    ti = mock.MagicMock()
    with mock.patch(
        "task_groups.legacy_brand_registry_alert.count_legacy_brand_booking_registry_rows",
        return_value=0,
    ):
        result = legacy_brand_registry_alert._check_legacy_registry_row_count(
            table="legacy_brand_booking_registry", task_instance=ti,
        )

    assert result == "daily_etl.legacy_brand_registry_alert.slack_alert_legacy_brand_registry_empty"
    ti.xcom_push.assert_called_once_with(key='row_count', value=0)


def test_check_legacy_registry_row_count_branches_to_ok_when_not_empty():
    ti = mock.MagicMock()
    with mock.patch(
        "task_groups.legacy_brand_registry_alert.count_legacy_brand_booking_registry_rows",
        return_value=3,
    ):
        result = legacy_brand_registry_alert._check_legacy_registry_row_count(
            table="legacy_brand_booking_registry", task_instance=ti,
        )

    assert result == "daily_etl.legacy_brand_registry_alert.legacy_registry_still_needed"
    ti.xcom_push.assert_called_once_with(key='row_count', value=3)


def test_get_registry_empty_alert_message_tags_measurement_team():
    message = legacy_brand_registry_alert.get_registry_empty_alert_message()
    assert "<!here>" in message
    assert "legacy_brand_booking_registry is empty" in message
