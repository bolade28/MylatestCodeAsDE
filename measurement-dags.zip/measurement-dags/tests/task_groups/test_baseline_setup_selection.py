from unittest import mock

from airflow.providers.standard.operators.empty import EmptyOperator
import pytest

from helpers.constants import EvaluationPhase
from helpers.utils import has_eligible_booking_rows
from helpers.xcom import get_eligible_booking_rows
from task_groups import baseline_setup


@pytest.mark.parametrize(
    ("phase", "date_column", "is_post"),
    [
        (EvaluationPhase.DURING, "campaign_end_dt", False),
        (EvaluationPhase.POST, "post_campaign_dt", True),
    ],
)
def test_select_campaigns_automated_adds_query_and_empty_result_gate(
    test_dag, phase, date_column, is_post
):
    dag_run_source = EmptyOperator(task_id="dag_run_source")
    expected_campaigns = EmptyOperator(task_id="configured_campaigns")

    with mock.patch(
        "task_groups.baseline_setup.setup.configure_campaigns",
        return_value=expected_campaigns,
    ) as configure_campaigns:
        result = baseline_setup.select_campaigns(
            phase,
            dag_run_source=dag_run_source,
        )

    assert result is expected_campaigns
    configure_campaigns.assert_called_once_with(
        dag_run_source=dag_run_source,
        eligible_booking_rows=get_eligible_booking_rows(),
    )

    is_automated = test_dag.get_task("is_automated_run")
    query = test_dag.get_task("query_eligible_booking")
    has_booking = test_dag.get_task("has_eligible_booking")

    assert is_automated.upstream_task_ids == {"dag_run_source"}
    assert query.upstream_task_ids == {"is_automated_run"}
    assert has_booking.upstream_task_ids == {"query_eligible_booking"}
    assert expected_campaigns.upstream_task_ids == {"has_eligible_booking", "dag_run_source"}
    assert has_booking.python_callable is has_eligible_booking_rows
    assert has_booking.python_callable([]) is False
    assert has_booking.python_callable([["booking-1"]]) is True
    assert has_booking.ignore_downstream_trigger_rules is True
    assert query.params["date_column"] == date_column
    assert query.params["is_post"] is is_post
