"""Tests for attribution_model_dataset task group.

This test suite verifies the behavior of the attribution_model_dataset task group,
including task group assembly, branching logic, and trigger rules.
"""

from unittest import mock
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE


def test_attribution_model_dataset_task_group_returns_task_group(test_dag):
    """Verifies model_dataset task group is created with the expected group id."""
    # Arrange: mock dataset step factory and run type
    with mock.patch("task_groups.attribution_model_dataset.attribution_model_dataset"), \
         mock.patch("task_groups.attribution_model_dataset.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_dataset

        # Act: create task group
        tg = attribution_model_dataset.task_group()

        # Assert: verify task group properties
        assert tg is not None
        assert tg.group_id == "model_dataset"


def test_attribution_model_dataset_creates_all_four_tasks(test_dag):
    """Verifies four dataset tasks are created for DTP and Pollen offer/brand paths."""
    # Arrange: mock dataset step factory
    with mock.patch("task_groups.attribution_model_dataset.attribution_model_dataset") as mock_amd, \
         mock.patch("task_groups.attribution_model_dataset.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_dataset

        # Act: create task group
        attribution_model_dataset.task_group()

        # Assert: verify four tasks are created
        assert mock_amd.tasks.call_count == 4


def test_attribution_model_dataset_dtp_task_names(test_dag):
    """Verifies expected task names are produced for attribution model dataset branches."""
    # Arrange: mock dataset step factory
    with mock.patch("task_groups.attribution_model_dataset.attribution_model_dataset") as mock_amd, \
         mock.patch("task_groups.attribution_model_dataset.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_dataset

        # Act: create task group
        attribution_model_dataset.task_group()

        # Assert: verify all expected step names are used
        calls = mock_amd.tasks.call_args_list
        # Extract step_name from kwargs if present, otherwise from first positional arg
        step_names = [c.kwargs.get("step_name") or (c.args[0] if c.args else None) for c in calls]

        assert "AttributionModelDatasetBrand" in step_names
        assert "AttributionModelDatasetOffer" in step_names
        assert "AttributionModelDatasetBrandPollen" in step_names
        assert "AttributionModelDatasetOfferPollen" in step_names


def test_attribution_model_dataset_journey_types(test_dag):
    """Verifies task definitions include both DTP and Pollen pipeline run types."""
    # Arrange: mock dataset step factory
    with mock.patch("task_groups.attribution_model_dataset.attribution_model_dataset") as mock_amd, \
         mock.patch("task_groups.attribution_model_dataset.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_dataset

        # Act: create task group
        attribution_model_dataset.task_group()

        # Assert: verify both run types are represented
        calls = mock_amd.tasks.call_args_list
        # Extract pipeline_run_type from kwargs if present, otherwise from second positional arg
        run_types = [c.kwargs.get("pipeline_run_type") or (c.args[1] if len(c.args) > 1 else None) for c in calls]

        assert DTP_RUN_TYPE in run_types
        assert POLLEN_RUN_TYPE in run_types


def test_attribution_model_dataset_branch_operator_config(test_dag):
    """Verifies branch operator is configured with correct callable and op_args."""
    # Arrange: mock dataset step factory and decision function
    with mock.patch("task_groups.attribution_model_dataset.attribution_model_dataset"), \
         mock.patch("task_groups.attribution_model_dataset.pipeline_run_type", return_value=DTP_RUN_TYPE), \
         mock.patch("task_groups.attribution_model_dataset.decide_pollen_dtp"):

        from task_groups import attribution_model_dataset

        # Act: create task group
        tg = attribution_model_dataset.task_group()

        # Assert: verify branch operator task exists
        task_ids = [t.task_id for t in tg]
        assert any("run_dtp_or_pollen_pipeline" in tid for tid in task_ids)


def test_attribution_model_dataset_finish_trigger_rule(test_dag):
    """Verifies finish operator uses NONE_FAILED_MIN_ONE_SUCCESS trigger rule."""
    # Arrange: mock dataset step factory
    with mock.patch("task_groups.attribution_model_dataset.attribution_model_dataset"), \
         mock.patch("task_groups.attribution_model_dataset.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_dataset

        # Act: create task group
        tg = attribution_model_dataset.task_group()

        # Assert: verify finish task trigger rule
        finish_task = [t for t in tg if "finish" in t.task_id]
        assert len(finish_task) >= 1
        assert finish_task[0].trigger_rule == TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS


def test_attribution_model_dataset_invalid_pipeline_type_handling(test_dag):
    """Verifies branch operator handles unexpected pipeline type gracefully."""
    # Arrange: mock with invalid pipeline type
    with mock.patch("task_groups.attribution_model_dataset.attribution_model_dataset"), \
         mock.patch("task_groups.attribution_model_dataset.pipeline_run_type", return_value="UNKNOWN_TYPE"), \
         mock.patch("task_groups.attribution_model_dataset.decide_pollen_dtp") as mock_decide:

        mock_decide.return_value = None

        from task_groups import attribution_model_dataset

        # Act: create task group with invalid type
        tg = attribution_model_dataset.task_group()

        # Assert: task group still constructs successfully
        assert tg is not None
        assert tg.group_id == "model_dataset"


def test_attribution_model_dataset_total_task_count(test_dag):
    """Verifies the task group contains all expected control and data tasks."""
    # Arrange: mock dataset step factory
    with mock.patch("task_groups.attribution_model_dataset.attribution_model_dataset"), \
         mock.patch("task_groups.attribution_model_dataset.pipeline_run_type", return_value=DTP_RUN_TYPE):

        from task_groups import attribution_model_dataset

        # Act: create task group
        tg = attribution_model_dataset.task_group()

        # Assert: verify minimum task count
        task_count = len(list(tg))
        assert task_count >= 3
