from unittest import mock
from helpers.constants import CAMPAIGN_DURATION_DURING


def test_analytical_pipeline_task_group_returns_task_group(test_dag):
    """Verifies analytical_pipeline.task_group returns the expected task group id."""
    # Arrange: mock pipeline steps
    with mock.patch("task_groups.analytical_pipeline.three_letter_coding"), \
         mock.patch("task_groups.analytical_pipeline.baseline_modelling_dataset"):

        from task_groups import analytical_pipeline

        # Act: create task group
        tg = analytical_pipeline.task_group()

        # Assert: verify task group properties
        assert tg is not None
        assert tg.group_id == "analytical_pipeline"


def test_analytical_pipeline_calls_steps_with_correct_executors(test_dag):
    """Verifies both analytical pipeline steps are invoked with executors=8."""
    # Arrange: mock pipeline steps
    with mock.patch("task_groups.analytical_pipeline.three_letter_coding") as mock_tlc, \
         mock.patch("task_groups.analytical_pipeline.baseline_modelling_dataset") as mock_bmd:

        from task_groups import analytical_pipeline

        # Act: create task group
        analytical_pipeline.task_group()

        # Assert: verify steps called with correct executor count
        mock_tlc.tasks.assert_called_once_with(executors=8)
        mock_bmd.tasks.assert_called_once_with(
            executors=8, campaign_duration=CAMPAIGN_DURATION_DURING
        )


def test_analytical_pipeline_task_ordering(test_dag):
    """Verifies three_letter_coding task runs before baseline_modelling_dataset."""
    # Arrange: mock pipeline steps and tasks
    with mock.patch("task_groups.analytical_pipeline.three_letter_coding") as mock_tlc, \
         mock.patch("task_groups.analytical_pipeline.baseline_modelling_dataset") as mock_bmd:

        three_letter_task = mock.MagicMock()
        baseline_task = mock.MagicMock()

        # Set up Airflow-like relationship tracking on mocks to verify DAG structure.
        # This is more robust than checking method calls—it works regardless of
        # whether the implementation uses >> or set_downstream/set_upstream.
        three_letter_task.downstream_list = []
        baseline_task.upstream_list = []

        def track_downstream(other):
            """Track downstream relationship when >> operator or set_downstream is used."""
            three_letter_task.downstream_list.append(other)
            if hasattr(other, 'upstream_list'):
                other.upstream_list.append(three_letter_task)
            return other

        # Use side_effect to handle >> operator call correctly (with implicit self)
        three_letter_task.__rshift__.side_effect = track_downstream
        three_letter_task.set_downstream.side_effect = track_downstream

        mock_tlc.tasks.return_value = three_letter_task
        mock_bmd.tasks.return_value = baseline_task

        from task_groups import analytical_pipeline

        # Act: create task group with task dependencies
        analytical_pipeline.task_group()

        # Assert: verify task ordering via Airflow relationship properties (not method calls)
        assert baseline_task in three_letter_task.downstream_list, \
            "baseline_modelling_dataset should be downstream of three_letter_coding"
        assert three_letter_task in baseline_task.upstream_list, \
            "three_letter_coding should be upstream of baseline_modelling_dataset"
