import json
from contextlib import ExitStack
from unittest import mock

import pytest
from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule
from jinja2 import Template

from helpers.constants import BookingStatus, EvaluationPhase


def import_metadata_modules():
    with mock.patch("airflow.sdk.Variable.get", return_value="dev"):
        from task_groups import metadata_and_slack_alert
        from tasks.metadata import publish_metadata

    return publish_metadata, metadata_and_slack_alert


@pytest.mark.parametrize('group_ids', [(), ('metadata',), ('completed_checkpoint', 'metadata')])
@pytest.mark.parametrize('is_fallback', [True, False])
def test_configure_fallback_metadata_creates_reader_and_scoped_xcom(
    test_dag, group_ids, is_fallback,
):
    publish_metadata, _ = import_metadata_modules()
    metadata_path = 's3://bucket/run/incrementality_fallback_metadata'
    with mock.patch.object(
        publish_metadata, 'get_path', return_value=metadata_path,
    ) as get_path, mock.patch.object(
        publish_metadata, 'get_ci', return_value='run',
    ) as get_ci, ExitStack() as stack:
        for group_id in group_ids:
            stack.enter_context(TaskGroup(group_id=group_id))
        reader, fallback_xcom = publish_metadata.configure_fallback_metadata(
            pipeline_stage='completed', experiment_config=None,
        )

    expected_task_id = '.'.join((*group_ids, 'read_fallback_metadata'))
    assert isinstance(reader, publish_metadata.PythonOperator)
    assert reader.task_id == expected_task_id
    assert reader.python_callable is publish_metadata.read_fallback_metadata
    assert reader.op_kwargs == {
        'fallback_metadata_path': metadata_path,
        'correlation_id': 'run',
    }
    assert test_dag.get_task(expected_task_id) is reader
    get_path.assert_called_once_with('incrementality_fallback_metadata')
    get_ci.assert_called_once_with()

    task_instance = mock.Mock()
    task_instance.xcom_pull.return_value = is_fallback
    assert json.loads(Template(fallback_xcom).render(task_instance=task_instance)) is is_fallback
    task_instance.xcom_pull.assert_called_once_with(task_ids=expected_task_id)


@pytest.mark.parametrize('pipeline_stage', ['start', 'started', '', None, 'COMPLETED'])
def test_configure_fallback_metadata_skips_non_completed_stages(pipeline_stage):
    publish_metadata, _ = import_metadata_modules()
    with mock.patch.multiple(
        publish_metadata, PythonOperator=mock.DEFAULT, get_path=mock.DEFAULT, get_ci=mock.DEFAULT,
    ) as dependencies:
        result = publish_metadata.configure_fallback_metadata(
            pipeline_stage=pipeline_stage, experiment_config=None,
        )

    assert result == (None, None)
    for dependency in dependencies.values():
        dependency.assert_not_called()


@pytest.mark.parametrize('pipeline_stage', ['start', 'completed'])
@pytest.mark.parametrize('config_is_truthy', [True, False])
def test_configure_fallback_metadata_skips_experiments(pipeline_stage, config_is_truthy):
    publish_metadata, _ = import_metadata_modules()
    experiment_config = mock.MagicMock()
    experiment_config.__bool__.return_value = config_is_truthy
    with mock.patch.multiple(
        publish_metadata, PythonOperator=mock.DEFAULT, get_path=mock.DEFAULT, get_ci=mock.DEFAULT,
    ) as dependencies:
        result = publish_metadata.configure_fallback_metadata(
            pipeline_stage=pipeline_stage, experiment_config=experiment_config,
        )

    assert result == (None, None)
    for dependency in dependencies.values():
        dependency.assert_not_called()


@pytest.mark.parametrize('is_fallback', [True, False])
def test_read_fallback_metadata_reads_spark_json_parts(is_fallback):
    publish_metadata, _ = import_metadata_modules()
    prefix = 'run/incrementality_fallback_metadata/'
    part_key = prefix + 'part-00001.json'
    empty_key = prefix + 'part-00000.json'
    with mock.patch.object(publish_metadata, 'S3Hook') as hook_factory:
        hook = hook_factory.return_value
        hook.list_keys.return_value = [prefix + '_SUCCESS', part_key, empty_key]
        hook.read_key.side_effect = lambda key, bucket_name: (
            '' if key == empty_key else json.dumps({
                'correlation_id': '00123', 'is_fallback': is_fallback,
            }) + '\n'
        )

        result = publish_metadata.read_fallback_metadata(
            's3://bucket/' + prefix, '00123')

    assert result is is_fallback
    hook.list_keys.assert_called_once_with(bucket_name='bucket', prefix=prefix)
    assert hook.read_key.call_count == 2
    hook.get_key.assert_not_called()


def test_read_fallback_metadata_ignores_success_file():
    publish_metadata, _ = import_metadata_modules()
    prefix = 'run/incrementality_fallback_metadata/'
    json_key = prefix + 'metadata.json'
    with mock.patch.object(publish_metadata, 'S3Hook') as hook_factory:
        hook = hook_factory.return_value
        hook.list_keys.return_value = [prefix + 'SUCCESS', json_key]
        hook.read_key.return_value = json.dumps({
            'correlation_id': 'run', 'is_fallback': True,
        })

        result = publish_metadata.read_fallback_metadata(
            's3://bucket/' + prefix, 'run')

    assert result is True
    hook.read_key.assert_called_once_with(key=json_key, bucket_name='bucket')


@pytest.mark.parametrize('keys', [None, [], ['run/metadata/_SUCCESS']])
def test_read_fallback_metadata_rejects_missing_parts(keys):
    publish_metadata, _ = import_metadata_modules()
    with mock.patch.object(publish_metadata, 'S3Hook') as hook_factory:
        hook_factory.return_value.list_keys.return_value = keys
        with pytest.raises(FileNotFoundError, match='Fallback metadata not found'):
            publish_metadata.read_fallback_metadata('s3://bucket/run/metadata', 'run')


@pytest.mark.parametrize(('payload', 'message'), [
    ('', 'exactly one row'),
    ('{}\n{}\n', 'exactly one row'),
    ('{"correlation_id":"other","is_fallback":true}', 'correlation ID'),
    ('{"correlation_id":"run"}', 'boolean is_fallback'),
    ('{"correlation_id":"run","is_fallback":"false"}', 'boolean is_fallback'),
    ('{"correlation_id":"run","is_fallback":0}', 'boolean is_fallback'),
    ('{"correlation_id":"run","is_fallback":null}', 'boolean is_fallback'),
    ('null', 'JSON object'),
    ('[]', 'JSON object'),
])
def test_read_fallback_metadata_validates_records(payload, message):
    publish_metadata, _ = import_metadata_modules()
    with mock.patch.object(publish_metadata, 'S3Hook') as hook_factory:
        hook = hook_factory.return_value
        hook.list_keys.return_value = ['run/metadata/part-00000.json']
        hook.read_key.return_value = payload
        with pytest.raises(ValueError, match=message):
            publish_metadata.read_fallback_metadata('s3://bucket/run/metadata', 'run')


@pytest.fixture
def additional_metadata_module():
    publish_metadata, _ = import_metadata_modules()
    with mock.patch.multiple(
        publish_metadata,
        get_build_hash=mock.Mock(return_value='build-123'),
        get_experimentation_flag=mock.Mock(return_value='false'),
        get_emulation_run=mock.Mock(return_value='false'),
        get_during_correlation_id=mock.Mock(return_value='configured-cid'),
        get_resolved_during_correlation_id=mock.Mock(return_value='resolved-cid'),
        get_used_new_brand_logic_for_during=mock.Mock(
            return_value='"used_new_brand_logic": true,'),
        get_experiment_details=mock.Mock(return_value='[]'),
    ):
        yield publish_metadata


@pytest.mark.parametrize('evaluation_phase', [
    EvaluationPhase.DURING, EvaluationPhase.POST,
    EvaluationPhase.DURING.value, EvaluationPhase.POST.value,
])
@pytest.mark.parametrize(('is_fallback', 'expected'), [
    (True, True), (False, False), ('true', True), ('false', False), (None, False),
])
def test_additional_metadata_serializes_fallback(
    additional_metadata_module, evaluation_phase, is_fallback, expected,
):
    metadata = json.loads(additional_metadata_module.additional_metadata(
        evaluation_phase, booking_name='booking-123', is_fallback=is_fallback,
    ))

    assert metadata['is_fallback'] is expected
    assert metadata['build_hash'] == 'build-123'
    assert metadata['used_new_brand_logic'] is True
    assert metadata['experimentation_run'] == 'false'
    assert metadata['is_emulated_run'] == 'false'
    if evaluation_phase in (EvaluationPhase.POST, EvaluationPhase.POST.value):
        assert metadata['configured_during_cid'] == 'configured-cid'
        assert metadata['resolved_during_cid'] == 'resolved-cid'
    else:
        assert metadata['booking_name'] == 'booking-123'


@pytest.mark.parametrize('evaluation_phase', [EvaluationPhase.DURING, EvaluationPhase.POST])
@pytest.mark.parametrize('is_fallback', [True, False])
def test_additional_metadata_renders_fallback_xcom_as_boolean(
    additional_metadata_module, evaluation_phase, is_fallback,
):
    fallback_xcom = (
        '{{ task_instance.xcom_pull(task_ids="metadata.read_fallback_metadata") | tojson }}'
    )
    template = additional_metadata_module.additional_metadata(
        evaluation_phase, is_fallback=fallback_xcom,
    )
    task_instance = mock.Mock()
    task_instance.xcom_pull.return_value = is_fallback

    assert fallback_xcom in template
    metadata = json.loads(Template(template).render(task_instance=task_instance))

    assert metadata['is_fallback'] is is_fallback
    task_instance.xcom_pull.assert_called_once_with(
        task_ids='metadata.read_fallback_metadata')


@pytest.mark.parametrize('evaluation_phase', [EvaluationPhase.DURING, EvaluationPhase.POST])
@pytest.mark.parametrize('is_fallback', [True, False, None])
def test_additional_metadata_omits_fallback_for_experiments(
    additional_metadata_module, evaluation_phase, is_fallback,
):
    metadata = json.loads(additional_metadata_module.additional_metadata(
        evaluation_phase, experiment_config=mock.Mock(count=2), is_fallback=is_fallback,
    ))

    assert 'is_fallback' not in metadata
    assert metadata['experiment_count'] == '2'
    assert metadata['experiment_details'] == []
    assert metadata['build_hash'] == 'build-123'
    additional_metadata_module.get_experimentation_flag.assert_not_called()


def test_additional_metadata_returns_none_for_unsupported_phase(additional_metadata_module):
    assert additional_metadata_module.additional_metadata(
        'unsupported', is_fallback=True,
    ) is None


@pytest.mark.parametrize(
    ("factory_name", "expected_status", "expected_task_id", "expected_trigger_rule"),
    [
        (
            "mark_booking_as_in_progress",
            BookingStatus.IN_PROGRESS,
            "mark_booking_as_in_progress",
            TriggerRule.ALL_SUCCESS,
        ),
        (
            "mark_booking_as_completed",
            BookingStatus.COMPLETED,
            "mark_booking_as_completed",
            TriggerRule.ALL_SUCCESS,
        ),
        (
            "mark_booking_as_failed",
            BookingStatus.FAILED,
            "mark_booking_as_failed",
            TriggerRule.ONE_FAILED,
        ),
    ],
)
def test_booking_status_factories_configure_tracker_updates(
    test_dag, factory_name, expected_status, expected_task_id, expected_trigger_rule
):
    publish_metadata, _ = import_metadata_modules()
    with mock.patch(
        "tasks.metadata.publish_metadata.get_configured_campaign",
        return_value="booking_123",
    ) as get_configured_campaign, mock.patch(
        "tasks.metadata.publish_metadata.MeasurementSnowflakeOperator"
    ) as snowflake_operator:
        task = getattr(publish_metadata, factory_name)(
            evaluation_phase=EvaluationPhase.POST,
            trigger_rule=expected_trigger_rule,
        )

    snowflake_operator.assert_called_once()
    assert task is snowflake_operator.return_value
    operator_kwargs = snowflake_operator.call_args.kwargs
    assert operator_kwargs["task_id"] == expected_task_id
    assert operator_kwargs["sql"] == "booking_tracker/booking_status_update.sql"
    assert operator_kwargs["params"] == {
        "booking_id": "booking_123",
        "pipeline_stage": EvaluationPhase.POST.value,
        "status": expected_status.value,
    }
    assert operator_kwargs["trigger_rule"] == expected_trigger_rule
    get_configured_campaign.assert_called_once_with()


def test_booking_status_factory_skips_tracker_update_for_experiment(test_dag):
    publish_metadata, _ = import_metadata_modules()
    with mock.patch(
        "tasks.metadata.publish_metadata.MeasurementSnowflakeOperator"
    ) as snowflake_operator:
        task = publish_metadata.mark_booking_as_in_progress(
            experiment_config=mock.Mock(),
        )

    assert isinstance(task, EmptyOperator)
    snowflake_operator.assert_not_called()


def test_start_checkpoint_builds_in_progress_status_task(test_dag):
    _, metadata_and_slack_alert = import_metadata_modules()
    metadata = EmptyOperator(task_id="metadata")
    alerts = EmptyOperator(task_id="alerts")
    in_progress = EmptyOperator(task_id="in_progress")

    with mock.patch(
        "task_groups.metadata_and_slack_alert.publish_metadata.commit_metadata",
        return_value=metadata,
    ), mock.patch(
        "task_groups.metadata_and_slack_alert.slack_alert.task_group",
        return_value=alerts,
    ), mock.patch(
        "task_groups.metadata_and_slack_alert.publish_metadata.mark_booking_as_in_progress",
        return_value=in_progress,
    ) as mark_in_progress:
        task_group = metadata_and_slack_alert.task_group_start()

    assert task_group.group_id == "start_checkpoint"
    mark_in_progress.assert_called_once_with(
        experiment_config=None,
        evaluation_phase=EvaluationPhase.DURING,
    )
    assert alerts.downstream_task_ids == {in_progress.task_id}


def test_completed_checkpoint_runs_failed_status_when_any_checkpoint_task_fails(test_dag):
    _, metadata_and_slack_alert = import_metadata_modules()
    metadata = EmptyOperator(task_id="metadata")
    alerts = EmptyOperator(task_id="alerts")
    completed = EmptyOperator(task_id="completed")
    failed = EmptyOperator(task_id="failed", trigger_rule=TriggerRule.ONE_FAILED)

    with mock.patch(
        "task_groups.metadata_and_slack_alert.publish_metadata.commit_metadata",
        return_value=metadata,
    ), mock.patch(
        "task_groups.metadata_and_slack_alert.slack_alert.task_group",
        return_value=alerts,
    ), mock.patch(
        "task_groups.metadata_and_slack_alert.publish_metadata.mark_booking_as_completed",
        return_value=completed,
    ), mock.patch(
        "task_groups.metadata_and_slack_alert.publish_metadata.mark_booking_as_failed",
        return_value=failed,
    ) as mark_failed:
        task_group = metadata_and_slack_alert.task_group_completed()

    assert task_group.group_id == "completed_checkpoint"
    mark_failed.assert_called_once_with(
        experiment_config=None,
        evaluation_phase=EvaluationPhase.DURING,
        trigger_rule=TriggerRule.ONE_FAILED,
    )
    assert failed.upstream_task_ids == {
        metadata.task_id,
        alerts.task_id,
        completed.task_id,
    }
