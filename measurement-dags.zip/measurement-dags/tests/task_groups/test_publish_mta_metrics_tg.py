from unittest import mock
from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE
from task_groups.metric_tasks import publish_mta_metrics


def test_publish_mta_metrics_task_group_returns_task_group(test_dag):
    """Verifies publish_mta_metrics.task_group returns a TaskGroup with the correct id."""
    with mock.patch("task_groups.metric_tasks.publish_mta_metrics.mta_metrics"), \
         mock.patch("task_groups.metric_tasks.publish_mta_metrics.publish_mta_validation"), \
         mock.patch("task_groups.metric_tasks.publish_mta_metrics.pipeline_run_type", return_value="DTP"):

        tg = publish_mta_metrics.task_group()

    assert tg is not None
    assert tg.group_id == "publish_mta_metrics"


def test_publish_mta_metrics_calls_mta_metrics_with_executors(test_dag):
    """Verifies mta_metrics step is called with executors=8."""
    with mock.patch("task_groups.metric_tasks.publish_mta_metrics.mta_metrics") as mock_mta, \
         mock.patch("task_groups.metric_tasks.publish_mta_metrics.publish_mta_validation"), \
         mock.patch("task_groups.metric_tasks.publish_mta_metrics.pipeline_run_type", return_value="DTP"):

        publish_mta_metrics.task_group()

    mock_mta.tasks.assert_called_once_with(executors=8)


def test_publish_mta_metrics_creates_both_validation_steps(test_dag):
    """Verifies both DTP and Pollen mta validation steps are created."""
    with mock.patch("task_groups.metric_tasks.publish_mta_metrics.mta_metrics"), \
         mock.patch("task_groups.metric_tasks.publish_mta_metrics.publish_mta_validation") as mock_val, \
         mock.patch("task_groups.metric_tasks.publish_mta_metrics.pipeline_run_type", return_value="DTP"):

        publish_mta_metrics.task_group()

    assert mock_val.tasks.call_count == 2
    call_kwargs = [c.kwargs for c in mock_val.tasks.call_args_list]
    run_types = {kw["pipeline_run_type"] for kw in call_kwargs}
    assert DTP_RUN_TYPE in run_types
    assert POLLEN_RUN_TYPE in run_types


def test_decide_pollen_dtp_returns_dtp_task(test_dag):
    """Verifies decide_pollen_dtp returns DTP task path when run_type is DTP."""
    from helpers.utils import decide_pollen_dtp

    result = decide_pollen_dtp(
        run_type=DTP_RUN_TYPE,
        dtp_task_name="PublishMTAValidation",
        pollen_task_name="PublishMTAValidationPollen",
        task_group_name="publish_mta_metrics",
    )

    assert result == "publish_mta_metrics.PublishMTAValidation"


def test_decide_pollen_dtp_returns_pollen_task(test_dag):
    """Verifies decide_pollen_dtp returns Pollen task path when run_type is Pollen."""
    from helpers.utils import decide_pollen_dtp

    result = decide_pollen_dtp(
        run_type=POLLEN_RUN_TYPE,
        dtp_task_name="PublishMTAValidation",
        pollen_task_name="PublishMTAValidationPollen",
        task_group_name="publish_mta_metrics",
    )

    assert result == "publish_mta_metrics.PublishMTAValidationPollen"
