from helpers.constants import CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST
from task_groups.snowflake_unload_tasks import unload_mta_tables


def test_unload_mta_tables_unloads_instore_pollen_inputs(test_dag):
    """Verifies in-store pollen inputs are unloaded with the MTA tables."""
    tg = unload_mta_tables.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)

    tasks_by_id = {task.task_id: task for task in tg}
    item_task = tasks_by_id["unload_mta_tables.unload_mta_fact_sale_transaction_item"]

    assert item_task.sql == "mta_tables_unload/mta_fact_sale_transaction_item.sql"
    assert "unload_mta_tables.unload_dim_customer_loyalty" in tasks_by_id


def test_unload_mta_tables_post_reads_during_customers_from_metadata_paths(test_dag):
    """Post runs read the During customer data collection via metadata paths, so nothing extra is unloaded."""
    tg = unload_mta_tables.task_group(campaign_duration=CAMPAIGN_DURATION_POST)

    assert not any("customer_data_collection" in task.task_id for task in tg)
