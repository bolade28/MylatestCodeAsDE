from unittest import mock

import pendulum
import pytest
from airflow import DAG
from airflow.providers.standard.operators.empty import EmptyOperator

from helpers.constants import DEV, PROD
from task_groups.snowflake_unload_tasks import shared_snowflake_unload


@pytest.mark.parametrize("environment,emulation_run,expected_is_prod", [
    (DEV, True, False),
    (DEV, False, False),
    (PROD, True, True),
    (PROD, False, True),
])
def test_shared_snowflake_unload_passes_prod_emulation_params_to_campaign_booking(environment, emulation_run, expected_is_prod):
    """Verifies campaign booking unload task passes emulate/is_prod params required by SQL Jinja condition."""
    def _build_task_group_and_collect_operator_calls(environment, emulation_run, dag):
        # Arrange: keep operator construction lightweight while capturing SQL operator inputs.
        operator_calls = []

        def _operator_stub(**kwargs):
            operator_calls.append(kwargs)
            return EmptyOperator(task_id=kwargs["task_id"], dag=dag)

        with mock.patch(
            "task_groups.snowflake_unload_tasks.shared_snowflake_unload.MeasurementSnowflakeOperator",
            side_effect=_operator_stub,
        ), mock.patch(
            "task_groups.snowflake_unload_tasks.shared_snowflake_unload.EmptyOperator",
            side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=dag),
        ), mock.patch(
            "task_groups.snowflake_unload_tasks.shared_snowflake_unload.ShortCircuitOperator",
            side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=dag),
        ), mock.patch(
            "task_groups.snowflake_unload_tasks.shared_snowflake_unload.get_environment",
            return_value=environment,
        ), mock.patch(
            "task_groups.snowflake_unload_tasks.shared_snowflake_unload.get_emulation_run",
            return_value=emulation_run,
        ):
            with dag:
                # Act
                shared_snowflake_unload.task_group()

        return {call["task_id"]: call for call in operator_calls}

    # Arrange + Act: build task group with specified environment/emulation and capture operator calls.
    scenario_dag = DAG(
        dag_id=f"test_shared_snowflake_unload_{environment.lower()}_{str(emulation_run).lower()}",
        schedule=None,
        start_date=pendulum.datetime(2024, 1, 1),
    )
    by_task_id = _build_task_group_and_collect_operator_calls(environment, emulation_run, scenario_dag)
    campaign_booking_task = by_task_id["upload_campaign_booking_media_channel"]

    # Assert: verify params are set correctly for this scenario.
    assert "upload_campaign_booking_media_channel" in by_task_id, f"tasks found: {list(by_task_id)}"
    assert "unload_item_brand_hist" in by_task_id
    assert campaign_booking_task["sql"] == "pollen_sources/campaign_booking_media_channel.sql"
    assert campaign_booking_task["params"]["emulate_prod_env"] is emulation_run
    assert campaign_booking_task["params"]["is_prod"] is expected_is_prod


def test_overlapping_campaign_spend_weights_receives_brand_time_reference():
    """The SQL resolves items from dim_item_hist, so it needs the brand reference date."""
    operator_calls = []
    dag = DAG(
        dag_id="test_shared_snowflake_unload_brand_time_reference",
        schedule=None,
        start_date=pendulum.datetime(2024, 1, 1),
    )

    with mock.patch(
        "task_groups.snowflake_unload_tasks.shared_snowflake_unload.MeasurementSnowflakeOperator",
        side_effect=lambda **kwargs: (operator_calls.append(kwargs), EmptyOperator(task_id=kwargs["task_id"], dag=dag))[1],
    ), mock.patch(
        "task_groups.snowflake_unload_tasks.shared_snowflake_unload.EmptyOperator",
        side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=dag),
    ), mock.patch(
        "task_groups.snowflake_unload_tasks.shared_snowflake_unload.ShortCircuitOperator",
        side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=dag),
    ), mock.patch(
        "task_groups.snowflake_unload_tasks.shared_snowflake_unload.get_environment",
        return_value=DEV,
    ):
        with dag:
            shared_snowflake_unload.task_group()

    by_task_id = {call["task_id"]: call for call in operator_calls}

    for task_id in ("unload_item_brand_hist",):
        params = by_task_id[task_id]["params"]
        assert "configure_booking_reference_date" in params["brand_time_reference"], task_id
