from contextlib import ExitStack
from unittest import mock

from airflow.providers.standard.operators.empty import EmptyOperator
from helpers.constants import EvaluationPhase


SNOWFLAKE_TABLES = {
    "measurement_unified_campaign": "dtp",
    "measurement_unified_campaign_pollen": "pollen",
}


def test_baseline_setup_includes_configure_dag_run_source(test_dag):
    """Verifies configure_dag_run_source is called as part of the baseline setup task group."""
    start_task = EmptyOperator(task_id="job_flow_start_time", dag=test_dag)
    configured_campaigns = EmptyOperator(task_id="configured_campaigns", dag=test_dag)

    with ExitStack() as stack:
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.job_flow_start_time", return_value=start_task))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_correlation_id", return_value="corr-id"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_persist_dataset", return_value=False))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_snowflake_stage"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_compute_units"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_pipelines_version"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_snowflake_tables", return_value=SNOWFLAKE_TABLES))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_campaign_start_date"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_sns"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_campaigns", return_value=configured_campaigns))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_mlflow"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_dag_version"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_aws_user"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_master_instance_type"))
        mock_configure_model_start_end_dates = stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_model_start_end_dates"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_run_type", return_value="DTP"))
        mock_dag_run_source = stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_dag_run_source"))
        mock_campaign_end_date = stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_campaign_end_date"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_paths"))

        from task_groups import baseline_setup
        baseline_setup.task_group()

    mock_dag_run_source.assert_called_once_with()
    mock_configure_model_start_end_dates.assert_called_once_with(
        '{{data_interval_end | ds }}',
        '2022-01-01',
        end_date_conf_key='campaign_end_date',
        campaigns=configured_campaigns,
        run_type="DTP",
        snowflake_tables={"measurement_unified_campaign": "dtp", "measurement_unified_campaign_pollen": "pollen"},
    )
    mock_campaign_end_date.assert_called_once_with(
        '{{data_interval_end | ds }}',
        campaigns=configured_campaigns,
        run_type="DTP",
        snowflake_tables={"measurement_unified_campaign": "dtp", "measurement_unified_campaign_pollen": "pollen"},
    )


def test_baseline_setup_includes_configure_dag_run_source_post_period(test_dag):
    """Verifies configure_dag_run_source is called for POST period setup as well."""
    start_task = EmptyOperator(task_id="job_flow_start_time_post", dag=test_dag)
    configured_campaigns = EmptyOperator(task_id="configured_campaigns", dag=test_dag)

    with ExitStack() as stack:
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.job_flow_start_time", return_value=start_task))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_correlation_id", return_value="corr-id"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_persist_dataset", return_value=False))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_snowflake_stage"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_compute_units"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_pipelines_version"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_snowflake_tables", return_value=SNOWFLAKE_TABLES))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_campaign_start_date"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_sns"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_campaigns", return_value=configured_campaigns))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_mlflow"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_dag_version"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_aws_user"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_master_instance_type"))
        mock_configure_model_start_end_dates = stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_model_start_end_dates"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_run_type", return_value="DTP"))
        mock_dag_run_source = stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_dag_run_source"))
        mock_post_period_end_date = stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_post_period_end_date"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_ci_of_during_run"))
        stack.enter_context(mock.patch("task_groups.baseline_setup.setup.configure_paths"))

        from task_groups import baseline_setup
        baseline_setup.task_group(type=EvaluationPhase.POST)

    mock_dag_run_source.assert_called_once_with()
    mock_configure_model_start_end_dates.assert_called_once_with(
        '{{data_interval_end | ds }}',
        '2022-01-01',
        end_date_conf_key='post_period_end_date',
        campaigns=configured_campaigns,
        run_type="DTP",
        snowflake_tables={"measurement_unified_campaign": "dtp", "measurement_unified_campaign_pollen": "pollen"},
    )
    mock_post_period_end_date.assert_called_once_with(
        '{{data_interval_end | ds }}',
        campaigns=configured_campaigns,
        run_type="DTP",
        snowflake_tables={"measurement_unified_campaign": "dtp", "measurement_unified_campaign_pollen": "pollen"},
    )
