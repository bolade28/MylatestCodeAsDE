from unittest import mock

from airflow.providers.standard.operators.empty import EmptyOperator

from helpers.constants import DEFAULT_DAILY_ETL_MODEL_START_DATE
from task_groups import daily_etl_setup


def test_daily_etl_setup_calls_expected_setup_functions(test_dag):
    # Arrange
    start_task = EmptyOperator(task_id="job_flow_start_time", dag=test_dag)

    with mock.patch("task_groups.daily_etl_setup.setup.job_flow_start_time", return_value=start_task), mock.patch(
        "task_groups.daily_etl_setup.setup.configure_correlation_id",
        return_value="corr-id",
    ) as mock_ci, mock.patch(
        "task_groups.daily_etl_setup.setup.configure_paths"
    ) as mock_paths, mock.patch(
        "task_groups.daily_etl_setup.setup.configure_snowflake_tables"
    ) as mock_tables, mock.patch(
        "task_groups.daily_etl_setup.setup.configure_campaign_start_date"
    ) as mock_campaign_start, mock.patch(
        "task_groups.daily_etl_setup.setup.configure_model_start_end_dates"
    ) as mock_dates:
        # Act: build setup task group while capturing helper invocations.
        result = daily_etl_setup.task_group()

    # Assert: verify setup group id and that each setup helper is called with expected arguments.
    assert result.group_id == "setup_tasks"
    mock_ci.assert_called_once_with()
    mock_paths.assert_called_once()
    assert mock_paths.call_args.args[0] == "corr-id"
    assert "".join(mock_paths.call_args.args[1].split()) == "{{data_interval_end|ds}}"  # avoid brittle whitespace-only failures
    mock_tables.assert_called_once_with("corr-id", used_new_brand_logic=False)
    mock_campaign_start.assert_called_once_with()
    mock_dates.assert_called_once()
    assert "".join(mock_dates.call_args.args[0].split()) == "{{data_interval_end|ds}}"
    assert mock_dates.call_args.args[1] == DEFAULT_DAILY_ETL_MODEL_START_DATE
    assert mock_dates.call_args.args[2] is True
