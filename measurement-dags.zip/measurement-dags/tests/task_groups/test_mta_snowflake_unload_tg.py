from unittest import mock

import pendulum
import pytest
from airflow import DAG
from airflow.providers.standard.operators.empty import EmptyOperator

from helpers.constants import DEV, PROD
from task_groups.snowflake_unload_tasks import mta_snowflake_unload


@pytest.mark.parametrize("environment,emulation_run,expected_is_prod", [
    (DEV, True, False),
    (DEV, False, False),
    (PROD, True, True),
    (PROD, False, True),
])
def test_mta_snowflake_unload_passes_prod_emulation_params_to_dv360_pollen(environment, emulation_run, expected_is_prod):
    """Verifies dv360 pollen unload task passes params required by SQL Jinja condition."""
    def _build_task_group_and_collect_operator_calls(environment, emulation_run, dag):
        # Arrange: keep operator construction lightweight while capturing SQL operator inputs.
        operator_calls = []

        def _operator_stub(**kwargs):
            operator_calls.append(kwargs)
            return EmptyOperator(task_id=kwargs["task_id"], dag=dag)

        with mock.patch(
            "task_groups.snowflake_unload_tasks.mta_snowflake_unload.MeasurementSnowflakeOperator",
            side_effect=_operator_stub,
        ), mock.patch(
            "task_groups.snowflake_unload_tasks.mta_snowflake_unload.EmptyOperator",
            side_effect=lambda **kw: EmptyOperator(task_id=kw["task_id"], dag=dag),
        ), mock.patch(
            "task_groups.snowflake_unload_tasks.mta_snowflake_unload.get_environment",
            return_value=environment,
        ), mock.patch(
            "task_groups.snowflake_unload_tasks.mta_snowflake_unload.get_emulation_run",
            return_value=emulation_run,
        ):
            with dag:
                # Act
                mta_snowflake_unload.task_group()

        return {call["task_id"]: call for call in operator_calls}

    # Arrange + Act: build task group with specified environment/emulation and capture operator calls.
    scenario_dag = DAG(
        dag_id=f"test_mta_snowflake_unload_{environment.lower()}_{str(emulation_run).lower()}",
        schedule=None,
        start_date=pendulum.datetime(2024, 1, 1),
    )
    by_task_id = _build_task_group_and_collect_operator_calls(environment, emulation_run, scenario_dag)
    dv360_pollen_task = by_task_id["upload_dv360_normalize_pollen"]

    # Assert: verify params are set correctly for this scenario.
    assert "upload_dv360_normalize_pollen" in by_task_id, f"tasks found: {list(by_task_id)}"
    assert dv360_pollen_task["sql"] == "dv360_normalize/dv360_normalize_pollen.sql"
    assert dv360_pollen_task["params"]["emulate_prod_env"] is emulation_run
    assert dv360_pollen_task["params"]["is_prod"] is expected_is_prod
