from unittest import mock


def test_attribution_pre_requisite_task_group_returns_task_group(test_dag):
    """Verifies attribution pre-requisite task group is created with the expected id."""
    # Arrange
    # Patch step task factory to isolate TaskGroup construction.
    with mock.patch("task_groups.attribution_pre_requisite.attribution_pre_requisite"):

        from task_groups import attribution_pre_requisite

        # Act
        # Build the task group inside DAG context.
        tg = attribution_pre_requisite.task_group()

        # Assert
        # Verify the expected group id contract.
        assert tg is not None
        assert tg.group_id == "mta_attribution_pre_requisite"


def test_attribution_pre_requisite_task_names(test_dag):
    """Verifies attribution pre-requisite task names match expected step identifiers."""
    # Arrange
    # Patch task factory and capture call arguments.
    with mock.patch("task_groups.attribution_pre_requisite.attribution_pre_requisite") as mock_apr:

        from task_groups import attribution_pre_requisite

        # Act
        # Build the group and collect emitted step names.
        attribution_pre_requisite.task_group()

        # Assert
        # Ensure all expected pre-requisite task names are present.
        calls = mock_apr.tasks.call_args_list
        # Extract step_name from kwargs if present, otherwise from first positional arg
        step_names = [c.kwargs.get("step_name") or (c.args[0] if c.args else None) for c in calls]

        assert "AttributionPreRequisiteOffer" in step_names
        assert "AttributionPreRequisiteBrand" in step_names
        assert "AttributionPreRequisiteAisle" in step_names


def test_attribution_pre_requisite_journey_types(test_dag):
    """Verifies pre-requisite task calls cover offer, brand, and aisle journey types."""
    # Arrange
    # Patch task factory and inspect journey type arguments.
    with mock.patch("task_groups.attribution_pre_requisite.attribution_pre_requisite") as mock_apr:

        from task_groups import attribution_pre_requisite
        from helpers.constants import JOURNEY_TYPE

        # Act
        # Build the group and read journey types from call args.
        attribution_pre_requisite.task_group()

        # Assert
        # Verify all configured journey types are represented.
        calls = mock_apr.tasks.call_args_list
        # Extract journey_type from kwargs if present, otherwise from third positional arg
        journey_types = [c.kwargs.get("journey_type") or (c.args[2] if len(c.args) > 2 else None) for c in calls]

        assert JOURNEY_TYPE["offer"] in journey_types
        assert JOURNEY_TYPE["brand"] in journey_types
        assert JOURNEY_TYPE["aisle"] in journey_types


def test_attribution_pre_requisite_control_task_ids(test_dag):
    """Verifies control flow tasks (start, skip, finish, decide) exist with correct ids."""
    # Arrange
    # Patch task factory.
    with mock.patch("task_groups.attribution_pre_requisite.attribution_pre_requisite"):

        from task_groups import attribution_pre_requisite

        # Act
        # Build the task group.
        tg = attribution_pre_requisite.task_group()

        # Assert
        # Verify all control tasks are present (full qualified names).
        task_ids = [t.task_id for t in tg]
        assert any("start" in tid for tid in task_ids)
        assert any("skip" in tid for tid in task_ids)
        assert any("finish" in tid for tid in task_ids)
        assert any("decide_aisle_run" in tid for tid in task_ids)
