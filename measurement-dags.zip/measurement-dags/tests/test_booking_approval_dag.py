import importlib
from unittest import mock

import pendulum
import pytest

from helpers.booking_approval import (
    build_pre_check_map,
    empty_rows_sql,
    escape_sql,
    evaluate_pre_checks,
    in_clause,
    campaign_is_older_than_threshold,
)
from helpers.utils import normalize_ids


# ---------------------------------------------------------------------------
# normalize_ids
# ---------------------------------------------------------------------------

def test_normalize_booking_ids_handles_csv_string():
    assert normalize_ids("B1, B2 ,B3") == ["B1", "B2", "B3"]


def test_normalize_booking_ids_deduplicates():
    assert normalize_ids("B1,B2,B1") == ["B1", "B2"]


def test_normalize_booking_ids_handles_list_input():
    assert normalize_ids(["B1", "B2", "B1", ""]) == ["B1", "B2"]


def test_normalize_booking_ids_handles_tuple_input():
    assert normalize_ids(("B1", "B2")) == ["B1", "B2"]


def test_normalize_booking_ids_handles_none():
    assert normalize_ids(None) == []


def test_normalize_booking_ids_handles_empty_string():
    assert normalize_ids("") == []


def test_normalize_booking_ids_handles_numeric():
    assert normalize_ids(123) == ["123"]


# ---------------------------------------------------------------------------
# campaign_is_older_than_threshold
# ---------------------------------------------------------------------------

def test_campaign_is_older_than_threshold_true_when_equal_to_threshold():
    assert campaign_is_older_than_threshold("2026-07-01", "2026-07-08", 7) is True


def test_campaign_is_older_than_threshold_true_when_above_threshold():
    assert campaign_is_older_than_threshold("2026-06-01", "2026-07-08", 7) is True


def test_campaign_is_older_than_threshold_false_when_below_threshold():
    assert campaign_is_older_than_threshold("2026-07-02", "2026-07-08", 7) is False


def test_campaign_is_older_than_threshold_raises_on_invalid_date():
    with pytest.raises(ValueError):
        campaign_is_older_than_threshold("not-a-date", "2026-07-08", 7)


# ---------------------------------------------------------------------------
# _escape_sql
# ---------------------------------------------------------------------------

def test_escape_sql_replaces_single_quotes():
    assert escape_sql("O'Brien") == "O''Brien"


def test_escape_sql_no_quotes_unchanged():
    assert escape_sql("normal") == "normal"


def test_escape_sql_multiple_quotes():
    assert escape_sql("it's a 'test'") == "it''s a ''test''"


# ---------------------------------------------------------------------------
# _in_clause
# ---------------------------------------------------------------------------

def test_in_clause_single_value():
    assert in_clause(["A"]) == "'A'"


def test_in_clause_multiple_values():
    assert in_clause(["A", "B", "C"]) == "'A', 'B', 'C'"


def test_in_clause_escapes_quotes():
    assert in_clause(["O'Brien"]) == "'O''Brien'"


# ---------------------------------------------------------------------------
# _empty_rows_sql
# ---------------------------------------------------------------------------

def test_empty_rows_sql_is_no_op():
    sql = empty_rows_sql()
    assert "WHERE 1 = 0" in sql
    assert "booking_id" in sql
    assert "campaign_name" in sql
    assert "pipeline_stage" in sql


# ---------------------------------------------------------------------------
# booking pre-checks
# ---------------------------------------------------------------------------

def _make_pre_check_row(
    booking_id="B1",
    campaign_name="Campaign A",
    campaign_end_date="2026-07-01",
    category="01_store_cd_list",
    status="PASS",
    reason="STORE_CD_LIST is populated.",
):
    return [booking_id, campaign_name, campaign_end_date, category, status, reason]


def test_build_pre_check_map_groups_results_by_booking():
    result = build_pre_check_map([
        _make_pre_check_row(category="01_store_cd_list"),
        _make_pre_check_row(category="02_campaign_id"),
    ])

    assert result["B1"]["campaign_name"] == "Campaign A"
    assert len(result["B1"]["checks"]) == 2


def test_evaluate_pre_checks_promotes_when_all_checks_pass_or_warn():
    rows = [
        _make_pre_check_row(status="PASS"),
        _make_pre_check_row(category="08_dates_align_to_unified_campaign", status="WARNING"),
    ]

    promoted, rejected, approved_sql, approved_params = evaluate_pre_checks(
        ["B1"], rows, RUN_DATE, THRESHOLD
    )

    assert [item["booking_id"] for item in promoted] == ["B1"]
    assert rejected == []
    assert approved_sql.count("%s") == len(approved_params) == 6
    assert approved_params[:3] == ["B1", "Campaign A", "During"]
    assert approved_params[3:] == ["B1", "Campaign A", "Post"]


def test_evaluate_pre_checks_promotes_passing_bookings_when_one_of_three_fails():
    rows = [
        _make_pre_check_row(booking_id="B1", campaign_name="Campaign 1"),
        _make_pre_check_row(
            booking_id="B2", campaign_name="Campaign 2", status="FAIL", reason="STORE_CD_LIST is missing."
        ),
        _make_pre_check_row(booking_id="B3", campaign_name="Campaign 3"),
    ]

    promoted, rejected, approved_sql, approved_params = evaluate_pre_checks(
        ["B1", "B2", "B3"], rows, RUN_DATE, THRESHOLD
    )

    assert [item["booking_id"] for item in promoted] == ["B1", "B3"]
    assert [(item["booking_id"], item["reason"]) for item in rejected] == [("B2", "STORE_CD_LIST is missing.")]
    assert approved_sql.count("%s") == len(approved_params) == 12
    assert approved_params == [
        "B1", "Campaign 1", "During", "B1", "Campaign 1", "Post",
        "B3", "Campaign 3", "During", "B3", "Campaign 3", "Post",
    ]


def test_evaluate_pre_checks_records_each_failed_check_and_blocks_tracker_rows():
    rows = [
        _make_pre_check_row(status="FAIL", reason="STORE_CD_LIST is missing."),
        _make_pre_check_row(
            category="02_campaign_id",
            status="FAIL",
            reason="CAMPAIGN_ID is null or -1.",
        ),
    ]

    promoted, rejected, approved_sql, approved_params = evaluate_pre_checks(
        ["B1"], rows, RUN_DATE, THRESHOLD
    )

    assert promoted == []
    assert [item["category"] for item in rejected] == ["01_store_cd_list", "02_campaign_id"]
    assert "WHERE 1 = 0" in approved_sql
    assert [item["reason"] for item in rejected] == [
        "STORE_CD_LIST is missing.",
        "CAMPAIGN_ID is null or -1.",
    ]


def test_evaluate_pre_checks_records_booking_not_found():
    promoted, rejected, approved_sql, approved_params = evaluate_pre_checks(
        ["MISSING"], [], RUN_DATE, THRESHOLD
    )

    assert promoted == []
    assert rejected == [{
        "booking_id": "MISSING",
        "stage": "PROMOTION",
        "category": "booking_not_found",
        "reason": "Booking not found in BDV.",
    }]
    assert "WHERE 1 = 0" in approved_sql


def test_evaluate_pre_checks_records_date_threshold_failure():
    rows = [_make_pre_check_row(campaign_end_date="2026-07-10")]

    promoted, rejected, approved_sql, approved_params = evaluate_pre_checks(
        ["B1"], rows, RUN_DATE, THRESHOLD
    )

    assert promoted == []
    assert rejected[0]["category"] == "campaign_end_date_threshold"
    assert "WHERE 1 = 0" in approved_sql


def test_evaluate_pre_checks_records_invalid_campaign_end_date():
    rows = [_make_pre_check_row(campaign_end_date="not-a-date")]

    promoted, rejected, approved_sql, approved_params = evaluate_pre_checks(
        ["B1"], rows, RUN_DATE, THRESHOLD
    )

    assert promoted == []
    assert rejected == [{
        "booking_id": "B1",
        "stage": "PROMOTION",
        "category": "invalid_campaign_end_date",
        "reason": "Campaign end date cannot be parsed.",
    }]
    assert "WHERE 1 = 0" in approved_sql


RUN_DATE = "2026-07-15"
THRESHOLD = 7
# ---------------------------------------------------------------------------
# DAG smoke test
# ---------------------------------------------------------------------------


def test_booking_approval_dag_import_and_instantiation():
    with mock.patch.dict("os.environ", AIRFLOW_VAR_MEASUREMENT_ENVIRONMENT="dev"):
        mod = importlib.import_module("booking_approval_dag")
        importlib.reload(mod)
        dag = mod.booking_approval_dag()

    assert hasattr(mod, "booking_approval_dag")
    assert callable(mod.booking_approval_dag)
    assert dag.dag_id == "booking_approval_dag"
    assert dag.schedule is None
    assert "booking_ids" in dag.params
    assert "during_min_days_after_end" in dag.params

    insert_approved_rows = dag.get_task("insert_approved_tracker_rows")
    assert insert_approved_rows.params["booking_status"] == "READY"
    assert "campaign_duration" in dag.params
    assert dag.get_task("query_candidate_bookings").sql == "booking_approval/run_pre_checks.sql"
    assert "insert_approved_tracker_rows" in dag.get_task("notify_booking_promotion").upstream_task_ids
    assert "record_failed_pre_checks" not in dag.task_ids
    assert "create_booking_promotion_failure_table" not in dag.task_ids
    assert "notify_booking_promotion" in dag.task_ids


# ---------------------------------------------------------------------------
# DAG tasks
# ---------------------------------------------------------------------------

@pytest.fixture
def dag_module():
    with mock.patch.dict("os.environ", AIRFLOW_VAR_MEASUREMENT_ENVIRONMENT="dev"):
        yield importlib.import_module("booking_approval_dag")


def test_prepare_approval_inputs_normalises_ids_and_builds_in_clause(dag_module):
    result = dag_module.prepare_approval_inputs.function("B1, B2,B1")

    assert result == {"booking_ids": ["B1", "B2"], "booking_ids_sql": "'B1', 'B2'"}


@pytest.mark.parametrize("booking_ids", ["", None, []])
def test_prepare_approval_inputs_raises_when_no_booking_ids(dag_module, booking_ids):
    with pytest.raises(ValueError, match="No booking IDs provided"):
        dag_module.prepare_approval_inputs.function(booking_ids)


def test_evaluate_candidate_bookings_promotes_passing_and_rejects_failing(dag_module):
    rows = [
        _make_pre_check_row(booking_id="B1", campaign_name="Campaign 1"),
        _make_pre_check_row(booking_id="B2", campaign_name="Campaign 2", status="FAIL", reason="STORE_CD_LIST is missing."),
    ]
    context = {"data_interval_end": pendulum.parse(RUN_DATE)}

    with mock.patch.object(dag_module, "get_current_context", return_value=context):
        result = dag_module.evaluate_candidate_bookings.function(["B1", "B2"], rows, "7")

    summary = result["summary"]
    assert summary["requested"] == ["B1", "B2"]
    assert summary["threshold_days"] == 7
    assert summary["run_date"] == RUN_DATE
    assert [item["booking_id"] for item in summary["promoted"]] == ["B1"]
    assert [item["booking_id"] for item in summary["rejected"]] == ["B2"]
    assert summary["approved_row_candidates"] == 2
    assert result["approved_row_params"] == ["B1", "Campaign 1", "During", "B1", "Campaign 1", "Post"]
    assert result["approved_rows_sql"].count("%s") == 6


def _run_notify(dag_module, summary):
    context = {"ti": mock.Mock(xcom_pull=mock.Mock(return_value="corr-1"))}
    with mock.patch.object(dag_module, "get_current_context", return_value=context), \
            mock.patch.object(dag_module, "get_environment", return_value="dev"), \
            mock.patch.object(dag_module, "SlackAPIPostOperator") as slack:
        dag_module.notify_booking_promotion.function(summary)
    return slack


def test_notify_booking_promotion_lists_promoted_and_rejected_bookings(dag_module):
    summary = {
        "run_date": RUN_DATE,
        "threshold_days": THRESHOLD,
        "promoted": [{"booking_id": "B1", "campaign_name": "Campaign 1"}],
        "rejected": [
            {"booking_id": "B2", "stage": "PROMOTION", "category": "07_booking_media_budget",
             "reason": "FAIL — CUMULATIVE_BILLABLE_SPEND_AMT is null or 0 for: A | B"},
            {"booking_id": "B2", "stage": "PROMOTION", "category": "13_overlapping_campaigns",
             "reason": "FAIL — Booking overlaps with: B9"},
            {"booking_id": "B3", "stage": "PROMOTION", "category": "booking_not_found",
             "reason": "Booking not found in BDV."},
        ],
    }

    slack = _run_notify(dag_module, summary)

    assert slack.call_args.kwargs["channel"] == "#measurement-data-dev"
    text = slack.call_args.kwargs["text"]
    assert text.splitlines()[0] == ":warning: *Booking Promotion* — 1 promoted, 2 rejected"
    assert ":white_check_mark: B1 - Campaign 1" in text
    assert ":x: B2" in text
    assert "07_booking_media_budget: CUMULATIVE_BILLABLE_SPEND_AMT is null or 0 for campaign_id's" in text
    assert "13_overlapping_campaigns: Booking overlaps with: B9" in text
    assert ":x: B3 — not found in BDV" in text
    assert "A | B" not in text
    assert "Run 2026-07-15 · Threshold 7 days (During) · Correlation corr-1" in text
    slack.return_value.execute.assert_called_once()


def test_notify_booking_promotion_reports_success_when_nothing_rejected(dag_module):
    summary = {
        "run_date": RUN_DATE,
        "threshold_days": THRESHOLD,
        "promoted": [{"booking_id": "B1", "campaign_name": "Campaign 1"}],
        "rejected": [],
    }

    text = _run_notify(dag_module, summary).call_args.kwargs["text"]

    assert text.splitlines()[0] == ":white_check_mark: *Booking Promotion* — 1 promoted, 0 rejected"
    assert ":x:" not in text


@pytest.mark.parametrize("reason, expected", [
    ("FAIL — CAMPAIGN_ID is null or -1.", "CAMPAIGN_ID is null or -1."),
    ("FAIL — BOOKING_MEDIA_BUDGET_AMT is null or 0 for: A | B", "BOOKING_MEDIA_BUDGET_AMT is null or 0 for campaign_id's"),
    ("Booking not found in BDV.", "Booking not found in BDV."),
])
def test_format_slack_reason(dag_module, reason, expected):
    assert dag_module.format_slack_reason(reason) == expected
