import pathlib

from helpers.constants import PROD
from helpers.tables import Snowflake
from jinja2 import Environment


def _render(correlation_id: str = "ci-prod-render-00000001") -> str:
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/mta_tables_setup/post_campaign_period/post_campaign_period.sql"
    prod_table_map = Snowflake(correlation_id=correlation_id, env=PROD, emulation_run=False).tables
    env = Environment()
    template = env.from_string(sql_path.read_text())
    return template.render(
        params={"correlation_id": correlation_id},
        get_table=lambda name: prod_table_map[name],
    )


def test_template_fully_renders():
    """No unresolved Jinja tokens remain after rendering."""
    rendered = _render()
    assert "{{" not in rendered
    assert "{%" not in rendered


def test_item_brand_hist_is_brand_source():
    """ITEM_BRAND_HIST is the brand lookup; EAN_BR and its CTEs must be absent."""
    rendered = _render()
    assert "ITEM_BRAND_HIST" in rendered
    assert "EAN_BR" not in rendered
    assert "filtered_ean" not in rendered
    assert "get_brand_data" not in rendered


def test_key_ctes_present():
    """item_brand_hist and transaction_df CTEs must exist in the rendered SQL."""
    rendered = _render()
    assert "item_brand_hist as (" in rendered
    assert "transaction_df as (" in rendered


def test_insert_target_resolves_to_prod_table():
    """INSERT target must resolve to the prod measurement post-campaign-period table."""
    rendered = _render()
    assert "UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_POST_CAMPAIGN_PERIOD" in rendered


def test_correlation_id_is_rendered():
    """correlation_id param is substituted into the final SELECT."""
    rendered = _render(correlation_id="test-corr-id-123")
    assert "test-corr-id-123" in rendered
