import pathlib

from jinja2 import Environment, StrictUndefined


def _render_campaign_product_type(*, is_prod: bool) -> str:
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    template_path = root_dir / "dags/templates/sql/daily_etl/campaign_product_type_new_brand_logic.sql"
    env = Environment(undefined=StrictUndefined)

    with template_path.open("r") as template_file:
        template = env.from_string(template_file.read())

    return template.render(
        params={
            "pollen_type": "pollen",
            "dtp_type": "dtp",
            "emulation_type": "prod_emulation",
            "is_prod": is_prod,
            "correlation_id": "test-correlation-id",
        },
        get_table=lambda table_name: f"DEV_DB.PUBLIC.{table_name}",
    )


def test_campaign_product_type_includes_prod_emulation_cte():
    """prod_emulation_campaigns CTE is present and keeps the prod pollen source."""
    rendered_sql = _render_campaign_product_type(is_prod=False)

    assert "prod_emulation_campaigns" in rendered_sql
    assert "DEV_DB.PUBLIC.measurement_unified_campaign_pollen_prod" in rendered_sql
    assert "DEV_DB.PUBLIC.campaign_booking_media_channel_prod" in rendered_sql


def test_campaign_product_type_dev_includes_emulation_rows():
    """When is_prod=False, AND NOT False evaluates to True — emulation rows are included."""
    rendered_sql = _render_campaign_product_type(is_prod=False)

    assert "AND NOT False" in rendered_sql


def test_campaign_product_type_prod_guard_excludes_emulation_rows():
    """When is_prod=True, AND NOT True evaluates to False — emulation CTE returns zero rows in PROD."""
    rendered_sql = _render_campaign_product_type(is_prod=True)

    assert "AND NOT True" in rendered_sql


def test_campaign_product_type_all_three_paths_unioned():
    """campaign_items union includes pollen, prod_emulation, and non_pollen (DTP)."""
    rendered_sql = _render_campaign_product_type(is_prod=False)

    assert "SELECT * FROM pollen_items" in rendered_sql
    assert "SELECT * FROM prod_emulation_items" in rendered_sql
    assert "SELECT * FROM non_pollen_items" in rendered_sql


def test_campaign_product_type_uses_item_brand_hist_not_unified_products():
    """Brand and item attributes now come from ITEM_BRAND_HIST, DIM_ITEM_HIST, and CBMC sources."""
    rendered_sql = _render_campaign_product_type(is_prod=False)

    assert "DEV_DB.PUBLIC.item_brand_hist" in rendered_sql
    assert "DEV_DB.PUBLIC.dim_item_hist" in rendered_sql
    assert "DEV_DB.PUBLIC.campaign_booking_media_channel" in rendered_sql
    assert "FROM DEV_DB.PUBLIC.dim_item\n" not in rendered_sql
    assert "DEV_DB.PUBLIC.unified_products" not in rendered_sql


def test_campaign_product_type_filters_item_brand_hist_before_ranking():
    """Deleted or blank brand rows should be removed before ROW_NUMBER picks the latest slice."""
    rendered_sql = _render_campaign_product_type(is_prod=False)

    assert "WHERE COALESCE(technical_metadata:record_deleted_flag::VARCHAR, 'N') = 'N'" in rendered_sql
    assert "AND NULLIF(TRIM(unique_brand_name), '') IS NOT NULL" in rendered_sql
    assert rendered_sql.index("WHERE COALESCE(technical_metadata:record_deleted_flag::VARCHAR, 'N') = 'N'") < rendered_sql.index("QUALIFY ROW_NUMBER() OVER (")
