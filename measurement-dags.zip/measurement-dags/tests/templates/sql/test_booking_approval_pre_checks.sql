-- Scenario test for booking approval checks 11 and 12.
-- Run in Snowflake; every row should return TEST_RESULT = 'PASS'.
WITH test_run_date AS (
    SELECT '2026-10-02'::DATE AS run_date
),
scenarios AS (
    SELECT '11_prod_no_reporting_row' AS scenario_id, '11' AS check_id,
        'BOOK_11A' AS booking_id, 'prod' AS environment, FALSE AS emulation_run,
        'During' AS campaign_duration, 'PASS' AS expected_status
    UNION ALL SELECT '11_prod_matching_during_row', '11',
        'BOOK_11B', 'prod', FALSE, 'During', 'FAIL'
    UNION ALL SELECT '11_prod_post_row_but_during_selected', '11',
        'BOOK_11C', 'prod', FALSE, 'During', 'PASS'
    UNION ALL SELECT '11_prod_matching_post_row', '11',
        'BOOK_11D', 'prod', FALSE, 'Post', 'FAIL'
    UNION ALL SELECT '11_non_prod_matching_row', '11',
        'BOOK_11E', 'dev', TRUE, 'During', 'PASS'
    UNION ALL SELECT '12_emulated_stale_extract', '12',
        'BOOK_12A', 'dev', TRUE, 'During', 'SKIPPED'
    UNION ALL SELECT '12_production_post_stale_extract', '12',
        'BOOK_12F', 'prod', FALSE, 'Post', 'SKIPPED'
    UNION ALL SELECT '12_no_during_extract', '12',
        'BOOK_12B', 'dev', TRUE, 'Post', 'SKIPPED'
    UNION ALL SELECT '12_extract_21_days_old', '12',
        'BOOK_12C', 'dev', TRUE, 'Post', 'FAIL'
    UNION ALL SELECT '12_extract_exactly_20_days_old', '12',
        'BOOK_12D', 'dev', TRUE, 'Post', 'PASS'
    UNION ALL SELECT '12_extract_19_days_old', '12',
        'BOOK_12E', 'dev', TRUE, 'Post', 'PASS'
),
reporting_rows AS (
    SELECT 'BOOK_11B' AS booking_id, 'During' AS campaign_duration,
        '2026-10-01'::TIMESTAMP_NTZ AS load_ts
    UNION ALL SELECT 'BOOK_11C', 'Post', '2026-10-01'::TIMESTAMP_NTZ
    UNION ALL SELECT 'BOOK_11D', 'Post', '2026-10-01'::TIMESTAMP_NTZ
    UNION ALL SELECT 'BOOK_11E', 'During', '2026-10-01'::TIMESTAMP_NTZ
    UNION ALL SELECT 'BOOK_12A', 'During', DATEADD('DAY', -21, '2026-10-02'::DATE)
    UNION ALL SELECT 'BOOK_12C', 'During', DATEADD('DAY', -21, '2026-10-02'::DATE)
    UNION ALL SELECT 'BOOK_12D', 'During', DATEADD('DAY', -20, '2026-10-02'::DATE)
    UNION ALL SELECT 'BOOK_12E', 'During', DATEADD('DAY', -19, '2026-10-02'::DATE)
),
check_11_results AS (
    SELECT
        s.scenario_id,
        s.expected_status,
        CASE
            WHEN LOWER(s.environment) != 'prod' THEN 'PASS'
            WHEN COUNT_IF(r.booking_id IS NULL) > 0 THEN 'PASS'
            ELSE 'FAIL'
        END AS actual_status
    FROM scenarios AS s
    LEFT JOIN reporting_rows AS r
        ON s.booking_id = r.booking_id
        AND UPPER(r.campaign_duration) = UPPER(s.campaign_duration)
    WHERE s.check_id = '11'
    GROUP BY
        s.scenario_id,
        s.expected_status,
        s.booking_id,
        s.environment,
        s.campaign_duration
),
latest_during_reporting AS (
    SELECT booking_id, MAX(load_ts) AS load_ts
    FROM reporting_rows
    WHERE UPPER(campaign_duration) = 'DURING'
    GROUP BY booking_id
),
check_12_results AS (
    SELECT
        s.scenario_id,
        s.expected_status,
        CASE
            WHEN NOT s.emulation_run OR UPPER(s.campaign_duration) != 'POST' THEN 'SKIPPED'
            WHEN latest.load_ts IS NULL THEN 'SKIPPED'
            WHEN DATEDIFF('DAY', latest.load_ts, test_run_date.run_date) > 20 THEN 'FAIL'
            ELSE 'PASS'
        END AS actual_status
    FROM scenarios AS s
    CROSS JOIN test_run_date
    LEFT JOIN latest_during_reporting AS latest
        ON s.booking_id = latest.booking_id
    WHERE s.check_id = '12'
),
all_results AS (
    SELECT * FROM check_11_results
    UNION ALL
    SELECT * FROM check_12_results
)
SELECT
    scenario_id,
    expected_status,
    actual_status,
    IFF(actual_status = expected_status, 'PASS', 'FAIL') AS test_result
FROM all_results
ORDER BY scenario_id;