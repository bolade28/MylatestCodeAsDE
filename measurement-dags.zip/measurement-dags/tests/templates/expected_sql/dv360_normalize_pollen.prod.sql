-- Select only the columns needed for DV360 normalization
SELECT
    booking_id,
    campaign_id,
    booking_media_live_start_dt,
    booking_media_live_end_dt,
    booking_media_budget_amt,
    channel_type,
    media_provider,
    booking_status,
    media_business_group,
    replace(replace(f.value,'{"skuId":',''),'}','')::VARCHAR as sku_id
FROM ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR AS aal,
LATERAL FLATTEN(input => aal.booking_item_cd_list) f
WHERE aal.booking_item_cd_list IS NOT NULL
AND json_extract_path_text(f.value,'skuId') IS NOT NULL

-- TODO:: there is also a risk that new test bookings/brands may be added that are not in the hardcoded list.
-- Production only: exclude bookings with 'test' in their name or associated with test brands
AND aal.TEST_BOOKING_FLAG != 'Y'