with
-- Mirrors the helper logic to pin the booking reference date to a single date per booking
booking_reference_source AS (
    SELECT
        booking_id,
        MIN(booking_media_live_start_dt) AS booking_start_dt,
        ANY_VALUE(booking_item_cd_list) AS booking_item_cd_list
    FROM 
        ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR
    
    GROUP BY booking_id
),
booking_reference_dates AS (
    SELECT
        booking_id,
        MAX(
            COALESCE(
                TO_TIMESTAMP_NTZ(TRY_TO_NUMBER(json_extract_path_text(flattened.value, 'addedOn')), 3),
                booking_start_dt
            )::DATE
        ) AS booking_reference_dt
    FROM booking_reference_source
    , LATERAL FLATTEN(input => booking_item_cd_list, OUTER => TRUE) AS flattened
    GROUP BY booking_id
),
campaign_data AS (
    SELECT
        campaign_id,
        booking_media_live_start_dt AS campaign_start_dt,
        booking_media_live_end_dt AS campaign_end_dt,
        case
            when booking_status = 'COMPLETED'
                and cumulative_billable_spend_amt IS NOT NULL
                and cumulative_billable_spend_amt != 0
            then cumulative_billable_spend_amt
            else booking_media_budget_amt
        end AS budget_amt,
        case
            when booking_status = 'COMPLETED'
                and cumulative_billable_spend_amt is not NULL
                and cumulative_billable_spend_amt != 0
            then 'CUMULATIVE_BILLABLE_SPEND_AMT'
            else 'BOOKING_MEDIA_BUDGET_AMT'
        end AS media_spend_source,
        marketing_subchannel AS subchannel_name,
        json_extract_path_text(out.value,'skuId') AS items,
        booking_reference_dates.booking_reference_dt,
        aal.booking_id,
        channel_type AS marketing_type,
        marketing_channel AS channel_name,
        booking_name AS campaign_name,
        partner_id,
        advertiser_id,
        advertiser_name,
        marketing_hierarchy_cd
    FROM 
        ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR
     AS aal
    INNER JOIN booking_reference_dates
        ON booking_reference_dates.booking_id = aal.booking_id
    , lateral flatten(input => aal.booking_item_cd_list) AS out
    where
        campaign_id !='-1'
        and booking_status IN ('COMPLETED','ACTIVE')
        and marketing_channel!='-1'
        and marketing_subchannel!='-1'
        and channel_type !='-1'
        and booking_media_live_start_dt is not null
        and booking_media_live_end_dt is not null
        -- Add null checks to filter out invalid skuIds
        and booking_item_cd_list is not null
        and json_extract_path_text(out.value,'skuId') is not null
        and NOT EXISTS (
            SELECT 1
            FROM UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.POLLEN_BOOKINGS_BLACKLIST_AWS AS b
            WHERE
                b.booking_id = aal.booking_id or
                b.campaign_id = aal.campaign_id
        )
        
        -- Prod or prod-emulation mode: exclude test bookings.
        -- This keeps the canonical production dataset clean from test traffic.
        and aal.TEST_BOOKING_FLAG != 'Y'
        
),
-- Brand source A: strategic ITEM_BRAND_HIST lookup (used for all non-legacy bookings)
item_brand_hist AS (
    SELECT
        item_cd,
        valid_from_dt,
        valid_until_dt,
        brand_name,
        brand_owner_name
    FROM UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    WHERE
        coalesce(technical_metadata:record_deleted_flag::varchar, 'N') = 'N'
        AND NULLIF(TRIM(brand_name), '') IS NOT NULL
        AND NULLIF(TRIM(brand_owner_name), '') IS NOT NULL
    QUALIFY row_number() OVER (
        PARTITION BY item_cd, valid_from_dt
        ORDER BY load_ts DESC
    ) = 1
),
-- Fallback brand for pre-history bookings: earliest available ITEM_BRAND_HIST row per SKU.
item_brand_hist_earliest AS (
    SELECT
        item_cd,
        brand_name,
        brand_owner_name
    FROM item_brand_hist
    QUALIFY row_number() OVER (
        PARTITION BY item_cd
        ORDER BY valid_from_dt ASC, valid_until_dt ASC
    ) = 1
),
-- Brand source B: legacy EAN_BR lookup, only applied to bookings in legacy_brand_booking_registry (see brand_data below)
legacy_ean_br_latest AS (
    -- most recent active EAN_BR load per item, mirrors the historical filtered_ean logic
    SELECT
        item_nk1,
        max(load_ts) AS max_ts
    FROM UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.EAN_BR
    WHERE
        valid_to_dt = '9999-12-31'
        AND record_deleted_flag <> 'Y'
    GROUP BY 1
),
legacy_ean_br_brand AS (
    SELECT
        fe.item_nk1 AS item_cd,
        eb.brand_name,
        eb.brand_owner_name
    FROM legacy_ean_br_latest AS fe
    INNER JOIN UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.EAN_BR AS eb
        ON fe.item_nk1 = eb.item_nk1
        AND fe.max_ts = eb.load_ts
    WHERE
        eb.valid_to_dt = '9999-12-31'
        AND eb.record_deleted_flag <> 'Y'
),
brand_data AS (
    SELECT
        es.booking_id,
        es.campaign_id,
        es.channel_name,
        es.subchannel_name,
        es.items,
        COALESCE(
            legacy_brand.brand_name,
            new_brand.brand_name,
            fallback_new_brand.brand_name
        ) AS brand_name,
        COALESCE(
            legacy_brand.brand_owner_name,
            new_brand.brand_owner_name,
            fallback_new_brand.brand_owner_name
        ) AS brand_owner_name
    FROM campaign_data AS es
    -- legacy_brand_booking_registry membership is the single source of truth for the brand-source
    -- decision per booking: present -> legacy EAN_BR, absent -> ITEM_BRAND_HIST (see registry SQL
    -- for how/when a booking enters and leaves this list).
    LEFT JOIN UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.LEGACY_BRAND_BOOKING_REGISTRY_AWS AS registered_legacy_booking
        ON registered_legacy_booking.booking_id = es.booking_id
    LEFT JOIN legacy_ean_br_brand AS legacy_brand
        ON registered_legacy_booking.booking_id IS NOT NULL
        AND es.items = legacy_brand.item_cd
    LEFT JOIN item_brand_hist AS new_brand
        ON registered_legacy_booking.booking_id IS NULL
        AND es.items = new_brand.item_cd
        AND es.booking_reference_dt
            BETWEEN new_brand.valid_from_dt AND new_brand.valid_until_dt
    -- Exact-date matches above take precedence; otherwise use the earliest known brand.
    LEFT JOIN item_brand_hist_earliest AS fallback_new_brand
        ON registered_legacy_booking.booking_id IS NULL
        AND new_brand.item_cd IS NULL
        AND es.items = fallback_new_brand.item_cd
    QUALIFY row_number() OVER (
        PARTITION BY
            es.booking_id,
            es.campaign_id,
            es.channel_name,
            es.subchannel_name,
            es.items
        ORDER BY
            new_brand.valid_from_dt DESC,
            new_brand.valid_until_dt DESC
    ) = 1
),
-- get the item level details for each sku
campaign_items AS (
    SELECT
        es.booking_id,
        es.campaign_id,
        es.items,
        es.channel_name,
        es.subchannel_name,
        COALESCE(legacy_item.super_cat_name, current_item.super_cat_name) AS super_cat_name,
        COALESCE(legacy_item.sub_cat_name, current_item.sub_cat_name) AS sub_cat_name,
        bd.brand_name,
        concat(trim(bd.brand_name), ' | ', trim(bd.brand_owner_name)) AS unique_brand_name,
        es.marketing_hierarchy_cd
    FROM campaign_data AS es
    LEFT JOIN brand_data AS bd
        ON es.booking_id = bd.booking_id
        AND es.campaign_id = bd.campaign_id
        AND es.channel_name = bd.channel_name
        AND es.subchannel_name = bd.subchannel_name
        AND es.items = bd.items
    -- Registry membership keeps the legacy EAN_BR and DIM_ITEM paths aligned.
    LEFT JOIN UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.LEGACY_BRAND_BOOKING_REGISTRY_AWS AS registered_legacy_booking
        ON registered_legacy_booking.booking_id = es.booking_id
    LEFT JOIN ADW_PROD.ADW_PRODUCT_PL.DIM_ITEM AS legacy_item
        ON registered_legacy_booking.booking_id IS NOT NULL
        AND es.items = legacy_item.item_cd
    LEFT JOIN ADW_PROD.ADW_PRODUCT_PL.DIM_ITEM_HIST AS current_item
        ON registered_legacy_booking.booking_id IS NULL
        AND es.items = current_item.item_cd
        AND es.booking_reference_dt
            BETWEEN current_item.valid_from_dt AND current_item.valid_until_dt
),
campaign_result AS (
    SELECT
        cd.booking_id,
        cd.campaign_id,
        cd.marketing_type,
        cd.channel_name,
        cd.campaign_name,
        cd.campaign_start_dt,
        cd.subchannel_name,
        cd.budget_amt AS media_spend_amt,
        cd.media_spend_source,
        cd.campaign_end_dt,
        partner_id,
        advertiser_id,
        advertiser_name,
        cd.marketing_hierarchy_cd,
        listagg(DISTINCT ci.items, ',') WITHIN GROUP (ORDER BY ci.items) AS item_cd_list,
        listagg(DISTINCT ci.unique_brand_name, ',') within GROUP (ORDER BY ci.unique_brand_name) AS unique_brand_name,
        listagg(DISTINCT ci.super_cat_name, ',') within GROUP (ORDER BY ci.super_cat_name) AS super_category_name,
        listagg(DISTINCT ci.sub_cat_name, ',') within GROUP (ORDER BY ci.sub_cat_name) AS sub_category_name
    FROM campaign_data cd
    INNER join campaign_items ci
    ON cd.campaign_id = ci.campaign_id AND cd.channel_name = ci.channel_name AND cd.subchannel_name = ci.subchannel_name
    WHERE cd.campaign_id!='~~'
    GROUP BY
        cd.marketing_type,
        cd.channel_name,
        cd.campaign_id,
        cd.campaign_name,
        cd.campaign_start_dt,
        cd.campaign_end_dt,
        cd.subchannel_name,
        cd.budget_amt,
        cd.media_spend_source,
        cd.booking_id,
        partner_id,
        advertiser_id,
        advertiser_name,
        cd.marketing_hierarchy_cd
),
get_single_brand_records AS (
    SELECT * FROM campaign_result
    WHERE unique_brand_name not ilike '%,%'
),
get_skus_for_post_campaign AS (
    SELECT
        gnr.campaign_id
        , gnr.item_cd_list
        , gnr.channel_name
        , gnr.subchannel_name
        , sku_list.value::integer AS item
    FROM get_single_brand_records AS gnr
    , lateral flatten(input => split(gnr.item_cd_list, ',')) AS sku_list
),
get_post_campaign_period AS (
    SELECT
        gns.campaign_id
        , gns.channel_name
        , gns.subchannel_name
        , max(pcp.median_proposed_bucket_wk) AS post_campaign_wk
    FROM get_skus_for_post_campaign AS gns
    INNER JOIN UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_POST_CAMPAIGN_PERIOD AS pcp
        ON gns.item = pcp.item_cd
    WHERE pcp.year_of_transaction = (SELECT year(current_date()) - 1)
    GROUP by 1, 2, 3
),
combined_unified_campaign AS (
    SELECT
        gnr.campaign_id,
        gnr.media_spend_amt,
        gnr.media_spend_source,
        gnr.campaign_start_dt,
        gnr.campaign_end_dt,
        gnr.item_cd_list,
        gnr.super_category_name,
        gnr.sub_category_name,
        gnr.channel_name,
        gnr.campaign_name,
        gnr.marketing_type,
        gnr.unique_brand_name,
        gnr.booking_id,
        gnr.subchannel_name,
        case
            when gpcp.post_campaign_wk is null then dateadd('DAY', 42, gnr.campaign_end_dt)
            else dateadd('DAY', gpcp.post_campaign_wk * 7, gnr.campaign_end_dt)
        end AS post_campaign_dt,
        partner_id,
        advertiser_id,
        advertiser_name,
        gnr.marketing_hierarchy_cd
    FROM get_single_brand_records AS gnr
    LEFT JOIN get_post_campaign_period AS gpcp
        on
            gnr.campaign_id = gpcp.campaign_id
            and gnr.channel_name = gpcp.channel_name
            and gnr.subchannel_name = gpcp.subchannel_name
),
check_multi_channel AS (
    SELECT
        *,
        count(DISTINCT channel_name) over (partition by booking_id) AS channel_count,
        count(DISTINCT subchannel_name) over (partition by booking_id) AS subchannel_count
    FROM combined_unified_campaign
),
apply_is_multichannel AS (
    SELECT DISTINCT
        cuc.*
        , case
            when cmc.channel_count > 1 then true
            when cmc.channel_count = 1 and cmc.subchannel_count > 1 then true
            when cmc.channel_count = 1 and cmc.channel_name not in ('Onsite-GOL') then false
            else false
        end AS is_multi_channel
    FROM combined_unified_campaign AS cuc
    INNER JOIN check_multi_channel AS cmc
        on
            cuc.booking_id = cmc.booking_id
            and cuc.campaign_id = cmc.campaign_id
            and cuc.campaign_start_dt = cmc.campaign_start_dt
            and cuc.campaign_end_dt = cmc.campaign_end_dt
),
unified_campaign_pre_overlap AS (
    SELECT
        'NA'::varchar(1000) AS job_bag_number,
        campaign_id::varchar(1000) AS campaign_id,
        media_spend_amt::float AS media_spend_amt,
        media_spend_source::varchar(1000) AS media_spend_source,
        campaign_start_dt::date AS campaign_start_dt,
        campaign_end_dt::date AS campaign_end_dt,
        subchannel_name::varchar(1000) AS subchannel_name,
        item_cd_list::varchar(16777216) AS item_cd_list,
        super_category_name::varchar(1000) AS super_category_name,
        sub_category_name::varchar(1000) AS sub_category_name,
        channel_name::varchar(1000) AS channel_name,
        campaign_name::varchar(1000) AS campaign_name,
        booking_id::varchar(1000) AS booking_id,
        null::varchar(1000) AS campaign_status,
        is_multi_channel::boolean AS is_multi_channel,
        -- Standard batch timestamp for the normal insert path.
        current_timestamp::timestamp_ntz AS load_ts,
        'ci-prod-render'::varchar(36) AS job_run_id,
        marketing_type::varchar(100) AS marketing_type,
        unique_brand_name::varchar(1000) AS unique_brand_name,
        partner_id,
        advertiser_id,
        advertiser_name,
        post_campaign_dt::date AS post_campaign_dt,
        marketing_hierarchy_cd::varchar(100) AS marketing_hierarchy_cd
    FROM apply_is_multichannel
),
direct_overlaps AS (
    SELECT DISTINCT
        LEAST(a.campaign_id, b.campaign_id) AS source_campaign_id,
        GREATEST(a.campaign_id, b.campaign_id) AS target_campaign_id
    FROM unified_campaign_pre_overlap a
    JOIN unified_campaign_pre_overlap b
        ON (
           a.campaign_start_dt BETWEEN b.campaign_start_dt AND b.campaign_end_dt OR
           b.campaign_start_dt BETWEEN a.campaign_start_dt AND a.campaign_end_dt
       )
       AND ARRAY_SIZE(ARRAY_INTERSECTION(SPLIT(a.item_cd_list, ','), SPLIT(b.item_cd_list, ','))) > 0
       AND a.campaign_id <> b.campaign_id
),
overlapping_booking_ids AS (
    SELECT  a.target_campaign_id,
         MIN(COALESCE( d.source_campaign_id ,c.source_campaign_id, b.source_campaign_id, a.source_campaign_id)) AS root_campaign_id
    FROM direct_overlaps a
    LEFT JOIN direct_overlaps b ON a.source_campaign_id = b.target_campaign_id
    LEFT JOIN direct_overlaps c ON b.source_campaign_id = c.target_campaign_id
    LEFT JOIN direct_overlaps d ON c.source_campaign_id = d.target_campaign_id
    GROUP BY 1)
, initial_booking_ids AS (
    SELECT  root_campaign_id
        ,   a.target_campaign_id AS Campaign_id
    FROM overlapping_booking_ids a
    UNION ALL
    SELECT
        campaign_id AS root_campaign_id,
        campaign_id
    FROM unified_campaign_pre_overlap
    WHERE campaign_id NOT IN (SELECT target_campaign_id FROM direct_overlaps)
),
campaign_booking_map AS (
    SELECT
        root_campaign_id,
        LISTAGG(DISTINCT a.campaign_id, ',') WITHIN GROUP (ORDER BY a.campaign_id) AS booking_string,
        SHA2(booking_string, 256) AS campaign_overlap_id
    FROM unified_campaign_pre_overlap a
    LEFT JOIN initial_booking_ids b ON a.campaign_id = b.campaign_id
    GROUP BY root_campaign_id
),
unified_campaign AS (
SELECT DISTINCT
    booking_id AS job_bag_number, -- Once E2E run is complete, we need to change this back.
    uc.campaign_id,
    media_spend_amt,
    media_spend_source,
    campaign_start_dt,
    campaign_end_dt,
    subchannel_name,
    item_cd_list,
    super_category_name,
    sub_category_name,
    channel_name,
    campaign_name,
    campaign_overlap_id AS booking_id, -- Once E2E run is complete, we need to change this back.
    campaign_status,
    is_multi_channel,
    load_ts,
    job_run_id,
    marketing_type,
    unique_brand_name,
    partner_id,
    advertiser_id,
    advertiser_name,
    post_campaign_dt,
    marketing_hierarchy_cd
FROM unified_campaign_pre_overlap uc
LEFT JOIN initial_booking_ids ibi ON uc.campaign_id = ibi.campaign_id
LEFT JOIN campaign_booking_map cbm ON ibi.root_campaign_id = cbm.root_campaign_id)
SELECT 
    job_bag_number,
    campaign_id,
    media_spend_amt,
    media_spend_source,
    campaign_start_dt,
    campaign_end_dt,
    subchannel_name,
    item_cd_list,
    super_category_name,
    sub_category_name,
    channel_name,
    campaign_name,
    booking_id,
    campaign_status,
    is_multi_channel,
    load_ts,
    job_run_id,
    marketing_type,
    unique_brand_name,
    partner_id,
    advertiser_id,
    advertiser_name,
    post_campaign_dt,
    marketing_hierarchy_cd
FROM unified_campaign
;
