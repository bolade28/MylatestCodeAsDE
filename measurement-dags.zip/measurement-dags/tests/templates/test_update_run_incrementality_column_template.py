import pathlib

from jinja2 import Environment, StrictUndefined


def _render_update_run_incrementality_column(*, is_prod: bool) -> str:
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    template_path = root_dir / "dags/templates/sql/daily_etl/update_run_incrementality_column.sql"
    env = Environment(undefined=StrictUndefined)

    # Compiles string into a Template object
    with template_path.open("r") as template_file:
        template = env.from_string(template_file.read())

    # Render the template with specific parameters
    return template.render(
        params={
            "pollen_type": "POLLEN",
            "dtp_type": "DTP",
            "emulation_type": "EMULATION",
            "is_prod": is_prod,
            "product_type_filter": "brand",
            "look_back_period": 104,
            "consective_sales_period": 52,
        },
        get_table=lambda table_name: f"DEV_DB.PUBLIC.{table_name}",
    )


def test_update_run_incrementality_column_renders_prod_emulation_cte():
    """prod_emulation_campaigns CTE is present and reads from measurement_unified_campaign_pollen (not the old DEV eval table)."""
    rendered_sql = _render_update_run_incrementality_column(is_prod=False)

    assert "prod_emulation_campaigns" in rendered_sql
    assert "DEV_DB.PUBLIC.measurement_unified_campaign_pollen" in rendered_sql
    # is_prod=False so AND NOT False — emulation rows are included in DEV
    assert "AND NOT False" in rendered_sql
    # The UPDATE block for the old emulation snapshot table has been removed
    assert "-- Update the latest prod-emulation snapshot." not in rendered_sql
    assert "DEV_DB.PUBLIC.measurement_unified_campaign_pollen_prod_evaluation" not in rendered_sql


def test_update_run_incrementality_column_prod_guard_excludes_emulation_rows():
    """AND NOT True guard causes prod_emulation_campaigns to return zero rows when running in PROD."""
    rendered_sql = _render_update_run_incrementality_column(is_prod=True)

    assert "AND NOT True" in rendered_sql
    # UPDATE block for old emulation table is not present
    assert "-- Update the latest prod-emulation snapshot." not in rendered_sql


def test_update_run_incrementality_column_joins_transactions_by_item_only():
    """Transaction sales history is independent of the transaction brand column."""
    rendered_sql = _render_update_run_incrementality_column(is_prod=False)

    assert "ON scope.item_cd = transactions.item_cd" in rendered_sql
    assert "scope.unique_brand_name = transactions.unique_brand_name" not in rendered_sql
    assert "scope.unique_brand_name" in rendered_sql
