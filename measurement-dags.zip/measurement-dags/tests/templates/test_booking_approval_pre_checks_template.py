import pathlib
import re

from jinja2 import Environment, StrictUndefined
import pytest


CHECK_CTES = {
    "01": "check_01_store_cd_list",
    "02": "check_02_campaign_id",
    "03": "check_03_test_booking",
    "04": "check_04_duplicate_campaign_id",
    "05": "check_05_multi_brand",
    "06": "check_06_booking_item_cd_list",
    "07": "check_07_budget",
    "08": "check_08_dates_align",
    "09": "check_09_in_scope",
    "10": "check_10_booking_status",
    "11": "check_11_first_production_run",
    "12": "check_12_emulated_post_extract",
    "13": "check_13_overlapping_campaigns",
}


def _render_pre_checks(
    *,
    environment: str = "prod",
    emulation_run: bool = True,
    campaign_duration: str = "During",
) -> str:
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    template_path = root_dir / "dags/templates/sql/booking_approval/run_pre_checks.sql"
    env = Environment(undefined=StrictUndefined)

    with template_path.open("r") as template_file:
        template = env.from_string(template_file.read())

    return template.render(
        params={
            "booking_source_table": "DB.PUBLIC.booking_source",
            "pollen_table": "DB.PUBLIC.unified_campaign_pollen",
            "hierarchy_table": "DB.PUBLIC.marketing_hierarchy",
            "reporting_table": "DB.PUBLIC.campaign_reporting",
            "booking_ids_sql": "'BOOKING_1'",
            "environment": environment,
            "emulation_run": emulation_run,
            "campaign_duration": campaign_duration,
            "instore_channel_type": "INSTORE",
        }
    )


def _get_check_cte(sql: str, check_number: str) -> str:
    cte_name = CHECK_CTES[check_number]
    start = sql.index(f"{cte_name} AS (")
    end_match = re.search(r"(?m)^\),\n(?:-- Check|check_results AS)", sql[start:])
    assert end_match is not None, f"Could not find end of {cte_name}"
    return sql[start:start + end_match.start()]


STATUS_BRANCH_SCENARIOS = [
    pytest.param("01", "COALESCE(COUNT_IF(UPPER(channel_type) = 'INSTORE' AND media_name NOT ILIKE 'coupon%'), 0) = 0 THEN 'SKIPPED'", "prod", True, id="check-01-skip-no-applicable-rows"),
    pytest.param("01", "ARRAY_SIZE(store_cd_list) = 0) ) > 0 THEN 'FAIL'", "prod", True, id="check-01-fail-missing-store-codes"),
    pytest.param("01", "ELSE 'PASS'", "prod", True, id="check-01-pass-populated-store-codes"),
    pytest.param("02", "IFF(COUNT_IF(campaign_id IS NULL OR campaign_id = '-1') > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-02-fail-null-or-sentinel-id"),
    pytest.param("02", "IFF(COUNT_IF(campaign_id IS NULL OR campaign_id = '-1') > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-02-pass-valid-ids"),
    pytest.param("03", "IFF(COUNT_IF(UPPER(test_booking_flag) = 'Y') > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-03-fail-test-booking"),
    pytest.param("03", "IFF(COUNT_IF(UPPER(test_booking_flag) = 'Y') > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-03-pass-non-test-booking"),
    pytest.param("04", "IFF(COUNT_IF(counts.campaign_count > 1) > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-04-fail-duplicate-campaign-id"),
    pytest.param("04", "IFF(COUNT_IF(counts.campaign_count > 1) > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-04-pass-unique-campaign-ids"),
    pytest.param("05", "IFF(COUNT_IF(UPPER(multi_brand_flag) = 'Y') > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-05-fail-multi-brand"),
    pytest.param("05", "IFF(COUNT_IF(UPPER(multi_brand_flag) = 'Y') > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-05-pass-single-brand"),
    pytest.param("06", "IFF(COUNT_IF(ARRAY_SIZE(br.booking_item_cd_list) = 0 OR item.value:skuId IS NULL) > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-06-fail-empty-or-invalid-item-list"),
    pytest.param("06", "IFF(COUNT_IF(ARRAY_SIZE(br.booking_item_cd_list) = 0 OR item.value:skuId IS NULL) > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-06-pass-valid-item-list"),
    pytest.param("07", "WHEN COUNT_IF(booking_media_budget_amt IS NULL OR booking_media_budget_amt = 0) > 0 THEN 'FAIL'", "prod", True, id="check-07-fail-null-or-zero-budget"),
    pytest.param("07", "ELSE 'PASS'", "prod", True, id="check-07-pass-nonzero-budget"),
    pytest.param("08", "WHEN context.pollen_job_bag_number IS NULL THEN 'WARNING'", "prod", True, id="check-08-warn-missing-pollen-row"),
    pytest.param("08", "context.media_start_dt = context.campaign_start_dt AND context.media_end_dt = context.campaign_end_dt THEN 'PASS'", "prod", True, id="check-08-pass-matching-dates"),
    pytest.param("08", "ELSE 'FAIL'", "prod", True, id="check-08-fail-mismatched-dates"),
    pytest.param("09", "IFF(COUNT(violations.booking_id) > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-09-fail-out-of-scope-or-not-ready"),
    pytest.param("09", "IFF(COUNT(violations.booking_id) > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-09-pass-ready-hierarchy"),
    pytest.param("10", "IFF(COUNT_IF(booking_status IS NULL OR UPPER(booking_status) NOT IN ('COMPLETED', 'ACTIVE')) > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-10-fail-null-or-disallowed-status"),
    pytest.param("10", "IFF(COUNT_IF(booking_status IS NULL OR UPPER(booking_status) NOT IN ('COMPLETED', 'ACTIVE')) > 0, 'FAIL', 'PASS') AS check_status", "prod", True, id="check-10-pass-allowed-status"),
    pytest.param("11", "WHEN LOWER('dev') != 'prod' THEN 'PASS'", "dev", True, id="check-11-pass-non-production"),
    pytest.param("11", "COUNT_IF(reporting.booking_id IS NULL) > 0 THEN 'PASS'", "prod", True, id="check-11-pass-no-selected-duration-row"),
    pytest.param("11", "ELSE 'FAIL'", "prod", True, id="check-11-fail-existing-selected-duration-row"),
    pytest.param("12", "WHEN NOT false THEN 'SKIPPED'", "dev", False, id="check-12-skip-non-emulated-run"),
    pytest.param("12", "WHEN latest_run.load_ts IS NULL THEN 'SKIPPED'", "dev", True, id="check-12-skip-no-during-extract"),
    pytest.param("12", "DATEDIFF('DAY', latest_run.load_ts, CURRENT_DATE()) > 20 THEN 'FAIL'", "dev", True, id="check-12-fail-extract-older-than-20-days"),
    pytest.param("12", "ELSE 'PASS'", "dev", True, id="check-12-pass-extract-within-20-days"),
    pytest.param("13", "WHEN COUNT(oft.booking_a) > 0 THEN 'FAIL'", "prod", True, id="check-13-fail-overlapping-booking"),
    pytest.param("13", "ELSE 'PASS'", "prod", True, id="check-13-pass-no-overlap"),
]


def _normalize_sql(sql: str) -> str:
    return re.sub(r"\s+", " ", sql).replace("( ", "(").replace(" )", ")")


@pytest.mark.parametrize(
    "check_number,expected_branch,environment,emulation_run",
    STATUS_BRANCH_SCENARIOS,
)
def test_each_check_renders_expected_status_for_scenario(
    check_number: str,
    expected_branch: str,
    environment: str,
    emulation_run: bool,
):
    """Pin the rendered SQL branch that produces each check's PASS, FAIL, or skip/warning outcome."""
    campaign_duration = "Post" if check_number == "12" else "During"
    sql = _render_pre_checks(
        environment=environment,
        emulation_run=emulation_run,
        campaign_duration=campaign_duration,
    )
    cte = _get_check_cte(sql, check_number)
    normalized_cte = _normalize_sql(cte)
    normalized_branch = _normalize_sql(expected_branch)

    assert normalized_branch in normalized_cte


def test_check_01_store_codes_skips_irrelevant_media_and_checks_missing_codes():
    """Skip non-applicable media; fail missing INSTORE store codes; pass populated codes."""
    cte = _get_check_cte(_render_pre_checks(), "01")

    assert "UPPER(channel_type) = 'INSTORE'" in cte
    assert "media_name NOT ILIKE 'coupon%'" in cte
    assert "COALESCE(COUNT_IF(" in cte
    assert "), 0) = 0 THEN 'SKIPPED'" in cte
    assert "store_cd_list IS NULL OR ARRAY_SIZE(store_cd_list) = 0" in cte
    assert ") > 0 THEN 'FAIL'" in cte
    assert "ELSE 'PASS'" in cte


def test_check_02_campaign_id_rejects_null_and_sentinel_values():
    """Fail when any campaign ID is null or the -1 sentinel; otherwise pass."""
    cte = _get_check_cte(_render_pre_checks(), "02")

    assert "campaign_id IS NULL OR campaign_id = '-1'" in cte
    assert "'FAIL'" in cte
    assert "'PASS'" in cte


def test_check_03_test_booking_flag_rejects_y_and_allows_other_values():
    """Fail test bookings flagged Y and pass bookings without that flag."""
    cte = _get_check_cte(_render_pre_checks(), "03")

    assert "COUNT_IF(UPPER(test_booking_flag) = 'Y') > 0" in cte
    assert "'FAIL'" in cte
    assert "'PASS'" in cte


def test_check_04_duplicate_campaign_ids_excludes_sentinel_and_detects_repeats():
    """Ignore -1 IDs and fail when a valid campaign ID occurs on multiple rows."""
    sql = _render_pre_checks()
    cte = _get_check_cte(sql, "04")

    assert "WHERE campaign_id <> '-1'" in sql
    assert "COUNT(*) AS campaign_count" in sql
    assert "counts.campaign_count > 1" in cte
    assert "'FAIL'" in cte
    assert "'PASS'" in cte


def test_check_05_multi_brand_rejects_y_flag():
    """Fail bookings with a Y multi-brand flag and pass other flag values."""
    cte = _get_check_cte(_render_pre_checks(), "05")

    assert "COUNT_IF(UPPER(multi_brand_flag) = 'Y') > 0" in cte
    assert "'FAIL'" in cte
    assert "'PASS'" in cte


def test_check_06_item_list_rejects_empty_or_missing_sku_and_accepts_sku():
    """Fail empty item lists or items without skuId; pass lists with valid SKUs."""
    cte = _get_check_cte(_render_pre_checks(), "06")

    assert "ARRAY_SIZE(br.booking_item_cd_list) = 0 OR item.value:skuId IS NULL" in cte
    assert "LATERAL FLATTEN(input => br.booking_item_cd_list, OUTER => TRUE)" in cte
    assert "'FAIL'" in cte
    assert "'PASS'" in cte


def test_check_07_budget_rejects_null_or_zero_and_accepts_nonzero():
    """Fail null or zero media budgets and pass nonzero budgets."""
    cte = _get_check_cte(_render_pre_checks(), "07")

    assert "booking_media_budget_amt IS NULL OR booking_media_budget_amt = 0" in cte
    assert "'FAIL'" in cte
    assert "'PASS'" in cte


def test_check_08_dates_warns_when_missing_and_compares_both_boundaries():
    """Warn when no Pollen campaign matches, pass matching dates, and fail mismatches."""
    cte = _get_check_cte(_render_pre_checks(), "08")

    assert "WHEN context.pollen_job_bag_number IS NULL THEN 'WARNING'" in cte
    assert "context.media_start_dt = context.campaign_start_dt" in cte
    assert "context.media_end_dt = context.campaign_end_dt" in cte
    assert "THEN 'PASS'" in cte
    assert "ELSE 'FAIL'" in cte


def test_unified_campaign_dates_aggregate_all_rows_at_latest_load_timestamp():
    """Use the latest Pollen load per booking and compare its full date extent."""
    sql = _render_pre_checks()
    cte = sql[sql.index("unified_campaign_latest AS ("):sql.index("booking_metadata AS (")]

    assert "MAX(latest.load_ts)" in cte
    assert "latest.job_bag_number = pollen.job_bag_number" in cte
    assert "MIN(campaign_start_dt) AS campaign_start_dt" in cte
    assert "MAX(campaign_end_dt) AS campaign_end_dt" in cte
    assert "GROUP BY job_bag_number" in cte
    assert "ROW_NUMBER()" not in cte


def test_check_09_in_scope_fails_matched_false_flags_and_passes_otherwise():
    """Fail matched hierarchy rows with either readiness flag false; otherwise pass."""
    cte = _get_check_cte(_render_pre_checks(), "09")

    assert "INNER JOIN DB.PUBLIC.marketing_hierarchy AS hierarchy" in cte
    assert "hierarchy.in_scope_flag = FALSE" in cte
    assert "hierarchy.measurement_campaign_ready = FALSE" in cte
    assert "COUNT(violations.booking_id) > 0" in cte
    assert "'FAIL'" in cte
    assert "'PASS'" in cte


def test_check_10_booking_status_accepts_allowlist_and_rejects_other_statuses():
    """Allow the status list; fail NULL and statuses outside that set."""
    cte = _get_check_cte(_render_pre_checks(), "10")

    assert "booking_status IS NULL OR UPPER(booking_status) NOT IN ('COMPLETED', 'ACTIVE')" in cte
    assert "'FAIL'" in cte
    assert "'PASS'" in cte


def test_check_11_allows_non_prod_and_checks_selected_duration_in_prod():
    """Pass non-prod runs; in prod, fail an existing row for the selected duration."""
    cte = _get_check_cte(_render_pre_checks(), "11")

    assert "LOWER('prod') != 'prod' THEN 'PASS'" in cte
    assert "COUNT_IF(reporting.booking_id IS NULL) > 0 THEN 'PASS'" in cte
    assert "ELSE 'FAIL'" in cte
    assert "UPPER(reporting.campaign_duration) = UPPER('During')" in cte


def test_check_12_emulation_extract_age_skip_fail_and_boundary_branches():
    """Apply the age rule only to emulated Post runs with a During extract."""
    cte = _get_check_cte(_render_pre_checks(), "12")

    assert "WHEN NOT true THEN 'SKIPPED'" in cte
    assert "UPPER('During') != 'POST' THEN 'SKIPPED'" in cte
    assert "WHEN latest_run.load_ts IS NULL THEN 'SKIPPED'" in cte
    assert "DATEDIFF('DAY', latest_run.load_ts, CURRENT_DATE()) > 20 THEN 'FAIL'" in cte
    assert "ELSE 'PASS'" in cte
    assert "WHERE UPPER(campaign_duration) = 'DURING'" in cte


def test_check_12_skips_production_post_and_during_runs():
    """Skip production Post runs and emulated During runs, as in the original check."""
    production_post = _get_check_cte(
        _render_pre_checks(environment="prod", emulation_run=False, campaign_duration="Post"),
        "12",
    )
    emulated_during = _get_check_cte(
        _render_pre_checks(environment="dev", emulation_run=True, campaign_duration="During"),
        "12",
    )

    assert "WHEN NOT false THEN 'SKIPPED'" in production_post
    assert "UPPER('Post') != 'POST' THEN 'SKIPPED'" in production_post
    assert "WHEN NOT true THEN 'SKIPPED'" in emulated_during
    assert "UPPER('During') != 'POST' THEN 'SKIPPED'" in emulated_during


def test_check_13_detects_only_other_bookings_with_matching_sku_and_overlapping_dates():
    """Fail eligible overlapping bookings sharing a SKU; exclude self-pairs and filtered bookings."""
    cte = _get_check_cte(_render_pre_checks(), "13")

    assert "test_booking_flag = 'N'" in cte
    assert "multi_brand_flag = 'N'" in cte
    assert "item_cd_list IS NOT NULL" in cte
    assert "a.sku_cd = b.sku_cd" in cte
    assert "a.booking_id < b.booking_id" in cte
    assert "a.start_date <= b.end_date" in cte
    assert "b.start_date <= a.end_date" in cte
    assert "WHEN COUNT(oft.booking_a) > 0 THEN 'FAIL'" in cte
    assert "ELSE 'PASS'" in cte


def test_final_results_union_all_thirteen_check_ctes():
    """Ensure all 13 check CTEs are included in the final results union and ordering."""
    sql = _render_pre_checks()
    union_section = sql[sql.index("check_results AS ("):]

    assert "SELECT * FROM check_01_store_cd_list" in union_section
    for check_number, cte_name in list(CHECK_CTES.items())[1:]:
        assert f"UNION ALL SELECT * FROM {cte_name}" in union_section
    assert "ORDER BY checks.booking_id, checks.check_category" in union_section
