import os
import pathlib
import re
from typing import Optional

from jinja2 import Environment
from jinja2.nativetypes import NativeEnvironment
from helpers.constants import (
    OVERLAP_POST_PRESENCE_START_RATE,
    OVERLAP_POST_PRESENCE_WEEKLY_DECAY,
    PROD,
)
from helpers.tables import Snowflake


def test_sql_templates_are_valid():
    """Check that the sql templates are all valid jinja2 templates."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    templates_dir = os.path.join(root_dir, "dags/templates/sql")

    assert os.path.exists(templates_dir)  # in case they move

    template_paths = (
        os.path.join(dirname, filename)
        for dirname, _, filenames in os.walk(templates_dir)
        for filename in filenames
        if filename.endswith(".sql")  # Only check .sql files

    )

    env = Environment()
    for template_path in template_paths:
        with open(template_path, "r") as template:
            env.parse(template.read())


def test_booking_promotion_pre_checks_include_documented_categories():
    """Keep the initial Hypercare check categories visible in the promotion SQL."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/booking_approval/run_pre_checks.sql"

    sql = sql_path.read_text()

    for category in (
        "01_store_cd_list",
        "02_campaign_id",
        "03_test_booking",
        "04_duplicate_campaign_id",
        "05_multi_brand",
        "06_booking_item_cd_list",
        "07_booking_media_budget",
        "08_dates_align_to_unified_campaign",
        "09_marketing_subchannel_in_scope",
        "10_booking_status",
        "11_first_production_run",
        "12_emulated_post_extract_age",
    ):
        assert category in sql


def test_item_brand_hist_unload_uses_brand_skus_and_latest_item_details():
    # Arrange
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/pollen_sources/item_brand_hist.sql"

    # Act: ensure a specific time reference is used
    rendered_sql = _render_sql_with_params(
        sql_path,
        params={"brand_time_reference": "2026-08-24"},
    )

    # Assert
    assert "FROM item_brand_hist_all AS bh" in rendered_sql
    assert "LEFT JOIN item_details AS i\n            ON bh.item_cd = i.item_cd" in rendered_sql
    assert "PARTITION BY item_cd\n            ORDER BY load_ts DESC" in rendered_sql

    # The brand valid at the reference date takes precedence
    assert "bh.valid_from_dt <= '2026-08-24'" in rendered_sql
    assert "bh.valid_until_dt >= '2026-08-24'" in rendered_sql

    # Fall back to the latest history row only when no reference-date brand exists.
    assert "item_brand_details_out_of_scope AS" in rendered_sql
    assert "NOT EXISTS (" in rendered_sql
    assert "FROM item_brand_details_in_scope AS in_scope" in rendered_sql
    assert "WHERE in_scope.item_cd = bh.item_cd" in rendered_sql
    assert "FROM item_brand_details_in_scope\n\n        UNION ALL" in rendered_sql
    assert "FROM item_brand_details_out_of_scope" in rendered_sql
    assert rendered_sql.count("PARTITION BY bh.item_cd") == 2
    assert "booking_id" not in rendered_sql


def test_published_campaign_reporting_sql_renders_phase_end_date():
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/measurement_campaign_reporting/unload_published_campaign_reporting.sql"

    for end_date in ("2026-10-25", "2026-11-15"):
        rendered_sql = _render_sql_with_params(
            sql_path,
            params={
                "correlation_id": "test-correlation-id",
                "end_date": end_date,
            },
        )

        assert f"having max(load_ts) < '{end_date}'" in rendered_sql.lower()
        assert "{{ params.end_date }}" not in rendered_sql


def test_pipeline_item_sources_use_dim_item_hist_at_the_brand_reference_date():
    """The pipeline must read item attributes from dim_item_hist, resolved at a single point in time."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()

    sql_paths = [
        "dags/templates/sql/sales_data_transaction/fact_sales_transaction_item.sql",
        "dags/templates/sql/temp_unified_product/temp_unified_product.sql",
    ]

    for relative_path in sql_paths:
        rendered_sql = _render_sql_with_params(
            root_dir / relative_path,
            params={
                "brand_time_reference": "2026-08-24",
                "correlation_id": "test-correlation-id",
                "campaign_id_manual": "[]",
                "campaign_id_default": "1234",
                "start_date": "2026-01-01",
                "end_date": "2026-02-01",
                "emulate_prod_env": "false",
                "is_prod": False,
            },
        )

        assert "dim_item_hist" in rendered_sql, relative_path
        assert not re.search(r"\bdim_item\b(?!_hist)", rendered_sql), relative_path
        assert "valid_from_dt <= '2026-08-24'" in rendered_sql, relative_path
        assert "valid_until_dt >= '2026-08-24'" in rendered_sql, relative_path


def test_dim_item_hist_item_sources_are_deduplicated_per_item():
    """dim_item_hist holds multiple rows per item, so joins must not fan out fact rows."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()

    sql_paths = [
        "dags/templates/sql/sales_data_transaction/fact_sales_transaction_item.sql",
    ]

    for relative_path in sql_paths:
        content = (root_dir / relative_path).read_text()
        assert "QUALIFY ROW_NUMBER() OVER (" in content, relative_path
        assert "PARTITION BY item_cd" in content, relative_path

    temp_unified_product = (root_dir / "dags/templates/sql/temp_unified_product/temp_unified_product.sql").read_text()
    assert "select distinct item_cd" in temp_unified_product


def test_legacy_brand_booking_registry_grace_window_requires_surviving_reporting_output():
    """A completed POST whose reporting output was cleared must not end the grace window."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/daily_etl/legacy_brand_booking_registry.sql"

    rendered_sql = _render_sql_with_params(sql_path, params={})

    assert "JOIN reported_post_runs_pollen AS r\n          ON r.correlation_id = p.correlation_id" in rendered_sql
    assert "completed_during_runs_pollen AS d" not in rendered_sql
    # The exclusion must be gated on surviving reporting output, not merely on POST completion.
    not_exists_start = rendered_sql.index("NOT EXISTS (")
    not_exists_block = rendered_sql[not_exists_start:rendered_sql.index(");", not_exists_start)]
    assert "completed_post_runs_pollen" in not_exists_block
    assert "reported_post_runs_pollen" in not_exists_block
    assert "reported_post_runs_pollen" in not_exists_block


def test_customer_campaign_engagement_event_names_are_parameterized():
    """Ensure event_name values come from params, not hardcoded labels."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    templates_dir = root_dir / "dags/templates/sql/mta_tables_setup/customer_campaign_engagement"

    assert templates_dir.exists()

    sql_files = templates_dir.glob("*.sql")
    for sql_file in sql_files:
        content = sql_file.read_text()

        assert "'Touchpoint'" not in content
        assert "'Purchase Transaction'" not in content
        assert "{{ params.touchpoint_event_name }}" in content
        assert "{{ params.transaction_event_name }}" in content


def test_customer_campaign_engagement_purchase_type_logic_present():
    """Ensure transaction rows derive purchase_type and blank channel attribution fields."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    templates_dir = root_dir / "dags/templates/sql/mta_tables_setup/customer_campaign_engagement"

    assert templates_dir.exists()

    sql_files = templates_dir.glob("*.sql")
    for sql_file in sql_files:
        content = sql_file.read_text()
        content_lower = content.lower()

        assert "as purchase_type" in content_lower
        has_case_blanking = "then '' else" in content_lower
        has_explicit_blanks = (
            "'' as channel_name" in content_lower and
            "'' as subchannel_name" in content_lower and
            "'' as marketing_type" in content_lower and
            "'' as campaign_id" in content_lower
        )

        assert has_case_blanking or has_explicit_blanks


def test_test_booking_flag_condition_is_present_in_modified_sql_templates():
    """Ensure modified pollen SQL templates keep TEST_BOOKING_FLAG conditional filtering blocks."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()

    sql_files = {
        "dags/templates/sql/unified_campaign/unified_campaign_pollen_insert.sql": "aal.TEST_BOOKING_FLAG != 'Y'",
        "dags/templates/sql/dv360_normalize/dv360_normalize_pollen.sql": "aal.TEST_BOOKING_FLAG != 'Y'",
        "dags/templates/sql/pollen_sources/campaign_booking_media_channel.sql": "t.TEST_BOOKING_FLAG != 'Y'",
    }

    jinja_condition = "{% if params.emulate_prod_env | default(false) or params.is_prod | default(false) %}"

    for relative_path, expected_filter in sql_files.items():
        sql_path = root_dir / relative_path
        assert sql_path.exists()

        content = sql_path.read_text()

        if "unified_campaign_pollen_insert.sql" in relative_path:
            # Unified campaign template has an outer dev prod-test branch,
            # with prod/emulation behavior handled in an inner elif branch.
            assert "{% if params.enable_prod_bookings_in_dev | default(false) %}" in content
            assert "{% elif params.emulate_prod_env | default(false) or params.is_prod | default(false) %}" in content
            assert "aal.TEST_BOOKING_FLAG = 'Y'" in content
        else:
            assert jinja_condition in content
        assert expected_filter in content


def test_unified_campaign_pollen_template_contains_test_booking_flag_jinja_block():
    """Ensure unified_campaign_pollen_insert keeps both dev prod-test and prod/emulation TEST_BOOKING_FLAG branches."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/unified_campaign/unified_campaign_pollen_insert.sql"

    assert sql_path.exists()

    content = sql_path.read_text()

    assert "{% if params.enable_prod_bookings_in_dev | default(false) %}" in content
    assert "{% elif params.emulate_prod_env | default(false) or params.is_prod | default(false) %}" in content
    assert "and aal.TEST_BOOKING_FLAG = 'Y'" in content
    assert "and aal.TEST_BOOKING_FLAG != 'Y'" in content
    assert "{% endif %}" in content


def test_modified_sql_templates_contain_expected_test_booking_jinja_block_content():
    """Validate direct SQL content for the test-booking Jinja guard block in all modified templates."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    block_start = "{% if params.emulate_prod_env | default(false) or params.is_prod | default(false) %}"
    block_end = "{% endif %}"

    sql_files_and_expected_predicates = {
        "dags/templates/sql/unified_campaign/unified_campaign_pollen_insert.sql": "and aal.TEST_BOOKING_FLAG != 'Y'",
        "dags/templates/sql/dv360_normalize/dv360_normalize_pollen.sql": "AND aal.TEST_BOOKING_FLAG != 'Y'",
        "dags/templates/sql/pollen_sources/campaign_booking_media_channel.sql": "AND t.TEST_BOOKING_FLAG != 'Y'",
    }

    for relative_path, expected_predicate in sql_files_and_expected_predicates.items():
        sql_path = root_dir / relative_path
        assert sql_path.exists()

        content = sql_path.read_text()

        if "unified_campaign_pollen_insert.sql" in relative_path:
            assert "{% if params.enable_prod_bookings_in_dev | default(false) %}" in content
            assert "{% elif params.emulate_prod_env | default(false) or params.is_prod | default(false) %}" in content
            assert "and aal.TEST_BOOKING_FLAG = 'Y'" in content
            assert expected_predicate in content
            assert "{% endif %}" in content
            continue

        start_index = content.find(block_start)
        assert start_index != -1

        end_index = content.find(block_end, start_index)
        assert end_index != -1

        block_content = content[start_index:end_index + len(block_end)]

        assert block_start in block_content
        assert expected_predicate in block_content
        assert block_end in block_content


def _get_test_booking_sql_templates(root_dir: pathlib.Path) -> dict:
    """Returns the SQL templates and expected TEST_BOOKING_FLAG predicate snippets."""
    return {
        "dags/templates/sql/unified_campaign/unified_campaign_pollen_insert.sql": "aal.TEST_BOOKING_FLAG != 'Y'",
        "dags/templates/sql/dv360_normalize/dv360_normalize_pollen.sql": "aal.TEST_BOOKING_FLAG != 'Y'",
        "dags/templates/sql/pollen_sources/campaign_booking_media_channel.sql": "t.TEST_BOOKING_FLAG != 'Y'",
    }


def _render_sql_with_params(
    sql_path: pathlib.Path,
    params: Optional[dict],
    table_name_resolver=None,
) -> str:
    """Renders a SQL template with provided params and no-op table/stage helpers."""
    content = sql_path.read_text()
    env = Environment()
    template = env.from_string(content)
    resolver = table_name_resolver if table_name_resolver is not None else (lambda name: name)

    return template.render(
        params=params,
        get_table=resolver,
        get_stage=lambda name: f"@STAGE/{name}",
    )


def test_booking_approval_merge_promotes_pending_and_inserts_missing_rows():
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/booking_approval/insert_approved_tracker_rows.sql"

    rendered_sql = re.sub(
        r"\s+",
        " ",
        _normalize_sql_for_snapshot(_render_sql_with_params(
            sql_path,
            params={
                "tracker_table": "DB.SCHEMA.MEASUREMENT_BOOKING_TRACKER",
                "rows_sql": (
                    "SELECT 'booking-1' AS booking_id, 'Campaign' AS campaign_name, "
                    "'During' AS pipeline_stage"
                ),
                "booking_status": "READY",
            },
        )),
    )

    assert "MERGE INTO DB.SCHEMA.MEASUREMENT_BOOKING_TRACKER AS target" in rendered_sql
    assert "ON target.booking_id = src.booking_id AND UPPER(target.pipeline_stage) = UPPER(src.pipeline_stage)" in rendered_sql
    assert "WHEN MATCHED AND UPPER(target.status) = 'PENDING' THEN UPDATE SET target.status = 'READY'" in rendered_sql
    assert "target.load_ts = CURRENT_TIMESTAMP()" in rendered_sql
    assert "WHEN NOT MATCHED THEN INSERT" in rendered_sql
    assert "src.pipeline_stage, 'READY', TRUE" in rendered_sql


def _normalize_sql_for_snapshot(sql: str) -> str:
    """Normalizes trailing whitespace and surrounding blank lines for stable snapshot asserts."""
    normalized_lines = []
    for line in sql.strip().splitlines():
        # Snapshot comparisons should focus on SQL behavior, not comment wording.
        line = re.sub(r"--.*$", "", line)
        # Compare semantic SQL content rather than formatting-only differences.
        collapsed = re.sub(r"\s+", " ", line).strip()
        if collapsed:
            normalized_lines.append(collapsed)
    return "\n".join(normalized_lines)


def _extract_snapshot_core_sql(sql: str, snapshot_kind: str) -> str:
    """Extracts non-mutating SQL logic for snapshot comparisons."""
    if snapshot_kind == "unified_cte":
        start_match = re.search(r"(?im)^with\s*$", sql)
        assert start_match is not None
        return sql[start_match.start():]

    if snapshot_kind == "copy_into_inner_query":
        inner_match = re.search(r"(?is)FROM\s*\((.*)\)\s*include_query_id", sql)
        assert inner_match is not None
        return inner_match.group(1).strip() + "\n"

    raise ValueError(f"Unsupported snapshot kind: {snapshot_kind}")


def test_ad_hoc_brand_id_backfill_renders_production_booking_source():
    """Ensure the ad hoc brand ID backfill reads only production booking data."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/ad_hoc_scripts/backfill_brand_id.sql"
    tables = Snowflake(env="dev", correlation_id="test-correlation-id").tables

    rendered = _render_sql_with_params(
        sql_path,
        params={},
        table_name_resolver=tables.__getitem__,
    )

    assert "{{" not in rendered
    assert "MERGE INTO UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CAMPAIGN_REPORTING_AWS AS target" in rendered
    assert "FROM ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR AS cbm" in rendered
    assert "ADW_DEV.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR" not in rendered
    assert "ARRAY_AGG(DISTINCT brand_id) AS brand_id" in rendered
    assert "WHEN MATCHED" in rendered
    assert "AND target.brand_id IS NULL" in rendered


def _extract_source_table_for_aal(sql: str) -> Optional[str]:
    """Extract the underlying unified-campaign source table, whether used directly or via source_booking_rows."""
    source_cte_match = re.search(
        r"source_booking_rows\s+AS\s*\(\s*SELECT\s+\*\s+FROM\s+(?:--[^\n]*\n\s*)*([A-Za-z0-9_.]+)",
        sql,
    )
    if source_cte_match is not None:
        return source_cte_match.group(1)

    source_match = re.search(
        r"FROM\s+(?:--[^\n]*\n\s*)*([A-Za-z0-9_.]+)\s+AS\s+aal",
        sql,
    )
    return source_match.group(1) if source_match is not None else None


def test_test_booking_flag_filter_renders_for_prod_or_emulated_runs_only_across_modified_templates():
    """Validate all three modified templates render TEST_BOOKING_FLAG filter only for prod/emulated runs."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_files = _get_test_booking_sql_templates(root_dir)
    scenarios = [
        ({"emulate_prod_env": True, "is_prod": False}, True),
        ({"emulate_prod_env": False, "is_prod": True}, True),
        ({"emulate_prod_env": True, "is_prod": True}, True),
        ({"emulate_prod_env": False, "is_prod": False}, False),
        ({}, False),
        (None, False),
    ]

    for params, should_render_filter in scenarios:
        for relative_path, expected_filter in sql_files.items():
            sql_path = root_dir / relative_path
            rendered = _render_sql_with_params(sql_path, params)

            if should_render_filter:
                assert expected_filter in rendered
            else:
                assert expected_filter not in rendered


def test_unified_campaign_pollen_source_table_render_behavior():
    """Validate emulate_prod_env controls the source booking table used by unified campaign pollen SQL."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/unified_campaign/unified_campaign_pollen_insert.sql"
    scenarios = [
        (
            {"emulate_prod_env": True, "is_prod": False},
            "campaign_booking_media_channel_prod",
        ),
        (
            {"emulate_prod_env": True, "is_prod": True},
            "campaign_booking_media_channel_prod",
        ),
        (
            {"emulate_prod_env": False, "is_prod": True},
            "campaign_booking_media_channel",
        ),
        (
            {"emulate_prod_env": False, "is_prod": False},
            "campaign_booking_media_channel",
        ),
        ({}, "campaign_booking_media_channel"),
        (None, "campaign_booking_media_channel"),
        (
            {"enable_prod_bookings_in_dev": True, "emulate_prod_env": False, "is_prod": False},
            "campaign_booking_media_channel_prod",
        ),
    ]

    for params, expected_source_table in scenarios:
        rendered = _render_sql_with_params(sql_path, params)
        source_table = _extract_source_table_for_aal(rendered)

        assert source_table is not None
        assert source_table == expected_source_table


def test_unified_campaign_pollen_whole_sql_renders_with_and_without_prod():
    """Render the full unified campaign pollen SQL and validate prod/non-prod behavior."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/unified_campaign/unified_campaign_pollen_insert.sql"

    params_without_prod = {
        "table": "DB.SCHEMA.measurement_unified_campaign_pollen_daily_etl",
        "correlation_id": "ci-1",
        "emulate_prod_env": False,
        "is_prod": False,
    }
    params_with_prod = {
        "table": "DB.SCHEMA.measurement_unified_campaign_pollen_daily_etl",
        "correlation_id": "ci-1",
        "emulate_prod_env": False,
        "is_prod": True,
    }

    rendered_without_prod = _render_sql_with_params(sql_path, params_without_prod)
    rendered_with_prod = _render_sql_with_params(sql_path, params_with_prod)

    # Both renders should fully resolve Jinja and target the expected destination table.
    assert "{{" not in rendered_without_prod
    assert "{%" not in rendered_without_prod
    assert "{{" not in rendered_with_prod
    assert "{%" not in rendered_with_prod

    # With emulate_prod_env disabled, both runs read from the same base source table.
    source_without_prod = _extract_source_table_for_aal(rendered_without_prod)
    source_with_prod = _extract_source_table_for_aal(rendered_with_prod)

    assert source_without_prod is not None
    assert source_with_prod is not None
    assert source_without_prod == "campaign_booking_media_channel"
    assert source_with_prod == "campaign_booking_media_channel"

    # TEST_BOOKING_FLAG filter is enabled only for prod/emulated runs.
    assert "and aal.TEST_BOOKING_FLAG != 'Y'" not in rendered_without_prod
    assert "and aal.TEST_BOOKING_FLAG != 'Y'" in rendered_with_prod


def test_unified_campaign_pollen_uses_booking_max_reference_date_for_new_brand_and_item_lookups():
    """Non-legacy brand and item history lookups should use the booking reference date."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/unified_campaign/unified_campaign_pollen_insert.sql"

    rendered = _render_sql_with_params(
        sql_path,
        {
            "table": "DB.SCHEMA.measurement_unified_campaign_pollen_daily_etl",
            "correlation_id": "ci-1",
            "emulate_prod_env": False,
            "is_prod": False,
        },
    )

    assert "booking_reference_source AS (" in rendered
    assert "MIN(booking_media_live_start_dt) AS booking_start_dt" in rendered
    assert "ANY_VALUE(booking_item_cd_list) AS booking_item_cd_list" in rendered
    assert "booking_reference_dates AS (" in rendered
    assert "MAX(" in rendered
    assert "INNER JOIN booking_reference_dates" in rendered
    assert "AND es.booking_reference_dt" in rendered
    assert "BETWEEN new_brand.valid_from_dt AND new_brand.valid_until_dt" in rendered
    assert "LEFT JOIN legacy_brand_booking_registry AS registered_legacy_booking" in rendered
    assert "LEFT JOIN dim_item AS legacy_item" in rendered
    assert "ON registered_legacy_booking.booking_id IS NOT NULL" in rendered
    assert "LEFT JOIN dim_item_hist AS current_item" in rendered
    assert "ON registered_legacy_booking.booking_id IS NULL" in rendered
    assert "BETWEEN current_item.valid_from_dt AND current_item.valid_until_dt" in rendered


def test_unified_campaign_pollen_backfills_missing_historical_brand_from_earliest_interval():
    """Bookings outside ITEM_BRAND_HIST coverage use the earliest non-empty brand interval."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/unified_campaign/unified_campaign_pollen_insert.sql"

    rendered = _render_sql_with_params(
        sql_path,
        {
            "table": "DB.SCHEMA.measurement_unified_campaign_pollen_daily_etl",
            "correlation_id": "ci-1",
            "emulate_prod_env": False,
            "is_prod": False,
        },
    )

    assert "item_brand_hist_earliest AS (" in rendered
    assert "FROM item_brand_hist\n    QUALIFY row_number() OVER (" in rendered
    assert "PARTITION BY item_cd\n        ORDER BY valid_from_dt ASC, valid_until_dt ASC" in rendered
    assert "LEFT JOIN item_brand_hist_earliest AS fallback_new_brand" in rendered
    assert "AND new_brand.item_cd IS NULL" in rendered
    assert "AND es.items = fallback_new_brand.item_cd" in rendered
    assert "fallback_new_brand.brand_name" in rendered
    assert "fallback_new_brand.brand_owner_name" in rendered
    assert rendered.index("new_brand.brand_name") < rendered.index("fallback_new_brand.brand_name")
    assert rendered.index("new_brand.brand_owner_name") < rendered.index("fallback_new_brand.brand_owner_name")


def test_dv360_normalize_pollen_whole_sql_renders_with_and_without_prod_or_emulation():
    """Render full DV360 pollen SQL and validate core SQL structure plus TEST_BOOKING_FLAG behavior."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/dv360_normalize/dv360_normalize_pollen.sql"

    scenarios = [
        ({"emulate_prod_env": False, "is_prod": False}, False),
        ({"emulate_prod_env": True, "is_prod": False}, True),
        ({"emulate_prod_env": False, "is_prod": True}, True),
        ({"emulate_prod_env": True, "is_prod": True}, True),
        ({}, False),
        (None, False),
    ]

    for params, should_render_flag_filter in scenarios:
        rendered = _render_sql_with_params(sql_path, params)

        # Validate full-template rendering and key SQL scaffolding.
        assert "{{" not in rendered
        assert "{%" not in rendered
        assert "REMOVE @STAGE/dv360_pollen_campaign/;" in rendered
        assert "COPY INTO @STAGE/dv360_pollen_campaign" in rendered
        assert "FROM campaign_booking_media_channel AS aal," in rendered
        assert "LATERAL FLATTEN(input => aal.booking_item_cd_list) f" in rendered
        assert "AND json_extract_path_text(f.value,'skuId') IS NOT NULL" in rendered
        assert "include_query_id = true" in rendered
        assert "header = true;" in rendered

        if should_render_flag_filter:
            assert "AND aal.TEST_BOOKING_FLAG != 'Y'" in rendered
        else:
            assert "AND aal.TEST_BOOKING_FLAG != 'Y'" not in rendered


def test_campaign_booking_media_channel_whole_sql_renders_with_and_without_prod_or_emulation():
    """Render full campaign booking SQL and validate core SQL structure plus TEST_BOOKING_FLAG behavior."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/pollen_sources/campaign_booking_media_channel.sql"

    scenarios = [
        ({"emulate_prod_env": False, "is_prod": False}, False),
        ({"emulate_prod_env": True, "is_prod": False}, True),
        ({"emulate_prod_env": False, "is_prod": True}, True),
        ({"emulate_prod_env": True, "is_prod": True}, True),
        ({}, False),
        (None, False),
    ]

    for params, should_render_flag_filter in scenarios:
        rendered = _render_sql_with_params(sql_path, params)

        # Validate full-template rendering and key SQL scaffolding.
        assert "{{" not in rendered
        assert "{%" not in rendered
        assert "REMOVE @STAGE/campaign_booking_media_channel/;" in rendered
        assert "COPY INTO @STAGE/campaign_booking_media_channel" in rendered
        assert "WITH blacklisted_bookings AS (" in rendered
        assert "FROM bookings_blacklist" in rendered
        assert "FROM campaign_booking_media_channel AS t" in rendered
        assert "AND NOT EXISTS (" in rendered
        assert "COUNT_IF(json_extract_path_text(f.value, 'skuId') IS NULL) AS null_sku_id_count" in rendered
        assert "INNER JOIN flattened_booking_skus_check fc ON t.booking_id = fc.booking_id" in rendered
        assert "WHERE fc.null_sku_id_count = 0" in rendered
        assert "include_query_id = true" in rendered
        assert "header = true;" in rendered

        if should_render_flag_filter:
            assert "AND t.TEST_BOOKING_FLAG != 'Y'" in rendered
        else:
            assert "AND t.TEST_BOOKING_FLAG != 'Y'" not in rendered


def test_campaign_booking_media_channel_jinja_renders_with_and_without_prod():
    """Render campaign booking SQL in non-prod and prod and verify TEST_BOOKING_FLAG behavior."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/pollen_sources/campaign_booking_media_channel.sql"
    expected_prod_sql_path = root_dir / "tests/templates/expected_sql/campaign_booking_media_channel.prod.sql"
    prod_table_map = Snowflake(
        correlation_id="ci-prod-render-00000001",
        env=PROD,
        emulation_run=False,
    ).tables

    def prod_table_resolver(name: str) -> str:
        return prod_table_map[name]

    rendered_without_prod = _render_sql_with_params(
        sql_path,
        {"emulate_prod_env": False, "is_prod": False},
        table_name_resolver=prod_table_resolver,
    )
    rendered_with_prod = _render_sql_with_params(
        sql_path,
        {"emulate_prod_env": False, "is_prod": True},
        table_name_resolver=prod_table_resolver,
    )

    expected_rendered_with_prod = expected_prod_sql_path.read_text()

    # Ensure templates are fully rendered in both modes.
    assert "{{" not in rendered_without_prod
    assert "{%" not in rendered_without_prod
    assert "{{" not in rendered_with_prod
    assert "{%" not in rendered_with_prod

    # Verify prod toggle behavior for the test-booking filter.
    assert "AND t.TEST_BOOKING_FLAG != 'Y'" not in rendered_without_prod
    assert "AND t.TEST_BOOKING_FLAG != 'Y'" in rendered_with_prod
    assert re.search(
        r"FROM\s+ADW_PROD\.ADW_BDV\.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR\s+AS\s+t",
        rendered_with_prod,
    )
    assert re.search(
        r"FROM\s+UNIFIED_PLATFORM_PROD\.ADW_UNIFIED_PLATFORM_TACTICAL\.POLLEN_BOOKINGS_BLACKLIST_AWS",
        rendered_with_prod,
    )

    # Snapshot assertion: compare only CTE/query core logic (no data-changing wrappers).
    rendered_core = _extract_snapshot_core_sql(rendered_with_prod, "copy_into_inner_query")
    assert _normalize_sql_for_snapshot(rendered_core) == _normalize_sql_for_snapshot(expected_rendered_with_prod)


def test_unified_campaign_pollen_jinja_renders_with_and_without_prod():
    """Render unified campaign SQL in non-prod and prod and verify TEST_BOOKING_FLAG behavior."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/unified_campaign/unified_campaign_pollen_insert.sql"
    expected_prod_sql_path = root_dir / "tests/templates/expected_sql/unified_campaign_pollen_insert.prod.sql"
    prod_table_map = Snowflake(
        correlation_id="ci-prod-render-00000001",
        env=PROD,
        emulation_run=False,
    ).tables

    def prod_table_resolver(name: str) -> str:
        return prod_table_map[name]

    rendered_without_prod = _render_sql_with_params(
        sql_path,
        {
            "table": "measurement_unified_campaign_pollen_daily_etl",
            "correlation_id": "ci-prod-render",
            "emulate_prod_env": False,
            "is_prod": False,
        },
        table_name_resolver=prod_table_resolver,
    )
    rendered_with_prod = _render_sql_with_params(
        sql_path,
        {
            "table": "measurement_unified_campaign_pollen_daily_etl",
            "correlation_id": "ci-prod-render",
            "emulate_prod_env": False,
            "is_prod": True,
        },
        table_name_resolver=prod_table_resolver,
    )

    expected_rendered_with_prod = expected_prod_sql_path.read_text()

    # Ensure templates are fully rendered in both modes.
    assert "{{" not in rendered_without_prod
    assert "{%" not in rendered_without_prod
    assert "{{" not in rendered_with_prod
    assert "{%" not in rendered_with_prod

    # Verify prod toggle behavior for the test-booking filter.
    assert "and aal.TEST_BOOKING_FLAG != 'Y'" not in rendered_without_prod
    assert "and aal.TEST_BOOKING_FLAG != 'Y'" in rendered_with_prod
    source_table_with_prod = _extract_source_table_for_aal(rendered_with_prod)
    assert source_table_with_prod == prod_table_map["campaign_booking_media_channel"]
    assert re.search(
        r"FROM\s+UNIFIED_PLATFORM_PROD\.ADW_UNIFIED_PLATFORM_TACTICAL\.POLLEN_BOOKINGS_BLACKLIST_AWS\s+AS\s+b",
        rendered_with_prod,
    )

    # Snapshot assertion: compare only CTE/query core logic (no data-changing wrappers).
    rendered_core = _extract_snapshot_core_sql(rendered_with_prod, "unified_cte")
    assert _normalize_sql_for_snapshot(rendered_core) == _normalize_sql_for_snapshot(expected_rendered_with_prod)


def test_dv360_normalize_pollen_jinja_renders_with_and_without_prod():
    """Render DV360 normalize SQL in non-prod and prod and verify TEST_BOOKING_FLAG behavior."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/dv360_normalize/dv360_normalize_pollen.sql"
    expected_prod_sql_path = root_dir / "tests/templates/expected_sql/dv360_normalize_pollen.prod.sql"
    prod_table_map = Snowflake(
        correlation_id="ci-prod-render-00000001",
        env=PROD,
        emulation_run=False,
    ).tables

    def prod_table_resolver(name: str) -> str:
        return prod_table_map[name]

    rendered_without_prod = _render_sql_with_params(
        sql_path,
        {"emulate_prod_env": False, "is_prod": False},
        table_name_resolver=prod_table_resolver,
    )
    rendered_with_prod = _render_sql_with_params(
        sql_path,
        {"emulate_prod_env": False, "is_prod": True},
        table_name_resolver=prod_table_resolver,
    )

    expected_rendered_with_prod = expected_prod_sql_path.read_text()

    # Ensure templates are fully rendered in both modes.
    assert "{{" not in rendered_without_prod
    assert "{%" not in rendered_without_prod
    assert "{{" not in rendered_with_prod
    assert "{%" not in rendered_with_prod

    # Verify prod toggle behavior for the test-booking filter.
    assert "AND aal.TEST_BOOKING_FLAG != 'Y'" not in rendered_without_prod
    assert "AND aal.TEST_BOOKING_FLAG != 'Y'" in rendered_with_prod
    assert re.search(
        r"FROM\s+ADW_PROD\.ADW_BDV\.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR\s+AS\s+aal\s*,",
        rendered_with_prod,
    )

    # Snapshot assertion: compare only CTE/query core logic (no data-changing wrappers).
    rendered_core = _extract_snapshot_core_sql(rendered_with_prod, "copy_into_inner_query")
    assert _normalize_sql_for_snapshot(rendered_core) == _normalize_sql_for_snapshot(expected_rendered_with_prod)


class _FakeTaskInstance:
    """Stands in for Airflow's `task_instance` when simulating the operator's second templating pass."""

    def __init__(self, emulation_run: bool):
        self._emulation_run = emulation_run

    def xcom_pull(self, task_ids=None, key=None):
        return self._emulation_run


def _render_overlapping_campaign_spend_weights_two_pass(is_dev_env: bool, emulation_run: bool) -> str:
    """
    Simulates MeasurementSnowflakeOperator's real two-pass rendering (see helpers/snowflake.py):
    round 1 renders the SQL exactly as Airflow does before any task runs - i.e. with
    `params.emulate_prod_env` still holding the raw, unrendered xcom-pull expression string
    that `get_emulation_run()` produces (native-obj rendering does not resolve nested/embedded
    Jinja text, only real params). Round 2 (triggered by the operator's pre_execute hook)
    re-renders the round-1 output against a fake task_instance to resolve any xcom-pull
    expressions that survived as literal text.
    """
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    sql_path = root_dir / "dags/templates/sql/overlapping_campaigns/overlapping_campaign_spend_weights_pollen.sql"
    content = sql_path.read_text()

    unrendered_xcom_expression = (
        '{{task_instance.xcom_pull(task_ids="setup_tasks.configure_emulation_run", key="return_value")}}'
    )

    native_env = NativeEnvironment()
    round_one_output = native_env.from_string(content).render(
        params={
            "emulate_prod_env": unrendered_xcom_expression,
            "is_prod": not is_dev_env,
            "post_presence_start_rate": OVERLAP_POST_PRESENCE_START_RATE,
            "post_presence_weekly_decay": OVERLAP_POST_PRESENCE_WEEKLY_DECAY,
        },
        get_table=lambda name: name,
        get_stage=lambda name: f"@STAGE/{name}",
    )

    round_two_output = native_env.from_string(str(round_one_output)).render(
        task_instance=_FakeTaskInstance(emulation_run),
    )

    return str(round_two_output)


def test_overlapping_campaign_spend_weights_pollen_booking_source_across_environments():
    """
    Validate booking_source picks the right BDV table combination for each env/emulation
    scenario, using the same two-pass rendering MeasurementSnowflakeOperator performs in
    production (params.emulate_prod_env only resolves via xcom on the second pass).
    """
    scenarios = [
        # (is_dev_env, emulation_run)
        (True, True),
        (True, False),
        (False, True),
        (False, False),
    ]

    for is_dev_env, emulation_run in scenarios:
        rendered = _render_overlapping_campaign_spend_weights_two_pass(is_dev_env, emulation_run)
        # Scoped to booking_source so unrelated set operations further down cannot match.
        booking_source_sql = rendered.split("eligible_bookings AS (", 1)[0]

        # The xcom-pull expression must be fully resolved, not left as literal Jinja/xcom text.
        assert "task_instance.xcom_pull" not in rendered
        assert "{{" not in rendered
        assert "{%" not in rendered
        assert "item_brand_hist" in rendered
        assert "ean_br" not in rendered
        assert "get_table('dim_item')" not in rendered
        assert "ON a.item_cd = ibh.item_cd" in rendered

        if not is_dev_env:
            # Production uses the environment-specific production source.
            assert "UNION ALL" not in booking_source_sql
            assert "campaign_booking_media_channel_prod" not in booking_source_sql
            assert "WHERE test_booking_flag != 'Y'" in rendered
        elif emulation_run:
            # Emulation uses non-test production bookings and filters out dev rows.
            assert "campaign_booking_media_channel_prod" in rendered
            assert "(True AND test_booking_flag != 'Y')" in rendered
            assert "WHERE NOT True" in rendered
        else:
            # Dev: prefer production test bookings, then use development bookings.
            assert "UNION ALL" in booking_source_sql
            assert "source_priority" in rendered
            assert "campaign_booking_media_channel_prod" in rendered
            assert "(False AND test_booking_flag != 'Y')" in rendered
            assert "(NOT False AND test_booking_flag = 'Y')" in rendered
            assert "WHERE NOT False" in rendered
            assert "campaign_booking_media_channel\n" in rendered
