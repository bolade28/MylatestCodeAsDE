from unittest import mock
from mockito import when
from steps.attribution_pre_requisite import attribution_pre_requisite

from helpers.constants import JOURNEY_TYPE


@mock.patch("steps.attribution_pre_requisite.attribution_pre_requisite.add_and_watch_step")
def test_attribution_pre_requisite(mock_run_step: mock.MagicMock):

    when(attribution_pre_requisite).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(attribution_pre_requisite).get_path("user_journey_aisle").thenReturn("user_journey_aisle")
    when(attribution_pre_requisite).get_path("attribution_pre_requisite_aisle").thenReturn("attribution_pre_requisite_aisle")
    when(attribution_pre_requisite).get_ci().thenReturn("some_correlation_id")
    when(attribution_pre_requisite).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    expected_args = [
        ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
        ("--user-journey-path", "user_journey_aisle"),
        ("--output-path", "attribution_pre_requisite_aisle"),
        ("--journey-type", JOURNEY_TYPE["aisle"]),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "some_correlation_id"),
        ('--slack-topic-arn', "slack_topic_arn")
    ]

    attribution_pre_requisite.tasks('AttributionPreRequisiteAisle', "user_journey_aisle", JOURNEY_TYPE["aisle"], "attribution_pre_requisite_aisle")

    step_name = "AttributionPreRequisiteAisle"
    step_script = "attribution_pre_requisite.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=8,
        executor_cores=4,
        executor_memory="20g",
    )


def test_decide_aisle_processing_returns_skip_when_aisle_skus_disabled():
    """Verifies aisle branch resolves to skip when aisle SKU processing is disabled."""
    # Arrange
    # Force aisle processing flag off.
    with mock.patch("task_groups.attribution_pre_requisite.INCLUDE_AISLE_SKUS", False):
        from task_groups import attribution_pre_requisite

        # Act
        # Resolve the branch target task id.
        result = attribution_pre_requisite.decide_aisle_processing()

        # Assert
        # When disabled, branch should point to skip.
        assert result == "mta_attribution_pre_requisite.skip"


def test_decide_aisle_processing_returns_aisle_task_when_aisle_skus_enabled():
    """Verifies aisle branch resolves to aisle task when aisle SKU processing is enabled."""
    # Arrange
    # Force aisle processing flag on.
    with mock.patch("task_groups.attribution_pre_requisite.INCLUDE_AISLE_SKUS", True):
        from task_groups import attribution_pre_requisite

        # Act
        # Resolve the branch target task id.
        result = attribution_pre_requisite.decide_aisle_processing()

        # Assert
        # When enabled, branch should point to aisle pre-requisite task.
        assert result == "mta_attribution_pre_requisite.attribution_pre_requisite_aisle"
