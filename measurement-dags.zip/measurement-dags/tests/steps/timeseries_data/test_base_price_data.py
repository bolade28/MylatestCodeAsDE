from unittest import mock
from mockito import when
from steps.timeseries_data import base_price_data


@mock.patch("steps.timeseries_data.base_price_data.add_and_watch_step")
def test_base_price_data_tasks(mock_run_step: mock.MagicMock):
    when(base_price_data).get_path("processed_fact_sales_transaction_item").thenReturn("fact_sales")
    when(base_price_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(base_price_data).get_path("dim_store_org_hierarchy").thenReturn("store_hierarchy")
    when(base_price_data).get_path("weekly_dates").thenReturn("weekly_dates")
    when(base_price_data).get_path("base_price_data").thenReturn("base_price_data")
    when(base_price_data).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--fact-sales-path", "fact_sales"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--store-hierarchy-path", "store_hierarchy"),
        ("--weekly-dates-path", "weekly_dates"),
        ("--output-path", "base_price_data"),
        ("--correlation-id", "Corr-1"),
    ]

    execs = 48
    base_price_data.tasks(execs)

    step_name = "BasePriceData"
    step_script = "base_price_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
