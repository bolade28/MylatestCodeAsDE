from unittest import mock
from mockito import when
from steps.timeseries_data import youtube_processed_data


@mock.patch("steps.timeseries_data.youtube_processed_data.add_and_watch_step")
def test_youtube_processed_data(mock_run_step: mock.MagicMock):

    when(youtube_processed_data).get_path("youtube_normalize").thenReturn("youtube_normalize")
    when(youtube_processed_data).get_path("weekly_dates").thenReturn("weekly_dates")
    when(youtube_processed_data).get_path("media_report").thenReturn("media_report")
    when(youtube_processed_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping_temp")
    when(youtube_processed_data).get_path("youtube_processed_data").thenReturn("youtube_processed_data")
    when(youtube_processed_data).get_model_start_end_dates('start_date').thenReturn("2023-06-12")
    when(youtube_processed_data).get_model_start_end_dates('end_date').thenReturn("2025-06-30")
    when(youtube_processed_data).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--youtube-normalize-path", "youtube_normalize"),
        ("--weekly-dates-path", "weekly_dates"),
        ("--media-report-path", "media_report"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping_temp"),
        ("--start-date", "2023-06-12"),
        ("--end-date", "2025-06-30"),
        ("--output-path", "youtube_processed_data"),
        ("--correlation-id", "Corr-1"),
    ]

    execs = 8
    youtube_processed_data.tasks(execs)

    step_name = "YoutubeProcessedData"
    step_script = "youtube_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
