from unittest import mock

from steps.timeseries_data import dv360_processed_data_pollen


def test_dv360_processed_data_pollen_tasks():
    """Verifies DV360 pollen step builds expected args for a custom executor size."""
    # Arrange
    executors = 24
    expected_args = [
        ("--dv360-normalised-path", "path::dv360_normalised_pollen"),
        ("--sku-cluster-mapping-path", "path::sku_cluster_mapping"),
        ("--dv360-media-report-path", "path::dv360_media_report"),
        ("--historic-dv360-processed-data", "path::dv360_processed_data"),
        ("--output-path", "path::dv360_processed_data_pollen"),
        ("--correlation-id", "Corr-1"),
    ]

    # Act: build the step with patched xcom/path helpers for deterministic arguments.
    with mock.patch(
        "steps.timeseries_data.dv360_processed_data_pollen.get_path",
        side_effect=lambda k: f"path::{k}",
    ), mock.patch(
        "steps.timeseries_data.dv360_processed_data_pollen.get_ci",
        return_value="Corr-1",
    ), mock.patch(
        "steps.timeseries_data.dv360_processed_data_pollen.add_and_watch_step",
    ) as mock_run_step:
        dv360_processed_data_pollen.tasks(executors=executors)

    # Assert: validate step metadata/resources and the full argument payload.
    mock_run_step.assert_called_once_with(
        step_name="Dv360ProcessedDataPollen",
        step_script="dv360_processed_data_pollen.py",
        step_args=expected_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )


def test_dv360_processed_data_pollen_default_executors():
    """Verifies DV360 pollen step uses default executors when not provided."""
    # Act: invoke without executors to exercise default executor branch.
    with mock.patch(
        "steps.timeseries_data.dv360_processed_data_pollen.get_path",
        side_effect=lambda k: f"path::{k}",
    ), mock.patch(
        "steps.timeseries_data.dv360_processed_data_pollen.get_ci",
        return_value="Corr-2",
    ), mock.patch(
        "steps.timeseries_data.dv360_processed_data_pollen.add_and_watch_step",
    ) as mock_run_step:
        dv360_processed_data_pollen.tasks()

    # Assert: confirm fallback executor count is applied.
    assert mock_run_step.call_args.kwargs["num_executors"] == 48
