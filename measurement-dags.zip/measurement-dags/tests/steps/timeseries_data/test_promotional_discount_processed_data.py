from unittest import mock
from mockito import when
from steps.timeseries_data import promotional_discount_processed_data


@mock.patch("steps.timeseries_data.promotional_discount_processed_data.add_and_watch_step")
def test_promotional_discount_processed_data(mock_run_step: mock.MagicMock):

    when(promotional_discount_processed_data).get_path("weekly_dates").thenReturn("weekly_dates")
    when(promotional_discount_processed_data).get_path("unified_product").thenReturn("unified_product")
    when(promotional_discount_processed_data).get_path("brand_data").thenReturn("brand_data")
    when(promotional_discount_processed_data).get_path("processed_fact_sales_transaction_item").thenReturn("processed_fact_sales_transaction_item")
    when(promotional_discount_processed_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(promotional_discount_processed_data).get_path("promotional_discount_processed_data").thenReturn("promotional_discount_processed_data")
    when(promotional_discount_processed_data).get_ci().thenReturn("123")

    expected_args = [
        ("--weekly-dates-path", "weekly_dates"),
        ("--item-brand-hist-path", "brand_data"),
        ("--processed-fact-sales-transaction-item", "processed_fact_sales_transaction_item"),
        ("--sku-cluster-mapping", "sku_cluster_mapping"),
        ("--output-path", "promotional_discount_processed_data"),
        ("--correlation-id", "123"),
    ]

    execs = 8
    promotional_discount_processed_data.tasks(execs)

    step_name = "PromotionalDiscountProcessedData"
    step_script = "promotional_discount_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
