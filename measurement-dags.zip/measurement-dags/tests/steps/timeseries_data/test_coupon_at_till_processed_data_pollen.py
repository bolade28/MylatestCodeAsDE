from unittest import mock

from steps.timeseries_data import coupon_at_till_processed_data_pollen


def test_coupon_at_till_processed_data_pollen_custom_executors():
    """Verifies coupon-at-till pollen step builds expected args for custom executors."""
    # Arrange
    executors = 16
    expected_args = [
        ("--campaign-booking-media-channel-path", "path::campaign_booking_media_channel"),
        ("--sku-cluster-mapping-path", "path::sku_cluster_mapping"),
        ("--coupon-path", "path::coupon"),
        ("--coupon-cell-path", "path::coupon_cell"),
        ("--cell-path", "path::cell"),
        ("--campaign-path", "path::campaign"),
        ("--start-date", "2023-01-01"),
        ("--end-date", "2023-12-31"),
        ("--historic-cat-processed-data", "path::coupon_at_till_processed_data"),
        ("--output-path", "path::coupon_at_till_processed_data_pollen"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "Corr-1"),
    ]

    # Act: build the step with patched xcom/path helpers for deterministic arguments.
    with mock.patch(
        "steps.timeseries_data.coupon_at_till_processed_data_pollen.get_path",
        side_effect=lambda name: f"path::{name}",
    ), mock.patch(
        "steps.timeseries_data.coupon_at_till_processed_data_pollen.get_model_start_end_dates",
        side_effect=lambda key: "2023-01-01" if key == "start_date" else "2023-12-31",
    ), mock.patch(
        "steps.timeseries_data.coupon_at_till_processed_data_pollen.get_ci",
        return_value="Corr-1",
    ), mock.patch(
        "steps.timeseries_data.coupon_at_till_processed_data_pollen.add_and_watch_step",
    ) as mock_run_step:
        coupon_at_till_processed_data_pollen.tasks(executors=executors)

    # Assert: validate step metadata/resources and the full argument payload.
    mock_run_step.assert_called_once_with(
        step_name="CouponAtTillProcessedDataPollen",
        step_script="coupon_at_till_processed_pollen.py",
        step_args=expected_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )


def test_coupon_at_till_processed_data_pollen_default_executors():
    """Verifies coupon-at-till pollen step uses default executor count when omitted."""
    # Act: invoke without executors to exercise default executor branch.
    # Todo: as tests could be flagged as duplicate for channel related steps, consider refactoring common logic.
    with mock.patch(
        "steps.timeseries_data.coupon_at_till_processed_data_pollen.get_path",
        side_effect=lambda name: f"path::{name}",
    ), mock.patch(
        "steps.timeseries_data.coupon_at_till_processed_data_pollen.get_model_start_end_dates",
        side_effect=lambda key: "2022-01-01" if key == "start_date" else "2022-06-30",
    ), mock.patch(
        "steps.timeseries_data.coupon_at_till_processed_data_pollen.get_ci",
        return_value="Corr-2",
    ), mock.patch(
        "steps.timeseries_data.coupon_at_till_processed_data_pollen.add_and_watch_step",
    ) as mock_run_step:
        coupon_at_till_processed_data_pollen.tasks()

    # Assert: confirm fallback executor count is applied.
    assert mock_run_step.call_args.kwargs["num_executors"] == 8
