from unittest import mock
from mockito import when
from helpers.constants import CAMPAIGN_DURATION_POST
from steps.timeseries_data import secondary_space_data


@mock.patch("steps.timeseries_data.secondary_space_data.add_and_watch_step")
def test_secondary_space_data(mock_run_step: mock.MagicMock):

    when(secondary_space_data).get_path("weekly_dates").thenReturn("weekly_dates")
    when(secondary_space_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(secondary_space_data).get_path("planogram_campaigns").thenReturn("planogram_campaigns")
    when(secondary_space_data).get_path("dim_section").thenReturn("dim_section")
    when(secondary_space_data).get_path("secondary_space_processed_data").thenReturn("secondary_space_processed_data")
    when(secondary_space_data).get_model_start_end_dates('start_date').thenReturn("2023-06-12")
    when(secondary_space_data).get_model_start_end_dates('end_date').thenReturn("2025-06-30")
    when(secondary_space_data).get_ci().thenReturn("Corr-1")

    expected_args = [

        ("--weekly-dates-path", "weekly_dates"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--plngrm-campaign-item-postn-daily-path", "planogram_campaigns"),
        ("--dim-section-path", "dim_section"),
        ("--output-path", "secondary_space_processed_data"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--start-date", "2023-06-12"),
        ("--end-date", "2025-06-30"),
        ("--correlation-id", "Corr-1"),

    ]

    execs = 8
    secondary_space_data.tasks(execs)

    step_name = "SecondarySpaceProccessedData"
    step_script = "secondary_space_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )


@mock.patch("steps.timeseries_data.secondary_space_data.add_and_watch_step")
def test_secondary_space_data_post_campaign(mock_run_step: mock.MagicMock):

    when(secondary_space_data).get_path("weekly_dates").thenReturn("weekly_dates")
    when(secondary_space_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(secondary_space_data).get_path("planogram_campaigns").thenReturn("planogram_campaigns")
    when(secondary_space_data).get_path("dim_section").thenReturn("dim_section")
    when(secondary_space_data).get_path("secondary_space_processed_data").thenReturn("secondary_space_processed_data")
    when(secondary_space_data).get_path("previous_baseline_modelling_dataset").thenReturn("previous_baseline_modelling_dataset")
    when(secondary_space_data).get_model_start_end_dates('start_date').thenReturn("2023-06-12")
    when(secondary_space_data).get_model_start_end_dates('end_date').thenReturn("2025-06-30")
    when(secondary_space_data).get_ci().thenReturn("Corr-1")
    when(secondary_space_data).get_resolved_during_correlation_id().thenReturn("Corr-during-1")

    expected_args = [
        ("--weekly-dates-path", "weekly_dates"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--plngrm-campaign-item-postn-daily-path", "planogram_campaigns"),
        ("--dim-section-path", "dim_section"),
        ("--output-path", "secondary_space_processed_data"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--start-date", "2023-06-12"),
        ("--end-date", "2025-06-30"),
        ("--correlation-id", "Corr-1"),
        ("--baseline-modelling-dataset-path", "previous_baseline_modelling_dataset"),
        ("--during-correlation-id", "Corr-during-1"),
    ]

    execs = 8
    secondary_space_data.tasks(execs, campaign_duration=CAMPAIGN_DURATION_POST)

    step_name = "SecondarySpaceProccessedData"
    step_script = "secondary_space_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
