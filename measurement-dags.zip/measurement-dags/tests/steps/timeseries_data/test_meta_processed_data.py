from unittest import mock
from mockito import when
from steps.timeseries_data import meta_processed_data


@mock.patch("steps.timeseries_data.meta_processed_data.add_and_watch_step")
def test_meta_processed_data(mock_run_step: mock.MagicMock):

    when(meta_processed_data).get_path("fb_campaign_normalized").thenReturn("fb_campaign_normalized")
    when(meta_processed_data).get_path("fb_insight_normalize").thenReturn("fb_insight_normalize")
    when(meta_processed_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(meta_processed_data).get_path("weekly_dates").thenReturn("weekly_dates")
    when(meta_processed_data).get_path("meta_processed_data").thenReturn("meta_processed_data")
    when(meta_processed_data).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--fb-campaign-normalize-path", "fb_campaign_normalized"),
        ("--fb-insight-normalize-path", "fb_insight_normalize"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--weekly-dates-path", "weekly_dates"),
        ("--output-path", "meta_processed_data"),
        ("--correlation-id", "Corr-1")

    ]

    execs = 8
    meta_processed_data.tasks(execs)

    step_name = "MetaProcessedData"
    step_script = "meta_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
