from unittest import mock
from steps.sku_level_attribution.sku_level_attribution import tasks
from task_groups.sku_level_attribution import decide_aisle_processing
from helpers.constants import PRODUCT_TYPE, DTP_RUN_TYPE, POLLEN_RUN_TYPE
import json
from helpers.channel_hierarchy import SUBCHANNELS_CODE


@mock.patch("steps.sku_level_attribution.sku_level_attribution.add_and_watch_step")
def test_tasks_brand_product_type_dtp_run(mock_run_step: mock.MagicMock):
    with mock.patch("steps.sku_level_attribution.sku_level_attribution.get_path") as mock_get_path, \
         mock.patch("steps.sku_level_attribution.sku_level_attribution.pipeline_run_type") as mock_pipeline_run_type, \
         mock.patch("steps.sku_level_attribution.sku_level_attribution.get_ci") as mock_get_ci, \
         mock.patch("steps.sku_level_attribution.sku_level_attribution.get_sns") as mock_get_sns:

        mock_get_path.side_effect = lambda key: key
        mock_pipeline_run_type.return_value = DTP_RUN_TYPE
        mock_get_ci.return_value = "some_ci"
        mock_get_sns.side_effect = lambda key: key

        # DTP run type (not Pollen), no campaign_duration, no offer product type
        expected_args = [
            ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
            ("--customer-data-collection-path", "customer_data_collection"),
            ("--attribution-model-results-level-path", "attribution_model_results_brand_path"),
            ("--sku-level-attributed-sales-and-units-offer-path", "sku_level_attributed_sales_and_units_offer"),
            ("--output-path", "out_path"),
            ("--product-type", PRODUCT_TYPE["brand"]),
            ("--run-date", "{{ data_interval_end | ds }}"),
            ("--pipeline-run-type", DTP_RUN_TYPE),
            ("--correlation-id", "some_ci"),
            ("--slack-topic-arn", "slack_topic_arn"),
            ("--campaign-duration", None),
            ("--measurement-marketing-channel-hierarchy-path", "measurement_marketing_channel_hierarchy"),
            ("--subchannel-hierarchy-codes", f"'{json.dumps(SUBCHANNELS_CODE)}'"),
        ]

        tasks("SkuLevelAttributedSalesAndUnitsBrand", "attribution_model_results_brand_path", "brand", "out_path")

        mock_run_step.assert_called_with(
            step_name="SkuLevelAttributedSalesAndUnitsBrand",
            step_script="sku_level_attribution.py",
            step_args=expected_args,
            num_executors=48,
            executor_cores=4,
            executor_memory="32g"
        )


@mock.patch("steps.sku_level_attribution.sku_level_attribution.add_and_watch_step")
def test_tasks_offer_product_type_pollen_run(mock_run_step):
    with mock.patch("steps.sku_level_attribution.sku_level_attribution.get_path") as mock_get_path, \
         mock.patch("steps.sku_level_attribution.sku_level_attribution.pipeline_run_type") as mock_pipeline_run_type, \
         mock.patch("steps.sku_level_attribution.sku_level_attribution.get_ci") as mock_get_ci, \
         mock.patch("steps.sku_level_attribution.sku_level_attribution.get_sns") as mock_get_sns:

        mock_get_path.side_effect = lambda key: key
        mock_pipeline_run_type.return_value = POLLEN_RUN_TYPE
        mock_get_ci.return_value = "some_ci"
        mock_get_sns.side_effect = lambda key: key

        subchannel_hierarchy_json = json.dumps(SUBCHANNELS_CODE)
        base_args = [
            ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
            ("--customer-data-collection-path", "customer_data_collection"),
            ("--attribution-model-results-level-path", "attribution_model_results_offer_path"),
            ("--sku-level-attributed-sales-and-units-offer-path", "sku_level_attributed_sales_and_units_offer"),
            ("--output-path", "out_path"),
            ("--product-type", PRODUCT_TYPE["offer"]),
            ("--run-date", "{{ data_interval_end | ds }}"),
            ("--pipeline-run-type", POLLEN_RUN_TYPE),
            ("--correlation-id", "some_ci"),
            ("--slack-topic-arn", "slack_topic_arn"),
            ("--campaign-duration", None),
        ]
        pollen_args = [
            ("--measurement-marketing-channel-hierarchy-path", "measurement_marketing_channel_hierarchy"),
            ("--subchannel-hierarchy-codes", f"'{subchannel_hierarchy_json}'"),
        ]
        offer_args = [
            ("--reach-engagement-path", "reach_engagement_reporting"),
            ("--attribution-pre-requisite-offer-path", "attribution_pre_requisite_offer")
        ]
        expected_args = base_args + pollen_args + offer_args

        tasks("SkuLevelAttributedSalesAndUnitsOffer", "attribution_model_results_offer_path", "offer", "out_path")

        mock_run_step.assert_called_with(
            step_name="SkuLevelAttributedSalesAndUnitsOffer",
            step_script="sku_level_attribution.py",
            step_args=expected_args,
            num_executors=48,
            executor_cores=4,
            executor_memory="32g"
        )


@mock.patch("task_groups.sku_level_attribution.INCLUDE_AISLE_SKUS", True)
def test_decide_aisle_processing_returns_aisle_task_id_when_enabled():
    assert decide_aisle_processing() == "mta_sku_level_attribution.sku_level_attribution_aisle"


@mock.patch("task_groups.sku_level_attribution.INCLUDE_AISLE_SKUS", False)
def test_decide_aisle_processing_returns_skip_task_id_when_disabled():
    assert decide_aisle_processing() == "mta_sku_level_attribution.skip"
