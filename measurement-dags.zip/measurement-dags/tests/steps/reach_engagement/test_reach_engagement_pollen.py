from unittest import mock
from mockito import when
from steps.reach_engagement import reach_engagement_pollen


@mock.patch("steps.reach_engagement.reach_engagement_pollen.get_is_not_emulated_run", return_value='{{(not task_instance.xcom_pull(task_ids="setup_tasks.configure_emulation_run", key="return_value")) | string | lower}}')
@mock.patch("steps.reach_engagement.reach_engagement_pollen.add_and_watch_step")
def test_reach_engagement_pollen(mock_run_step: mock.MagicMock, mock_is_not_emulated: mock.MagicMock):
    when(reach_engagement_pollen).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(reach_engagement_pollen).get_path("digital_trading_campaign_link").thenReturn("digital_trading_campaign_link")
    when(reach_engagement_pollen).get_path("digital_trading_campaign_insight_link").thenReturn("digital_trading_campaign_insight_link")
    when(reach_engagement_pollen).get_path("dv360_media_report").thenReturn("media_report")
    when(reach_engagement_pollen).get_path("unique_reach_lineitem_report").thenReturn("unique_reach_lineitem_report")
    when(reach_engagement_pollen).get_path("floodlight_report").thenReturn("floodlight_report")
    when(reach_engagement_pollen).get_path("user_journey_offer").thenReturn("user_journey_offer")
    when(reach_engagement_pollen).get_path("advertise_request_realised").thenReturn("advertise_request_realised")
    when(reach_engagement_pollen).get_path("advertising_campaign_citcam_sat").thenReturn("advertising_campaign_citcam_sat")
    when(reach_engagement_pollen).get_path("unified_campaigns_pollen").thenReturn("unified_campaigns_pollen")
    when(reach_engagement_pollen).get_path("meta_data").thenReturn("meta_data")
    when(reach_engagement_pollen).get_path("reach_engagement_reporting").thenReturn("reach_engagement_reporting")
    when(reach_engagement_pollen).get_path("marketing_media_hierarchy_mkthrc_ref").thenReturn("marketing_media_hierarchy_mkthrc_ref")
    when(reach_engagement_pollen).get_path("measurement_marketing_channel_hierarchy").thenReturn("measurement_marketing_channel_hierarchy")
    when(reach_engagement_pollen).get_ci().thenReturn("some_correlation_id")
    when(reach_engagement_pollen).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    expected_args = [
        ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
        ("--digital-trading-campaign-channel-dmfbca-link-path", "digital_trading_campaign_link"),
        ("--digital-trading-campaign-insight-dmfbin-link-path", "digital_trading_campaign_insight_link"),
        ("--media-report-path", "media_report"),
        ("--unique-reach-lineitem-report-path", "unique_reach_lineitem_report"),
        ("--floodlight-report-path", "floodlight_report"),
        ("--user-journey-offer-path", "user_journey_offer"),
        ("--advertising-campaign-request-realised-link-path", "advertise_request_realised"),
        ("--advertising-campaign-citcam-sat-path", "advertising_campaign_citcam_sat"),
        ("--unified-campaigns-path", "unified_campaigns_pollen"),
        ("--meta-data-path", "meta_data"),
        ("--output-reporting-path", "reach_engagement_reporting"),
        ("--correlation-id", "some_correlation_id"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--marketing-media-hierarchy-mkthrc-ref-path", "marketing_media_hierarchy_mkthrc_ref"),
        ("--measurement-marketing-channel-hierarchy-path", "measurement_marketing_channel_hierarchy"),
        ("--slack-topic-arn", "slack_topic_arn"),
        ("--campaign-complete", "{{(not task_instance.xcom_pull(task_ids=\"setup_tasks.configure_emulation_run\", key=\"return_value\")) | string | lower}}"),
        ("--subchannel-hierarchy-codes", '\'{"dv360": [3001], "meta": [3009], "youtube": [3014], "coupon_at_till": [2050, 2051], "instore": [2011, 2020, 2028, 2074, 2068, 2067, 2059, 2055, 2078, 2080, 2121, 2135, 2156, 2157, 2159, 2168, 2171, 2178, 2179, 2180, 2181, 2183, 2188, 2189, 2193, 2197, 2012, 2198, 2199, 2200, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2195, 2005, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2060, 2122, 2107, 2185, 2123, 2108, 2167, 2186, 2172, 2182, 2027, 2058, 2066, 2079, 2089, 2082, 2032, 2021, 2022, 2023, 2024, 2025, 2052, 2053, 2076, 2106, 2124, 2131, 2187, 2192, 2134, 2004, 2194, 2173, 2176, 2153, 2147, 2154, 2158, 2036, 2143, 2014, 2064]}\''),
    ]

    execs = 8
    reach_engagement_pollen.tasks(executors=execs)

    step_name = "ReachEngagementPollen"
    step_script = "reach_engagement_pollen.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
