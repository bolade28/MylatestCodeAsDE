from unittest.mock import MagicMock
from unittest import mock
from mockito import when
from steps.baseline_modelling_shrinkage import incremental_shrinkage


@mock.patch("steps.baseline_modelling_shrinkage.incremental_shrinkage.make_path_resolvers")
@mock.patch("steps.baseline_modelling_shrinkage.incremental_shrinkage.add_and_watch_step")
def test_incremental_shrinkage(mock_run_step: MagicMock, mock_make_path_resolvers: MagicMock):
    """
    Test that incremental_shrinkage.tasks() correctly configures and calls add_and_watch_step
    with all required input paths, output paths, and executor configuration.
    """
    mock_make_path_resolvers.return_value = (lambda key: f"s3://source/{key}", lambda key: f"s3://experiment/{key}")
    when(incremental_shrinkage).get_ci().thenReturn("test_correlation_id")

    expected_args = [
        ("--baseline-output-path", "s3://experiment/ucm_output_data"),
        ("--avg-weekly-spend-data-path", "s3://source/sub_cat_brand_weekly_spend"),
        ("--campaign-selection-path", "s3://source/campaign_selection"),
        ("--measurement-legacy-campaign-performance", "s3://source/measurement_legacy_campaign_performance"),
        ("--brand-data-path", "s3://source/brand_data"),
        ("--output-path", "s3://experiment/incremental_shrinkage"),
        ("--output-path-audit", "s3://experiment/incremental_shrinkage_audit"),
        ("--campaign-duration", "During"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "test_correlation_id"),
        ("--ucm-base-data", "s3://experiment/ucm_base_data"),
    ]

    incremental_shrinkage.tasks(step_name="IncrementalShrinkage", campaign_duration="During")

    mock_run_step.assert_called_with(
        step_name="IncrementalShrinkage",
        step_script="incremental_shrinkage.py",
        step_args=expected_args,
        num_executors=48,
        executor_cores=4,
        executor_memory="32g",
    )
