from unittest import mock
from jinja2.nativetypes import NativeEnvironment
from mockito import when
from helpers.constants import CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST
from steps.instore_data_pollen import instore_data_pollen


def stub_paths():
    for path in [
        "measurement_campaign_execution",
        "unified_campaigns_pollen",
        "campaign_booking_media_channel",
        "campaign_product_type",
        "processed_fact_sales_transaction_basket",
        "mta_fact_sale_transaction_item",
        "dim_customer_loyalty",
        "instore_data",
    ]:
        when(instore_data_pollen).get_path(path).thenReturn(path)
    when(instore_data_pollen).get_ci().thenReturn("Corr-1")
    when(instore_data_pollen).get_resolved_during_correlation_id().thenReturn("During-Corr-1")
    when(instore_data_pollen).get_previous_path("customer_data_collection").thenReturn("during_customer_data_collection")


def expected_base_args(campaign_duration_is_post: str):
    return [
        ("--measurement-campaign-execution-status-path", "measurement_campaign_execution"),
        ("--measurement-unified-campaign-pollen-path", "unified_campaigns_pollen"),
        ("--campaign-booking-media-channel-path", "campaign_booking_media_channel"),
        ("--campaign-product-type-path", "campaign_product_type"),
        ("--fact-sale-transaction-basket-path", "processed_fact_sales_transaction_basket"),
        ("--fact-sale-transaction-item-path", "mta_fact_sale_transaction_item"),
        ("--dim-customer-loyalty-path", "dim_customer_loyalty"),
        ("--output-path", "instore_data"),
        ("--correlation-id", "Corr-1"),
        ("--hierarchy-codes", "'2011'", "'2020'"),
        ("--sales-origination-all-codes", "'14'", "'16'", "'17'", "'19'", "'20'", "'21'", "'29'"),
        ("--sales-origination-instore-codes", "'14'", "'16'"),
        ("--sales-origination-online-codes", "'17'", "'19'", "'20'", "'21'", "'29'"),
        ("--campaign-duration-is-post", campaign_duration_is_post),
        ("--transaction-event-name", "transaction"),
        ("--touchpoint-event-name", "touchpoint"),
    ]


@mock.patch.dict("steps.instore_data_pollen.instore_data_pollen.SUBCHANNELS_CODE", {"instore": [2011, 2020]})
@mock.patch("steps.instore_data_pollen.instore_data_pollen.add_and_watch_step")
def test_instore_data_pollen_tasks_during(mock_run_step: mock.MagicMock):
    stub_paths()

    execs = 8
    instore_data_pollen.tasks(campaign_duration=CAMPAIGN_DURATION_DURING, executors=execs)

    mock_run_step.assert_called_with(
        step_name="InStoreDataPollen",
        step_script="instore_data.py",
        step_args=expected_base_args("false"),
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )


@mock.patch.dict("steps.instore_data_pollen.instore_data_pollen.SUBCHANNELS_CODE", {"instore": [2011, 2020]})
@mock.patch("steps.instore_data_pollen.instore_data_pollen.add_and_watch_step")
def test_instore_data_pollen_tasks_post_adds_during_inputs(mock_run_step: mock.MagicMock):
    stub_paths()

    instore_data_pollen.tasks(campaign_duration=CAMPAIGN_DURATION_POST)

    expected_args = expected_base_args("true") + [
        ("--customer-data-collection-path", "during_customer_data_collection"),
        ("--during-correlation-id", "During-Corr-1"),
    ]
    assert mock_run_step.call_args.kwargs["step_args"] == expected_args


@mock.patch("steps.instore_data_pollen.instore_data_pollen.add_and_watch_step")
def test_instore_data_pollen_code_args_stay_strings_after_native_rendering(mock_run_step: mock.MagicMock):
    """EMR only accepts string args; the DAGs render templates as native objects, which turns bare digits into ints."""
    stub_paths()

    instore_data_pollen.tasks(campaign_duration=CAMPAIGN_DURATION_DURING)

    env = NativeEnvironment()
    rendered = [env.from_string(value).render() for arg in mock_run_step.call_args.kwargs["step_args"] for value in arg]
    assert all(isinstance(value, str) for value in rendered)
