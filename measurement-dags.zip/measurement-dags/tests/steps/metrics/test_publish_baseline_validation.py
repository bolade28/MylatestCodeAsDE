from unittest import mock
from mockito import when

from steps.metrics import publish_baseline_validation


@mock.patch("steps.metrics.publish_baseline_validation.add_and_watch_step")
def test_publish_baseline_validation(mock_run_step: mock.MagicMock):

    when(publish_baseline_validation).get_path("campaign_selection").thenReturn("campaign_selection")
    when(publish_baseline_validation).get_path("baseline_modelling_dataset_output").thenReturn("baseline_modelling_dataset_output")
    when(publish_baseline_validation).get_sns("metrics_topic_arn").thenReturn("metrics_topic_arn")
    when(publish_baseline_validation).get_ci().thenReturn("some_correlation_id")

    expected_args = [
        ("--campaign-selection-path", "campaign_selection"),
        ("--baseline-modelling-dataset-path", "baseline_modelling_dataset_output"),
        ("--metrics-topic-arn", "metrics_topic_arn"),
        ("--correlation-id", "some_correlation_id"),
        ("--campaign-duration", "During")
    ]

    execs = 8
    campaign_duration = "During"
    publish_baseline_validation.tasks(campaign_duration=campaign_duration, executors=execs)

    step_name = "PublishBaselineValidation"
    step_script = "publish_baseline_validation.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
