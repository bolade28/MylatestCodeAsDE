from unittest import mock

import pytest

from helpers.constants import CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST
from steps.metrics import hypercare_validation_checks


@pytest.mark.parametrize('campaign_duration', [CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST])
def test_hypercare_validation_checks_arguments(campaign_duration):
    with (
        mock.patch.object(hypercare_validation_checks, 'get_path', side_effect=lambda path: f's3://run/{path}'),
        mock.patch.object(hypercare_validation_checks, 'get_ci', return_value='current-run'),
        mock.patch.object(
            hypercare_validation_checks,
            'get_sns',
            side_effect=lambda topic: {
                'metrics_topic_arn': 'metrics-topic',
                'slack_topic_arn': 'slack-topic',
            }[topic],
        ),
        mock.patch.object(hypercare_validation_checks, 'get_manual_campaigns_list', return_value='booking_1,booking_2'),
        mock.patch.object(hypercare_validation_checks, 'add_and_watch_step') as run_step,
    ):
        result = hypercare_validation_checks.tasks(campaign_duration=campaign_duration, executors=2)

    assert result is run_step.return_value
    run_step.assert_called_once_with(
        step_name='HypercareValidationChecks',
        step_script='publish_hypercare_validation.py',
        step_args=[
            ('--measurement-campaign-reporting-path', 's3://run/measurement_campaign_reporting'),
            ('--reach-engagement-path', 's3://run/reach_engagement_reporting'),
            ('--campaign-booking-media-channel-path', 's3://run/campaign_booking_media_channel'),
            ('--measurement-marketing-channel-hierarchy-path', 's3://run/measurement_marketing_channel_hierarchy'),
            ('--campaign-period', campaign_duration),
            ('--booking-id', '"booking_1,booking_2"'),
            ('--correlation-id', 'current-run'),
            ('--metrics-topic-arn', 'metrics-topic'),
            ('--slack-topic-arn', 'slack-topic'),
            ('--output-path', 's3://run/hypercare_validation_checks'),
        ],
        num_executors=2,
        executor_cores=4,
        executor_memory='20g',
    )


def test_hypercare_validation_checks_rejects_invalid_period():
    with mock.patch.object(hypercare_validation_checks, 'add_and_watch_step') as run_step:
        with pytest.raises(ValueError, match='Unsupported campaign_duration'):
            hypercare_validation_checks.tasks(campaign_duration='invalid')
    run_step.assert_not_called()
