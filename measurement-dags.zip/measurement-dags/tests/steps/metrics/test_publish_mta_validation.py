from unittest import mock
from mockito import when

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE
from steps.metrics import publish_mta_validation


def _mock_common_paths():
    when(publish_mta_validation).get_path("attribution_model_result_brand").thenReturn("attribution_model_result_brand")
    when(publish_mta_validation).get_path("measurement_campaign_reporting").thenReturn("measurement_campaign_reporting")
    when(publish_mta_validation).get_path("user_journey_offer").thenReturn("user_journey_offer")
    when(publish_mta_validation).get_path("user_journey_brand").thenReturn("user_journey_brand")
    when(publish_mta_validation).get_sns("metrics_topic_arn").thenReturn("metrics_topic_arn")
    when(publish_mta_validation).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")
    when(publish_mta_validation).get_ci().thenReturn("some_correlation_id")


@mock.patch("steps.metrics.publish_mta_validation.add_and_watch_step")
def test_publish_mta_validation_dtp(mock_run_step: mock.MagicMock):

    _mock_common_paths()
    when(publish_mta_validation).get_path("unified_campaigns").thenReturn("unified_campaigns")

    expected_args = [
        ("--attribution-model-results-path", "attribution_model_result_brand"),
        ("--measurement-campaign-reporting-path", "measurement_campaign_reporting"),
        ("--user-journey-offer-path", "user_journey_offer"),
        ("--user-journey-brand-path", "user_journey_brand"),
        ("--metrics-topic-arn", "metrics_topic_arn"),
        ("--correlation-id", "some_correlation_id"),
        ("--slack-topic-arn", "slack_topic_arn"),
        ("--unified-campaign-path", "unified_campaigns"),
    ]

    execs = 8
    publish_mta_validation.tasks(pipeline_run_type=DTP_RUN_TYPE, executors=execs)

    mock_run_step.assert_called_with(
        step_name="PublishMTAValidation",
        step_script="publish_mta_validation.py",
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )


@mock.patch("steps.metrics.publish_mta_validation.add_and_watch_step")
def test_publish_mta_validation_pollen(mock_run_step: mock.MagicMock):

    _mock_common_paths()
    when(publish_mta_validation).get_path("unified_campaigns_pollen").thenReturn("unified_campaigns_pollen")

    expected_args = [
        ("--attribution-model-results-path", "attribution_model_result_brand"),
        ("--measurement-campaign-reporting-path", "measurement_campaign_reporting"),
        ("--user-journey-offer-path", "user_journey_offer"),
        ("--user-journey-brand-path", "user_journey_brand"),
        ("--metrics-topic-arn", "metrics_topic_arn"),
        ("--correlation-id", "some_correlation_id"),
        ("--slack-topic-arn", "slack_topic_arn"),
        ("--unified-campaign-path", "unified_campaigns_pollen"),
    ]

    execs = 8
    publish_mta_validation.tasks(pipeline_run_type=POLLEN_RUN_TYPE, executors=execs)

    mock_run_step.assert_called_with(
        step_name="PublishMTAValidation",
        step_script="publish_mta_validation.py",
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
