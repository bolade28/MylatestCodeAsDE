from unittest import mock
from mockito import when

from steps.metrics import mta_metrics


@mock.patch("steps.metrics.mta_metrics.add_and_watch_step")
def test_publish_mta_metrics(mock_run_step: mock.MagicMock):

    when(mta_metrics).get_path("measurement_campaign_reporting").thenReturn("measurement_campaign_reporting")
    when(mta_metrics).get_path("reach_engagement_reporting").thenReturn("reach_engagement_reporting")
    when(mta_metrics).get_sns("metrics_topic_arn").thenReturn("metrics_topic_arn")
    when(mta_metrics).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")
    when(mta_metrics).get_ci().thenReturn("some_correlation_id")

    expected_args = [
        ("--measurement-campaign-reporting-path", "measurement_campaign_reporting"),
        ("--reach-engagement-detail-path", "reach_engagement_reporting"),
        ("--metrics-topic-arn", "metrics_topic_arn"),
        ("--correlation-id", "some_correlation_id"),
        ("--slack-topic-arn", "slack_topic_arn"),
        ("--run-date", "{{ data_interval_end | ds }}"),
    ]

    execs = 8
    mta_metrics.tasks(executors=execs)

    step_name = "MTA_Metrics"
    step_script = "publish_mta_metrics.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
