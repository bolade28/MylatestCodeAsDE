from unittest import mock
from mockito import when

from steps.metrics import publish_pipeline_summary
from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE


@mock.patch("steps.metrics.publish_pipeline_summary.add_and_watch_step")
def test_publish_pipeline_summary_for_dtp_run_type(mock_run_step: mock.MagicMock):

    when(publish_pipeline_summary).get_path("campaign_product_type").thenReturn("campaign_product_type")
    when(publish_pipeline_summary).get_path("baseline_modelling_dataset_output").thenReturn("baseline_modelling_dataset_output")
    when(publish_pipeline_summary).get_path("feature_prioritisation").thenReturn("feature_prioritisation")
    when(publish_pipeline_summary).get_path("incremental_shrinkage").thenReturn("incremental_shrinkage")
    when(publish_pipeline_summary).get_path("incremental_shrinkage_audit").thenReturn("incremental_shrinkage_audit")
    when(publish_pipeline_summary).get_path("ucm_output_data").thenReturn("ucm_output_data")
    when(publish_pipeline_summary).get_path("ucm_base_data").thenReturn("ucm_base_data")
    when(publish_pipeline_summary).get_path("campaign_booking_media_channel").thenReturn("campaign_booking_media_channel")
    when(publish_pipeline_summary).get_path("unified_campaigns").thenReturn("unified_campaigns")
    when(publish_pipeline_summary).get_manual_campaigns_list().thenReturn("booking_1,booking_2")
    when(publish_pipeline_summary).get_sns("metrics_topic_arn").thenReturn("metrics_topic_arn")
    when(publish_pipeline_summary).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")
    when(publish_pipeline_summary).get_ci().thenReturn("some_correlation_id")
    when(publish_pipeline_summary).get_path("user_journey_offer").thenReturn("user_journey_offer")
    when(publish_pipeline_summary).get_path("user_journey_brand").thenReturn("user_journey_brand")
    when(publish_pipeline_summary).get_path("attribution_model_result_brand").thenReturn("attribution_model_result_brand")
    when(publish_pipeline_summary).get_path("sku_level_attributed_sales_and_units_offer").thenReturn("sku_level_attributed_sales_and_units_offer")
    when(publish_pipeline_summary).get_path("sku_level_attributed_sales_and_units_brand").thenReturn("sku_level_attributed_sales_and_units_brand")

    expected_args = [
        ("--campaign-product-type-path", "campaign_product_type"),
        ("--baseline-modelling-dataset-path", "baseline_modelling_dataset_output"),
        ("--feature-prioritisation-path", "feature_prioritisation"),
        ("--incremental-shrinkage-path", "incremental_shrinkage"),
        ("--calibration-audit-path", "incremental_shrinkage_audit"),
        ("--ucm-output-data-path", "ucm_output_data"),
        ("--ucm-base-data-path", "ucm_base_data"),
        ("--campaign-booking-media-channel-path", "campaign_booking_media_channel"),
        ("--booking-id", '"booking_1,booking_2"'),
        ("--metrics-topic-arn", "metrics_topic_arn"),
        ("--slack-topic-arn", "slack_topic_arn"),
        ("--correlation-id", "some_correlation_id"),
        ("--user-journey-offer-path", "user_journey_offer"),
        ("--user-journey-brand-path", "user_journey_brand"),
        ("--attribution-model-results-path", "attribution_model_result_brand"),
        ("--sku-level-attributed-sales-offer-path", "sku_level_attributed_sales_and_units_offer"),
        ("--sku-level-attributed-sales-brand-path", "sku_level_attributed_sales_and_units_brand"),
        ("--unified-campaign-path", "unified_campaigns"),
    ]

    execs = 8
    publish_pipeline_summary.tasks(executors=execs, pipeline_run_type=DTP_RUN_TYPE)

    step_name = "PublishPipelineSummary"
    step_script = "publish_pipeline_summary.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )


@mock.patch("steps.metrics.publish_pipeline_summary.add_and_watch_step")
def test_publish_pipeline_summary_for_pollen_run_type(mock_run_step: mock.MagicMock):

    when(publish_pipeline_summary).get_path("campaign_product_type").thenReturn("campaign_product_type")
    when(publish_pipeline_summary).get_path("baseline_modelling_dataset_output").thenReturn("baseline_modelling_dataset_output")
    when(publish_pipeline_summary).get_path("feature_prioritisation").thenReturn("feature_prioritisation")
    when(publish_pipeline_summary).get_path("incremental_shrinkage").thenReturn("incremental_shrinkage")
    when(publish_pipeline_summary).get_path("incremental_shrinkage_audit").thenReturn("incremental_shrinkage_audit")
    when(publish_pipeline_summary).get_path("ucm_output_data").thenReturn("ucm_output_data")
    when(publish_pipeline_summary).get_path("ucm_base_data").thenReturn("ucm_base_data")
    when(publish_pipeline_summary).get_path("campaign_booking_media_channel").thenReturn("campaign_booking_media_channel")
    when(publish_pipeline_summary).get_path("unified_campaigns_pollen").thenReturn("unified_campaigns_pollen")
    when(publish_pipeline_summary).get_manual_campaigns_list().thenReturn("booking_1,booking_2")
    when(publish_pipeline_summary).get_sns("metrics_topic_arn").thenReturn("metrics_topic_arn")
    when(publish_pipeline_summary).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")
    when(publish_pipeline_summary).get_ci().thenReturn("some_correlation_id")
    when(publish_pipeline_summary).get_path("user_journey_offer").thenReturn("user_journey_offer")
    when(publish_pipeline_summary).get_path("user_journey_brand").thenReturn("user_journey_brand")
    when(publish_pipeline_summary).get_path("attribution_model_result_brand").thenReturn("attribution_model_result_brand")
    when(publish_pipeline_summary).get_path("sku_level_attributed_sales_and_units_offer").thenReturn("sku_level_attributed_sales_and_units_offer")
    when(publish_pipeline_summary).get_path("sku_level_attributed_sales_and_units_brand").thenReturn("sku_level_attributed_sales_and_units_brand")

    expected_args = [
        ("--campaign-product-type-path", "campaign_product_type"),
        ("--baseline-modelling-dataset-path", "baseline_modelling_dataset_output"),
        ("--feature-prioritisation-path", "feature_prioritisation"),
        ("--incremental-shrinkage-path", "incremental_shrinkage"),
        ("--calibration-audit-path", "incremental_shrinkage_audit"),
        ("--ucm-output-data-path", "ucm_output_data"),
        ("--ucm-base-data-path", "ucm_base_data"),
        ("--campaign-booking-media-channel-path", "campaign_booking_media_channel"),
        ("--booking-id", '"booking_1,booking_2"'),
        ("--metrics-topic-arn", "metrics_topic_arn"),
        ("--slack-topic-arn", "slack_topic_arn"),
        ("--correlation-id", "some_correlation_id"),
        ("--user-journey-offer-path", "user_journey_offer"),
        ("--user-journey-brand-path", "user_journey_brand"),
        ("--attribution-model-results-path", "attribution_model_result_brand"),
        ("--sku-level-attributed-sales-offer-path", "sku_level_attributed_sales_and_units_offer"),
        ("--sku-level-attributed-sales-brand-path", "sku_level_attributed_sales_and_units_brand"),
        ("--unified-campaign-path", "unified_campaigns_pollen"),
    ]

    execs = 8
    publish_pipeline_summary.tasks(executors=execs, pipeline_run_type=POLLEN_RUN_TYPE)

    step_name = "PublishPipelineSummary"
    step_script = "publish_pipeline_summary.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )


def test_publish_pipeline_summary_raises_for_unsupported_run_type():
    unsupported_run_type = "INVALID"

    with mock.patch("steps.metrics.publish_pipeline_summary.get_path"), \
         mock.patch("steps.metrics.publish_pipeline_summary.get_manual_campaigns_list"), \
         mock.patch("steps.metrics.publish_pipeline_summary.get_sns"), \
         mock.patch("steps.metrics.publish_pipeline_summary.get_ci"):
        try:
            publish_pipeline_summary.tasks(pipeline_run_type=unsupported_run_type)
            assert False, "Expected ValueError for unsupported pipeline_run_type"
        except ValueError as exc:
            assert str(exc) == (
                "Unsupported pipeline_run_type: 'INVALID'. "
                "Expected 'DTP' or 'Pollen'."
            )
