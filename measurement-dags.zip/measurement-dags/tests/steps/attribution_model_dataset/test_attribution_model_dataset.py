import pytest
from collections import Counter
from unittest import mock
from mockito import when

from steps.attribution_model_dataset import attribution_model_dataset


@pytest.fixture(autouse=True)
def unstub_mockito():
    from mockito import unstub
    yield
    unstub()


@pytest.mark.parametrize("journey_type,pipeline_run_type,step_name", [
    ("brand", "DTP", "AttributionModelDatasetBrand"),
    ("offer", "DTP", "AttributionModelDatasetOffer"),
    ("brand", "Pollen", "AttributionModelDatasetBrandPollen"),
    ("offer", "Pollen", "AttributionModelDatasetOfferPollen"),
])
@mock.patch("steps.attribution_model_dataset.attribution_model_dataset.add_and_watch_step")
def test_attribution_model_dataset(mock_add_step, journey_type, pipeline_run_type, step_name):
    """Verifies dataset step arguments and defaults for each journey and pipeline combination."""
    # Arrange
    # Stub all helper lookups so the test remains deterministic.
    when(attribution_model_dataset).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(attribution_model_dataset).get_path(f"attribution_pre_requisite_{journey_type}").thenReturn(f"attribution_pre_requisite_{journey_type}")
    when(attribution_model_dataset).get_path("campaign_decay_rate").thenReturn("campaign_decay_rate")
    when(attribution_model_dataset).get_path(f"journey_channel_metadata_{journey_type}").thenReturn(f"journey_channel_metadata_{journey_type}")
    when(attribution_model_dataset).get_path(f"attribution_model_dataset_flattened_{journey_type}").thenReturn(f"attribution_model_dataset_flattened_{journey_type}")
    when(attribution_model_dataset).get_ci().thenReturn("some_correlation_id")
    when(attribution_model_dataset).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    expected_args = [
        ("--measurement-campaign-path", "measurement_campaign_execution"),
        ("--attribution-prerequisite-path", f"attribution_pre_requisite_{journey_type}"),
        ("--campaign-decay-path", "campaign_decay_rate"),
        ("--journey-channel-metadata-path", f"journey_channel_metadata_{journey_type}"),
        ("--attribution-model-dataset-flattened-path", f"attribution_model_dataset_flattened_{journey_type}"),
        ("--journey-type", journey_type),
        ("--job-run-id", "some_correlation_id"),
        ("--slack-topic-arn", "slack_topic_arn"),
        ("--pipeline-run-type", pipeline_run_type),
    ]

    # Act
    # Build the EMR step for the requested journey/run-type variant.
    result = attribution_model_dataset.tasks(
        step_name=step_name,
        journey_type=journey_type,
        attribution_pre_requisite=f"attribution_pre_requisite_{journey_type}",
        journey_channel_metadata_path=f"journey_channel_metadata_{journey_type}",
        attribution_model_dataset_flattened_path=f"attribution_model_dataset_flattened_{journey_type}",
        pipeline_run_type=pipeline_run_type,
    )

    # Assert
    # Ensure the step wiring and resources are passed to add_and_watch_step.
    # Check args separately to allow harmless ordering changes.
    call_args = mock_add_step.call_args
    assert call_args.kwargs["step_name"] == step_name
    assert call_args.kwargs["step_script"] == "attribution_model_dataset.py"
    assert call_args.kwargs["num_executors"] == 48
    assert call_args.kwargs["executor_cores"] == 8
    assert call_args.kwargs["executor_memory"] == "32g"
    # Verify all required args are present, including multiplicity (order-insensitive).
    actual_args_counter = Counter(call_args.kwargs["step_args"])
    expected_args_counter = Counter(expected_args)
    assert actual_args_counter == expected_args_counter
    assert result == mock_add_step.return_value


@mock.patch("steps.attribution_model_dataset.attribution_model_dataset.add_and_watch_step")
def test_attribution_model_dataset_custom_executors(mock_add_step):
    """Verifies a custom executor count is forwarded to the EMR step builder."""
    # Arrange
    # Stub path/id helpers and provide an explicit executor override.
    when(attribution_model_dataset).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(attribution_model_dataset).get_path("attribution_pre_requisite_brand").thenReturn("attribution_pre_requisite_brand")
    when(attribution_model_dataset).get_path("campaign_decay_rate").thenReturn("campaign_decay_rate")
    when(attribution_model_dataset).get_path("journey_channel_metadata_brand").thenReturn("journey_channel_metadata_brand")
    when(attribution_model_dataset).get_path("attribution_model_dataset_flattened_brand").thenReturn("attribution_model_dataset_flattened_brand")
    when(attribution_model_dataset).get_ci().thenReturn("some_correlation_id")
    when(attribution_model_dataset).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    # Act
    # Build the task using a non-default executor count.
    attribution_model_dataset.tasks(
        step_name="AttributionModelDatasetBrand",
        journey_type="brand",
        attribution_pre_requisite="attribution_pre_requisite_brand",
        journey_channel_metadata_path="journey_channel_metadata_brand",
        attribution_model_dataset_flattened_path="attribution_model_dataset_flattened_brand",
        pipeline_run_type="DTP",
        executors=16,
    )

    # Assert
    # Verify the custom executor value propagates to the EMR operator config.
    mock_add_step.assert_called_once_with(
        step_name="AttributionModelDatasetBrand",
        step_script="attribution_model_dataset.py",
        step_args=mock.ANY,
        num_executors=16,
        executor_cores=8,
        executor_memory="32g",
    )


@mock.patch("steps.attribution_model_dataset.attribution_model_dataset.add_and_watch_step")
def test_attribution_model_dataset_step_script_is_exact(mock_add_step):
    """Verifies step script name is exactly attribution_model_dataset.py for all variants."""
    # Arrange
    # Stub all helper lookups.
    when(attribution_model_dataset).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(attribution_model_dataset).get_path("attribution_pre_requisite_brand").thenReturn("attribution_pre_requisite_brand")
    when(attribution_model_dataset).get_path("campaign_decay_rate").thenReturn("campaign_decay_rate")
    when(attribution_model_dataset).get_path("journey_channel_metadata_brand").thenReturn("journey_channel_metadata_brand")
    when(attribution_model_dataset).get_path("attribution_model_dataset_flattened_brand").thenReturn("attribution_model_dataset_flattened_brand")
    when(attribution_model_dataset).get_ci().thenReturn("some_correlation_id")
    when(attribution_model_dataset).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    # Act
    # Build dataset task.
    attribution_model_dataset.tasks(
        step_name="AttributionModelDatasetBrand",
        journey_type="brand",
        attribution_pre_requisite="attribution_pre_requisite_brand",
        journey_channel_metadata_path="journey_channel_metadata_brand",
        attribution_model_dataset_flattened_path="attribution_model_dataset_flattened_brand",
        pipeline_run_type="DTP",
    )

    # Assert
    # Ensure step_script is never anything other than the expected value.
    call_args = mock_add_step.call_args
    assert call_args.kwargs["step_script"] == "attribution_model_dataset.py"
