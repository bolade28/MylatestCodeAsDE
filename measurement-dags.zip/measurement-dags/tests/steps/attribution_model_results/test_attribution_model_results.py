import pytest
from unittest import mock
from mockito import when
from steps.attribution_model_results import attribution_model_results


@pytest.fixture(autouse=True)
def unstub_mockito():
    from mockito import unstub
    yield
    unstub()


@pytest.mark.parametrize("journey_type,pipeline_run_type,step_script,step_name,synergy_output,expected_extra", [
    ("brand", "DTP", "attribution_model_results.py", "AttributionModelResultBrand", None, []),
    ("offer", "DTP", "attribution_model_results.py", "AttributionModelResultOffer", "attribution_synergy_results",
     [("--synergy-output-path", "attribution_synergy_results")]),
    ("brand", "Pollen", "attribution_model_results.py", "AttributionModelResultBrandPollen", None, []),
    ("offer", "Pollen", "attribution_model_results.py", "AttributionModelResultOfferPollen", "attribution_synergy_results",
     [("--synergy-output-path", "attribution_synergy_results")]),
])
@mock.patch("steps.attribution_model_results.attribution_model_results.make_path_resolvers")
@mock.patch("steps.attribution_model_results.attribution_model_results.add_and_watch_step")
def test_attribution_model_results(mock_add_step, mock_make_resolvers, journey_type, pipeline_run_type, step_script, step_name, synergy_output, expected_extra):

    mock_make_resolvers.return_value = (lambda key: key, lambda key: key)
    when(attribution_model_results).get_ci().thenReturn("some_correlation_id")
    when(attribution_model_results).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    expected_args = [
        ("--attribution-model-dataset-flattened-path", f"attribution_model_dataset_flattened_{journey_type}"),
        ("--journey-channel-metadata-path", f"journey_channel_metadata_{journey_type}"),
        ("--output-path", f"attribution_model_result_{journey_type}"),
        ("--job-run-id", "some_correlation_id"),
        ("--slack-topic-arn", "slack_topic_arn"),
        ("--journey-type", journey_type),
        ("--pipeline-run-type", pipeline_run_type),
        *expected_extra,
    ]

    kwargs = dict(
        step_name=step_name,
        journey_type=journey_type,
        attribution_model_dataset_flattened_path=f"attribution_model_dataset_flattened_{journey_type}",
        journey_channel_metadata_path=f"journey_channel_metadata_{journey_type}",
        output_path=f"attribution_model_result_{journey_type}",
        pipeline_run_type=pipeline_run_type,
    )
    if synergy_output:
        kwargs["synergy_output_path"] = synergy_output

    result = attribution_model_results.tasks(**kwargs)

    mock_add_step.assert_called_once_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=48,
        executor_cores=8,
        executor_memory="32g",
    )
    assert result == mock_add_step.return_value
