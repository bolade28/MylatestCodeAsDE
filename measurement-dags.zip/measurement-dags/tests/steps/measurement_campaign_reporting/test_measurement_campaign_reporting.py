from unittest import mock
from mockito import when
from steps.measurement_campaign_reporting import measurement_campaign_reporting
from helpers.constants import CAMPAIGN_DURATION_POST, POLLEN_RUN_TYPE


@mock.patch("steps.measurement_campaign_reporting.measurement_campaign_reporting.add_and_watch_step")
def test_measurement_campaign_reporting(mock_run_step: mock.MagicMock):
    """
    Test that measurement_campaign_reporting.tasks() correctly configures and calls add_and_watch_step
    with all required input paths, output path, and executor configuration.
    """
    # Mock the xcom path lookups
    when(measurement_campaign_reporting).get_path("incremental_shrinkage").thenReturn("s3://bucket/incremental/shrinkage")
    when(measurement_campaign_reporting).get_path("reach_engagement_reporting").thenReturn("s3://bucket/reach/engagement/reporting")
    when(measurement_campaign_reporting).get_path("measurement_campaign_execution").thenReturn("s3://bucket/campaign/execution")
    when(measurement_campaign_reporting).get_path("unified_campaigns").thenReturn("s3://bucket/unified/campaign")
    when(measurement_campaign_reporting).get_path("sku_level_attributed_sales_and_units_brand").thenReturn("s3://bucket/sku/attributed/sales/units/brand")
    when(measurement_campaign_reporting).get_path("sku_level_attributed_sales_and_units_offer").thenReturn("s3://bucket/sku/attributed/sales/units/offer")
    when(measurement_campaign_reporting).get_path("attribution_pre_requisite_brand").thenReturn("s3://bucket/pre/mta/brand")
    when(measurement_campaign_reporting).get_path("attribution_pre_requisite_offer").thenReturn("s3://bucket/pre/mta/offer")
    when(measurement_campaign_reporting).get_path("measurement_campaign_reporting").thenReturn("s3://bucket/measurement/campaign/reporting")
    when(measurement_campaign_reporting).get_path("measurement_campaign_reporting_audit").thenReturn("s3://bucket/measurement/campaign/reporting/audit")
    when(measurement_campaign_reporting).get_path("incrementality_fallback_metadata").thenReturn("s3://bucket/incrementality/fallback/metadata")
    when(measurement_campaign_reporting).get_path("published_campaign_reporting").thenReturn("s3://bucket/published/campaign/reporting")
    when(measurement_campaign_reporting).get_path("measurement_legacy_campaign_performance").thenReturn("s3://bucket/measurement/legacy/campaign/performance")
    when(measurement_campaign_reporting).get_path("brand_data").thenReturn("s3://bucket/brand/data")
    when(measurement_campaign_reporting).get_path("base_price_data").thenReturn("s3://bucket/base_price")
    when(measurement_campaign_reporting).get_path("measurement_marketing_channel_hierarchy").thenReturn("s3://bucket/measurement/marketing/channel/hierarchy")
    when(measurement_campaign_reporting).get_ci().thenReturn("test_correlation_id")
    when(measurement_campaign_reporting).get_sns("slack_topic_arn").thenReturn("test_slack_topic_arn")

    expected_args = [
        ("--campaign-execution-path", "s3://bucket/campaign/execution"),
        ("--unified-campaign-path", "s3://bucket/unified/campaign"),
        ("--sku-level-attributed-sales-units-brand-path", "s3://bucket/sku/attributed/sales/units/brand"),
        ("--sku-level-attributed-sales-units-offer-path", "s3://bucket/sku/attributed/sales/units/offer"),
        ("--pre-mta-brand-path", "s3://bucket/pre/mta/brand"),
        ("--pre-mta-offer-path", "s3://bucket/pre/mta/offer"),
        ("--base-price-path", "s3://bucket/base_price"),
        ("--measurement-marketing-channel-hierarchy-path", "s3://bucket/measurement/marketing/channel/hierarchy"),
        ("--incremental-shrinkage-path", "s3://bucket/incremental/shrinkage"),
        ("--reach-engagement-path", "s3://bucket/reach/engagement/reporting"),
        ("--output-path", "s3://bucket/measurement/campaign/reporting"),
        ("--measurement-campaign-reporting-audit-path", "s3://bucket/measurement/campaign/reporting/audit"),
        ("--fallback-metadata-path", "s3://bucket/incrementality/fallback/metadata"),
        ("--published-campaign-reporting-path", "s3://bucket/published/campaign/reporting"),
        ("--measurement-legacy-campaign-performance", "s3://bucket/measurement/legacy/campaign/performance"),
        ("--brand-data-path", "s3://bucket/brand/data"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "test_correlation_id"),
        ("--slack-topic-arn", "test_slack_topic_arn"),
    ]

    # Call the tasks function with default parameters
    measurement_campaign_reporting.tasks()

    step_name = "MeasurementCampaignReporting"
    step_script = "measurement_campaign_reporting.py"

    # Verify add_and_watch_step was called with correct arguments
    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=8,
        executor_cores=4,
        executor_memory="20g",
    )


@mock.patch("steps.measurement_campaign_reporting.measurement_campaign_reporting.add_and_watch_step")
def test_measurement_campaign_reporting_pollen_adds_campaign_period(mock_run_step: mock.MagicMock):
    when(measurement_campaign_reporting).get_path("incremental_shrinkage").thenReturn("s3://bucket/incremental/shrinkage")
    when(measurement_campaign_reporting).get_path("reach_engagement_reporting").thenReturn("s3://bucket/reach/engagement/reporting")
    when(measurement_campaign_reporting).get_path("measurement_campaign_execution").thenReturn("s3://bucket/campaign/execution")
    when(measurement_campaign_reporting).get_path("campaign_booking_media_channel").thenReturn("s3://bucket/campaign/booking/media/channel")
    when(measurement_campaign_reporting).get_path("unified_campaigns_pollen").thenReturn("s3://bucket/unified/campaign/pollen")
    when(measurement_campaign_reporting).get_path("sku_level_attributed_sales_and_units_brand").thenReturn("s3://bucket/sku/attributed/sales/units/brand")
    when(measurement_campaign_reporting).get_path("sku_level_attributed_sales_and_units_offer").thenReturn("s3://bucket/sku/attributed/sales/units/offer")
    when(measurement_campaign_reporting).get_path("attribution_pre_requisite_brand").thenReturn("s3://bucket/pre/mta/brand")
    when(measurement_campaign_reporting).get_path("attribution_pre_requisite_offer").thenReturn("s3://bucket/pre/mta/offer")
    when(measurement_campaign_reporting).get_path("measurement_campaign_reporting").thenReturn("s3://bucket/measurement/campaign/reporting")
    when(measurement_campaign_reporting).get_path("measurement_campaign_reporting_audit").thenReturn("s3://bucket/measurement/campaign/reporting/audit")
    when(measurement_campaign_reporting).get_path("incrementality_fallback_metadata").thenReturn("s3://bucket/incrementality/fallback/metadata")
    when(measurement_campaign_reporting).get_path("published_campaign_reporting").thenReturn("s3://bucket/published/campaign/reporting")
    when(measurement_campaign_reporting).get_path("measurement_legacy_campaign_performance").thenReturn("s3://bucket/measurement/legacy/campaign/performance")
    when(measurement_campaign_reporting).get_path("brand_data").thenReturn("s3://bucket/brand/data")
    when(measurement_campaign_reporting).get_path("base_price_data").thenReturn("s3://bucket/base_price")
    when(measurement_campaign_reporting).get_path("measurement_marketing_channel_hierarchy").thenReturn("s3://bucket/measurement/marketing/channel/hierarchy")
    when(measurement_campaign_reporting).get_path("overlapping_campaign_spend_weights").thenReturn("s3://bucket/overlapping/campaign/spend/weights")
    when(measurement_campaign_reporting).get_ci().thenReturn("test_correlation_id")
    when(measurement_campaign_reporting).get_sns("slack_topic_arn").thenReturn("test_slack_topic_arn")

    measurement_campaign_reporting.tasks(
        pipeline_run_type=POLLEN_RUN_TYPE,
        campaign_duration="during",
    )

    step_args = mock_run_step.call_args.kwargs["step_args"]
    assert ("--campaign-period", "during") in step_args
    assert ("--overlapping-campaign-spend-weights-path", "s3://bucket/overlapping/campaign/spend/weights") in step_args


@mock.patch("steps.measurement_campaign_reporting.measurement_campaign_reporting.add_and_watch_step")
def test_measurement_campaign_reporting_pollen_non_post_adds_booking_path_not_previous(mock_run_step: mock.MagicMock):
    when(measurement_campaign_reporting).get_path("incremental_shrinkage").thenReturn("s3://bucket/incremental/shrinkage")
    when(measurement_campaign_reporting).get_path("reach_engagement_reporting").thenReturn("s3://bucket/reach/engagement/reporting")
    when(measurement_campaign_reporting).get_path("measurement_campaign_execution").thenReturn("s3://bucket/campaign/execution")
    when(measurement_campaign_reporting).get_path("campaign_booking_media_channel").thenReturn("s3://bucket/campaign/booking/media/channel")
    when(measurement_campaign_reporting).get_path("unified_campaigns_pollen").thenReturn("s3://bucket/unified/campaign/pollen")
    when(measurement_campaign_reporting).get_path("sku_level_attributed_sales_and_units_brand").thenReturn("s3://bucket/sku/attributed/sales/units/brand")
    when(measurement_campaign_reporting).get_path("sku_level_attributed_sales_and_units_offer").thenReturn("s3://bucket/sku/attributed/sales/units/offer")
    when(measurement_campaign_reporting).get_path("attribution_pre_requisite_brand").thenReturn("s3://bucket/pre/mta/brand")
    when(measurement_campaign_reporting).get_path("attribution_pre_requisite_offer").thenReturn("s3://bucket/pre/mta/offer")
    when(measurement_campaign_reporting).get_path("measurement_campaign_reporting").thenReturn("s3://bucket/measurement/campaign/reporting")
    when(measurement_campaign_reporting).get_path("measurement_campaign_reporting_audit").thenReturn("s3://bucket/measurement/campaign/reporting/audit")
    when(measurement_campaign_reporting).get_path("incrementality_fallback_metadata").thenReturn("s3://bucket/incrementality/fallback/metadata")
    when(measurement_campaign_reporting).get_path("published_campaign_reporting").thenReturn("s3://bucket/published/campaign/reporting")
    when(measurement_campaign_reporting).get_path("measurement_legacy_campaign_performance").thenReturn("s3://bucket/measurement/legacy/campaign/performance")
    when(measurement_campaign_reporting).get_path("brand_data").thenReturn("s3://bucket/brand/data")
    when(measurement_campaign_reporting).get_path("base_price_data").thenReturn("s3://bucket/base_price")
    when(measurement_campaign_reporting).get_path("measurement_marketing_channel_hierarchy").thenReturn("s3://bucket/measurement/marketing/channel/hierarchy")
    when(measurement_campaign_reporting).get_path("overlapping_campaign_spend_weights").thenReturn("s3://bucket/overlapping/campaign/spend/weights")
    when(measurement_campaign_reporting).get_ci().thenReturn("test_correlation_id")
    when(measurement_campaign_reporting).get_sns("slack_topic_arn").thenReturn("test_slack_topic_arn")

    measurement_campaign_reporting.tasks(
        pipeline_run_type=POLLEN_RUN_TYPE,
        campaign_duration="during",
    )

    step_args = mock_run_step.call_args.kwargs["step_args"]
    assert ("--campaign-booking-media-channel-path", "s3://bucket/campaign/booking/media/channel") in step_args
    assert not any(arg[0] == "--previous-measurement-campaign-reporting" for arg in step_args)


@mock.patch("steps.measurement_campaign_reporting.measurement_campaign_reporting.add_and_watch_step")
def test_measurement_campaign_reporting_pollen_post_adds_previous_reporting_path(mock_run_step: mock.MagicMock):
    when(measurement_campaign_reporting).get_path("incremental_shrinkage").thenReturn("s3://bucket/incremental/shrinkage")
    when(measurement_campaign_reporting).get_path("reach_engagement_reporting").thenReturn("s3://bucket/reach/engagement/reporting")
    when(measurement_campaign_reporting).get_path("measurement_campaign_execution").thenReturn("s3://bucket/campaign/execution")
    when(measurement_campaign_reporting).get_path("unified_campaigns_pollen").thenReturn("s3://bucket/unified/campaign/pollen")
    when(measurement_campaign_reporting).get_path("sku_level_attributed_sales_and_units_brand").thenReturn("s3://bucket/sku/attributed/sales/units/brand")
    when(measurement_campaign_reporting).get_path("sku_level_attributed_sales_and_units_offer").thenReturn("s3://bucket/sku/attributed/sales/units/offer")
    when(measurement_campaign_reporting).get_path("attribution_pre_requisite_brand").thenReturn("s3://bucket/pre/mta/brand")
    when(measurement_campaign_reporting).get_path("attribution_pre_requisite_offer").thenReturn("s3://bucket/pre/mta/offer")
    when(measurement_campaign_reporting).get_path("measurement_campaign_reporting").thenReturn("s3://bucket/measurement/campaign/reporting")
    when(measurement_campaign_reporting).get_path("measurement_campaign_reporting_audit").thenReturn("s3://bucket/measurement/campaign/reporting/audit")
    when(measurement_campaign_reporting).get_path("incrementality_fallback_metadata").thenReturn("s3://bucket/incrementality/fallback/metadata")
    when(measurement_campaign_reporting).get_path("published_campaign_reporting").thenReturn("s3://bucket/published/campaign/reporting")
    when(measurement_campaign_reporting).get_path("measurement_legacy_campaign_performance").thenReturn("s3://bucket/measurement/legacy/campaign/performance")
    when(measurement_campaign_reporting).get_path("brand_data").thenReturn("s3://bucket/brand/data")
    when(measurement_campaign_reporting).get_path("previous_measurement_campaign_reporting").thenReturn("s3://bucket/measurement/campaign/reporting/previous")
    when(measurement_campaign_reporting).get_path("post_period_audit").thenReturn("s3://bucket/post/period/audit")
    when(measurement_campaign_reporting).get_path("base_price_data").thenReturn("s3://bucket/base_price")
    when(measurement_campaign_reporting).get_path("measurement_marketing_channel_hierarchy").thenReturn("s3://bucket/measurement/marketing/channel/hierarchy")
    when(measurement_campaign_reporting).get_path("overlapping_campaign_spend_weights").thenReturn("s3://bucket/overlapping/campaign/spend/weights")
    when(measurement_campaign_reporting).get_ci().thenReturn("test_correlation_id")
    when(measurement_campaign_reporting).get_sns("slack_topic_arn").thenReturn("test_slack_topic_arn")

    measurement_campaign_reporting.tasks(
        pipeline_run_type=POLLEN_RUN_TYPE,
        campaign_duration=CAMPAIGN_DURATION_POST,
    )

    step_args = mock_run_step.call_args.kwargs["step_args"]
    assert ("--campaign-period", CAMPAIGN_DURATION_POST) in step_args
    assert (
        "--previous-measurement-campaign-reporting",
        "s3://bucket/measurement/campaign/reporting/previous",
    ) in step_args
