from helpers.tables import Snowflake


def test_snowflake_all():
    """Test that the method calls in the all method work correctly."""
    s = Snowflake(env="dev", correlation_id="test_correlation_id")
    assert s.tables


def test_resolve_automated_booking_tables_returns_prod_tables():
    prod_schema = "UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL"

    assert Snowflake.resolve_automated_booking_tables() == {
        "tracker_table": f"{prod_schema}.MEASUREMENT_BOOKING_TRACKER",
        "pollen_table": f"{prod_schema}.MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN",
        "prod_tracker_table": f"{prod_schema}.MEASUREMENT_BOOKING_TRACKER",
        "mcr_table": f"{prod_schema}.MEASUREMENT_CAMPAIGN_REPORTING_AWS",
        "approved_ref_table": f"{prod_schema}.MEASUREMENT_REPORTING_APPROVED_BOOKING_ID_REF",
    }
