import pathlib

import pytest
from jinja2 import Environment

from helpers.xcom import get_booking_reference_date

RUN_DATE = "2026-09-03"
BOOKING_REFERENCE_DATE = "2026-08-24"

# (scenario, used_new_brand_logic xcom, booking reference date xcom, expected rendered date)
BRAND_REFERENCE_SCENARIOS = [
    ("during_run", None, BOOKING_REFERENCE_DATE, BOOKING_REFERENCE_DATE),
    ("post_run_new_brand_logic", True, BOOKING_REFERENCE_DATE, BOOKING_REFERENCE_DATE),
    ("post_run_legacy_brand_logic", False, BOOKING_REFERENCE_DATE, RUN_DATE),
    ("dtp_run_reference_date_none", None, None, RUN_DATE),
    ("dtp_run_reference_date_empty", None, "", RUN_DATE),
    ("post_run_legacy_and_no_reference_date", False, None, RUN_DATE),
]

SQL_TEMPLATE_DIR = pathlib.Path("dags/templates/sql")

# (template relative to the repo root, brand history table the template must window)
ITEM_SOURCE_SQL_TEMPLATES = [
    ("dags/templates/sql/sales_data_transaction/fact_sales_transaction_item.sql", "dim_item_hist"),
    ("dags/templates/sql/temp_unified_product/temp_unified_product.sql", "dim_item_hist"),
    ("dags/templates/sql/pollen_sources/item_brand_hist.sql", "dim_item_hist"),
    ("dags/templates/sql/validate_campaign_data/check_multi_brand_campaigns.sql", "item_brand_hist"),
]


class _FakeTaskInstance:
    """Simulates the two relevant upstream xcom values: the resolved booking reference date
    and the setup phase's used_new_brand_logic flag (None when the flag task hasn't run,
    i.e. a DURING run)."""

    def __init__(self, used_new_brand_logic=None, reference_date=BOOKING_REFERENCE_DATE):
        self._used_new_brand_logic = used_new_brand_logic
        self._reference_date = reference_date

    def xcom_pull(self, task_ids, key):
        if task_ids.endswith('setup_tasks.configure_used_new_brand_logic'):
            return self._used_new_brand_logic
        if task_ids.endswith('config_setup.configure_booking_reference_date'):
            return self._reference_date
        return None


def _environment() -> Environment:
    """Airflow exposes ds as a Jinja filter, so the test environment must register it too."""
    env = Environment()
    env.filters['ds'] = lambda value: str(value)
    return env


def _render(used_new_brand_logic=None, reference_date=BOOKING_REFERENCE_DATE, sql="{macro}"):
    """Render the macro as it appears in real SQL templates, inside quotes."""
    template = _environment().from_string(sql.format(macro=get_booking_reference_date()))
    return template.render(
        task_instance=_FakeTaskInstance(used_new_brand_logic, reference_date),
        data_interval_end=RUN_DATE,
    )


@pytest.mark.parametrize(
    "scenario,used_new_brand_logic,reference_date,expected_date",
    BRAND_REFERENCE_SCENARIOS,
)
def test_brand_reference_date_resolves_per_brand_logic_scenario(
    scenario, used_new_brand_logic, reference_date, expected_date
):
    rendered = _render(
        used_new_brand_logic=used_new_brand_logic,
        reference_date=reference_date,
        sql="WHERE valid_from_dt <= '{macro}'",
    )

    assert rendered == f"WHERE valid_from_dt <= '{expected_date}'", scenario


@pytest.mark.parametrize(
    "scenario,used_new_brand_logic,reference_date,expected_date",
    BRAND_REFERENCE_SCENARIOS,
)
def test_brand_reference_date_has_no_surrounding_whitespace(
    scenario, used_new_brand_logic, reference_date, expected_date
):
    """The value is spliced inside SQL quotes, so stray whitespace would corrupt the literal."""
    rendered = _render(used_new_brand_logic=used_new_brand_logic, reference_date=reference_date)

    assert rendered == expected_date, scenario


@pytest.mark.parametrize("relative_path,brand_source_table", ITEM_SOURCE_SQL_TEMPLATES)
@pytest.mark.parametrize(
    "scenario,used_new_brand_logic,reference_date,expected_date",
    BRAND_REFERENCE_SCENARIOS,
)
def test_item_sources_resolve_brand_history_at_the_expected_date(
    scenario, used_new_brand_logic, reference_date, expected_date, relative_path, brand_source_table
):
    """End-to-end of the two template passes: the macro resolves first, then the SQL renders
    with that value, so the final query must window the brand history table on the expected date."""
    resolved_reference_date = _render(
        used_new_brand_logic=used_new_brand_logic,
        reference_date=reference_date,
    )

    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    template = _environment().from_string((root_dir / relative_path).read_text())
    rendered_sql = template.render(
        params={
            "brand_time_reference": resolved_reference_date,
            "correlation_id": "test-correlation-id",
            "campaign_id_manual": "[]",
            "campaign_id_default": "1234",
            "start_date": "2026-01-01",
            "end_date": "2026-02-01",
            "emulate_prod_env": "false",
            "is_prod": False,
        },
        get_table=lambda name: name,
        get_stage=lambda name: f"@STAGE/{name}",
    )

    assert brand_source_table in rendered_sql, scenario
    assert f"valid_from_dt <= '{expected_date}'" in rendered_sql, scenario
    assert f"valid_until_dt >= '{expected_date}'" in rendered_sql, scenario


def test_every_brand_time_reference_template_is_covered():
    """Guards against a new (or moved) template silently escaping the coverage above."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    templates_using_reference_date = {
        str(path.relative_to(root_dir))
        for path in (root_dir / SQL_TEMPLATE_DIR).rglob("*.sql")
        if "params.brand_time_reference" in path.read_text()
    }

    assert templates_using_reference_date == {path for path, _ in ITEM_SOURCE_SQL_TEMPLATES}
