from unittest import mock

import pytest

from helpers.constants import EvaluationPhase
from helpers.snowflake import (
    resolve_used_new_brand_logic,
    check_brand_logic_consistency,
    count_legacy_brand_booking_registry_rows,
)


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_resolve_used_new_brand_logic_returns_true_for_latest_metadata(mock_hook):
    mock_hook.return_value.get_records.return_value = [
        ({"used_new_brand_logic": True},)
    ]

    assert resolve_used_new_brand_logic("latest", "booking-1", "dev") is True

    query = mock_hook.return_value.get_records.call_args.args[0]
    parameters = mock_hook.return_value.get_records.call_args.kwargs["parameters"]
    assert "booking_id = %(campaign_id)s" in query
    assert "LOWER(evaluation_period) = LOWER(%(phase)s)" in query
    assert parameters == {
        "campaign_id": "booking-1",
        "phase": EvaluationPhase.DURING.value,
    }


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_resolve_used_new_brand_logic_uses_explicit_correlation_id(mock_hook):
    mock_hook.return_value.get_records.return_value = [
        ({"used_new_brand_logic": True},)
    ]

    assert resolve_used_new_brand_logic("during-cid", "booking-1", "dev") is True

    query = mock_hook.return_value.get_records.call_args.args[0]
    parameters = mock_hook.return_value.get_records.call_args.kwargs["parameters"]
    assert "correlation_id = %(correlation_id)s" in query
    assert parameters == {
        "correlation_id": "during-cid",
        "phase": EvaluationPhase.DURING.value,
    }


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_resolve_used_new_brand_logic_defaults_to_legacy_for_missing_metadata(mock_hook):
    mock_hook.return_value.get_records.return_value = [(None,)]

    assert resolve_used_new_brand_logic("during-cid", "booking-1", "dev") is False


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_resolve_used_new_brand_logic_defaults_to_legacy_for_invalid_metadata(mock_hook):
    mock_hook.return_value.get_records.return_value = [
        ('{"used_new_brand_logic": "true"}',)
    ]

    assert resolve_used_new_brand_logic("during-cid", "booking-1", "dev") is False


# --- check_brand_logic_consistency scenario matrix ---
# Booking-level scenarios from the design: (DURING history, POST history, registry membership) -> expected behavior.

@mock.patch("helpers.snowflake.SnowflakeHook")
def test_check_brand_logic_only_legacy_during_no_post_is_allowed(mock_hook):
    """Only legacy DURING history, no completed POST yet -> booking is in the registry, POST run proceeds."""
    mock_hook.return_value.get_records.return_value = [
        ("during-cid-1", {"used_new_brand_logic": False})
    ]

    assert check_brand_logic_consistency(
        booking_id="booking-1",
        during_correlation_id="during-cid-1",
        table="measurement_metadata",
    ) is True

    assert mock_hook.return_value.get_records.call_count == 1


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_check_brand_logic_legacy_post_rerun_is_allowed(mock_hook):
    """Only legacy DURING history, a legacy POST already completed -> re-running against that same legacy
    correlation id is intentionally allowed (e.g. to recover from a failed/emulated POST run)."""
    mock_hook.return_value.get_records.return_value = [
        ("during-cid-1", {"used_new_brand_logic": False})
    ]

    assert check_brand_logic_consistency(
        booking_id="booking-1",
        during_correlation_id="during-cid-1",
        table="measurement_metadata",
    ) is True

    assert mock_hook.return_value.get_records.call_count == 1


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_check_brand_logic_new_logic_booking_rejects_legacy_correlation_id(mock_hook):
    """Booking has a completed new-logic DURING run, but POST is configured against a legacy correlation id (Part D.1)."""
    mock_hook.return_value.get_records.return_value = [
        ("during-cid-new", {"used_new_brand_logic": True}),
        ("during-cid-legacy", {"used_new_brand_logic": False}),
    ]

    assert check_brand_logic_consistency(
        booking_id="booking-1",
        during_correlation_id="during-cid-legacy",
        table="measurement_metadata",
    ) is False

    assert mock_hook.return_value.get_records.call_count == 1


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_check_brand_logic_mixed_during_history_allows_new_correlation_id(mock_hook):
    """Mixed legacy/new DURING history ('new wins'), POST configured against the new-logic correlation id -> allowed."""
    mock_hook.return_value.get_records.return_value = [
        ("during-cid-new", {"used_new_brand_logic": True}),
        ("during-cid-legacy", {"used_new_brand_logic": False}),
    ]

    assert check_brand_logic_consistency(
        booking_id="booking-1",
        during_correlation_id="during-cid-new",
        table="measurement_metadata",
    ) is True

    assert mock_hook.return_value.get_records.call_count == 1


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_check_brand_logic_no_during_history_is_a_noop(mock_hook):
    """A booking with no completed DURING pollen runs yet has nothing to validate against."""
    mock_hook.return_value.get_records.return_value = []

    assert check_brand_logic_consistency(
        booking_id="booking-1",
        during_correlation_id="during-cid-1",
        table="measurement_metadata",
    ) is True

    assert mock_hook.return_value.get_records.call_count == 1


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_check_brand_logic_rejects_unsafe_table_identifier(mock_hook):
    with pytest.raises(ValueError, match="Invalid Snowflake table identifier"):
        check_brand_logic_consistency(
            booking_id="booking-1",
            during_correlation_id="during-cid-1",
            table="measurement_metadata; DROP TABLE users",
        )

    mock_hook.return_value.get_records.assert_not_called()


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_check_brand_logic_consistency_parses_json_string_metadata(mock_hook):
    """additional_metadata can come back as a JSON string instead of a parsed dict."""
    mock_hook.return_value.get_records.return_value = [
        ("during-cid-new", '{"used_new_brand_logic": true}'),
        ("during-cid-legacy", '{"used_new_brand_logic": false}'),
    ]

    assert check_brand_logic_consistency(
        booking_id="booking-1",
        during_correlation_id="during-cid-legacy",
        table="measurement_metadata",
    ) is False


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_check_brand_logic_consistency_treats_invalid_json_string_as_legacy(mock_hook):
    mock_hook.return_value.get_records.return_value = [
        ("during-cid-1", "not-valid-json"),
    ]

    assert check_brand_logic_consistency(
        booking_id="booking-1",
        during_correlation_id="during-cid-1",
        table="measurement_metadata",
    ) is True


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_count_legacy_brand_booking_registry_rows_returns_count(mock_hook):
    mock_hook.return_value.get_records.return_value = [(5,)]

    assert count_legacy_brand_booking_registry_rows("legacy_brand_booking_registry") == 5


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_count_legacy_brand_booking_registry_rows_defaults_to_zero_for_no_rows(mock_hook):
    mock_hook.return_value.get_records.return_value = []

    assert count_legacy_brand_booking_registry_rows("legacy_brand_booking_registry") == 0


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_count_legacy_brand_booking_registry_rows_rejects_unsafe_table_identifier(mock_hook):
    with pytest.raises(ValueError, match="Invalid Snowflake table identifier"):
        count_legacy_brand_booking_registry_rows("legacy_brand_booking_registry; DROP TABLE users")

    mock_hook.return_value.get_records.assert_not_called()
