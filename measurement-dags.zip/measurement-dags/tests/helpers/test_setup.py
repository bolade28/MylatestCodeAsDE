from unittest import mock
from uuid import UUID

from freezegun import freeze_time
import pendulum
import pytest


from helpers.constants import (
    DEV,
    DEV_ACCOUNT_NUMBER,
    PROD,
    PROD_ACCOUNT_NUMBER,
)
from helpers.setup import (
    resolve_effective_end_date,
    resolve_previous_paths,
    resolve_source_end_date,
    configure_campaigns,
    configure_correlation_id,
    configure_pipelines_version,
    configure_dag_run_source,
    get_account_number,
    get_environment,
    job_flow_start_time,
)

from helpers.setup import configure_model_start_end_dates
from helpers.xcom import get_emulation_run, get_is_not_emulated_run


class TestResolveSourceEndDate:
    def test_returns_campaign_end_date_for_during_runs(self):
        with mock.patch(
            "helpers.setup.get_max_unified_campaign_end_date",
            return_value="2026-09-30",
        ) as get_campaign_end_date, mock.patch(
            "helpers.setup.get_max_unified_post_campaign_date",
        ) as get_post_campaign_date:
            result = resolve_source_end_date(
                end_date_conf_key="campaign_end_date",
                campaigns="campaign-1",
                run_type="DTP",
                snowflake_tables={
                    "measurement_unified_campaign": "dtp",
                    "measurement_unified_campaign_pollen": "pollen",
                },
            )

        assert result == "2026-09-30"
        get_campaign_end_date.assert_called_once_with(
            campaign_ids="campaign-1",
            run_type="DTP",
            pollen_table="pollen",
            dtp_table="dtp",
        )
        get_post_campaign_date.assert_not_called()

    def test_returns_post_campaign_date_for_post_period_runs(self):
        with mock.patch(
            "helpers.setup.get_max_unified_campaign_end_date",
        ) as get_campaign_end_date, mock.patch(
            "helpers.setup.get_max_unified_post_campaign_date",
            return_value="2026-09-30",
        ) as get_post_campaign_date:
            result = resolve_source_end_date(
                end_date_conf_key="post_period_end_date",
                campaigns="campaign-1",
                run_type="DTP",
                snowflake_tables={
                    "measurement_unified_campaign": "dtp",
                    "measurement_unified_campaign_pollen": "pollen",
                },
            )

        assert result == "2026-09-30"
        get_post_campaign_date.assert_called_once_with(
            campaign_ids="campaign-1",
            run_type="DTP",
            pollen_table="pollen",
            dtp_table="dtp",
        )
        get_campaign_end_date.assert_not_called()

    @pytest.mark.parametrize(
        ("campaigns", "run_type", "snowflake_tables"),
        [
            (None, "DTP", {"measurement_unified_campaign": "dtp", "measurement_unified_campaign_pollen": "pollen"}),
            ("campaign-1", None, {"measurement_unified_campaign": "dtp", "measurement_unified_campaign_pollen": "pollen"}),
            ("campaign-1", "DTP", None),
            ("campaign-1", "DTP", {"measurement_unified_campaign": "dtp"}),
        ],
    )
    def test_returns_none_when_required_inputs_are_missing(
        self, campaigns, run_type, snowflake_tables
    ):
        assert resolve_source_end_date(
            end_date_conf_key="campaign_end_date",
            campaigns=campaigns,
            run_type=run_type,
            snowflake_tables=snowflake_tables,
        ) is None


class TestResolveEffectiveEndDate:
    @mock.patch("helpers.setup.get_current_context")
    def test_configured_end_date_takes_precedence(
        self, get_current_context: mock.MagicMock
    ):
        get_current_context.return_value = {
            "dag_run": mock.MagicMock(conf={"campaign_end_date": "2026-09-10"})
        }

        with mock.patch("helpers.setup.resolve_source_end_date") as resolve_source:
            result = resolve_effective_end_date(
                run_date="2026-09-15",
                end_date_conf_key="campaign_end_date",
                campaigns="campaign-1",
                run_type="DTP",
                snowflake_tables={"measurement_unified_campaign": "dtp"},
            )

        assert result == "2026-09-10"
        resolve_source.assert_not_called()

    @mock.patch("helpers.setup.get_current_context")
    def test_single_empty_date_value_uses_source_fallback(
        self, get_current_context: mock.MagicMock
    ):
        get_current_context.return_value = {
            "dag_run": mock.MagicMock(conf={"campaign_end_date": '[""]'})
        }

        with mock.patch(
            "helpers.setup.resolve_source_end_date",
            return_value="2026-09-10",
        ) as resolve_source:
            result = resolve_effective_end_date(
                run_date="2026-09-15",
                end_date_conf_key="campaign_end_date",
                campaigns="campaign-1",
                run_type="DTP",
                snowflake_tables={"measurement_unified_campaign": "dtp"},
            )

        assert result == "2026-09-10"
        resolve_source.assert_called_once()

    @mock.patch("helpers.setup.get_current_context")
    def test_uses_source_end_date_when_it_is_before_logical_date(
        self, get_current_context: mock.MagicMock
    ):
        # Empty DAG configuration forces resolution from source data or logical date.
        get_current_context.return_value = {"dag_run": mock.MagicMock(conf={})}

        with mock.patch(
            "helpers.setup.resolve_source_end_date",
            return_value="2026-09-10",
        ) as resolve_source:
            result = resolve_effective_end_date(
                run_date="2026-09-15",
                end_date_conf_key="campaign_end_date",
                campaigns="campaign-1",
                run_type="DTP",
                snowflake_tables={"measurement_unified_campaign": "dtp"},
            )

        assert result == "2026-09-10"
        resolve_source.assert_called_once_with(
            end_date_conf_key="campaign_end_date",
            campaigns="campaign-1",
            run_type="DTP",
            snowflake_tables={"measurement_unified_campaign": "dtp"},
        )

    @mock.patch("helpers.setup.get_current_context")
    def test_falls_back_to_logical_date_when_source_date_is_missing(
        self, get_current_context: mock.MagicMock
    ):
        get_current_context.return_value = {"dag_run": mock.MagicMock(conf={})}

        with mock.patch(
            "helpers.setup.resolve_source_end_date",
            return_value=None,
        ):
            result = resolve_effective_end_date(
                run_date="2026-09-15",
                end_date_conf_key="campaign_end_date",
            )

        assert result == "2026-09-15"

    @mock.patch("helpers.setup.get_current_context")
    def test_uses_source_end_date_when_it_is_after_logical_date(
        self, get_current_context: mock.MagicMock
    ):
        get_current_context.return_value = {"dag_run": mock.MagicMock(conf={})}

        with mock.patch(
            "helpers.setup.resolve_source_end_date",
            return_value="2026-09-22",
        ):
            result = resolve_effective_end_date(
                run_date="2026-09-15",
                end_date_conf_key="campaign_end_date",
            )

        assert result == "2026-09-22"


def test_get_environment():
    with mock.patch.dict('os.environ', AIRFLOW_VAR_MEASUREMENT_ENVIRONMENT="some_env"):
        assert get_environment() == "some_env"


@pytest.mark.parametrize("env,account_number", [
    (DEV, DEV_ACCOUNT_NUMBER),
    (PROD, PROD_ACCOUNT_NUMBER),
])
def test_get_account_number(env: str, account_number: str):
    with mock.patch("helpers.setup.get_environment") as mock_get_env:
        mock_get_env.return_value = env
        assert get_account_number() == account_number


def test_configure_correlation_id():
    with mock.patch("helpers.setup.uuid", autospec=True) as uuid:
        uuid.uuid4.return_value = UUID("ad2afce0-b838-469f-a727-89c52ad8b6ac")
        correlation_id = configure_correlation_id.__wrapped__()
    assert correlation_id == "ad2afce0-b838-469f-a727-89c52ad8b6ac"


@mock.patch("helpers.setup.get_current_context")
def test_configure_pipelines_version(get_current_context: mock.MagicMock):
    dag_run = mock.MagicMock()

    dag_run.conf = {"pipelines_hash": "abcd1234"}
    get_current_context.return_value = {"dag_run": dag_run}
    assert configure_pipelines_version.__wrapped__() == "abcd1234"

    dag_run.conf = {}
    get_current_context.return_value = {"dag_run": dag_run}
    assert configure_pipelines_version.__wrapped__() == "latest"


def test_job_flow_start_time():
    t = "2020-10-20 10:20:30.54"
    with freeze_time(t):
        start_time = job_flow_start_time.__wrapped__()
        assert start_time == "2020-10-20T10:20:30"


@mock.patch("helpers.setup.get_current_context")
def test_configure_model_start_end_dates(get_current_context: mock.MagicMock):
    run_date = '2025-06-29'

    dag_run = mock.MagicMock()
    dag_run.conf = {
        "campaign_end_date": run_date,
    }
    get_current_context.return_value = {"dag_run": dag_run}

    # Valid case: No manual end date
    model_start_date = '2020-01-01'

    actual = configure_model_start_end_dates.__wrapped__(
        run_date=run_date,
        default_model_start_date=model_start_date
    )

    date_three_years_ago = pendulum.parse(run_date).date().subtract(years=3)

    expected_start_end_dates = {
        # Go back three years and pick Monday as starting date
        "start_date": date_three_years_ago.subtract(days=date_three_years_ago.day_of_week).strftime("%Y-%m-%d"),
        "end_date": '2025-06-29',
    }

    assert actual == expected_start_end_dates


@pytest.mark.parametrize(
    "configured_end_date",
    ("2026-06-23", "23-06-2026", "23-06-26"),
)
@mock.patch("helpers.setup.get_current_context")
def test_configure_model_start_end_dates_accepts_supported_date_formats(
    get_current_context: mock.MagicMock,
    configured_end_date: str,
):
    dag_run = mock.MagicMock()
    dag_run.conf = {"campaign_end_date": configured_end_date}
    get_current_context.return_value = {"dag_run": dag_run}

    actual = configure_model_start_end_dates.__wrapped__(
        run_date="2026-06-29",
        default_model_start_date="2020-01-01",
    )

    assert actual["end_date"] == "2026-06-23"


@mock.patch("helpers.setup.get_current_context")
def test_configure_model_start_end_dates_uses_post_period_end_date_when_requested(
    get_current_context: mock.MagicMock,
):
    run_date = '2025-06-29'

    dag_run = mock.MagicMock()
    dag_run.conf = {
        "campaign_end_date": "2025-06-01",
        "post_period_end_date": run_date,
    }
    get_current_context.return_value = {"dag_run": dag_run}

    actual = configure_model_start_end_dates.__wrapped__(
        run_date=run_date,
        default_model_start_date='2020-01-01',
        end_date_conf_key='post_period_end_date',
    )

    assert actual["end_date"] == run_date


@mock.patch("helpers.setup.get_current_context")
def test_configure_model_start_end_dates_invalid_campaign_end_date_raises(
    get_current_context: mock.MagicMock,
):
    dag_run = mock.MagicMock()
    dag_run.conf = {
        "campaign_end_date": "not-a-date",
    }
    get_current_context.return_value = {"dag_run": dag_run}

    with pytest.raises(ValueError, match="Invalid model_end_date provided"):
        configure_model_start_end_dates.__wrapped__(
            run_date="2025-06-29",
            default_model_start_date="2020-01-01",
        )


@mock.patch("helpers.setup.get_current_context")
def test_configure_model_start_end_dates_invalid_post_period_end_date_raises(
    get_current_context: mock.MagicMock,
):
    dag_run = mock.MagicMock()
    dag_run.conf = {
        "post_period_end_date": "not-a-date",
    }
    get_current_context.return_value = {"dag_run": dag_run}

    with pytest.raises(ValueError, match="Invalid model_end_date provided"):
        configure_model_start_end_dates.__wrapped__(
            run_date="2025-06-29",
            default_model_start_date="2020-01-01",
            end_date_conf_key='post_period_end_date',
        )


@mock.patch("helpers.setup.get_current_context")
def test_configure_model_start_end_dates_daily_etl_uses_default_start_date(
    get_current_context: mock.MagicMock,
):
    dag_run = mock.MagicMock()
    dag_run.conf = {
        "campaign_end_date": "2025-06-29",
    }
    get_current_context.return_value = {"dag_run": dag_run}

    actual = configure_model_start_end_dates.__wrapped__(
        run_date="2025-06-29",
        default_model_start_date="2023-01-01",  # When running daily ETL, we want to use the default start date rather than going back three years
        daily_etl_flag=True,
    )

    assert actual == {
        "start_date": "2023-01-01",
        "end_date": "2025-06-29",
    }


@mock.patch("helpers.setup.get_current_context")
def test_configure_dag_run_source_returns_manual_for_manual_trigger(get_current_context: mock.MagicMock):
    dag_run = mock.MagicMock()
    dag_run.run_type = "manual"
    get_current_context.return_value = {"dag_run": dag_run}

    result = configure_dag_run_source.__wrapped__()

    assert result == "MANUAL"


@mock.patch("helpers.setup.get_current_context")
@pytest.mark.parametrize("run_type", ["scheduled", "backfill", "asset_triggered"])
def test_configure_dag_run_source_returns_automated_for_non_manual_triggers(
    get_current_context: mock.MagicMock, run_type: str
):
    dag_run = mock.MagicMock()
    dag_run.run_type = run_type
    get_current_context.return_value = {"dag_run": dag_run}

    result = configure_dag_run_source.__wrapped__()

    assert result == "AUTOMATED"


class TestConfigureCampaigns:
    @staticmethod
    def _context(conf):
        return {
            "dag_run": mock.MagicMock(conf=conf),
            "data_interval_end": pendulum.datetime(2026, 10, 1),
        }

    @mock.patch("helpers.setup.get_current_context")
    def test_without_arguments_returns_manual_list(self, get_current_context: mock.MagicMock):
        get_current_context.return_value = self._context({"manual_run_campaign_list": "booking-1"})

        assert configure_campaigns.__wrapped__() == "booking-1"

    @mock.patch("helpers.setup.get_current_context")
    def test_without_arguments_and_empty_conf_returns_empty_list_string(self, get_current_context: mock.MagicMock):
        get_current_context.return_value = self._context({})

        assert configure_campaigns.__wrapped__() == "[]"

    @mock.patch("helpers.setup.get_current_context")
    def test_manual_run_ignores_eligible_booking_rows(self, get_current_context: mock.MagicMock):
        get_current_context.return_value = self._context({"manual_run_campaign_list": "booking-1"})

        result = configure_campaigns.__wrapped__(
            dag_run_source="MANUAL",
            eligible_booking_rows=[("booking-auto", "2026-09-01")],
        )

        assert result == "booking-1"

    @mock.patch("helpers.setup.get_current_context")
    def test_automated_run_returns_selected_booking(self, get_current_context: mock.MagicMock):
        get_current_context.return_value = self._context({"manual_run_campaign_list": "booking-1"})

        result = configure_campaigns.__wrapped__(
            dag_run_source="AUTOMATED",
            eligible_booking_rows=[["booking-auto", "2026-09-01"]],
        )

        assert result == "booking-auto"

    @pytest.mark.parametrize("rows", [None, []])
    @mock.patch("helpers.setup.get_current_context")
    def test_automated_run_without_eligible_booking_returns_empty_string(
        self, get_current_context: mock.MagicMock, rows
    ):
        get_current_context.return_value = self._context({"manual_run_campaign_list": "booking-1"})

        result = configure_campaigns.__wrapped__(dag_run_source="AUTOMATED", eligible_booking_rows=rows)

        assert result == ""


def test_get_emulation_run_returns_jinja_template():
    """Test that get_emulation_run returns a valid Jinja template string."""
    result = get_emulation_run()
    # Verify it contains the correct task id reference
    assert "setup_tasks.configure_emulation_run" in result
    assert 'task_instance.xcom_pull' in result
    assert 'key="return_value"' in result
    # Verify it's wrapped in Jinja syntax {{ }}
    assert result.startswith('{{')
    assert result.endswith('}}')


def test_get_is_not_emulated_run_returns_negated_jinja_template():
    """Test that get_is_not_emulated_run returns the negated emulation run template."""
    result = get_is_not_emulated_run()
    # Verify it contains the negation operator
    assert "(not " in result
    assert "| string | lower" in result
    # Verify it contains the correct task id reference
    assert "setup_tasks.configure_emulation_run" in result
    # Verify it's wrapped in Jinja syntax {{ }}
    assert result.startswith('{{')
    assert result.endswith('}}')
    # Verify it's different from the non-negated version
    assert result != get_emulation_run()


@mock.patch("helpers.setup.get_environment", return_value=DEV)
@mock.patch("helpers.setup.get_metadata_paths_by_correlation_id")
def test_resolve_previous_paths_with_explicit_correlation_id(
    get_metadata_paths: mock.MagicMock,
    _get_environment: mock.MagicMock,
):
    get_metadata_paths.return_value = {"scaler_df": "s3://bucket/scaler"}

    actual = resolve_previous_paths.__wrapped__("abc-123")

    assert actual == {"scaler_df": "s3://bucket/scaler"}
    get_metadata_paths.assert_called_once_with(
        correlation_id="abc-123",
        env=DEV,
    )


@mock.patch("helpers.setup.get_environment", return_value=DEV)
@mock.patch("helpers.setup.get_metadata_paths_by_correlation_id")
def test_resolve_previous_paths_raises_when_no_metadata_found(
    get_metadata_paths: mock.MagicMock,
    _get_environment: mock.MagicMock,
):
    get_metadata_paths.side_effect = ValueError("No metadata PATHS found")

    with pytest.raises(ValueError, match="No metadata PATHS found"):
        resolve_previous_paths.__wrapped__("abc-123")
