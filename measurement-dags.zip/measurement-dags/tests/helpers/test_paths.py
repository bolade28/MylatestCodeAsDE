from unittest import mock

import pytest

from helpers.paths import Paths


def test_paths_all():
    """Test that the method calls in the all method work correctly."""
    env_vars = {"MEASUREMENT_ENVIRONMENT": "dev"}
    with mock.patch("helpers.paths.Variable") as MockVariable:
        MockVariable.get = lambda x: env_vars[x]
        p = Paths(correlation_id="abcd", dt=None)
    assert p.paths


@pytest.mark.parametrize('experimentation,bucket', [
    (False, 'measurement-dev-etl-output'),
    (True, 'measurement-dev-experiment'),
])
def test_hypercare_validation_output_path(experimentation, bucket):
    with mock.patch('helpers.paths.Variable.get', return_value='dev'):
        paths = Paths(correlation_id='current-run', experimentation=experimentation)

    assert paths.paths['hypercare_validation_checks'] == f's3://{bucket}/current-run/hypercare_validation_checks'
