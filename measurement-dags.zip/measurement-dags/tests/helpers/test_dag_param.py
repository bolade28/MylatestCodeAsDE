from helpers.dag_param import DagParams, compute_units_param


def test_compute_units_param():
    cores = 32
    description = "The number of cores to use for EMR cluster (in multiples of 8)"
    param_type = "integer"
    title = "EMR Compute Units"
    description_md = f"""
        The number of cores to use for the EMR cluster. Since the smallest instance size we use has 8 cores,
        the number of cores requested should be a multiple of 8.

        If not specified it will default to **{cores}** cores.
        """

    actual_param = compute_units_param(cores=cores)

    assert actual_param.serialize() == {
        "value": cores,
        "description": description,
        "schema": {
            'description_md': description_md,
            'title': title,
            'type': param_type},
        "source": None,
    }


def test_campaign_end_date_param_is_optional():
    param = DagParams.campaign_end_date.serialize()

    assert param["value"] is None
    assert param["schema"]["type"] == ["null", "string"]
    assert param["schema"]["title"] == "Campaign end date"


def test_post_period_end_date_param_is_optional():
    param = DagParams.post_period_end_date.serialize()

    assert param["value"] is None
    assert param["schema"]["type"] == ["null", "string"]
    assert param["schema"]["title"] == "Post period end date"


def test_booking_approval_booking_ids_param_defaults():
    param = DagParams.booking_approval_booking_ids.serialize()
    assert param["value"] == ""
    assert "Booking IDs" == param["schema"]["title"]


def test_booking_approval_during_threshold_days_param_defaults():
    param = DagParams.booking_approval_during_threshold_days.serialize()
    assert param["value"] == 7
    assert param["schema"]["type"] == "integer"


def test_booking_approval_campaign_duration_param_defaults_to_during_and_limits_values():
    param = DagParams.booking_approval_campaign_duration.serialize()

    assert param["value"] == "During"
    assert param["schema"]["type"] == "string"
    assert param["schema"]["enum"] == ["During", "Post"]
