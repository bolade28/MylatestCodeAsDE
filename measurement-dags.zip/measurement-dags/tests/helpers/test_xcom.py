import pytest

from helpers.xcom import (
    get_eligible_booking_rows,
    get_previous_path,
    get_resolved_during_correlation_id,
    get_resolved_during_correlation_id_expression,
)


def test_resolved_during_correlation_id_expression_targets_setup_tasks():
    assert get_resolved_during_correlation_id_expression() == (
        'task_instance.xcom_pull(task_ids="config_and_validation.config_setup.resolve_during_correlation_id", '
        'key="return_value")'
    )


def test_resolved_during_correlation_id_wraps_expression_as_jinja():
    assert get_resolved_during_correlation_id() == (
        '{{task_instance.xcom_pull(task_ids="config_and_validation.config_setup.resolve_during_correlation_id", '
        'key="return_value")}}'
    )


def test_get_previous_path_reads_from_resolve_previous_paths_cache():
    template = get_previous_path("scaler_df")

    assert template.startswith("{{")
    assert template.endswith("}}")
    assert "config_and_validation.config_setup.resolve_previous_paths" in template
    assert 'key="return_value"' in template
    assert '["scaler_df"]' in template


def test_get_previous_path_raises_for_invalid_key():
    with pytest.raises(ValueError, match="Invalid path_key"):
        get_previous_path("not_a_valid_key")


def test_eligible_booking_rows_pulls_selection_query_result():
    assert get_eligible_booking_rows() == (
        "{{ task_instance.xcom_pull(task_ids='setup_tasks.query_eligible_booking') }}"
    )


def test_get_previous_path_supports_during_customer_data_collection():
    template = get_previous_path("customer_data_collection")

    assert 'key="return_value")["customer_data_collection"]' in template
