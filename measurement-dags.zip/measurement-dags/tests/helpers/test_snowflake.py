from datetime import date, datetime
from unittest import mock

import pytest

from helpers.constants import EvaluationPhase, POLLEN_RUN_TYPE
from helpers.snowflake import (
    get_max_unified_campaign_date,
    get_max_unified_campaign_end_date,
    get_max_unified_post_campaign_date,
    normalize_snowflake_date,
    check_campaign_data_exists,
    has_campaign_ended,
    resolve_during_correlation_id,
    resolve_booking_reference_date,
    check_if_we_should_run_post_campaign_period,
    get_metadata_paths_by_correlation_id,
)
from helpers.utils import normalize_ids


@pytest.fixture
def mock_hook():
    with mock.patch("helpers.snowflake.SnowflakeHook") as mock_hook_cls:
        yield mock_hook_cls.return_value


class TestHasCampaignEnded:
    def test_returns_true_when_no_future_rows(self, mock_hook):
        """No future-dated rows means the campaign has ended."""
        mock_hook.get_records.return_value = []

        result = has_campaign_ended(
            booking_id="booking_123",
            table="SOME_TABLE",
            run_date="2026-01-01",
            evaluation_phase=EvaluationPhase.DURING.value,
        )

        assert result == (True, '')

    def test_returns_false_when_future_rows_exist(self, mock_hook):
        """Future-dated rows mean the campaign is still live."""
        mock_hook.get_records.return_value = [("booking_123", "2026-12-31")]

        result = has_campaign_ended(
            booking_id="booking_123",
            table="SOME_TABLE",
            run_date="2026-01-01",
            evaluation_phase=EvaluationPhase.DURING.value,
        )

        assert result == (False, 'booking_123')

    def test_uses_campaign_end_dt_for_during_phase(self, mock_hook):
        """During-period runs must check campaign_end_dt."""
        mock_hook.get_records.return_value = []

        has_campaign_ended(
            booking_id="booking_123",
            table="SOME_TABLE",
            run_date="2026-01-01",
            evaluation_phase=EvaluationPhase.DURING.value,
        )

        query = mock_hook.get_records.call_args[0][0]
        parameters = mock_hook.get_records.call_args.kwargs["parameters"]
        assert "campaign_end_dt" in query
        assert "post_campaign_dt" not in query
        assert "job_bag_number = %(booking_id)s" in query
        assert "campaign_end_dt > %(run_date)s::DATE" in query
        assert parameters == {"booking_id": "booking_123", "run_date": "2026-01-01"}

    def test_uses_post_campaign_dt_for_post_phase(self, mock_hook):
        """Post-period runs must check post_campaign_dt."""
        mock_hook.get_records.return_value = []

        has_campaign_ended(
            booking_id="booking_123",
            table="SOME_TABLE",
            run_date="2026-01-01",
            evaluation_phase=EvaluationPhase.POST.value,
        )

        query = mock_hook.get_records.call_args[0][0]
        assert "post_campaign_dt" in query

    def test_rejects_unsafe_table_identifier(self, mock_hook):
        with pytest.raises(ValueError, match="Invalid Snowflake table identifier"):
            has_campaign_ended(
                booking_id="booking_123",
                table="SOME_TABLE; DROP TABLE users",
                run_date="2026-01-01",
                evaluation_phase=EvaluationPhase.DURING.value,
            )

        mock_hook.get_records.assert_not_called()


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_post_campaign_period_check_binds_previous_year(mock_hook):
    mock_hook.return_value.get_records.return_value = []

    assert check_if_we_should_run_post_campaign_period("2026-01-01", "SOME_TABLE") is True

    query = mock_hook.return_value.get_records.call_args.args[0]
    parameters = mock_hook.return_value.get_records.call_args.kwargs["parameters"]
    assert "YEAR_OF_TRANSACTION = %(previous_year)s" in query
    assert parameters == {"previous_year": 2025}


@mock.patch("helpers.snowflake.SnowflakeHook")
def test_resolve_during_correlation_id_binds_campaign_id_and_phase(mock_hook):
    mock_hook.return_value.get_records.return_value = [("during-cid",)]

    assert resolve_during_correlation_id("latest", "booking_123", "SOME_TABLE", POLLEN_RUN_TYPE) == "during-cid"

    query = mock_hook.return_value.get_records.call_args.args[0]
    parameters = mock_hook.return_value.get_records.call_args.kwargs["parameters"]
    assert "booking_id = %(campaign_id)s" in query
    assert "lower(campaign_duration) = lower(%(phase)s)" in query
    assert parameters == {
        "campaign_id": "booking_123",
        "phase": EvaluationPhase.DURING.value,
    }


@mock.patch("helpers.snowflake.Variable.get", return_value="dev")
@mock.patch("helpers.snowflake.SnowflakeHook")
def test_campaign_data_check_binds_runtime_values(mock_hook, mock_environment):
    mock_hook.return_value.get_records.return_value = [("experiment-cid",)]

    assert check_campaign_data_exists(
        booking_id="booking_123",
        table="SOME_TABLE",
        run_type="POLLEN",
        evaluation_phase=EvaluationPhase.DURING,
    ) == "experiment-cid"

    query = mock_hook.return_value.get_records.call_args.args[0]
    parameters = mock_hook.return_value.get_records.call_args.kwargs["parameters"]
    assert "booking_id = %(booking_id)s" in query
    assert "evaluation_period = %(evaluation_phase)s" in query
    assert "run_type = %(run_type)s" in query
    assert parameters == {
        "booking_id": "booking_123",
        "evaluation_phase": EvaluationPhase.DURING.value,
        "run_type": "POLLEN",
    }


class TestResolveBookingReferenceDate:
    def test_uses_added_on_and_booking_start_fallback(self, mock_hook):
        mock_hook.get_records.return_value = [("booking-1", "2025-03-15"), ("booking-2", "2025-03-12")]

        result = resolve_booking_reference_date(
            booking_ids=["booking-1", "booking-2"],
            booking_table="ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR",
        )

        assert result == "2025-03-15"
        query = mock_hook.get_records.call_args.args[0]
        assert "booking_id IN ('booking-1', 'booking-2')" in query
        assert "booking.booking_id" in query
        assert "flattened.value:addedOn::VARCHAR" in query
        assert "TO_TIMESTAMP(TRY_TO_NUMBER(flattened.value:addedOn::VARCHAR), 3)" in query
        assert "booking.booking_start_dt" in query
        assert "MAX(item_ref_dt) AS booking_reference_date" in query
        assert "GROUP BY booking_id" in query

    def test_falls_back_to_secondary_booking_table_for_missing_bookings(self, mock_hook):
        mock_hook.get_records.side_effect = [
            [("booking-1", "2025-03-01")],
            [("booking-2", "2025-03-15")],
        ]

        result = resolve_booking_reference_date(
            booking_ids=["booking-1", "booking-2"],
            booking_table="ADW_DEV.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR",
            fallback_booking_table="ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR",
        )

        assert result == "2025-03-15"
        assert mock_hook.get_records.call_count == 2

        primary_query = mock_hook.get_records.call_args_list[0].args[0]
        fallback_query = mock_hook.get_records.call_args_list[1].args[0]
        assert "FROM ADW_DEV.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR" in primary_query
        assert "booking_id IN ('booking-1', 'booking-2')" in primary_query
        assert "FROM ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR" in fallback_query
        assert "booking_id IN ('booking-2')" in fallback_query

    def test_raises_when_no_date_is_found(self, mock_hook):
        mock_hook.get_records.return_value = []

        with pytest.raises(ValueError, match="Unable to resolve a booking reference date"):
            resolve_booking_reference_date(
                booking_ids=["booking-1"],
                booking_table="SOME_TABLE",
            )


class TestCheckIfWeShouldRunPostCampaignPeriod:
    def test_returns_false_outside_january_without_querying(self, mock_hook):
        """Post-period generation only runs during January."""
        result = check_if_we_should_run_post_campaign_period(
            run_date="2026-02-01",
            table_name="POST_CAMPAIGN_PERIOD",
        )

        assert result is False
        mock_hook.get_records.assert_not_called()

    def test_returns_false_when_previous_year_data_exists(self, mock_hook):
        """Existing previous-year data prevents regeneration."""
        mock_hook.get_records.return_value = [(1,)]

        result = check_if_we_should_run_post_campaign_period(
            run_date="2026-01-01",
            table_name="POST_CAMPAIGN_PERIOD",
        )

        assert result is False
        query = mock_hook.get_records.call_args.args[0]
        parameters = mock_hook.get_records.call_args.kwargs["parameters"]
        assert "FROM POST_CAMPAIGN_PERIOD" in query
        assert "YEAR_OF_TRANSACTION = %(previous_year)s" in query
        assert parameters == {"previous_year": 2025}

    def test_returns_true_when_previous_year_data_is_missing(self, mock_hook):
        """Missing previous-year data triggers post-period generation."""
        mock_hook.get_records.return_value = []

        result = check_if_we_should_run_post_campaign_period(
            run_date="2026-01-01",
            table_name="POST_CAMPAIGN_PERIOD",
        )

        assert result is True
        mock_hook.get_records.assert_called_once()


class TestResolveDuringCorrelationId:
    def test_returns_configured_correlation_id_without_querying(self, mock_hook):
        """A configured correlation ID should bypass Snowflake lookup."""
        result = resolve_during_correlation_id(
            configured_during_cid="correlation_123",
            configured_campaign_id="booking_123",
            table="CAMPAIGN_EXECUTION",
            run_type=POLLEN_RUN_TYPE,
        )

        assert result == "correlation_123"
        mock_hook.get_records.assert_not_called()

    def test_resolves_latest_pollen_correlation_id_using_booking_id(self, mock_hook):
        """Pollen lookups use booking_id when resolving the latest correlation ID."""
        mock_hook.get_records.return_value = [("correlation_456",)]

        result = resolve_during_correlation_id(
            configured_during_cid="latest",
            configured_campaign_id="booking_123",
            table="CAMPAIGN_EXECUTION",
            run_type=POLLEN_RUN_TYPE,
        )

        assert result == "correlation_456"
        query = mock_hook.get_records.call_args.args[0]
        parameters = mock_hook.get_records.call_args.kwargs["parameters"]
        assert "booking_id = %(campaign_id)s" in query
        assert "lower(campaign_duration) = lower(%(phase)s)" in query
        assert parameters == {
            "campaign_id": "booking_123",
            "phase": EvaluationPhase.DURING.value,
        }

    def test_resolves_latest_non_pollen_correlation_id_using_job_bag_number(self, mock_hook):
        """Non-Pollen lookups use job_bag_number for the campaign identifier."""
        mock_hook.get_records.return_value = [("correlation_789",)]

        result = resolve_during_correlation_id(
            configured_during_cid="latest",
            configured_campaign_id="job_bag_123",
            table="CAMPAIGN_EXECUTION",
            run_type="DTP",
        )

        assert result == "correlation_789"
        query = mock_hook.get_records.call_args.args[0]
        parameters = mock_hook.get_records.call_args.kwargs["parameters"]
        assert "job_bag_number = %(campaign_id)s" in query
        assert parameters["campaign_id"] == "job_bag_123"

    def test_raises_when_latest_correlation_id_is_missing(self, mock_hook):
        """A latest lookup without a correlation ID should fail clearly."""
        mock_hook.get_records.return_value = []

        with pytest.raises(
            ValueError,
            match="unable to fetch correlation id for campaign booking_123",
        ):
            resolve_during_correlation_id(
                configured_during_cid="latest",
                configured_campaign_id="booking_123",
                table="CAMPAIGN_EXECUTION",
                run_type=POLLEN_RUN_TYPE,
            )


class TestGetMaxUnifiedCampaignDate:
    def test_normalize_campaign_id(self):
        """Tests that campaign IDs are correctly split and trimmed."""
        assert normalize_ids(" booking_1, booking_2 ") == [
            "booking_1",
            "booking_2",
        ]

    def test_normalize_snowflake_date(self):
        assert normalize_snowflake_date(datetime(2026, 9, 15, 12, 30)) == "2026-09-15"
        assert normalize_snowflake_date(date(2026, 9, 15)) == "2026-09-15"
        assert normalize_snowflake_date("2026-09-15T12:30:00") == "2026-09-15"

    def test_get_max_unified_campaign_date_returns_normalized_max_date(self, mock_hook):
        mock_hook.get_records.return_value = [(date(2026, 8, 27),)]

        result = get_max_unified_campaign_date(
            campaign_ids=" booking_1, booking_2 ",
            run_type=POLLEN_RUN_TYPE,
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
            date_column="campaign_end_dt",
        )

        assert result == "2026-08-27"
        query = mock_hook.get_records.call_args.args[0]

        assert "FROM POLLEN_TABLE" in query
        assert "job_bag_number IN ('booking_1', 'booking_2')" in query
        assert "MAX(campaign_end_dt)" in query

    def test_get_max_unified_campaign_date_returns_none_when_no_rows(self, mock_hook):
        mock_hook.get_records.return_value = []

        result = get_max_unified_campaign_date(
            campaign_ids=["booking_1"],
            run_type=POLLEN_RUN_TYPE,
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
            date_column="campaign_end_dt",
        )

        assert result is None

    def test_get_max_unified_campaign_date_returns_none_without_campaign_ids(self, mock_hook):
        """Missing campaign IDs should skip the Snowflake lookup."""
        result = get_max_unified_campaign_date(
            campaign_ids=None,
            run_type=POLLEN_RUN_TYPE,
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
            date_column="campaign_end_dt",
        )

        assert result is None
        mock_hook.get_records.assert_not_called()

    def test_get_max_unified_campaign_date_returns_none_for_null_date(self, mock_hook):
        """A Snowflake row with a NULL date should return None."""
        mock_hook.get_records.return_value = [(None,)]

        result = get_max_unified_campaign_date(
            campaign_ids=["booking_1"],
            run_type=POLLEN_RUN_TYPE,
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
            date_column="campaign_end_dt",
        )

        assert result is None

    def test_get_max_unified_campaign_date_uses_dtp_table_for_non_pollen_run(self, mock_hook):
        """Non-Pollen runs should query the DTP table."""
        mock_hook.get_records.return_value = [(date(2026, 8, 27),)]

        result = get_max_unified_campaign_date(
            campaign_ids=["job_bag_1"],
            run_type="DTP",
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
            date_column="campaign_end_dt",
        )

        assert result == "2026-08-27"
        query = mock_hook.get_records.call_args.args[0]
        assert "FROM DTP_TABLE" in query

    def test_get_max_unified_campaign_end_date_uses_campaign_end_dt(self):
        with mock.patch(
            "helpers.snowflake.get_max_unified_campaign_date",
            return_value="2026-07-12",
        ) as get_campaign_date:
            result = get_max_unified_campaign_end_date(
                campaign_ids="booking_1, booking_2",
                run_type=POLLEN_RUN_TYPE,
                pollen_table="POLLEN_TABLE",
                dtp_table="DTP_TABLE",
            )

        assert result == "2026-07-12"
        get_campaign_date.assert_called_once_with(
            campaign_ids="booking_1, booking_2",
            run_type=POLLEN_RUN_TYPE,
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
            date_column="campaign_end_dt",
        )

    def test_get_max_unified_post_campaign_date_uses_post_campaign_dt(self):
        with mock.patch(
            "helpers.snowflake.get_max_unified_campaign_date",
            return_value="2026-09-30",
        ) as get_campaign_date:
            result = get_max_unified_post_campaign_date(
                campaign_ids="booking_1, booking_2",
                run_type=POLLEN_RUN_TYPE,
                pollen_table="POLLEN_TABLE",
                dtp_table="DTP_TABLE",
            )

        assert result == "2026-09-30"
        get_campaign_date.assert_called_once_with(
            campaign_ids="booking_1, booking_2",
            run_type=POLLEN_RUN_TYPE,
            pollen_table="POLLEN_TABLE",
            dtp_table="DTP_TABLE",
            date_column="post_campaign_dt",
        )


class TestGetMetadataPathsByCorrelationId:
    def test_lookup_parses_paths_json_and_uses_expected_filters(self, mock_hook):
        mock_hook.get_records.return_value = [
            ('{"ucm_serialised_models":"s3://b","scaler_df":"s3://c"}',)
        ]

        paths = get_metadata_paths_by_correlation_id(
            correlation_id="during-correlation-id",
            env="dev",
        )

        assert paths == {
            "ucm_serialised_models": "s3://b",
            "scaler_df": "s3://c",
        }

        query = mock_hook.get_records.call_args.args[0]
        parameters = mock_hook.get_records.call_args.kwargs["parameters"]
        assert "WHERE correlation_id = %(correlation_id)s" in query
        assert "SELECT OBJECT_CONSTRUCT_KEEP_NULL" in query
        assert "'ucm_serialised_models', paths:ucm_serialised_models::STRING" in query
        assert "'scaler_df', paths:scaler_df::STRING" in query
        assert parameters == {
            "correlation_id": "during-correlation-id",
        }

    def test_explicit_lookup_returns_dict_without_json_parsing(self, mock_hook):
        mock_hook.get_records.return_value = [
            ({
                "ucm_serialised_models": "s3://b",
                "scaler_df": "s3://c",
            },)
        ]

        paths = get_metadata_paths_by_correlation_id(
            correlation_id="during-correlation-id",
            env="dev",
        )

        assert paths == {
            "ucm_serialised_models": "s3://b",
            "scaler_df": "s3://c",
        }

        query = mock_hook.get_records.call_args.args[0]
        parameters = mock_hook.get_records.call_args.kwargs["parameters"]
        assert "WHERE correlation_id = %(correlation_id)s" in query
        assert parameters == {
            "correlation_id": "during-correlation-id",
        }

    @pytest.mark.parametrize("snowflake_result", [[], [(None,)]])
    def test_raises_when_paths_are_missing(self, mock_hook, snowflake_result):
        mock_hook.get_records.return_value = snowflake_result

        with pytest.raises(ValueError, match="No metadata PATHS found"):
            get_metadata_paths_by_correlation_id(
                correlation_id="during-correlation-id",
                env="dev",
            )
