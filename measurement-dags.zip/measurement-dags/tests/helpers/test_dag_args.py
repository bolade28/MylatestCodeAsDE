from datetime import timedelta

from helpers.dag_args import DEFAULT_DAG_ARGS


def test_default_dag_args_has_expected_contract():
    # Arrange
    args = DEFAULT_DAG_ARGS

    # Assert: verify the default DAG argument contract used by all DAGs.
    assert args["owner"] == "MEASUREMENT"
    assert args["depends_on_past"] is False
    assert args["email_on_failure"] is False
    assert args["email_on_retry"] is False
    assert args["catchup"] is False
    assert args["retries"] == 4
    assert args["snowflake_conn_id"] == "snowflake_conn_private_key"
    assert args["aws_conn_id"] == "aws_default"


def test_default_dag_args_retry_delay_and_callback_types():
    # Arrange
    args = DEFAULT_DAG_ARGS

    # Assert: verify retry delay type/value and failure callback wiring.
    assert args["retry_delay"] == timedelta(minutes=5)
    assert callable(args["on_failure_callback"])
