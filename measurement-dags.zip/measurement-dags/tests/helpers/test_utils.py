import pytest

from helpers.utils import is_automated_run


@pytest.mark.parametrize(
    ("dag_run_source", "expected"),
    [("AUTOMATED", True), ("MANUAL", False), (None, False)],
)
def test_is_automated_run(dag_run_source, expected):
    assert is_automated_run(dag_run_source) is expected
