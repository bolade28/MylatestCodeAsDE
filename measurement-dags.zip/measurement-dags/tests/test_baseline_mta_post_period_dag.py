import importlib
from contextlib import ExitStack
from unittest import mock

from helpers.constants import EvaluationPhase


def make_mock_tg(group_id="tg"):
    m = mock.MagicMock()
    m.group_id = group_id
    # Preserve Airflow's `>>` behavior so chained mocks stay linked.
    m.__rshift__.side_effect = lambda downstream: downstream
    return m


def make_patches():
    return {
        "variable_get": mock.patch("airflow.sdk.Variable.get", return_value="dev"),
        "baseline_setup": mock.patch("task_groups.baseline_setup.task_group", return_value=make_mock_tg("baseline_setup")),
        "normalisations": mock.patch("task_groups.normalisations.task_group", return_value=make_mock_tg()),
        "campaign_selection": mock.patch("task_groups.campaign_selection.task_group", return_value=make_mock_tg()),
        "timeseries_data": mock.patch("task_groups.timeseries_data.task_group", return_value=make_mock_tg()),
        "analytical_pipeline": mock.patch("task_groups.analytical_pipeline.task_group", return_value=make_mock_tg()),
        "ml_tasks": mock.patch("task_groups.ml_tasks.task_group", return_value=make_mock_tg()),
        "sku_cluster_mapping": mock.patch("task_groups.sku_cluster_mapping.task_group", return_value=make_mock_tg()),
        "user_journey": mock.patch("task_groups.user_journey.task_group", return_value=make_mock_tg()),
        "attribution_pre_requisite": mock.patch("task_groups.attribution_pre_requisite.task_group", return_value=make_mock_tg()),
        "attribution_model_dataset": mock.patch("task_groups.attribution_model_dataset.task_group", return_value=make_mock_tg()),
        "sku_level_attribution": mock.patch("task_groups.sku_level_attribution.task_group", return_value=make_mock_tg()),
        "attribution_model_result": mock.patch("task_groups.attribution_model_result.task_group", return_value=make_mock_tg()),
        "customer_data_collection": mock.patch("task_groups.customer_data_collection.task_group", return_value=make_mock_tg()),
        "tables_cleanup": mock.patch("task_groups.tables_cleanup.task_group", return_value=make_mock_tg()),
        "baseline_attribution_integration_sku_level": mock.patch(
            "task_groups.baseline_attribution_integration_sku_level.task_group", return_value=make_mock_tg()
        ),
        "measurement_campaign_reporting": mock.patch(
            "task_groups.measurement_campaign_reporting.task_group", return_value=make_mock_tg()
        ),
        "metadata_start": mock.patch(
            "task_groups.metadata_and_slack_alert.task_group_start", return_value=make_mock_tg()
        ),
        "metadata_end": mock.patch(
            "task_groups.metadata_and_slack_alert.task_group_completed", return_value=make_mock_tg()
        ),
        "publish_mta_metrics": mock.patch(
            "task_groups.metric_tasks.publish_mta_metrics.task_group", return_value=make_mock_tg()
        ),
        "qa_validation_checks": mock.patch(
            "task_groups.metric_tasks.qa_validation_checks.task_group", return_value=make_mock_tg()
        ),
        "publish_baseline_metrics": mock.patch(
            "task_groups.metric_tasks.publish_baseline_metrics.task_group", return_value=make_mock_tg()
        ),
        "publish_pipeline_summary": mock.patch(
            "task_groups.metric_tasks.publish_pipeline_summary.task_group", return_value=make_mock_tg()
        ),
        "persist_baseline_attribution_integration": mock.patch(
            "task_groups.snowflake_persist_tasks.persist_baseline_attribution_integration.task_group",
            return_value=make_mock_tg(),
        ),
        "persist_ml_to_snowflake": mock.patch(
            "task_groups.snowflake_persist_tasks.persist_ml_to_snowflake.task_group", return_value=make_mock_tg()
        ),
        "persist_customer_data_collection": mock.patch(
            "task_groups.snowflake_persist_tasks.persist_customer_data_collection.task_group",
            return_value=make_mock_tg(),
        ),
        "persist_campaign_reporting_to_snowflake": mock.patch(
            "task_groups.snowflake_persist_tasks.persist_campaign_reporting_to_snowflake.task_group",
            return_value=make_mock_tg(),
        ),
        "persist_analytical_to_snowflake": mock.patch(
            "task_groups.snowflake_persist_tasks.persist_analytical_to_snowflake.task_group",
            return_value=make_mock_tg(),
        ),
        "config_validation": mock.patch(
            "task_groups.validation_tasks.config_validation.task_group", return_value=make_mock_tg()
        ),
        "validations_post": mock.patch(
            "task_groups.validation_tasks.validations.task_group_post", return_value=make_mock_tg()
        ),
        "baseline_snowflake_unload": mock.patch(
            "task_groups.snowflake_unload_tasks.baseline_snowflake_unload.task_group", return_value=make_mock_tg()
        ),
        "mta_snowflake_unload": mock.patch(
            "task_groups.snowflake_unload_tasks.mta_snowflake_unload.task_group", return_value=make_mock_tg()
        ),
        "mta_tables_setup": mock.patch(
            "task_groups.snowflake_unload_tasks.mta_tables_setup.task_group", return_value=make_mock_tg()
        ),
        "shared_snowflake_unload": mock.patch(
            "task_groups.snowflake_unload_tasks.shared_snowflake_unload.task_group", return_value=make_mock_tg()
        ),
        "unload_mta_tables": mock.patch(
            "task_groups.snowflake_unload_tasks.unload_mta_tables.task_group", return_value=make_mock_tg()
        ),
        "unload_reach_engagement": mock.patch(
            "task_groups.snowflake_unload_tasks.unload_reach_engagement.task_group", return_value=make_mock_tg()
        ),
        "branch_operator": mock.patch("airflow.providers.standard.operators.python.BranchPythonOperator"),
        "empty_operator": mock.patch("airflow.providers.standard.operators.empty.EmptyOperator"),
        "launch_cluster": mock.patch("helpers.emr.launch_cluster", return_value=mock.MagicMock()),
        "terminate_cluster": mock.patch("helpers.emr.terminate_cluster", return_value=mock.MagicMock()),
        "get_cluster_id": mock.patch("helpers.xcom.get_cluster_id", return_value=mock.MagicMock()),
    }


def enter_all_patches(stack):
    return {
        name: stack.enter_context(patcher)
        for name, patcher in make_patches().items()
    }


def reload_dag():
    mod = importlib.import_module("baseline_mta_post_period_dag")
    importlib.reload(mod)
    return mod


def test_baseline_mta_post_period_dag_import_and_instantiation():
    """Verifies baseline_mta_post_period_dag can be imported and instantiated with expected metadata."""
    with ExitStack() as stack:
        enter_all_patches(stack)
        mod = reload_dag()
        dag = mod.baseline_mta_post_period_dag()

    assert hasattr(mod, "baseline_mta_post_period_dag")
    assert callable(mod.baseline_mta_post_period_dag)
    assert dag.dag_id == "baseline_mta_post_period_dag"
    assert dag.schedule is None


def test_baseline_mta_post_period_dag_has_expected_params():
    """Verifies baseline_mta_post_period_dag is configured with required params."""
    with ExitStack() as stack:
        enter_all_patches(stack)
        mod = reload_dag()
        dag = mod.baseline_mta_post_period_dag()

    expected_params = {
        "pipelines_hash", "manual_run_campaign_list", "pipeline_run_type",
        "post_period_end_date", "ci_of_during_run", "persist_dataset",
    }
    assert expected_params.issubset(set(dag.params.keys()))


def test_baseline_mta_post_period_dag_invokes_baseline_setup():
    """Verifies the POST DAG uses automated campaign selection."""
    with ExitStack() as stack:
        mocks = enter_all_patches(stack)
        mod = reload_dag()
        mod.baseline_mta_post_period_dag()

    mocks["baseline_setup"].assert_called_with(type=EvaluationPhase.POST)


def test_baseline_mta_post_period_dag_invokes_launch_and_terminate_cluster():
    """Verifies that cluster is launched and terminated during DAG instantiation."""
    with ExitStack() as stack:
        mocks = enter_all_patches(stack)
        mod = reload_dag()
        mod.baseline_mta_post_period_dag()

    mocks["launch_cluster"].assert_called()
    mocks["terminate_cluster"].assert_called()


def test_baseline_mta_post_period_dag_places_qa_between_metrics_and_summary():
    from helpers.constants import CAMPAIGN_DURATION_POST

    with ExitStack() as stack:
        mocks = enter_all_patches(stack)
        mod = reload_dag()
        mod.baseline_mta_post_period_dag()

    qa = mocks['qa_validation_checks']
    qa.assert_called_with(campaign_duration=CAMPAIGN_DURATION_POST)
    qa.return_value.set_upstream.assert_called_with(mocks['publish_mta_metrics'].return_value)
    mocks['publish_pipeline_summary'].return_value.set_upstream.assert_called_with(qa.return_value)
    mocks['metadata_end'].return_value.set_upstream.assert_any_call(mocks['publish_pipeline_summary'].return_value)
    mocks['metadata_end'].return_value.set_upstream.assert_any_call(
        mocks['persist_campaign_reporting_to_snowflake'].return_value
    )
