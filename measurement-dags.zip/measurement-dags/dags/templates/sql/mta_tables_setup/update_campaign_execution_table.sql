{% set run_type = task_instance.xcom_pull(
    task_ids="setup_tasks.configure_run_type",
    key="return_value"
) %}


MERGE INTO {{ get_table('measurement_campaign_execution_aws') }} AS target
USING (
    SELECT
        campaign_id,
        booking_id,
        job_bag_number,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_start_dt,
        campaign_end_dt,
        campaign_duration,
        job_status,
        load_ts,
        job_run_id,
        overlapping_campaign_flag,
        marketing_hierarchy_cd
    FROM {{ get_table('measurement_campaign_execution_status') }}
    ) AS src
ON
  target.campaign_id = src.campaign_id
  AND target.booking_id = src.booking_id
  AND target.campaign_duration = src.campaign_duration
  {% if run_type == params.dtp_type %}
  AND target.job_bag_number = src.job_bag_number
  {% endif %}
WHEN MATCHED THEN UPDATE SET
  target.channel_name = src.channel_name,
  target.subchannel_name = src.subchannel_name,
  {% if run_type == params.pollen_type %}
  target.job_bag_number = src.job_bag_number,
  {% endif %}
  target.campaign_start_dt = src.campaign_start_dt,
  target.campaign_end_dt = src.campaign_end_dt,
  target.overlapping_campaign_flag = src.overlapping_campaign_flag,
  target.campaign_name = src.campaign_name,
  target.marketing_type = src.marketing_type,
  target.job_status = src.job_status,
  target.load_ts = src.load_ts,
  target.job_run_id = src.job_run_id,
  target.marketing_hierarchy_cd = src.marketing_hierarchy_cd
WHEN NOT MATCHED THEN INSERT (
  campaign_id,
  booking_id,
  job_bag_number,
  marketing_type,
  channel_name,
  subchannel_name,
  campaign_name,
  campaign_start_dt,
  campaign_end_dt,
  campaign_duration,
  job_status,
  load_ts,
  job_run_id,
  overlapping_campaign_flag,
  marketing_hierarchy_cd
) VALUES (
  src.campaign_id,
  src.booking_id,
  src.job_bag_number,
  src.marketing_type,
  src.channel_name,
  src.subchannel_name,
  src.campaign_name,
  src.campaign_start_dt,
  src.campaign_end_dt,
  src.campaign_duration,
  src.job_status,
  src.load_ts,
  src.job_run_id,
  src.overlapping_campaign_flag,
  src.marketing_hierarchy_cd
);
