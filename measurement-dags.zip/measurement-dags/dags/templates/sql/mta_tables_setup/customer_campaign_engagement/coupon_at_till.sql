CREATE TEMP TABLE {{ get_table('coupon_at_till_campaign_date_range_temp') }}
AS
(
    SELECT DISTINCT
        min(campaign_start_dt) as min_campaign_start_dt,
        max(campaign_end_dt) as max_campaign_end_dt
    FROM {{ get_table('measurement_campaign_execution_status') }} AS mce
    WHERE channel_name = 'Coupon At Till'
    AND(mce.job_status = 'Not Started' OR mce.job_status IS NULL)
    );

CREATE TEMP TABLE {{ get_table('fact_coupon_at_till_performant') }}
CLUSTER BY(coupon_print_dt)
AS
(
    SELECT
        hash_loyalty_id,
        coupon_print_dt,
        coupon_print_tm,
        barcode
    FROM {{ get_table('fact_coupon_at_till') }}
    CROSS JOIN {{ get_table('coupon_at_till_campaign_date_range_temp') }} AS catdr
    WHERE coupon_print_dt BETWEEN catdr.min_campaign_start_dt AND catdr.max_campaign_end_dt
);

CREATE TEMP TABLE {{ get_table('cat_fact_sale_transaction_basket_performant_temp') }}
CLUSTER BY(transaction_dt)
AS
(
    SELECT
       transaction_end_ts,
       nectar_card_num_hash,
       transaction_id,
       transaction_dt,
       sales_origination_channel_cd,
       transaction_key
    FROM {{ get_table('fact_sale_transaction_basket') }}
    CROSS JOIN {{ get_table('coupon_at_till_campaign_date_range_temp') }} AS catdr
    WHERE transaction_dt BETWEEN catdr.min_campaign_start_dt AND catdr.max_campaign_end_dt
);

CREATE TEMP TABLE {{ get_table('cat_fact_sale_transaction_item_performant_temp') }}
CLUSTER BY(transaction_dt)
AS
(
    SELECT
        transaction_id,
        transaction_dt,
        item_cd,
        net_retail_sales_amt,
        item_qty,
        item_sequence_num,
        store_cd
    FROM {{ get_table('fact_sale_transaction_item') }}
    CROSS JOIN {{ get_table('coupon_at_till_campaign_date_range_temp') }} AS catdr
    WHERE transaction_dt BETWEEN catdr.min_campaign_start_dt AND catdr.max_campaign_end_dt
);
REMOVE {{ get_stage('coupon_at_till_data') }}/;
COPY INTO {{ get_stage('coupon_at_till_data') }}
FROM
(
with get_measure_campgn_exec as (
    select
        campaign_id,
        booking_id,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_start_dt,
        campaign_end_dt,
        job_status
    from {{ get_table('measurement_campaign_execution_status') }} as mce
    where channel_name = 'Coupon At Till' 
    AND (mce.job_status = 'Not Started' OR mce.job_status IS NULL)
),
current_campaign_details as (
    select
        campaign_id,
        booking_id,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_start_dt as start_date,
        campaign_end_dt as end_date
    from get_measure_campgn_exec
),
get_coupon_details as (
    select
        substr(trim(cp.coupon_id), 8, 7) as coupon_id,
        substr(cp.coupon_id, 0, 14) as coupon_id_2
    from {{ get_table('cell') }} as c
    inner join {{ get_table('coupon_cell') }} as cc on c.cell_key = cc.cell_key
    inner join {{ get_table('coupon') }} as cp on cc.coupon_key = cp.coupon_key
    inner join current_campaign_details as ccd on c.campaign_id = ccd.campaign_id
    where
        c.campaign_id = ccd.campaign_id
    union
    select
        offerbarcode,
        substr(offerbarcode, 0, 14) as offerbarcode_2
    from {{ get_table('cat_plan_data') }}
    inner join current_campaign_details as ccd on cat_plan_data.campaigncode = ccd.campaign_id
    where campaigncode = ccd.campaign_id
),
get_targetted_customers_raw as (
    select distinct
        fcat.hash_loyalty_id as customer_key,
        timestamp_from_parts(fcat.coupon_print_dt, fcat.coupon_print_tm) as event_ts
    from {{ get_table('fact_coupon_at_till_performant') }} as fcat
    cross join current_campaign_details as ccd
    where
        fcat.barcode in (select distinct coupon_id_2 from get_coupon_details)
        and fcat.coupon_print_dt between ccd.start_date and ccd.end_date
),
get_targetted_customers as (
    select customer_key,
        min(event_ts) as event_ts
    from get_targetted_customers_raw
    group by 1
),
unified_data AS (
        SELECT DISTINCT
            uc.campaign_id AS uc_campaign_id,
            min(uc.campaign_start_dt) AS uc_campaign_start_dt,
            max(uc.campaign_end_dt) AS uc_campaign_end_dt
        FROM {{ get_table('measurement_unified_campaign_pollen') }} uc
        INNER JOIN current_campaign_details cd
            ON uc.job_bag_number = cd.booking_id
            AND uc.channel_name = cd.channel_name
            AND uc.subchannel_name = cd.subchannel_name
            AND uc.marketing_type = cd.marketing_type
            AND uc.campaign_start_dt = cd.start_date
            group by uc.campaign_id

    -- Get loyalty IDs from previous 'During' period (for POST campaigns only)
),
get_fact_sale_transaction_basket as (
    select
        transaction_end_ts,
        nectar_card_num_hash,
        transaction_id,
        transaction_dt,
        sales_origination_channel_cd,
        transaction_key
    from {{ get_table('cat_fact_sale_transaction_basket_performant_temp') }}
    cross join current_campaign_details as ccd
    where
        nectar_card_num_hash is not null
        and transaction_dt between ccd.start_date and ccd.end_date
        and sales_origination_channel_cd in (
            select all_codes.value
            from table(flatten(input => {{ params.sales_origination_all_codes }}::array)) as all_codes
        )
),
get_fact_sale_transaction_item as (
    select
        transaction_id,
        transaction_dt,
        item_cd,
        net_retail_sales_amt,
        item_qty,
        item_sequence_num,
        store_cd
    from {{ get_table('cat_fact_sale_transaction_item_performant_temp') }}
    cross join current_campaign_details as ccd
    where
        transaction_dt between ccd.start_date and ccd.end_date
),
max_load_ts as (
    select
        max(load_ts) as load_ts
    from {{ get_table('campaign_product_type_aws') }} as cpt
    inner join current_campaign_details as ccd on cpt.campaign_id = ccd.campaign_id
    where
        cpt.campaign_id = ccd.campaign_id
        and cpt.channel_name = ccd.channel_name
        and cpt.subchannel_name = ccd.subchannel_name
),
get_targeted_skus as (
    select distinct
        product_type,
        unique_brand_name,
        item_cd
    from {{ get_table('campaign_product_type_aws') }} as cpta
    inner join current_campaign_details as ccd on cpta.campaign_id = ccd.campaign_id
    where
        cpta.campaign_id = ccd.campaign_id
        and cpta.channel_name = ccd.channel_name
        and cpta.subchannel_name = ccd.subchannel_name
        and load_ts = (select load_ts from max_load_ts)
),
get_redeem_transaction_data_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id,
        gfstb.transaction_dt as event_dt,
        gfstb.transaction_end_ts as event_ts,
        gfstb.transaction_id as transaction_key,
        gfsti.item_cd,
        gts.unique_brand_name,
        '' as marketing_type,
        ccd.channel_name as channel_name,
        'instore' as purchase_type,
        ccd.campaign_name as campaign_name ,
        ccd.campaign_id as campaign_id,
        '{{ params.transaction_event_name }}' as event_name,
        ccd.booking_id as booking_id ,
        gts.product_type,
        gfsti.net_retail_sales_amt,
        gfsti.item_qty,
        gfsti.item_sequence_num
    from {{ get_table('dim_customer_loyalty') }} as dcl
    inner join get_fact_sale_transaction_basket as gfstb
        on dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
    inner join get_fact_sale_transaction_item as gfsti
        on gfstb.transaction_id = gfsti.transaction_id
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
    inner join {{ get_table('points_coupon_redemption') }} as pcr
        on gfstb.transaction_key = pcr.transaction_key
    inner join get_targetted_customers as gtc
        on dcl.nectar_collector_card_num = gtc.customer_key
    cross join current_campaign_details as ccd
    where
        pcr.coupon_id in (select distinct coupon_id from get_coupon_details)
        and dcl.nectar_collector_card_num != '~~'
        and gfsti.net_retail_sales_amt > 0
        and pcr.date_key between ccd.start_date and ccd.end_date
        and gfstb.transaction_dt between ccd.start_date and ccd.end_date
        and gfsti.transaction_dt between ccd.start_date and ccd.end_date
),
get_redeem_transaction_data as (
    select
        loyalty_id,
        event_dt,
        event_ts,
        transaction_key,
        item_cd,
        unique_brand_name,
        marketing_type,
        channel_name,
        campaign_name,
        campaign_id,
        event_name,
        purchase_type,
        booking_id,
        product_type,
        sum(net_retail_sales_amt) as net_sales_amt,
        sum(item_qty) as units_qty
    from get_redeem_transaction_data_distinct
    group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14
),
get_all_transaction_data_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id,
        gfstb.transaction_dt as event_dt,
        gfstb.transaction_end_ts as event_ts,
        gfstb.transaction_id as transaction_key,
        gfsti.item_cd,
        gts.unique_brand_name,
        '' as marketing_type,
        '' AS channel_name,
        CASE WHEN gfstb.sales_origination_channel_cd IN (
            SELECT instore_codes.value
            FROM TABLE(flatten(input => {{ params.sales_origination_instore_codes }}::ARRAY)) AS instore_codes
        ) THEN 'instore' ELSE 'online' END AS purchase_type,
        ccd.campaign_name as campaign_name,
        ccd.campaign_id as campaign_id,
        '{{ params.transaction_event_name }}' as event_name,
        ccd.booking_id as booking_id,
        gts.product_type,
        gfsti.net_retail_sales_amt,
        gfsti.item_qty,
        gfsti.item_sequence_num
    from  {{ get_table('dim_customer_loyalty') }} as dcl
    inner join get_targetted_customers as gtc
        on dcl.customer_loyalty_cd = gtc.customer_key
    inner join get_fact_sale_transaction_basket as gfstb
        on
            dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
            and gtc.event_ts <= gfstb.transaction_end_ts
    inner join get_fact_sale_transaction_item as gfsti
        on gfstb.transaction_id = gfsti.transaction_id
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
    cross join current_campaign_details as ccd
    where
        gfstb.transaction_dt between ccd.start_date and ccd.end_date
        and gfsti.net_retail_sales_amt > 0
        and gfsti.transaction_dt between ccd.start_date and ccd.end_date
        and dcl.nectar_collector_card_num != '~~'
        and gfstb.transaction_id not in (select distinct transaction_key from get_redeem_transaction_data)
        and gfstb.sales_origination_channel_cd in (
            select all_codes.value
            from table(flatten(input => {{ params.sales_origination_all_codes }}::array)) as all_codes
        )
),
get_all_transaction_data as (
    select
        loyalty_id,
        event_dt,
        event_ts,
        transaction_key,
        item_cd,
        unique_brand_name,
        marketing_type,
        channel_name,
        campaign_name,
        campaign_id,
        event_name,
        purchase_type,
        booking_id,
        product_type,
        sum(net_retail_sales_amt) as net_sales_amt,
        sum(item_qty) as units_qty
    from get_all_transaction_data_distinct
    group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14
),
create_get_coupon_touchpoint_data as (
    select distinct
        all_txn.loyalty_id,
        ccd.marketing_type as marketing_type,
        ccd.channel_name as channel_name,
        ccd.campaign_name as campaign_name,
        ccd.campaign_id as campaign_id,
        ccd.subchannel_name as subchannel_name,
        all_txn.transaction_key,
        '{{ params.touchpoint_event_name }}' as event_name,
        all_txn.booking_id,
        case when gtc.event_ts > all_txn.event_ts then timeadd(millisecond, -100, all_txn.event_ts) else gtc.event_ts end as event_ts,
        case when date(gtc.event_ts) < date(all_txn.event_ts) then date(gtc.event_ts) else date(all_txn.event_ts) end as event_dt
    from (
            select
                loyalty_id,
                event_dt,
                event_ts,
                transaction_key,
                item_cd,
                unique_brand_name,
                marketing_type,
                channel_name,
                campaign_name,
                campaign_id,
                event_name,
                '' AS purchase_type,
                booking_id,
                product_type,
                net_sales_amt,
                units_qty
            from get_all_transaction_data
            union
            select
                loyalty_id,
                event_dt,
                event_ts,
                transaction_key,
                item_cd,
                unique_brand_name,
                marketing_type,
                channel_name,
                campaign_name,
                campaign_id,
                event_name,
                '' AS purchase_type,
                booking_id,
                product_type,
                net_sales_amt,
                units_qty
            from get_redeem_transaction_data
        ) as all_txn
    inner join get_targetted_customers as gtc on all_txn.loyalty_id = gtc.customer_key
    inner join current_campaign_details as ccd on all_txn.campaign_id = ccd.campaign_id
    inner join unified_data ud 
    on ccd.campaign_id = ud.uc_campaign_id 
    and DATE(all_txn.event_ts) <= ud.uc_campaign_end_dt
),
get_non_converted_touchpoint_data as (
    select
        gtc.customer_key as loyalty_id,
        ccd.marketing_type as marketing_type,
        ccd.channel_name as channel_name,
        ccd.campaign_name as campaign_name,
        ccd.campaign_id as campaign_id,
        ccd.subchannel_name as subchannel_name,
        NULL AS transaction_key,
        '{{ params.touchpoint_event_name }}' as event_name,
        ccd.booking_id as booking_id,
        min(date(gtc.event_ts)) as event_dt,
        min(gtc.event_ts) as event_ts
    from get_targetted_customers as gtc
    cross join current_campaign_details as ccd
    where
        gtc.customer_key not in (select distinct loyalty_id from create_get_coupon_touchpoint_data)
    group by 1,2,3,4,5,6,7,8,9
),
coupon_at_till_collection as (
    select
        loyalty_id,
        transaction_key,
        event_dt,
        event_ts,
        '' as marketing_type,
        '' as channel_name,
        '' as subchannel_name,
        '' as campaign_name,
        '' as campaign_id,
        event_name,
        purchase_type,
        booking_id,
        item_cd,
        product_type,
        unique_brand_name,
        net_sales_amt,
        units_qty
    from get_redeem_transaction_data
    union all
    select
        loyalty_id,
        transaction_key,
        event_dt,
        event_ts,
        '' as marketing_type,
        '' as channel_name,
        '' as subchannel_name,
        '' as campaign_name,
        '' as campaign_id,
        event_name,
        purchase_type,
        booking_id,
        item_cd,
        product_type,
        unique_brand_name,
        net_sales_amt,
        units_qty
    from get_all_transaction_data
    union all
    select
        loyalty_id,
        transaction_key,
        event_dt,
        event_ts,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        '' AS purchase_type,
        booking_id,
        NULL AS item_cd,
        NULL AS product_type,
        NULL AS unique_brand_name,
        NULL AS net_sales_amt,
        NULL AS units_qty
    from create_get_coupon_touchpoint_data
    union all
    select
        loyalty_id,
        null,
        event_dt,
        event_ts,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        '' AS purchase_type,
        booking_id,
        NULL AS item_cd,
        NULL AS product_type,
        NULL AS unique_brand_name,
        NULL AS net_sales_amt,
        NULL AS units_qty
    from get_non_converted_touchpoint_data
)
    select
       loyalty_id::VARCHAR(1000) AS loyalty_id,
        COALESCE(transaction_key::VARCHAR(1000), 'NA') AS transaction_key,
        event_dt::DATE AS event_dt,
        event_ts::TIMESTAMP_NTZ(9) AS event_ts,
        marketing_type::VARCHAR(1000) AS marketing_type,
        channel_name::VARCHAR(1000) AS channel_name,
        subchannel_name::VARCHAR(1000) AS subchannel_name,
        campaign_name::VARCHAR(1000) AS campaign_name,
        campaign_id::VARCHAR(1000) AS campaign_id,
        event_name::VARCHAR(1000) AS event_name,
        purchase_type::VARCHAR(1000) AS purchase_type,
        booking_id::VARCHAR(1000) AS booking_id,
        CURRENT_TIMESTAMP::TIMESTAMP_NTZ(9) AS load_ts,
        COALESCE(item_cd::NUMBER(18, 0), 0) AS item_cd,
        COALESCE(product_type::VARCHAR(1000), 'NA') AS product_type,
        COALESCE(unique_brand_name::VARCHAR(1000), 'NA') AS unique_brand_name,
        COALESCE(net_sales_amt::NUMBER(30, 4), 0) AS net_sales_amt,
        COALESCE(units_qty::NUMBER(30, 4), 0) AS units_qty,
        CAST('{{params.correlation_id}}' AS VARCHAR(36)) AS job_run_id
    from coupon_at_till_collection
)
include_query_id = true
header = true;
