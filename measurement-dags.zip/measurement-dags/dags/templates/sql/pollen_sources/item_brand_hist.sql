REMOVE {{ get_stage('item_brand_hist') }}/;
COPY INTO {{ get_stage('item_brand_hist') }}
FROM (
    -- This will return multiple records for each item if the item has multiple brands over time.
    WITH item_brand_hist_all AS (
        SELECT
            item_cd,
            valid_from_dt,
            valid_until_dt,
            load_ts,
            unique_brand_name
        FROM {{ get_table('item_brand_hist') }}
        WHERE COALESCE(technical_metadata:record_deleted_flag::VARCHAR, 'N') = 'N'
            AND NULLIF(TRIM(unique_brand_name), '') IS NOT NULL
    ),

    -- Extract the latest item details for each item using the brand reference date.
    item_details AS (
        SELECT
            item_cd,
            sub_cat_name,
            super_cat_name
        FROM {{ get_table('dim_item_hist') }}
        WHERE valid_from_dt <= '{{ params.brand_time_reference }}'
            AND valid_until_dt >= '{{ params.brand_time_reference }}'
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY item_cd
            ORDER BY load_ts DESC
        ) = 1
    ),

    -- Get all the brands for items that are in scope, based on the reference date.
    item_brand_details_in_scope AS (
        SELECT
            bh.item_cd,
            bh.unique_brand_name,
            i.sub_cat_name,
            i.super_cat_name
        FROM item_brand_hist_all AS bh
        LEFT JOIN item_details AS i
            ON bh.item_cd = i.item_cd
        WHERE bh.valid_from_dt <= '{{ params.brand_time_reference }}'
            AND bh.valid_until_dt >= '{{ params.brand_time_reference }}'
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY bh.item_cd
            ORDER BY bh.load_ts DESC, bh.valid_from_dt DESC, bh.valid_until_dt DESC
        ) = 1
    ),


    -- Get all the brands for items that were not picked up by the in-scope query.
    -- We don't use a timestamp as these were not picked up due to out of scope sub-categories, discontinued items, or items that haven't had their brand confirmed yet. So they are not updated in the item_brand_hist fully.
    -- It is safe to include these as out-of-scope items because they will not be used in any current campaigns, or they don't have any relating sales. We still want to resolve their brand details for legacy campaigns and historical sales.
    item_brand_details_out_of_scope AS (
        SELECT
            bh.item_cd,
            bh.unique_brand_name,
            i.sub_cat_name,
            i.super_cat_name
        FROM item_brand_hist_all AS bh
        LEFT JOIN item_details AS i
            ON bh.item_cd = i.item_cd
        WHERE NOT EXISTS (
            SELECT 1
            FROM item_brand_details_in_scope AS in_scope
            WHERE in_scope.item_cd = bh.item_cd
        )
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY bh.item_cd
            ORDER BY bh.load_ts DESC, bh.valid_from_dt DESC, bh.valid_until_dt DESC
        ) = 1
    ),

    item_brand_details AS (
        SELECT
            item_cd,
            unique_brand_name,
            sub_cat_name,
            super_cat_name
        FROM item_brand_details_in_scope

        UNION ALL

        SELECT
            item_cd,
            unique_brand_name,
            sub_cat_name,
            super_cat_name
        FROM item_brand_details_out_of_scope
    )

    SELECT
        item_cd,
        unique_brand_name,
        sub_cat_name,
        super_cat_name
    FROM item_brand_details
)
INCLUDE_QUERY_ID = TRUE
HEADER = TRUE;
