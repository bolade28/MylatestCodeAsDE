REMOVE {{ get_stage('campaign_booking_media_channel') }}/;
COPY INTO {{ get_stage('campaign_booking_media_channel') }}
FROM (
    WITH blacklisted_bookings AS (
        SELECT DISTINCT
            booking_id, campaign_id
        FROM {{ get_table('bookings_blacklist') }}
    ),

    base_bookings AS (
        SELECT
            t.booking_id,
            t.campaign_id,
            t.channel_type,
            t.booking_status,
            t.cumulative_billable_spend_amt,
            t.booking_media_budget_amt,
            t.media_provider,
            t.media_business_group,
            t.booking_media_live_start_dt,
            t.booking_media_live_end_dt,
            t.booking_item_cd_list,
            t.marketing_hierarchy_cd,
            t.store_cd_list,
            t.unique_brand_list
        FROM {{ get_table('campaign_booking_media_channel') }} AS t
        WHERE t.booking_item_cd_list IS NOT NULL
        AND NOT EXISTS (
            SELECT 1
            FROM blacklisted_bookings AS b
            WHERE b.booking_id = t.booking_id
        )
        AND NOT EXISTS (
            SELECT 1
            FROM blacklisted_bookings AS b
            WHERE b.campaign_id = t.campaign_id
        )
        {% if params.emulate_prod_env | default(false) or params.is_prod | default(false) %}
        AND t.TEST_BOOKING_FLAG != 'Y'
        {% endif %}
    ),

    -- Get the first brand_id from the unique_brand_list for each booking. This is used to populate the new brand_id column in measurement_campaign_reporting_aws.
    flattened_brands_ids AS (
        SELECT DISTINCT 
            booking_id,
            obj_fields.VALUE::STRING AS brand_id
        FROM base_bookings AS bb,
        LATERAL FLATTEN(input => bb.UNIQUE_BRAND_LIST) arr_elements,
        LATERAL FLATTEN(input => arr_elements.VALUE) obj_fields
        WHERE obj_fields.KEY = '_id'
        AND obj_fields.VALUE::STRING IS NOT NULL
        AND obj_fields.VALUE::STRING != ''
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY booking_id 
            ORDER BY obj_fields.VALUE::STRING
        ) = 1
    ),

    -- Checks if any skus are null in the booking_item_cd_list. If there are, we want to exclude the entire booking
    flattened_booking_skus_check AS (
        SELECT
            booking_id,
            COUNT_IF(json_extract_path_text(f.value, 'skuId') IS NULL) AS null_sku_id_count
        FROM base_bookings,
             LATERAL FLATTEN(INPUT => booking_item_cd_list) AS f
        GROUP BY booking_id
    )

    SELECT
        t.booking_id,
        t.campaign_id,
        t.channel_type,
        t.booking_status,
        CASE
            WHEN t.booking_status = 'COMPLETED'
                AND t.cumulative_billable_spend_amt IS NOT NULL
                AND t.cumulative_billable_spend_amt != 0
            THEN t.cumulative_billable_spend_amt
            ELSE t.booking_media_budget_amt
        END AS media_spend_amt,
        t.media_provider,
        t.media_business_group,
        t.booking_media_live_start_dt,
        t.booking_media_live_end_dt,
        t.booking_item_cd_list AS item_cd_list,
        t.marketing_hierarchy_cd,
        t.store_cd_list,
        fbi.brand_id
    FROM base_bookings t
    INNER JOIN flattened_booking_skus_check fc ON t.booking_id = fc.booking_id
    LEFT JOIN flattened_brands_ids fbi
        ON t.booking_id = fbi.booking_id
    WHERE fc.null_sku_id_count = 0
)
include_query_id = true
header = true;