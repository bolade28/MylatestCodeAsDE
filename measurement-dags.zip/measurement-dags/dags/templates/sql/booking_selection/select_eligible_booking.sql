-- Selects at most one booking for an AUTOMATED baseline MTA run.
-- Tie-breaker: latest relevant end date first, then booking_id ascending, so selection is deterministic.

WITH campaign_dates AS (
    SELECT
        job_bag_number AS booking_id, -- job_bag_number holds the BDV booking_id for Pollen campaigns
        MAX({{ params.date_column }}) AS relevant_end_dt
    FROM {{ params.pollen_table }}
    WHERE load_ts = (SELECT MAX(load_ts) FROM {{ params.pollen_table }})
    GROUP BY job_bag_number
)

SELECT
    t.booking_id,
    cd.relevant_end_dt
FROM {{ params.tracker_table }} t
INNER JOIN campaign_dates cd
    ON cd.booking_id = t.booking_id
WHERE UPPER(t.pipeline_stage) = UPPER('{{ params.pipeline_stage }}')
  AND UPPER(t.status) = UPPER('{{ params.pending_status }}')
  AND cd.relevant_end_dt IS NOT NULL
  AND DATEADD(day, {{ params.offset_days }}, cd.relevant_end_dt) <= '{{ data_interval_end | ds }}'::DATE
{% if params.is_post %}
  AND EXISTS (
      SELECT 1
      FROM {{ params.prod_tracker_table }} d
      WHERE d.booking_id = t.booking_id
        AND UPPER(d.pipeline_stage) = UPPER('{{ params.during_stage }}')
        AND UPPER(d.status) = UPPER('{{ params.completed_status }}')
  )
  AND EXISTS (
      SELECT 1
      FROM {{ params.mcr_table }} m
      WHERE m.booking_id = t.booking_id
        AND LOWER(m.campaign_duration) = LOWER('{{ params.during_stage }}')
  )
  AND EXISTS (
      SELECT 1
      FROM {{ params.approved_ref_table }} r
      WHERE r.booking_id = t.booking_id
        AND UPPER(r.reporting_status) = UPPER('{{ params.approved_status }}')
  )
{% endif %}
ORDER BY cd.relevant_end_dt DESC, t.booking_id ASC
LIMIT 1
