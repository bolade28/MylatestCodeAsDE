ALTER TABLE {{ get_table('bookings_blacklist') }}
ADD COLUMN IF NOT EXISTS campaign_id VARCHAR(1000)
;