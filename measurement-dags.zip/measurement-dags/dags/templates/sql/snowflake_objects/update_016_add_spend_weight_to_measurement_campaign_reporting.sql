ALTER TABLE IF EXISTS {{ get_table('measurement_campaign_reporting_aws') }}
ADD COLUMN IF NOT EXISTS PRODUCT_TYPE VARCHAR(10)
COMMENT 'BRAND or OFFER, identifying which measurement the row belongs to.';

ALTER TABLE IF EXISTS {{ get_table('measurement_campaign_reporting_aws') }}
ADD COLUMN IF NOT EXISTS SPEND_WEIGHT FLOAT
COMMENT 'Share of overlapping campaign spend applied to this row, by product type and campaign duration.';
