-- Update all the pollen unified campaign tables to include a new column 'can_run_incrementality' which indicates whether a booking can run the baseline pipeline to produce incremental results.
-- This column will be used in the logic to determine if the incremental pipeline can be executed for a given booking, otherwise it will be skipped, which will save resources and prevent unnecessary pipeline runs for bookings that are not eligible for incremental processing.

ALTER TABLE {{ get_table('measurement_unified_campaign_pollen_daily_etl') }}
ADD COLUMN IF NOT EXISTS can_run_incrementality BOOLEAN
;

ALTER TABLE {{ get_table('measurement_unified_campaign_pollen_prod_evaluation') }}
ADD COLUMN IF NOT EXISTS can_run_incrementality BOOLEAN
;