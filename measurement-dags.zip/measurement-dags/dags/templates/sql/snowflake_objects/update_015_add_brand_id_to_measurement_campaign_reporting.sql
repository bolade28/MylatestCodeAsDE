-- Recreate BRAND_ID as ARRAY to avoid unsupported direct type conversion from VARCHAR
ALTER TABLE IF EXISTS {{ get_table('measurement_campaign_reporting_aws') }}
DROP COLUMN IF EXISTS BRAND_ID;

ALTER TABLE IF EXISTS {{ get_table('measurement_campaign_reporting_aws') }}
ADD COLUMN IF NOT EXISTS BRAND_ID ARRAY
COMMENT 'List of brand IDs associated with the campaign.';
