CREATE TABLE IF NOT EXISTS {{ get_table('measurement_booking_tracker') }} (
    booking_id                 VARCHAR         NOT NULL COMMENT 'Configured booking ID for the tracked pipeline run',
    campaign_name              VARCHAR COMMENT 'Campaign name metadata to make tracked runs easier to identify',

    pipeline_stage             VARCHAR         NOT NULL COMMENT 'Pipeline stage for the tracked run (e.g., DURING, POST)',
    status                     VARCHAR         NOT NULL DEFAULT 'READY' COMMENT 'Current tracker status for the run (e.g., READY, STARTED, COMPLETED, FAILED)',
    qa_passed                  BOOLEAN COMMENT 'Used to determine the status of the QA validation checks',

    last_run_correlation_id    VARCHAR         NOT NULL COMMENT 'Latest pipeline correlation ID associated with this booking and stage combination',

    run_count                  INTEGER         DEFAULT 0 COMMENT 'Number of times this booking and stage combination has been run or rerun',

    created_at                 TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP() COMMENT 'Timestamp when the tracker row was first created',
    load_ts                    TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP() COMMENT 'Timestamp when the tracker row was last updated'
)
COMMENT='Booking tracker table for measurement pipeline automation.';
