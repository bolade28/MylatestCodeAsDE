


-- Snowflake does not permit altering column data type directly if the column already contains data. The workaround is to create a new column with the desired data type, copy the data over with necessary casting, and then drop the old column.

-- Measurement campaign execution
ALTER TABLE {{ get_table('measurement_campaign_reporting_aws') }}
RENAME COLUMN IF EXISTS
  iroas_exposed TO iroas_exposed_old
;

ALTER TABLE {{ get_table('measurement_campaign_reporting_aws') }}
ADD COLUMN IF NOT EXISTS
  iroas_exposed FLOAT COMMENT 'Incremental ROAS (Return on Ad Spend) exposed metric, calculated as incremental sales amount exposed divided by media spend amount.'
;

UPDATE {{ get_table('measurement_campaign_reporting_aws') }}
SET iroas_exposed = iroas_exposed_old::FLOAT
WHERE iroas_exposed_old IS NOT NULL
;

ALTER TABLE {{ get_table('measurement_campaign_reporting_aws') }}
DROP COLUMN IF EXISTS iroas_exposed_old
;
