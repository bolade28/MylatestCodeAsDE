ALTER TABLE IF EXISTS {{ get_table('measurement_metadata') }}
ADD COLUMN IF NOT EXISTS RUN_TRIGGER_TYPE VARCHAR(20)
COMMENT 'How the DAG run was initiated (e.g., AUTOMATED, MANUAL)';

