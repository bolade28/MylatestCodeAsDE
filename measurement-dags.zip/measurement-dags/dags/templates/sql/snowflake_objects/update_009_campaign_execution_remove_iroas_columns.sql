

-- Columns were added accidentlly, this just removes them. No data should have been written to these columns yet, so no data loss should occur.
ALTER TABLE {{ get_table('measurement_campaign_execution_aws') }}
DROP COLUMN IF EXISTS
  IROAS_EXPOSED
;

ALTER TABLE {{ get_table('measurement_campaign_execution_aws') }}
DROP COLUMN IF EXISTS
  IROAS_EXPOSED_OLD
;