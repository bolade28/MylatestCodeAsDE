ALTER TABLE IF EXISTS {{ get_table('measurement_booking_tracker') }}
RENAME COLUMN IF EXISTS updated_at TO load_ts;
