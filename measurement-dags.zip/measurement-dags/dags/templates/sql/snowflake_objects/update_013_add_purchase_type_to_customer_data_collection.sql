ALTER TABLE {{ get_table('customer_data_collection_aws') }}
ADD COLUMN IF NOT EXISTS purchase_type VARCHAR(1000)
;