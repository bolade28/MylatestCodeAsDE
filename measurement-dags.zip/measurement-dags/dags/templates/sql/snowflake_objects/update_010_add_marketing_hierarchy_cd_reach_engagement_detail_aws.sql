-- Add marketing_hierarchy_cd column to measurement_booking_reach_engagement_detail_aws
-- This table was missing the marketing_hierarchy_cd column that was added as part of the channel hierarchy standardisation update

ALTER TABLE {{ get_table('measurement_booking_reach_engagement_detail_aws') }}
ADD COLUMN IF NOT EXISTS
  marketing_hierarchy_cd VARCHAR(1000) COMMENT 'Marketing hierarchy code derived from subchannel_name, used for hierarchical campaign reporting and grouping'
;

UPDATE {{ get_table('measurement_booking_reach_engagement_detail_aws') }} d
SET d.marketing_hierarchy_cd = h.marketing_hierarchy_cd
FROM {{ get_table('measurement_marketing_channel_hierarchy') }} h
WHERE d.subchannel_name = h.marketing_subchannel
  AND d.marketing_hierarchy_cd IS NULL
  AND h.in_scope_flag = TRUE;
