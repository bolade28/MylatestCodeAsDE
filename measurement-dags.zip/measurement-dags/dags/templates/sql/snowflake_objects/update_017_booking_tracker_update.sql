UPDATE {{ get_table('measurement_booking_tracker') }}
SET status = 'READY',
    load_ts = CURRENT_TIMESTAMP()
WHERE UPPER(status) = 'PENDING';
