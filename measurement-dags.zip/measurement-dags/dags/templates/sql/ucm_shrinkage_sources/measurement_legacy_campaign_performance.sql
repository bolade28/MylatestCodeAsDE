REMOVE {{ get_stage('measurement_legacy_campaign_performance') }}/;
COPY INTO {{ get_stage('measurement_legacy_campaign_performance') }}
FROM (
    SELECT
        item_cd,
        campaign_id,
        campaign_start_date,
        campaign_end_date,
        period,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM {{ get_table('measurement_legacy_campaign_performance') }}
)
include_query_id = true
header = true;
