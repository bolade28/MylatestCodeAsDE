REMOVE {{ get_stage('sub_cat_brand_weekly_spend') }}/;
COPY INTO {{ get_stage('sub_cat_brand_weekly_spend') }}
FROM (
    SELECT
        item_cd,
        year,
        week,
        inflation_ratio,
        avg_weekly_spend,
        avg_weekly_spend_inf_adj
    FROM {{ get_table('sub_cat_brand_weekly_spend') }}
)
include_query_id = true
header = true;

