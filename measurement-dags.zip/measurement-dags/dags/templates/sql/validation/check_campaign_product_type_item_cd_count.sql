-- This test file runs in sequence after check_mandatory_campaign_details.sql has created the staging table
INSERT INTO {{ get_table('campaign_validation_issues_stage') }}
WITH valid_campaigns AS (
    SELECT
        cbmc.campaign_id,
        cbmc.booking_id,
        cbmc.booking_status,
        cbmc.booking_name,
        cbmc.marketing_channel AS channel_name,
        cbmc.marketing_subchannel,
        cbmc.channel_type,
        CAST(cbmc.booking_media_live_end_dt AS DATE) AS campaign_end_date,
        cbmc.booking_item_cd_list
    FROM {{ get_table('campaign_booking_media_channel') }} AS cbmc
    WHERE LOWER(cbmc.booking_status) IN ('completed', 'active')
        AND cbmc.campaign_id != '-1'
        AND cbmc.marketing_channel != '-1'
        AND cbmc.marketing_subchannel != '-1'
        AND cbmc.channel_type != '-1'
        AND cbmc.booking_media_live_start_dt IS NOT NULL
        AND cbmc.booking_media_live_end_dt IS NOT NULL
        AND cbmc.booking_item_cd_list IS NOT NULL
),
--Count distinct booking item codes (SKUs) from BDV for each campaign
booking_item_cd_counts AS (
    SELECT
        cb.campaign_id,
        cb.booking_id,
        cb.channel_name,
        cb.marketing_subchannel,
        COUNT(DISTINCT TRY_CAST(json_extract_path_text(out.value, 'skuId') AS INT)) AS booking_item_cd_count
    FROM valid_campaigns AS cb
    LEFT JOIN LATERAL FLATTEN(input => cb.booking_item_cd_list) AS out
    WHERE json_extract_path_text(out.value, 'skuId') IS NOT NULL
    GROUP BY
        cb.campaign_id,
        cb.booking_id,
        cb.channel_name,
        cb.marketing_subchannel
),
--Count distinct booking item codes (SKUs) from campaign_product_type for each campaign
product_type_item_cd_counts AS (
    SELECT
        campaign_id,
        booking_id,
        channel_name,
        subchannel_name AS marketing_subchannel,
        COUNT(DISTINCT item_cd) AS product_type_item_cd_count
    FROM {{ get_table('campaign_product_type_aws') }}
    WHERE lower(product_type) = 'offer'
    GROUP BY
        campaign_id,
        booking_id,
        channel_name,
        subchannel_name
),
-- Identify campaigns with item count mismatches
item_cd_mismatch_campaigns AS (
    SELECT
        cb.campaign_id,
        cb.booking_id,
        cb.channel_name,
        cb.marketing_subchannel,
        cb.booking_name,
        cb.booking_status,
        cb.campaign_end_date,
        ARRAY_TO_STRING(
            ARRAY_CONSTRUCT_COMPACT(
                IFF(bic.booking_item_cd_count > COALESCE(pt.product_type_item_cd_count, 0), '510', NULL),
                IFF(bic.booking_item_cd_count < COALESCE(pt.product_type_item_cd_count, 0), '511', NULL)
            ), ', '
        ) AS reason_for_blacklisting
    FROM valid_campaigns AS cb
    LEFT JOIN booking_item_cd_counts AS bic
        ON cb.campaign_id = bic.campaign_id
        AND cb.booking_id = bic.booking_id
        AND cb.channel_name = bic.channel_name
        AND cb.marketing_subchannel = bic.marketing_subchannel
    INNER JOIN product_type_item_cd_counts AS pt
        ON cb.campaign_id = pt.campaign_id
        AND cb.booking_id = pt.booking_id
        AND cb.channel_name = pt.channel_name
        AND cb.marketing_subchannel = pt.marketing_subchannel
    WHERE (
        COALESCE(bic.booking_item_cd_count, 0) > COALESCE(pt.product_type_item_cd_count, 0)
        OR COALESCE(bic.booking_item_cd_count, 0) < COALESCE(pt.product_type_item_cd_count, 0)
    )
)

SELECT DISTINCT
    CAST('{{params.correlation_id}}' AS VARCHAR(36)) AS correlation_id,
    CAST(booking_id AS VARCHAR(1000)) AS booking_id,
    CAST(campaign_id AS VARCHAR(1000)) AS campaign_id,
    channel_name,
    booking_name,
    booking_status,
    campaign_end_date,
    reason_for_blacklisting,
    CAST(CURRENT_TIMESTAMP AS TIMESTAMP_NTZ(6)) AS load_ts
FROM item_cd_mismatch_campaigns
WHERE campaign_id IS NOT NULL
  AND booking_id IS NOT NULL;
