MERGE INTO {{ get_table('measurement_campaign_reporting_aws') }} AS target
USING (

    WITH get_brand_id AS (
        SELECT DISTINCT
            cbm.booking_id,
            obj_fields.value::STRING AS brand_id
        FROM {{ get_table('campaign_booking_media_channel_prod') }} AS cbm,
            LATERAL FLATTEN(input => cbm.unique_brand_list) AS arr_elements,
            LATERAL FLATTEN(input => arr_elements.value) AS obj_fields
        WHERE obj_fields.key = '_id'
          AND obj_fields.value::STRING IS NOT NULL
          AND obj_fields.value::STRING != ''
    )

    SELECT
        booking_id,
        ARRAY_AGG(DISTINCT brand_id) AS brand_id
    FROM get_brand_id
    GROUP BY booking_id

) AS source
ON target.booking_id = source.booking_id

WHEN MATCHED
    AND target.brand_id IS NULL
THEN UPDATE SET
    target.brand_id = source.brand_id;