REMOVE {{ get_stage('mta_fact_sale_transaction_item') }}/;
COPY INTO {{ get_stage('mta_fact_sale_transaction_item') }}
FROM (
    WITH campaign_date_range AS (
        SELECT
            MIN(mce.campaign_start_dt) AS min_campaign_start_dt,
            MAX(mce.campaign_end_dt) AS max_campaign_end_dt
        FROM {{ get_table('measurement_campaign_execution_status') }} AS mce
        WHERE mce.job_status = 'Not Started' OR mce.job_status IS NULL
    )
    SELECT
        fsti.transaction_id,
        fsti.transaction_dt,
        fsti.item_cd,
        fsti.net_retail_sales_amt,
        fsti.item_qty,
        fsti.item_sequence_num,
        fsti.store_cd
    FROM {{ get_table('fact_sale_transaction_item') }} fsti
    CROSS JOIN campaign_date_range cdr
    WHERE fsti.transaction_dt BETWEEN cdr.min_campaign_start_dt AND cdr.max_campaign_end_dt
    AND fsti.net_retail_sales_amt > 0
)
include_query_id = true
header = true;
