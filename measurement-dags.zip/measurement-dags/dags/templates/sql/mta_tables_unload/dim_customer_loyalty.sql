REMOVE {{ get_stage('dim_customer_loyalty') }}/;
COPY INTO {{ get_stage('dim_customer_loyalty') }}
FROM (
    SELECT
        dcl.nectar_collector_card_num,
        dcl.household_num,
        dcl.customer_account_type_name,
        dcl.customer_loyalty_cd
    FROM {{ get_table('dim_customer_loyalty') }} dcl
)
include_query_id = true
header = true;
