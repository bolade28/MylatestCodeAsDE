REMOVE {{ get_stage('reach_engagement_reporting') }}/;
COPY INTO {{ get_stage('reach_engagement_reporting') }}
FROM (
    SELECT DISTINCT
        mbre.campaign_id,
        mbre.channel_name,
        mbre.subchannel_name,
        mbre.marketing_type,
        mbre.booking_id,
        mbre.reach_count as reach_cnt,
        mbre.reach_count_distinct as dedup_campaign_reach,
        mbre.clicks_count as clicks_cnt,
        mbre.impressions_count as impressions_cnt,
        mbre.sales_amount as sales_amt,
        mbre.conversions_count as conversions_cnt,
        mbre.media_spend_amount as media_spend_amt,
        mbre.engagement_click_through_rate_percent as engagement_ctr_pct,
        mbre.load_ts::TIMESTAMP_NTZ AS load_ts,
        mbre.correlation_id as job_run_id
    FROM {{ get_table('measurement_booking_reach_engagement_detail_aws') }} AS mbre
    WHERE mbre.correlation_id = '{{params.during_correlation_id}}'
)
include_query_id = true
header = true;
