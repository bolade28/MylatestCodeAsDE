-- dim_item is current-state / non-time-aware
-- Historical super category attribution may reflect the latest mapping rather than the mapping at transaction time
-- This is considered acceptable because super category assignments are generally stable
-- As it looks at the whole year of transactions anyway, the impact of any super category changes is expected to be minimal
-- The tradeoff is intentional to avoid the cost/complexity of fully time-aware historical attribution for inflation adjustment
CREATE OR REPLACE TEMP TABLE {{ get_table('super_category_yearly_inflation') }} AS
WITH YEARLY_PRICES AS (
    SELECT  DATE_PART('year', tx.transaction_dt) AS YEAR,
        i.super_cat_cd,
        AVG(tx.base_unit_price_amt) AS avg_unit_price
    FROM {{ get_table('fact_sale_transaction_item') }} tx
    LEFT JOIN {{ get_table('dim_item') }} i ON tx.item_cd = i.item_cd
    WHERE tx.transaction_dt < CURRENT_DATE
    GROUP BY 1,2
)

SELECT
    YEAR,
    super_cat_cd,
    avg_unit_price,
    MAX(IFF(YEAR = DATE_PART('YEAR', CURRENT_DATE), AVG_UNIT_PRICE, 0)) OVER (PARTITION BY SUPER_CAT_CD) AS CURRENT_PRICE,
    ZEROIFNULL(AVG_UNIT_PRICE / NULLIFZERO(CURRENT_PRICE)) AS INFLATION_RATIO
FROM YEARLY_PRICES;

-- Calculate spend at weekly grain, to produce one average weekly spend value per item and category
CREATE OR REPLACE TRANSIENT TABLE {{ get_table('sub_cat_brand_weekly_spend') }} AS
WITH SC_BRAND_SPEND_PER_WEEK AS (
    SELECT
        i.item_cd,
        DATE_PART('year', tx.transaction_dt) AS YEAR,
        DATE_PART('week', tx.transaction_dt) AS WEEK,
        i.super_cat_cd,
        SUM(tx.EXTENDED_PRICE_AMT) AS WEEKLY_SPEND
    FROM {{ get_table('fact_sale_transaction_item') }} tx
    LEFT JOIN {{ get_table('dim_item') }} i ON tx.item_cd = i.item_cd
    WHERE tx.transaction_dt < CURRENT_DATE
    GROUP BY 1,2,3,4
)

SELECT
    sc.ITEM_CD,
    sc.YEAR,
    sc.WEEK,
    yi.INFLATION_RATIO,
    WEEKLY_SPEND AS AVG_WEEKLY_SPEND,
    WEEKLY_SPEND / NULLIFZERO(INFLATION_RATIO) AS AVG_WEEKLY_SPEND_INF_ADJ
FROM SC_BRAND_SPEND_PER_WEEK sc
LEFT JOIN {{ get_table('super_category_yearly_inflation') }} yi
    ON sc.super_cat_cd = yi.super_cat_cd
    AND sc.YEAR = yi.YEAR
