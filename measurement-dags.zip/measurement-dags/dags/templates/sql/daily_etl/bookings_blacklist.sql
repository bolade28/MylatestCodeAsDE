-- List of booking ids that needs to be excluded from unified_campaigns
-- TODO:: !important  - once booking linking is functional, we should look into removing this

CREATE OR REPLACE TRANSIENT TABLE {{ get_table('bookings_blacklist') }} COPY GRANTS AS
SELECT
    column1 AS correlation_id,
    column2 AS booking_id,
    column3 AS reason_for_exclusion,
    column4 AS load_ts,
    column5 AS campaign_id
FROM (VALUES
          (CAST('{{params.correlation_id}}' AS VARCHAR(36)), '69304b8fbc8295fbebf8c317',
           'we have to exclude this booking id as it''s been merged into 697cb5625dc3bb4b7469a763 . this needs to be done due to manual booking linking issue in Pollen platform.',
           current_timestamp::timestamp_ntz(9), NULL),
          (CAST('{{params.correlation_id}}' AS VARCHAR(36)), '6960cfcd86951c1f0b2be885',
           'we have to exclude this booking id as it''s been merged into 697cb5625dc3bb4b7469a763 . this needs to be done due to manual booking linking issue in Pollen platform.',
           current_timestamp::timestamp_ntz(9), NULL),
          (CAST('{{params.correlation_id}}' AS VARCHAR(36)), '68e5243cdbf0e3bdab79b7ac',
           'we have to exclude this booking id as it''s been merged into 697cb5625dc3bb4b7469a763 . this needs to be done due to manual booking linking issue in Pollen platform.',
           current_timestamp::timestamp_ntz(9), NULL),
          (CAST('{{params.correlation_id}}' AS VARCHAR(36)), '69de3734f5932cb18e48769b',
           'we have to exclude this booking id as it''s been merged into 69e7574f16d05f396ff99e6c . this needs to be done due to manual booking linking issue in Pollen platform.',
           current_timestamp::timestamp_ntz(9), NULL),
          (CAST('{{params.correlation_id}}' AS VARCHAR(36)), '',
           'we have to exclude this campaign id belonging to booking id 69e7574f16d05f396ff99e6c . this needs to be done as a result of some data quality issues.',
           current_timestamp::timestamp_ntz(9), '2458b7db-546c-457e-b5a1-39ecc86614b1'),
          (CAST('{{params.correlation_id}}' AS VARCHAR(36)), '6a104f452e0550f6a115ac95',
           'we have to exclude this booking id as it''s an abandoned overlapping campaign into 6a3bae761dbdd2229241174a . this needs to be done to ensure the spend weight is calculated correctly.',
           current_timestamp::timestamp_ntz(9), NULL)
           
);
