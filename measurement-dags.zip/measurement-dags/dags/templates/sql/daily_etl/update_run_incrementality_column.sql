{% set is_prod = params.get('is_prod', false) %}

-- Purpose
-- -------
-- Set `can_run_incrementality` in the Daily ETL so downstream baseline
-- modelling can skip bookings that do not have enough pre-campaign sales history.
--
-- Business rule (Contact Grigorios Mingas for any clarifications)
-- -------------
-- For each booking + brand + sub-category combination:
--   1. Look back across the 104 weeks before the booking starts.
--   2. Find the earliest week X where sales are non-zero and the next 3 weeks are also non-zero.
--      In other words, find the earliest continuous 4-week non-zero sales window.
--   3. Count the number of weeks from X to the campaign start week.
--   4. The combination is eligible only if that count is >= 52 weeks.
--
-- Booking-level rule
-- ------------------
-- A booking can run incrementality only when every brand/sub-category combination tied to
-- that booking passes the rule above.

CREATE OR REPLACE TEMPORARY TABLE incrementality_booking_eligibility AS
WITH pollen_campaigns AS (
    SELECT
        job_bag_number AS booking_id,
        '{{ params.pollen_type }}' AS campaign_type,
        DATE_TRUNC('week', MIN(campaign_start_dt)) AS campaign_start_week
    FROM {{ get_table('measurement_unified_campaign_pollen_daily_etl') }}
    WHERE load_ts = (
        SELECT MAX(load_ts)
        FROM {{ get_table('measurement_unified_campaign_pollen_daily_etl') }}
    )
    GROUP BY 1
),

prod_emulation_campaigns AS (
    SELECT
        job_bag_number AS booking_id,
        '{{ params.emulation_type }}' AS campaign_type,
        DATE_TRUNC('week', MIN(campaign_start_dt)) AS campaign_start_week
    FROM {{ get_table('measurement_unified_campaign_pollen') }}
    WHERE load_ts = (
        SELECT MAX(load_ts)
        FROM {{ get_table('measurement_unified_campaign_pollen') }}
    )
        AND NOT {{ is_prod }}
    GROUP BY 1
),

non_pollen_campaigns AS (
    SELECT
        booking_id,
        '{{ params.dtp_type }}' AS campaign_type,
        DATE_TRUNC('week', MIN(campaign_start_dt)) AS campaign_start_week
    FROM {{ get_table('measurement_unified_campaign') }}
    WHERE load_ts = (
        SELECT MAX(load_ts)
        FROM {{ get_table('measurement_unified_campaign') }}
    )
    GROUP BY 1
),

all_campaigns AS (
    SELECT booking_id, campaign_type, campaign_start_week FROM pollen_campaigns
    UNION ALL
    SELECT booking_id, campaign_type, campaign_start_week FROM prod_emulation_campaigns
    UNION ALL
    SELECT booking_id, campaign_type, campaign_start_week FROM non_pollen_campaigns
),

campaign_brand_scope AS (
    -- Each item_cd in this table is already filtered to the brand/sub-category scope of the campaign based on the logic in campaign_product_type.sql,
    -- so we can directly join to transactions on item_cd to get the relevant sales history.
    SELECT DISTINCT
        campaigns.booking_id,
        campaigns.campaign_type,
        campaigns.campaign_start_week,
        campaign_products.unique_brand_name,
        campaign_products.item_cd
    FROM all_campaigns AS campaigns
    INNER JOIN {{ get_table('campaign_product_type_aws') }} AS campaign_products
        ON campaigns.booking_id = campaign_products.booking_id
        AND campaigns.campaign_type = campaign_products.campaign_type
    WHERE LOWER(campaign_products.product_type) = '{{ params.product_type_filter }}'
        AND COALESCE(TRIM(campaign_products.unique_brand_name), '') <> ''
        AND COALESCE(TRIM(campaign_products.sub_cat_name), '') <> ''
),

weekly_brand_sales AS (
    -- Aggregate to weekly sales for each booking + brand + sub-category over the 104-week lookback window.
    SELECT
        scope.booking_id,
        scope.campaign_type,
        scope.campaign_start_week,
        scope.unique_brand_name,
        transactions.week_start_dt,
        SUM(COALESCE(transactions.total_sales_amt, 0)) AS weekly_sales_amt
    FROM campaign_brand_scope AS scope
    INNER JOIN {{ get_table('transactions') }} AS transactions
        ON scope.item_cd = transactions.item_cd -- get the scope of transactions that match the campaign's brand/sub-category based on item_cd
    WHERE transactions.week_start_dt >= DATEADD(week, -{{ params.look_back_period }}, LEAST(scope.campaign_start_week, DATE_TRUNC('week', CURRENT_DATE()))) -- Look back at the last 2 years (104 weeks) of sales history before the campaign start week (or current date if we're doing an early run).
        AND transactions.week_start_dt < scope.campaign_start_week
    GROUP BY 1, 2, 3, 4, 5
),

-- Retain only non-zero weeks, then identify the earliest continuous 4-week window.
positive_sales_weeks AS (
    SELECT
        booking_id,
        campaign_type,
        campaign_start_week,
        unique_brand_name,
        week_start_dt,
        ROW_NUMBER() OVER (
            PARTITION BY booking_id, campaign_type, campaign_start_week, unique_brand_name
            ORDER BY week_start_dt
        ) AS rn
    FROM weekly_brand_sales
    WHERE weekly_sales_amt > 0
),

-- Label groups of consecutive non-zero weeks with the same group number
consecutive_sales_groups AS (
    SELECT
        booking_id,
        campaign_type,
        campaign_start_week,
        unique_brand_name,
        week_start_dt,
        DATEADD(week, -rn, week_start_dt) AS consecutive_group
    FROM positive_sales_weeks
),

earliest_continuous_sales_window AS (
    SELECT
        booking_id,
        campaign_type,
        campaign_start_week,
        unique_brand_name,
        MIN(week_start_dt) AS earliest_sales_window_week
    FROM consecutive_sales_groups
    GROUP BY 1, 2, 3, 4, consecutive_group
    HAVING COUNT(*) >= 4 -- Only consider groups of 4 or more consecutive non-zero sales weeks to meet the requirement of a continuous 4-week window.
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY booking_id, campaign_type, campaign_start_week, unique_brand_name
        ORDER BY MIN(week_start_dt)
    ) = 1
),

-- Right now we don't run multi-brand campaigns through the incremental pipeline, but in the future when we do, this logic will allow us to evaluate the 52-week requirement at the brand level and then roll it up to the booking level.
brand_subcategory_eligibility AS (
    -- Evaluate the 52-week requirement per booking + brand (sub-category already filtered within the brand)
    SELECT
        scope.booking_id,
        scope.campaign_type,
        scope.unique_brand_name,
        IFF(
            window.earliest_sales_window_week IS NOT NULL
            AND DATEDIFF(week, window.earliest_sales_window_week, LEAST(scope.campaign_start_week, DATE_TRUNC('week', CURRENT_DATE()))) >= {{ params.consective_sales_period }}, -- supports early runs
            TRUE,
            FALSE
        ) AS can_run_incrementality
    FROM (
        SELECT DISTINCT
            booking_id,
            campaign_type,
            campaign_start_week,
            unique_brand_name
        FROM campaign_brand_scope
    ) AS scope
    LEFT JOIN earliest_continuous_sales_window AS window
        ON scope.booking_id = window.booking_id
        AND scope.campaign_type = window.campaign_type
        AND scope.campaign_start_week = window.campaign_start_week
        AND scope.unique_brand_name = window.unique_brand_name
),

booking_eligibility AS (
    -- Reduce the rule to the booking level to support multi-brand campaigns, where if any brand tied to the booking fails the requirement, then the whole booking fails.
    --   * no scope found => FALSE
    --   * any failing brand => FALSE
    --   * otherwise => TRUE
    SELECT
        campaigns.booking_id,
        campaigns.campaign_type,
        CASE
            WHEN COUNT(eligibility.unique_brand_name) = 0 THEN FALSE
            ELSE MIN(IFF(eligibility.can_run_incrementality, 1, 0)) = 1
        END AS can_run_incrementality
    FROM all_campaigns AS campaigns
    LEFT JOIN brand_subcategory_eligibility AS eligibility
        ON campaigns.booking_id = eligibility.booking_id
        AND campaigns.campaign_type = eligibility.campaign_type
    GROUP BY 1, 2
)
SELECT
    booking_id,
    campaign_type,
    can_run_incrementality
FROM booking_eligibility
;

-- Update the latest pollen snapshot.
UPDATE {{ get_table('measurement_unified_campaign_pollen_daily_etl') }} AS campaigns
SET can_run_incrementality = eligibility.can_run_incrementality
FROM incrementality_booking_eligibility AS eligibility
WHERE campaigns.job_bag_number = eligibility.booking_id
    AND eligibility.campaign_type = '{{ params.pollen_type }}'
    AND campaigns.load_ts = (
        SELECT MAX(load_ts)
        FROM {{ get_table('measurement_unified_campaign_pollen_daily_etl') }}
    )
;

-- Update the latest DTP unified campaign snapshot.
UPDATE {{ get_table('measurement_unified_campaign') }} AS campaigns
SET can_run_incrementality = eligibility.can_run_incrementality
FROM incrementality_booking_eligibility AS eligibility
WHERE campaigns.booking_id = eligibility.booking_id
    AND eligibility.campaign_type = '{{ params.dtp_type }}'
    AND campaigns.load_ts = (
        SELECT MAX(load_ts)
        FROM {{ get_table('measurement_unified_campaign') }}
    )
;
