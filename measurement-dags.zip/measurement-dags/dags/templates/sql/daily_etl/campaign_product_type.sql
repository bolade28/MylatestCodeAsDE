{% set is_prod = params.get('is_prod', false) %}

-- Note: we currently only build Offer and Brand product scopes.
-- Aisle SKU logic has been intentionally removed because it is not in use.

CREATE OR REPLACE TRANSIENT TABLE {{ get_table('campaign_product_type_aws') }} COPY GRANTS AS
(
    -- Build the unified campaigns for (Dev and Prod) Pollen and DTP, then derive Offer and Brand SKU groupings.
    -- unified_products is the single source of product and brand attributes.
    WITH pollen_campaigns AS (
		SELECT
            job_bag_number AS booking_id, -- job_bag_number is the booking_id from BDV for pollen campaigns
			campaign_id,
			channel_name,
			subchannel_name,
			sub_category_name,
			item_cd_list,
			campaign_start_dt,
            campaign_end_dt,
			'{{ params.pollen_type }}' AS campaign_type
		FROM {{ get_table('measurement_unified_campaign_pollen') }}
		WHERE load_ts = (
			SELECT MAX(load_ts)
			FROM {{ get_table('measurement_unified_campaign_pollen') }}
		)
	),

	-- When the emulation toggle is ON, this CTE reads from the PROD measurement_unified_campaign_pollen table.
	prod_emulation_campaigns AS (
		SELECT
            job_bag_number AS booking_id, -- job_bag_number is the booking_id from BDV for pollen campaigns
			campaign_id,
			channel_name,
			subchannel_name,
			sub_category_name,
			item_cd_list,
			campaign_start_dt,
            campaign_end_dt,
			'{{ params.emulation_type }}' AS campaign_type
		FROM {{ get_table('measurement_unified_campaign_pollen_prod') }}
		WHERE load_ts = (
			SELECT MAX(load_ts)
			FROM {{ get_table('measurement_unified_campaign_pollen_prod') }}
		)
		AND NOT {{ is_prod }}
	),

	non_pollen_campaigns AS (
	    SELECT
            booking_id,
			campaign_id,
			channel_name,
			subchannel_name,
			sub_category_name,
			item_cd_list,
			campaign_start_dt,
            campaign_end_dt,
			'{{ params.dtp_type }}' AS campaign_type
		FROM {{ get_table('measurement_unified_campaign') }}
		WHERE load_ts = (
			SELECT MAX(load_ts)
			FROM {{ get_table('measurement_unified_campaign') }}
		)
	),

	-- Keep both pollen and non_pollen campaigns, we'll filter in the unload step downstream depending on if we're doing a DTP or pollen run
	all_campaigns AS (
	    SELECT
            booking_id,
			campaign_id,
			channel_name,
			subchannel_name,
			sub_category_name,
			item_cd_list,
			campaign_start_dt,
            campaign_end_dt,
			campaign_type
		FROM pollen_campaigns

        UNION ALL

        SELECT
            booking_id,
			campaign_id,
			channel_name,
			subchannel_name,
			sub_category_name,
			item_cd_list,
			campaign_start_dt,
            campaign_end_dt,
			campaign_type
		FROM prod_emulation_campaigns

		UNION ALL

		SELECT
            booking_id,
            campaign_id,
            channel_name,
            subchannel_name,
            sub_category_name,
            item_cd_list,
            campaign_start_dt,
            campaign_end_dt,
            campaign_type
        FROM non_pollen_campaigns
    ),

    -- Get the campaign end date to check if an item_cd was valid for the current campaign
    -- For example we might pick up a brand sku that was valid from April 2026 onwards, but we're running a campaign that ended in March 2026, so that brand sku should not be included in the output for that campaign
    min_max_campaign_dates AS (
        SELECT
            campaign_id,
            channel_name,
            subchannel_name,
            MAX(campaign_end_dt) AS max_campaign_end_dt
        FROM all_campaigns
        GROUP BY 1, 2, 3
    ),

    -- Split comma-separated item lists into one row per offer SKU.
    offer_flatten AS (
        SELECT DISTINCT
            booking_id,
            campaign_id,
            channel_name,
            subchannel_name,
            campaign_type,
            TRIM(flattened.value::VARCHAR) AS item_cd
        FROM all_campaigns,
            LATERAL FLATTEN(INPUT => SPLIT(item_cd_list, ',')) AS flattened
        WHERE TRIM(flattened.value::VARCHAR) <> ''
    ),

	-- unified_products contains our product view with all relevant attributes for filtering and enrichment
	product_reference AS (
		SELECT DISTINCT
            item_cd,
			item_name,
			sub_cat_name,
            brand_name,
            brand_owner_name,
			unique_brand_name,
            valid_from_dt,
            load_ts
		FROM {{ get_table('unified_products') }}
        WHERE unique_brand_name IS NOT NULL
            AND TRIM(unique_brand_name) != ''
	),

    -- Enrich each campaign SKU with product metadata from unified_products.
	offer_items AS (
        SELECT
            offer.booking_id,
			offer.campaign_id,
            offer.channel_name,
			offer.subchannel_name,
            product.sub_cat_name,
            product.brand_name,
            product.brand_owner_name,
            product.unique_brand_name,
            offer.item_cd,
            product.item_name AS sku_name,
			offer.campaign_type,
            product.load_ts
        FROM offer_flatten AS offer
        INNER JOIN product_reference AS product
            ON offer.item_cd = product.item_cd
    ),

	-- Offer SKUs are the campaign (booking) SKUs themselves, enriched with product + brand details.
    offer_rows AS (
        SELECT
            item_cd,
            'Offer' AS product_type,
            channel_name,
            subchannel_name,
            booking_id,
            campaign_id,
            sku_name,
            sub_cat_name,
            brand_name,
            brand_owner_name,
            unique_brand_name,
            campaign_type
        FROM offer_items
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY campaign_type, booking_id, campaign_id, channel_name, subchannel_name, item_cd
            ORDER BY load_ts DESC
        ) = 1
    ),

    -- Brand SKUs are all products that share the offer SKU brand and sub-category.
    -- Keep the latest product snapshot that was valid on or before the campaign end date.
    brand_items AS (
        SELECT
            product.item_cd,
            offer.channel_name,
            offer.subchannel_name,
            offer.booking_id,
            offer.campaign_id,
            product.item_name AS sku_name,
            offer.sub_cat_name,
            product.brand_name,
            product.brand_owner_name,
            product.unique_brand_name,
            offer.campaign_type,
            product.load_ts
        FROM offer_rows AS offer
        INNER JOIN product_reference AS product
            ON product.unique_brand_name = offer.unique_brand_name
            AND product.sub_cat_name = offer.sub_cat_name
        INNER JOIN min_max_campaign_dates AS cd
            ON cd.campaign_id = offer.campaign_id
            AND cd.channel_name = offer.channel_name
            AND cd.subchannel_name = offer.subchannel_name
        WHERE product.valid_from_dt <= cd.max_campaign_end_dt
    ),

	brand_rows AS (
        SELECT
            item_cd,
            'Brand' AS product_type,
            channel_name,
            subchannel_name,
            booking_id,
            campaign_id,
            sku_name,
            sub_cat_name,
            brand_name,
            brand_owner_name,
            unique_brand_name,
            campaign_type
        FROM brand_items
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY campaign_type, booking_id, campaign_id, channel_name, subchannel_name, item_cd
            ORDER BY load_ts DESC
        ) = 1
	),

	campaign_product_type AS (
	    SELECT * FROM offer_rows
		UNION ALL
		SELECT * FROM brand_rows
	)

	-- Cast into the final table structure expected by downstream steps.
	SELECT DISTINCT
		COALESCE(CAST(item_cd AS NUMBER(38,0)), 0) AS item_cd,
		CAST(product_type AS VARCHAR(32)) AS product_type,
	    CAST(channel_name AS VARCHAR(128)) AS channel_name,
		CAST(COALESCE(subchannel_name, 'NA') AS VARCHAR(128)) AS subchannel_name,
		CAST(booking_id AS VARCHAR(100)) AS booking_id,
		CAST(campaign_id AS VARCHAR(100)) AS campaign_id,
		CAST(sku_name AS VARCHAR(3000)) AS sku_name,
		CAST(sub_cat_name AS VARCHAR(1000)) AS sub_cat_name,
        CAST(brand_name AS VARCHAR(1000)) AS brand_name,
        CAST(brand_owner_name AS VARCHAR(1000)) AS brand_owner_name,
		COALESCE(CAST(unique_brand_name AS VARCHAR(1000)), '') AS unique_brand_name,
		CAST(campaign_type AS VARCHAR(32)) AS campaign_type,
		CAST('{{ params.correlation_id }}' AS VARCHAR(36)) AS job_run_id,
		CURRENT_TIMESTAMP::TIMESTAMP_NTZ AS load_ts
	FROM campaign_product_type
);