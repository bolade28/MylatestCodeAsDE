{#/******************************************************************************************************************

* Objective:
        - This script is used to create time series data of sales along with other features listed below at Item code level
            AND create feature metrics - total_sales_amt, avg_purchase_per_customer_cnt, online, super market,
            convenience sales percentage, pack size, price per point etc...

* Business Context:
        - Sales forms the main dependent variable in our process to estimate baseline sales. However raw transaction data
            is too granular AND unprocessed for us to use directly
        - This script not only provides the sales in a processed manner, but also calculates other variables from the
            transaction table which form features for the clustering model.
        - The output of this script basically forms a starting point for all the other scripts since our entire process
            is dependent on sales.

* Lineage:
        Upstream:
                - transactions_agg_intermediate
        Downstream:
                - sales_data_transformation

* Confluence:
        https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/834210620/Sales+Data+Transformation

*******************************************************************************************************************/#}

ALTER SESSION SET statement_timeout_in_seconds = 43200;
CREATE OR REPLACE TRANSIENT TABLE {{ get_table('transactions') }} COPY GRANTS AS
 -- Use 1 as a neutral default so missing attributes do not null or zero calculations. 
 -- TODO: see if we can remove some/all item based features if downstream process dont use it.
WITH product_attributes AS (
    SELECT DISTINCT
        item_cd,
        COALESCE(std_item_total_wgt_or_vol_qty, 1) AS sku_volume_std,
        COALESCE(unit_or_item_weight_or_vol_qty, 1) AS pack_size
    FROM {{ get_table('dim_item') }}
    WHERE operating_company_cd = 1
        AND op_co_item_cd <> -2
),

supermarket_prices AS (
    SELECT
        transactions.item_cd,
        DATE_TRUNC('week', transactions.transaction_dt)::DATE AS week_start_date,
        MAX(transactions.base_unit_price_amt) AS base_price_amt
    FROM {{ get_table('fact_sale_transaction_item') }} AS transactions
    INNER JOIN {{ get_table('dim_store_org_hierarchy') }} AS stores
        ON transactions.store_cd = stores.store_cd
    WHERE UPPER(stores.store_type) = '{{ params.supermarket_store_type }}'
    GROUP BY
        transactions.item_cd,
        DATE_TRUNC('week', transactions.transaction_dt)::DATE
),

temp_date_dataset AS (
    SELECT week_start_dt AS week_start_date
    FROM {{ get_table('weekly_start_dates_daily_etl') }}
),

sales_by_sku AS (
    SELECT DISTINCT
        transactions.sku_no,
        transactions.date_,
        transactions.total_quantity,
        transactions.freq_of_purch,
        transactions.distinct_customers,
        transactions.avg_purchase_per_customer_cnt,
        transactions.online_trans,
        transactions.conven_trans,
        transactions.super_trans,
        transactions.nectar_sales,
        transactions.non_nectar_sales,
        attributes.sku_volume_std,
        attributes.pack_size,
        prices.base_price_amt
    FROM {{ get_table('transactions_agg_intermediate') }} AS transactions
    INNER JOIN product_attributes AS attributes
        ON transactions.sku_no = attributes.item_cd
    LEFT JOIN supermarket_prices AS prices
        ON transactions.sku_no = prices.item_cd
        AND transactions.date_ = prices.week_start_date
),

required_skus AS (
    SELECT DISTINCT sku_no
    FROM sales_by_sku
),

weekly_sales_by_sku AS (
    SELECT
        skus.sku_no,
        weeks.week_start_date,
        AVG(sales.sku_volume_std) AS sku_volume_std,
        AVG(sales.pack_size) AS pack_size,
        AVG(sales.base_price_amt) AS base_price_amt,
        COALESCE(SUM(sales.avg_purchase_per_customer_cnt), 0) AS avg_purchase_per_customer_cnt,
        COALESCE(SUM(sales.total_quantity), 0) AS total_item_qty,
        COALESCE(SUM(sales.freq_of_purch), 0) AS freq_of_purch,
        COALESCE(SUM(sales.distinct_customers), 0) AS distinct_customers,
        COALESCE(SUM(sales.online_trans), 0) AS online_trans,
        COALESCE(SUM(sales.conven_trans), 0) AS conven_trans,
        COALESCE(SUM(sales.super_trans), 0) AS super_trans,
        COALESCE(SUM(sales.nectar_sales), 0) AS nectar_sales,
        COALESCE(SUM(sales.non_nectar_sales), 0) AS non_nectar_sales
    FROM required_skus AS skus
    CROSS JOIN temp_date_dataset AS weeks
    LEFT JOIN sales_by_sku AS sales
        ON skus.sku_no = sales.sku_no
        AND weeks.week_start_date <= sales.date_
        AND sales.date_ < DATEADD(week, 1, weeks.week_start_date)
    GROUP BY
        skus.sku_no,
        weeks.week_start_date
),

weekly_sales_imputed AS (
    SELECT
        week_start_date,
        sku_no,
        nectar_sales,
        non_nectar_sales,
        total_item_qty,
        freq_of_purch,
        avg_purchase_per_customer_cnt,
        distinct_customers,
        online_trans,
        conven_trans,
        super_trans,
        COALESCE(
            sku_volume_std,
            FIRST_VALUE(sku_volume_std IGNORE NULLS) OVER (
                PARTITION BY sku_no
                ORDER BY week_start_date
                ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
            ),
            LAST_VALUE(sku_volume_std IGNORE NULLS) OVER (
                PARTITION BY sku_no
                ORDER BY week_start_date
                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
            )
        ) AS sku_volume_std,
        COALESCE(
            pack_size,
            FIRST_VALUE(pack_size IGNORE NULLS) OVER (
                PARTITION BY sku_no
                ORDER BY week_start_date
                ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
            ),
            LAST_VALUE(pack_size IGNORE NULLS) OVER (
                PARTITION BY sku_no
                ORDER BY week_start_date
                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
            )
        ) AS pack_size,
        COALESCE(
            base_price_amt,
            FIRST_VALUE(base_price_amt IGNORE NULLS) OVER (
                PARTITION BY sku_no
                ORDER BY week_start_date
                ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
            ),
            LAST_VALUE(base_price_amt IGNORE NULLS) OVER (
                PARTITION BY sku_no
                ORDER BY week_start_date
                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
            )
        ) AS base_price_amt
    FROM weekly_sales_by_sku
),

negative_values_adjusted AS (
    SELECT
        week_start_date,
        sku_no,
        freq_of_purch,
        distinct_customers,
        avg_purchase_per_customer_cnt,
        online_trans,
        conven_trans,
        super_trans,
        sku_volume_std,
        pack_size,
        base_price_amt,
        CASE WHEN nectar_sales < 0 THEN 0 ELSE nectar_sales END AS nectar_sales_value,
        CASE WHEN non_nectar_sales < 0 THEN 0 ELSE non_nectar_sales END AS non_nectar_sales_value,
        CASE WHEN total_item_qty < 0 THEN 0 ELSE total_item_qty END AS item_qty,
        CASE WHEN online_trans < 0 THEN 0 ELSE online_trans END AS online_sales,
        CASE WHEN super_trans < 0 THEN 0 ELSE super_trans END AS super_sales,
        CASE WHEN conven_trans < 0 THEN 0 ELSE conven_trans END AS conven_sales
    FROM weekly_sales_imputed
),

sales_metrics AS (
    SELECT
        week_start_date,
        sku_no,
        nectar_sales_value,
        non_nectar_sales_value,
        nectar_sales_value + non_nectar_sales_value AS sales_value,
        freq_of_purch,
        distinct_customers,
        avg_purchase_per_customer_cnt,
        online_sales,
        super_sales,
        conven_sales,
        sku_volume_std,
        pack_size,
        base_price_amt
    FROM negative_values_adjusted
),

sales_data_transformation_output AS (
    SELECT
        week_start_date AS week_start_dt,
        sku_no AS item_cd,
        sales_value AS total_sales_amt,
        nectar_sales_value AS nectar_sales_amt,
        non_nectar_sales_value AS non_nectar_sales_amt,
        freq_of_purch AS frequency_of_purchase,
        distinct_customers AS distinct_customer_cnt,
        avg_purchase_per_customer_cnt,
        COALESCE(online_sales / NULLIF(sales_value, 0), 0) AS online_sales_pct,
        COALESCE(super_sales / NULLIF(sales_value, 0), 0) AS supermarket_sales_pct,
        COALESCE(conven_sales / NULLIF(sales_value, 0), 0) AS convenience_sales_pct,
        COALESCE(pack_size, 0) AS pack_size,
        COALESCE(base_price_amt / NULLIF(pack_size, 0), 0) AS price_per_point,
        COALESCE(base_price_amt, 0) AS base_price_amt
    FROM sales_metrics
)

SELECT DISTINCT
    CAST(week_start_dt AS DATE) AS week_start_dt,
    CAST(NULL AS VARCHAR(300)) AS super_category_name,
    CAST(NULL AS VARCHAR(384)) AS unique_brand_name,
    CAST(item_cd AS NUMBER(38, 0)) AS item_cd,
    CAST(total_sales_amt AS NUMBER(38, 4)) AS total_sales_amt,
    CAST(nectar_sales_amt AS NUMBER(38, 4)) AS nectar_sales_amt,
    CAST(non_nectar_sales_amt AS NUMBER(38, 4)) AS non_nectar_sales_amt,
    CAST(frequency_of_purchase AS NUMBER(30, 0)) AS frequency_of_purchase,
    CAST(distinct_customer_cnt AS NUMBER(30, 0)) AS distinct_customer_cnt,
    CAST(avg_purchase_per_customer_cnt AS NUMBER(36, 6)) AS avg_purchase_per_customer_cnt,
    CAST(online_sales_pct AS NUMBER(38, 10)) AS online_sales_pct,
    CAST(supermarket_sales_pct AS NUMBER(38, 10)) AS supermarket_sales_pct,
    CAST(convenience_sales_pct AS NUMBER(38, 10)) AS convenience_sales_pct,
    CAST(pack_size AS NUMBER(38, 12)) AS pack_size,
    CAST(price_per_point AS NUMBER(38, 12)) AS price_per_point,
    CAST(base_price_amt AS NUMBER(38, 12)) AS base_price_amt
FROM sales_data_transformation_output;