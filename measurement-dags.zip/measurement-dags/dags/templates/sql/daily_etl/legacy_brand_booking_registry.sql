-- Booking-level registry of bookings that must keep using legacy EAN_BR brand logic.
-- Rebuilt daily, purely from measurement_metadata, no hardcoded booking ids.
CREATE OR REPLACE TRANSIENT TABLE {{ get_table('legacy_brand_booking_registry') }} COPY GRANTS AS
WITH completed_during_runs_pollen AS (
    -- every completed DURING pollen run for a booking, not just the latest one
    SELECT
        booking_id,
        correlation_id,
        COALESCE(additional_metadata:used_new_brand_logic::boolean, FALSE) AS used_new_brand_logic
    FROM {{ get_table('measurement_metadata') }}
    WHERE lower(evaluation_period) = 'during'
      AND lower(pipeline_status) = 'completed'
      AND lower(run_type) = 'pollen'
),
completed_post_runs_pollen AS (
    SELECT
        booking_id,
        correlation_id,
        during_correlation_id
    FROM {{ get_table('measurement_metadata') }}
    WHERE lower(evaluation_period) = 'post'
      AND lower(pipeline_status) = 'completed'
      AND lower(run_type) = 'pollen'
),
booking_brand_status AS (
    SELECT
        booking_id,
        -- "new wins": TRUE if any completed DURING run for this booking used new brand logic
        BOOLOR_AGG(used_new_brand_logic) AS any_during_used_new_logic
    FROM completed_during_runs_pollen
    GROUP BY booking_id
),
reported_post_runs_pollen AS (
    -- POST correlation ids whose reporting output still exists (i.e. not since cleared)
    SELECT DISTINCT correlation_id, booking_id
    FROM {{ get_table('measurement_campaign_reporting_aws') }}
)
SELECT DISTINCT
    b.booking_id,
    CURRENT_TIMESTAMP()::timestamp_ntz(9) AS load_ts
FROM booking_brand_status AS b
WHERE b.any_during_used_new_logic = FALSE
  -- booking_brand_status already guarantees every DURING run here is legacy, so the grace
  -- window ends once a completed POST run's reporting output still exists; a completed POST
  -- whose output was later cleared (clear_measurement_outputs_dag) must not drop the booking
  -- out of the registry
  AND NOT EXISTS (
        SELECT 1
        FROM completed_post_runs_pollen AS p
        JOIN reported_post_runs_pollen AS r
          ON r.correlation_id = p.correlation_id
         AND r.booking_id = p.booking_id
        WHERE p.booking_id = b.booking_id
  );
