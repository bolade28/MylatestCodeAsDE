{#/*******************************************************************************************************************
* Objective:
    - This script is used to create time series date skeleton at weekly level between start and end date
    - Start Date would be the date, 2 years ago from today (lower bound set at 1st Jan 2022)
    - End Date anchor is the earliest of:
        1. the monday of the campaign booking end week
        2. the monday of the latest fully completed run week
    - This prevents us from including a partially completed run week while still not extending beyond the campaign end week

**********************************************************************************************************************/#}

CREATE OR REPLACE TRANSIENT TABLE {{ get_table('weekly_start_dates') }} COPY GRANTS AS
(
    -- Calculating start and end date for processing period, to generate weekly_dates view
    -- Anchor to the campaign-end week monday while that week is in progress, advance to the next monday once that week has completed,
    -- and for earlier runs use the previous completed run week monday.
    WITH
    date_anchors AS (
        SELECT
            CAST('{{ params.booking_end_date }}' AS date) AS booking_end_date,
            CAST('{{ params.run_date }}' AS date) AS run_date,
            DATE_TRUNC('week', CAST('{{ params.booking_end_date }}' AS date)) AS booking_end_week_monday,
            DATEADD(week, -1, DATE_TRUNC('week', CAST('{{ params.run_date }}' AS date))) AS last_completed_run_week_monday
    ),
    anchor_date AS (
        SELECT
            LEAST(last_completed_run_week_monday, booking_end_week_monday) AS current_week_monday
        FROM date_anchors
    ),
    generator_nums AS (
        SELECT seq1() AS num
          FROM TABLE(GENERATOR(ROWCOUNT => {{ params.number_of_weeks }}))
    ),
    -- Create a series of dates starting from the anchor monday and going back 104 weeks to create the modelling period.
    -- Example: campaigns that start on a Wednesday are considered to have started on the Monday of the same week.
    monday_series AS (
        SELECT DATEADD(week, -gen.num, (SELECT current_week_monday FROM anchor_date)) AS monday_date
          FROM generator_nums AS gen
         -- ensure campaign start dates are never too far in the past
         WHERE monday_date >= TO_DATE('2022-01-03')
    )

  SELECT monday_date AS WEEK_START_DT FROM monday_series
  ORDER BY monday_date

);
