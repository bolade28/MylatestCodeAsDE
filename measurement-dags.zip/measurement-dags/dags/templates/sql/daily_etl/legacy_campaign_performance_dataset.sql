/*
Builds the legacy campaign performance dataset populated in the daily ETL DAG.

This template:
- Aggregates campaign performance metrics for instore, coupon-at-till, ecoupon, and DTP (META) campaigns.
- Leaves granularity at the campaign level, SKU level, to decouple the product hierarchy from the campaign performance metrics, for more control.
- Adds campaign dates, media cost, and duplicate-row flags for safe downstream aggregation.
- Unions all campaign sources into measurement_legacy_campaign_performance with metadata.

Note:
- This data is calculated for the During period (timeperiod = 2) and Post period (timeperiod = 3).
- This data is calculated on the Brand level (product = 'brand') to align with the UCM methodology

Output table:
- {{ get_table('measurement_legacy_campaign_performance') }}
*/

CREATE OR REPLACE TEMP TABLE {{ get_table('instore_performance_temp') }} AS
-- Aggregate Instore performance data from media level to campaign level.
WITH instore_performance_data_campaign_level AS (
        SELECT
            master_campaign_id AS campaign_id,
            CASE WHEN timeperiod = 2 THEN 'DURING' WHEN timeperiod = 3 THEN 'POST' END AS period,
            SUM(uplift) AS uplift,
            SUM(test) AS test,
            SUM(control) AS control
        FROM {{ get_table('instore_dashboard') }}
        WHERE
            LOWER(product) = '{{ params.product_type }}'
            AND timeperiod IN {{ params.time_period }} -- filter for the during and post period
            AND LOWER(media_type) = 'total'
            AND LOWER(metric) = 'spend'
            AND uplift IS NOT NULL
        GROUP BY master_campaign_id, period
    ),
    -- Retrieve distinct SKUs linked to each instore campaign.
    campaign_skus AS (
        SELECT DISTINCT
            inpdcl.campaign_id,
            pdl.sku_no as item_cd
        FROM instore_performance_data_campaign_level AS inpdcl
        INNER JOIN {{ get_table('ie_product') }} AS iep
            ON inpdcl.campaign_id = iep.master_campaign_id
        INNER JOIN {{ get_table('product_dim_latest') }} AS pdl
            ON iep.product_key = pdl.product_key
        WHERE LOWER(iep.product_name) = '{{ params.product_type }}'
    )
-- Combine campaign metrics, product hierarchy and campaign dates.
SELECT
    ipdcl.campaign_id,
    cs.item_cd,
    ipdcl.period,
    iec.start_date AS campaign_start_date,
    iec.end_date AS campaign_end_date,
    NULL AS exposed, -- exposed metric not currently available for instore finding a new source in progress :D
    ipdcl.uplift,
    ipdcl.test,
    ipdcl.control,
    iec.media_cost,
    'instore' AS campaign_source
FROM instore_performance_data_campaign_level AS ipdcl
INNER JOIN {{ get_table('ie_campaign_filt') }} AS iec
    ON iec.master_campaign_id = ipdcl.campaign_id
INNER JOIN campaign_skus AS cs
    ON ipdcl.campaign_id = cs.campaign_id;


CREATE OR REPLACE TEMP TABLE {{ get_table('cat_performance_temp') }} AS
-- Coupon at till campaign media data.
-- The data is should already be aggregated at the campaign level but just in case we have multiple rows per campaign, we take the max value of total cost to avoid double counting.
WITH cat_media_cost AS (
        SELECT
            campaign_id,
            MAX(total_cost) AS media_cost
        FROM {{ get_table('cat_media_costs') }}
        WHERE analysis_level = 2 -- This is a filter for the aggregated values at the campaign level, as opposed to the coupon level which is analysis_level 1
        GROUP BY campaign_id
    ),
    -- Aggregate CAT dashboard data from coupon level to campaign level.
    -- The data is currently partitioned per coupon per cycle
    cat_performance_data_campaign_level AS (
        SELECT
            cd.campaign_id,
            SUM(cd.exposed) AS exposed,
            COALESCE(
                NULLIF(MAX(cmc.media_cost), 0), -- if the value is 0 use the fallback
                SUM(total_cost)
            ) AS media_cost,
            SUM(cd.uplift) AS uplift,
            SUM(cd.test) AS test,
            SUM(cd.control) AS control
        FROM {{ get_table('cat_dashboard') }} cd
        LEFT JOIN cat_media_cost AS cmc
            ON cd.campaign_id = cmc.campaign_id
        WHERE
            cd.uplift IS NOT NULL
            AND cd.brand_name IS NOT NULL
            AND LOWER(cd.brand_name) != 'unknown'
        GROUP BY cd.campaign_id
    ),

    -- Retrieve distinct SKUs linked to each coupon-at-till campaign.
    -- We persist coupon key as well to get the campaign dates later
    campaign_skus AS (
        SELECT DISTINCT
            pd.campaign_id,
            ctp.coupon_key,
            pdl.sku_no as item_cd
        FROM cat_performance_data_campaign_level AS pd
        INNER JOIN {{ get_table('cell') }} AS c
            ON pd.campaign_id = c.campaign_id
        INNER JOIN {{ get_table('coupon_cell') }} AS cc
            ON c.cell_key = cc.cell_key
        INNER JOIN {{ get_table('coupon_to_product') }} AS ctp
            ON cc.coupon_key = ctp.coupon_key
        INNER JOIN {{ get_table('product_dim_latest') }} AS pdl
            ON ctp.product_key = pdl.product_key
        WHERE ctp.correct_offer = 'Y'
          AND ctp.correct_brand = 'Y'
    ),

    -- Get campaign start and end dates for coupon-at-till campaigns.
    cat_campaign_dates AS (
        SELECT
            coupon_key,
            MIN(start_date) AS campaign_start_date,
            MAX(expiry_date) AS campaign_end_date
        FROM {{ get_table('coupon') }}
        WHERE expiry_date IS NOT NULL
        GROUP BY coupon_key
    ),
    cat_campaign_dates_filtered AS (
        SELECT DISTINCT
            ck.campaign_id,
            MIN(cat_dates.campaign_start_date) AS campaign_start_date,
            MAX(cat_dates.campaign_end_date) AS campaign_end_date
        FROM cat_campaign_dates AS cat_dates
        INNER JOIN campaign_skus AS ck
            ON cat_dates.coupon_key = ck.coupon_key
       GROUP BY ck.campaign_id
    )

-- Combine product hierarchy and campaign dates.
SELECT
    cpd.campaign_id,
    cs.item_cd,
    cpdtf.campaign_start_date,
    cpdtf.campaign_end_date,
    cpd.exposed,
    cpd.uplift,
    cpd.test,
    cpd.control,
    cpd.media_cost,
    'coupon-at-till' AS campaign_source
FROM cat_performance_data_campaign_level AS cpd
INNER JOIN cat_campaign_dates_filtered AS cpdtf
    ON cpd.campaign_id = cpdtf.campaign_id
INNER JOIN campaign_skus AS cs
    ON cpd.campaign_id = cs.campaign_id;


CREATE OR REPLACE TEMP TABLE {{ get_table('ecoupon_performance_temp') }} AS
-- Get the total cost which is exposed_cost + redemption_cost this is an estimate so it's not reliable,
-- it's only used to backfill any missing values that aren't present in ec_dash_metrics_3
WITH ecoupon_exposed_redemptions AS (
        SELECT
            campaign_id,
            sum(case when metric = 'EXPOSED' then test else 0 end) as exposed,
            sum(case when metric = 'EXPOSED' then test else 0 end) * '{{ params.exposed_cost_estimate }}' as exposed_cost,
            sum(case when metric = 'REDEMPTIONS' then test else 0 end) as redemptions,
            sum(case when metric = 'REDEMPTION COST' then test else 0 end) as redemptions_cost
        FROM {{ get_table('ecoupon_results_table') }}
            WHERE timeperiod IN {{ params.time_period }} -- during period
            AND product_no = 1 -- the costs are created on the offer level as that's what the campaign is targeting so we need to filter on product_no 1
        GROUP BY 1
    ),
    -- Aggregate ecoupon dashboard data from coupon level to campaign level and join with cost data
    -- The data is currently partitioned per coupon per cycle per offer, brand, aisle
    ecoupon_performance_data_campaign_level AS (
        SELECT
            ee.campaign_id,
            SUM(emc.tot_exposed) AS exposed,
            COALESCE(
                SUM(emc.total_cost),
                SUM(eer.exposed_cost) + SUM(eer.redemptions_cost)
            ) AS media_cost,
            SUM(ee.uplift) AS uplift,
            SUM(ee.test) AS test,
            SUM(ee.control) AS control
        FROM {{ get_table('ecoupon_results_table') }} AS ee
        INNER JOIN {{ get_table('ecoupon_media_costs') }} AS emc
            ON ee.campaign_id = emc.campaign_id
        LEFT JOIN ecoupon_exposed_redemptions AS eer
            ON ee.campaign_id = eer.campaign_id
        WHERE ee.timeperiod IN {{ params.time_period }} -- filter for the during period
            AND ee.product_no = '{{ params.product_type_no }}' -- filter for brand skus
            AND LOWER(ee.metric) = 'spend' -- get the spend of the campaigns
            AND ee.uplift IS NOT NULL
        GROUP BY ee.campaign_id
    ),

    -- Retrieve distinct SKUs linked to each ecoupon campaign.
    campaign_skus AS (
        SELECT DISTINCT
            epd.campaign_id,
            pdl.sku_no as item_cd
        FROM ecoupon_performance_data_campaign_level AS epd
        INNER JOIN {{ get_table('oc_products') }} AS ocp
            ON epd.campaign_id = ocp.campaign_id
        INNER JOIN {{ get_table('product_dim_latest') }} AS pdl
            ON ocp.product_key = pdl.product_key
        WHERE ocp.product_no = '{{ params.product_type_no }}' -- filter for brand skus
    ),
    campaign_dates AS (
        SELECT
            campaign_id,
            MIN(start_date) AS campaign_start_date,
            MAX(expiry_date) AS campaign_end_date
        FROM {{ get_table('oc_campaign') }}
        WHERE start_date IS NOT NULL
            AND expiry_date IS NOT NULL
        GROUP BY campaign_id
    )

SELECT
    epdcl.campaign_id,
    cs.item_cd,
    cd.campaign_start_date,
    cd.campaign_end_date,
    epdcl.exposed,
    epdcl.uplift,
    epdcl.test,
    epdcl.control,
    epdcl.media_cost,
    'ecoupon' AS campaign_source
FROM ecoupon_performance_data_campaign_level AS epdcl
INNER JOIN campaign_dates AS cd
    ON cd.campaign_id = epdcl.campaign_id
INNER JOIN campaign_skus AS cs
    ON cs.campaign_id = epdcl.campaign_id;


CREATE OR REPLACE TEMP TABLE {{ get_table('dtp_performance_temp') }} AS
-- Aggregate DTP data from weekly level to campaign level
WITH dtp_performance_data_campaign_level AS (
        SELECT
            campaign_id,
            CASE WHEN timeperiod = 2 THEN 'DURING' WHEN timeperiod = 3 THEN 'POST' END AS period,
            SUM(uplift) AS uplift,
            SUM(total_exposed_spend) AS test,
            SUM(total_control_spend) AS control
        FROM {{ get_table('dtp_dashboard') }}
        WHERE
            timeperiod IN {{ params.time_period }} -- filter for the during and post period
            AND LOWER(product) = '{{ params.product_type }}'
            AND uplift IS NOT NULL
        GROUP BY campaign_id, period
    ),
    -- Retrieve distinct SKUs linked to each DTP campaign.
    campaign_skus AS (
        SELECT DISTINCT
            dpdcl.campaign_id,
            pd.sku_no as item_cd
        FROM dtp_performance_data_campaign_level AS dpdcl
        INNER JOIN {{ get_table('de_product') }} AS dp
            ON dpdcl.campaign_id = dp.master_campaign_id
       -- product_dim is a tactical source so this may need to be replaced in the future, as of now I'm using to map product keys to skus for the DTP (Meta) campaigns,
       -- This source is also being used for the Analytics team
        INNER JOIN {{ get_table('product_dim') }} AS pd
            ON dp.product_key = pd.product_key
        WHERE LOWER(dp.product_name) = '{{ params.product_type }}'
    ),
    campaign_dates AS (
        SELECT
            master_campaign_id AS campaign_id,
            MIN(start_date) AS campaign_start_date,
            MAX(end_date) AS campaign_end_date,
            MAX(media_cost) AS media_cost
        FROM {{ get_table('de_campaign') }}
        WHERE start_date IS NOT NULL
            AND end_date IS NOT NULL
        GROUP BY master_campaign_id
    )

SELECT
    dpdcl.campaign_id,
    cs.item_cd,
    dpdcl.period,
    cd.campaign_start_date,
    cd.campaign_end_date,
    NULL AS exposed, -- exposed metric not currently available for DTP, finding some in progress
    dpdcl.uplift,
    dpdcl.test,
    dpdcl.control,
    cd.media_cost,
    'offsite' AS campaign_source
FROM dtp_performance_data_campaign_level AS dpdcl
INNER JOIN campaign_dates AS cd
    ON cd.campaign_id = dpdcl.campaign_id
INNER JOIN campaign_skus AS cs
    ON cs.campaign_id = dpdcl.campaign_id;


CREATE OR REPLACE TRANSIENT TABLE {{ get_table('measurement_legacy_campaign_performance') }} COPY GRANTS AS
WITH unioned_campaign_performance AS (
    SELECT
        campaign_id,
        item_cd,
        period,
        campaign_start_date,
        campaign_end_date,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM {{ get_table('instore_performance_temp') }}

    UNION ALL

    SELECT
        campaign_id,
        item_cd,
        'DURING' AS period, -- we only have during period data for CAT campaigns
        campaign_start_date,
        campaign_end_date,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM {{ get_table('cat_performance_temp') }}

    UNION ALL

    SELECT
        campaign_id,
        item_cd,
        'DURING' AS period, -- we only have during period data for ecoupon campaigns
        campaign_start_date,
        campaign_end_date,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM {{ get_table('ecoupon_performance_temp') }}

    UNION ALL

    SELECT
        campaign_id,
        item_cd,
        period,
        campaign_start_date,
        campaign_end_date,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM {{ get_table('dtp_performance_temp') }}
),

final_campaign_performance AS (
    SELECT
        campaign_id,
        item_cd,
        period,
        campaign_start_date,
        campaign_end_date,
        CASE
            WHEN COUNT(*) OVER (PARTITION BY campaign_id) > 1 THEN 'Y'
            ELSE 'N'
        END AS has_multiple_rows,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM unioned_campaign_performance
)

SELECT
    CAST(UPPER(campaign_id) AS VARCHAR(50)) AS campaign_id,
    CAST(UPPER(item_cd) AS VARCHAR(50)) AS item_cd,
    CAST(UPPER(period) AS VARCHAR(50)) AS period,
    CAST(campaign_start_date AS DATE) AS campaign_start_date,
    CAST(campaign_end_date AS DATE) AS campaign_end_date,
    CAST(has_multiple_rows AS VARCHAR(1)) AS has_multiple_rows,
    CAST(exposed AS NUMBER(38,0)) AS exposed,
    CAST(uplift AS NUMBER(18,6)) AS uplift,
    CAST(test AS NUMBER(18,6)) AS test,
    CAST(control AS NUMBER(18,6)) AS control,
    CAST(media_cost AS NUMBER(18,6)) AS media_cost,
    CAST(UPPER(campaign_source) AS VARCHAR(300)) AS campaign_source,
    CAST('{{ params.correlation_id }}' AS VARCHAR(36)) AS correlation_id,
    CAST(CURRENT_TIMESTAMP AS TIMESTAMP_NTZ) AS load_ts
FROM final_campaign_performance;