{% set is_prod = params.get('is_prod', false) %}


CREATE OR REPLACE TRANSIENT TABLE {{ get_table('campaign_product_type_aws_new_brand_source') }} COPY GRANTS AS
(
    -- Unified Campaign tables act as a filter since we extract the raw booking_item_cd_list from the booking source table, since we need the addon dates
    WITH pollen_campaigns AS (
		SELECT
            job_bag_number AS booking_id, -- job_bag_number is the booking_id from BDV for pollen campaigns
			campaign_id,
			channel_name,
			subchannel_name,
			'{{ params.pollen_type }}' AS campaign_type
		FROM {{ get_table('measurement_unified_campaign_pollen') }}
		WHERE load_ts = (
			SELECT MAX(load_ts)
			FROM {{ get_table('measurement_unified_campaign_pollen') }}
		)
	),

	prod_emulation_campaigns AS (
		SELECT
            job_bag_number AS booking_id, -- job_bag_number is the booking_id from BDV for pollen campaigns
			campaign_id,
			channel_name,
			subchannel_name,
			'{{ params.emulation_type }}' AS campaign_type
		FROM {{ get_table('measurement_unified_campaign_pollen_prod') }}
		WHERE load_ts = (
			SELECT MAX(load_ts)
			FROM {{ get_table('measurement_unified_campaign_pollen_prod') }}
		)
		AND NOT {{ is_prod }}
	),

    -- currently DTP campaigns will be broken as any old ones will not have any brand data since brand data only from 2025 onwards
    -- ToDo: Use the latest resolved brands from the ITEM_BRAND view instead of the historical table to resolve DTP campaigns
	non_pollen_campaigns AS (
	    SELECT
            booking_id,
			campaign_id,
			channel_name,
			subchannel_name,
			item_cd_list,
			campaign_start_dt,
            campaign_end_dt,
			'{{ params.dtp_type }}' AS campaign_type
		FROM {{ get_table('measurement_unified_campaign') }}
		WHERE load_ts = (
			SELECT MAX(load_ts)
			FROM {{ get_table('measurement_unified_campaign') }}
		)
	),

    -- Gets brand data for each item_cd and valid_from_dt
    item_brand_hist AS (
        SELECT
            item_cd,
            valid_from_dt,
            valid_until_dt,
            unique_brand_name
        FROM {{ get_table('item_brand_hist') }}
        WHERE COALESCE(technical_metadata:record_deleted_flag::VARCHAR, 'N') = 'N'
            AND NULLIF(TRIM(unique_brand_name), '') IS NOT NULL
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY item_cd, valid_from_dt
            ORDER BY load_ts DESC
        ) = 1
    ),

    -- Fallback brand for pre-history bookings: earliest available ITEM_BRAND_HIST row per SKU.
    item_brand_hist_earliest AS (
        SELECT
            item_cd,
            unique_brand_name
        FROM item_brand_hist
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY item_cd
            ORDER BY valid_from_dt ASC, valid_until_dt ASC
        ) = 1
    ),

    -- Get the booking SKU list from the source table.
    pollen_booking_source AS (
        SELECT
            booking_id,
            campaign_id,
            booking_item_cd_list,
            MIN(booking_media_live_start_dt) AS booking_start_dt,
            MAX(booking_media_live_end_dt) AS booking_end_dt
        FROM {{ get_table('campaign_booking_media_channel') }}
        WHERE booking_item_cd_list IS NOT NULL
        GROUP BY 1, 2, 3
    ),

    pollen_booking_reference_dates AS (
        SELECT
            booking_id,
            MAX(
                COALESCE(
                    TRY_TO_TIMESTAMP(flattened.value:addedOn::VARCHAR),
                    TO_TIMESTAMP(TRY_TO_NUMBER(flattened.value:addedOn::VARCHAR), 3),
                    booking_start_dt
                )::DATE
            ) AS booking_reference_dt
        FROM pollen_booking_source
        , LATERAL FLATTEN(INPUT => booking_item_cd_list, OUTER => TRUE) AS flattened
        GROUP BY 1
    ),

    prod_emulation_booking_source AS (
        SELECT
            booking_id,
            campaign_id,
            booking_item_cd_list,
            MIN(booking_media_live_start_dt) AS booking_start_dt,
            MAX(booking_media_live_end_dt) AS booking_end_dt
        FROM {{ get_table('campaign_booking_media_channel_prod') }}
        WHERE booking_item_cd_list IS NOT NULL
        AND NOT {{ is_prod }}
        GROUP BY 1, 2, 3
    ),

    prod_emulation_booking_reference_dates AS (
        SELECT
            booking_id,
            MAX(
                COALESCE(
                    TRY_TO_TIMESTAMP(flattened.value:addedOn::VARCHAR),
                    TO_TIMESTAMP(TRY_TO_NUMBER(flattened.value:addedOn::VARCHAR), 3),
                    booking_start_dt
                )::DATE
            ) AS booking_reference_dt
        FROM prod_emulation_booking_source
        , LATERAL FLATTEN(INPUT => booking_item_cd_list, OUTER => TRUE) AS flattened
        GROUP BY 1
    ),

    -- Create a unified list of all campaign items across pollen, prod emulation, and non-pollen campaigns.
    pollen_items AS (
        SELECT DISTINCT
            campaign.booking_id,
            campaign.campaign_id,
            campaign.channel_name,
            campaign.subchannel_name,
            source.booking_start_dt,
            source.booking_end_dt,
            campaign.campaign_type,
            TRIM(flattened.value:skuId::VARCHAR) AS item_cd,
            reference.booking_reference_dt
        FROM pollen_campaigns AS campaign
        INNER JOIN pollen_booking_source AS source
            ON source.booking_id = campaign.booking_id
            AND source.campaign_id = campaign.campaign_id
        INNER JOIN pollen_booking_reference_dates AS reference
            ON reference.booking_id = campaign.booking_id
        , LATERAL FLATTEN(INPUT => source.booking_item_cd_list, OUTER => TRUE) AS flattened
        WHERE TRIM(flattened.value:skuId::VARCHAR) <> ''
    ),

    prod_emulation_items AS (
        SELECT DISTINCT
            campaign.booking_id,
            campaign.campaign_id,
            campaign.channel_name,
            campaign.subchannel_name,
            source.booking_start_dt,
            source.booking_end_dt,
            campaign.campaign_type,
            TRIM(flattened.value:skuId::VARCHAR) AS item_cd,
            reference.booking_reference_dt
        FROM prod_emulation_campaigns AS campaign
        INNER JOIN prod_emulation_booking_source AS source
            ON source.booking_id = campaign.booking_id
            AND source.campaign_id = campaign.campaign_id
        INNER JOIN prod_emulation_booking_reference_dates AS reference
            ON reference.booking_id = campaign.booking_id
        , LATERAL FLATTEN(INPUT => source.booking_item_cd_list, OUTER => TRUE) AS flattened
        WHERE TRIM(flattened.value:skuId::VARCHAR) <> ''
        AND NOT {{ is_prod }}
    ),

    -- Non-pollen campaigns do not have BDV item metadata, so their reference date is the campaign start date.
    -- Their item list already arrives as a comma-separated string on the unified campaign table.
    non_pollen_items AS (
        SELECT DISTINCT
            booking_id,
            campaign_id,
            channel_name,
            subchannel_name,
            campaign_start_dt AS booking_start_dt,
            campaign_end_dt AS booking_end_dt,
            campaign_type,
            TRIM(flattened.value::VARCHAR) AS item_cd,
            campaign_start_dt AS booking_reference_dt
        FROM non_pollen_campaigns
        , LATERAL FLATTEN(INPUT => SPLIT(item_cd_list, ',')) AS flattened
        WHERE TRIM(flattened.value::VARCHAR) <> ''
    ),

    campaign_items AS (
        SELECT * FROM pollen_items

        UNION ALL

        SELECT * FROM prod_emulation_items

        UNION ALL

        SELECT * FROM non_pollen_items
    ),

    -- The booking reference date is the primary lookup date, it reflects the same logic we use in the pipeline to resolve the brand/sub-category for the offer item.
    offer_item_mapping AS (
        SELECT
            campaign.booking_id,
            campaign.campaign_id,
            campaign.channel_name,
            campaign.subchannel_name,
            campaign.booking_start_dt,
            campaign.booking_end_dt,
            campaign.campaign_type,
            campaign.item_cd,
            campaign.booking_reference_dt,
            COALESCE(brand.unique_brand_name, fallback_brand.unique_brand_name) AS unique_brand_name,
            item_hist.unique_sub_cat_cd,
            item_hist.item_name,
            item_hist.sub_cat_name
        FROM campaign_items AS campaign
        LEFT JOIN item_brand_hist AS brand
            ON campaign.item_cd = brand.item_cd
            AND (
                campaign.booking_reference_dt BETWEEN brand.valid_from_dt AND brand.valid_until_dt
            )
        -- Preserve the reference-date brand when present; otherwise use the earliest known brand.
        LEFT JOIN item_brand_hist_earliest AS fallback_brand
            ON campaign.item_cd = fallback_brand.item_cd
            AND brand.item_cd IS NULL
        LEFT JOIN {{ get_table('dim_item_hist') }} AS item_hist
            ON campaign.item_cd = item_hist.item_cd
            AND (
                campaign.booking_reference_dt BETWEEN item_hist.valid_from_dt AND item_hist.valid_until_dt
            )
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY campaign.campaign_type, campaign.booking_id, campaign.campaign_id, campaign.channel_name, campaign.subchannel_name, campaign.item_cd
            ORDER BY brand.valid_from_dt ASC, item_hist.valid_from_dt ASC
        ) = 1
    ),

    offer_rows AS (
        SELECT
            offer.item_cd,
            'Offer' AS product_type,
            offer.channel_name,
            offer.subchannel_name,
            offer.booking_id,
            offer.campaign_id,
            offer.item_name AS sku_name,
            offer.sub_cat_name,
            NULLIF(TRIM(SPLIT_PART(offer.unique_brand_name, ' | ', 1)), '') AS brand_name,
            NULLIF(TRIM(SPLIT_PART(offer.unique_brand_name, ' | ', 2)), '') AS brand_owner_name,
            offer.unique_brand_name,
            offer.campaign_type
        FROM offer_item_mapping AS offer
    ),

    brand_scopes AS (
        SELECT DISTINCT
            booking_id,
            campaign_id,
            channel_name,
            subchannel_name,
            booking_start_dt,
            booking_end_dt,
            campaign_type,
            booking_reference_dt,
            unique_brand_name,
            unique_sub_cat_cd
        FROM offer_item_mapping
        WHERE unique_brand_name IS NOT NULL
            AND unique_sub_cat_cd IS NOT NULL
    ),

    -- Brand rows expand each resolved offer brand to all in-scope items for the same historic brand and sub-category.
    brand_item_mapping AS (
        SELECT
            scope.booking_id,
            scope.campaign_id,
            scope.channel_name,
            scope.subchannel_name,
            scope.campaign_type,
            brand.item_cd,
            scope.unique_brand_name,
            item_hist.item_name,
            item_hist.sub_cat_name
        FROM brand_scopes AS scope
        INNER JOIN item_brand_hist AS brand
            ON scope.unique_brand_name = brand.unique_brand_name
            -- if the brand matches at any point during the booking period, include the SKU.
            -- there is pending a final decision on the logic, but this the most inclusive approach if we care about getting all partial brands
            AND (
                scope.booking_reference_dt BETWEEN brand.valid_from_dt AND brand.valid_until_dt
            )
        INNER JOIN {{ get_table('dim_item_hist') }} AS item_hist
            ON item_hist.item_cd = brand.item_cd
            AND item_hist.unique_sub_cat_cd = scope.unique_sub_cat_cd
            -- Apply the same overlap rule to the historic sub-category so the brand SKU is valid in the same period as the brand match above.
            AND (
                scope.booking_reference_dt BETWEEN item_hist.valid_from_dt AND item_hist.valid_until_dt
            )
        -- De-duplicate multiple overlapping historic records down to one row per output SKU.
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY scope.campaign_type, scope.booking_id, scope.campaign_id, scope.channel_name, scope.subchannel_name, brand.item_cd
            ORDER BY brand.valid_from_dt ASC, item_hist.valid_from_dt ASC
        ) = 1
    ),

	brand_rows AS (
        SELECT
            brand.item_cd,
            'Brand' AS product_type,
            brand.channel_name,
            brand.subchannel_name,
            brand.booking_id,
            brand.campaign_id,
            brand.item_name AS sku_name,
            brand.sub_cat_name,
            NULLIF(TRIM(SPLIT_PART(brand.unique_brand_name, ' | ', 1)), '') AS brand_name,
            NULLIF(TRIM(SPLIT_PART(brand.unique_brand_name, ' | ', 2)), '') AS brand_owner_name,
            brand.unique_brand_name,
            brand.campaign_type
        FROM brand_item_mapping AS brand
	),

	campaign_product_type AS (
	    SELECT * FROM offer_rows
		UNION ALL
		SELECT * FROM brand_rows
	)

	SELECT DISTINCT
		COALESCE(CAST(item_cd AS NUMBER(38,0)), 0) AS item_cd,
		CAST(product_type AS VARCHAR(32)) AS product_type,
	    CAST(channel_name AS VARCHAR(128)) AS channel_name,
		CAST(COALESCE(subchannel_name, 'NA') AS VARCHAR(128)) AS subchannel_name,
		CAST(booking_id AS VARCHAR(100)) AS booking_id,
		CAST(campaign_id AS VARCHAR(100)) AS campaign_id,
		CAST(sku_name AS VARCHAR(3000)) AS sku_name,
		CAST(sub_cat_name AS VARCHAR(1000)) AS sub_cat_name,
        CAST(brand_name AS VARCHAR(1000)) AS brand_name,
        CAST(brand_owner_name AS VARCHAR(1000)) AS brand_owner_name,
		COALESCE(CAST(unique_brand_name AS VARCHAR(1000)), '') AS unique_brand_name,
		CAST(campaign_type AS VARCHAR(32)) AS campaign_type,
		CAST('{{ params.correlation_id }}' AS VARCHAR(36)) AS job_run_id,
		CURRENT_TIMESTAMP::TIMESTAMP_NTZ AS load_ts
	FROM campaign_product_type
);
