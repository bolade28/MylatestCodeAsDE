BEGIN;

DELETE FROM {{ get_table('measurement_booking_reach_engagement_detail_aws') }}
WHERE correlation_id = '{{ params.correlation_id }}';



DELETE FROM {{ get_table('measurement_campaign_reporting_aws') }}
WHERE correlation_id = '{{ params.correlation_id }}';


DELETE FROM {{ get_table('customer_data_collection_aws') }}
WHERE job_run_id = '{{ params.correlation_id }}';



DELETE FROM {{ get_table('unified_products_aws') }}
WHERE job_run_id = '{{ params.correlation_id }}';


DELETE FROM {{ get_table('baseline_attribution_integration_aws') }}
WHERE correlation_id = '{{ params.correlation_id }}';


DELETE FROM {{ get_table('measurement_sku_cluster_mapping') }}
WHERE job_run_id = '{{ params.correlation_id }}';


DELETE FROM {{ get_table('measurement_baseline_modelling_dataset') }}
WHERE job_run_id = '{{ params.correlation_id }}';


DELETE FROM {{ get_table('measurement_baseline_modelling_output') }}
WHERE job_run_id = '{{ params.correlation_id }}';

COMMIT;
