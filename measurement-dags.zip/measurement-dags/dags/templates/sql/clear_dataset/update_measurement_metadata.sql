UPDATE {{ get_table('measurement_metadata') }}
SET deployment_status = 'deleted',
    load_ts = CURRENT_TIMESTAMP()
WHERE correlation_id = '{{ params.correlation_id }}';
