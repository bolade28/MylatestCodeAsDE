REMOVE {{ get_stage('ucm_output_data_during') }}/;
COPY INTO {{ get_stage('ucm_output_data_during') }}
FROM (
    SELECT
        week_start_dt,
        super_category_name,
        unique_brand_name,
        cluster_num,
        iteration,
        modelling_type,
        best_iteration,
        metric_name,
        metric_value,
        rsq,
        wsmape,
        baseline_perc,
        job_run_id,
        load_ts
    FROM {{ get_table('measurement_baseline_modelling_output') }}
    -- Only the during run's best iteration is needed for post-period baseline modelling
    WHERE job_run_id = '{{ params.during_correlation_id }}'
      AND best_iteration = 'Y'
)
include_query_id = true
header = true;
