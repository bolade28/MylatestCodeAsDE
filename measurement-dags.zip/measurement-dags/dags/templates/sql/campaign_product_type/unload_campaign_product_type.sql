REMOVE {{ get_stage('campaign_product_type') }}/;
COPY INTO {{ get_stage('campaign_product_type') }}
FROM (
SELECT
    item_cd,
    product_type,
    channel_name,
    subchannel_name,
    booking_id,
    campaign_id,
    sku_name,
    sub_cat_name,
    brand_name,
    brand_owner_name,
    unique_brand_name,
    campaign_type,
    job_run_id,
    load_ts
FROM {{ get_table('campaign_product_type_aws') }}
WHERE campaign_type = CASE
    WHEN LOWER('{{ params.run_type }}') = '{{ params.pollen_filter }}' AND {{ params.emulated_run }} = TRUE THEN '{{ params.emulation_filter }}'
    WHEN LOWER('{{ params.run_type }}') = '{{ params.dtp_filter }}' THEN '{{ params.dtp_filter }}'
    ELSE '{{ params.pollen_filter }}'
END
)
include_query_id = true
header = true;
