REMOVE {{ get_stage('overlapping_campaign_spend_weights') }}/;
COPY INTO {{ get_stage('overlapping_campaign_spend_weights') }}
FROM (
WITH booking_source AS (

    SELECT
        booking_id,
        campaign_id,
        booking_media_budget_amt,
        booking_media_live_start_dt,
        booking_media_live_end_dt,
        booking_status,
        marketing_channel,
        marketing_subchannel,
        channel_type,
        booking_item_cd_list as item_cd_list,
        source_priority
    FROM (
        {% if params.is_prod %}
            -- Prod: campaign_booking_media_channel already resolves to BDV prod for this environment.
            SELECT
                booking_id,
                campaign_id,
                booking_media_budget_amt,
                booking_media_live_start_dt,
                booking_media_live_end_dt,
                booking_status,
                marketing_channel,
                marketing_subchannel,
                channel_type,
                booking_item_cd_list,
                0 AS source_priority
            FROM {{ get_table('campaign_booking_media_channel') }}
            WHERE test_booking_flag != 'Y'
        {% else %}
            -- Dev: the XCom expression is evaluated by the second template pass.
            -- Emulation uses non-test production bookings; normal dev runs prefer
            -- production test bookings and then fall back to development bookings.
            SELECT
                booking_id,
                campaign_id,
                booking_media_budget_amt,
                booking_media_live_start_dt,
                booking_media_live_end_dt,
                booking_status,
                marketing_channel,
                marketing_subchannel,
                channel_type,
                booking_item_cd_list,
                0 AS source_priority
            FROM {{ get_table('campaign_booking_media_channel_prod') }}
            WHERE (
                ({{ params.emulate_prod_env }} AND test_booking_flag != 'Y')
                OR (NOT {{ params.emulate_prod_env }} AND test_booking_flag = 'Y')
            )

            UNION ALL

            SELECT
                booking_id,
                campaign_id,
                booking_media_budget_amt,
                booking_media_live_start_dt,
                booking_media_live_end_dt,
                booking_status,
                marketing_channel,
                marketing_subchannel,
                channel_type,
                booking_item_cd_list,
                1 AS source_priority
            FROM {{ get_table('campaign_booking_media_channel') }}
            WHERE NOT {{ params.emulate_prod_env }}
            AND test_booking_flag != 'Y'
        {% endif %}

    )
    -- Keeps every media/channel row for a booking; only whole bookings are resolved across sources.
    QUALIFY source_priority = MIN(source_priority) OVER (PARTITION BY booking_id)

),
brand_data AS (
    -- We load this from the snowflake stage, since we have already applied all the transformations
    -- we want to apply to the brand data in the item_brand_hist unload.
    -- This avoids having to re-apply those transformations here and read from the dim_item table.
    SELECT
        $1:ITEM_CD::STRING AS item_cd,
        $1:UNIQUE_BRAND_NAME::STRING AS unique_brand_name,
        $1:SUB_CAT_NAME::STRING AS sub_cat_name
    FROM {{ get_stage('item_brand_hist') }}
),
eligible_bookings AS (
    SELECT *
    FROM booking_source t
    WHERE campaign_id != '-1'
        AND booking_status IN ('COMPLETED', 'ACTIVE')
        AND marketing_channel != '-1'
        AND marketing_subchannel != '-1'
        AND channel_type != '-1'
        AND booking_media_live_start_dt IS NOT NULL
        AND booking_media_live_end_dt IS NOT NULL
        -- Align with the same eligibility checks used when loading unified campaigns
        AND NOT EXISTS (
            SELECT 1
            FROM {{ get_table('bookings_blacklist') }} AS b
            WHERE b.booking_id = t.booking_id
               OR b.campaign_id = t.campaign_id
        )
),
product_types AS (
    SELECT column1 AS product_type
    FROM (VALUES {{ params.product_types }})
),

booking_sku_list AS (
    SELECT
        booking_id,
        f.value:skuId::STRING AS item_cd
    FROM eligible_bookings t,
    LATERAL FLATTEN(input => t.item_cd_list) f
),

booking_skus AS (
    SELECT
        a.booking_id,
        a.item_cd,
        pcp.median_proposed_bucket_wk AS sku_post_period
    FROM booking_sku_list a
    LEFT JOIN {{ get_table('post_campaign_period') }} pcp
           ON TRY_TO_NUMBER(a.item_cd) = pcp.item_cd
            -- TODO: Replace this current-year lookup when post-period mapping becomes booking-date aware.
          AND pcp.year_of_transaction = (SELECT YEAR(CURRENT_DATE()) - 1)
),

booking_sub_category_brand AS (
    SELECT
        a.booking_id,
        array_agg(DISTINCT a.item_cd) AS skus,
        array_agg(DISTINCT ibh.sub_cat_name) AS sub_categories,
        array_agg(DISTINCT ibh.unique_brand_name) AS brands,
        MAX(a.sku_post_period) AS max_sku_post_period
    FROM booking_skus a
    LEFT JOIN brand_data AS ibh
        ON a.item_cd = ibh.item_cd
    GROUP BY a.booking_id
),

booking_dates AS (
    SELECT
        booking_id,
        MIN(booking_media_live_start_dt) AS booking_start_date,
        MAX(booking_media_live_end_dt) AS booking_end_date
    FROM eligible_bookings
    GROUP BY booking_id
),

bookings AS (
    SELECT
        a.booking_id,
        a.booking_start_date,
        a.booking_end_date,
        DATEADD('week', COALESCE(b.max_sku_post_period, 6), a.booking_end_date) AS post_campaign_dt,
        b.sub_categories,
        b.brands,
        b.skus
    FROM booking_dates a 
    LEFT JOIN booking_sub_category_brand b ON a.booking_id = b.booking_id
),

-- Brand match plus sub-category (BRAND) or SKU (OFFER) match, over the post-inclusive presence span.
edges AS (
    SELECT DISTINCT
        p.product_type,
        a.booking_id,
        b.booking_id AS overlapping_booking_id
    FROM bookings a
    CROSS JOIN product_types p
    JOIN bookings b ON a.booking_id != b.booking_id
                   AND ARRAY_SIZE(ARRAY_INTERSECTION(a.brands, b.brands)) > 0
                   AND ARRAY_SIZE(ARRAY_INTERSECTION(
                           CASE p.product_type WHEN 'BRAND' THEN a.sub_categories ELSE a.skus END,
                           CASE p.product_type WHEN 'BRAND' THEN b.sub_categories ELSE b.skus END)) > 0
                   AND a.booking_start_date <= b.post_campaign_dt
                   AND b.booking_start_date <= a.post_campaign_dt
    WHERE a.sub_categories IS NOT NULL
),

campaigns AS (
    SELECT
        booking_id,
        campaign_id,
        booking_media_budget_amt AS total_budget,
        booking_media_live_start_dt AS start_date,
        booking_media_live_end_dt AS end_date,
        DATEDIFF('day', booking_media_live_start_dt, booking_media_live_end_dt) + 1 AS campaign_days
    FROM eligible_bookings
),

bounds AS (
    SELECT MIN(c.start_date) AS min_dt,
           MAX(COALESCE(b.post_campaign_dt, c.end_date)) AS max_dt
    FROM campaigns c
    LEFT JOIN bookings b ON b.booking_id = c.booking_id
),

week_spine AS (
    SELECT week_start
    FROM (
        SELECT DATEADD('week', SEQ4(),
                       (SELECT DATE_TRUNC('week', min_dt) FROM bounds)) AS week_start
        FROM TABLE(GENERATOR(ROWCOUNT => 10000))
    )
    WHERE week_start <= (SELECT max_dt FROM bounds)
),

live_presence AS (          -- pro-rata on days live
    SELECT
        c.booking_id,
        w.week_start,
        'During' AS phase,
        SUM(c.total_budget
            * (DATEDIFF('day',
                        GREATEST(c.start_date, w.week_start),
                        LEAST(c.end_date, DATEADD('day', 6, w.week_start))) + 1)
            / NULLIFZERO(c.campaign_days)) AS weekly_presence
    FROM campaigns c
    JOIN week_spine w
      ON w.week_start                     <= c.end_date
     AND DATEADD('day', 6, w.week_start)  >= c.start_date
    GROUP BY booking_id, week_start, phase
),

post_presence AS (          -- live weekly rate x start rate x decay^(weeks since flight end)
    SELECT
        c.booking_id,
        w.week_start,
        'Post' AS phase,
        SUM((c.total_budget * 7.0 / NULLIFZERO(c.campaign_days))
            * {{ params.post_presence_start_rate }}
            * POWER({{ params.post_presence_weekly_decay }},
                    DATEDIFF('week', DATE_TRUNC('week', c.end_date), w.week_start) - 1)
        ) AS weekly_presence
    FROM campaigns c
    JOIN bookings b ON b.booking_id = c.booking_id
    JOIN week_spine w
      ON w.week_start >  DATE_TRUNC('week', c.end_date)
     AND w.week_start <= b.post_campaign_dt
        GROUP BY c.booking_id, week_start, phase
),

weekly_presence AS (
    SELECT booking_id, week_start, phase, SUM(weekly_presence) AS weekly_presence
    FROM (SELECT * FROM live_presence UNION ALL SELECT * FROM post_presence)
    GROUP BY booking_id, week_start, phase
),

weekly_share AS (
    SELECT
        p.product_type,
        w.booking_id,
        w.week_start,
        w.phase,
        w.weekly_presence,
        COALESCE(SUM(o.weekly_presence), 0) AS overlap_presence,
        w.weekly_presence
          / NULLIF(w.weekly_presence + COALESCE(SUM(o.weekly_presence), 0), 0) AS week_share
    FROM weekly_presence w
    CROSS JOIN product_types p                 -- keeps zero-overlap bookings in both product types
    LEFT JOIN edges e
           ON e.booking_id   = w.booking_id
          AND e.product_type = p.product_type
    LEFT JOIN weekly_presence o
           ON o.booking_id = e.overlapping_booking_id
          AND o.week_start = w.week_start      -- co-present in *this* week, not just ever
    GROUP BY p.product_type, w.booking_id, w.week_start, w.phase, w.weekly_presence
),

booking_budget AS (
    SELECT
        booking_id,
        SUM(total_budget) AS campaign_budget,
        SUM(total_budget) / SUM(SUM(total_budget)) OVER () AS share_of_all_spend
    FROM campaigns
    GROUP BY booking_id
),

overlap_counts AS (
    SELECT
        s.product_type,
        s.booking_id,
        s.phase,
        COUNT(DISTINCT e.overlapping_booking_id) AS overlapping_bookings
    FROM weekly_share s
    JOIN edges e
      ON e.booking_id   = s.booking_id
     AND e.product_type = s.product_type
    JOIN weekly_presence o
      ON o.booking_id = e.overlapping_booking_id
     AND o.week_start = s.week_start           -- only count genuinely co-present bookings
    GROUP BY s.product_type, s.booking_id, s.phase
),

booking_share_raw AS (
    SELECT
        booking_id,
        product_type,
        phase AS campaign_duration,
        SUM(weekly_presence * week_share) / NULLIFZERO(SUM(weekly_presence)) AS spend_weight
    FROM weekly_share
    GROUP BY booking_id, product_type, phase
),

booking_share AS (
    SELECT
        booking_id,
        product_type,
        campaign_duration,
        -- Adjust spend weight for BRAND product type to ensure it is at least as large as the maximum spend weight of overlapping OFFER product types
        IFF(product_type = 'BRAND',
            GREATEST(spend_weight,
                     COALESCE(MAX(IFF(product_type = 'OFFER', spend_weight, NULL))
                                  OVER (PARTITION BY booking_id, campaign_duration),
                              spend_weight)),
            spend_weight) AS spend_weight
    FROM booking_share_raw
)
SELECT
    s.booking_id,
    s.product_type,
    s.campaign_duration,
    b.campaign_budget,
    b.share_of_all_spend,
    s.spend_weight,
    COALESCE(oc.overlapping_bookings, 0) AS overlapping_bookings
FROM booking_share s
LEFT JOIN booking_budget b
       ON b.booking_id = s.booking_id
LEFT JOIN overlap_counts oc
       ON oc.booking_id   = s.booking_id
      AND oc.product_type = s.product_type
      AND oc.phase        = s.campaign_duration
)
include_query_id = true
header = true;
