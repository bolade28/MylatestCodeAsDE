MERGE INTO {{ params.target_table }} AS target
USING (
    SELECT
        stg.job_bag_number,
        stg.campaign_id,
        stg.media_spend_amt,
        stg.media_spend_source,
        stg.campaign_start_dt,
        stg.campaign_end_dt,
        stg.subchannel_name,
        stg.item_cd_list,
        stg.super_category_name,
        stg.sub_category_name,
        stg.channel_name,
        stg.campaign_name,
        stg.booking_id,
        stg.campaign_status,
        stg.is_multi_channel,
        COALESCE(
            (
                SELECT MAX(t.load_ts)
                FROM {{ params.target_table }} AS t
                WHERE t.job_run_id = '{{ params.correlation_id }}'
            ),
            stg.load_ts
        ) AS load_ts,
        stg.job_run_id,
        stg.marketing_type,
        stg.unique_brand_name,
        stg.partner_id,
        stg.advertiser_id,
        stg.advertiser_name,
        stg.post_campaign_dt,
        stg.marketing_hierarchy_cd
    FROM {{ params.source_table }} AS stg
    WHERE stg.job_run_id = '{{ params.correlation_id }}'
) AS source
ON target.job_bag_number = source.job_bag_number
   AND target.campaign_id = source.campaign_id
   AND target.channel_name = source.channel_name
   AND target.subchannel_name = source.subchannel_name
   AND target.job_run_id = source.job_run_id
WHEN MATCHED THEN UPDATE SET
    job_bag_number         = source.job_bag_number,
    media_spend_amt        = source.media_spend_amt,
    media_spend_source     = source.media_spend_source,
    campaign_start_dt      = source.campaign_start_dt,
    campaign_end_dt        = source.campaign_end_dt,
    subchannel_name        = source.subchannel_name,
    item_cd_list           = source.item_cd_list,
    super_category_name    = source.super_category_name,
    sub_category_name      = source.sub_category_name,
    channel_name           = source.channel_name,
    campaign_name          = source.campaign_name,
    booking_id             = source.booking_id,
    campaign_status        = source.campaign_status,
    is_multi_channel       = source.is_multi_channel,
    job_run_id             = source.job_run_id,
    marketing_type         = source.marketing_type,
    unique_brand_name      = source.unique_brand_name,
    partner_id             = source.partner_id,
    advertiser_id          = source.advertiser_id,
    advertiser_name        = source.advertiser_name,
    post_campaign_dt       = source.post_campaign_dt,
    marketing_hierarchy_cd = source.marketing_hierarchy_cd
WHEN NOT MATCHED THEN INSERT (
    job_bag_number,
    campaign_id,
    media_spend_amt,
    media_spend_source,
    campaign_start_dt,
    campaign_end_dt,
    subchannel_name,
    item_cd_list,
    super_category_name,
    sub_category_name,
    channel_name,
    campaign_name,
    booking_id,
    campaign_status,
    is_multi_channel,
    load_ts,
    job_run_id,
    marketing_type,
    unique_brand_name,
    partner_id,
    advertiser_id,
    advertiser_name,
    post_campaign_dt,
    marketing_hierarchy_cd
) VALUES (
    source.job_bag_number,
    source.campaign_id,
    source.media_spend_amt,
    source.media_spend_source,
    source.campaign_start_dt,
    source.campaign_end_dt,
    source.subchannel_name,
    source.item_cd_list,
    source.super_category_name,
    source.sub_category_name,
    source.channel_name,
    source.campaign_name,
    source.booking_id,
    source.campaign_status,
    source.is_multi_channel,
    source.load_ts,
    source.job_run_id,
    source.marketing_type,
    source.unique_brand_name,
    source.partner_id,
    source.advertiser_id,
    source.advertiser_name,
    source.post_campaign_dt,
    source.marketing_hierarchy_cd
)
;