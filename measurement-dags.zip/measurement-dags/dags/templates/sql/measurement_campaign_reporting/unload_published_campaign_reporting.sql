/*
Builds the published campaign reporting table, which is used by the fallback mechanism when Incrementality is greater than  Attributed 

This template:
- Finds approved (proxy for published) campaigns, that were not marked as fallback
- Filters out campaigns that were loaded after the campaign end date
- Calculates overall ratio of incremental to attributed sales for each published campaign at the booking level


Output table:
- {{ get_stage('published_campaign_reporting') }}
*/


REMOVE {{ get_stage('published_campaign_reporting') }}/;
COPY INTO {{ get_stage('published_campaign_reporting') }}

FROM (
    with

    measurement_metadata_run as (
        select booking_id, evaluation_period, max(end_time) as end_time
        from {{ get_table('measurement_metadata_prod') }}
        group by booking_id, evaluation_period
    ),

    measurement_metadata as (
        select 
            distinct 
                booking_id, 
                campaign_end_date, 
                initcap(evaluation_period) as campaign_duration, 
                run_date, 
                PARSE_JSON(additional_metadata):is_fallback::boolean as is_fallback
        from {{ get_table('measurement_metadata_prod') }} as metadata 
        inner join measurement_metadata_run
        using(booking_id, evaluation_period, end_time)
    ),


    approved_bookings as (
        select distinct
            booking_id, 
            reporting_status, 
            campaign_duration
        from 
            {{ get_table('measurement_reporting_booking_ref_prod') }} 
        where reporting_status = 'APPROVED'
        and booking_id not in (
            select booking_id 
            from measurement_metadata
            where is_fallback = True
        )
    ), 

    campaign_reporting_latest as (
        select 
            campaign_id, 
            booking_id, 
            campaign_duration,
            journey_type,
            max(load_ts) as load_ts
        from {{ get_table('measurement_campaign_reporting_aws_prod') }}
        group by campaign_id, booking_id, campaign_duration, journey_type
    ),

    measurement_campaign_reporting as (
        select 
            booking_id, 
            initcap(campaign_duration) as campaign_duration,
            initcap(journey_type) as journey_type,
            upper(marketing_type) as marketing_type,
            sum(ATTRIBUTED_RECALIBRATED_SALES_AMT) as total_attributed,
            sum(INCREMENTAL_SALES_AMT_EXPOSED) as total_incremental, 
            div0(total_incremental, total_attributed) as incremental_attributed_ratio
        from {{ get_table('measurement_campaign_reporting_aws_prod') }} mcr
        inner join campaign_reporting_latest
        using (campaign_id, booking_id, campaign_duration, load_ts) 
        where upper(mcr.campaign_duration) in ('DURING', 'POST')
        group by booking_id, campaign_duration, journey_type, marketing_type
        having max(load_ts) < '{{ params.end_date }}'
    ), 

    final_published_campaigns as (
        select 
            mcr.booking_id, 
            metadata.campaign_end_date,
            mcr.campaign_duration, 
            mcr.journey_type,
            mcr.marketing_type,
            mcr.total_attributed, 
            mcr.total_incremental,
            mcr.incremental_attributed_ratio
        from measurement_campaign_reporting mcr
        inner join measurement_metadata metadata
        using (booking_id, campaign_duration)
        inner join approved_bookings 
        using (booking_id, campaign_duration)
    )

    select  
        CAST(UPPER(booking_id) AS VARCHAR(50)) as job_bag_number, 
        CAST(campaign_end_date AS DATE) as campaign_end_dt, 
        CAST(campaign_duration AS VARCHAR(50)) as campaign_duration, 
        CAST(journey_type AS VARCHAR(50)) as product_type,
        CAST(marketing_type AS VARCHAR(50)) as marketing_type,
        CAST(total_attributed AS NUMBER(18,6)) as attributed_recalibrated_sales_amt, 
        CAST(total_incremental AS NUMBER(18,6)) as incremental_sales_amt_exposed,
        CAST(incremental_attributed_ratio AS NUMBER(18,6)) as incremental_attributed_ratio, 
        CAST('{{ params.correlation_id }}' AS VARCHAR(36)) AS correlation_id,
        CAST(CURRENT_TIMESTAMP AS TIMESTAMP_NTZ) AS load_ts
    from final_published_campaigns
)

include_query_id = true
header = true; 
