UPDATE {{ get_table('measurement_booking_tracker') }}
SET
    status = '{{ params.status }}',
    load_ts = CURRENT_TIMESTAMP()
WHERE booking_id = '{{ params.booking_id }}'
  AND UPPER(pipeline_stage) = UPPER('{{ params.pipeline_stage }}');
