REMOVE {{ get_stage('processed_fact_sales_transaction_item') }}/;
COPY INTO {{ get_stage('processed_fact_sales_transaction_item') }}
FROM(
    WITH media_campaign_list AS (
    SELECT trim(table1.value) AS campaign_id
        FROM TABLE(SPLIT_TO_TABLE(
            CASE WHEN NOT(REPLACE('{{params.campaign_id_manual}}','[]','') = '') THEN REPLACE('{{params.campaign_id_manual}}','"','')
             ELSE '{{params.campaign_id_default}}' END ,',')) AS table1
),
     sub_categories_initial AS (
        SELECT DISTINCT sub_category_name AS sub_cat_name
        FROM {{ get_table('measurement_unified_campaign') }}
        INNER JOIN media_campaign_list mcl 
        ON job_bag_number = mcl.campaign_id
        UNION 
        SELECT DISTINCT sub_category_name AS sub_cat_name
        FROM {{ get_table('measurement_unified_campaign_pollen') }}
        JOIN media_campaign_list mcl 
        ON job_bag_number = mcl.campaign_id

    )
    , sub_categories AS (
        SELECT DISTINCT value AS sub_cat_name FROM sub_categories_initial , LATERAL SPLIT_TO_TABLE(sub_categories_initial.sub_cat_name, ',')
     )
    -- Extract the latest item details for each item as of the brand reference date.
    , item_details AS (
        SELECT
            item_cd,
            sub_cat_name
        FROM {{ get_table('dim_item_hist') }}
        WHERE valid_from_dt <= '{{ params.brand_time_reference }}'
            AND valid_until_dt >= '{{ params.brand_time_reference }}'
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY item_cd
            ORDER BY load_ts DESC
        ) = 1
    )
-- Retrieve Transaction Data from FACT_SALE_TRANSACTION_ITEM. Business Context - Tagging Item Sales and Item Returns separately using filters. Also Filtering transactions between select dates
    select
        i.transaction_id,
        i.transaction_dt,
        i.net_retail_sales_amt,
        i.pre_promotional_sale_amt,
        i.item_cd,
        i.store_cd,
        i.uom_cd,
        i.item_qty,
        i.item_type_sale_or_return,
        i.base_unit_price_amt
    from {{ get_table('fact_sale_transaction_item') }} i
    INNER JOIN item_details di ON i.item_cd = di.item_cd
    INNER JOIN sub_categories ON
    lower(sub_categories.sub_cat_name) = lower(di.sub_cat_name)
    where transaction_dt >= '{{ params.start_date }}' AND transaction_dt <= '{{ params.end_date }}'
        )
include_query_id = true
header = true;
