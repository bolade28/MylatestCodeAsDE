REMOVE {{ get_stage('processed_fact_sales_transaction_basket') }}/;
COPY INTO {{ get_stage('processed_fact_sales_transaction_basket') }}
FROM (
  SELECT
    sales_origination_channel_cd,
    transaction_id,
    transaction_dt,
    nectar_card_num_hash,
    transaction_end_ts
  FROM {{ get_table('fact_sale_transaction_basket') }}
)
include_query_id = true
header = true;