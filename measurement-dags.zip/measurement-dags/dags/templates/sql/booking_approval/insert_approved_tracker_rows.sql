MERGE INTO {{ params.tracker_table }} AS target
USING (
    {{ params.rows_sql }}
) AS src
ON target.booking_id = src.booking_id
AND UPPER(target.pipeline_stage) = UPPER(src.pipeline_stage)
WHEN MATCHED AND UPPER(target.status) = 'PENDING' THEN UPDATE SET
    target.status = '{{ params.booking_status }}',
    target.load_ts = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT (
    booking_id,
    campaign_name,
    pipeline_stage,
    status,
    qa_passed,
    last_run_correlation_id,
    run_count,
    created_at,
    load_ts
)
VALUES (
    src.booking_id,
    src.campaign_name,
    src.pipeline_stage,
    '{{ params.booking_status }}',
    TRUE,
    '',
    NULL,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP()
);
