WITH requested_bookings AS (
    SELECT
        booking_id,
        booking_name,
        booking_media_live_start_dt,
        booking_media_live_end_dt,
        booking_media_budget_amt,
        cumulative_billable_spend_amt,
        booking_status,
        campaign_id,
        channel_type,
        booking_item_cd_list,
        marketing_hierarchy_cd,
        marketing_subchannel,
        media_name,
        multi_brand_flag,
        store_cd_list,
        test_booking_flag
    FROM {{ params.booking_source_table }}
    WHERE booking_id IN ({{ params.booking_ids_sql }})
),
unified_campaign_latest AS (
    SELECT
        job_bag_number,
        MAX(campaign_name) AS campaign_name,
        MIN(campaign_start_dt) AS campaign_start_dt,
        MAX(campaign_end_dt) AS campaign_end_dt
    FROM {{ params.pollen_table }} AS pollen
    WHERE job_bag_number IN ({{ params.booking_ids_sql }})
      AND load_ts = (
          SELECT MAX(latest.load_ts)
          FROM {{ params.pollen_table }} AS latest
          WHERE latest.job_bag_number = pollen.job_bag_number
      )
    GROUP BY job_bag_number
),
booking_metadata AS (
    SELECT
        booking_id,
        MAX(booking_name) AS campaign_name,
        MIN(booking_media_live_start_dt) AS media_start_dt,
        MAX(booking_media_live_end_dt) AS media_end_dt
    FROM requested_bookings
    GROUP BY booking_id
),
booking_context AS (
    SELECT
        metadata.booking_id,
        COALESCE(unified.campaign_name, metadata.campaign_name, metadata.booking_id) AS campaign_name,
        metadata.media_start_dt,
        metadata.media_end_dt,
        unified.job_bag_number AS pollen_job_bag_number,
        unified.campaign_start_dt,
        unified.campaign_end_dt
    FROM booking_metadata AS metadata
    LEFT JOIN unified_campaign_latest AS unified
        ON metadata.booking_id = unified.job_bag_number
),
-- Check 01: Require store codes for INSTORE non-coupon media; skip bookings without those records.
check_01_store_cd_list AS (
    SELECT
        booking_id,
        '01 · INSTORE Store CD List Populated' AS check_category,
        CASE
            WHEN COALESCE(COUNT_IF(
                UPPER(channel_type) = '{{ params.instore_channel_type }}'
                AND media_name NOT ILIKE 'coupon%'
            ), 0) = 0 THEN 'SKIPPED'
            WHEN COUNT_IF(
                UPPER(channel_type) = '{{ params.instore_channel_type }}'
                AND media_name NOT ILIKE 'coupon%'
                AND (store_cd_list IS NULL OR ARRAY_SIZE(store_cd_list) = 0)
            ) > 0 THEN 'FAIL'
            ELSE 'PASS'
        END AS check_status,
        CASE
            WHEN COALESCE(COUNT_IF(
                UPPER(channel_type) = '{{ params.instore_channel_type }}'
                AND media_name NOT ILIKE 'coupon%'
            ), 0) = 0 THEN 'SKIPPED — No INSTORE, non-coupon records found.'
            WHEN COUNT_IF(
                UPPER(channel_type) = '{{ params.instore_channel_type }}'
                AND media_name NOT ILIKE 'coupon%'
                AND (store_cd_list IS NULL OR ARRAY_SIZE(store_cd_list) = 0)
            ) > 0 THEN 'FAIL — STORE_CD_LIST is missing for some INSTORE non-coupon records.'
            ELSE 'PASS — All INSTORE, non-coupon records have a populated STORE_CD_LIST.'
        END AS check_reason
    FROM requested_bookings
    GROUP BY booking_id
),
-- Check 02: Reject bookings containing a null or -1 campaign ID.
check_02_campaign_id AS (
    SELECT
        booking_id,
        '02_campaign_id' AS check_category,
        IFF(COUNT_IF(campaign_id IS NULL OR campaign_id = '-1') > 0, 'FAIL', 'PASS') AS check_status,
        IFF(
            COUNT_IF(campaign_id IS NULL OR campaign_id = '-1') > 0,
            'FAIL — CAMPAIGN_ID is null or -1.',
            'PASS — CAMPAIGN_ID populated and valid on all records.'
        ) AS check_reason
    FROM requested_bookings
    GROUP BY booking_id
),
-- Check 03: Reject bookings flagged as test bookings.
check_03_test_booking AS (
    SELECT
        booking_id,
        '03_test_booking' AS check_category,
        IFF(COUNT_IF(UPPER(test_booking_flag) = 'Y') > 0, 'FAIL', 'PASS') AS check_status,
        IFF(
            COUNT_IF(UPPER(test_booking_flag) = 'Y') > 0,
            'FAIL — Booking is flagged as a test booking.',
            'PASS — Not flagged as a test booking.'
        ) AS check_reason
    FROM requested_bookings
    GROUP BY booking_id
),
-- Check 04: Reject bookings where a campaign ID occurs on multiple BDV rows.
campaign_counts AS (
    SELECT booking_id, campaign_id, COUNT(*) AS campaign_count
    FROM requested_bookings
    WHERE campaign_id <> '-1'
    GROUP BY booking_id, campaign_id
),
check_04_duplicate_campaign_id AS (
    SELECT
        metadata.booking_id,
        '04_duplicate_campaign_id' AS check_category,
        IFF(COUNT_IF(counts.campaign_count > 1) > 0, 'FAIL', 'PASS') AS check_status,
        IFF(
            COUNT_IF(counts.campaign_count > 1) > 0,
            'FAIL — Duplicate CAMPAIGN_ID values found within booking.',
            'PASS — No duplicate CAMPAIGN_ID values in this booking.'
        ) AS check_reason
    FROM booking_metadata AS metadata
    LEFT JOIN campaign_counts AS counts ON metadata.booking_id = counts.booking_id
    GROUP BY metadata.booking_id
),
-- Check 05: Reject bookings marked as multi-brand.
check_05_multi_brand AS (
    SELECT
        booking_id,
        '05_multi_brand' AS check_category,
        IFF(COUNT_IF(UPPER(multi_brand_flag) = 'Y') > 0, 'FAIL', 'PASS') AS check_status,
        IFF(
            COUNT_IF(UPPER(multi_brand_flag) = 'Y') > 0,
            'FAIL — Booking is multi-brand.',
            'PASS — Single-brand booking.'
        ) AS check_reason
    FROM requested_bookings
    GROUP BY booking_id
),
-- Check 06: Reject item lists that are empty or contain an item without a skuId.
check_06_booking_item_cd_list AS (
    SELECT
        br.booking_id,
        '06_booking_item_cd_list' AS check_category,
        IFF(
            COUNT_IF(ARRAY_SIZE(br.booking_item_cd_list) = 0 OR item.value:skuId IS NULL) > 0,
            'FAIL',
            'PASS'
        ) AS check_status,
        IFF(
            COUNT_IF(ARRAY_SIZE(br.booking_item_cd_list) = 0 OR item.value:skuId IS NULL) > 0,
            'FAIL — ITEM_CD_LIST is empty or contains a missing skuId.',
            'PASS — ITEM_CD_LIST available in at least one source.'
        ) AS check_reason
    FROM requested_bookings AS br,
    LATERAL FLATTEN(input => br.booking_item_cd_list, OUTER => TRUE) AS item
    GROUP BY br.booking_id
),
-- Check 07: Reject null/zero media budget, or null/zero cumulative billable spend for non-INSTORE channels.
check_07_budget AS (
    SELECT
        booking_id,
        '07_booking_media_budget' AS check_category,
        CASE
            WHEN channel_type <> '{{ params.instore_channel_type }}'
             AND COUNT_IF(cumulative_billable_spend_amt IS NULL OR cumulative_billable_spend_amt = 0) > 0 THEN 'FAIL'
            WHEN COUNT_IF(booking_media_budget_amt IS NULL OR booking_media_budget_amt = 0) > 0 THEN 'FAIL'
            ELSE 'PASS'
        END AS check_status,
        CASE
            WHEN COUNT_IF(booking_media_budget_amt IS NULL OR booking_media_budget_amt = 0) > 0
                THEN 'FAIL — BOOKING_MEDIA_BUDGET_AMT is null or 0 for: ' || LISTAGG(DISTINCT campaign_id, ' | ')
            WHEN channel_type <> '{{ params.instore_channel_type }}'
             AND COUNT_IF(cumulative_billable_spend_amt IS NULL OR cumulative_billable_spend_amt = 0) > 0
                THEN 'FAIL — CUMULATIVE_BILLABLE_SPEND_AMT is null or 0 for: ' || LISTAGG(DISTINCT campaign_id, ' | ')
            ELSE 'PASS — BOOKING_MEDIA_BUDGET_AMT populated on all records.'
        END AS check_reason
    FROM requested_bookings
    GROUP BY booking_id, channel_type
),
-- Check 08: Compare BDV media dates with the latest Pollen campaign dates; warn if no Pollen row exists.
check_08_dates_align AS (
    SELECT
        context.booking_id,
        '08_dates_align_to_unified_campaign' AS check_category,
        CASE
            WHEN context.pollen_job_bag_number IS NULL THEN 'WARNING'
            WHEN context.media_start_dt = context.campaign_start_dt
             AND context.media_end_dt = context.campaign_end_dt THEN 'PASS'
            ELSE 'FAIL'
        END AS check_status,
        CASE
            WHEN context.pollen_job_bag_number IS NULL THEN 'WARNING — No matching JOB_BAG_NUMBER found in unified_campaign_pollen for this booking.'
            WHEN context.media_start_dt = context.campaign_start_dt
             AND context.media_end_dt = context.campaign_end_dt THEN 'PASS — BOOKING_MEDIA_LIVE dates match Unified Campaign dates.'
            ELSE 'FAIL — Booking media dates do not match Unified Campaign dates.'
        END AS check_reason
    FROM booking_context AS context
),
-- Check 09: Reject matched hierarchy entries marked out of scope or not measurement-ready.
check_09_in_scope AS (
    SELECT
        metadata.booking_id,
        '09_marketing_subchannel_in_scope' AS check_category,
        IFF(COUNT(violations.booking_id) > 0, 'FAIL', 'PASS') AS check_status,
        IFF(
            COUNT(violations.booking_id) > 0,
            'FAIL — MARKETING_SUBCHANNEL is not in scope or measurement-ready.',
            'PASS — All MARKETING_SUBCHANNEL values are in scope and measurement-ready.'
        ) AS check_reason
    FROM booking_metadata AS metadata
    LEFT JOIN (
        SELECT DISTINCT br.booking_id
        FROM requested_bookings AS br
        INNER JOIN {{ params.hierarchy_table }} AS hierarchy
            ON br.marketing_subchannel = hierarchy.marketing_subchannel
            AND br.marketing_hierarchy_cd = hierarchy.marketing_hierarchy_cd
        WHERE hierarchy.in_scope_flag = FALSE
           OR hierarchy.measurement_campaign_ready = FALSE
    ) AS violations ON metadata.booking_id = violations.booking_id
    GROUP BY metadata.booking_id
),
-- Check 10: Allow only COMPLETED or ACTIVE booking statuses.
check_10_booking_status AS (
    SELECT
        booking_id,
        '10_booking_status' AS check_category,
        IFF(
            COUNT_IF(booking_status IS NULL OR UPPER(booking_status) NOT IN ('COMPLETED', 'ACTIVE')) > 0,
            'FAIL',
            'PASS'
        ) AS check_status,
        IFF(
            COUNT_IF(booking_status IS NULL OR UPPER(booking_status) NOT IN ('COMPLETED', 'ACTIVE')) > 0,
            'FAIL — BOOKING_STATUS is not COMPLETED or ACTIVE.',
            'PASS — All BOOKING_STATUS values are valid.'
        ) AS check_reason
    FROM requested_bookings
    GROUP BY booking_id
),
-- Check 11: Allow repeat runs outside PROD; in PROD reject an existing row for the selected duration.
check_11_first_production_run AS (
    SELECT
        metadata.booking_id,
        '11_first_production_run' AS check_category,
        CASE
            WHEN LOWER('{{ params.environment }}') != 'prod' THEN 'PASS'
            WHEN COUNT_IF(reporting.booking_id IS NULL) > 0 THEN 'PASS'
            ELSE 'FAIL'
        END AS check_status,
        CASE
            WHEN LOWER('{{ params.environment }}') != 'prod' THEN 'PASS — This is a non-prod environment, multiple runs allowed.'
            WHEN COUNT_IF(reporting.booking_id IS NULL) > 0 THEN 'PASS — This is the first time this BOOKING_ID is being run.'
            ELSE 'FAIL — A reporting run already exists for this booking and selected duration.'
        END AS check_reason
    FROM booking_metadata AS metadata
    LEFT JOIN {{ params.reporting_table }} AS reporting
        ON metadata.booking_id = reporting.booking_id
        AND UPPER(reporting.campaign_duration) = UPPER('{{ params.campaign_duration }}')
    GROUP BY metadata.booking_id
),
-- Check 12: Skip emulated runs; otherwise reject when the latest During reporting load is more than 20 days old.
check_12_emulated_post_extract AS (
    SELECT
        metadata.booking_id,
        '12_emulated_post_extract_age' AS check_category,
        CASE
            WHEN NOT {{ params.emulation_run | lower }} THEN 'SKIPPED'
            WHEN UPPER('{{ params.campaign_duration }}') != 'POST' THEN 'SKIPPED'
            WHEN latest_run.load_ts IS NULL THEN 'SKIPPED'
            WHEN DATEDIFF('DAY', latest_run.load_ts, CURRENT_DATE()) > 20 THEN 'FAIL'
            ELSE 'PASS'
        END AS check_status,
        CASE
            WHEN NOT {{ params.emulation_run | lower }} THEN 'SKIPPED — Not applicable outside emulated runs.'
            WHEN UPPER('{{ params.campaign_duration }}') != 'POST' THEN 'SKIPPED — This check applies only to emulated Post runs.'
            WHEN latest_run.load_ts IS NULL THEN 'SKIPPED — No During reporting extract found.'
            WHEN DATEDIFF('DAY', latest_run.load_ts, CURRENT_DATE()) > 20 THEN 'FAIL — s3_extract is over 20 days.'
            ELSE 'PASS, Successfully processed.'
        END AS check_reason
    FROM booking_metadata AS metadata
    LEFT JOIN (
        SELECT booking_id, MAX(load_ts) AS load_ts
        FROM {{ params.reporting_table }}
        WHERE UPPER(campaign_duration) = 'DURING'
        GROUP BY booking_id
    ) AS latest_run ON metadata.booking_id = latest_run.booking_id
),
-- Check 13: Detect overlapping campaigns (same SKU, overlapping media dates, different booking).
-- TODO: This is not a production ready check as OVERLAPPING logic is adapting
check_13_overlapping_campaigns AS (
    WITH all_bookings_for_overlap AS (
        SELECT DISTINCT
            booking_id,
            booking_media_live_start_dt,
            booking_media_live_end_dt,
            booking_item_cd_list,
            test_booking_flag,
            multi_brand_flag
        FROM {{ params.booking_source_table }} AS bdv,
        LATERAL FLATTEN(input => bdv.unique_brand_list) AS brand
        WHERE multi_brand_flag = 'N'
          AND test_booking_flag = 'N'
          AND booking_item_cd_list IS NOT NULL
    ),
    exploded_skus AS (
        SELECT
            b.booking_id,
            b.booking_media_live_start_dt AS start_date,
            b.booking_media_live_end_dt AS end_date,
            item.value:skuId::STRING AS sku_cd
        FROM all_bookings_for_overlap AS b,
        LATERAL FLATTEN(input => b.booking_item_cd_list, OUTER => TRUE) AS item
        WHERE item.value:skuId IS NOT NULL
    ),
    sku_overlap AS (
        SELECT DISTINCT
            a.booking_id AS booking_a,
            b.booking_id AS booking_b,
            a.sku_cd,
            a.start_date AS start_a,
            a.end_date AS end_a,
            b.start_date AS start_b,
            b.end_date AS end_b
        FROM exploded_skus AS a
        INNER JOIN exploded_skus AS b
            ON a.sku_cd = b.sku_cd
            AND a.booking_id < b.booking_id  -- avoid duplicate pairs
            AND a.start_date <= b.end_date   -- date range intersection
            AND b.start_date <= a.end_date
    ),
    target_bookings AS (
        SELECT DISTINCT booking_id
        FROM requested_bookings
    ),
    overlaps_for_target AS (
        SELECT DISTINCT
            t.booking_id,
            so.booking_a,
            so.booking_b
        FROM target_bookings AS t
        INNER JOIN sku_overlap AS so
            ON (t.booking_id = so.booking_a OR t.booking_id = so.booking_b)
    )
    SELECT
        t.booking_id,
        '13_overlapping_campaigns' AS check_category,
        CASE
            WHEN COUNT(oft.booking_a) > 0 THEN 'FAIL'
            ELSE 'PASS'
        END AS check_status,
        CASE
            WHEN COUNT(oft.booking_a) > 0 THEN 
                'FAIL — Booking overlaps with: ' || LISTAGG(
                    CASE 
                        WHEN oft.booking_a = t.booking_id THEN oft.booking_b
                        ELSE oft.booking_a
                    END, ', '
                ) WITHIN GROUP (ORDER BY 1)
            ELSE 'PASS — No overlapping bookings detected.'
        END AS check_reason
    FROM target_bookings AS t
    LEFT JOIN overlaps_for_target AS oft
        ON t.booking_id = oft.booking_id
    GROUP BY t.booking_id
),
check_results AS (
    SELECT * FROM check_01_store_cd_list
    UNION ALL SELECT * FROM check_02_campaign_id
    UNION ALL SELECT * FROM check_03_test_booking
    UNION ALL SELECT * FROM check_04_duplicate_campaign_id
    UNION ALL SELECT * FROM check_05_multi_brand
    UNION ALL SELECT * FROM check_06_booking_item_cd_list
    UNION ALL SELECT * FROM check_07_budget
    UNION ALL SELECT * FROM check_08_dates_align
    UNION ALL SELECT * FROM check_09_in_scope
    UNION ALL SELECT * FROM check_10_booking_status
    UNION ALL SELECT * FROM check_11_first_production_run
    UNION ALL SELECT * FROM check_12_emulated_post_extract
    UNION ALL SELECT * FROM check_13_overlapping_campaigns
)
SELECT
    checks.booking_id,
    context.campaign_name,
    context.campaign_end_dt,
    checks.check_category AS category,
    checks.check_status AS status,
    checks.check_reason AS reason,
    context.media_end_dt,
    DATEDIFF('DAY', CURRENT_DATE(), context.media_end_dt) AS days_to_media_end,
    IFF(SUM(IFF(checks.check_status = 'FAIL', 1, 0)) OVER (PARTITION BY checks.booking_id) > 0, 'No 🚫', 'Yes 👍') AS is_okay_to_run
FROM check_results AS checks
INNER JOIN booking_context AS context ON checks.booking_id = context.booking_id
ORDER BY checks.booking_id, checks.check_category;
