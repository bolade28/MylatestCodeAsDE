WITH manual_campaign_list AS (
    SELECT trim(table1.value) AS campaign_id
    FROM TABLE(SPLIT_TO_TABLE(
        CASE WHEN NOT(REPLACE('{{params.campaign_id_manual}}','[]','') = '') THEN '{{params.campaign_id_manual}}'
             ELSE '{{params.campaign_id_default}}' END, ','
    )) AS table1
),
-- Extract booking_id/sku_id pairs from campaign_booking_media_channel for the selected campaigns
selected_booking_skus AS (
    SELECT DISTINCT
        bdv.booking_id,
        json_extract_path_text(sku_list.value, 'skuId')::VARCHAR AS sku_id
    FROM {{ get_table('campaign_booking_media_channel') }} AS bdv,
         LATERAL FLATTEN(input => bdv.booking_item_cd_list) AS sku_list
    WHERE bdv.booking_id IN (SELECT campaign_id FROM manual_campaign_list)
      AND bdv.booking_item_cd_list IS NOT NULL
),
-- Identify booking/sku combinations where the SKU is missing from DIM_ITEM
missing_dim_item_skus AS (
    SELECT
        sbs.booking_id,
        sbs.sku_id
    FROM selected_booking_skus AS sbs
    LEFT JOIN {{ get_table('dim_item') }} AS di
        ON TO_VARCHAR(di.item_cd) = TO_VARCHAR(sbs.sku_id)
    WHERE sbs.sku_id IS NOT NULL
      AND di.item_cd IS NULL
)
-- Final selection: return missing SKU records in a stable order for alerting
SELECT
    booking_id,
    sku_id
FROM missing_dim_item_skus
ORDER BY booking_id, sku_id;
