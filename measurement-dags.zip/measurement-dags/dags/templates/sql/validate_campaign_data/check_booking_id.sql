-- list campaign_id from manual or default params
WITH manual_campaign_list AS (
    SELECT trim(table1.value) AS campaign_id
    FROM TABLE(SPLIT_TO_TABLE(
        CASE WHEN NOT(REPLACE('{{params.campaign_id_manual}}','[]','') = '') THEN '{{params.campaign_id_manual}}'
             ELSE '{{params.campaign_id_default}}' END ,',')) AS table1
),
-- Get all distinct booking ids from DTP unified campaign for current date
unified_dtp AS (
        SELECT DISTINCT job_bag_number
        FROM {{ get_table('measurement_unified_campaign') }} aal
            WHERE job_bag_number IS NOT NULL
                AND CAST(load_ts AS DATE) = CURRENT_DATE()
),
-- Get all distinct booking ids from Pollen unified campaign for current date
unified_pollen AS (
    SELECT DISTINCT job_bag_number
    FROM {{ get_table('measurement_unified_campaign_pollen') }} AS aal
        WHERE job_bag_number IS NOT NULL
            AND CAST(load_ts AS DATE) = CURRENT_DATE()
),
-- Combine DTP and Pollen unified campaign booking ids into a single list with source information
unified AS (
  SELECT job_bag_number, '{{ params.dtp_run | lower }}' AS src FROM unified_dtp
  UNION ALL
  SELECT job_bag_number, '{{ params.pollen_run | lower }}' AS src FROM unified_pollen
)
SELECT
  mcl.campaign_id,
  CASE WHEN u.job_bag_number IS NOT NULL THEN TRUE ELSE FALSE END AS exist
FROM manual_campaign_list mcl
LEFT JOIN unified u
  ON mcl.campaign_id = u.job_bag_number
  AND LOWER(u.src) = LOWER('{{ params.run_type }}');
