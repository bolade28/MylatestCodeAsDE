-- Check for multi-brand campaigns in the provided booking

WITH manual_campaign_list AS (
    SELECT trim(table1.value) AS campaign_id
    FROM TABLE(SPLIT_TO_TABLE(
        CASE WHEN NOT(REPLACE('{{params.campaign_id_manual}}','[]','') = '') THEN '{{params.campaign_id_manual}}'
             ELSE '{{params.campaign_id_default}}' END ,',')) AS table1
),
-- Get booking data from CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR
booking_campaigns AS (
    SELECT
        cbd.booking_id,
        cbd.booking_item_cd_list AS item_cd_list
    FROM {{ get_table('campaign_booking_media_channel') }} cbd
    WHERE cbd.booking_id IN (SELECT campaign_id FROM manual_campaign_list)
      AND LOWER(cbd.booking_status) IN ('completed', 'active')
      AND cbd.booking_item_cd_list IS NOT NULL
),
resolved_item_brands AS (
    SELECT
                item_cd,
                unique_brand_name
        FROM {{ get_table('item_brand_hist') }}
        WHERE COALESCE(technical_metadata:record_deleted_flag::VARCHAR, 'N') = 'N'
            AND NULLIF(TRIM(unique_brand_name), '') IS NOT NULL
            AND valid_from_dt <= '{{ params.brand_time_reference }}'
            AND valid_until_dt >= '{{ params.brand_time_reference }}'
    QUALIFY ROW_NUMBER() OVER (
                PARTITION BY item_cd
                ORDER BY load_ts DESC, valid_from_dt DESC, valid_until_dt DESC
    ) = 1
),
-- Explode items and join to brand data using item_brand_hist
item_brands AS (
    SELECT
        bc.booking_id,
        rib.unique_brand_name
    FROM booking_campaigns bc
    CROSS JOIN LATERAL FLATTEN(input => bc.item_cd_list) AS sku_list
    LEFT JOIN resolved_item_brands AS rib
        ON json_extract_path_text(sku_list.value, 'skuId')::INTEGER = rib.item_cd
),
-- Count distinct brands per campaign
brand_counts AS (
    SELECT
        booking_id,
        COUNT(DISTINCT unique_brand_name) AS brand_count
    FROM item_brands
    WHERE unique_brand_name IS NOT NULL
    GROUP BY booking_id
)
SELECT
    booking_id,
    brand_count,
    CASE WHEN brand_count > 1 THEN TRUE ELSE FALSE END AS is_multi_brand
FROM brand_counts
ORDER BY booking_id;
