from datetime import datetime
from airflow.sdk import dag
from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import get_stage, get_table, resolve_pipelines_version
from task_groups import baseline_setup
from task_groups import ad_hoc_tasks


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule=None,
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
        "resolve_pipelines_version": resolve_pipelines_version,
    }
)
def ad_hoc_dag():
    """
    Measurement ad-hoc DAG
    This is an ad-hoc DAG for running one-off tasks.
    """

    setup = baseline_setup.task_group()

    run_ad_hoc_stuff = ad_hoc_tasks.task_group()
    setup >> run_ad_hoc_stuff


ad_hoc_dag()
