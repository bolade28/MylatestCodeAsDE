import re
import json
from pathlib import Path
from dataclasses import dataclass

from airflow.sdk import task
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from js_snowflake.hooks.snowflake import SnowflakeKeyArnHook as SnowflakeHook

from helpers.aws import split_s3_path, parquet_files_exist
from helpers.constants import BUCKETS_BY_SOURCE_TYPE, SNOWFLAKE_CONN_ID
from helpers.paths import Paths
from helpers.xcom import get_path
from helpers.constants import CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST


@dataclass
class ExperimentConfig:
    run_type: str
    count: int = None


@task
def validate_parquet_data_exists(experiment_config_path: str) -> dict[str, str]:
    """
    Validates that for each correlation ID specified in the experiment config, there is corresponding parquet data in S3 buckets.
     - experiment_config_path: S3 path to experiment config JSON file.
     - Raises RuntimeError if any correlation ID does not have corresponding parquet data in S3.
     - Returns the original experiment config if validation is successful.
     - Expected format of experiment config JSON:
    {
        "experiments": [
            {
                "name": "Experiment 1",
                "description": "Description of experiment 1",
                "campaign_duration": "During",
                "data_source": {
                    "type": "experiment",  # or "standard"
                    "correlation_id": "uuid-string"
                }
            },
            ...
        ]
    }
    """

    bucket, key = split_s3_path(experiment_config_path)
    hook = S3Hook()
    obj = hook.get_key(key=key, bucket_name=bucket)
    experiments_config = json.loads(obj.get()["Body"].read().decode("utf-8"))

    ids_by_type = get_correlation_ids_by_source_type(experiments_config)

    for source_type, correlation_ids in ids_by_type.items():
        for correlation_id in correlation_ids:
            for bucket_name in BUCKETS_BY_SOURCE_TYPE[source_type]:
                if not parquet_files_exist(bucket=bucket_name, prefix=f"{correlation_id}/"):
                    raise RuntimeError(
                        f"No parquet data found for correlation_id '{correlation_id}' "
                        f"in s3://{bucket_name}/{correlation_id}/."
                    )

    print(f"All {len(experiments_config.get('experiments', []))} experiment(s) validated successfully.")


def get_correlation_ids_by_source_type(experiments_config: dict) -> dict[str, list[str]]:
    """Returns correlation IDs grouped by source type."""
    result = {"experiment": [], "standard": []}
    for exp in experiments_config.get("experiments", []):
        source_type = exp["data_source"]["type"]
        if source_type not in result:
            raise ValueError(
                f"Unknown data_source type '{source_type}' for experiment '{exp['name']}'."
            )
        result[source_type].append(exp["data_source"]["correlation_id"])
    return result


@task
def get_experiments_config(experiment_config_path: str, dt: str) -> list[dict]:
    """
    Returns a list of configure_paths kwargs, one per correlation ID.
    experiment_flag=True for 'experiment' type, False for 'standard'.
    """

    bucket, key = split_s3_path(experiment_config_path)
    hook = S3Hook()
    obj = hook.get_key(key=key, bucket_name=bucket)
    experiments_config = json.loads(obj.get()["Body"].read().decode("utf-8"))

    return [
        {
            "name": exp["name"],
            "description": exp.get("description", ""),
            "campaign_duration": exp.get("campaign_duration", ""),
            "correlation_id": exp["data_source"]["correlation_id"],
            "source_type": exp["data_source"]["type"],
            "dt": dt,
        }
        for exp in experiments_config.get("experiments", [])
    ]


def load_experiments(config_path: str) -> list[dict]:
    """Reads experiments JSON at DAG parse time. config_path is relative to dags/.
    Returns an empty list if the config file does not exist (e.g. in AWS Airflow environments
    where the local trials config is not deployed).
    """
    path = Path(__file__).parent.parent / config_path
    if not path.exists():
        return []
    return json.loads(path.read_text()).get("experiments", [])


@task
def validate_experiment_config(
    experiment_config_path: str,
) -> None:
    """
    Validate that a correlation ids provided in config files are all unique and in valid UUID format.
    Also validates that experiment names are unique and data source types are valid.
    """
    UUID_PATTERN = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.IGNORECASE)
    VALID_SOURCE_TYPES = {"experiment", "standard"}
    VALID_CAMPAIGN_DURATIONS = {CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST}

    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
    results: list[tuple[str]] = hook.get_records(f"""
        SELECT
            exp.value:name::VARCHAR AS name,
            exp.value:data_source:correlation_id::VARCHAR AS correlation_id,
            exp.value:data_source:type::VARCHAR AS source_type,
            exp.value:campaign_duration::VARCHAR AS campaign_duration

        FROM
            {experiment_config_path} (FILE_FORMAT => 'measurement_json_file_format') AS exp_config,
            table(FLATTEN(parse_json(exp_config.$1):experiments)) AS exp
    """)
    names = [row[0] for row in results]
    correlation_ids = [x[1] for x in results]
    source_types = [x[2] for x in results]
    campaign_durations = [x[3] for x in results]

    duplicate_names = [name for name in set(names) if names.count(name) > 1]
    if duplicate_names:
        raise ValueError(
            f"Duplicate experiment names found in config {experiment_config_path}: {duplicate_names}"
        )
    invalid = [
        i + 1 for i, cid in enumerate(correlation_ids)
        if not cid or not UUID_PATTERN.match(cid)
    ]
    if invalid:
        raise ValueError(
            f"Invalid or malformed correlation ID at experiment position(s): {invalid} in config {experiment_config_path}. "
            f"Expected UUID format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
        )

    invalid_types = [t for t in source_types if t not in VALID_SOURCE_TYPES]
    if invalid_types:
        raise ValueError(
            f"Invalid data source type(s) found in config {experiment_config_path}: {invalid_types}. "
            f"Allowed types: {VALID_SOURCE_TYPES}"
        )

    invalid_durations = [d for d in campaign_durations if d and d not in VALID_CAMPAIGN_DURATIONS]
    if invalid_durations:
        raise ValueError(
            f"Invalid campaign duration(s) found in config {experiment_config_path}: {invalid_durations}. "
            f"Allowed durations: {VALID_CAMPAIGN_DURATIONS}"
        )


def make_path_resolvers(experiment: bool, correlation_id: str = None, source_type: str = None, experiment_name: str = None):

    """
    Returns a pair of (source_path, experiment_path) resolver functions for use in EMR step definitions.

    For experiment runs, input paths are resolved from the pre-computed Paths dict using the
    given correlation_id and source_type. For standard runs, paths are resolved via XCom using
    Jinja templates at task execution time.

    Args:
        experiment: Whether this is an experiment run.
        correlation_id: Correlation ID of the experiment input data source. Required if experiment is True.
        source_type: Source type ('experiment' or 'standard'). Determines the S3 bucket to resolve from.
        experiment_name: Experiment name used to namespace output paths. Required if experiment is True.

    Returns:
        Tuple of (source_path, experiment_path) callables, each accepting a path key (str) and returning
        the resolved S3 path string.
    """

    paths = Paths(
        correlation_id=correlation_id,
        experimentation=(source_type == "experiment")
    ).paths if experiment else None

    def source_path(key):
        """Resolves paths from the experiment's source data (input correlation ID)."""
        return paths[key] if experiment else get_path(key)

    def experiment_path(key):
        """Resolves paths within the current experiment's namespace (intermediates + outputs)."""
        return get_path(key, experiment_name) if experiment else get_path(key)

    return source_path, experiment_path
