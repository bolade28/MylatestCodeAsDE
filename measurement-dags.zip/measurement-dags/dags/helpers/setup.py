import os
import uuid
import random
import json
import re
from datetime import datetime
import boto3
import pendulum
from typing import Optional, Dict, Any

from airflow.sdk import task
from airflow.sdk import Variable
from airflow.providers.standard.operators.python import get_current_context
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import (
    CLUSTER_DEFAULT_COMPUTE_UNITS,
    MASTER_INSTANCE_TYPES,
    PROD_ACCOUNT_NUMBER,
    DEV_ACCOUNT_NUMBER,
    PROD,
    DEFAULT_RUN_TYPE,
    PROD_SNOWFLAKE_EXTERNAL_STAGE,
    DEV_SNOWFLAKE_EXTERNAL_STAGE,
    EXP_SNOWFLAKE_EXTERNAL_STAGE,
    PROD_SNOWFLAKE_UNLOAD_PATH,
    DEV_SNOWFLAKE_UNLOAD_PATH,
    DEV_EXP_SNOWFLAKE_UNLOAD_PATH,
    EvaluationPhase,
    DagRunSource

)
from helpers.tables import Snowflake
from helpers.paths import Paths
from helpers.sns import SNS
from helpers.mlflow import MLFLOW
from helpers.utils import get_dag_commit_hash
from helpers.snowflake import (
    get_metadata_paths_by_correlation_id,
    resolve_used_new_brand_logic,
)
from helpers.snowflake import get_max_unified_campaign_end_date, get_max_unified_post_campaign_date
import logging


def get_environment() -> str:
    return Variable.get("MEASUREMENT_ENVIRONMENT")


def get_airflow_platform() -> str:
    return Variable.get("AIRFLOW_PLATFORM")


def get_build_hash() -> str:
    return Variable.get("BUILD_HASH")


@task
def get_config() -> Dict[str, str]:
    return {
        "environment": get_environment()
    }


def get_value_from_context(context, default, dag_conf_key):
    if context['dag_run'].conf:
        return context['dag_run'].conf.get(dag_conf_key, default)
    else:
        return default


def resolve_source_end_date(
    end_date_conf_key: str,
    campaigns: Optional[str],
    run_type: Optional[str],
    snowflake_tables: Optional[Dict[str, str]],
) -> Optional[str]:
    if not campaigns or not run_type or not snowflake_tables:
        return None

    pollen_table = snowflake_tables.get('measurement_unified_campaign_pollen')
    dtp_table = snowflake_tables.get('measurement_unified_campaign')
    if not pollen_table or not dtp_table:
        return None

    if end_date_conf_key == 'post_period_end_date':
        return get_max_unified_post_campaign_date(
            campaign_ids=campaigns,
            run_type=run_type,
            pollen_table=pollen_table,
            dtp_table=dtp_table,
        )

    return get_max_unified_campaign_end_date(
        campaign_ids=campaigns,
        run_type=run_type,
        pollen_table=pollen_table,
        dtp_table=dtp_table,
    )


def resolve_effective_end_date(
    run_date: str,
    end_date_conf_key: str,
    campaigns: Optional[str] = None,
    run_type: Optional[str] = None,
    snowflake_tables: Optional[Dict[str, str]] = None,
) -> str:
    context = get_current_context()
    configured_end_date = get_value_from_context(
        context=context,
        default='',
        dag_conf_key=end_date_conf_key,
    )

    if isinstance(configured_end_date, str):
        configured_end_date = configured_end_date.strip()
        try:
            configured_end_date = json.loads(configured_end_date)
        except json.JSONDecodeError:
            pass

    if isinstance(configured_end_date, (list, tuple)) and len(configured_end_date) == 1:
        configured_end_date = configured_end_date[0]

    if isinstance(configured_end_date, str):
        configured_end_date = configured_end_date.strip()

    if configured_end_date:
        return configured_end_date

    logical_date = pendulum.parse(run_date).date()
    source_end_date = resolve_source_end_date(
        end_date_conf_key=end_date_conf_key,
        campaigns=campaigns,
        run_type=run_type,
        snowflake_tables=snowflake_tables,
    )

    if source_end_date is None:
        return logical_date.strftime('%Y-%m-%d')

    return pendulum.parse(source_end_date).date().strftime('%Y-%m-%d')


def parse_model_end_date(value: str):
    date_formats = (
        (r'\d{4}-\d{2}-\d{2}', 'YYYY-MM-DD'),
        (r'\d{2}-\d{2}-\d{4}', 'DD-MM-YYYY'),
        (r'\d{2}-\d{2}-\d{2}', 'DD-MM-YY'),
    )

    for pattern, date_format in date_formats:
        if re.fullmatch(pattern, value):
            try:
                return pendulum.from_format(value, date_format).date()
            except ValueError:
                break

    raise ValueError(
        f"Invalid date '{value}'. Use YYYY-MM-DD, DD-MM-YYYY, or DD-MM-YY."
    )


#
#  ---- Setup tasks that push to XCOM
#
"""
The @task decorated functions all push their return value to a xcom entry for that task.
That value can then be used in other tasks by pulling the appropriate xcom entry.
"""


@task
def configure_compute_units(default: int = CLUSTER_DEFAULT_COMPUTE_UNITS) -> int:
    """
    If you call this function as part of your DAG setup you can ensure a sensible default
    size for your DAGs EMR cluster, e.g. configure_compute_units(16).
    """
    context = get_current_context()
    return int(get_value_from_context(context=context, default=default, dag_conf_key='compute_units'))


@task
def configure_correlation_id(date_based: bool = False) -> str:
    """
    Pass in the data_based bool value as True to get the correlation ID in format `yyyy-dd-mm/<8_random_letters>`.
    Otherwise, the correlation ID will be random.
    """
    if date_based:
        return os.path.join(datetime.now().strftime("%Y-%m-%d"), str(uuid.uuid4()).split('-')[0])
    else:
        return str(uuid.uuid4())


@task
def configure_pipelines_version() -> str:
    """
    Used to point spark to a path on the artefacts bucket to a particular version of a script,
    e.g. s3://measurement-dev-artefacts/{pipelines_version}/some_script.py
    The default value of oa_version is 'latest'
    :return:
    """
    context = get_current_context()
    return get_value_from_context(context=context, default='latest', dag_conf_key='pipelines_hash')


@task
def configure_campaign_end_date(
    run_date: str,
    campaigns: Optional[str] = None,
    run_type: Optional[str] = None,
    snowflake_tables: Optional[Dict[str, str]] = None,
) -> str:
    """
    Returns the effective campaign end date for the pipeline run.
    A configured DAG param takes precedence; otherwise the value is resolved from
    unified campaign data and capped at the DAG logical date.
    """
    return resolve_effective_end_date(
        run_date=run_date,
        end_date_conf_key='campaign_end_date',
        campaigns=campaigns,
        run_type=run_type,
        snowflake_tables=snowflake_tables,
    )


@task
def configure_post_period_end_date(
    run_date: str,
    campaigns: Optional[str] = None,
    run_type: Optional[str] = None,
    snowflake_tables: Optional[Dict[str, str]] = None,
) -> str:
    """
    Returns the effective post period end date for the pipeline run.
    A configured DAG param takes precedence; otherwise the value is resolved from
    unified campaign data and capped at the DAG logical date.
    """
    return resolve_effective_end_date(
        run_date=run_date,
        end_date_conf_key='post_period_end_date',
        campaigns=campaigns,
        run_type=run_type,
        snowflake_tables=snowflake_tables,
    )


@task(multiple_outputs=True)
def configure_paths(correlation_id: str, dt: Optional[str] = None, experiment_flag: Optional[bool] = False, used_new_brand_logic: bool = True) -> Dict[str, str]:
    return Paths(correlation_id, dt=dt, experimentation=experiment_flag, used_new_brand_logic=used_new_brand_logic).paths


@task
def configure_seed() -> int:
    return random.randint(0, 1_000_000)


@task(multiple_outputs=True)
def configure_snowflake_tables(ci: str = None, emulation_run: bool = False, used_new_brand_logic: bool = True) -> Dict[str, str]:
    return Snowflake(correlation_id=ci, emulation_run=emulation_run, used_new_brand_logic=used_new_brand_logic).tables


@task
def configure_emulation_run() -> bool:
    """
    Reads the emulation_run flag from the DAG config.
    When True, downstream table resolution uses the production source
    instead of development, enabling emulation run of in-flight campaigns.
    Always returns False in production — the toggle is not exposed there.
    """
    if get_environment() == PROD:
        return False
    context = get_current_context()
    return get_value_from_context(
        context=context,
        default=True,
        dag_conf_key='emulation_run'
    )


@task(multiple_outputs=True)
def configure_sns() -> Dict[str, str]:
    return SNS().all()


@task
def job_flow_start_time():
    return datetime.now(tz=None).replace(microsecond=0).isoformat()


def get_account_number() -> str:
    return PROD_ACCOUNT_NUMBER if get_environment() == PROD else DEV_ACCOUNT_NUMBER


@task
def parse_dag_config() -> Dict[str, str]:
    config = get_current_context()["dag_run"].conf
    return {
        "source_bucket_key": config["source_bucket_key"],
        "destination_bucket_key": config["destination_bucket_key"]
    }


@task(multiple_outputs=True)
def configure_campaign_start_date():
    """
    Campaign start year = 2025 if environment = prod otherwise 2023
    Campaign start month = 02 if environment = prod otherwise 01
    """

    return {
        'year': '2025' if get_environment() == PROD else '2023',
        'month': '02' if get_environment() == PROD else '01'
    }


# NONE_FAILED_MIN_ONE_SUCCESS lets manual runs proceed when query_eligible_booking is short-circuited.
@task(trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
def configure_campaigns(dag_run_source: Optional[str] = None, eligible_booking_rows: Optional[list] = None):
    """
    Returns the campaigns to run.
    Manual runs use the manual_run_campaign_list DAG config.
    Automated runs use the booking returned by query_eligible_booking, or '' when none is eligible.
    """
    context = get_current_context()
    if dag_run_source != DagRunSource.AUTOMATED.value:
        return str(get_value_from_context(
            context=context,
            default=[],
            dag_conf_key='manual_run_campaign_list'
        ))

    if not eligible_booking_rows:
        logging.info("Automated run: no eligible booking found.")
        return ''

    booking_id = eligible_booking_rows[0][0]
    logging.info(f"Automated run: selected booking {booking_id}.")
    return str(booking_id)


@task
def configure_mlflow() -> Dict[str, str]:
    """
    Configures MLflow tracking URI based on the environment.
    Returns a dictionary with the MLflow tracker URI.
    """
    mlflow = MLFLOW()
    return mlflow.all()


# TODO:: This function will be updated to retrieve dates from weekly_dates table for consistency
@task(multiple_outputs=True)
def configure_model_start_end_dates(
    run_date: str,
    default_model_start_date: str,
    daily_etl_flag: bool = False,
    end_date_conf_key: str = 'campaign_end_date',
    campaigns: Optional[str] = None,
    run_type: Optional[str] = None,
    snowflake_tables: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    """
    Calculate start and end dates based on input parameters.

    Args:
        run_date (str): End of the data interval of the pipeline in 'YYYY-MM-DD' format.
        default_model_start_date (str): The minimum allowed start date in 'YYYY-MM-DD' format.
        daily_etl_flag (bool): Flag indicating whether the pipeline is a daily ETL. If True, start date is set to default_model_start_date.
        end_date_conf_key (str): DAG config key used to resolve the model end date.
        campaigns (Optional[str]): Configured campaign IDs for the run.
        run_type (Optional[str]): Run type for the campaign selection (e.g. DTP or Pollen).
        snowflake_tables (Optional[Dict[str, str]]): Resolved Snowflake tables for the run.

    Returns:
        dict: A dictionary with 'start_date' and 'end_date' as datetime.date objects.
    Raises:
        ValueError: If the configured end date key is not in YYYY-MM-DD, DD-MM-YYYY, or DD-MM-YY format.

    Notes:
        Please note this function used to normalise the end date to a Monday, however, this means we miss campaigns that end mid-week.
        Since this is passed in as a input into the feature processed scripts we want to allow for end dates that are mid-week so that we can capture all relevant campaigns.

        The weekly dates script already normalises the week start date to a Monday, so this is in the correct format and it is not necessary to also normalise the end date to a Monday here.
    """

    min_start_date = pendulum.parse(default_model_start_date).date()
    resolved_end_date = resolve_effective_end_date(
        run_date=run_date,
        end_date_conf_key=end_date_conf_key,
        campaigns=campaigns,
        run_type=run_type,
        snowflake_tables=snowflake_tables,
    )

    try:
        end_date = parse_model_end_date(resolved_end_date)
    except Exception as e:
        raise ValueError(f"Invalid model_end_date provided: {e}") from e

    # Setting model start date to three years ago from today
    if daily_etl_flag:
        start_date = pendulum.parse(default_model_start_date).date()
    else:
        three_years_ago = end_date.subtract(years=3)
        start_date = three_years_ago.subtract(days=three_years_ago.day_of_week)

    if start_date < min_start_date:
        start_date = min_start_date

    return {'start_date': start_date.strftime('%Y-%m-%d'), 'end_date': end_date.strftime('%Y-%m-%d')}


@task
def configure_run_type() -> str:
    """
    Returns:
        run_type (str): The run type for the pipeline (e.g., "Pollen" or "DTP"), as set with the DAG config parameter.
    """
    context = get_current_context()
    run_type = get_value_from_context(
        context=context,
        default=DEFAULT_RUN_TYPE,
        dag_conf_key='pipeline_run_type'
    )

    if not run_type:
        raise ValueError("run_type must be provided in DAG config. Acceptable values are 'Pollen' or 'DTP'.")
    if run_type not in ['Pollen', 'DTP']:
        raise ValueError("Invalid run_type. Acceptable values are 'Pollen' or 'DTP'.")

    return run_type


@task(multiple_outputs=True)
def configure_dag_version() -> str:
    """
    Returns:
        dag_version (str): The version of the DAG, as set with the DAG config parameter.
        The version of DAG in docker will the the last  commit hash when merged to main branch.
        The version of DAG in EC2 will the the main branch commit hash when deployed to EC2.

    """

    platform = get_airflow_platform()
    context = get_current_context()
    commits = get_dag_commit_hash(platform, context)

    return {'git_commit': commits}


@task
def configure_ci_of_during_run() -> str:
    """
    Returns:
        ci_of_during_run (str): The correlation ID of the 'During' run, as set with the DAG config parameter.
    """
    context = get_current_context()
    return get_value_from_context(
        context=context,
        default='latest',
        dag_conf_key='ci_of_during_run'
    )


@task
def resolve_previous_paths(during_correlation_id: str) -> Dict[str, Any]:
    """Return DURING-run PATHS from metadata for an explicit correlation id."""
    env = get_environment()

    previous_paths = get_metadata_paths_by_correlation_id(
        correlation_id=during_correlation_id,
        env=env,
    )

    return previous_paths


@task
def configure_used_new_brand_logic(during_ci: str, campaign_id: str) -> bool:
    """Return whether the configured DURING run used new brand logic."""
    try:
        return resolve_used_new_brand_logic(
            during_ci=during_ci,
            campaign_id=campaign_id,
            env=get_environment(),
        )
    except Exception as e:
        logging.warning(
            f"Failed to resolve brand logic for CI {during_ci}: {e}. "
            f"Defaulting to False (legacy)."
        )
        return False


@task
def configure_aws_user():
    """Get the current AWS user's name for cluster naming."""
    try:
        # Get current user identity
        sts = boto3.client('sts')
        identity = sts.get_caller_identity()

        # Extract username from ARN
        arn = identity.get('Arn', '')

        if "instance-role" in arn:
            return "airflow-aws"

        user_name = arn.split('/')[-1].lower().split('@')[0]
        return user_name.replace(".", "-")

    except Exception as e:
        raise RuntimeError(f"Not logged in to AWS or credentials expired: {e}") from e


@task
def configure_master_instance_type() -> str:
    """Get a random master instance type based on weights.
    This is to suport multiple DAG runs in dev environment where we can hit capacity issues
    Once we fix parallisation issues linked to campaign/job bag number issue, we can remove this and just use a single instance type
    """
    instances = list(MASTER_INSTANCE_TYPES.keys())
    weights = list(MASTER_INSTANCE_TYPES.values())
    return random.choices(instances, weights=weights)[0]


@task
def configure_persist_dataset() -> str:
    """
    Returns:
        persist_dataset (str): The flag indicating whether to persist intermediate datasets, as set with the DAG config parameter.
    """
    logger = logging.getLogger(__name__)
    context = get_current_context()
    value = get_value_from_context(
        context=context,
        default=False,
        dag_conf_key='persist_dataset'
    )
    if get_environment() == PROD:
        logger.info("In PROD environment, setting persist_dataset to False regardless of DAG config.")
        return False

    if isinstance(value, str):
        value = value.lower() == 'true'
    return bool(value)


@task(multiple_outputs=True)
def configure_snowflake_stage(experimentation: bool = False) -> Dict[str, str]:
    """
    Resolves the correct Snowflake external stage and S3 bucket based on environment
    and whether experimentation mode is enabled.
    """
    env = get_environment()
    if env == PROD:
        return {"stage": PROD_SNOWFLAKE_EXTERNAL_STAGE, "bucket": PROD_SNOWFLAKE_UNLOAD_PATH}
    if experimentation:
        return {"stage": EXP_SNOWFLAKE_EXTERNAL_STAGE, "bucket": DEV_EXP_SNOWFLAKE_UNLOAD_PATH}
    return {"stage": DEV_SNOWFLAKE_EXTERNAL_STAGE, "bucket": DEV_SNOWFLAKE_UNLOAD_PATH}


@task
def evaluation_phase() -> str:
    """
    Returns:
        evaluation_phase (str): The evaluation phase for the experiment, as set with the DAG config parameter.
    """
    context = get_current_context()
    return get_value_from_context(
        context=context,
        default=EvaluationPhase.DURING,
        dag_conf_key='evaluation_phase'
    )


@task
def configure_previous_correlation_id() -> str:
    """
    Returns:
        previous_correlation_id (str): The correlation ID for the previous run, as set with the DAG config parameter.
    """
    context = get_current_context()
    return get_value_from_context(
        context=context,
        default='',
        dag_conf_key='previous_correlation_id'
    )


@task
def configure_dag_run_source() -> str:
    """
    Determines whether the DAG run was triggered manually or by automation (scheduler, backfill, asset trigger).

    Returns:
        str: "MANUAL" if the DAG was triggered manually, "AUTOMATED" otherwise.
    """
    context = get_current_context()
    dag_run = context['dag_run']
    is_manual = dag_run.run_type == "manual"
    return "MANUAL" if is_manual else "AUTOMATED"


@task
def configure_run_incrementality_v2() -> bool:
    """
    Returns:
        run_incrementality_v2 (bool): The flag indicating whether to run the v2 edition of incrementality, as chosen by user in dag run setup.
    """
    logger = logging.getLogger(__name__)
    context = get_current_context()
    value = get_value_from_context(
        context=context,
        default=False,
        dag_conf_key="run_incrementality_v2"
    )
    if get_environment() == PROD:
        logger.info("NOTE: PROD environment -> setting run_incrementality_v2 to False regardless of DAG config! (TODO eventually should enable this in prod, but not this day)")
        return False

    if isinstance(value, str):
        value = value.lower() == "true"
    return bool(value)
