from airflow.sdk import Param
from helpers.constants import (
    CAMPAIGN_DURATION_DURING,
    CAMPAIGN_DURATION_POST,
    DEFAULT_RUN_TYPE,
)


# dag run configuration parameters
def compute_units_param(cores: int = 16) -> Param:

    return Param(
        default=cores,
        description="The number of cores to use for EMR cluster (in multiples of 8)",
        type="integer",
        title="EMR Compute Units",
        description_md=f"""
        The number of cores to use for the EMR cluster. Since the smallest instance size we use has 8 cores,
        the number of cores requested should be a multiple of 8.

        If not specified it will default to **{cores}** cores.
        """
    )


class DagParams:
    pipelines_hash_param = Param(
        default="latest",
        description="Github or custom commit hash for measurement-pipelines version",
        type="string",
        title="Pipelines commit hash",
        description_md="""
        Use `latest` to run pipelines from the `main` branch of the `measurement-pipelines` repository.
        To run a specific version, provide any git commit hash from that repository or create your
        own custom hash value using dev_deploy.sh in pipelines repo.
        """
    )

    source_bucket_key = Param(
        default="/folder_1/",
        description="source location from the file to be copied",
        type="string",
        title="measurement pipelines test source location",
        description_md="""
        Source location to copy the file from
        """
    )

    destination_bucket_key = Param(
        default="s3://measurement-dev-temp/folder_2/some_temp_file.csv",
        description="source location from the file to be copied",
        type="string",
        title="measurement pipelines test destination location",
        description_md="""
        Source location to copy the file from
        """
    )

    pipelines_manual_campaign_list = Param(
        default="",
        type="string",
        title="Booking ID or Job bag number",
        description="Provide booking ID for Pollen or Job Bag Number for DTP",
        description_md="""
                This parameter is used to provide the booking ID for Pollen campaigns or the job bag number for DTP campaigns.
            """
    )
    pipeline_run_type = Param(
        default=DEFAULT_RUN_TYPE,
        type="string",
        title="Run type - Pollen or DTP",
        description="This parameter is used to decide if we are running pipelines using Pollen based campaigns or DTP",
        description_md="""
                Provide only Pollen or DTP as input.
            """
    )

    campaign_end_date = Param(
        default=None,
        type=["null", "string"],
        title="Campaign end date",
        description="OPTIONAL: This parameter is used to specify the end date for the campaign and can be left empty to automatically resolve at runtime.",
        description_md="""
            Provide a valid campaign end date as input. Accepted formats: YYYY-MM-DD, DD-MM-YYYY, or DD-MM-YY.
            Examples: 2025-07-02, 02-07-2025, or 02-07-25.
                This parameter is optional - leave it empty (no value at all) to resolve the effective campaign end date
                at runtime from unified campaign data, falling back to the DAG logical date when needed.
            """
    )

    post_period_end_date = Param(
        default=None,
        type=["null", "string"],
        title="Post period end date",
        description="This parameter is used to specify the end date for the post period evaluation and can be left empty to automatically resolve at runtime.",
        description_md="""
            Provide a valid post period end date as input. Accepted formats: YYYY-MM-DD, DD-MM-YYYY, or DD-MM-YY.
            Examples: 2025-07-02, 02-07-2025, or 02-07-25.
                This parameter is optional - leave it empty (no value at all) to resolve the effective post period end date
                at runtime from unified campaign data, falling back to the DAG logical date when needed.
            """
    )

    ci_of_during_run = Param(
        default="latest",
        type="string",
        title="Correlation ID of During Run",
        description="This parameter is used to decide if we are pulling results of a specific correlation id or the latest timestamp for specific campaigns.",
        description_md="""
                    Provide a correlation id of a During run to use results of that run in the Post run.
                    Otherwise the latest load_ts will be used for campaign list.
            """
    )
    persist_dataset = Param(
        default=False,
        type="boolean",
        title="Persist dataset",
        description="This parameter is used to persist this runs dataset in S3 experimentation bucket. By default, intermediate datasets are not persisted and are deleted after currently configured retention period",
        description_md="""
                This parameter is used to decide whether to persist intermediate datasets in S3 for experimentation purposes.
                By default, intermediate datasets are only persisted temporarily and are deleted after some time.
            """
    )

    experiment_config = Param(
        default="",
        type="string",
        title="Experiment configuration",
        description="This parameter is used to provide S3 path for the configuration for the experiment.",
    )

    evaluation_phase = Param(
        default="during",
        type="string",
        title="Evaluation phase",
        description="This parameter is used to specify the evaluation phase for which the DAG is being run. Valid values are 'during' and 'post'",
        description_md="""
                This parameter is used to specify the evaluation phase for which the DAG is being run. Valid values are 'during' and 'post'."""
    )

    experiment_data_correlation_id = Param(
        default="",
        type="string",
        title="Correlation ID for experimental unloaded data",
        description="This parameter is used to provide the correlation ID for the experimental data that needs to be cleared from the S3 experiment bucket. This is only used in the clear_experimental_data_dag.",
    )

    previous_correlation_id = Param(
        default="",
        type="string",
        title="Correlation ID for measurement outputs to be DELETED",
        description="This parameter is used to provide the correlation ID for the measurement outputs that need to be cleared from the Snowflake tables. This is only used in the clear_measurement_outputs_dag.",
    )

    emulation_run = Param(
        default=True,
        type="boolean",
        title="Enable emulation run",
        description=(
            "Set to True to run the pipeline in emulation mode using production bookings. "
            "Set to False to use development bookings instead."
        ),
    )

    booking_approval_booking_ids = Param(
        default="",
        type="string",
        title="Booking IDs",
        description="Comma-separated booking IDs to approve. Example: 69b156f9a40e90028e348194, 69ca97ba06d36308c3f7ad5d",
    )

    booking_approval_during_threshold_days = Param(
        default=7,
        type="integer",
        title="During threshold days",
        description="Minimum number of days after campaign end date for During approval.",
        description_md="""
                Booking is eligible only when campaign_end_dt is at least this many days
                before the DAG run date.
            """
    )

    booking_approval_campaign_duration = Param(
        default=CAMPAIGN_DURATION_DURING,
        type="string",
        enum=[CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST],
        title="Campaign duration",
        description="Campaign duration to validate: During or Post.",
    )

    run_incrementality_v2 = Param(
        default=False,
        type="boolean",
        title="Run Incrementality v2",
        description="Whether to run the new v2 Incrementality. If not, run only the default one. If yes, run both (TODO: we are not yet doing anything with the v2 results).",
        description_md="Whether to run the new v2 Incrementality. If not, run only the default one. If yes, run both (TODO: we are not yet doing anything with the v2 results)."
    )
