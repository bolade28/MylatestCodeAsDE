import enum
import re


class FileExists(enum.Enum):
    YES = "YES"
    NO = "NO"


class EvaluationPhase(str, enum.Enum):
    DURING = "during"
    POST = "post"


class DagRunSource(str, enum.Enum):
    MANUAL = "MANUAL"
    AUTOMATED = "AUTOMATED"


# TODO: we should use REPORTING_STATUS_APPROVED instead
class BookingApprovalStatus(str, enum.Enum):
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"


class XComKeys:
    DAGS_COMMIT_LIST = 'dags_commit_hash_list'
    PIPELINES_COMMIT_LIST = 'pipelines_commit_hash_list'


class DAGSMetrics(str, enum.Enum):
    PIPELINES_METADATA = "pipelines_metadata"


class DeploymentStatus(str, enum.Enum):
    APPROVED = "approved"
    DELETED = "deleted"


TASK_INSTANCE_NOT_AVAILABLE_ERROR = "Task instance not available in context"


EMR_RELEASE = "emr-7.8.0"
SLACK_CONN_ID = 'slack_conn'
REGION_NAME = 'eu-west-1'

# ---- DEV ACCOUNT DETAILS ----
DEV = "dev"
DEV_KEY = "measurement-dev-key"
DEV_ACCOUNT_NUMBER = "277707132387"
DEV_SUBNETS = ["subnet-04819b6a006117513", "subnet-0eafe65261833d3e3", "subnet-0a320fec7a82e0084"]
DEV_SNOWFLAKE_EXTERNAL_STAGE = "@measurement_dev_stage"
DEV_SNOWFLAKE_UNLOAD_PATH = "s3://measurement-dev-snowflake-unload"
EXP_SNOWFLAKE_EXTERNAL_STAGE = "@measurement_dev_exp_stage"
DEV_EXP_SNOWFLAKE_UNLOAD_PATH = "s3://measurement-dev-experiment"

# ---- PROD ACCOUNT DETAILS ----
PROD = "prod"
PROD_KEY = "measurement-prod-key"
PROD_ACCOUNT_NUMBER = "626635410130"
PROD_SUBNETS = ["subnet-0eb11ded0d64d0588", "subnet-08b08a220c3df113d", "subnet-03a33b234531986a3"]
PROD_SNOWFLAKE_EXTERNAL_STAGE = "@measurement_prod_stage"
PROD_SNOWFLAKE_UNLOAD_PATH = "s3://measurement-prod-snowflake-unload"

CLUSTER_DEFAULT_COMPUTE_UNITS = 12  # NOTE: change by Moses see PR #175 - testing this here as well
MAX_RUNTIME_HOURS = 6  # Default max runtime for EMR cluster

# ---- AIRFLOW ENVIRONMENT VARIABLE NAMES ----
SNOWFLAKE_CONN_ID = "snowflake_conn"
SNOWFLAKE_TABLE_IDENTIFIER_PATTERN = re.compile(
    r"^[A-Za-z_][A-Za-z0-9_$]*(?:\.[A-Za-z_][A-Za-z0-9_$]*){0,2}$"
)
SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE = "WHS_PROD_CUSTOMER_ETL_GIGA"
SUPERMARKET_STORE_TYPE = "SUPERMARKET"
AIRFLOW_PLATFORM_EC2 = "ec2"
AIRFLOW_PLATFORM_DOCKER = "docker"

# see https://aws.amazon.com/ec2/instance-types/
# and https://docs.aws.amazon.com/emr/latest/ManagementGuide/emr-supported-instance-types.html
# https://aws.amazon.com/ec2/spot/instance-advisor/
INSTANCE_TYPES = [
    {"type": "r5b.16xlarge", "weight": 64, "ebs_volumes": 8, "ebs_vol_size": 512},
    {"type": "r5b.24xlarge", "weight": 96, "ebs_volumes": 8, "ebs_vol_size": 768},

    {"type": "r5n.8xlarge", "weight": 32, "ebs_volumes": 8, "ebs_vol_size": 256},
    {"type": "r5n.12xlarge", "weight": 48, "ebs_volumes": 8, "ebs_vol_size": 384},
    {"type": "r5n.16xlarge", "weight": 64, "ebs_volumes": 8, "ebs_vol_size": 512},
    # 15-20% frequency of interruption
    # {"type": "r5n.24xlarge", "weight": 96, "ebs_volumes": 8, "ebs_vol_size": 768},

    # >20% frequency of interruption
    # {"type": "r6a.8xlarge", "weight": 32, "ebs_volumes": 8, "ebs_vol_size": 256},
    {"type": "r6a.12xlarge", "weight": 48, "ebs_volumes": 8, "ebs_vol_size": 384},
    # >20% frequency of interruption
    # {"type": "r6a.16xlarge", "weight": 64, "ebs_volumes": 8, "ebs_vol_size": 512},
    # >20% frequency of interruption
    # {"type": "r6a.24xlarge", "weight": 96, "ebs_volumes": 8, "ebs_vol_size": 768},
    {"type": "r6a.32xlarge", "weight": 128, "ebs_volumes": 8, "ebs_vol_size": 1024},

    {"type": "r6in.8xlarge", "weight": 32, "ebs_volumes": 8, "ebs_vol_size": 256},
    {"type": "r6in.12xlarge", "weight": 48, "ebs_volumes": 8, "ebs_vol_size": 384},
    {"type": "r6in.16xlarge", "weight": 64, "ebs_volumes": 8, "ebs_vol_size": 512},
    {"type": "r6in.24xlarge", "weight": 96, "ebs_volumes": 8, "ebs_vol_size": 768},
    {"type": "r6in.32xlarge", "weight": 128, "ebs_volumes": 8, "ebs_vol_size": 1024},

    {"type": "r7a.8xlarge", "weight": 32, "ebs_volumes": 8, "ebs_vol_size": 256},
    {"type": "r7a.12xlarge", "weight": 48, "ebs_volumes": 8, "ebs_vol_size": 384},
    {"type": "r7a.16xlarge", "weight": 64, "ebs_volumes": 8, "ebs_vol_size": 512},
    {"type": "r7a.24xlarge", "weight": 96, "ebs_volumes": 8, "ebs_vol_size": 768},
    {"type": "r7a.32xlarge", "weight": 128, "ebs_volumes": 8, "ebs_vol_size": 1024},

    {"type": "r7i.8xlarge", "weight": 32, "ebs_volumes": 8, "ebs_vol_size": 256},
    {"type": "r7i.12xlarge", "weight": 48, "ebs_volumes": 8, "ebs_vol_size": 384},
    # >20% frequency of interruption
    # {"type": "r7i.16xlarge", "weight": 64, "ebs_volumes": 8, "ebs_vol_size": 512},
    {"type": "r7i.24xlarge", "weight": 96, "ebs_volumes": 8, "ebs_vol_size": 768},

    {"type": "r7g.8xlarge", "weight": 32, "ebs_volumes": 8, "ebs_vol_size": 256},
    {"type": "r7g.12xlarge", "weight": 48, "ebs_volumes": 8, "ebs_vol_size": 384},
    {"type": "r7g.16xlarge", "weight": 64, "ebs_volumes": 8, "ebs_vol_size": 512},

    {"type": "r7gd.8xlarge", "weight": 32, "ebs_volumes": 8, "ebs_vol_size": 256},
    {"type": "r7gd.12xlarge", "weight": 48, "ebs_volumes": 8, "ebs_vol_size": 384},
    {"type": "r7gd.16xlarge", "weight": 64, "ebs_volumes": 8, "ebs_vol_size": 512},
]

# Define master instance types with weights (higher weight = more likely to be selected)
MASTER_INSTANCE_TYPES = {
    "r6in.8xlarge": 30,   # Current - higher weight as it's proven
    "r6i.4xlarge": 25,    # Smaller - for lighter workloads. We can test this and remove it if it causes issues
    "r6i.8xlarge": 40,    # Best availability, same specs as r6in.8xlarge
    "r7i.8xlarge": 30,    # Latest gen, same specs
    "r6in.4xlarge": 25,   # Smaller - for lighter workloads. We can test this and remove it if it causes issues
    "r5.8xlarge": 35,     # Proven availability, slightly older gen
    "r5.4xlarge": 25,      # Smaller - for lighter workloads. We can test this and remove it if it causes issues
}

# TODO:: need to change this variable later
# -------- External data VARIABLE -----------
HOLIDAY_DATE_TAGGING = {
    '2022-11-25': 'Black Friday',
    '2023-11-24': 'Black Friday',
    '2024-11-29': 'Black Friday',
    '2025-11-28': 'Black Friday',
    '2026-11-27': 'Black Friday',
    '2022-11-28': 'Cyber Monday',
    '2023-11-27': 'Cyber Monday',
    '2024-12-02': 'Cyber Monday',
    '2025-12-01': 'Cyber Monday',
    '2026-11-30': 'Cyber Monday',
}

HOLIDAY_FLAG_MAPPINGS = {
    '2ND JANUARY (SUBSTITUTE DAY)': 'NEW YEARS DAY OBSERVED',
    'SUBSTITUTE BANK HOLIDAY FOR CHRISTMAS DAY': 'CHRISTMAS DAY',
    'CHRISTMAS EVE': 'CHRISTMAS DAY',
    'BATTLE OF THE BOYNE OBSERVED': 'BATTLE OF THE BOYNE',
    'DAY OFF FOR ST PATRICKS DAY': 'ST PATRICKS DAY',
    'EARLY MAY BANK HOLIDAY / VE DAY': 'EARLY MAY BANK HOLIDAY',
    'NEW YEARS DAY HOLIDAY': 'NEW YEARS DAY OBSERVED',
    'NEW YEARS DAY': 'NEW YEARS DAY HOLIDAY',
    'ST ANDREWS DAY OBSERVED': 'ST ANDREWS DAY',
    'SUBSTITUTE BANK HOLIDAY FOR BOXING DAY': 'BOXING DAY',
    'EASTER SUNDAY': 'EASTER',
    'EASTER MONDAY': 'EASTER',
    'GOOD FRIDAY': 'EASTER',
    'NEW YEARS EVE': 'NEW YEARS DAY OBSERVED',
}

# List of Holiday Types where Holiday Flag column is created using Holiday Name
EXT_HOLIDAY_NAME_LIST = ['Local holiday', 'National holiday', 'Common local holiday', 'Observance']
# List of Holiday Types that we filter out from input raw data as these contain the holiday data that we want to test in model
EXT_HOLIDAY_TYPE_FILTER = [
    'Local holiday', 'National holiday', 'Common local holiday',
    'Hinduism', 'Muslim', 'Christian', 'Observance']
# List of marketing sub_channels that have been extended from its week to past couple of weeks as well to capture its impact on sales better
EXT_MARKETING_SUB_CHANNEL_EXTEND = [
    'CHINESE_NEW_YEAR', 'DIWALI_DEEPAVALI', 'GUY_FAWKES_DAY', 'HALLOWEEN',
    'MOTHERING_SUNDAY', 'ST_ANDREWS_DAY', 'ST_PATRICKS_DAY', 'ST._DAVIDS_DAY',
    'ST._GEORGES_DAY', 'VALENTINES_DAY', 'FATHERS_DAY', 'EASTER', 'CHRISTMAS_DAY']  # ------------FACT_SALES_TRANSACTION_BASKET_VARIABLE------------
# christmas list to gather start dates for Christmas
EXT_CHRISTMAS_LIST = ['Christmas Eve', 'Christmas Day', 'Substitute Bank Holiday for Christmas Day']

# --- PRE-CLUSTERING FLAG----
PRE_CLUSTERING_FILTER_ENABLED = False  # Default set to False so no clustering pre-filters are applied
# TODO:: need to change this variable later
# --- BASELINE CONFIG VARIABLES----
DEFAULT_DAILY_ETL_MODEL_START_DATE = '2021-01-04'  # Default start date for daily ETL transactions
DEFAULT_MODEL_START_DATE = '2022-01-01'  # Default start date
NUMBER_OF_WEEKS = '104'
NUMBER_OF_WEEKS_DAILY_ETL = '310'
# ----  Campaign Channel Mapping Parameters ----
CHANNELS = {"youtube": "Youtube", "on-site": "Onsite (GOL)", "ecoupons": "eCoupons", "ecoupons_pollen": "ECOUPON", "dv360": "DV360"}
SUBCHANNELS = {"META": "Social - Meta", "citrus": "ecoupons"}
SERVICE_TYPE = "Ecomm Media Plat"
# ------------FACT_SALES_TRANSACTION_BASKET_VARIABLE------------
SALES_TRANSACTION_CODES = [14, 16, 17, 19, 20, 21, 29]

RUN_BASELINE_MANUALLY = True

# ------------INSTORE_CUSTOMER_DATA_VARIABLE------------
# Sales origination channel codes for instore used in the channel specific customer data collection scripts.
SALES_ORIGINATION_INSTORE_CODES = ('14', '16')

# Sales origination channel codes for all channels used in the channel specific customer data collection scripts.
SALES_ORIGINATION_ALL_CODES = ('14', '16', '17', '19', '20', '21', '29')

# Sales origination channel codes for online channels used in the channel specific customer data collection scripts.
SALES_ORIGINATION_ONLINE_CODES = ('17', '19', '20', '21', '29')

USER_JOURNEY_CHANNEL = {"In-store": "In-store", "Online": "Online"}
USER_JOURNEY_SUBCHANNEL = "TXN"

ECOUPON_TARGETED = 2
# ------------USER_JOURNEY_TYPE------------
PRODUCT_TYPE = {"aisle": "aisle", "brand": "brand", "offer": "offer"}
JOURNEY_TYPE = {"aisle": "aisle", "brand": "brand", "offer": "offer"}

INCLUDE_AISLE_SKUS = False

DEFAULT_RUN_TYPE = "Pollen"

DTP_RUN_TYPE = "DTP"
POLLEN_RUN_TYPE = "Pollen"
DURING_METADATA_PATH_KEYS = (
    "ucm_serialised_models",
    "ucm_serialised_models_v2",
    "scaler_df",
    "scaler_df_v2",
    "customer_data_collection",
)
# ------------CAMPAIGN_DECAY_POLLEN------------
MARKETING_TYPE = {"offsite": "offsite", "onsite": "onsite"}
MIN_IMPRESSION_VALUE = 0.001
CAMPAIGN_LIST_TYPE = {"DTP": "JOB_BAG_NUMBER", "Pollen": "BOOKING_ID"}
# ------------Post and During campaigns------------
CAMPAIGN_DURATION_POST = "Post"
CAMPAIGN_DURATION_DURING = "During"

# ------------Booking Approval and Pre-Check Status------------
REPORTING_STATUS_APPROVED = "APPROVED"
AUTOMATED_RUN_OFFSET_DAYS = 7
BOOKING_APPROVAL_STATUS_READY = "READY"
BOOKING_APPROVAL_STAGE_PROMOTION = "PROMOTION"
CHANNEL_TYPE_INSTORE = "INSTORE"
PRE_CHECK_STATUS_FAIL = "FAIL"
BOOKING_NOT_FOUND = "booking_not_found"
CAMPAIGN_END_DATE_MISSING = "campaign_end_date"
CAMPAIGN_END_DATE_INVALID = "invalid_campaign_end_date"
CAMPAIGN_END_DATE_THRESHOLD = "campaign_end_date_threshold"
# ------------Overlapping campaign post-period presence------------
# Post week 1 presence as a fraction of the live weekly spend rate, then decayed weekly.
OVERLAP_POST_PRESENCE_START_RATE = 0.30
OVERLAP_POST_PRESENCE_WEEKLY_DECAY = 0.70
PRODUCT_TYPE_BRAND = "BRAND"
PRODUCT_TYPE_OFFER = "OFFER"
OVERLAP_PRODUCT_TYPES = [PRODUCT_TYPE_BRAND, PRODUCT_TYPE_OFFER]
# ------------Booking Evaluation Alert Parameters------------
BOOKING_EVALUATION_DAYS_THRESHOLD = 25  # Number of days to look ahead for campaign evaluations
SLACK_MESSAGE_TABLE_DISPLAY_LIMIT = 10  # Maximum number of blacklist records to display in Slack alerts

# ------------CAMPAIGN VALIDATION FAILURE CODES------------
CAMPAIGN_VALIDATION_FAILURE_CODES: dict[str, str] = {
    "501": "invalid campaign ID",
    "502": "invalid marketing channel",
    "503": "invalid marketing subchannel",
    "504": "invalid channel type",
    "505": "missing booking media live start date",
    "506": "missing booking media live end date",
    "507": "missing booking item CD list",
    "508": "invalid SKU ID",
    "509": "in store marketing channel is missing the store list",
    "510": "more item_cd in BDV booking than in campaign product type",
    "511": "fewer item_cd in BDV booking than in campaign product type",
}

# ------------ Experimentations ------------

BUCKETS_BY_SOURCE_TYPE = {
    "experiment": ["measurement-dev-experiment"],
    "standard": ["measurement-dev-snowflake-unload", "measurement-dev-etl-output"],
}

# ------------LEGACY PERFORMANCE TABLE PARAMETERS------------
TIME_PERIOD = (2, 3)  # This represents the during and post period
PRODUCT_TYPE_NO = 2   # This represents the product type, 2 means 'brand' for which the legacy performance table is built
EXPOSED_COST_ESTIMATE = 0.08  # This value is a fallback cost estimate per impression used to calculate the exposed cost when the actual cost data is missing for a campaign. This is based on what the Analytics team use

# ------------CAMPAIGN PRODUCT TYPE PARAMETERS------------
# These filters are passed into the campaign product type script depending on what run type is used when triggering the DAG.]
# The script then uses these filters to determine which campaigns to include in the output.
CP_POLLEN_FILTER = 'pollen'
CP_DTP_FILTER = 'dtp'
CP_EMULATION_FILTER = 'prod_emulation'

# ------------INCREMENTALITY ELIGIBILITY VALIDATION PARAMETERS------------
CONSECUTIVE_SALES_WEEKS = 52

# ------------POLLEN TEST Bookings in PROD BDV EXCLUSION LIST------------
# This is a list of brands to exclude in our BDV Production table as they are tests and shouldn't be consumed in our runs.
# TODO: Temporary fix - filter out test bookings and test brands in production.
# Pollen team will provide a measurement-ready flag in the future, at which point this should be removed.


class EventName(enum.Enum):
    """Customer event type enumeration used across pipeline and user journey logic."""
    TOUCHPOINT = 'touchpoint'
    TRANSACTION = 'transaction'


# -------- Pipeline Automation -----------
class BookingStatus(str, enum.Enum):
    """Booking statuses for the different phases of a booking, across the pipeline."""
    READY = "READY"
    IN_PROGRESS = "IN PROGRESS"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
