import json
from typing import Dict, List, Optional, Tuple
from datetime import date, datetime
import pendulum
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from js_snowflake.hooks.snowflake import SnowflakeKeyArnHook as SnowflakeHook
from airflow.sdk import Variable

from helpers.constants import (
    SNOWFLAKE_CONN_ID,
    SNOWFLAKE_TABLE_IDENTIFIER_PATTERN,
    POLLEN_RUN_TYPE,
    PROD,
    EvaluationPhase,
    DURING_METADATA_PATH_KEYS,
)
from helpers.utils import normalize_ids
from helpers.booking_approval import in_clause


def validate_snowflake_table_identifier(table: str) -> None:
    if not SNOWFLAKE_TABLE_IDENTIFIER_PATTERN.fullmatch(table):
        raise ValueError(f"Invalid Snowflake table identifier: {table}")


def get_unified_platform_database(env: str) -> str:
    return 'UNIFIED_PLATFORM_PROD' if env == PROD else 'UNIFIED_PLATFORM_DEV'


class MeasurementSnowflakeOperator(SQLExecuteQueryOperator):
    """
    This operator just adds an extra round of Jinja templating to the standard SnowflakeOperator which
    allows us to handle a special case.
    We have two set up steps at the beginning which serve to push ASPIRE table names and the various s3
    paths we require into the XCOM table for the dag run.

    This means the paths for that dag run would not be changed if the underlying code is updated, UNLESS
    someone re-runs the setup tasks that push the table names and paths into the XCOM table. This helps us
    maintain idempotency, but in order to render table names in SQL we need two rounds of Jinja templating.
    e.g. consider this line at the top of the l2_transactions.sql:
    COPY INTO {{ get_path('l2_transactions_query', s3=False) }}

    The get_path() macro is a convenience function which returns a string of the xcom to pull, in this example:
    '@measurement_[dev|prod]stage/{{task_instance.xcom_pull(task_ids="configure_paths", key="l2_transactions_query")}}'
    where [dev|prod] depends on which environment the DAG is running.
    This requires templating a second time to replace the returned {{ }} string, which the becomes:
    '@measurement_[dev|prod]_stage/some_correlation_id/l2_transactions_query'

    So assuming we were running in dev, with the correlation_id 12345-abcde the templating would go like this:
    START:  COPY INTO {{ get_path('l2_transactions_query', s3=False) }}
    FIRST:  COPY INTO @measurement_dev_stage/{{task_instance.xcom_pull(task_ids="configure_paths", key="l2_transactions_query")}}
    SECOND: COPY INTO @measurement_dev_stage/12345-abcde/l2_transactions_query
    """
    ui_color = "#fdb462"  # Sainsbury's orange!

    def __init__(self, *, conn_id: str = SNOWFLAKE_CONN_ID, **kwargs) -> None:
        super().__init__(conn_id=conn_id, **kwargs)

    def pre_execute(self, context):
        self.log.info('Rendering templates')
        context['ti'].render_templates()


def normalize_snowflake_date(value) -> str:
    """Normalizes a Snowflake date value into a consistent string format 'YYYY-MM-DD'"""
    if isinstance(value, datetime):
        return pendulum.instance(value).to_date_string()
    if isinstance(value, date):
        return pendulum.date(value.year, value.month, value.day).to_date_string()

    return pendulum.parse(str(value)).to_date_string()


def get_max_unified_campaign_date(
    campaign_ids: str | List[str] | Tuple[str, ...] | None,
    run_type: str,
    pollen_table: str,
    dtp_table: str,
    date_column: str,
) -> Optional[str]:
    """ Return the latest campaign date for the selected campaign IDs """

    selected_campaign_ids = normalize_ids(campaign_ids)
    if not selected_campaign_ids:
        return None

    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
    table = pollen_table if run_type == POLLEN_RUN_TYPE else dtp_table
    campaign_id_column = 'job_bag_number'
    formatted_campaign_ids = ", ".join(f"'{campaign_id}'" for campaign_id in selected_campaign_ids)

    result: List[Tuple] = hook.get_records(
        f"""
        SELECT MAX({date_column}) as relevant_end_dt
        FROM {table}
        WHERE {campaign_id_column} IN ({formatted_campaign_ids})
        """
    )

    if not result or result[0][0] is None:
        return None

    return normalize_snowflake_date(result[0][0])


def get_max_unified_campaign_end_date(
        campaign_ids: str | List[str] | Tuple[str, ...] | None,
        run_type: str,
        pollen_table: str,
        dtp_table: str,
) -> Optional[str]:
    return get_max_unified_campaign_date(
        campaign_ids=campaign_ids,
        run_type=run_type,
        pollen_table=pollen_table,
        dtp_table=dtp_table,
        date_column='campaign_end_dt',
    )


def get_max_unified_post_campaign_date(
        campaign_ids: str | List[str] | Tuple[str, ...] | None,
        run_type: str,
        pollen_table: str,
        dtp_table: str,
) -> Optional[str]:
    return get_max_unified_campaign_date(
        campaign_ids=campaign_ids,
        run_type=run_type,
        pollen_table=pollen_table,
        dtp_table=dtp_table,
        date_column='post_campaign_dt',
    )


def check_if_we_should_run_post_campaign_period(run_date: str, table_name: str) -> bool:
    """
    If given run_date is in month 1 (January), AND if table_name does not yet have data for previous year, return True;
    else return False
    """
    date_ob = pendulum.from_format(run_date, 'YYYY-MM-DD')
    current_month = date_ob.month
    previous_year = date_ob.subtract(years=1).year

    if current_month != 1:
        print("It is not January. Skipping post_campaign_period SQL execution.")
        return False

    validate_snowflake_table_identifier(table_name)
    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
    result: List[Tuple[int]] = hook.get_records(
        f"""
        SELECT 1
        FROM {table_name}
        WHERE YEAR_OF_TRANSACTION = %(previous_year)s LIMIT 1
        """,
        parameters={"previous_year": previous_year},
    )

    if any(result):
        print("Previous year's data already exists. Skipping post_campaign_period SQL execution.")
        return False

    print(f"No data found for year {previous_year} in post_campaign_period table {table_name}, and current month is {current_month} - will run SQL to create it...")
    return True


def resolve_during_correlation_id(
        configured_during_cid: str,
        configured_campaign_id: str,
        table: str,
        run_type: str,
) -> str:
    """
    Resolve the "during" correlation ID for a given campaign.

    This function returns the latest correlation ID associated with the provided
    campaign ID by querying the measurement campaign execution table in Snowflake.
    If a specific correlation ID is already configured (i.e., not set to `"latest"`),
    the function returns it directly and logs that it was used.

    When `"latest"` is specified, the function looks up the most recent record
    (based on `load_ts`) where:
        • the campaign identifier matches (`booking_id` for POLLEN runs, otherwise
          `job_bag_number`)
        • the campaign duration equals `"during"`

    If no corresponding record is found, a `ValueError` is raised.

    Parameters
    ----------
    configured_during_cid : str
        The "during" correlation ID specified in configuration.
        If equal to `"latest"`, the function will attempt to fetch the newest
        correlation ID from Snowflake. Otherwise, the provided value is returned
        without querying Snowflake.

    configured_campaign_id : str
         This is the booking_id/job bag number provided as part of DAG parameter
         when kicking off the pipeline.

    table : str
        Name of the Snowflake table containing campaign execution data.

    run_type : str
        The type of run being executed. Determines which column is used as the
        campaign identifier. When equal to `POLLEN_RUN_TYPE`, `booking_id` is used;
        otherwise `job_bag_number`.

    Returns
    -------
    str
        The resolved correlation ID—either the configured value or the latest value
        retrieved from Snowflake.
    """

    if configured_during_cid != 'latest':
        print(f"Using configured correlation id for this post run: {configured_during_cid}")
        return configured_during_cid
    else:
        validate_snowflake_table_identifier(table)
        hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
        col_name = "booking_id" if run_type == POLLEN_RUN_TYPE else "job_bag_number"
        result: List[Tuple[int]] = hook.get_records(
            f"""
            select correlation_id
            from {table}
            where {col_name} = %(campaign_id)s
            and lower(campaign_duration) = lower(%(phase)s)
            order by load_ts desc
            limit 1
            """,
            parameters={
                "campaign_id": configured_campaign_id,
                "phase": EvaluationPhase.DURING.value,
            },
        )
        if not result or result[0][0] is None:
            raise ValueError(
                f"unable to fetch correlation id for campaign "
                f"{configured_campaign_id} in table {table}. "
                f"Please check that the campaign id is correct and that "
                f"there is data in the table for that campaign id."
            )

        return result[0][0]


def resolve_used_new_brand_logic(during_ci: str, campaign_id: str, env: str) -> bool:
    """Return whether the configured or latest DURING run used new brand logic."""
    database = get_unified_platform_database(env)
    table = f'{database}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_METADATA'
    validate_snowflake_table_identifier(table)
    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)

    if during_ci == 'latest':
        query = f"""
            SELECT additional_metadata
            FROM {table}
            WHERE booking_id = %(campaign_id)s
              AND LOWER(evaluation_period) = LOWER(%(phase)s)
              AND LOWER(pipeline_status) = 'completed'
            ORDER BY load_ts DESC
            LIMIT 1
        """
        parameters = {
            'campaign_id': campaign_id,
            'phase': EvaluationPhase.DURING.value,
        }
    else:
        query = f"""
            SELECT additional_metadata
            FROM {table}
            WHERE correlation_id = %(correlation_id)s
              AND LOWER(evaluation_period) = LOWER(%(phase)s)
            ORDER BY load_ts DESC
            LIMIT 1
        """
        parameters = {
            'correlation_id': during_ci,
            'phase': EvaluationPhase.DURING.value,
        }

    result: List[Tuple[object]] = hook.get_records(query, parameters=parameters)
    return parse_used_new_brand_logic(result[0][0]) if result else False


def get_metadata_paths_by_correlation_id(
        correlation_id: str,
        env: str,
) -> Dict[str, object]:
    """Return PATHS for a metadata lookup by correlation id."""
    database = get_unified_platform_database(env)
    table = f'{database}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_METADATA'
    validate_snowflake_table_identifier(table)

    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
    result: List[Tuple[object]] = hook.get_records(
        f"""
        SELECT OBJECT_CONSTRUCT_KEEP_NULL({", ".join(
            f"'{key}', paths:{key}::STRING"
            for key in DURING_METADATA_PATH_KEYS
        )}) AS previous_paths
        FROM {table}
        WHERE correlation_id = %(correlation_id)s
        ORDER BY load_ts DESC
        LIMIT 1
        """,
        parameters={
            'correlation_id': correlation_id,
        },
    )

    if not result or result[0][0] is None:
        raise ValueError(
            f'No metadata PATHS found for correlation_id={correlation_id}'
        )

    previous_paths = (
        json.loads(result[0][0])
        if isinstance(result[0][0], str)
        else result[0][0]
    )
    return previous_paths


def parse_used_new_brand_logic(additional_metadata) -> bool:
    metadata = additional_metadata
    if isinstance(metadata, str):
        try:
            metadata = json.loads(metadata)
        except (TypeError, json.JSONDecodeError):
            return False
    return isinstance(metadata, dict) and metadata.get('used_new_brand_logic') is True


def check_brand_logic_consistency(
        booking_id: str,
        during_correlation_id: str,
        table: str,
) -> bool:
    """
    Checks for inconsistent brand-logic correlation id selection on POST runs.

    Returns False (validation failure, to be branched to a Slack skip-alert instead of
    hard-failing the pipeline) when the booking already has a completed DURING run using
    new brand logic, but this POST run is configured against a legacy during_correlation_id
    for that booking. Re-running POST against a during_correlation_id that has already
    completed a POST run (legacy or new) is intentionally allowed, e.g. to recover from a
    failed/emulated POST run.
    """
    validate_snowflake_table_identifier(table)

    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
    during_rows: List[Tuple[str, object]] = hook.get_records(
        f"""
        SELECT correlation_id, additional_metadata
        FROM {table}
        WHERE booking_id = %(booking_id)s
          AND LOWER(evaluation_period) = LOWER(%(phase)s)
          AND LOWER(pipeline_status) = 'completed'
          AND LOWER(run_type) = LOWER(%(run_type)s)
        """,
        parameters={
            "booking_id": booking_id,
            "phase": EvaluationPhase.DURING.value,
            "run_type": POLLEN_RUN_TYPE,
        },
    )

    if not during_rows:
        return True

    used_new_brand_logic_by_cid = {
        row[0]: parse_used_new_brand_logic(row[1]) for row in during_rows
    }
    any_during_used_new_logic = any(used_new_brand_logic_by_cid.values())
    current_correlation_used_new_logic = used_new_brand_logic_by_cid.get(during_correlation_id, False)

    if any_during_used_new_logic and not current_correlation_used_new_logic:
        print(
            f"Booking {booking_id} already has a completed DURING run using new brand logic, "
            f"but this POST run is configured against legacy during_correlation_id="
            f"{during_correlation_id}. Re-run POST against the correlation id of the "
            f"new-brand-logic DURING run instead."
        )
        return False

    return True


def count_legacy_brand_booking_registry_rows(table: str) -> int:
    """Returns the number of bookings currently requiring legacy EAN_BR brand logic."""
    validate_snowflake_table_identifier(table)
    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
    result: List[Tuple[int]] = hook.get_records(f"SELECT COUNT(*) FROM {table}")
    return int(result[0][0]) if result and result[0][0] is not None else 0


def check_campaign_data_exists(
        booking_id: str,
        table: str,
        run_type: str,
        evaluation_phase: EvaluationPhase) -> str:
    """
    Get the correlation ID for a selected campaign.

    This function retrieves the correlation ID associated with the provided
    campaign ID by querying the measurement campaign execution table in Snowflake.
    If a specific correlation ID is already configured (i.e., not set to `"latest"`),
    the function returns it directly and logs that it was used.

    When `"latest"` is specified, the function looks up the most recent record
    (based on `load_ts`) where:
        • the campaign identifier matches (`booking_id` for POLLEN runs, otherwise
          `job_bag_number`)
    """
    if Variable.get('MEASUREMENT_ENVIRONMENT') == PROD:
        print("Not applicable for prod run")
        return None

    validate_snowflake_table_identifier(table)
    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
    result: List[Tuple[int]] = hook.get_records(
        f"""
        SELECT correlation_id
        FROM {table}
        WHERE
        booking_id = %(booking_id)s
        AND evaluation_period = %(evaluation_phase)s
        and run_type = %(run_type)s
        AND PARSE_JSON(additional_metadata):experimentation_run::STRING = 'true'
        AND load_ts >= DATEADD(day, -60, CURRENT_TIMESTAMP())
        order by load_ts desc
        limit 1
        """,
        parameters={
            "booking_id": booking_id,
            "evaluation_phase": evaluation_phase.value,
            "run_type": run_type,
        },
    )

    if not result or result[0][0] is None:
        return None

    return result[0][0]


def has_campaign_ended(
        booking_id: str,
        table: str,
        run_date: str,
        evaluation_phase: str,
) -> Tuple[bool, str]:
    """
    Checks whether the campaign for the given booking ID has ended relative to run_date.

    For during-period runs, checks campaign_end_dt.
    For post-period runs, checks post_campaign_dt.

    Returns a tuple (has_ended, incomplete_campaign_id):
        - (True, '')          if the campaign has ended (no future-dated rows found)
        - (False, booking_id) if the campaign has NOT ended (end date is still in the future)

    Used by validate_campaign_end_date_passed in config_validation.py to block prod runs
    before a campaign (or its post-campaign window) has ended.
    """
    campaign_end_date = 'post_campaign_dt' if evaluation_phase == EvaluationPhase.POST.value else 'campaign_end_dt'

    validate_snowflake_table_identifier(table)
    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)

    result: List[Tuple] = hook.get_records(
        f"""
        SELECT DISTINCT job_bag_number, MAX({campaign_end_date}) AS relevant_end_dt
        FROM {table}
        WHERE job_bag_number = %(booking_id)s
            AND {campaign_end_date} > %(run_date)s::DATE
        GROUP BY job_bag_number
        """,
        parameters={"booking_id": booking_id, "run_date": run_date},
    )

    if result:
        # Rows returned means end date is in the future — campaign has NOT ended
        return (False, booking_id)

    # No rows means end date has passed — campaign has ended
    return (True, '')


def _get_booking_reference_dates_by_booking(booking_ids: List[str], booking_table: str) -> Dict[str, str]:
    """Return the latest resolved item reference date for each supplied booking ID."""
    validate_snowflake_table_identifier(booking_table)
    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
    result = hook.get_records(
        f"""
        WITH booking AS (
            SELECT
                booking_id,
                MIN(booking_media_live_start_dt) AS booking_start_dt,
                -- Avoid grouping by a potentially large item list; assumes it is identical for all rows of a booking.
                ANY_VALUE(booking_item_cd_list) AS booking_item_cd_list
            FROM {booking_table}
            WHERE booking_id IN ({in_clause(booking_ids)})
            GROUP BY booking_id
        ),
        item_reference_dates AS (
            SELECT
                booking.booking_id,
                COALESCE(
                    COALESCE(
                        TRY_TO_TIMESTAMP(flattened.value:addedOn::VARCHAR),
                        TO_TIMESTAMP(TRY_TO_NUMBER(flattened.value:addedOn::VARCHAR), 3)
                    )::DATE,
                    booking.booking_start_dt
                ) AS item_ref_dt
            FROM booking,
            LATERAL FLATTEN(input => booking.booking_item_cd_list, OUTER => TRUE) AS flattened
        )
        SELECT
            booking_id,
            MAX(item_ref_dt) AS booking_reference_date
        FROM item_reference_dates
        GROUP BY booking_id
        """
    )

    return {
        str(row[0]): str(row[1])
        for row in result
        if row and row[0] is not None and row[1] is not None
    }


def resolve_booking_reference_date(
        booking_ids: List[str],
        booking_table: str,
        fallback_booking_table: Optional[str] = None,
) -> str:
    """
    Resolve the latest item reference date across the supplied Pollen booking IDs.

    An item's reference date is its JSON ``addedOn`` timestamp (as an ISO timestamp
    or millisecond epoch). Historical items without ``addedOn`` use their booking's
    media live start date instead.

    When a booking is missing from the primary booking table (for example, a dev run
    that needs prod test bookings), the optional ``fallback_booking_table`` is queried
    for only the missing booking IDs. If the same booking exists in both sources, the
    primary table always wins i.e. if you're running in dev, dev or then in prod, prod
    """
    resolved_dates = _get_booking_reference_dates_by_booking(
        booking_ids=booking_ids,
        booking_table=booking_table,
    )
    # We currently don't suppport multi-booking runs, however we can accept multiple bookings so this resolves for that as well
    missing_booking_ids = [booking_id for booking_id in booking_ids if booking_id not in resolved_dates]

    # This prevents prod runs for re querying the same table
    if missing_booking_ids and fallback_booking_table and fallback_booking_table != booking_table:
        fallback_dates = _get_booking_reference_dates_by_booking(
            booking_ids=missing_booking_ids,
            booking_table=fallback_booking_table,
        )
        resolved_dates.update(fallback_dates)

    if not resolved_dates:
        raise ValueError(
            "Unable to resolve a booking reference date for Pollen booking IDs: "
            f"{', '.join(booking_ids)}."
        )

    return max(resolved_dates.values())
