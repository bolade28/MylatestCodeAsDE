from typing import Any, Dict, List, Optional, Tuple

import pendulum

from helpers.constants import (
    BOOKING_APPROVAL_STAGE_PROMOTION,
    BOOKING_NOT_FOUND,
    CAMPAIGN_DURATION_DURING,
    CAMPAIGN_DURATION_POST,
    CAMPAIGN_END_DATE_INVALID,
    CAMPAIGN_END_DATE_MISSING,
    CAMPAIGN_END_DATE_THRESHOLD,
    PRE_CHECK_STATUS_FAIL,
)


def campaign_is_older_than_threshold(campaign_end_date: Any, run_date: Any, min_days: int) -> bool:
    """Return True if the campaign ended at least min_days before run_date, enforcing the During eligibility window."""
    campaign_end = pendulum.parse(str(campaign_end_date)).date()
    run_dt = pendulum.parse(str(run_date)).date()
    return (run_dt - campaign_end).days >= min_days


def escape_sql(value: str) -> str:
    """Escape single quotes to prevent SQL injection when building inline SQL strings."""
    return value.replace("'", "''")


def in_clause(values: List[str]) -> str:
    """Build a quoted SQL IN-clause string from a list of values, e.g. 'A', 'B', 'C'."""
    escaped = [f"'{escape_sql(v)}'" for v in values]
    return ", ".join(escaped)


# Snowflake connector %s bind placeholders; values are passed separately as parameters.
APPROVED_ROW_SQL = "SELECT %s AS booking_id, %s AS campaign_name, %s AS pipeline_stage"


def empty_rows_sql() -> str:
    """Return a no-op SELECT used when no bookings are approved, so the INSERT SQL remains valid."""
    return (
        "SELECT NULL AS booking_id, NULL AS campaign_name, NULL AS pipeline_stage "
        "WHERE 1 = 0"
    )


def build_pre_check_map(pre_check_rows: List[Any]) -> Dict[str, Dict[str, Any]]:
    """Group the booking pre-check SQL output by booking ID."""
    booking_checks: Dict[str, Dict[str, Any]] = {}
    for row in pre_check_rows or []:
        booking_id, campaign_name, campaign_end_dt, category, status, reason, *_ = row
        booking_id = str(booking_id)
        booking = booking_checks.setdefault(
            booking_id,
            {
                "campaign_name": str(campaign_name) if campaign_name is not None else booking_id,
                "campaign_end_dt": campaign_end_dt,
                "checks": [],
            },
        )
        booking["checks"].append(
            {
                "category": str(category),
                "status": str(status),
                "reason": str(reason),
            }
        )
    return booking_checks


def campaign_end_date_failure(
    campaign_end_date: Any, run_date: str, threshold_days: int
) -> Optional[Tuple[str, str]]:
    """Return (category, reason) when the campaign end date blocks approval, else None."""
    if campaign_end_date in (None, ""):
        return CAMPAIGN_END_DATE_MISSING, "Campaign end date is missing."
    try:
        passes_threshold = campaign_is_older_than_threshold(campaign_end_date, run_date, threshold_days)
    except ValueError:
        return CAMPAIGN_END_DATE_INVALID, "Campaign end date cannot be parsed."
    if not passes_threshold:
        return CAMPAIGN_END_DATE_THRESHOLD, f"Campaign end date is within the {threshold_days}-day threshold."
    return None


def evaluate_pre_checks(
    requested_booking_ids: List[str],
    pre_check_rows: List[Any],
    run_date: str,
    threshold_days: int,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, str]], str, List[str]]:
    """Approve bookings without failed checks and build parameterised tracker rows for the passing bookings."""
    booking_checks = build_pre_check_map(pre_check_rows)
    promoted: List[Dict[str, Any]] = []
    rejected: List[Dict[str, str]] = []
    approved_rows_sql_parts: List[str] = []
    approved_row_params: List[str] = []

    def record_failure(booking_id: str, category: str, reason: str) -> None:
        rejected.append(
            {
                "booking_id": booking_id,
                "stage": BOOKING_APPROVAL_STAGE_PROMOTION,
                "category": category,
                "reason": reason,
            }
        )

    for booking_id in requested_booking_ids:
        booking = booking_checks.get(booking_id)
        if not booking:
            failures = [{"category": BOOKING_NOT_FOUND, "reason": "Booking not found in BDV."}]
        else:
            failures = [check for check in booking["checks"] if check["status"] == PRE_CHECK_STATUS_FAIL]

        if failures:
            for failure in failures:
                record_failure(
                    booking_id,
                    failure["category"],
                    failure["reason"],
                )
            continue

        end_date_failure = campaign_end_date_failure(booking["campaign_end_dt"], run_date, threshold_days)
        if end_date_failure:
            record_failure(booking_id, *end_date_failure)
            continue

        for stage in (CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST):
            approved_rows_sql_parts.append(APPROVED_ROW_SQL)
            approved_row_params.extend([booking_id, booking["campaign_name"], stage])
        promoted.append(
            {
                "booking_id": booking_id,
                "campaign_name": booking["campaign_name"],
                "stages": [CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST],
            }
        )

    approved_rows_sql = " UNION ALL ".join(approved_rows_sql_parts) if approved_rows_sql_parts else empty_rows_sql()
    return promoted, rejected, approved_rows_sql, approved_row_params
