from enum import Enum
from typing import Dict, Optional
from dataclasses import dataclass, field

import helpers.utils as pg_utils
from helpers.sns import SNS
from helpers.utils import MetricsPublisher, PGDataType, current_timestamp


@dataclass
class PipelineMetadata():
    correlation_id: str
    name: str
    run_date: str
    run_by: str
    dags_base_commit: str
    pipelines_base_commit: str
    pipelines_git_hashes: list
    dags_git_hashes: list
    start_time: str
    end_time: str
    pipeline_status: str
    deployment_status: str
    run_type: str
    booking_id: str
    validated_booking_id: str
    paths: str
    campaign_date: Dict[str, str]
    evaluation_period: str
    campaign_end_date: str
    airflow_platform: str
    additional_metadata: Dict[str, str]
    during_correlation_id: Optional[str] = None
    create_timestamp: str = field(default_factory=current_timestamp)
    event_schema: Dict = field(init=False)

    def __post_init__(self):
        self.event_schema = vars(PipelineMetadataSchema())


class WriteOperation(Enum):
    """
    Database write operation types.

    INSERT: Insert multiple records with same correlation_id (special cases only)
    UPSERT: Insert new or update existing records (default - idempotent).
            This means if we rerun our pipeline, the existing metrics will be updated with the new values.
            In order to update already published metrics, name and correlation has to be the same.
    UPDATE: Used to update one or more columns of an existing record identified by (correlation_id, name).
    """

    INSERT = "insert"
    UPSERT = "upsert"
    UPDATE = "update"


class PipelineMetadataSchema():
    def __init__(
            self,
            table_name: str = 'pipelines_metadata',
            schema: str = 'metrics',
            write_operation: WriteOperation = WriteOperation.UPSERT
    ):
        self.table_schema = pg_utils.get_schema([
            pg_utils.PostgreSQLColumn("correlation_id", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("name", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("run_date", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("booking_id", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("campaign_end_date", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("evaluation_period", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("run_by", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("dags_base_commit", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("pipelines_base_commit", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("start_time", PGDataType.timestamp, True),
            pg_utils.PostgreSQLColumn("end_time", PGDataType.timestamp, True),
            pg_utils.PostgreSQLColumn("pipelines_git_hashes", PGDataType.jsonb, True),
            pg_utils.PostgreSQLColumn("dags_git_hashes", PGDataType.jsonb, True),
            pg_utils.PostgreSQLColumn("pipeline_status", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("deployment_status", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("run_type", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("validated_booking_id", PGDataType.jsonb, True),
            pg_utils.PostgreSQLColumn("during_correlation_id", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("campaign_date", PGDataType.jsonb, True),
            pg_utils.PostgreSQLColumn("airflow_platform", PGDataType.text, True),
            pg_utils.PostgreSQLColumn("additional_metadata", PGDataType.jsonb, True),
            pg_utils.PostgreSQLColumn("paths", PGDataType.jsonb, True),
            pg_utils.PostgreSQLColumn("create_timestamp", PGDataType.timestamp, True),
            pg_utils.PostgreSQLColumn("load_timestamp", PGDataType.timestamp, True)
        ])
        # Change table name if INSERT operation is selected
        if write_operation == WriteOperation.INSERT:
            self.table_name = f"{table_name}_insert"
        else:
            self.table_name = table_name
        self.schema = schema
        self.write_operation = write_operation.value


def publish_metric_update(
        correlation_id: str,
        table_name: str,
        name: str,
        updates: Dict,
        column_types: Optional[Dict[str, str]] = None,
        schema_name: str = 'metrics'
):
    """
    Patches specific columns on an existing metric row identified by (correlation_id, name).
    column_types only needs entries for non-text columns (e.g. PGDataType.timestamp, .jsonb, .bigint).
    Publish-only: this cannot confirm a matching row exists downstream, so a missing row is a silent no-op.
    """
    publisher = MetricsPublisher(topic_arn=SNS().metrics_topic_arn())

    event = {
        'correlation_id': correlation_id,
        'name': name,
        'load_timestamp': current_timestamp(),
        **updates,
        'event_schema': {
            'table_name': table_name,
            'schema': schema_name,
            'write_operation': WriteOperation.UPDATE.value,
            'table_schema': column_types or {}
        }
    }

    publisher.publish_to_sns(event, message_subject="Metric Update Event")

    return "published metric update"
