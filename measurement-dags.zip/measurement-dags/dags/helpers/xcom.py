from airflow.sdk import task
from airflow.providers.standard.operators.python import get_current_context
from helpers.constants import (
    DURING_METADATA_PATH_KEYS,
    TASK_INSTANCE_NOT_AVAILABLE_ERROR,
    XComKeys,
)
from helpers.setup import (
    configure_aws_user,
    configure_campaign_end_date,
    configure_campaign_start_date,
    configure_campaigns,
    configure_ci_of_during_run,
    configure_compute_units,
    configure_correlation_id,
    configure_dag_run_source,
    configure_emulation_run,
    configure_master_instance_type,
    configure_mlflow,
    configure_model_start_end_dates,
    configure_paths,
    configure_persist_dataset,
    configure_pipelines_version,
    configure_post_period_end_date,
    configure_previous_correlation_id,
    configure_run_incrementality_v2,
    configure_run_type,
    configure_sns,
    configure_snowflake_stage,
    configure_snowflake_tables,
    configure_used_new_brand_logic,
    get_airflow_platform,
    evaluation_phase,
    resolve_previous_paths,
)
from helpers.utils import get_pipelines_commit_hash, get_dag_commit_hash

#
# ---- Utility functions
#
#


def get_snowflake_unload_stage_name() -> str:
    return f"task_instance.xcom_pull(task_ids='setup_tasks.{configure_snowflake_stage.__wrapped__.__name__}', key='stage')"


def get_snowflake_unload_s3_path() -> str:
    return f"task_instance.xcom_pull(task_ids='setup_tasks.{configure_snowflake_stage.__wrapped__.__name__}', key='bucket')"


"""
The get_...() functions all return the correct template to use when pulling an xcom variable.
A variable gets substituted in at run-time during Jinja templating, so you may specify them
in the templated fields of any operator, e.g. consider:

    PythonOperator(task_id='some_task', python_callable=print, op_kwargs={"x": get_compute_units()})

get_compute_units() returns the string:

    f'{{task_instance.xcom_pull(task_ids="{compute_units.__wrapped__.__name__}", key="return_value")}}'

When the Python Operator is launched, the op_kwargs() is templated, so Jinja will render
everything inside the {{ }}, in this case it pulls and returns the appropriate value from
the xcom table. The function that is run by the operator is then equivalent to:

    print(3456)

In order to pull the xcom, the pulling task must have the correct task_id. In an @task decorated
function, this is the name of the decorated function, which is why we use the convention

    some_function.__wrapped__.__name__

When referring to a task id - if someone changes the name of the decorated function, this should
break the import in this file, rather than silently returning None during Jinja templating when that
task cannot be found in the xcom table for the current dag run.
"""


def get_all_paths_for_meta_data():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_paths.__wrapped__.__name__}", key="return_value") | replace("\\\'", "\\\"")}}}}'


def get_ci():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_correlation_id.__wrapped__.__name__}", key="return_value")}}}}'


def get_cluster_id():
    return '{{ task_instance.xcom_pull(task_ids="create_emr_cluster", key="return_value") }}'


def get_compute_units():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_compute_units.__wrapped__.__name__}", key="return_value")}}}}'


def get_pipelines_version():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_pipelines_version.__wrapped__.__name__}", key="return_value")}}}}'


def get_path(path: str, experiment_name: str = None):
    if experiment_name:
        return get_experiment_path(path, experiment_name)
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_paths.__wrapped__.__name__}", key="{path}")}}}}'


def get_sns(topic: str):
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_sns.__wrapped__.__name__}", key="{topic}")}}}}'


def get_stage(path: str):
    bucket = get_snowflake_unload_s3_path()
    stage = get_snowflake_unload_stage_name()
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_paths.__wrapped__.__name__}", key="{path}") | replace({bucket}, {stage})}}}}'


def get_table(table: str):
    """
    :param table: The name of the table you wish to template. See helpers.utils.tables for the full list of options
    :return str: The templated table name
    """
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_snowflake_tables.__wrapped__.__name__}", key="{table}")}}}}'


def get_job_flow_start_time():
    return '{{task_instance.xcom_pull(task_ids="job_flow_start_time", key="return_value")}}'


def get_campaign_start_date(period: str):
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_campaign_start_date.__wrapped__.__name__}", key="{period}")}}}}'


def get_model_start_end_dates(period: str):
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_model_start_end_dates.__wrapped__.__name__}", key="{period}")}}}}'


def get_configured_campaign(is_tag: bool = False):
    if is_tag:
        return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_campaigns.__wrapped__.__name__}", key="return_value") | replace("|", "-") | lower}}}}'
    else:
        return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_campaigns.__wrapped__.__name__}", key="return_value")}}}}'


# TODO: why do we need strip() here? can this be removed?
def get_manual_campaigns_list(type: str = None):
    """
    Dynamically pull qualified campaigns list from the correct validation group.
    Checks both 'campaign_validations' (during) and 'campaign_validations_post' (post-period).
    Returns the first non-null result.
    """
    if type == "meta_data":
        return """
    {%- set during = task_instance.xcom_pull(task_ids="campaign_validations.qualified_campaigns.qualified_campaigns_list", key="return_value") -%}
    {%- set post = task_instance.xcom_pull(task_ids="campaign_validations_post.qualified_campaigns.qualified_campaigns_list", key="return_value") -%}
    {%- set selected = during if during else post -%}
    {{ (selected.split(',') if selected else []) | tojson }}
    """.strip()
    else:
        return """
        {%- set during = task_instance.xcom_pull(task_ids="campaign_validations.qualified_campaigns.qualified_campaigns_list", key="return_value") -%}
        {%- set post = task_instance.xcom_pull(task_ids="campaign_validations_post.qualified_campaigns.qualified_campaigns_list", key="return_value") -%}
        {{ during if during else post }}
        """.strip()


# TODO: we need to update this function to grab all campaign start and end dates and return as json
def get_campaign_dates():
    """Return campaign dates as JSON object"""
    return """
    {%- set start_date = task_instance.xcom_pull(task_ids="setup_tasks.configure_model_start_end_dates", key="start_date") -%}
    {%- set end_date = task_instance.xcom_pull(task_ids="setup_tasks.configure_model_start_end_dates", key="end_date") -%}
    {{ {"start_date": start_date, "end_date": end_date} | tojson }}
    """.strip()


# ToDo: We might want to make this function dynamic even though it is only used in post-period currently
def get_manual_campaigns_list_filtered(post_camp_list="campaign_validations_post.campaign_validation.filter_manual_campaigns"):
    """
    Returns the filtered manual campaigns list that only includes campaigns that exist in the validation.
    This pulls from the campaign_validation.filter_manual_campaigns task result.
    """
    return f'{{{{task_instance.xcom_pull(task_ids="{post_camp_list}", key="return_value")}}}}'


def get_mlflow(topic: str):
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_mlflow.__wrapped__.__name__}", key="{topic}")}}}}'


def pipeline_run_type():
    # TODO: if configure_run_type() returns dict like {"run_type": <actual value>} then use key="run_type" here
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_run_type.__wrapped__.__name__}", key="return_value")}}}}'


def pipeline_run_type_name():
    """Get just the run type name in lowercase (e.g., 'pollen', 'dtp')."""
    # TODO: if configure_run_type() returns dict like {"run_type": <actual value>} then use key="run_type" here
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_run_type.__wrapped__.__name__}", key="return_value") | lower}}}}'


def get_campaign_end_date():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_campaign_end_date.__wrapped__.__name__}", key="return_value")}}}}'


def get_booking_reference_date():
    """Return the timestamp reference to be used for brand and item data.

        Branches on the setup-phase used_new_brand_logic flag, this will look whether a run is
        using new brand logic or legacy (if new brand it will use addedon date, if legacy will use current date).
    The reason is for new logic we want to keep correct brand owner at the time of the campaign run
        but for legacy we only use latest (FYI - TODO:: legacy is temporary and will be cleaned up once all
    the relevant campaigns are run)
            - DURING runs: for during we assume every new run is using new logic
      so the flag is None -> booking reference date.
      - POST runs, flag True (new-logic DURING): booking reference date.
      - POST runs, flag False (legacy DURING): the run date, so dim_item_hist resolves to the
        same current-state rows those runs previously got from dim_item.

    Trim markers are required here (unlike in get_campaign_product_type_table): this value is
    spliced inside SQL quotes as '{{ params.brand_time_reference }}', so any surrounding
    whitespace would end up inside the date literal.
    """
    reference_date = (
        'task_instance.xcom_pull(task_ids="config_and_validation.config_setup.'
        'configure_booking_reference_date", key="return_value")'
    )
    # An empty reference date only happens on DTP; configure_booking_reference_date raises for Pollen.
    return (
        f'{{%- set _ref_date = {reference_date} -%}}'
        f'{{%- set _during_used_new_brand_logic = {get_used_new_brand_logic_raw_expression()} -%}}'
        '{%- if _during_used_new_brand_logic == false or not _ref_date -%}'
        '{{ data_interval_end | ds }}'
        '{%- else -%}'
        '{{ _ref_date }}'
        '{%- endif -%}'
    )


def get_post_period_end_date():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_post_period_end_date.__wrapped__.__name__}", key="return_value")}}}}'


def get_emulation_run() -> str:
    """Return the Jinja expression used to pull the emulation run from XCom.

    The expression calls `task_instance.xcom_pull` on the task that configures
    the emulation run and retrieves its return value.
    """
    task_name = configure_emulation_run.__wrapped__.__name__
    full_task_id = f"setup_tasks.{task_name}"
    return f'{{{{task_instance.xcom_pull(task_ids="{full_task_id}", key="return_value")}}}}'


def get_is_not_emulated_run() -> str:
    """Return the Jinja expression that negates the emulation_run flag.

    This returns the inverse of emulation_run as a lowercase string ('true' or 'false').
    Useful when the Jinja template needs the logical NOT of emulation_run at render time.

    Returns:
        str: Jinja template string that evaluates to 'true' or 'false' at runtime.
    """
    inner_expr = get_emulation_run()[2:-2]  # Strip {{ }} to get inner xcom_pull
    return f'{{{{(not {inner_expr}) | string | lower}}}}'


def get_dag_run_source():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_dag_run_source.__wrapped__.__name__}", key="return_value")}}}}'


def get_git_hash(pipeline_stage: str, type: str = 'dags'):
    if type in ["dags_base", "pipelines_base"]:
        return f'{{{{ task_instance.xcom_pull(task_ids="{pipeline_stage}_checkpoint.metadata.get_git_commits", key="{type}")}}}}'
    else:
        return f'{{{{ task_instance.xcom_pull(task_ids="{pipeline_stage}_checkpoint.metadata.get_git_commits", key="{type}") | tojson}}}}'


def resolve_pipelines_version(environment: str) -> str:
    """
    Macro to resolve pipelines git commit hash value - fetches from SSM if value is 'latest',
    otherwise returns the provided value.

    Note: This function intentionally does NOT cache SSM values to ensure
    each EMR step uses the most current pipelines commit hash value. SSM parameter
    containing pieplines commit hash can be updated during pipeline run (e.g., for hotfixes),
    and we prioritise freshness over caching. AWS SSM Standard Parameters have
    unlimited free API calls with no charges, so there's no cost concern.

    This is designed to be called from Jinja templates where the actual value
    is available (not just the template string).

    Args:
        environment: The environment ('dev' or 'prod') to fetch the parameter for

    Returns:
        Either the SSM parameter value (if 'latest') or the configured custom pipelines
        hash value

    """

    # Get the actual value from XCom
    context = get_current_context()
    ti = context.get('ti')

    if ti is None:
        raise ValueError(TASK_INSTANCE_NOT_AVAILABLE_ERROR)
    pipelines_hash_value = ti.xcom_pull(
        task_ids='setup_tasks.configure_pipelines_version',
        key='return_value'
    )

    if pipelines_hash_value == "latest":
        return get_pipelines_commit_hash(environment, context)

    return pipelines_hash_value


@task()
def get_git_commits(environment: str) -> dict:

    context = get_current_context()
    git_commits = {}
    ti = context.get('ti')

    if ti is None:
        raise ValueError(TASK_INSTANCE_NOT_AVAILABLE_ERROR)

    # Refresh dags commits by calling configure_dag_version logic
    platform = get_airflow_platform()
    # get fresh dags commit hash values
    _ = get_dag_commit_hash(platform, context)

    dags_commits = ti.xcom_pull(
        key=XComKeys.DAGS_COMMIT_LIST
    )

    git_commits['dags'] = dags_commits or []

    git_commits['dags_base'] = dags_commits[0][:7] if dags_commits else None

    configured_pipelines_hash_value = ti.xcom_pull(
        task_ids='setup_tasks.configure_pipelines_version',
        key='return_value'
    )

    if configured_pipelines_hash_value == "latest":
        # get fresh pipelines commit hash value
        _ = get_pipelines_commit_hash(environment=environment, context=context)
        fresh_pipelines_hash_values = ti.xcom_pull(
            key=XComKeys.PIPELINES_COMMIT_LIST
        )
        git_commits['pipelines'] = fresh_pipelines_hash_values or []
        git_commits['pipelines_base'] = fresh_pipelines_hash_values[0][:7] if fresh_pipelines_hash_values else None
    else:
        git_commits['pipelines'] = [configured_pipelines_hash_value]
        git_commits['pipelines_base'] = configured_pipelines_hash_value

    return git_commits


def get_during_correlation_id():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_ci_of_during_run.__wrapped__.__name__}", key="return_value")}}}}'


def get_booking_approval_booking_ids_sql() -> str:
    return "{{ task_instance.xcom_pull(task_ids='prepare_approval_inputs', key='booking_ids_sql') }}"


def get_booking_approval_booking_ids() -> str:
    return "{{ task_instance.xcom_pull(task_ids='prepare_approval_inputs', key='booking_ids') }}"


def get_booking_approval_candidate_rows() -> str:
    return "{{ task_instance.xcom_pull(task_ids='query_candidate_bookings') }}"


def get_booking_approval_rows_sql() -> str:
    return "{{ task_instance.xcom_pull(task_ids='evaluate_candidate_bookings', key='approved_rows_sql') }}"


def get_eligible_booking_rows() -> str:
    return "{{ task_instance.xcom_pull(task_ids='setup_tasks.query_eligible_booking') }}"


def get_previous_path(path_key: str) -> str:
    """Get a previous-run path from the metadata lookup cache.
    This reads the dictionary returned by ``config_and_validation.config_setup.resolve_previous_paths``
    and returns the path value for the supplied key.
    """
    if path_key not in DURING_METADATA_PATH_KEYS:
        raise ValueError(
            f"Invalid path_key '{path_key}'. Expected one of: {', '.join(DURING_METADATA_PATH_KEYS)}"
        )

    task_name = resolve_previous_paths.__wrapped__.__name__
    return (
        f'{{{{task_instance.xcom_pull(task_ids="config_and_validation.config_setup.{task_name}", '
        f'key="return_value")["{path_key}"]}}}}'
    )


def get_resolved_during_correlation_id_expression() -> str:
    return 'task_instance.xcom_pull(task_ids="config_and_validation.config_setup.resolve_during_correlation_id", key="return_value")'


def get_resolved_during_correlation_id() -> str:
    return f'{{{{{get_resolved_during_correlation_id_expression()}}}}}'


def get_used_new_brand_logic_for_during():
    """Return the conditional Jinja fragment for the POST DURING-brand field.

    The ``setup_tasks.configure_used_new_brand_logic`` task reads
    the DURING run's metadata and returns either ``True`` or ``False``. This helper
    pulls that XCom value so POST metadata records the field only when new logic was
    used. If the value is ``False``, missing, or invalid, the field is omitted and
    legacy EAN_BR logic is implied.
    """
    return f'''
            {{% if {get_used_new_brand_logic_raw_expression()} == true %}}
            "used_new_brand_logic_for_during": true,
            {{% endif %}}
            '''


def get_used_new_brand_logic_expression() -> str:
    """Return the complete Jinja expression for the brand-logic flag from setup_tasks."""
    return f'{{{{{get_used_new_brand_logic_raw_expression()}}}}}'


def get_used_new_brand_logic_raw_expression() -> str:
    """Return the unwrapped XCom expression for use inside Jinja statements.

    The expression reads whether the DURING run used new brand logic or legacy logic
    from the setup-phase XCom value.
    """
    return f'task_instance.xcom_pull(task_ids="setup_tasks.{configure_used_new_brand_logic.__wrapped__.__name__}", key="return_value")'


def get_current_aws_user():
    """Get the current AWS user's name for cluster naming and pipeline metadata."""
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_aws_user.__wrapped__.__name__}", key="return_value")}}}}'


def get_random_master_instance_type():
    """Get a random master instance type based on weights.
    This is to support multiple DAG runs in dev environment where we can hit capacity issues.
    Once we fix parallelisation issues linked to campaign/job bag number, we can remove this and just use a single instance type.
    """
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_master_instance_type.__wrapped__.__name__}", key="return_value")}}}}'


def get_experimentation_flag(as_string: bool = False):
    """Get the experimentation flag value to determine if we are running in experimentation mode or not."""
    experiment_flag = f'task_instance.xcom_pull(task_ids="setup_tasks.{configure_persist_dataset.__wrapped__.__name__}", key="return_value")'
    if as_string:
        return f'{{{{{experiment_flag} | lower}}}}'
    return f'{{{{{experiment_flag}}}}}'


def get_evaluation_phase():
    """Get the evaluation phase (during or post) for the current run."""
    return f'{{{{task_instance.xcom_pull(task_ids="exp_setup_tasks.{evaluation_phase.__wrapped__.__name__}", key="return_value")}}}}'


def get_validation_check_details(task_id: str):
    return f'{{{{task_instance.xcom_pull(task_ids="{task_id}", key="return_value")}}}}'


# TODO: do the same for all other validation checks instead of directly using xcom_pull
def get_booking_id_validation_results(parent_group_id: str):
    """
    Get booking ID validation results from xcom at runtime.

    :param parent_group_id: The parent task group ID
    :return: The validation results from check_booking_id task
    """
    context = get_current_context()
    ti = context.get('ti')

    if ti is None:
        raise ValueError(TASK_INSTANCE_NOT_AVAILABLE_ERROR)

    return ti.xcom_pull(
        task_ids=f'{parent_group_id}.booking_id_validate.check_booking_id',
        key='return_value'
    )


def get_multi_brand_validation_results(parent_group_id: str):
    """
    Get multi-brand campaign validation results from xcom at runtime.

    :param parent_group_id: The parent task group ID
    :return: The validation results from check_multi_brand_campaigns task
    """
    context = get_current_context()
    ti = context.get('ti')

    if ti is None:
        raise ValueError(TASK_INSTANCE_NOT_AVAILABLE_ERROR)

    return ti.xcom_pull(
        task_ids=f'{parent_group_id}.campaign_multi_brand_validate.check_multi_brand_campaigns',
        key='return_value'
    )


def get_experiment_path(path: str, experiment_name: str):
    return f"""
            {{%- set p = task_instance.xcom_pull(task_ids="setup_tasks.{configure_paths.__wrapped__.__name__}", key="{path}") -%}}
            {{%- set parts = p.rsplit('/', 1) -%}}
            {{{{ parts[0] + '/results/{experiment_name}/' + parts[1] }}}}
            """.strip()


def get_experiment_details():
    return '{{task_instance.xcom_pull(task_ids="upload_and_validate_config.get_experiments_config", key="return_value") | tojson}}'


def get_booking_name():
    """
    Get the booking name for the current campaign from Snowflake, based on the configured campaign ID and run type.

    This function pulls the configured campaign ID and run type from XCom, then queries Snowflake to retrieve the corresponding booking name.
    The booking name is used for EMR cluster naming and in pipeline metadata.

    Returns:
        str: The booking name associated with the configured campaign ID and run type.
    """
    return '{{task_instance.xcom_pull(task_ids="config_and_validation.config_setup.fetch_booking_name_from_snowflake", key="return_value")}}'


def get_correlation_id_for_deletion():
    """
    Get the previous correlation ID for measurement outputs from XCom.

    This function pulls the previous correlation ID from XCom, which is used in the clear_measurement_outputs_dag to identify which measurement outputs to clear from Snowflake tables.

    Returns:
        str: The previous correlation ID for measurement outputs.
    """
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_previous_correlation_id.__wrapped__.__name__}", key="return_value")}}}}'


def get_run_incrementality_v2():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_run_incrementality_v2.__wrapped__.__name__}", key="return_value")}}}}'
