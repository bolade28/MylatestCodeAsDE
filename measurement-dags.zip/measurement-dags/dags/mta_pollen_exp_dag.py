from datetime import datetime
import logging

from airflow.sdk import dag, TaskGroup
from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import (
    get_stage,
    get_table,
    get_cluster_id,
    get_ci,
    resolve_pipelines_version,
)
from task_groups import (
    exp_setup,
    metadata_and_slack_alert,
    exp_config_validation,
)
from helpers.setup import get_airflow_platform
from helpers.constants import JOURNEY_TYPE, AIRFLOW_PLATFORM_DOCKER, POLLEN_RUN_TYPE
from helpers.emr import launch_cluster, terminate_cluster
from helpers.dag_param import DagParams
from helpers import experiments
from helpers.experiments import ExperimentConfig
from steps.attribution_model_results import attribution_model_results

logging.getLogger(__name__)

INC_TRIALS_CONFIG = "trials/mta_pollen_experiments.json"
INC_TRIALS_CONFIG_ABS = f"/home/airflow/airflow/dags/{INC_TRIALS_CONFIG}"
EXP_NAME = "mta-pollen-exp"


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule=None,
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
        "get_ci": get_ci,
        "resolve_pipelines_version": resolve_pipelines_version,
    },
    params={
        "pipelines_hash": DagParams.pipelines_hash_param,
    }
)
def mta_pollen_exp_dag():
    """
    MTA Pollen Experimentation DAG
    Should only run in non-prod environment via docker.
    config file format: See readme file
    incrementality experiment config file name and location: dags/trials/mta_pollen_experiments.json
    """

    if get_airflow_platform() != AIRFLOW_PLATFORM_DOCKER:
        logging.info("This DAG must only run via Docker.")
        return

    # Setup tasks
    setup = exp_setup.task_group()

    # Cluster management
    start_cluster = launch_cluster('mta-pollen-exp', experiment=True)
    stop_cluster = terminate_cluster(get_cluster_id())

    experiment_sources = experiments.load_experiments(INC_TRIALS_CONFIG)
    exp_config = ExperimentConfig(run_type=EXP_NAME, count=len(experiment_sources))

    # Metadata and Slack alerts
    start_notify = metadata_and_slack_alert.task_group_start(experiment_config=exp_config)
    end_notify = metadata_and_slack_alert.task_group_completed(experiment_config=exp_config)

    config_validation = exp_config_validation.config_validation(INC_TRIALS_CONFIG_ABS)

    with TaskGroup("mta_pollen_experiments") as mta_pollen_experiments:

        # Attribution Model offer tasks
        offer_experiment_steps = [
            attribution_model_results.tasks(
                step_name=f"offer_attribution_{exp['name']}",
                journey_type=JOURNEY_TYPE["offer"],
                attribution_model_dataset_flattened_path="attribution_model_dataset_flattened_offer",
                journey_channel_metadata_path="journey_channel_metadata_offer",
                output_path="attribution_model_result_offer",
                pipeline_run_type=POLLEN_RUN_TYPE,
                correlation_id=exp["data_source"]["correlation_id"],
                source_type=exp["data_source"]["type"],
                experiment_name=f"{i}_{exp['name']}",
                experiment=True,
            )
            for i, exp in enumerate(experiment_sources, start=1)
        ]

        # Attribution Model brand tasks
        brand_experiment_steps = [
            attribution_model_results.tasks(
                step_name=f"brand_attribution_{exp['name']}",
                journey_type=JOURNEY_TYPE["brand"],
                attribution_model_dataset_flattened_path="attribution_model_dataset_flattened_brand",
                journey_channel_metadata_path="journey_channel_metadata_brand",
                output_path="attribution_model_result_brand",
                pipeline_run_type=POLLEN_RUN_TYPE,
                correlation_id=exp["data_source"]["correlation_id"],
                source_type=exp["data_source"]["type"],
                experiment_name=f"{i}_{exp['name']}",
                experiment=True,
            )
            for i, exp in enumerate(experiment_sources, start=1)
        ]

        for a, b in zip(offer_experiment_steps, offer_experiment_steps[1:]):
            a >> b

        for a, b in zip(brand_experiment_steps, brand_experiment_steps[1:]):
            a >> b

        if offer_experiment_steps and brand_experiment_steps:
            offer_experiment_steps[-1] >> brand_experiment_steps[0]

    config_validation.set_upstream(setup)
    start_notify.set_upstream(config_validation)
    start_cluster.set_upstream(start_notify)
    mta_pollen_experiments.set_upstream(start_cluster)
    stop_cluster.set_upstream(mta_pollen_experiments)
    end_notify.set_upstream(stop_cluster)


mta_pollen_exp_dag()
