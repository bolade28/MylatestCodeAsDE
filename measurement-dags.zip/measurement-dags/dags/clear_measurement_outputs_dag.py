from datetime import datetime

from airflow.sdk import dag

from task_groups import clear_measurtement_setup, clear_measurement_outputs
from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import (
    get_stage,
    get_table
)
from helpers.dag_param import DagParams


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule=None,
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
    },
    params={
        "previous_correlation_id": DagParams.previous_correlation_id
    }
)
def clear_measurement_outputs_dag():
    """
    DAG to remove measurement outputs from snowflake tables for a given correlation ID.

    """
    setup = clear_measurtement_setup.task_group()

    remove_measuremenmt_outputs = clear_measurement_outputs.task_group()

    setup >> remove_measuremenmt_outputs


clear_measurement_outputs_dag()
