from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci
from helpers.constants import CAMPAIGN_DURATION_DURING


def tasks(
    executors: int = 8, campaign_duration: str = CAMPAIGN_DURATION_DURING
) -> EmrAddAndWatchStep:

    step_name = 'BaselineModellingDataset'
    step_script = 'baseline_modelling_dataset.py'
    step_args = [
        ("--weekly-dates-path", get_path("weekly_dates")),
        ("--channel-processed-data-path", get_path("channel_processed_data")),
        ("--three-letter-coding-path", get_path("three_letter_coding")),
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--correlation-id", get_ci()),
        ("--output-path", get_path("baseline_modelling_dataset_output")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--campaign-period", campaign_duration),

    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
