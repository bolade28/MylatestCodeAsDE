from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_ci, get_sns, get_previous_path
from helpers.experiments import make_path_resolvers
from helpers.constants import CAMPAIGN_DURATION_POST


def tasks(
        executors: int = 48,
        correlation_id: str = None,
        source_type: str = None,
        experiment: bool = None,
        experiment_name: str = None,
        campaign_duration: str = None,
) -> EmrAddAndWatchStep:
    """Returns the EMR step for baseline modelling output.

    Handles both standard and experiment pipeline runs. For experiment runs, paths are
    resolved from the experiment data source; for standard runs, paths are resolved via XCom.

    Args:
        executors: Number of executors for the EMR step.
        correlation_id: Correlation ID for the experiment input data source. Required if experiment is True.
        source_type: Source type for the experiment ('experiment' or 'standard'). Required if experiment is True.
        experiment: Flag to indicate if this is an experiment run.
        experiment_name: Name of the experiment, used to namespace output paths. Required if experiment is True.
        campaign_duration: Campaign duration ('During' or 'Post'). When 'Post', intermediate/model/scaler
            paths are resolved using the during run's correlation ID (if configured).
    Returns:
        EmrAddAndWatchStep: The EMR step to be added to the DAG.
    """

    get_input_path, get_output_path = make_path_resolvers(experiment, correlation_id, source_type, experiment_name)

    step_name = f'BaselineModellingOutput_{experiment_name}' if experiment else 'BaselineModellingOutput'
    step_script = 'baseline_modelling_output.py'
    step_args = [
        ("--baseline-modelling-dataset-path", get_input_path("baseline_modelling_dataset_output")),
        ("--campaign-selection-path", get_input_path("campaign_selection")),
        ("--cluster-path", get_input_path("sku_cluster_mapping")),
        ("--feature-prioritisation-path", get_input_path("feature_prioritisation")),
        ("--weekly-dates-path", get_input_path("weekly_dates")),
        # ToDo: Add a specific dir for all checkpoints
        # Temp location to test the run with
        ("--checkpoint-path", get_output_path("ucm_checkpoint_data")),
        ("--baseline-modelling-base-data-output-path", get_output_path("ucm_base_data")),
        ("--baseline-modelling-fin-summary-output-path", get_output_path("ucm_summary_data")),
        ("--baseline-modelling-input-path", get_output_path("ucm_input_data")),
        ("--baseline-modelling-intermediate-output-path", get_output_path("ucm_intermediate_data")),
        ("--baseline-modelling-ucm-models-output-path", get_output_path("ucm_serialised_models")),
        ("--baseline-modelling-scalers-output-path", get_output_path("scaler_df")),
        ("--new-baseline-modelling-output-path", get_output_path("ucm_output_data")),
        ('--slack-topic-arn', get_sns("slack_topic_arn")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", correlation_id if experiment else get_ci()),
        ("--campaign-period", campaign_duration),
    ]

    if campaign_duration == CAMPAIGN_DURATION_POST:
        step_args += [
            ("--baseline-modelling-during-ucm-output-data-path", get_input_path("ucm_output_data_during")),
            ("--baseline-modelling-during-serialised-model-path", get_previous_path("ucm_serialised_models")),
            ("--baseline-modelling-during-scaler-path", get_previous_path("scaler_df")),

        ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
