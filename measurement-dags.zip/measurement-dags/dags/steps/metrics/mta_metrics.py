
from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns


def tasks(executors: int = 8) -> EmrAddAndWatchStep:

    step_name = 'MTA_Metrics'
    step_script = 'publish_mta_metrics.py'
    step_args = [
        ("--measurement-campaign-reporting-path", get_path("measurement_campaign_reporting")),
        ("--reach-engagement-detail-path", get_path("reach_engagement_reporting")),
        ("--metrics-topic-arn", get_sns("metrics_topic_arn")),
        ("--correlation-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn")),
        ("--run-date", "{{ data_interval_end | ds }}"),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
