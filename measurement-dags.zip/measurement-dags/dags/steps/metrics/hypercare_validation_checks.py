from helpers.constants import CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST
from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns, get_manual_campaigns_list


def tasks(
    campaign_duration: str,
    step_name: str = 'HypercareValidationChecks',
    executors: int = 8,
) -> EmrAddAndWatchStep:
    if campaign_duration not in (CAMPAIGN_DURATION_DURING, CAMPAIGN_DURATION_POST):
        raise ValueError(f"Unsupported campaign_duration: '{campaign_duration}'.")

    return add_and_watch_step(
        step_name=step_name,
        step_script='publish_hypercare_validation.py',
        step_args=[
            ("--measurement-campaign-reporting-path", get_path('measurement_campaign_reporting')),
            ("--reach-engagement-path", get_path('reach_engagement_reporting')),
            ("--campaign-booking-media-channel-path", get_path('campaign_booking_media_channel')),
            ("--measurement-marketing-channel-hierarchy-path", get_path('measurement_marketing_channel_hierarchy')),
            ("--campaign-period", campaign_duration),
            ("--booking-id", f'\"{get_manual_campaigns_list()}"'),
            ("--correlation-id", get_ci()),
            ("--metrics-topic-arn", get_sns("metrics_topic_arn")),
            ("--slack-topic-arn", get_sns('slack_topic_arn')),
            ("--output-path", get_path('hypercare_validation_checks')),
        ],
        num_executors=executors,
        executor_cores=4,
        executor_memory='20g',
    )
