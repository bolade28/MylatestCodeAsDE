from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE
from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns, get_manual_campaigns_list


def tasks(
    step_name: str = 'PublishPipelineSummary',
    pipeline_run_type: str = DTP_RUN_TYPE,
    executors: int = 8
) -> EmrAddAndWatchStep:

    step_script = 'publish_pipeline_summary.py'
    step_args = [
        ("--campaign-product-type-path", get_path("campaign_product_type")),
        ("--baseline-modelling-dataset-path", get_path("baseline_modelling_dataset_output")),
        ("--feature-prioritisation-path", get_path("feature_prioritisation")),
        ("--incremental-shrinkage-path", get_path("incremental_shrinkage")),
        ("--calibration-audit-path", get_path("incremental_shrinkage_audit")),
        ("--ucm-output-data-path", get_path("ucm_output_data")),
        ("--ucm-base-data-path", get_path("ucm_base_data")),
        ("--campaign-booking-media-channel-path", get_path("campaign_booking_media_channel")),
        ("--booking-id", f'\"{get_manual_campaigns_list()}"'),
        ("--metrics-topic-arn", get_sns("metrics_topic_arn")),
        ("--slack-topic-arn", get_sns("slack_topic_arn")),
        ("--correlation-id", get_ci()),
        ("--user-journey-offer-path", get_path("user_journey_offer")),
        ("--user-journey-brand-path", get_path("user_journey_brand")),
        ("--attribution-model-results-path", get_path("attribution_model_result_brand")),
        ("--sku-level-attributed-sales-offer-path", get_path("sku_level_attributed_sales_and_units_offer")),
        ("--sku-level-attributed-sales-brand-path", get_path("sku_level_attributed_sales_and_units_brand")),
    ]

    if pipeline_run_type == DTP_RUN_TYPE:
        campaign_type_args = [("--unified-campaign-path", get_path("unified_campaigns"))]
    elif pipeline_run_type == POLLEN_RUN_TYPE:
        campaign_type_args = [("--unified-campaign-path", get_path("unified_campaigns_pollen"))]
    else:
        raise ValueError(f"Unsupported pipeline_run_type: '{pipeline_run_type}'. Expected '{DTP_RUN_TYPE}' or '{POLLEN_RUN_TYPE}'.")

    step_args += campaign_type_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
