from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns
from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE


def tasks(
        step_name: str = 'PublishMTAValidation',
        pipeline_run_type: str = POLLEN_RUN_TYPE,
        executors: int = 8
) -> EmrAddAndWatchStep:

    step_script = 'publish_mta_validation.py'
    step_args = [
        ("--attribution-model-results-path", get_path("attribution_model_result_brand")),
        ("--measurement-campaign-reporting-path", get_path("measurement_campaign_reporting")),
        ("--user-journey-offer-path", get_path("user_journey_offer")),
        ("--user-journey-brand-path", get_path("user_journey_brand")),
        ("--metrics-topic-arn", get_sns("metrics_topic_arn")),
        ("--correlation-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn")),
    ]

    if pipeline_run_type == DTP_RUN_TYPE:
        campaign_type_args = [("--unified-campaign-path", get_path("unified_campaigns"))]
    elif pipeline_run_type == POLLEN_RUN_TYPE:
        campaign_type_args = [("--unified-campaign-path", get_path("unified_campaigns_pollen"))]
    else:
        raise ValueError(f"Unsupported pipeline_run_type: '{pipeline_run_type}'. Expected '{DTP_RUN_TYPE}' or '{POLLEN_RUN_TYPE}'.")

    step_args += campaign_type_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
