from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns


def tasks(campaign_duration: str, executors: int = 8) -> EmrAddAndWatchStep:

    step_name = 'PublishBaselineValidation'
    step_script = 'publish_baseline_validation.py'
    step_args = [
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--baseline-modelling-dataset-path", get_path("baseline_modelling_dataset_output")),
        ("--metrics-topic-arn", get_sns("metrics_topic_arn")),
        ("--correlation-id", get_ci()),
        ("--campaign-duration", campaign_duration)
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
