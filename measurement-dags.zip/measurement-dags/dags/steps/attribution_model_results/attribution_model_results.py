from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_ci, get_sns
from helpers.experiments import make_path_resolvers


def tasks(
        step_name: str,
        journey_type: str,
        attribution_model_dataset_flattened_path: str,
        journey_channel_metadata_path: str,
        pipeline_run_type: str,
        output_path: str,
        synergy_output_path: str = "attribution_synergy_results",
        correlation_id: str = None,
        source_type: str = None,
        experiment_name: str = None,
        experiment: bool = False,
) -> EmrAddAndWatchStep:
    """
    Prepares the EMR step for the AttributionModelResult job.

    Handles both standard and experiment pipeline runs. For experiment runs, paths are
    resolved from the provided correlation ids data source; for standard runs, paths are resolved via XCom as normal.
    Uses the Pollen script when pipeline_run_type == POLLEN_RUN_TYPE, DTP script otherwise.
    Appends synergy-output-path only when journey_type == "offer".

    Args:
        step_name: Name of the EMR step.
        journey_type: Journey type (e.g. 'offer', 'visit').
        attribution_model_dataset_flattened_path: Path key for the flattened attribution model dataset.
        journey_channel_metadata_path: Path key for the journey channel metadata.
        pipeline_run_type: Pipeline run type determining which script to use.
        output_path: Path key for the attribution model results output.
        synergy_output_path: Path key for the synergy results output. Only used when journey_type == 'offer'.
        correlation_id: Correlation ID for the experiment input data source. Required if experiment is True.
        source_type: Source type for the experiment ('experiment' or 'standard'). Required if experiment is True.
        experiment_name: Name of the experiment, used to namespace output paths. Required if experiment is True.
        experiment: Flag to indicate if this is an experiment run.
    Returns:
        EmrAddAndWatchStep: The EMR step to be added to the DAG.
    """

    get_input_path, get_output_path = make_path_resolvers(experiment, correlation_id, source_type, experiment_name)

    step_script = "attribution_model_results.py"
    step_args = [
        ("--attribution-model-dataset-flattened-path", get_input_path(attribution_model_dataset_flattened_path)),
        ("--journey-channel-metadata-path", get_input_path(journey_channel_metadata_path)),
        ("--output-path", get_output_path(output_path)),
        ("--job-run-id", get_ci()),
        ("--slack-topic-arn", get_sns("slack_topic_arn")),
        ("--journey-type", journey_type),
        ("--pipeline-run-type", pipeline_run_type),
    ]

    # Add synergy path only for offer journey
    if journey_type.strip().lower() == "offer":
        step_args.append(
            ("--synergy-output-path", get_output_path(synergy_output_path))
        )

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=48,
        executor_cores=8,
        executor_memory="32g",
    )

    return tg
