from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns


def tasks(
        step_name: str,
        journey_type: str,
        attribution_pre_requisite: str,
        journey_channel_metadata_path: str,
        attribution_model_dataset_flattened_path: str,
        pipeline_run_type: str,
        executors: int = 48,
) -> EmrAddAndWatchStep:
    """
    Prepare EMR step for AttributionModelDataset job.
    - Uses Pollen script when pipeline_run_type == POLLEN_RUN_TYPE, DTP script otherwise.
    - Adds synergy-output-path only when journey_type == "offer".
    """

    step_script = "attribution_model_dataset.py"
    step_args = [
        ("--measurement-campaign-path", get_path("measurement_campaign_execution")),
        ("--attribution-prerequisite-path", get_path(attribution_pre_requisite)),
        ("--campaign-decay-path", get_path("campaign_decay_rate")),
        ("--journey-channel-metadata-path", get_path(journey_channel_metadata_path)),
        ("--attribution-model-dataset-flattened-path", get_path(attribution_model_dataset_flattened_path)),
        ("--journey-type", journey_type),
        ("--job-run-id", get_ci()),
        ("--slack-topic-arn", get_sns("slack_topic_arn")),
        ("--pipeline-run-type", pipeline_run_type),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=8,
        executor_memory="32g",
    )

    return tg
