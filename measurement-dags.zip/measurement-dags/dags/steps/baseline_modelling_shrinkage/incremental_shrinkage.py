from helpers.xcom import get_ci, get_path
from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.experiments import make_path_resolvers
from helpers.constants import CAMPAIGN_DURATION_POST


def tasks(
        step_name: str,
        correlation_id: str = None,
        source_type: str = None,
        experiment: bool = None,
        experiment_name: str = None,
        campaign_duration: str = None
) -> EmrAddAndWatchStep:

    """
    Prepares the EMR step for the Incremental Shrinkage job.
    When rrunning this step without experimentation, get_input_path and get_output_path will use the usual get_path function to resolve paths from XCom.
    When running as part of an experiment, the resolvers will pull paths from the experiment's data source using the provided correlation_id and source_type,
    and namespace outputs using experiment_name.
    """

    step_script = 'incremental_shrinkage.py'

    get_input_path, get_output_path = make_path_resolvers(experiment, correlation_id, source_type, experiment_name)

    step_args = [
        ("--baseline-output-path", get_output_path("ucm_output_data")),    # experiment namespace - read previous step
        ("--avg-weekly-spend-data-path", get_input_path("sub_cat_brand_weekly_spend")),
        ("--campaign-selection-path", get_input_path("campaign_selection")),
        ("--measurement-legacy-campaign-performance", get_input_path("measurement_legacy_campaign_performance")),
        ("--brand-data-path", get_input_path("brand_data")),
        ("--output-path", get_output_path("incremental_shrinkage")),
        ("--output-path-audit", get_output_path("incremental_shrinkage_audit")),
        ("--campaign-duration", campaign_duration),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
        ("--ucm-base-data", get_output_path("ucm_base_data")),
    ]

    # Only add previous measurement campaign reporting path for Post period
    if campaign_duration == CAMPAIGN_DURATION_POST:
        step_args.append(("--previous-measurement-campaign-reporting", get_path("previous_measurement_campaign_reporting")))

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=48,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
