import logging

from airflow.sdk import TaskGroup, task

from helpers.constants import CAMPAIGN_DURATION_POST
from helpers.experiments import make_path_resolvers
from helpers.xcom import get_ci, get_path


logger = logging.getLogger(__name__)


def tasks(
        correlation_id: str = None,
        source_type: str = None,
        experiment: bool = None,
        experiment_name: str = None,
        campaign_duration: str = None
):
    """
    Prepares the EMR step for incremental post-processing (part of incrementality v2).
    """

    with TaskGroup("v2_incremental_post_processing", ui_color="ff7f00") as tg:

        @task
        def log_tuples_post_processing(tuples_of_2) -> None:
            for a, b in tuples_of_2:
                logger.info(f"{a} {b}")

        get_input_path, get_output_path = make_path_resolvers(experiment, correlation_id, source_type, experiment_name)
        step_script = "incremental_post_processing.py"
        step_args = [
            # experiment namespace - read previous step
            ("--baseline-output-path", get_output_path("ucm_output_data_v2")),
            ("--ucm-base-data", get_output_path("ucm_base_data_v2")),
            ("--avg-weekly-spend-data-path", get_input_path("sub_cat_brand_weekly_spend")),
            ("--campaign-selection-path", get_input_path("campaign_selection")),
            ("--measurement-legacy-campaign-performance", get_input_path("measurement_legacy_campaign_performance")),
            ("--brand-data-path", get_input_path("brand_data")),
            ("--output-path", get_output_path("incremental_shrinkage_v2")),
            ("--output-path-audit", get_output_path("incremental_shrinkage_audit_v2")),
            ("--campaign-duration", campaign_duration),
            ("--run-date", "{{ data_interval_end | ds }}"),
            ("--correlation-id", get_ci()),
        ]

        # Only add previous measurement campaign reporting path for Post period
        if campaign_duration == CAMPAIGN_DURATION_POST:
            step_args.append(("--previous-measurement-campaign-reporting", get_path("previous_measurement_campaign_reporting")))

        logger.info("Salutations. I would have run the following Spark thingy with these args, if this were a finished product:")
        logger.info(f"{step_script=}")
        logger.info("TODO executors 48, executor_cores 4, executor_memory 32g <- can be changed/parameterised obvs")
        log_tuples_post_processing(step_args)

    return tg
