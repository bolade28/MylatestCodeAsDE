import logging

from airflow.sdk import TaskGroup, task

from helpers.constants import CAMPAIGN_DURATION_POST
from helpers.experiments import make_path_resolvers
from helpers.xcom import get_ci, get_sns, get_previous_path


logger = logging.getLogger(__name__)


def tasks(
        executors: int = 48,
        correlation_id: str = None,
        source_type: str = None,
        experiment: bool = None,
        experiment_name: str = None,
        campaign_duration: str = None,
):
    """
    Returns the EMR step for incremental estimation (part of incrementality v2).
    """

    with TaskGroup("v2_incremental_estimation", ui_color="ff7f00") as tg:

        # yes this is pretty dumb, however, it'll do for now just for debug
        @task
        def log_tuples_estimation(tuples_of_2) -> None:
            for a, b in tuples_of_2:
                logger.info(f"{a} {b}")

        get_input_path, get_output_path = make_path_resolvers(experiment, correlation_id, source_type, experiment_name)

        step_name = f"IncrementalEstimation_{experiment_name}" if experiment else "IncrementalEstimation"
        step_script = "incremental_estimation.py"
        step_args = [
            ("--baseline-modelling-dataset-path", get_input_path("baseline_modelling_dataset_output")),
            ("--campaign-selection-path", get_input_path("campaign_selection")),
            ("--cluster-path", get_input_path("sku_cluster_mapping")),
            ("--feature-prioritisation-path", get_input_path("feature_prioritisation_v2")),
            ("--weekly-dates-path", get_input_path("weekly_dates")),
            ("--checkpoint-path", get_output_path("ucm_checkpoint_data_v2")),
            ("--baseline-modelling-base-data-output-path", get_output_path("ucm_base_data_v2")),
            ("--baseline-modelling-fin-summary-output-path", get_output_path("ucm_summary_data_v2")),
            ("--baseline-modelling-input-path", get_output_path("ucm_input_data_v2")),
            ("--baseline-modelling-intermediate-output-path", get_output_path("ucm_intermediate_data_v2")),
            ("--baseline-modelling-ucm-models-output-path", get_output_path("ucm_serialised_models_v2")),
            ("--baseline-modelling-scalers-output-path", get_output_path("scaler_df_v2")),
            ("--new-baseline-modelling-output-path", get_output_path("ucm_output_data_v2")),
            ("--slack-topic-arn", get_sns("slack_topic_arn")),
            ("--run-date", "{{ data_interval_end | ds }}"),
            ("--correlation-id", correlation_id if experiment else get_ci()),
            ("--campaign-period", campaign_duration),
        ]

        if campaign_duration == CAMPAIGN_DURATION_POST:
            step_args += [
                ("--baseline-modelling-during-ucm-output-data-path", get_input_path("ucm_output_data_v2")),
                ("--baseline-modelling-during-serialised-model-path", get_previous_path("ucm_serialised_models_v2")),
                ("--baseline-modelling-during-scaler-path", get_previous_path("scaler_df_v2")),

            ]

        logger.info("Yo, I would have run the following Spark thingy with these args, if this were a finished product:")
        logger.info(f"{step_name=}")
        logger.info(f"{step_script=}")
        logger.info(f"{executors=}")
        log_tuples_estimation(step_args)

    return tg
