from helpers.channel_hierarchy import SUBCHANNELS_CODE
from helpers.constants import (
    CAMPAIGN_DURATION_POST,
    SALES_ORIGINATION_ALL_CODES,
    SALES_ORIGINATION_INSTORE_CODES,
    SALES_ORIGINATION_ONLINE_CODES,
    EventName,
)
from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_previous_path, get_resolved_during_correlation_id


def tasks(campaign_duration: str, executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'InStoreDataPollen'
    step_script = 'instore_data.py'
    campaign_duration_is_post = campaign_duration == CAMPAIGN_DURATION_POST

    step_args = [
        ("--measurement-campaign-execution-status-path", get_path("measurement_campaign_execution")),
        ("--measurement-unified-campaign-pollen-path", get_path("unified_campaigns_pollen")),
        ("--campaign-booking-media-channel-path", get_path("campaign_booking_media_channel")),
        ("--campaign-product-type-path", get_path("campaign_product_type")),
        ("--fact-sale-transaction-basket-path", get_path("processed_fact_sales_transaction_basket")),
        ("--fact-sale-transaction-item-path", get_path("mta_fact_sale_transaction_item")),
        ("--dim-customer-loyalty-path", get_path("dim_customer_loyalty")),
        ("--output-path", get_path("instore_data")),
        ("--correlation-id", get_ci()),
        ("--hierarchy-codes", *[f"'{code}'" for code in SUBCHANNELS_CODE['instore']]),
        ("--sales-origination-all-codes", *[f"'{code}'" for code in SALES_ORIGINATION_ALL_CODES]),
        ("--sales-origination-instore-codes", *[f"'{code}'" for code in SALES_ORIGINATION_INSTORE_CODES]),
        ("--sales-origination-online-codes", *[f"'{code}'" for code in SALES_ORIGINATION_ONLINE_CODES]),
        ("--campaign-duration-is-post", str(campaign_duration_is_post).lower()),
        ("--transaction-event-name", EventName.TRANSACTION.value.lower()),
        ("--touchpoint-event-name", EventName.TOUCHPOINT.value.lower()),
    ]

    post_period_args = [
        ("--customer-data-collection-path", get_previous_path("customer_data_collection")),
        ("--during-correlation-id", get_resolved_during_correlation_id()),
    ] if campaign_duration_is_post else []

    step_args += post_period_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
