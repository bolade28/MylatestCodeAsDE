from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_model_start_end_dates


def tasks(executors: int = 8) -> EmrAddAndWatchStep:
    step_name = 'YoutubeProcessedData'
    step_script = 'youtube_processed_data.py'
    step_args = [
        ("--youtube-normalize-path", get_path("youtube_normalize")),
        ("--weekly-dates-path", get_path("weekly_dates")),
        ("--media-report-path", get_path("media_report")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--start-date", str(get_model_start_end_dates('start_date'))),
        ("--end-date", str(get_model_start_end_dates('end_date'))),
        ("--output-path", get_path("youtube_processed_data")),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
