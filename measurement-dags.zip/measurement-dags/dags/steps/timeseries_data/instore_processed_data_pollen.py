from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_model_start_end_dates


def tasks(executors: int = 8) -> EmrAddAndWatchStep:

    step_name = 'InstoreProcessedDataPollen'
    step_script = 'instore_processed_data_pollen.py'
    step_args = [
        ("--campaign-booking-media-channel-path", get_path("campaign_booking_media_channel")),
        ("--cust-by-location-path", get_path("cust_by_location")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--historic-instore-processed-data", get_path("instore_processed_data")),
        ("--start-date", str(get_model_start_end_dates('start_date'))),
        ("--end-date", str(get_model_start_end_dates('end_date'))),
        ("--output-path", get_path("instore_processed_data_pollen")),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
