from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci


def tasks(executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'Dv360ProcessedData'
    step_script = 'dv360_processed_data.py'
    step_args = [
        ("--dv360-normalised-path", get_path("dv360_normalised")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--weekly-dates-path", get_path("weekly_dates")),
        ("--dv360-media-report-path", get_path("dv360_media_report")),
        ("--output-path", get_path("dv360_processed_data")),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
