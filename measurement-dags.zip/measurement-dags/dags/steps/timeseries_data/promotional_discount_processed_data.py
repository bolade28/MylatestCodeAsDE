from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci


def tasks(executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'PromotionalDiscountProcessedData'
    step_script = 'promotional_discount_processed_data.py'

    step_args = [
        ("--weekly-dates-path", get_path("weekly_dates")),
        ("--item-brand-hist-path", get_path("brand_data")),
        ("--processed-fact-sales-transaction-item", get_path("processed_fact_sales_transaction_item")),
        ("--sku-cluster-mapping", get_path("sku_cluster_mapping")),
        ("--output-path", get_path("promotional_discount_processed_data")),
        ("--correlation-id", get_ci()),
    ]
    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
