from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci


def tasks(executors: int = 48) -> EmrAddAndWatchStep:
    step_name = 'BasePriceData'
    step_script = 'base_price_data.py'
    step_args = [
        ("--fact-sales-path", get_path("processed_fact_sales_transaction_item")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--store-hierarchy-path", get_path("dim_store_org_hierarchy")),
        ("--weekly-dates-path", get_path("weekly_dates")),
        ("--output-path", get_path("base_price_data")),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
