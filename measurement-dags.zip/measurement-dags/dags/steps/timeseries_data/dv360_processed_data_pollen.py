from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci


def tasks(executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'Dv360ProcessedDataPollen'
    step_script = 'dv360_processed_data_pollen.py'
    step_args = [
        ("--dv360-normalised-path", get_path("dv360_normalised_pollen")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--dv360-media-report-path", get_path("dv360_media_report")),
        ("--historic-dv360-processed-data", get_path("dv360_processed_data")),
        ("--output-path", get_path("dv360_processed_data_pollen")),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
