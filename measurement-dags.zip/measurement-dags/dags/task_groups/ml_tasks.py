from airflow.sdk import TaskGroup
from steps.feature_prioritisation import feature_prioritisation
from steps.baseline_modelling_output import baseline_modelling_output
from steps.baseline_modelling_shrinkage import incremental_shrinkage
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule


def task_group(campaign_duration: str = None) -> TaskGroup:

    with TaskGroup('ml_tasks', ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        feature_prioritisation_task = feature_prioritisation.tasks()
        baseline_modelling_output_task = baseline_modelling_output.tasks(campaign_duration=campaign_duration)

        incremental_shrinkage_task = incremental_shrinkage.tasks(campaign_duration=campaign_duration, step_name='IncrementalShrinkage')

        start >> feature_prioritisation_task >> baseline_modelling_output_task >> incremental_shrinkage_task >> finish

    return tg
