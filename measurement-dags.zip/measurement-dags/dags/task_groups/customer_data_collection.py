from airflow.sdk import TaskGroup

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE
from helpers.utils import decide_pollen_dtp
from helpers.xcom import pipeline_run_type
from steps.customer_data_collection import customer_data_collection
from steps.instore_data_pollen import instore_data_pollen
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule


def customer_engagement(campaign_duration: str) -> TaskGroup:

    with TaskGroup('customer_engagement', ui_color="ff7f00") as tg:
        instore_data_pollen.tasks(campaign_duration=campaign_duration)

    return tg


def task_group(campaign_duration: str) -> TaskGroup:

    with TaskGroup('customer_data_collection', ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        pollen_customer_engagement = customer_engagement(campaign_duration=campaign_duration)
        dtp_customer_data_collection = customer_data_collection.tasks(pipeline_run_type=DTP_RUN_TYPE)
        pollen_customer_data_collection = customer_data_collection.tasks(pipeline_run_type=POLLEN_RUN_TYPE)

        decide = BranchPythonOperator(
            task_id="run_dtp_or_pollen_customer_data_collection",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                f"CustomerDataCollection_{DTP_RUN_TYPE}",
                "customer_engagement.InStoreDataPollen",
                "customer_data_collection",
            ],
        )

        start >> decide >> dtp_customer_data_collection >> finish
        start >> decide >> pollen_customer_engagement >> pollen_customer_data_collection >> finish

    return tg
