from airflow.sdk import TaskGroup

from helpers import setup


def task_group() -> TaskGroup:

    start = setup.job_flow_start_time()

    with TaskGroup('setup_tasks') as tg:

        ci = setup.configure_correlation_id()
        setup.configure_snowflake_stage(experimentation=True)
        setup.configure_compute_units()
        setup.configure_pipelines_version()
        setup.configure_snowflake_tables(ci)
        setup.configure_sns()
        setup.configure_dag_version()
        setup.configure_aws_user()
        setup.evaluation_phase()
        setup.configure_master_instance_type()
        setup.configure_run_type()
        setup.configure_paths(ci, '{{data_interval_end | ds }}', experiment_flag=True)

    return start >> tg
