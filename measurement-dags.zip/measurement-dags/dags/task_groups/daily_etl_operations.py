from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule
from helpers.constants import (
    CHANNELS,
    CONSECUTIVE_SALES_WEEKS,
    NUMBER_OF_WEEKS,
    NUMBER_OF_WEEKS_DAILY_ETL,
    SALES_TRANSACTION_CODES,
    SERVICE_TYPE,
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE,
    SUPERMARKET_STORE_TYPE,
    PROD,
    TIME_PERIOD,
    PRODUCT_TYPE,
    PRODUCT_TYPE_NO,
    EXPOSED_COST_ESTIMATE,
    CP_POLLEN_FILTER,
    CP_DTP_FILTER,
    CP_EMULATION_FILTER,
)

from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_ci, get_table, get_model_start_end_dates, get_campaign_start_date
from helpers.snowflake import check_if_we_should_run_post_campaign_period
from helpers.setup import get_environment
from helpers.channel_hierarchy import MEASUREMENT_READY_CODE, INSCOPE_HIERARCHY_CODE
from task_groups import legacy_brand_registry_alert


def task_group() -> TaskGroup:

    with TaskGroup('daily_etl', ui_color="ff7f00") as tg:

        a = MeasurementSnowflakeOperator(
            task_id="create_weekly_dates_table",
            sql="daily_etl/weekly_start_dates_daily_etl.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'number_of_weeks': NUMBER_OF_WEEKS_DAILY_ETL,
                'start_date': get_model_start_end_dates('start_date'),
                'end_date': get_model_start_end_dates('end_date')
                # 'run_date': '{{data_interval_end | ds }}'
            },
            doc_md="""
                This task creates weekly dates table with monday as start of week. This is used in baseline DAG.
                """,
        )
        b = MeasurementSnowflakeOperator(
            task_id="create_unified_products_table",
            sql="daily_etl/unified_products.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'correlation_id': get_ci()
            },
            doc_md="""
                This task creates unified product table in snowflake.
                """,
        )
        hist = MeasurementSnowflakeOperator(
            task_id="load_historic_campaign_sku_scope",
            sql="daily_etl/historic_campaigns.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates unified product table in snowflake.
                """,
        )
        intm = MeasurementSnowflakeOperator(
            task_id="planogram_campaign_item_postn_daily_int",
            sql="daily_etl/planogram_campaign_item_postn_daily_intermediate.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates unified product table in snowflake.
                """,
        )
        items = MeasurementSnowflakeOperator(
            task_id="planogram_campaign_item_postn_daily",
            sql="daily_etl/planogram_campaign_item_postn_daily.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},

            doc_md="""
                This task creates unified product table in snowflake.
                """,
        )
        hist >> intm >> items
        transactions = MeasurementSnowflakeOperator(
            task_id="transactions_table",
            sql="daily_etl/transactions.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'modelling_end_date': get_model_start_end_dates('end_date'),
                'modelling_start_date': get_model_start_end_dates('start_date'),
                'transaction_codes': SALES_TRANSACTION_CODES,
                'supermarket_store_type': SUPERMARKET_STORE_TYPE,
            },
            doc_md="""
                This task creates unified product table in snowflake.
                """,
        )

        transactions_append = MeasurementSnowflakeOperator(
            task_id="transactions_append_table",
            sql="daily_etl/transactions_intermediate_append.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'modelling_end_date': get_model_start_end_dates('end_date'),
                'modelling_start_date': get_model_start_end_dates('start_date'),
                'transaction_codes': SALES_TRANSACTION_CODES,
                'correlation_id': get_ci()
            },
            doc_md="""
                This task creates unified product table in snowflake.
                """,
        )
        transactions_append >> transactions

        unified_campaign_tg = unified_campaign()

        customer_by_location_intermediate = MeasurementSnowflakeOperator(
            task_id="create_customer_by_location_intermediate_table",
            sql="daily_etl/customer_by_location_intermediate.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                    'start_date': get_model_start_end_dates('start_date'),
                    'end_date': get_model_start_end_dates('end_date'),
                    'transaction_codes': SALES_TRANSACTION_CODES
            },
            doc_md="""
                This task creates the customer_by_location table in Snowflake
                """,
        )

        customer_by_location = MeasurementSnowflakeOperator(
            task_id="create_customer_by_location_table",
            sql="daily_etl/customer_by_location.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                    'start_date': get_model_start_end_dates('start_date'),
                    'end_date': get_model_start_end_dates('end_date'),
                    'transaction_codes': SALES_TRANSACTION_CODES
            },
            doc_md="""
                This task creates the customer_by_location table in Snowflake
                """,
        )

        pollen_booking_blacklist = MeasurementSnowflakeOperator(
            task_id="load_pollen_booking_blacklist",
            sql="daily_etl/bookings_blacklist.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'correlation_id': get_ci(),
            },
            doc_md="""
                This task will create a transit table for blacklist bookings from BDV.
                """,
        )

        legacy_brand_booking_registry = MeasurementSnowflakeOperator(
            task_id="load_legacy_brand_booking_registry",
            sql="daily_etl/legacy_brand_booking_registry.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Rebuilds the booking-level registry of bookings that must keep using
                legacy EAN_BR brand logic in the Unified Campaign Pollen build.
                """,
        )

        legacy_brand_registry_alert_tg = legacy_brand_registry_alert.task_group()

        unified_campaign_pollen = MeasurementSnowflakeOperator(
            task_id="load_unified_campaign_pollen",
            sql="unified_campaign/unified_campaign_pollen_insert.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                    'table': get_table('measurement_unified_campaign_pollen_daily_etl'),
                    'run_date': '{{data_interval_end | ds }}',
                    'correlation_id': get_ci(),
                    'emulate_prod_env': False,
                    'is_prod': get_environment() == PROD,
                    'enable_prod_bookings_in_dev': False
            },
            doc_md="""
                This task Snowflake pulls data from adw_bdv table for pollen campaigns
                """,
        )

        load_unified_campaign_pollen_prod_test_bookings = MeasurementSnowflakeOperator(
            task_id="load_unified_campaign_pollen_prod_test_bookings",
            sql="unified_campaign/unified_campaign_pollen_insert.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'table': get_table('measurement_unified_campaign_pollen_test_booking_prod'),
                'run_date': '{{data_interval_end | ds }}',
                'correlation_id': get_ci(),
                'emulate_prod_env': False,
                'enable_prod_bookings_in_dev': True,
            },
            doc_md="""
                Creates a transient staging table with prod test-bookings for dev emulation runs.
                """,
        )

        merge_unified_campaign_pollen_prod_test_bookings = MeasurementSnowflakeOperator(
            task_id="merge_unified_campaign_pollen_prod_test_bookings",
            sql="unified_campaign/unified_campaign_pollen_merge_prod_test_bookings.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'target_table': get_table('measurement_unified_campaign_pollen_daily_etl'),
                'source_table': get_table('measurement_unified_campaign_pollen_test_booking_prod'),
                'correlation_id': get_ci(),
            },
            doc_md="""
                Merges staged prod test-bookings into the dev pollen table for the same correlation run.
                """,
        )

        marketing_channel_hierarchy = MeasurementSnowflakeOperator(
            task_id="load_marketing_channel_hierarchy",
            sql="measurement_hierarchy/measurement_media_hierarchy.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'run_date': '{{data_interval_end | ds }}',
                'correlation_id': get_ci(),
                'inscope_hierarchy_cd': ', '.join(str(code) for code in INSCOPE_HIERARCHY_CODE),
                'measurement_ready_cd': ', '.join(str(code) for code in MEASUREMENT_READY_CODE),
            },
            doc_md="""
                Loads marketing channel hierarchy reference table from ADW_RDV source.
                Applies measurement readiness logic based on hierarchy code.
            """,
        )

        legacy_campaign_performance = MeasurementSnowflakeOperator(
            task_id="create_legacy_campaign_performance",
            sql="daily_etl/legacy_campaign_performance_dataset.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'correlation_id': get_ci(),
                'time_period': TIME_PERIOD,
                'product_type': PRODUCT_TYPE["brand"],
                'product_type_no': PRODUCT_TYPE_NO,
                'exposed_cost_estimate': EXPOSED_COST_ESTIMATE
            },
            doc_md="""
                Loads historic performance data for legacy campaigns channel wise from I2C_WORKSPACE
                Feeds into UCM shrinkage algorithm to smooth out the result
            """,
        )

        sub_cat_brand_weekly_spend = MeasurementSnowflakeOperator(
            task_id="create_sub_cat_brand_weekly_spend_data",
            sql="daily_etl/sub_cat_brand_weekly_spend.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Calculates the average weekly spend for each super-category, sub-category and brand, adjusts for inflation.
            """,
        )

        # This runs after the unified campaign inputs it expands into offer and brand SKU scope.
        campaign_product_type = MeasurementSnowflakeOperator(
            task_id="create_campaign_product_type",
            sql="daily_etl/campaign_product_type.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
            params={
                'correlation_id': get_ci(),
                'pollen_type': CP_POLLEN_FILTER,
                'dtp_type': CP_DTP_FILTER,
                'emulation_type': CP_EMULATION_FILTER,
                'is_prod': get_environment() == PROD,
            },
            doc_md="""
               This task creates campaign product table in snowflake.
               Which contains the offer and brand skus for each campaign.
            """,
        )

        # This is the new logic for campaign product type, pointing to the new strategic brand source
        # It will replace the old task above after we have finished all current Post runs.
        # At that point the tables/code references will all refer to campaign_product_type only, however it will have the new logic
        # Right now the newer logic is stored separately
        campaign_product_type_new_strategic_source = MeasurementSnowflakeOperator(
            task_id="create_campaign_product_type_new_brand_logic",
            sql="daily_etl/campaign_product_type_new_brand_logic.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
            params={
                'correlation_id': get_ci(),
                'pollen_type': CP_POLLEN_FILTER,
                'dtp_type': CP_DTP_FILTER,
                'emulation_type': CP_EMULATION_FILTER,
                'is_prod': get_environment() == PROD,
            },
            doc_md="""
               This task creates the new-version campaign product table in Snowflake.
               Which contains the offer and brand skus for each campaign using the new brand logic.
               This will replace the old task after we have finishe dall current Post runs.
            """,
        )

        update_run_incrementality_column = MeasurementSnowflakeOperator(
            task_id="update_run_incrementality_column",
            sql="daily_etl/update_run_incrementality_column.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'pollen_type': CP_POLLEN_FILTER,
                'dtp_type': CP_DTP_FILTER,
                'emulation_type': CP_EMULATION_FILTER,
                'is_prod': get_environment() == PROD,
                'product_type_filter': PRODUCT_TYPE["brand"],
                'look_back_period': NUMBER_OF_WEEKS,
                'consective_sales_period': CONSECUTIVE_SALES_WEEKS
            },
            doc_md="""
                Evaluates whether each booking has sufficient pre-campaign sales history to run
                the incrementality baseline pipeline and updates the unified campaign tables.
            """,
        )

    a >> b >> customer_by_location_intermediate >> customer_by_location
    a >> b >> [transactions_append, unified_campaign_tg, marketing_channel_hierarchy, legacy_campaign_performance, sub_cat_brand_weekly_spend, pollen_booking_blacklist, legacy_brand_booking_registry]
    [pollen_booking_blacklist, legacy_brand_booking_registry] >> unified_campaign_pollen
    legacy_brand_booking_registry >> legacy_brand_registry_alert_tg
    if get_environment() != PROD:
        unified_campaign_pollen >> load_unified_campaign_pollen_prod_test_bookings >> merge_unified_campaign_pollen_prod_test_bookings
        [merge_unified_campaign_pollen_prod_test_bookings, unified_campaign_tg] >> campaign_product_type >> campaign_product_type_new_strategic_source
    else:
        [unified_campaign_pollen, unified_campaign_tg] >> campaign_product_type >> campaign_product_type_new_strategic_source

    [campaign_product_type_new_strategic_source, transactions] >> update_run_incrementality_column

    return tg


def unified_campaign() -> TaskGroup:
    with TaskGroup('unified_campaign', ui_color="ff7f00") as tg_main:
        with TaskGroup('unified_campaign_prereq', ui_color="ff7f00") as tg_prereq:

            post_campaign_period()

            MeasurementSnowflakeOperator(
                task_id="create_table_citrus_campaigns",
                sql="unified_campaign/citrus_campaigns.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'campaign_start_year': get_campaign_start_date('year'),
                    'campaign_start_month': get_campaign_start_date('month'),
                    'run_date': '{{data_interval_end | ds }}',
                    'channel_mapping_onsite_citrus': CHANNELS['on-site'],
                    'channel_mapping_onsite_citrus_service_type': SERVICE_TYPE
                },
                doc_md="""
                    This task creates the measurement_citrus_campaigns table in Snowflake
                    """,
            )

            MeasurementSnowflakeOperator(
                task_id="create_table_coupon_at_till_campaigns",
                sql="unified_campaign/coupon_at_till_campaigns.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                        'campaign_start_year': get_campaign_start_date('year'),
                        'campaign_start_month': get_campaign_start_date('month'),
                        'run_date': '{{data_interval_end | ds }}'
                },
                doc_md="""
                    This task creates the measurement_coupon_at_till_campaigns table in Snowflake
                    """,
            )

            MeasurementSnowflakeOperator(
                task_id="create_table_dv360_campaigns",
                sql="unified_campaign/dv360_campaigns.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'campaign_start_year': get_campaign_start_date('year'),
                    'campaign_start_month': get_campaign_start_date('month'),
                },
                doc_md="""
                    This task creates the measurement_dv360_campaigns table in Snowflake
                    """,
            )

            MeasurementSnowflakeOperator(
                task_id="create_table_ecoupons_campaigns",
                sql="unified_campaign/ecoupons_campaigns.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'campaign_start_year': get_campaign_start_date('year'),
                    'campaign_start_month': get_campaign_start_date('month'),
                    'run_date': '{{data_interval_end | ds }}'
                },
                doc_md="""
                    This task creates the measurement_ecoupons_campaigns table in Snowflake
                    """,
            )

            MeasurementSnowflakeOperator(
                task_id="create_table_instore_campaigns",
                sql="unified_campaign/instore_campaigns.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'campaign_start_year': get_campaign_start_date('year'),
                    'campaign_start_month': get_campaign_start_date('month'),
                    'run_date': '{{data_interval_end | ds }}'
                },
                doc_md="""
                    This task creates the measurement_instore_campaigns table in Snowflake
                    """,
            )

            MeasurementSnowflakeOperator(
                task_id="create_table_magazine_campaigns",
                sql="unified_campaign/magazine_campaigns.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'campaign_start_year': get_campaign_start_date('year'),
                    'campaign_start_month': get_campaign_start_date('month'),
                    'run_date': '{{data_interval_end | ds }}'
                },
                doc_md="""
                    This task creates the measurement_magazine_campaigns table in Snowflake
                    """,
            )

            MeasurementSnowflakeOperator(
                task_id="create_table_meta_campaigns",
                sql="unified_campaign/meta_campaigns.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'campaign_start_year': get_campaign_start_date('year'),
                    'campaign_start_month': get_campaign_start_date('month'),
                    'run_date': '{{data_interval_end | ds }}'
                },
                doc_md="""
                    This task creates the measurement_meta_campaigns table in Snowflake
                    """,
            )
        with TaskGroup('unified_campaign_table', ui_color="ff7f00") as tg_unified_campaign:

            unified_campaign_table = MeasurementSnowflakeOperator(
                task_id="create_table_unified_campaign",
                sql="unified_campaign/unified_campaign.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'campaign_start_year': get_campaign_start_date('year'),
                    'campaign_start_month': get_campaign_start_date('month'),
                    'run_date': '{{data_interval_end | ds }}',
                    'correlation_id': get_ci()
                },
                doc_md="""
                    This task creates the measurement_unified_campaign table in Snowflake - this is based on the 7 prereq SQL tables
                    """,
            )

            missing_campaigns = MeasurementSnowflakeOperator(
                task_id="insert_into_table_unified_campaign",
                sql="unified_campaign/unified_campaign_insert.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'run_date': '{{data_interval_end | ds }}',
                    'correlation_id': get_ci()
                },
                doc_md="""
                        TODO: This is a temp fix and should be looked into later.
                    This task inserts data from grid based unified campaign table into measurement unified campaign table
                    """,
            )

        unified_campaign_table >> missing_campaigns
        tg_prereq >> tg_unified_campaign
    return tg_main


def _do_post_campaign_period_or_not(run_date: str, table_name: str) -> str:
    print(f"Input args: {run_date=} {table_name=}")
    should_we_then = check_if_we_should_run_post_campaign_period(run_date, table_name)
    print(f"Should we: {should_we_then=}")
    if should_we_then:
        print("Will run post_campaign_period SQL. This will take about 20-25 min...")
        return "daily_etl.unified_campaign.unified_campaign_prereq.post_campaign_period.run_post_campaign_period_sql"
    else:
        return "daily_etl.unified_campaign.unified_campaign_prereq.post_campaign_period.skip"


def post_campaign_period() -> TaskGroup:
    with TaskGroup("post_campaign_period", ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        skip = EmptyOperator(task_id="skip")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        branch = BranchPythonOperator(
            task_id="do_post_campaign_period_or_not",
            python_callable=_do_post_campaign_period_or_not,
            op_args=[
                "{{ data_interval_end | ds }}",
                get_table("post_campaign_period")
            ]
        )

        run_post_campaign_period_sql = MeasurementSnowflakeOperator(
            task_id="run_post_campaign_period_sql",
            sql="mta_tables_setup/post_campaign_period/post_campaign_period.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                    "correlation_id": get_ci()
            },
            doc_md="""This task creates the post_campaign_period table.""",
        )

        start >> branch >> run_post_campaign_period_sql >> finish
        branch >> skip >> finish

    return tg
