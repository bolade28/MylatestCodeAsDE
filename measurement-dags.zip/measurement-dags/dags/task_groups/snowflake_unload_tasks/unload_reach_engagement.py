from airflow.sdk import TaskGroup

from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.xcom import get_manual_campaigns_list, get_resolved_during_correlation_id
from helpers.dag_param import DagParams


def task_group() -> TaskGroup:
    """
    Campaign validation task group that checks if campaigns exist with 'During' status
    """
    with TaskGroup("unload_reach_engagement") as tg:
        MeasurementSnowflakeOperator(
            task_id="reach_engagement_reporting",
            sql="mta_tables_unload/reach_engagement_reporting.sql",
            params={
                'campaign_id_default': DagParams.pipelines_manual_campaign_list,
                'campaign_id_manual': get_manual_campaigns_list(),
                'during_correlation_id': get_resolved_during_correlation_id()
            },
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="Unloads the reach engagement table to run the pipeline for campaigns with 'Post'"
        )

    return tg
