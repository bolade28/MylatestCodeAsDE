from airflow.sdk import TaskGroup
from helpers.constants import (
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
)
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group(campaign_duration: str) -> TaskGroup:
    with TaskGroup('unload_mta_tables', ui_color="ff7f00") as tg:

        MeasurementSnowflakeOperator(
            task_id="unload_campaign_execution",
            sql="mta_tables_unload/campaign_execution.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "campaign_duration": campaign_duration
            },
            doc_md="""This task unloads the campaign execution data to S3.""",
        )

        MeasurementSnowflakeOperator(
            task_id="unload_mta_fact_sale_transaction_item",
            sql="mta_tables_unload/mta_fact_sale_transaction_item.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads item transactions within the in-store campaign window to S3.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_dim_customer_loyalty",
            sql="mta_tables_unload/dim_customer_loyalty.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads the customer loyalty dimension to S3.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_advertising_campaign_citcam_sat",
            sql="mta_tables_unload/advertising_campaign_citcam_sat.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates initial dv360 customer data table.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_digital_trading_campaign_link",
            sql="mta_tables_unload/digital_trading_campaign_link.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates initial dv360 customer data table.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_digital_trading_campaign_insight_link",
            sql="mta_tables_unload/digital_trading_campaign_insight_link.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                    This task contains de-duplicated reach data from Meta
                    """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_digital_trading_campaign_sat",
            sql="mta_tables_unload/digital_trading_campaign_sat.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates initial dv360 customer data table.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_digital_trading_lineitem_fb_insight",
            sql="mta_tables_unload/digital_trading_lineitem_fb_insight.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads fb_insight data to s3.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_floodlight_report",
            sql="mta_tables_unload/floodlight_report.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unload floodlight report to s3.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_unique_reach_lineitem_report_sat",
            sql="mta_tables_unload/unique_reach_lineitem_report.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates initial dv360 customer data table.
                """,
        )

    return tg
