from airflow.providers.standard.operators.python import ShortCircuitOperator
from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule


from helpers.dag_param import DagParams
from helpers.constants import (
    CP_DTP_FILTER,
    CP_EMULATION_FILTER,
    CP_POLLEN_FILTER,
    OVERLAP_POST_PRESENCE_START_RATE,
    OVERLAP_POST_PRESENCE_WEEKLY_DECAY,
    OVERLAP_PRODUCT_TYPES,
    PROD,
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE,
    CAMPAIGN_DURATION_POST
)
from helpers.setup import get_environment
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.utils import is_dtp, is_pollen
from helpers.xcom import (
    get_ci,
    get_campaign_end_date,
    get_post_period_end_date,
    get_resolved_during_correlation_id,
    pipeline_run_type,
    get_emulation_run,
    get_manual_campaigns_list,
    get_booking_reference_date,
)


def create_pipeline_type_conditionals(task_id_prefix: str = ""):
    prefix = f"{task_id_prefix}_" if task_id_prefix else ""

    is_this_dtp = ShortCircuitOperator(
        task_id=f'{prefix}is_dtp',
        python_callable=is_dtp,
        op_kwargs=dict(
            run_type=pipeline_run_type(),
        ),
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
        ignore_downstream_trigger_rules=False,
    )

    is_this_pollen = ShortCircuitOperator(
        task_id=f'{prefix}is_pollen',
        python_callable=is_pollen,
        op_kwargs=dict(
            run_type=pipeline_run_type(),
        ),
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
        ignore_downstream_trigger_rules=False,
    )

    return is_this_dtp, is_this_pollen


def task_group(campaign_duration: str = None) -> TaskGroup:

    with TaskGroup('shared_snowflake_unload', ui_color="ff7f00") as tg:
        s1 = EmptyOperator(
            task_id="s_start", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
        s2 = EmptyOperator(
            task_id="s_end", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        is_this_dtp_unified_campaigns, is_this_pollen_unified_campaigns = create_pipeline_type_conditionals(
            "unified_campaigns")

        # Unified product chain (sequential dependency)
        unload_unified_product = MeasurementSnowflakeOperator(
            task_id="unload_unified_product",
            sql="unified_product/unload_unified_product.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads unified product data to S3
                """,
        )

        load_unified_products_to_snowflake = MeasurementSnowflakeOperator(
            task_id="load_unified_products_to_snowflake",
            sql="load_to_snowflake/persist_unified_products_to_snowflake.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads unified product data from S3 to snowflake in incremental mode
                """,
            params={
                'run_type': pipeline_run_type(),
            },
        )

        unload_campaign_product_type = MeasurementSnowflakeOperator(
            task_id="unload_campaign_product_type",
            sql="campaign_product_type/unload_campaign_product_type.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads campaign product type data to S3
            """,
            params={
                'run_type': pipeline_run_type(),
                'emulated_run': get_emulation_run(),
                'pollen_filter': CP_POLLEN_FILTER,
                'dtp_filter': CP_DTP_FILTER,
                'emulation_filter': CP_EMULATION_FILTER,
            },
        )

        # Parallel independent tasks
        upload_campaign_booking_media_channel = MeasurementSnowflakeOperator(
            task_id="upload_campaign_booking_media_channel",
            sql="pollen_sources/campaign_booking_media_channel.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'emulate_prod_env': get_emulation_run(),
                'is_prod': get_environment() == PROD,
            },
            doc_md="""
                This task unloads campaign_booking_media_channel data to S3 to be used in pollen sources
                """,
        )

        upload_item_brand_hist = MeasurementSnowflakeOperator(
            task_id="unload_item_brand_hist",
            sql="pollen_sources/item_brand_hist.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "brand_time_reference": get_booking_reference_date(),
            },
            doc_md="""
                This task unloads item brand and category SKU mappings to S3.
                """,
        )

        unload_marketing_media_hierarchy_mkthrc_ref = MeasurementSnowflakeOperator(
            task_id="unload_marketing_media_hierarchy_mkthrc_ref",
            sql="mta_tables_unload/marketing_media_hierarchy_mkthrc_ref.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates initial mapping data for marketing_media_hierarchy_mkthrc_ref
                """,
        )

        unload_measurement_marketing_channel_hierarchy = MeasurementSnowflakeOperator(
            task_id="unload_measurement_marketing_channel_hierarchy",
            sql="mta_tables_unload/measurement_marketing_hierarchy.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates initial mapping data for measurement_marketing_channel_hierarchy
                """,
        )

        unload_dim_store_org_hierarchy = MeasurementSnowflakeOperator(
            task_id="unload_dim_store_org_hierarchy",
            sql="base_price_data/dim_store_org_hierarchy.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads dim_store_org_hierarchy data to S3
                """,
        )

        unload_published_campaign_reporting = MeasurementSnowflakeOperator(
            task_id="unload_published_campaign_reporting",
            sql="measurement_campaign_reporting/unload_published_campaign_reporting.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'correlation_id': get_ci(),
                'end_date': (
                    get_post_period_end_date()
                    if campaign_duration == CAMPAIGN_DURATION_POST
                    else get_campaign_end_date()
                ),
            },
            doc_md="""
                This task unloads published_campaign_reporting data to S3
                """,
        )

        # Conditional branch tasks
        unload_unified_campaigns = MeasurementSnowflakeOperator(
            task_id="unload_unified_campaigns",
            sql="unified_campaign/unload_unified_campaigns.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads unified_campaigns data to S3
                """,
        )

        unload_unified_campaigns_pollen = MeasurementSnowflakeOperator(
            task_id="unload_unified_campaigns_pollen",
            sql="unified_campaign/unload_unified_campaigns_pollen.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads unified_campaigns data to S3
                """,
        )

        # TODO:: this is part of overlapping tactical solution and must be later replaced with strategic one
        overlapping_campaign_spend_weights_pollen = MeasurementSnowflakeOperator(
            task_id="overlapping_campaign_spend_weights_pollen",
            sql="overlapping_campaigns/overlapping_campaign_spend_weights_pollen.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'emulate_prod_env': get_emulation_run(),
                'is_prod': get_environment() == PROD,
                'post_presence_start_rate': OVERLAP_POST_PRESENCE_START_RATE,
                'post_presence_weekly_decay': OVERLAP_POST_PRESENCE_WEEKLY_DECAY,
                'product_types': ', '.join(f"('{pt}')" for pt in OVERLAP_PRODUCT_TYPES),
                'campaign_id_default': DagParams.pipelines_manual_campaign_list,
                'campaign_id_manual': f'\"{get_manual_campaigns_list()}"',
            },
            doc_md="""
                This task calculates overlapping campaign spend weights for overlapping pollen campaigns - as part of the agreed tactical solution
                """,
        )

        if campaign_duration == CAMPAIGN_DURATION_POST:
            MeasurementSnowflakeOperator(
                task_id="unload_measurement_campaign_reporting",
                sql="measurement_campaign_reporting/unload_reporting.sql",
                hook_params={
                    "warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    "during_correlation_id": get_resolved_during_correlation_id(),
                },
                doc_md="""
                    This task reads reporting table for campaigns in the post period.
                    """,
            )

        # Dependency flow: s1 (start) -> [parallel branches] -> s2 (end)
        # Sequential unified product chain
        s1 >> unload_unified_product >> load_unified_products_to_snowflake >> unload_campaign_product_type >> s2

        independent_tasks = [
            unload_marketing_media_hierarchy_mkthrc_ref,
            unload_measurement_marketing_channel_hierarchy,
            unload_dim_store_org_hierarchy,
            unload_published_campaign_reporting,
        ]

        s1 >> independent_tasks >> s2
        s1 >> [upload_item_brand_hist,
               upload_campaign_booking_media_channel] >> overlapping_campaign_spend_weights_pollen >> s2

        # Conditional unified campaigns (DTP/Pollen)
        s1 >> [is_this_dtp_unified_campaigns, is_this_pollen_unified_campaigns]
        is_this_dtp_unified_campaigns >> unload_unified_campaigns >> s2
        is_this_pollen_unified_campaigns >> unload_unified_campaigns_pollen >> s2

        # Campaign selection task group

    return tg
