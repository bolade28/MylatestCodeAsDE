from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import (
    CHANNELS,
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE,
    PROD,
)
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.setup import get_environment
from helpers.xcom import get_emulation_run

'''The normalized scripts here are run separately to MTA and Baseline, as they are used later in the MTA unload step pipeline'''


def task_group() -> TaskGroup:

    with TaskGroup('mta_snowflake_unload', ui_color="ff7f00") as tg:
        m1 = EmptyOperator(task_id="m_start", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
        m2 = EmptyOperator(task_id="m_end", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        upload_dv360_normalize = MeasurementSnowflakeOperator(
            task_id="upload_dv360_normalize",
            sql="dv360_normalize/dv360_normalize.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads dv360_normalize data to S3
                """,
        )

        upload_dv360_normalize_pollen = MeasurementSnowflakeOperator(
            task_id="upload_dv360_normalize_pollen",
            sql="dv360_normalize/dv360_normalize_pollen.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'emulate_prod_env': get_emulation_run(),
                'is_prod': get_environment() == PROD,
            },
            doc_md="""
                This task unloads dv360_normalize data to S3
                """,
        )

        unload_fb_campaign_normalized = MeasurementSnowflakeOperator(
            task_id="unload_fb_campaign_normalized",
            sql="fb_campaign_normalized/fb_campaign_normalized.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads fb campaign normalized data to S3
                """,
        )

        unload_youtube_normalize = MeasurementSnowflakeOperator(
            task_id="unload_youtube_normalize",
            sql="youtube_normalize/youtube_normalize.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                    'channel': CHANNELS['youtube']
            },
            doc_md="""
                This task unloads youtube normalized data to S3
                """,
        )

        unload_fb_insight_normalize = MeasurementSnowflakeOperator(
            task_id="unload_fb_insight_normalize",
            sql="fb_insight_normalize/fb_insight_normalize.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads facebook insight normalized data to S3
                """,
        )

        # Dependency flow: m1 (start) -> [parallel unloads] -> m2 (end)
        m1 >> [
            upload_dv360_normalize,
            upload_dv360_normalize_pollen,
            unload_fb_campaign_normalized,
            unload_youtube_normalize,
            unload_fb_insight_normalize,
        ] >> m2

    return tg
