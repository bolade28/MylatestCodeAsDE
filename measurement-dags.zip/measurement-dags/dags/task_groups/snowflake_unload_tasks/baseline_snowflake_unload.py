from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.dag_param import DagParams
from helpers.constants import (
    DTP_RUN_TYPE,
    EXT_CHRISTMAS_LIST,
    EXT_HOLIDAY_NAME_LIST,
    EXT_HOLIDAY_TYPE_FILTER,
    EXT_MARKETING_SUB_CHANNEL_EXTEND,
    NUMBER_OF_WEEKS,
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE,
    POLLEN_RUN_TYPE,
)
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_booking_reference_date
from helpers.xcom import (
    get_ci,
    get_model_start_end_dates,
    get_resolved_during_correlation_id,
    get_stage,
    get_table,
    pipeline_run_type,
)
from helpers.xcom import get_manual_campaigns_list


def task_group(is_post_period: bool = False) -> TaskGroup:

    with TaskGroup('baseline_snowflake_unload', ui_color="ff7f00") as tg:

        b1 = EmptyOperator(task_id='unload_queries')
        b2 = EmptyOperator(task_id="b_start", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
        b3 = EmptyOperator(task_id="b_end", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        unload_temp_unified_product = MeasurementSnowflakeOperator(
            task_id="unload_temp_unified_product",
            sql="temp_unified_product/temp_unified_product.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'correlation_id': get_ci(),
                'brand_time_reference': get_booking_reference_date(),
            },
            doc_md="""
                This task unloads temp_unified_product to S3
                """,
        )

        unload_legacy_campaign_performance_data = MeasurementSnowflakeOperator(
            task_id="unload_legacy_campaign_performance_data",
            sql="ucm_shrinkage_sources/measurement_legacy_campaign_performance.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads measurement_legacy_campaign_performance data to S3 to be used for the UCM shrinkage algorithm
            """,
        )

        unload_super_category_yearly_inflation = MeasurementSnowflakeOperator(
            task_id="unload_super_category_yearly_inflation",
            sql="ucm_shrinkage_sources/unload_super_category_yearly_inflation.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads measurement_legacy_campaign_performance data to S3 to be used for the UCM shrinkage algorithm
            """,
        )

        agg_value_index_dashboard_w_unload = MeasurementSnowflakeOperator(
            task_id="agg_value_index_dashboard_w_unload",
            sql="value_index_processed_data/agg_value_index_dashboard_w.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads baseline_modelling_output to S3 - BASELINE
                """,
        )

        dv360_media_report_unload = MeasurementSnowflakeOperator(
            task_id="dv360_media_report_unload",
            sql="dv360_processed_data/dv360_media_report.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads baseline_modelling_output to S3 - baseline
                """,
        )

        unload_baseline_primary_metric = MeasurementSnowflakeOperator(
            task_id="unload_baseline_primary_metric",
            sql="feature_prioritisation/baseline_primary_metric.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads the baseline primary metric data to S3
                """,
        )

        coupon_at_till_processed_data_unload = coupon_at_till_processed_data_task_group()
        additional_sales_data_transaction_unload = additional_sales_data_transaction_task_group()
        youtube_processed_data_unload = youtube_processed_data_task_group()
        citrus_process_data_unload = citrus_process_data_task_group()
        instore_process_data_unload = instore_process_data_task_group()
        baseline_modelling_dataset_unload = three_letter_coding_task_group()
        # baseline_forecasting_call_unload = baseline_forecasting_call_task_group()
        new_launch_estimation_unload = new_launch_estimation_task_group()
        secondary_space_unload = secondary_space_task_group()
        ecoupon_processed_data_unload = ecoupon_processed_data_task_group()

        transactions_unload = MeasurementSnowflakeOperator(
            task_id="unload_transactions",
            sql="transactions/unload_transactions.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},

            doc_md="""
                This task unloads transactions data to S3 - baseline
                """,
        )
        create_weekly_dates_table = MeasurementSnowflakeOperator(
            task_id="create_weekly_dates_table",
            sql="daily_etl/weekly_start_dates.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'number_of_weeks': NUMBER_OF_WEEKS,
                'booking_end_date': get_model_start_end_dates('end_date'),
                'run_date': '{{data_interval_end | ds }}'
            },
            doc_md="""
                This task creates weekly dates table with monday as start of week. This is used in baseline DAG. - Baseline
                """,
        )

        weekly_dates_unload = MeasurementSnowflakeOperator(
            task_id="unload_weekly_dates",
            sql="unload_table.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'table': get_table('weekly_start_dates'),
                'output': get_stage('weekly_dates')
            },
            doc_md="""
                This task unloads weekly dates table to S3. The table was not created by daily etl DAG. - Baseline
                """,
        )

        unload_external_processed_data_output = MeasurementSnowflakeOperator(
            task_id="unload_external_processed_data_output",
            sql="external_data/external_processed_data_output.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'correlation_id': get_ci(),
                'start_date': get_model_start_end_dates('start_date'),
                'end_date': get_model_start_end_dates('end_date'),
                'ext_holiday_name_list': EXT_HOLIDAY_NAME_LIST,
                'ext_holiday_type_filter': EXT_HOLIDAY_TYPE_FILTER,
                'ext_christmas_list': EXT_CHRISTMAS_LIST,
                'ext_marketing_sub_channel_extend': EXT_MARKETING_SUB_CHANNEL_EXTEND,
            },
            doc_md="""
                    This task unloads external_processed_data_output to S3
                    """,
        )

        if is_post_period:
            unload_during_ucm_output = MeasurementSnowflakeOperator(
                task_id="unload_during_ucm_output",
                sql="baseline_modelling_output/unload_ucm_output_during.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'during_correlation_id': get_resolved_during_correlation_id(),
                },
                doc_md="""
                    Unloads the during run's best-iteration UCM output from Snowflake to S3
                    for post-period baseline modelling.
                """,
            )

        # Dependency flow: b1 (entry) -> b2 (start) -> [parallel work] -> b3 (end)
        b1 >> b2

        # Simple unloads
        b2 >> [
            unload_temp_unified_product,
            agg_value_index_dashboard_w_unload,
            dv360_media_report_unload,
            unload_baseline_primary_metric
        ] >> b3

        if is_post_period:
            b2 >> unload_during_ucm_output >> b3

        # Legacy campaign performance chain
        b2 >> unload_legacy_campaign_performance_data >> unload_super_category_yearly_inflation >> b3

        # Main sequential data processing chain
        b2 >> [
            baseline_modelling_dataset_unload,
            coupon_at_till_processed_data_unload,
            additional_sales_data_transaction_unload,
            citrus_process_data_unload,
            youtube_processed_data_unload,
            # baseline_forecasting_call_unload,
            instore_process_data_unload,
            new_launch_estimation_unload,
            ecoupon_processed_data_unload
        ] >> create_weekly_dates_table >> secondary_space_unload >> unload_external_processed_data_output >> transactions_unload >> weekly_dates_unload >> b3

    return tg


def youtube_processed_data_task_group() -> TaskGroup:
    with TaskGroup('youtube_processed_data_unload', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="unload_youtube_processed_data",
            sql="youtube_processed_data/media_report.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads youtube processed data to S3
                """,
        )
    return tg


def coupon_at_till_processed_data_task_group() -> TaskGroup:
    with TaskGroup('coupon_at_till_processed_data_unload', ui_color="ff7f01") as tg:
        MeasurementSnowflakeOperator(
            task_id="unload_base_finance_assets",
            sql="coupon_at_till_processed_data/base_finance_assets.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads  coupon_at_till_processed_data base_finance_assets data to S3 - baseline
                """,
        ),
        MeasurementSnowflakeOperator(
            task_id="unload_campaign",
            sql="coupon_at_till_processed_data/campaign.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads  coupon_at_till_processed_data campaign data to S3 - baseline
                """,
        ),
        MeasurementSnowflakeOperator(
            task_id="unload_cell",
            sql="coupon_at_till_processed_data/cell.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads  coupon_at_till_processed_data cell data to S3 - baseline
                """,
        ),
        MeasurementSnowflakeOperator(
            task_id="unload_coupon_cell",
            sql="coupon_at_till_processed_data/coupon_cell.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads  coupon_at_till_processed_data coupon_cell data to S3 - baseline
                """,
        ),
        MeasurementSnowflakeOperator(
            task_id="unload_coupon_to_product",
            sql="coupon_at_till_processed_data/coupon_to_product.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'run_type': pipeline_run_type(),
                'dtp_run': DTP_RUN_TYPE,
            },
            doc_md="""
                This task unloads  coupon_at_till_processed_data coupon_to_product data to S3 - baseline
                """,
        ),
        MeasurementSnowflakeOperator(
            task_id="unload_coupon",
            sql="coupon_at_till_processed_data/coupon.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads  coupon_at_till_processed_data coupon data to S3 - baseline
                """,
        )
    return tg


def additional_sales_data_transaction_task_group() -> TaskGroup:

    with TaskGroup('additional_sales_data_transaction', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="unload_fact_sales_transaction_item",
            sql="sales_data_transaction/fact_sales_transaction_item.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                    'start_date': get_model_start_end_dates('start_date'),
                    'end_date': get_model_start_end_dates('end_date'),
                    'campaign_id_default': DagParams.pipelines_manual_campaign_list,
                    'campaign_id_manual': f'\"{get_manual_campaigns_list()}"',
                    'run_type': pipeline_run_type(),
                    'dtp_run': DTP_RUN_TYPE,
                    'pollen_run': POLLEN_RUN_TYPE,
                    'brand_time_reference': get_booking_reference_date(),
            },
            doc_md="""
                This task unloads fact sales transaction data on item level to S3
                """,
        ),
        MeasurementSnowflakeOperator(
            task_id="unload_fact_sales_transaction_item_agg",
            sql="sales_data_transaction/fact_sales_transaction_item_agg.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                    'start_date': get_model_start_end_dates('start_date'),
                    'end_date': get_model_start_end_dates('end_date'),
            },
            doc_md="""
                This task unloads fact sales transaction data on item level to S3
                """,
        ),
        MeasurementSnowflakeOperator(
            task_id="unload_fact_sales_transaction_basket",
            sql="sales_data_transaction/fact_sales_transaction_basket.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads fact sales transaction basket data on item level to S3
                """,
        )
    return tg


def citrus_process_data_task_group() -> TaskGroup:
    with TaskGroup('citrus_process_data_unload', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="unload_advertise_request_realised",
            sql="advertise_request_realised/advertise_request_realised.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "start_date": str(get_model_start_end_dates('start_date')),
                "end_date": str(get_model_start_end_dates('end_date')),
            },
            doc_md="""
                This task unloads advertise request realised data to S3
                """,
        )
    return tg


def three_letter_coding_task_group() -> TaskGroup:
    with TaskGroup('three_letter_coding_unload', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="unload_three_letter_coding",
            sql="three_letter_coding/baseline_modelling_dataset.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads baseline modelling dataset data to S3 - BASELINE
                """,
        )
    return tg


def instore_process_data_task_group() -> TaskGroup:
    with TaskGroup('instore_process_data_unload', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="unload_ie_campaign_filt",
            sql="instore_process_data/ie_campaign_filt.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads ie_campaign_filt data to S3
                """,
        )
        MeasurementSnowflakeOperator(
            task_id="unload_media_instore_init",
            sql="instore_process_data/media_instore_init.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads media_instore_init data to S3
                """,
        )
        MeasurementSnowflakeOperator(
            task_id="unload_ie_product",
            sql="instore_process_data/ie_product.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads ie_product data to S3
                """,
        )
        MeasurementSnowflakeOperator(
            task_id="unload_ie_location",
            sql="instore_process_data/ie_location.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads ie_location data to S3
                """,
        )
        MeasurementSnowflakeOperator(
            task_id="unload_unified_channel_active_media",
            sql="instore_process_data/unified_channel_active_media.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads ie_product data to S3
                """,
        )
        MeasurementSnowflakeOperator(
            task_id="unload_cust_by_location",
            sql="instore_process_data/cust_by_location_unload.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                    'start_date': get_model_start_end_dates('start_date'),
                    'end_date': get_model_start_end_dates('end_date'),
            },
            doc_md="""
                This task unloads cust_by_location data to S3
                """,
        )
    return tg


def new_launch_estimation_task_group() -> TaskGroup:
    with TaskGroup('new_launch_estimation_unload', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="unload_sku_cluster_mapping",
            sql="new_launch_estimation/sku_cluster_mapping.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads media_instore_init data to S3
                """,
        )
    return tg


def secondary_space_task_group() -> TaskGroup:
    with TaskGroup('secondary_space_unload', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="unload_dim_section",
            sql="secondary_space_processed_data/dim_section.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads dim_section data to S3
                """,
        )
        MeasurementSnowflakeOperator(
            task_id="unload_plngrm_campaign_item",
            sql="secondary_space_processed_data/planogram_campaigns.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'start_date': get_model_start_end_dates('start_date'),
                'end_date': get_model_start_end_dates('end_date'),
            },
            doc_md="""
                This task unloads flf_str_planogram_campaigns data to S3
                """,
        )
    return tg


def ecoupon_processed_data_task_group() -> TaskGroup:
    with TaskGroup('ecoupon_processed_data_unload', ui_color="ff7f01") as tg:
        MeasurementSnowflakeOperator(
            task_id="unload_oc_campaign",
            sql="ecoupon_processed_data/oc_campaign.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads ecoupon_processed_data oc_campaign data to S3
                """,
        ),
        MeasurementSnowflakeOperator(
            task_id="unload_oc_customer_selection",
            sql="ecoupon_processed_data/oc_customer_selection.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads ecoupon_processed_data oc_customer_selection to S3
                """,
        ),
        MeasurementSnowflakeOperator(
            task_id="unload_oc_products",
            sql="ecoupon_processed_data/oc_products.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads ecoupon_processed_data oc_products data to S3
                """,
        )
    return tg
