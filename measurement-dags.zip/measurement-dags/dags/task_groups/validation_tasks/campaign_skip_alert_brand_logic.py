from airflow.sdk import Variable
from airflow.providers.standard.operators.python import PythonOperator
from airflow.sdk import TaskGroup
from airflow.providers.slack.operators.slack import SlackAPIPostOperator

from helpers.xcom import (
    get_ci,
    get_configured_campaign,
    get_pipelines_version,
    get_resolved_during_correlation_id,
)


def task_group() -> TaskGroup:

    with TaskGroup("brand_logic_inconsistent") as alert_tg:
        """
        This task group first checks brand-logic consistency for the configured
        during_correlation_id, then (if inconsistent) sends alerts to notify measurement
        team that pipeline was skipped because this POST run's during_correlation_id used
        legacy brand logic for a booking that already has a completed DURING run using new
        brand logic.
        """

        send_alert = SlackAPIPostOperator(
            task_id="slack_alert_campaign_skip_brand_logic",
            channel=f'#measurement-ops-{Variable.get("MEASUREMENT_ENVIRONMENT")}',
            text=get_post_campaign_alert_message(ci=get_ci()),
        )

        skip_downstream = PythonOperator(
            task_id="skip_pipeline",
            python_callable=_mark_validation_failed,
        )

        send_alert >> skip_downstream

    return alert_tg


def get_post_campaign_alert_message(ci: str) -> str:
    """Returns text for brand-logic mismatch alert"""
    return f""":red_circle: pipeline skipped
        This booking already has a completed DURING run using new brand logic, but this POST run
        is configured against a legacy during_correlation_id.
        Correlation id: {ci}
        Job bag number(s): {get_configured_campaign()}
        Pipeline hash: {get_pipelines_version()}
        Correlation id for the during run: {get_resolved_during_correlation_id()}
        The baseline MTA pipeline has been stopped. Please re-run POST against the correlation id
        of the new-brand-logic DURING run instead.
        """


def _mark_validation_failed(**context):
    """Mark that validation failed"""
    context['task_instance'].xcom_push(key='validation_failed', value=True)
