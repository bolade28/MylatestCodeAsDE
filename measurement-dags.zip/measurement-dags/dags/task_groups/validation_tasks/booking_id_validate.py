from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.sdk import TaskGroup

from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_configured_campaign, pipeline_run_type, get_booking_id_validation_results, get_emulation_run
from helpers.dag_param import DagParams
from helpers.constants import (
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE,
    DTP_RUN_TYPE,
    POLLEN_RUN_TYPE,
)


def _decide_to_continue_or_skip(parent_group_id: str, **context):
    """
    Check booking id exists in unified campaign tables and decide whether to continue or skip pipeline
    """
    validation_results = get_booking_id_validation_results(parent_group_id)

    # validation_results expected to be rows like [booking_id, is_valid_bool]
    valid_found = False
    if validation_results:
        # Check boolean validity flag in result rows (row[1])
        valid_found = any(bool(row[1]) for row in validation_results)

    if valid_found:
        # Booking id validated -> continue to booking item cd validation
        return f"{parent_group_id}.booking_item_cd_list_validate.check_booking_item_cd_list"

    else:
        # No matching booking id found -> skip pipeline with campaign skip alert
        return f"{parent_group_id}.campaign_skip_alert_missing_booking.slack_alert_campaign_skip_missing_booking"
        # return f"validation_failed_for_{parent_group_id}"


def task_group(parent_group_id: str = 'campaign_validations') -> TaskGroup:
    with TaskGroup('booking_id_validate', ui_color="ff7f00") as tg:
        campaign_check = MeasurementSnowflakeOperator(
            task_id="check_booking_id",
            sql="validate_campaign_data/check_booking_id.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'campaign_id_default': DagParams.pipelines_manual_campaign_list,
                'campaign_id_manual': get_configured_campaign(),
                'emulate_prod_env': get_emulation_run(),
                'run_type': pipeline_run_type(),
                'dtp_run': DTP_RUN_TYPE,
                'pollen_run': POLLEN_RUN_TYPE
            },
            doc_md="""
                This task validates whether the provided job bag number exists in the
                unified campaign tables (DTP or pollen or emulated). If not present the pipeline will be skipped.
                    """,
        )

        decide = BranchPythonOperator(
            task_id='campaigns_qualification_check',
            python_callable=_decide_to_continue_or_skip,
            op_kwargs={'parent_group_id': parent_group_id},
            doc_md="""
                This task decides whether to continue or skip the pipeline based on booking id existence
                """,
        )

        campaign_check >> decide
        return tg
