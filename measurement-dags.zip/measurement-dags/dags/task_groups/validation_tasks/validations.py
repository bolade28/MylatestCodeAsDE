from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.sdk import TaskGroup
from task_groups.validation_tasks import booking_id_validate, booking_item_cd_list_validate, campaign_continue_alert, \
    campaign_media_spend_validate, campaign_skip_alert, campaign_skip_alert_brand_logic, campaign_skip_alert_media, \
    campaign_validation, campaign_skip_alert_multi_brand, campaign_skip_alert_booking_skus, \
    campaign_skip_alert_missing_booking, campaign_multi_brand_validate, campaign_partial_evaluation_alert, \
    offer_skus_dim_item_validate, campaign_skip_alert_missing_dim_item_skus
from task_groups import during_lookup
from helpers.constants import (
    CAMPAIGN_DURATION_DURING,
    CAMPAIGN_DURATION_POST,
    EvaluationPhase
)


def task_group() -> TaskGroup:
    """
    Combined validation task group that checks:
    1. Multi-brand campaigns
    2. Booking ID existence
    3. Booking item cd lists
    4. Offer SKUs existence in DIM_ITEM
    5. Campaign media spend (with 'During' duration)

    Containing routes to appropriate alert task groups if validation fails
    """
    with TaskGroup('campaign_validations', ui_color="#ff7f00") as tg:
        # Validation checks
        validate_multi_brand = campaign_multi_brand_validate.task_group(parent_group_id='campaign_validations')
        validate_booking_id = booking_id_validate.task_group(parent_group_id='campaign_validations')
        validate_booking_item_cd = booking_item_cd_list_validate.task_group(parent_group_id='campaign_validations')
        validate_offer_skus_dim_item = offer_skus_dim_item_validate.task_group(parent_group_id='campaign_validations')
        # We pass in the group name to ensure correct task referencing in the branching operator between dags
        # ToDo make these configure parameters in the future if needed
        validate_media_spend = campaign_media_spend_validate.task_group(
            campaign_duration=CAMPAIGN_DURATION_DURING,
            parent_group_id='campaign_validations'
        )

        # Alert task groups
        alert_booking_skus = campaign_skip_alert_booking_skus.task_group(parent_group_id='campaign_validations')
        alert_missing_dim_item_skus = campaign_skip_alert_missing_dim_item_skus.task_group(
            parent_group_id='campaign_validations'
        )
        alert_booking_not_found = campaign_skip_alert_missing_booking.task_group()
        alert_multi_brand = campaign_skip_alert_multi_brand.task_group(parent_group_id='campaign_validations')
        alert_media_spend = campaign_skip_alert_media.task_group()

        # Returns list of valid campaigns after media spend check
        select_campaigns = campaign_media_spend_validate.qualified_campaigns_list(parent_group_id='campaign_validations')

        # Campaign mismatch check and alert
        mismatch_check_and_alert = campaign_partial_evaluation_alert.create_mismatch_check_and_alert(
            group_id='campaign_mismatch_check_and_alert',
        )

        # Single exit point when all validations are complete
        validation_complete = EmptyOperator(
            task_id='validation_complete',
            trigger_rule='none_failed_min_one_success'
        )

        # Flow: booking id existence -> multi-brand check -> booking validation -> media validation -> select campaigns -> check mismatch -> alert -> validation complete
        validate_multi_brand >> validate_booking_id >> validate_booking_item_cd >> validate_offer_skus_dim_item >> validate_media_spend >> select_campaigns >> mismatch_check_and_alert >> validation_complete

        # If the validation failed, an alert will be sent out and the pipeline gets skipped
        validate_booking_id >> alert_booking_not_found >> validation_complete
        validate_multi_brand >> alert_multi_brand >> validation_complete
        validate_booking_item_cd >> alert_booking_skus >> validation_complete
        validate_offer_skus_dim_item >> alert_missing_dim_item_skus >> validation_complete
        validate_media_spend >> alert_media_spend >> validation_complete

        return tg


def task_group_post() -> TaskGroup:
    """
    Combined validation task group for post-period campaigns that checks:
    1. Campaign existence (with 'During' status)
    2. Booking ID existence
    3. Booking item cd lists
    4. Campaign media spend (with 'Post' duration)

    Containing routes to appropriate alert task groups if validation fails
    """
    with TaskGroup('campaign_validations_post', ui_color="#ff7f00") as tg:
        # Validation checks
        # Tasks specific to post-period validation only do not need a parent_group_id parameter
        # Run booking id validation first, then campaign existence validation
        validate_booking_id = booking_id_validate.task_group(parent_group_id='campaign_validations_post')
        validate_campaign_existence = campaign_validation.task_group()
        validate_booking_item_cd = booking_item_cd_list_validate.task_group(parent_group_id='campaign_validations_post')
        validate_offer_skus_dim_item = offer_skus_dim_item_validate.task_group(parent_group_id='campaign_validations_post')
        validate_media_spend = campaign_media_spend_validate.task_group(
            campaign_duration=CAMPAIGN_DURATION_POST,
            parent_group_id='campaign_validations_post'
        )

        # Alert task groups
        alert_campaign_not_found = campaign_skip_alert.task_group()
        alert_booking_not_found = campaign_skip_alert_missing_booking.task_group()
        alert_campaign_continue = campaign_continue_alert.task_group()
        alert_booking_skus = campaign_skip_alert_booking_skus.task_group(parent_group_id='campaign_validations_post')
        alert_missing_dim_item_skus = campaign_skip_alert_missing_dim_item_skus.task_group(
            parent_group_id='campaign_validations_post'
        )
        alert_media_spend = campaign_skip_alert_media.task_group()
        alert_brand_logic = campaign_skip_alert_brand_logic.task_group()
        resolve_during = during_lookup.task_group()

        # Returns list of valid campaigns after media spend check
        select_campaigns = campaign_media_spend_validate.qualified_campaigns_list(parent_group_id='campaign_validations_post')

        # Campaign mismatch check and alert
        mismatch_check_and_alert = campaign_partial_evaluation_alert.create_mismatch_check_and_alert(
            group_id='campaign_mismatch_check_and_alert',
        )

        # Single exit point when all validations are complete
        validation_complete = EmptyOperator(
            task_id='validation_complete',
            trigger_rule='none_failed_min_one_success'
        )

        # Flow: During campaign existence check first -> resolve During CID -> brand-logic check ->
        # booking validation -> booking item cd validation -> media validation -> select campaigns
        # -> check mismatch -> alert -> validation complete

        # If campaigns don't exist -> skip alert
        # If campaigns exist -> continue alert -> resolve During CID
        validate_campaign_existence >> [alert_campaign_not_found, alert_campaign_continue]

        alert_campaign_continue >> resolve_during
        resolve_during >> [validate_booking_id, alert_brand_logic]

        # If booking id missing -> booking not found alert
        # If booking id present -> booking item cd validation
        validate_booking_id >> [alert_booking_not_found, validate_booking_item_cd]

        # If booking item cd list invalid -> booking alert
        # If booking item cd list valid -> DIM_ITEM SKU validation
        validate_booking_item_cd >> [alert_booking_skus, validate_offer_skus_dim_item]

        # If any offer sku is missing in DIM_ITEM -> DIM_ITEM sku alert
        # If all offer skus exist -> media spend validation
        validate_offer_skus_dim_item >> [alert_missing_dim_item_skus, validate_media_spend]

        # If no media spend -> media alert
        # If media spend exists -> select campaigns -> check mismatch -> alert -> complete
        validate_media_spend >> [alert_media_spend, select_campaigns]
        select_campaigns >> mismatch_check_and_alert >> validation_complete

        # If the validation failed, an alert will be sent out and the pipeline gets skipped
        alert_campaign_not_found >> validation_complete
        alert_booking_not_found >> validation_complete
        alert_booking_skus >> validation_complete
        alert_missing_dim_item_skus >> validation_complete
        alert_media_spend >> validation_complete
        alert_brand_logic >> validation_complete

        return tg


def check_validation_status(parent_group_id: str, evaluation_phase: EvaluationPhase = EvaluationPhase.DURING.value, **context):
    """
    Check if any validation alerts were triggered.

    We use the parent_group_id to ensure correct task referencing in different DAGs (During and Post)
    """
    ti = context['task_instance']

    # Check if an alert task pushed the validation_failed marker
    booking_failed = ti.xcom_pull(
        task_ids=f'{parent_group_id}.campaign_skip_alert_booking_item_cd.skip_pipeline',
        key='validation_failed'
    )

    media_failed = ti.xcom_pull(
        task_ids=f'{parent_group_id}.campaign_skip_alert_media.skip_pipeline',
        key='validation_failed'
    )

    # Check if booking id missing alert was triggered (both During and Post use this alert)
    booking_id_failed = ti.xcom_pull(
        task_ids=f'{parent_group_id}.campaign_skip_alert_missing_booking.skip_pipeline',
        key='validation_failed'
    )

    # Check if multi-brand campaign alert was triggered
    multi_brand_failed = ti.xcom_pull(
        task_ids=f'{parent_group_id}.campaign_skip_alert_multi_brand.skip_pipeline',
        key='validation_failed'
    )

    dim_item_sku_failed = ti.xcom_pull(
        task_ids=f'{parent_group_id}.campaign_skip_alert_missing_dim_item_skus.skip_pipeline',
        key='validation_failed'
    )

    # Only check for campaign_not_found and brand-logic mismatch in post-period validation
    if parent_group_id == 'campaign_validations_post':
        campaign_not_found = ti.xcom_pull(
            task_ids=f'{parent_group_id}.campaign_skip_alert.skip_pipeline',
            key='validation_failed'
        )
        brand_logic_failed = ti.xcom_pull(
            task_ids=f'{parent_group_id}.brand_logic_inconsistent.skip_pipeline',
            key='validation_failed'
        )
    else:
        campaign_not_found = False
        brand_logic_failed = False

    # ToDo: may need to add a separate case for post and during validation failures
    if booking_failed or booking_id_failed or media_failed or campaign_not_found or multi_brand_failed or dim_item_sku_failed or brand_logic_failed:
        # This is a branch to indicate validation failure
        return 'validation_failed'
    else:
        # This refers to the snowflake unload task downstream. brand-logic validation now runs inside
        # campaign_validations_post, so both During and Post proceed to start_checkpoint.
        return 'start_checkpoint'
