from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.sdk import TaskGroup

from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_configured_campaign
from helpers.dag_param import DagParams
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE


def _decide_to_continue_or_skip(parent_group_id: str, **context):
    """
    Check whether all offer SKUs for selected bookings exist in DIM_ITEM.

    If query returns rows, at least one SKU is missing and we route to alert/skip.
    """
    task_instance = context['task_instance']
    validation_results = task_instance.xcom_pull(
        task_ids=f'{parent_group_id}.offer_skus_dim_item_validate.check_offer_skus_in_dim_item'
    )

    missing_sku_rows = validation_results or []
    if missing_sku_rows:
        return f"{parent_group_id}.campaign_skip_alert_missing_dim_item_skus.prepare_alert_message"

    return f"{parent_group_id}.media_spend_campaign_validate.check_media_spend_data"


def task_group(parent_group_id: str = 'campaign_validations') -> TaskGroup:
    with TaskGroup('offer_skus_dim_item_validate', ui_color='ff7f00') as tg:
        sku_check = MeasurementSnowflakeOperator(
            task_id='check_offer_skus_in_dim_item',
            sql='validate_campaign_data/check_offer_skus_in_dim_item.sql',
            hook_params={'warehouse': SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'campaign_id_default': DagParams.pipelines_manual_campaign_list,
                'campaign_id_manual': get_configured_campaign(),
            },
            doc_md="""
                This task validates whether all selected booking offer SKUs exist in DIM_ITEM.
                If any SKU is missing, the run is stopped before downstream heavy processing.
            """,
        )

        decide = BranchPythonOperator(
            task_id='campaigns_qualification_check',
            python_callable=_decide_to_continue_or_skip,
            op_kwargs={'parent_group_id': parent_group_id},
            doc_md="""
                Route to media-spend validation when all offer SKUs exist in DIM_ITEM,
                otherwise route to the skip/alert path.
            """,
        )

        sku_check >> decide
        return tg
