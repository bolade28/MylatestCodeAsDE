from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.sdk import TaskGroup

from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_booking_reference_date, get_configured_campaign, get_multi_brand_validation_results
from helpers.dag_param import DagParams
from helpers.constants import (
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE,
)


def _decide_to_continue_or_fail_multi_brand(parent_group_id: str, **context):
    """
    Check if any campaign within the booking is multi-brand and decide whether to continue or fail the entire booking.
    If any campaign is multi-brand, the entire booking run fails.
    """
    validation_results = get_multi_brand_validation_results(parent_group_id)

    if validation_results:
        # Check if any campaign is multi-brand (is_multi_brand = True/1)
        multi_brand_found = any(bool(row[2]) for row in validation_results)

        if multi_brand_found:
            # Multi-brand campaign found in booking -> fail with alert
            return f"{parent_group_id}.campaign_skip_alert_multi_brand.slack_alert_multi_brand_campaign"

    # No multi-brand campaigns found -> continue to next validation
    return f"{parent_group_id}.booking_id_validate.check_booking_id"


def task_group(parent_group_id: str = 'campaign_validations') -> TaskGroup:
    with TaskGroup('campaign_multi_brand_validate', ui_color="ff7f00") as tg:
        campaign_check = MeasurementSnowflakeOperator(
            task_id="check_multi_brand_campaigns",
            sql="validate_campaign_data/check_multi_brand_campaigns.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'brand_time_reference': get_booking_reference_date(),
                'campaign_id_default': DagParams.pipelines_manual_campaign_list,
                'campaign_id_manual': get_configured_campaign(),
            },
            doc_md="""
                This task validates whether any campaign within the booking contains multiple brands.
                Multi-brand campaigns are not supported and will cause the entire booking run to fail.
                    """,
        )

        decide = BranchPythonOperator(
            task_id='multi_brand_check',
            python_callable=_decide_to_continue_or_fail_multi_brand,
            op_kwargs={'parent_group_id': parent_group_id},
            doc_md="""
                This is a temporary task that decides whether to continue or fail the pipeline based on multi-brand campaign detection.
                If any multi-brand campaigns are found, the entire booking run fails.
                """,
        )

        campaign_check >> decide
        return tg
