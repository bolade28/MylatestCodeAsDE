from typing import Optional, Any
from airflow.providers.standard.operators.python import PythonOperator
from airflow.sdk import TaskGroup, task
from helpers.aws import FileExistsOperator
from helpers.aws import parquet_files_exist
import logging
from helpers.xcom import (
    get_pipelines_version,
    get_configured_campaign,
    get_during_correlation_id,
    pipeline_run_type,
    get_table,
    get_experimentation_flag,
)
from helpers.constants import PROD, POLLEN_RUN_TYPE, DTP_RUN_TYPE, SNOWFLAKE_CONN_ID
from js_snowflake.hooks.snowflake import SnowflakeKeyArnHook as SnowflakeHook
from helpers.snowflake import check_campaign_data_exists, has_campaign_ended, resolve_during_correlation_id
from helpers.constants import FileExists, EvaluationPhase
from helpers.setup import get_environment, resolve_previous_paths

from helpers.utils import normalize_ids
from helpers.snowflake import resolve_booking_reference_date


def task_group(evaluation_phase: EvaluationPhase = EvaluationPhase.DURING) -> TaskGroup:
    """
    Combined validation task group that checks:
    1. whether Pipelines commit hash value provided as DAG config exists in the
    S3 bucket where pipelines deployment artefacts are stored
    2. Breaks the pipeline if the provided pipelines commit hash value doesn't exist
    This is to ennsure we don't unload snowflake data and spin up EMR for our pipeline run and waste resources.

    """
    with TaskGroup('config_and_validation') as config_validate:

        with TaskGroup('config_setup') as setup_group:
            fetch_booking_name = fetch_booking_name_from_snowflake(
                booking_id=get_configured_campaign(),
                run_type=pipeline_run_type(),
                pollen_table=get_table("campaign_booking_media_channel"),
                dtp_table=get_table("measurement_unified_campaign")
            )
            booking_reference_date = configure_booking_reference_date(
                booking_ids=get_configured_campaign(),
                booking_table=get_table("campaign_booking_media_channel"),
                fallback_booking_table=get_table("campaign_booking_media_channel_prod"),
                run_type=pipeline_run_type(),
            )

            if evaluation_phase == EvaluationPhase.POST:
                resolve_during_ci = PythonOperator(
                    task_id='resolve_during_correlation_id',
                    python_callable=resolve_during_correlation_id,
                    op_kwargs={
                        'configured_during_cid': get_during_correlation_id(),
                        'configured_campaign_id': get_configured_campaign(),
                        'table': get_table('measurement_campaign_reporting_aws'),
                        'run_type': pipeline_run_type(),
                    },
                )
                previous_paths = resolve_previous_paths(
                    during_correlation_id=resolve_during_ci.output,
                )

                [fetch_booking_name, booking_reference_date] >> resolve_during_ci
                resolve_during_ci >> previous_paths

        with TaskGroup('validate_setup') as check_setup:

            env = get_environment()

            are_files_deployed = FileExistsOperator(
                task_id='check_pipelines_hash_exists',
                bucket=f"measurement-{env}-artefacts",
                prefix=f"pipelines/{get_pipelines_version()}"
            )

            validate = validate_artifact_exists(
                file_exists_result=are_files_deployed.output,
                pipelines_version=get_pipelines_version(),
                env=env
            )

            validate_existing_campaign_data(
                experiment_flag=get_experimentation_flag(),
                table=get_table("measurement_metadata"),
                booking_id=get_configured_campaign(),
                run_type=pipeline_run_type(),
                evaluation_phase=evaluation_phase.value,
            )

            validate_campaign_end_date_passed(
                table=get_table("measurement_unified_campaign_pollen"),
                booking_id=get_configured_campaign(),
                run_date='{{data_interval_end | ds }}',
                evaluation_phase=evaluation_phase.value,
            )

            are_files_deployed >> validate

        setup_group >> check_setup

    return config_validate


@task
def validate_existing_campaign_data(
    experiment_flag: bool,
    table: str,
    booking_id: str,
    run_type: str,
    evaluation_phase: EvaluationPhase,
):
    if not experiment_flag or get_environment() == PROD:
        print("experiment flag is set to false  or environment is PROD — skipping existing data check.")
        return None

    existing_cid = check_campaign_data_exists(
        table=table,
        booking_id=booking_id,
        run_type=run_type,
        evaluation_phase=evaluation_phase,
    )

    if existing_cid is None:
        print(f"Going ahead with the run as no experimentation data found for campaign {booking_id}.")
        return None

    # Now verify the data actually exists in S3
    parquet_files = parquet_files_exist(
        bucket="measurement-dev-experiment",
        prefix=f"{existing_cid}/"
    )

    if parquet_files:
        raise ValueError(
            f"Experimentation data already exists in S3 for booking ID '{booking_id}'.\n"
            f"Existing correlation ID: {existing_cid}\n\n"
            f"To use the existing data, re-run your experiments with correlation ID: {existing_cid}\n"
            f"To start a fresh run, first delete the data at:\n"
            f"s3://measurement-dev-experiment/{existing_cid}/\n"
            f"then trigger the pipeline again."
        )

    print(f"Correlation ID {existing_cid} found in Snowflake but no parquet files in S3 — proceeding with run.")
    return None


@task
def validate_campaign_end_date_passed(
    table: str,
    booking_id: str,
    run_date: str,
    evaluation_phase: str,
) -> None:
    """
    Validates that the provided booking ID's campaign (or post-campaign window) has already
    ended relative to run_date. Only applies in prod. Raises ValueError if the campaign is
    still active.
    """
    if get_environment() != PROD:
        print("Dev environment — skipping campaign end date validation.")
        return None

    has_ended, incomplete_campaign_id = has_campaign_ended(
        booking_id=booking_id,
        table=table,
        run_date=run_date,
        evaluation_phase=evaluation_phase,
    )

    if not has_ended:
        raise ValueError(
            f"Pipeline stopped: campaign {incomplete_campaign_id} is still live "
            f"and cannot be evaluated in production until it has ended."
        )

    logging.info(f"All campaigns for booking {booking_id} have ended. Proceeding with evaluation.")
    return None


@task
def validate_artifact_exists(file_exists_result: str, pipelines_version: str, env: str):
    """
    Fail the pipeline if the required artifact doesn't exist.
    """
    if file_exists_result == FileExists.NO.value:
        raise ValueError(
            f"Pipelines deployment not found for configured pipelines hash value: {pipelines_version}\n"
            f"Please ensure that you have deployed pipelines scripts using dev_deploy.sh shell script with the correct pipelines hash value before running this pipeline."
        )
    print(f"Pipelines deployment exists for version: {pipelines_version}")


@task
def fetch_booking_name_from_snowflake(
    booking_id: str,
    run_type: str,
    pollen_table: str,
    dtp_table: str,
) -> str:
    """
    Get the booking name for a selected campaign.

    This function retrieves the booking name associated with the provided
    campaign ID by querying the measurement campaign execution table in Snowflake.

    When `"latest"` is specified, the function looks up the most recent record
    (based on `load_ts`) where:
        • the campaign identifier matches (`booking_id` for POLLEN runs, otherwise
          `job_bag_number`)
    """
    result = None
    # table = get_table("measurement_unified_campaign_pollen") if run_type == POLLEN_RUN_TYPE else get_table("measurement_unified_campaign")
    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
    if run_type == POLLEN_RUN_TYPE:
        result: list[tuple[int]] = hook.get_records(
            f"""
            select distinct booking_name
            from {pollen_table}
            where booking_id = '{booking_id}'
            limit 1
            """
        )
    elif run_type == DTP_RUN_TYPE:
        result: list[tuple[int]] = hook.get_records(
            f""" select distinct campaign_name from
            {dtp_table}
            where job_bag_number = '{booking_id}'
            limit 1
            """
        )
    else:
        print(f"Warning: Unable to determine booking name for run_type '{run_type}'. Returning None.")
        return None

    if not result:
        print(f"Warning: No booking name found for booking_id '{booking_id}'. Query returned empty result.")
        return None

    if result[0][0] is None:
        print(f"Warning: Booking name is NULL for booking_id '{booking_id}'.")
        return None

    return result[0][0]


@task
def configure_booking_reference_date(
    booking_ids: Any,
    booking_table: str,
    run_type: str,
    fallback_booking_table: Optional[str] = None,
) -> Optional[str]:
    """
    Resolve the latest item reference date across the configured Pollen bookings.

    An item's reference date is its JSON ``addedOn`` value, supporting both timestamp
    strings and millisecond epochs. For historical items without ``addedOn``, the
    booking start date is used. The single maximum date is returned for downstream
    use through XCom.
    """
    if run_type != POLLEN_RUN_TYPE:
        logging.info("Booking reference date is only applicable to Pollen runs, for now...")
        return None

    if booking_ids is None or (isinstance(booking_ids, str) and booking_ids.strip() in ('', '[]')):
        raise ValueError("At least one Pollen booking ID is required to resolve the booking reference date.")

    resolved_booking_ids = normalize_ids(booking_ids)
    if not resolved_booking_ids:
        raise ValueError("At least one Pollen booking ID is required to resolve the booking reference date.")

    return resolve_booking_reference_date(
        booking_ids=resolved_booking_ids,
        booking_table=booking_table,
        fallback_booking_table=fallback_booking_table,
    )
