import pendulum

from airflow.sdk import Variable
from airflow.providers.standard.operators.python import PythonOperator
from airflow.sdk import TaskGroup
from airflow.providers.slack.operators.slack import SlackAPIPostOperator

from helpers.xcom import get_ci, get_configured_campaign, get_pipelines_version

tz = pendulum.timezone('Europe/London')


def task_group(parent_group_id: str = 'campaign_validations') -> TaskGroup:

    with TaskGroup("campaign_skip_alert_multi_brand", ui_color="#ff7f00") as alert_tg:
        """
        This task group sends alerts to notify measurement team that pipeline was skipped
        because one or more campaigns in the booking contain multiple brands.
        Multi-brand campaigns are not supported and cause the entire booking run to fail.
        """

        send_alert = SlackAPIPostOperator(
            task_id="slack_alert_multi_brand_campaign",
            channel=f'#measurement-ops-{Variable.get("MEASUREMENT_ENVIRONMENT")}',
            text=get_multi_brand_alert_message(),
        )

        skip_downstream = PythonOperator(
            task_id="skip_pipeline",
            python_callable=_mark_validation_failed,
        )

        send_alert >> skip_downstream

    return alert_tg


def get_multi_brand_alert_message() -> str:
    """Returns text for multi-brand campaign alert"""
    return f""":red_circle: pipeline skipped
One or more campaigns in the booking contain multiple brands. Multi-brand campaigns are not supported.
Correlation id: {get_ci()}
Job bag number(s): {get_configured_campaign()}
Pipeline hash: {get_pipelines_version()}
The baseline MTA pipeline has been stopped because multi-brand campaigns were detected.
Please review the campaign configuration and ensure each campaign contains products from a single brand only.
"""


def _mark_validation_failed(**context):
    """Mark that validation failed"""
    context['task_instance'].xcom_push(key='validation_failed', value=True)
