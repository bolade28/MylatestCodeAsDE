import pendulum

from airflow.sdk import Variable
from airflow.sdk import TaskGroup
from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from airflow.providers.standard.operators.python import PythonOperator

tz = pendulum.timezone('Europe/London')


def _mark_validation_failed(**context):
    """Mark that validation failed"""
    context['task_instance'].xcom_push(key='validation_failed', value=True)


def _get_alert_message(parent_group_id: str, **context):
    task_instance = context['task_instance']

    correlation_id = task_instance.xcom_pull(
        task_ids='setup_tasks.configure_correlation_id',
        key='return_value'
    )

    pipelines_version = task_instance.xcom_pull(
        task_ids='setup_tasks.configure_pipelines_version',
        key='return_value'
    )

    validation_results = task_instance.xcom_pull(
        task_ids=f'{parent_group_id}.offer_skus_dim_item_validate.check_offer_skus_in_dim_item'
    )

    rows = validation_results or []
    booking_ids = sorted({str(row[0]) for row in rows if len(row) > 0 and row[0] is not None})
    missing_skus = sorted({str(row[1]) for row in rows if len(row) > 1 and row[1] is not None})

    booking_ids_text = ', '.join(f'`{booking_id}`' for booking_id in booking_ids) if booking_ids else '`unknown`'
    missing_skus_text = ', '.join(f'`{sku}`' for sku in missing_skus) if missing_skus else '`unknown`'

    return f""":red_circle: :owl: *Pipeline Skipped*
        The baseline pipeline has been stopped because one or more Offer SKUs were not found in DIM_ITEM.
        *Correlation ID:* `{correlation_id}`
        *Booking IDs:* {booking_ids_text}
        *Missing Offer SKUs:* {missing_skus_text}
        *Pipeline Hash:* `{pipelines_version}`"""


def task_group(parent_group_id: str = 'campaign_validations') -> TaskGroup:
    with TaskGroup('campaign_skip_alert_missing_dim_item_skus') as alert_tg:
        get_message = PythonOperator(
            task_id='prepare_alert_message',
            python_callable=_get_alert_message,
            op_kwargs={'parent_group_id': parent_group_id},
        )

        send_alert = SlackAPIPostOperator(
            task_id='slack_alert_campaign_skip_missing_dim_item_skus',
            channel=f'#measurement-ops-{Variable.get("MEASUREMENT_ENVIRONMENT")}',
            text=f"{{{{ task_instance.xcom_pull(task_ids='{parent_group_id}.campaign_skip_alert_missing_dim_item_skus.prepare_alert_message') }}}}"
        )

        skip_downstream = PythonOperator(
            task_id='skip_pipeline',
            python_callable=_mark_validation_failed,
        )

        get_message >> send_alert >> skip_downstream

    return alert_tg
