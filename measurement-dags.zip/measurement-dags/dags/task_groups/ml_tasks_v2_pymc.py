from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.sdk import TaskGroup
from airflow.task.trigger_rule import TriggerRule
from helpers.xcom import get_run_incrementality_v2

from steps.feature_prioritisation import feature_prioritisation
from steps.incrementality_v2 import incremental_estimation, incremental_post_processing


def do_we_run_incr_v2_or_not(yes_or_no: bool) -> str:
    if yes_or_no:
        return "ml_tasks_v2_pymc.FeaturePrioritisation"
    else:
        return "ml_tasks_v2_pymc.finish"


def task_group(campaign_duration: str = None) -> TaskGroup:

    with TaskGroup("ml_tasks_v2_pymc", ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        feature_prioritisation_task = feature_prioritisation.tasks(run_v2=True)
        incremental_estimation_task = incremental_estimation.tasks(campaign_duration=campaign_duration)
        incremental_post_processing_task = incremental_post_processing.tasks(campaign_duration=campaign_duration)

        decide = BranchPythonOperator(
            task_id="check_run_incrementality_v2_or_not",
            python_callable=do_we_run_incr_v2_or_not,
            op_args=[
                get_run_incrementality_v2()
            ],
        )

        start >> decide >> feature_prioritisation_task >> incremental_estimation_task >> incremental_post_processing_task >> finish
        start >> decide >> finish

    return tg
