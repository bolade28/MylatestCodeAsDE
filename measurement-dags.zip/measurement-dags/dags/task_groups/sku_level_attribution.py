from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule

from steps.sku_level_attribution import sku_level_attribution
from helpers.constants import PRODUCT_TYPE, INCLUDE_AISLE_SKUS


def decide_aisle_processing():
    """Decide whether to process aisle SKUs or skip."""
    if INCLUDE_AISLE_SKUS:
        return "mta_sku_level_attribution.sku_level_attribution_aisle"
    else:
        return "mta_sku_level_attribution.skip"


def task_group(campaign_duration: str = None) -> TaskGroup:

    with TaskGroup('mta_sku_level_attribution', ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        skip = EmptyOperator(task_id="skip")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        sku_level_attribution_offer = sku_level_attribution.tasks('SkuLevelAttributionOffer', "attribution_model_result_offer", PRODUCT_TYPE["offer"], "sku_level_attributed_sales_and_units_offer", campaign_duration=campaign_duration)
        sku_level_attribution_brand = sku_level_attribution.tasks('SkuLevelAttributionBrand', "attribution_model_result_brand", PRODUCT_TYPE["brand"], "sku_level_attributed_sales_and_units_brand", campaign_duration=campaign_duration)
        sku_level_attribution_aisle = sku_level_attribution.tasks('SkuLevelAttributionAisle', "attribution_model_result_aisle", PRODUCT_TYPE["aisle"], "sku_level_attributed_sales_and_units_aisle", campaign_duration=campaign_duration)

        aisle_decision = BranchPythonOperator(
            task_id="decide_aisle_run",
            python_callable=decide_aisle_processing,
        )

        # explicitly design this way, as offer is used in brand and aisle
        start >> sku_level_attribution_offer >> sku_level_attribution_brand >> aisle_decision >> sku_level_attribution_aisle >> finish
        aisle_decision >> skip >> finish

    return tg
