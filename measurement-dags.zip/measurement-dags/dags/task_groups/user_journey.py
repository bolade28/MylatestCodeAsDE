from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule

from steps.user_journey import user_journey
from helpers.constants import PRODUCT_TYPE, JOURNEY_TYPE, DTP_RUN_TYPE, POLLEN_RUN_TYPE
from helpers.xcom import pipeline_run_type
from helpers.utils import decide_pollen_dtp


def task_group() -> TaskGroup:

    with TaskGroup('mta_user_journey', ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        # Task names for DTP and Pollen
        dtp_offer_task_name = 'UserJourneyOfferDtp'
        pollen_offer_task_name = 'UserJourneyOfferPollen'
        task_group_name = 'mta_user_journey'

        # Decision operator for pipeline branching
        decide_pipeline = BranchPythonOperator(
            task_id="run_dtp_or_pollen_pipeline",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_offer_task_name,
                pollen_offer_task_name,
                task_group_name,
            ],
        )

        # DTP path
        user_journey_offer_dtp = user_journey.tasks(
            dtp_offer_task_name, PRODUCT_TYPE["offer"], JOURNEY_TYPE["offer"], "user_journey_offer", DTP_RUN_TYPE
        )
        user_journey_brand_dtp = user_journey.tasks(
            'UserJourneyBrandDtp', PRODUCT_TYPE["brand"], JOURNEY_TYPE["brand"], "user_journey_brand", DTP_RUN_TYPE
        )

        # Pollen path
        user_journey_offer_pollen = user_journey.tasks(
            pollen_offer_task_name, PRODUCT_TYPE["offer"], JOURNEY_TYPE["offer"], "user_journey_offer", POLLEN_RUN_TYPE
        )
        user_journey_brand_pollen = user_journey.tasks(
            'UserJourneyBrandPollen', PRODUCT_TYPE["brand"], JOURNEY_TYPE["brand"], "user_journey_brand", POLLEN_RUN_TYPE
        )

        start >> decide_pipeline
        decide_pipeline >> user_journey_offer_dtp >> user_journey_brand_dtp >> finish
        decide_pipeline >> user_journey_offer_pollen >> user_journey_brand_pollen >> finish

    return tg
