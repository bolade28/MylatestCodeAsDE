import pendulum

from airflow.sdk import TaskGroup, Variable
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.slack.operators.slack import SlackAPIPostOperator

from helpers.snowflake import count_legacy_brand_booking_registry_rows
from helpers.xcom import get_table, get_ci

tz = pendulum.timezone('Europe/London')

# legacy_brand_registry_alert is nested inside the daily_etl task group in
# daily_etl_dag, so branch targets need this prefix to resolve to valid task_ids.
PARENT_GROUP_ID = 'daily_etl'


def _check_legacy_registry_row_count(table: str, **context):
    count = count_legacy_brand_booking_registry_rows(table=table)
    context['task_instance'].xcom_push(key='row_count', value=count)
    if count == 0:
        return f'{PARENT_GROUP_ID}.legacy_brand_registry_alert.slack_alert_legacy_brand_registry_empty'
    return f'{PARENT_GROUP_ID}.legacy_brand_registry_alert.legacy_registry_still_needed'


def task_group() -> TaskGroup:
    """
    Counts rows in legacy_brand_booking_registry after each daily rebuild. A row count of
    zero means no bookings currently require legacy EAN_BR brand logic - i.e. the legacy
    brand-logic migration is complete and this registry/legacy code path can be retired.
    """
    with TaskGroup('legacy_brand_registry_alert') as tg:
        check_row_count = BranchPythonOperator(
            task_id='check_legacy_registry_row_count',
            python_callable=_check_legacy_registry_row_count,
            op_kwargs={'table': get_table('legacy_brand_booking_registry')},
        )

        alert_empty = SlackAPIPostOperator(
            task_id='slack_alert_legacy_brand_registry_empty',
            channel=f'#measurement-{Variable.get("MEASUREMENT_ENVIRONMENT")}-alerts',
            text=get_registry_empty_alert_message(),
        )

        legacy_registry_still_needed = EmptyOperator(task_id='legacy_registry_still_needed')

        check_row_count >> [alert_empty, legacy_registry_still_needed]

    return tg


def get_registry_empty_alert_message() -> str:
    """Returns text for the legacy_brand_booking_registry empty-registry alert"""
    return f""":large_green_circle: <!here> legacy_brand_booking_registry is empty (0 rows).
No bookings currently require legacy EAN_BR brand logic in the Unified Campaign Pollen build.
Correlation id: {get_ci()}
This means the legacy brand-logic migration may be complete - if this stays empty across
multiple daily runs, consider retiring the legacy EAN_BR code path.
including the work in these tickets: NUP-27520 and also removing legacy brand ean_br reference  epic: NUP-27520
Also this alert also must be retired and removed from the repository.
"""
