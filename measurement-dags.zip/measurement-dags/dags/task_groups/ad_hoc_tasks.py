from airflow.sdk import TaskGroup
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('snowflake_unload', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="backfill_brand_id",
            sql="ad_hoc_scripts/backfill_brand_id.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                    This task backfills brand IDs with production data for the measurement_campaign_reporting_aws table.
                    """,
        )

    return tg
