from airflow.providers.standard.operators.python import PythonOperator
from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from airflow.sdk import TaskGroup

from helpers.constants import (
    DAGSMetrics,
    DeploymentStatus,
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
)
from helpers.setup import get_environment
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_correlation_id_for_deletion
from helpers.metrics import publish_metric_update


def task_group() -> TaskGroup:
    correlation_id_to_delete = get_correlation_id_for_deletion()

    with TaskGroup('remove_measurement_outputs', ui_color="ff7f00") as tg:

        remove_outputs = MeasurementSnowflakeOperator(
            task_id="remove_measurement_outputs",
            sql="clear_dataset/clear_measurement_dataset.sql",
            hook_params={
                "warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "correlation_id": correlation_id_to_delete
            },
            doc_md="""
                This task removes all measurement outputs for the specified correlation ID from the Snowflake tables.
                It executes a SQL script that deletes records from the relevant tables based on the provided correlation ID parameter.
                This is safe to rerun for the same correlation ID; the SQL is a no-op for rows that no longer exist.
                """,
        )

        update_metadata_snowflake = MeasurementSnowflakeOperator(
            task_id="update_metadata_snowflake",
            sql="clear_dataset/update_measurement_metadata.sql",
            hook_params={
                "warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "correlation_id": correlation_id_to_delete
            },
        )

        update_metadata_postgres = PythonOperator(
            task_id="update_metadata_postgres",
            python_callable=publish_metric_update,
            op_kwargs={
                "table_name": "pipelines_metadata",
                "correlation_id": correlation_id_to_delete,
                "name": DAGSMetrics.PIPELINES_METADATA.value,
                "updates": {"deployment_status": DeploymentStatus.DELETED.value},
            },
        )

        environment = get_environment()
        deletion_alert = SlackAPIPostOperator(
            task_id="deletion_alert",
            channel=f"#measurement-{environment}-alerts",
            text=(f":large_green_circle: Measurement data physically deleted for "
                  f"correlation ID `{correlation_id_to_delete}`. Metadata marked deleted."),
        )

        remove_outputs >> update_metadata_snowflake >> update_metadata_postgres >> deletion_alert
    return tg
