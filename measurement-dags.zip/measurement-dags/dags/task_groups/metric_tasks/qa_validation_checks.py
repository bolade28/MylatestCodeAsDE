from airflow.sdk import TaskGroup

from task_groups.metric_tasks import hypercare_validation_checks, analytics_validation_checks


def task_group(campaign_duration: str) -> TaskGroup:
    with TaskGroup('qa_validation_checks', ui_color='ff7f00') as tg:
        hypercare_validation_checks.task_group(campaign_duration=campaign_duration)
        analytics_validation_checks.task_group(campaign_duration=campaign_duration)
    return tg
