from airflow.sdk import TaskGroup

from steps.metrics import hypercare_validation_checks


def task_group(campaign_duration: str) -> TaskGroup:
    with TaskGroup('hypercare_validation_checks', ui_color='ff7f00') as tg:
        hypercare_validation_checks.tasks(campaign_duration=campaign_duration)
    return tg
