from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE
from helpers.utils import decide_pollen_dtp

from steps.metrics import publish_pipeline_summary


def task_group(pipeline_run_type: str) -> TaskGroup:

    with TaskGroup('publish_pipeline_summary', ui_color="ff7f00") as tg:
        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        dtp_task_name = 'PublishPipelineSummary'
        pollen_task_name = 'PublishPipelineSummaryPollen'
        task_group_name = 'publish_pipeline_summary'

        dtp_summary = publish_pipeline_summary.tasks(
            step_name=dtp_task_name,
            pipeline_run_type=DTP_RUN_TYPE,
            executors=8,
        )
        pollen_summary = publish_pipeline_summary.tasks(
            step_name=pollen_task_name,
            pipeline_run_type=POLLEN_RUN_TYPE,
            executors=8,
        )

        decide = BranchPythonOperator(
            task_id="run_dtp_or_pollen_pipeline_summary",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type,
                dtp_task_name,
                pollen_task_name,
                task_group_name,
            ],
        )

        start >> decide >> dtp_summary >> finish
        start >> decide >> pollen_summary >> finish

    return tg
