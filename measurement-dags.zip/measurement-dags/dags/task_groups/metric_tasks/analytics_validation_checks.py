from airflow.sdk import TaskGroup

from steps.metrics import analytics_validation_checks


def task_group(campaign_duration: str) -> TaskGroup:
    with TaskGroup('analytics_validation_checks', ui_color='ff7f00') as tg:
        analytics_validation_checks.tasks(campaign_duration=campaign_duration)
    return tg
