from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE
from helpers.xcom import pipeline_run_type
from helpers.utils import decide_pollen_dtp
from steps.metrics import mta_metrics
from steps.metrics import publish_mta_validation


def task_group() -> TaskGroup:

    with TaskGroup('publish_mta_metrics', ui_color="ff7f00") as tg:

        mta_metrics_step = mta_metrics.tasks(executors=8)

        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        dtp_task_name = 'PublishMTAValidation'
        pollen_task_name = 'PublishMTAValidationPollen'
        task_group_name = 'publish_mta_metrics'

        dtp_mta_validation_step = publish_mta_validation.tasks(
            step_name=dtp_task_name, pipeline_run_type=DTP_RUN_TYPE, executors=8
        )
        pollen_mta_validation_step = publish_mta_validation.tasks(
            step_name=pollen_task_name, pipeline_run_type=POLLEN_RUN_TYPE, executors=8
        )

        decide = BranchPythonOperator(
            task_id="run_dtp_or_pollen_mta_validation",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_task_name,
                pollen_task_name,
                task_group_name
            ],
        )

        mta_metrics_step >> decide >> dtp_mta_validation_step >> finish
        decide >> pollen_mta_validation_step >> finish

    return tg
