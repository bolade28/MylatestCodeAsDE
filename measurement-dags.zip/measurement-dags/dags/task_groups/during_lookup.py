from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.sdk import TaskGroup

from helpers.snowflake import check_brand_logic_consistency
from helpers.xcom import (
    get_configured_campaign,
    get_resolved_during_correlation_id,
    get_table,
)


def check_brand_logic_result(booking_id: str, during_correlation_id: str, table: str) -> str:
    """Route POST validation to booking checks or the brand-logic alert."""
    if check_brand_logic_consistency(booking_id, during_correlation_id, table):
        return 'campaign_validations_post.booking_id_validate.check_booking_id'
    return 'campaign_validations_post.brand_logic_inconsistent.slack_alert_campaign_skip_brand_logic'


def task_group() -> TaskGroup:
    """Validate brand-logic consistency for POST runs using resolved DURING CID."""
    with TaskGroup('brand_logic_lookup') as task_group:
        BranchPythonOperator(
            task_id='check_brand_logic_result',
            python_callable=check_brand_logic_result,
            op_kwargs={
                'booking_id': get_configured_campaign(),
                'during_correlation_id': get_resolved_during_correlation_id(),
                'table': get_table('measurement_metadata'),
            },
        )

    return task_group
