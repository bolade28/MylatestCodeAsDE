from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule
from steps.attribution_model_dataset import attribution_model_dataset
from helpers.constants import JOURNEY_TYPE, DTP_RUN_TYPE, POLLEN_RUN_TYPE
from helpers.xcom import pipeline_run_type
from helpers.utils import decide_pollen_dtp


def task_group() -> TaskGroup:

    with TaskGroup('model_dataset', ui_color="ff7f00") as tg:
        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        # Task names for DTP and Pollen
        dtp_brand_task_name = 'AttributionModelDatasetBrand'
        dtp_offer_task_name = 'AttributionModelDatasetOffer'

        pollen_brand_task_name = 'AttributionModelDatasetBrandPollen'
        pollen_offer_task_name = 'AttributionModelDatasetOfferPollen'

        task_group_name = 'model_dataset'

        # DTP Attribution Model Dataset Tasks
        attribution_model_dataset_brand_dtp = attribution_model_dataset.tasks(
            step_name=dtp_brand_task_name,
            journey_type=JOURNEY_TYPE["brand"],
            attribution_pre_requisite="attribution_pre_requisite_brand",
            journey_channel_metadata_path="journey_channel_metadata_brand",
            attribution_model_dataset_flattened_path="attribution_model_dataset_flattened_brand",
            pipeline_run_type=DTP_RUN_TYPE,
        )

        attribution_model_dataset_offer_dtp = attribution_model_dataset.tasks(
            step_name=dtp_offer_task_name,
            journey_type=JOURNEY_TYPE["offer"],
            attribution_pre_requisite="attribution_pre_requisite_offer",
            journey_channel_metadata_path="journey_channel_metadata_offer",
            attribution_model_dataset_flattened_path="attribution_model_dataset_flattened_offer",
            pipeline_run_type=DTP_RUN_TYPE,
        )

        # Pollen Attribution Model Dataset Tasks
        attribution_model_dataset_brand_pollen = attribution_model_dataset.tasks(
            step_name=pollen_brand_task_name,
            journey_type=JOURNEY_TYPE["brand"],
            attribution_pre_requisite="attribution_pre_requisite_brand",
            journey_channel_metadata_path="journey_channel_metadata_brand",
            attribution_model_dataset_flattened_path="attribution_model_dataset_flattened_brand",
            pipeline_run_type=POLLEN_RUN_TYPE,
        )

        attribution_model_dataset_offer_pollen = attribution_model_dataset.tasks(
            step_name=pollen_offer_task_name,
            journey_type=JOURNEY_TYPE["offer"],
            attribution_pre_requisite="attribution_pre_requisite_offer",
            journey_channel_metadata_path="journey_channel_metadata_offer",
            attribution_model_dataset_flattened_path="attribution_model_dataset_flattened_offer",
            pipeline_run_type=POLLEN_RUN_TYPE,
        )

        # Decision operator for pipeline branching
        decide_pipeline = BranchPythonOperator(
            task_id="run_dtp_or_pollen_pipeline",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_offer_task_name,
                pollen_offer_task_name,
                task_group_name
            ],
        )

        # Pipeline Dependencies
        start >> decide_pipeline

        # DTP Pipeline Path
        decide_pipeline >> attribution_model_dataset_offer_dtp >> attribution_model_dataset_brand_dtp

        # Pollen Pipeline Path
        decide_pipeline >> attribution_model_dataset_offer_pollen >> attribution_model_dataset_brand_pollen

        [attribution_model_dataset_brand_dtp, attribution_model_dataset_brand_pollen] >> finish

    return tg
