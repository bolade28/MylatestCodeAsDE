from airflow.providers.standard.operators.python import ShortCircuitOperator
from airflow.sdk import TaskGroup

from helpers.constants import (
    AUTOMATED_RUN_OFFSET_DAYS,
    CAMPAIGN_DURATION_DURING,
    CAMPAIGN_DURATION_POST,
    DEFAULT_MODEL_START_DATE,
    REPORTING_STATUS_APPROVED,
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE,
    EvaluationPhase,
    BookingApprovalStatus
)
from helpers import setup
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.tables import Snowflake
from helpers.utils import has_eligible_booking_rows, is_automated_run
from helpers.xcom import get_eligible_booking_rows

DATA_INTERVAL_END_DS = '{{data_interval_end | ds }}'


def eligible_booking_query_params(type: str = EvaluationPhase.DURING) -> dict:
    """Build trusted table and eligibility params for automated booking selection."""
    is_post = type == EvaluationPhase.POST
    return {
        **Snowflake.resolve_automated_booking_tables(),
        'is_post': is_post,
        'date_column': 'post_campaign_dt' if is_post else 'campaign_end_dt',
        'pipeline_stage': CAMPAIGN_DURATION_POST if is_post else CAMPAIGN_DURATION_DURING,
        'pending_status': BookingApprovalStatus.PENDING.value,
        'during_stage': CAMPAIGN_DURATION_DURING,
        'completed_status': BookingApprovalStatus.COMPLETED.value,
        'approved_status': REPORTING_STATUS_APPROVED,
        'offset_days': AUTOMATED_RUN_OFFSET_DAYS,
    }


def select_campaigns(type: str, dag_run_source):
    """Return the configure_campaigns task after runtime booking selection."""
    is_automated = ShortCircuitOperator(
        task_id='is_automated_run',
        python_callable=is_automated_run,
        op_args=[dag_run_source],
        ignore_downstream_trigger_rules=False,
    )

    query_eligible_booking = MeasurementSnowflakeOperator(
        task_id='query_eligible_booking',
        sql='booking_selection/select_eligible_booking.sql',
        hook_params={'warehouse': SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
        params=eligible_booking_query_params(type),
    )

    # Skips every downstream task (incl. ALL_DONE ones like terminate_emr_cluster) when no booking is eligible.
    has_eligible_booking = ShortCircuitOperator(
        task_id='has_eligible_booking',
        python_callable=has_eligible_booking_rows,
        op_args=[get_eligible_booking_rows()],
        ignore_downstream_trigger_rules=True,
    )

    campaigns = setup.configure_campaigns(
        dag_run_source=dag_run_source,
        eligible_booking_rows=get_eligible_booking_rows(),
    )

    dag_run_source >> is_automated >> query_eligible_booking >> has_eligible_booking >> campaigns
    dag_run_source >> campaigns
    return campaigns


def task_group(type: str = EvaluationPhase.DURING) -> TaskGroup:

    start = setup.job_flow_start_time()
    is_during_run = type == EvaluationPhase.DURING
    end_date_conf_key = 'campaign_end_date' if is_during_run else 'post_period_end_date'

    with TaskGroup('setup_tasks') as tg:

        # --- Run configuration with no upstream dependencies ---
        ci = setup.configure_correlation_id()
        emulation_run = setup.configure_emulation_run()
        experiment_flag = setup.configure_persist_dataset()
        dag_run_source = setup.configure_dag_run_source()
        campaigns = select_campaigns(type, dag_run_source)
        run_type = setup.configure_run_type()

        setup.configure_snowflake_stage(experiment_flag)
        setup.configure_compute_units()
        setup.configure_pipelines_version()
        setup.configure_campaign_start_date()
        setup.configure_sns()
        setup.configure_mlflow()
        setup.configure_dag_version()
        setup.configure_aws_user()
        setup.configure_master_instance_type()
        setup.configure_run_incrementality_v2()

        # --- Brand logic: DURING always uses the new logic, POST inherits it from its DURING run ---
        if is_during_run:
            used_new_brand_logic = True
        else:
            during_ci = setup.configure_ci_of_during_run()
            used_new_brand_logic = setup.configure_used_new_brand_logic(during_ci, campaigns)

        # --- Table resolution: depends on the brand logic flag ---
        snowflake_tables = setup.configure_snowflake_tables(ci, emulation_run, used_new_brand_logic)

        # --- End date: depends on the resolved unified campaign tables ---
        if is_during_run:
            setup.configure_campaign_end_date(
                DATA_INTERVAL_END_DS,
                campaigns=campaigns,
                run_type=run_type,
                snowflake_tables=snowflake_tables,
            )
        else:
            setup.configure_post_period_end_date(
                DATA_INTERVAL_END_DS,
                campaigns=campaigns,
                run_type=run_type,
                snowflake_tables=snowflake_tables,
            )

        # --- Model window: resolves the same end date, so also depends on the tables ---
        setup.configure_model_start_end_dates(
            DATA_INTERVAL_END_DS,
            DEFAULT_MODEL_START_DATE,
            end_date_conf_key=end_date_conf_key,
            campaigns=campaigns,
            run_type=run_type,
            snowflake_tables=snowflake_tables,
        )

        # --- Paths: depend on the correlation id and the brand logic flag ---
        setup.configure_paths(ci, DATA_INTERVAL_END_DS, experiment_flag, used_new_brand_logic)

    return start >> tg
