from airflow.sdk import TaskGroup
from airflow.providers.amazon.aws.transfers.local_to_s3 import LocalFilesystemToS3Operator

from helpers import experiments
from helpers.xcom import get_path, get_stage


def config_validation(config_file_path: str) -> TaskGroup:
    """
    TaskGroup for validating experiment configuration.
    1. Uploads local experiment config JSON to S3 staging area.
    2. Validates that for each correlation ID specified in the experiment config, there is corresponding parquet data in S3 buckets.
    """

    with TaskGroup("upload_and_validate_config") as stage_and_validate:
        upload_config_to_s3 = LocalFilesystemToS3Operator(
            task_id="upload_config_to_s3",
            filename=config_file_path,
            dest_key=get_path("experiment_config"),
            replace=True
        )

        get_config = experiments.get_experiments_config(
            experiment_config_path=get_path("experiment_config"),
            dt='{{data_interval_end | ds }}'
        )

        validate_experiment_config = experiments.validate_experiment_config(
            experiment_config_path=get_stage("experiment_config")
        )

        validate_data_exists = experiments.validate_parquet_data_exists(
            experiment_config_path=get_path("experiment_config")
        )

        upload_config_to_s3 >> get_config >> validate_experiment_config >> validate_data_exists

    return stage_and_validate
