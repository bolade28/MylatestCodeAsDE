from airflow.sdk import TaskGroup

from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('update_snowflake_objects', ui_color="ff7f00") as tg:

        MeasurementSnowflakeOperator(
            task_id="update_001_add_run_type_dag_run_ts_columns",
            sql="snowflake_objects/update_001_add_run_type_dag_run_ts_columns.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds run_type & dag_run_ts columns to 4 result tables
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_002_add_media_spend_source_column",
            sql="snowflake_objects/update_002_add_media_spend_source_column.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds media_spend_source to measurement_unified_campaign_pollen
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_003_update_unique_brand_name_column_spaces",
            sql="snowflake_objects/update_003_update_unique_brand_name_column_spaces.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
               Update field unique brand to append spaces before and after the pipe character.
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_004_add_overlapping_campaign_flag_column",
            sql="snowflake_objects/update_004_add_overlapping_campaign_flag_column.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds overlapping_campaign_id to measurement_campaign_execution_status
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_005_add_overlapping_campaign_to_campaign_reporting",
            sql="snowflake_objects/update_005_add_overlapping_campaign_to_campaign_reporting.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds overlapping_campaign_id to measurement_campaign_reporting_aws
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_004_update_baseline_intergration_aws",
            sql="snowflake_objects/update_004_update_baseline_intergration_aws.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Update field unique brand to append spaces before and after the pipe character.
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_006_add_modelling_weight_to_campaign_reporting",
            sql="snowflake_objects/update_006_add_modelling_weight_to_campaign_reporting.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds Modelling weights to measurement_campaign_reporting_aws
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_007_add_marketing_hierarchy_cd",
            sql="snowflake_objects/update_007_add_marketing_hierarchy_cd.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds marketing_hierarchy_cd column to multiple tables:
                - baseline_attribution_integration_aws
                - measurement_campaign_execution_aws
                - measurement_campaign_reporting_aws
                - measurement_unified_campaign_pollen
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_008_update_campaign_reporting_iroas_dtype",
            sql="snowflake_objects/update_008_update_campaign_reporting_iroas_dtype.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Updates the data type of the iroas_exposed column in measurement_campaign_reporting_aws
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_009_remove_campaign_execution_iroas_columns",
            sql="snowflake_objects/update_009_campaign_execution_remove_iroas_columns.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Removes the iroas_exposed and iroas_exposed_old columns from measurement_campaign_execution_aws
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_010_add_marketing_hierarchy_cd_reach_engagement_detail_aws",
            sql="snowflake_objects/update_010_add_marketing_hierarchy_cd_reach_engagement_detail_aws.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds marketing_hierarchy_cd column to measurement_booking_reach_engagement_detail_aws
                This table was missing the marketing_hierarchy_cd column that was added as part of the
                channel hierarchy standardisation update across measurement tables.
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_011_add_can_run_incrementality_column.sql",
            sql="snowflake_objects/update_011_add_can_run_incrementality_column.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds the can_run_incrementality column to all unified campaign tables
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_012_add_campaign_id_column_to_blacklist.sql",
            sql="snowflake_objects/update_012_add_campaign_id_column_to_blacklist.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds the campaign_id column bookings_blacklist table.
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_013_add_purchase_type_to_customer_data_collection.sql",
            sql="snowflake_objects/update_013_add_purchase_type_to_customer_data_collection.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds the purchase type column customer_data_collection table.
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_014_add_run_trigger_type_to_metadata",
            sql="snowflake_objects/update_014_add_run_trigger_type_to_metadata.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds the run_trigger_type column to measurement_metadata table.
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_015_add_brand_id_to_measurement_campaign_reporting.sql",
            sql="snowflake_objects/update_015_add_brand_id_to_measurement_campaign_reporting.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds the brand_id column to the measurement_campaign_reporting_aws table.
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_016_add_spend_weight_to_measurement_campaign_reporting",
            sql="snowflake_objects/update_016_add_spend_weight_to_measurement_campaign_reporting.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds the product_type and spend_weight columns to measurement_campaign_reporting_aws.
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_017_booking_tracker_update",
            sql="snowflake_objects/update_017_booking_tracker_update.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="Promotes PENDING measurement_booking_tracker rows to READY and sets load_ts to current timestamp.",
        )

        MeasurementSnowflakeOperator(
            task_id="update_018_measurement_booking_tracker_load_ts_update",
            sql="snowflake_objects/update_018_measurement_booking_tracker_load_ts_update.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="Renames updated_at to load_ts in the measurement_booking_tracker table.",
        )
    return tg
