from airflow.sdk import TaskGroup
from airflow.task.trigger_rule import TriggerRule
from task_groups import slack_alert
from tasks.metadata import publish_metadata
from helpers.constants import EvaluationPhase
from helpers.experiments import ExperimentConfig


def task_group_start(
    pipeline_stage: str = 'start',
    period: EvaluationPhase = EvaluationPhase.DURING,
    experiment_config: ExperimentConfig = None,
) -> TaskGroup:
    with TaskGroup("start_checkpoint") as tg:
        metadata = publish_metadata.commit_metadata(
            pipeline_stage=pipeline_stage,
            experiment_config=experiment_config,
            evaluation_phase=period,
        )
        alerts = slack_alert.task_group(
            pipeline_stage=pipeline_stage,
            experiment_config=experiment_config,
            period=period,
        )
        in_progress_status = publish_metadata.mark_booking_as_in_progress(
            experiment_config=experiment_config,
            evaluation_phase=period,
        )

        metadata >> alerts >> in_progress_status

    return tg


def task_group_completed(
    pipeline_stage: str = 'completed',
    period: EvaluationPhase = EvaluationPhase.DURING,
    experiment_config: ExperimentConfig = None,
) -> TaskGroup:
    with TaskGroup("completed_checkpoint") as tg:
        metadata = publish_metadata.commit_metadata(
            pipeline_stage=pipeline_stage,
            experiment_config=experiment_config,
            evaluation_phase=period,
        )
        alerts = slack_alert.task_group(
            pipeline_stage=pipeline_stage,
            experiment_config=experiment_config,
            period=period,
        )
        completed_status = publish_metadata.mark_booking_as_completed(
            experiment_config=experiment_config,
            evaluation_phase=period,
        )
        failed_status = publish_metadata.mark_booking_as_failed(
            experiment_config=experiment_config,
            evaluation_phase=period,
            trigger_rule=TriggerRule.ONE_FAILED,
        )

        # Success branch: triggered when all upstream tasks succeed.
        metadata >> alerts >> completed_status
        # Failure branch: triggered when any of the upstream tasks fail.
        [metadata, alerts, completed_status] >> failed_status

    return tg
