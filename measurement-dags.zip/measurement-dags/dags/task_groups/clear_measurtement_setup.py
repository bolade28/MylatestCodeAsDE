from airflow.sdk import TaskGroup

from helpers import setup


def task_group() -> TaskGroup:

    start = setup.job_flow_start_time()

    with TaskGroup('setup_tasks') as tg:

        ci = setup.configure_correlation_id()
        setup.configure_snowflake_stage()
        setup.configure_snowflake_tables(ci)
        setup.configure_paths(ci, '{{data_interval_end | ds }}')
        setup.configure_previous_correlation_id()

    return start >> tg
