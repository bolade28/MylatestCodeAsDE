from datetime import datetime
from typing import Any, Dict, List

from airflow.providers.standard.operators.python import get_current_context
from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from airflow.sdk import dag, task

from helpers.booking_approval import (
    evaluate_pre_checks,
    in_clause,
)

from helpers.constants import (
    BOOKING_APPROVAL_STATUS_READY,
    BOOKING_NOT_FOUND,
    CHANNEL_TYPE_INSTORE,
)

from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.dag_param import DagParams
from helpers.setup import get_environment
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.utils import normalize_ids
from helpers.xcom import (
    get_booking_approval_booking_ids,
    get_booking_approval_booking_ids_sql,
    get_booking_approval_candidate_rows,
    get_booking_approval_rows_sql,
    get_emulation_run,
    get_stage,
    get_table,
)
from task_groups import baseline_setup


@task(task_id="prepare_approval_inputs", multiple_outputs=True)
def prepare_approval_inputs(booking_ids: Any) -> Dict[str, Any]:
    """Normalise and validate the raw booking_ids param, returning the list and its SQL IN-clause fragment."""
    normalized_ids = normalize_ids(booking_ids)
    if not normalized_ids:
        raise ValueError("No booking IDs provided. Set dag_run.conf.booking_ids to a value or list.")

    return {
        "booking_ids": normalized_ids,
        "booking_ids_sql": in_clause(normalized_ids),
    }


@task(task_id="evaluate_candidate_bookings", multiple_outputs=True)
def evaluate_candidate_bookings(
    booking_ids: List[str],
    candidate_rows: List[Any],
    during_min_days_after_end: int,
) -> Dict[str, Any]:
    """Classify booking pre-check results and produce tracker rows for passing bookings."""
    context = get_current_context()
    threshold_days = int(during_min_days_after_end)
    run_date = context["data_interval_end"].to_date_string()

    promoted, rejected, approved_rows_sql, approved_row_params = evaluate_pre_checks(
        booking_ids, candidate_rows, run_date, threshold_days
    )

    summary = {
        "requested": booking_ids,
        "threshold_days": threshold_days,
        "run_date": run_date,
        "promoted": promoted,
        "rejected": rejected,
        "approved_row_candidates": len(promoted) * 2,  # one INSERT row per stage (During + Post) per booking
    }
    print(f"Approval summary: {summary}")
    return {
        "summary": summary,
        "approved_rows_sql": approved_rows_sql,
        "approved_row_params": approved_row_params,
    }


def format_slack_reason(reason: str) -> str:
    """Strip the FAIL prefix and replace any trailing campaign ID list with a generic phrase."""
    reason = reason.removeprefix("FAIL — ")
    return f"{reason.split(' for: ')[0]} for campaign_id's" if " for: " in reason else reason


@task(task_id="notify_booking_promotion")
def notify_booking_promotion(summary: Dict[str, Any]) -> None:
    """Post one concise Slack outcome message for the booking promotion run."""
    rejected = summary.get("rejected", [])
    promoted = summary.get("promoted", [])
    correlation_id = get_current_context()["ti"].xcom_pull(
        task_ids="setup_tasks.configure_correlation_id",
        key="return_value",
    )

    env = get_environment()
    rejected_by_booking: Dict[str, List[Dict[str, str]]] = {}
    for item in rejected:
        rejected_by_booking.setdefault(item["booking_id"], []).append(item)

    lines = [
        f"{':warning:' if rejected else ':white_check_mark:'} *Booking Promotion* — "
        f"{len(promoted)} promoted, {len(rejected_by_booking)} rejected",
    ]
    if promoted:
        lines.append("")
        lines.extend([f":white_check_mark: {item['booking_id']} - {item['campaign_name']}" for item in promoted])
    if rejected_by_booking:
        for booking_id, items in rejected_by_booking.items():
            lines.append("")
            if all(item["category"] == BOOKING_NOT_FOUND for item in items):
                lines.append(f":x: {booking_id} — not found in BDV")
                continue
            lines.append(f":x: {booking_id}")
            lines.extend([f"\u2003\u2003• {item['category']}: {format_slack_reason(item['reason'])}" for item in items])
    lines.extend([
        "",
        f"Run {summary.get('run_date')} · Threshold {summary.get('threshold_days')} days (During) · "
        f"Correlation {correlation_id}",
    ])

    slack_alert = SlackAPIPostOperator(
        task_id="post_booking_promotion_summary",
        channel=f"#measurement-data-{env}",
        text="\n".join(lines),
    )
    slack_alert.execute(context=get_current_context())


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule=None,
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
    },
    params={
        "booking_ids": DagParams.booking_approval_booking_ids,
        "during_min_days_after_end": DagParams.booking_approval_during_threshold_days,
        "campaign_duration": DagParams.booking_approval_campaign_duration,
    },
)
def booking_approval_dag():
    """Manual approval DAG that validates booking age and promotes approved bookings into tracker."""

    setup = baseline_setup.task_group()

    prepare_inputs = prepare_approval_inputs(
        booking_ids="{{ params.booking_ids }}",
    )

    query_candidates = MeasurementSnowflakeOperator(
        task_id="query_candidate_bookings",
        sql="booking_approval/run_pre_checks.sql",
        hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
        params={
            "pollen_table": get_table("measurement_unified_campaign_pollen"),
            "booking_source_table": get_table("campaign_booking_media_channel"),
            "hierarchy_table": get_table("measurement_marketing_channel_hierarchy"),
            "reporting_table": get_table("measurement_campaign_reporting_aws"),
            "booking_ids_sql": get_booking_approval_booking_ids_sql(),
            "environment": get_environment(),
            "emulation_run": get_emulation_run(),
            "instore_channel_type": CHANNEL_TYPE_INSTORE,
        },
    )

    evaluation_result = evaluate_candidate_bookings(
        booking_ids=get_booking_approval_booking_ids(),
        candidate_rows=get_booking_approval_candidate_rows(),
        during_min_days_after_end="{{ params.during_min_days_after_end }}",
    )

    insert_approved_rows = MeasurementSnowflakeOperator(
        task_id="insert_approved_tracker_rows",
        sql="booking_approval/insert_approved_tracker_rows.sql",
        hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
        parameters=evaluation_result["approved_row_params"],
        params={
            "tracker_table": get_table("measurement_booking_tracker"),
            "rows_sql": get_booking_approval_rows_sql(),
            "booking_status": BOOKING_APPROVAL_STATUS_READY,
        },
    )

    notify_task = notify_booking_promotion(summary=evaluation_result["summary"])
    setup >> prepare_inputs >> query_candidates >> evaluation_result
    evaluation_result >> insert_approved_rows
    insert_approved_rows.set_downstream(notify_task.operator)


booking_approval_dag()
