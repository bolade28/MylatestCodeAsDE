from datetime import datetime

from airflow.sdk import dag
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import get_stage, get_table, get_cluster_id, pipeline_run_type, resolve_pipelines_version
from task_groups import (
    analytical_pipeline,
    attribution_model_dataset,
    attribution_model_result,
    attribution_pre_requisite,
    baseline_attribution_integration_sku_level,
    baseline_setup,
    campaign_selection,
    customer_data_collection,
    measurement_campaign_reporting,
    metadata_and_slack_alert,
    ml_tasks,
    ml_tasks_v2_pymc,
    normalisations,
    reach_engagement,
    sku_cluster_mapping,
    sku_level_attribution,
    tables_cleanup,
    timeseries_data,
    user_journey,
)
from task_groups.metric_tasks import publish_mta_metrics, publish_baseline_metrics, publish_pipeline_summary, \
    qa_validation_checks
from task_groups.snowflake_persist_tasks import persist_baseline_attribution_integration, persist_ml_to_snowflake, \
    persist_reach_engagement_report_to_snowflake, persist_customer_data_collection, \
    persist_campaign_reporting_to_snowflake, persist_analytical_to_snowflake
from task_groups.validation_tasks import config_validation, validations
from task_groups.snowflake_unload_tasks import baseline_snowflake_unload, mta_snowflake_unload, mta_tables_setup, \
    shared_snowflake_unload, unload_mta_tables
from helpers.emr import launch_cluster, terminate_cluster
from helpers.dag_param import DagParams
from helpers.constants import CAMPAIGN_DURATION_DURING
from helpers.setup import get_environment
from helpers.constants import PROD


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule=None,
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
        "resolve_pipelines_version": resolve_pipelines_version,
    },
    params={
        "pipelines_hash": DagParams.pipelines_hash_param,
        "manual_run_campaign_list": DagParams.pipelines_manual_campaign_list,
        "pipeline_run_type": DagParams.pipeline_run_type,
        "campaign_end_date": DagParams.campaign_end_date,
        **({} if get_environment() == PROD else {"emulation_run": DagParams.emulation_run}),
        "persist_dataset": DagParams.persist_dataset,
        "run_incrementality_v2": DagParams.run_incrementality_v2,
    }
)
def baseline_mta_dag():
    """
    Measurement Baseline and MTA DAG
    Designed to measure true incremental sales at cluster level
    and multitouch attribution for campaigns.
    """

    setup = baseline_setup.task_group()

    start_cluster = launch_cluster('baseline-mta', trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
    stop_cluster = terminate_cluster(get_cluster_id())

    # Validation task group
    config_validations = config_validation.task_group()
    campaign_validations = validations.task_group()

    # If validation fails, branch to validation_failed task
    validation_check = BranchPythonOperator(
        task_id='check_validation_result',
        python_callable=validations.check_validation_status,
        op_kwargs={'parent_group_id': 'campaign_validations'},
    )

    validation_failed = EmptyOperator(task_id='validation_failed')

    # Metadata and Slack alerts
    start_notify = metadata_and_slack_alert.task_group_start()
    end_notify = metadata_and_slack_alert.task_group_completed()

    # This task group is used to unload all the required data from Snowflake to S3
    baseline_data = baseline_snowflake_unload.task_group()
    mta_data = mta_snowflake_unload.task_group()
    shared_data = shared_snowflake_unload.task_group()

    # Baseline task groups
    normalisations_tg = normalisations.task_group()
    campaign_selection_tg = campaign_selection.task_group()
    sku_cluster_mapping_tg = sku_cluster_mapping.task_group()
    timeseries_data_tg = timeseries_data.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)
    analytical_pipeline_tg = analytical_pipeline.task_group()
    analytical_to_snowflake = persist_analytical_to_snowflake.task_group()
    ml_to_snowflake = persist_ml_to_snowflake.task_group()
    baseline_metrics = publish_baseline_metrics.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)
    ml_tasks_tg = ml_tasks.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)
    ml_tasks_v2_tg = ml_tasks_v2_pymc.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)

    # MTA task groups
    setup_mta_tables = mta_tables_setup.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)
    mta_tables_unload = unload_mta_tables.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)
    mta_user_journey_tg = user_journey.task_group()
    mta_attribution_pre_requisite_tg = attribution_pre_requisite.task_group()
    mta_reach_engagement_tg = reach_engagement.task_group()
    sku_level_attribution_tg = sku_level_attribution.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)
    attribution_model_dataset_tg = attribution_model_dataset.task_group()
    attribution_model_result_tg = attribution_model_result.task_group()
    mta_measurement_campaign_reporting_tg = measurement_campaign_reporting.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)
    customer_data_collection_tg = customer_data_collection.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)
    load_customer_data_collection_to_snowflake = persist_customer_data_collection.task_group()
    remove_temp_tables = tables_cleanup.task_group()
    baseline_attribution_integration_sku_level_tg = baseline_attribution_integration_sku_level.task_group()

    deploy_measurement_reporting = persist_campaign_reporting_to_snowflake.task_group()
    mta_metrics = publish_mta_metrics.task_group()
    qa_validation_checks_tg = qa_validation_checks.task_group(campaign_duration=CAMPAIGN_DURATION_DURING)
    pipeline_summary = publish_pipeline_summary.task_group(pipeline_run_type=pipeline_run_type())
    reach_engagement_report_to_db = persist_reach_engagement_report_to_snowflake.task_group()
    load_baseline_attribution_integration_to_snowflake = persist_baseline_attribution_integration.task_group()

    # Baseline task dependencies - campaign validation happens after setup but before snowflake unload
    config_validations.set_upstream(setup)
    campaign_validations.set_upstream(config_validations)
    validation_check.set_upstream(campaign_validations)
    validation_failed.set_upstream(validation_check)
    start_notify.set_upstream(validation_check)

    # Snowflake unload task groups should start after validation and notification
    baseline_data.set_upstream(start_notify)
    mta_data.set_upstream(start_notify)
    shared_data.set_upstream(start_notify)

    # Starts cluster after any unload completes (trigger_rule will allow continuation even if one fails)
    start_cluster.set_upstream([baseline_data, mta_data, shared_data])
    normalisations_tg.set_upstream(start_cluster)
    campaign_selection_tg.set_upstream(normalisations_tg)
    sku_cluster_mapping_tg.set_upstream(campaign_selection_tg)
    timeseries_data_tg.set_upstream(sku_cluster_mapping_tg)
    analytical_pipeline_tg.set_upstream(timeseries_data_tg)
    ml_tasks_tg.set_upstream(analytical_pipeline_tg)
    ml_tasks_v2_tg.set_upstream(analytical_pipeline_tg)

    ml_to_snowflake.set_upstream(ml_tasks_tg)
    analytical_to_snowflake.set_upstream(analytical_pipeline_tg)
    baseline_metrics.set_upstream(ml_tasks_tg)
    mta_attribution_pre_requisite_tg.set_upstream(mta_user_journey_tg)
    attribution_model_dataset_tg.set_upstream(mta_attribution_pre_requisite_tg)
    attribution_model_result_tg.set_upstream(attribution_model_dataset_tg)
    mta_reach_engagement_tg.set_upstream(attribution_model_result_tg)
    mta_reach_engagement_tg.set_upstream(baseline_metrics)
    sku_level_attribution_tg.set_upstream(mta_reach_engagement_tg)
    ml_tasks_tg.set_upstream(analytical_pipeline_tg)

    # MTA task dependencies
    mta_tables_unload.set_upstream(setup_mta_tables)
    remove_temp_tables.set_upstream(mta_tables_unload)
    setup_mta_tables.set_upstream(normalisations_tg)
    customer_data_collection_tg.set_upstream(mta_tables_unload)
    load_customer_data_collection_to_snowflake.set_upstream(customer_data_collection_tg)
    mta_user_journey_tg.set_upstream(customer_data_collection_tg)
    deploy_measurement_reporting.set_upstream(mta_measurement_campaign_reporting_tg)
    mta_metrics.set_upstream(mta_measurement_campaign_reporting_tg)
    baseline_attribution_integration_sku_level_tg.set_upstream(sku_level_attribution_tg)
    mta_measurement_campaign_reporting_tg.set_upstream(baseline_attribution_integration_sku_level_tg)
    load_baseline_attribution_integration_to_snowflake.set_upstream(baseline_attribution_integration_sku_level_tg)
    qa_validation_checks_tg.set_upstream(mta_metrics)
    pipeline_summary.set_upstream(qa_validation_checks_tg)
    stop_cluster.set_upstream(pipeline_summary)
    end_notify.set_upstream(deploy_measurement_reporting)
    reach_engagement_report_to_db.set_upstream(mta_reach_engagement_tg)
    end_notify.set_upstream(pipeline_summary)


baseline_mta_dag()
