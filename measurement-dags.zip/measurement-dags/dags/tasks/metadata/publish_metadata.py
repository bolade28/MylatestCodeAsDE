import json
import pendulum
from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import PythonOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import (
    BookingStatus,
    DAGSMetrics,
    DeploymentStatus,
    EvaluationPhase,
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE,
)
from helpers.setup import get_environment, get_airflow_platform, get_build_hash
from helpers.aws import split_s3_path
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.metrics import PipelineMetadata
from helpers.utils import MetricsPublisher, get_current_iso_timestamp
from helpers.sns import SNS
from helpers.experiments import ExperimentConfig
from helpers.xcom import (
    get_ci,
    get_git_hash,
    get_job_flow_start_time,
    get_all_paths_for_meta_data,
    pipeline_run_type,
    get_manual_campaigns_list,
    get_git_commits,
    get_campaign_dates,
    get_configured_campaign,
    get_during_correlation_id,
    get_campaign_end_date,
    get_post_period_end_date,
    get_resolved_during_correlation_id,
    get_used_new_brand_logic_for_during,
    get_current_aws_user,
    get_experimentation_flag,
    get_experiment_details,
    get_dag_run_source,
    get_emulation_run,
    get_path,
)
from helpers.xcom import get_booking_name

tz = pendulum.timezone('Europe/London')

topic_arns = SNS()


def commit_metadata(
    pipeline_stage: str,
    evaluation_phase: EvaluationPhase = EvaluationPhase.DURING,
    experiment_config: ExperimentConfig = None,
) -> TaskGroup:
    """
    Commits pipeline metadata to Snowflake and publishes it to the metrics service.

    Args:
        pipeline_stage: 'start' or 'completed' — marks the beginning or end of a pipeline run.
        evaluation_phase: DURING (default) or POST campaign period.
        experiment: When True, skips campaign-specific fields (booking_id, campaign_date, etc.)
                    and records experiment trial details instead.

    Returns:
        TaskGroup: git_commits >> commit_metadata (Snowflake) >> publish_to_metrics (SNS)
    """

    task_group_name = 'metadata'

    if experiment_config:
        configured_end_date = None
        run_type = experiment_config.run_type
        booking_id = None
        validated_booking_ids = "[]"
        campaign_date = "{}"
        evaluation_period = None
        during_cid = None
        booking_name = None
    else:
        configured_end_date = get_campaign_end_date(
        ) if evaluation_phase == EvaluationPhase.DURING else get_post_period_end_date()
        run_type = pipeline_run_type()
        booking_id = get_configured_campaign()
        validated_booking_ids = get_manual_campaigns_list("meta_data")
        campaign_date = get_campaign_dates()
        evaluation_period = evaluation_phase.value
        during_cid = get_during_correlation_id(
        ) if evaluation_phase == EvaluationPhase.POST else None
        booking_name = get_booking_name()

    pipeline_status = 'started' if pipeline_stage == 'start' else 'completed'
    end_time = get_current_iso_timestamp() if pipeline_stage == 'completed' else None

    common_params = {
        'run_date': '{{data_interval_end | ds }}',
        'correlation_id': get_ci(),
        'configured_end_date': configured_end_date,
        'run_by': get_current_aws_user(),
        'dags_base_commit': get_git_hash(pipeline_stage=pipeline_stage, type='dags_base'),
        'pipelines_base_commit': get_git_hash(pipeline_stage=pipeline_stage, type='pipelines_base'),
        'pipelines_git_commits': get_git_hash(pipeline_stage=pipeline_stage, type='pipelines'),
        'dags_git_commits': get_git_hash(pipeline_stage=pipeline_stage, type='dags'),
        'airflow_platform': get_airflow_platform(),
        'start_time': get_job_flow_start_time(),
        'pipeline_status': pipeline_status,
        'deployment_status': DeploymentStatus.APPROVED.value,
        'end_time': end_time,
        'run_type': run_type,
        'run_trigger_type': get_dag_run_source(),
        'paths': get_all_paths_for_meta_data(),
        'booking_id': booking_id,
        'validated_booking_ids': validated_booking_ids,
        'campaign_date': campaign_date,
        'evaluation_period': evaluation_period,
        'during_cid': during_cid,
    }

    with TaskGroup(task_group_name, ui_color="ff7f00") as tg:
        git_commits = get_git_commits(environment=get_environment())
        fallback_metadata_reader, is_fallback = configure_fallback_metadata(
            pipeline_stage=pipeline_stage,
            experiment_config=experiment_config,
        )
        common_params['additional_info'] = additional_metadata(
            evaluation_phase,
            experiment_config,
            booking_name,
            is_fallback=is_fallback,
        )

        snowflake_commit = MeasurementSnowflakeOperator(
            task_id='commit_metadata',
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            sql='metadata/commit_metadata.sql',
            params=common_params
        )

        publish_to_metrics = PythonOperator(
            task_id='publish_to_metrics',
            python_callable=metrics_metadata_commit,
            op_kwargs=common_params
        )

        git_commits >> snowflake_commit >> publish_to_metrics
        if fallback_metadata_reader:
            fallback_metadata_reader >> snowflake_commit
    return tg


def create_booking_status_update(
        task_id: str,
        status: BookingStatus,
        evaluation_phase: EvaluationPhase,
        experiment_config: ExperimentConfig = None,
        trigger_rule: TriggerRule = TriggerRule.ALL_SUCCESS,
):
    if experiment_config:
        return EmptyOperator(task_id=task_id, trigger_rule=trigger_rule)

    return MeasurementSnowflakeOperator(
        task_id=task_id,
        hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
        sql="booking_tracker/booking_status_update.sql",
        params={
            "booking_id": get_configured_campaign(),
            "pipeline_stage": evaluation_phase.value,
            "status": status.value,
        },
        trigger_rule=trigger_rule,
    )


def mark_booking_as_in_progress(
        experiment_config: ExperimentConfig = None,
        evaluation_phase: EvaluationPhase = EvaluationPhase.DURING,
        trigger_rule: TriggerRule = TriggerRule.ALL_SUCCESS,
):
    return create_booking_status_update(
        task_id="mark_booking_as_in_progress",
        status=BookingStatus.IN_PROGRESS,
        evaluation_phase=evaluation_phase,
        experiment_config=experiment_config,
        trigger_rule=trigger_rule,
    )


def mark_booking_as_completed(
        experiment_config: ExperimentConfig = None,
        evaluation_phase: EvaluationPhase = EvaluationPhase.DURING,
        trigger_rule: TriggerRule = TriggerRule.ALL_SUCCESS,
):
    return create_booking_status_update(
        task_id="mark_booking_as_completed",
        status=BookingStatus.COMPLETED,
        evaluation_phase=evaluation_phase,
        experiment_config=experiment_config,
        trigger_rule=trigger_rule,
    )


def mark_booking_as_failed(
        experiment_config: ExperimentConfig = None,
        evaluation_phase: EvaluationPhase = EvaluationPhase.DURING,
        trigger_rule: TriggerRule = TriggerRule.ALL_SUCCESS,
):
    return create_booking_status_update(
        task_id="mark_booking_as_failed",
        status=BookingStatus.FAILED,
        evaluation_phase=evaluation_phase,
        experiment_config=experiment_config,
        trigger_rule=trigger_rule,
    )


def additional_metadata(
        evaluation_phase: EvaluationPhase,
        experiment_config: ExperimentConfig = None,
        booking_name: str = None,
        is_fallback: str | bool = None,
) -> str | None:

    build_hash = get_build_hash()
    evaluation_phase = evaluation_phase.value if isinstance(
        evaluation_phase, EvaluationPhase) else evaluation_phase

    if experiment_config:
        experiment_details = get_experiment_details()
        return f"""
        {{
            "build_hash": "{build_hash}",
            "experiment_count": "{experiment_config.count}",
            "experiment_details": {experiment_details},
            "is_emulated_run": "{get_emulation_run()}"
        }}
        """

    experiment_run = get_experimentation_flag(as_string=True)
    fallback_value = json.dumps(False)
    if is_fallback is not None:
        fallback_value = (
            is_fallback
            if isinstance(is_fallback, str)
            else json.dumps(is_fallback)
        )

    if evaluation_phase == EvaluationPhase.DURING.value:
        return f"""
        {{
            "build_hash": "{build_hash}",
            "used_new_brand_logic": true,
            "experimentation_run": "{experiment_run}",
            "booking_name": "{booking_name}",
            "is_fallback": {fallback_value},
            "is_emulated_run": "{get_emulation_run()}"
        }}
        """

    elif evaluation_phase == EvaluationPhase.POST.value:
        configured_cid = get_during_correlation_id()
        resolved_cid = get_resolved_during_correlation_id()
        return f"""
        {{
            "configured_during_cid": "{configured_cid}",
            "resolved_during_cid": "{resolved_cid}",
            {get_used_new_brand_logic_for_during()}
            "build_hash": "{build_hash}",
            "experimentation_run": "{experiment_run}",
            "booking_name": "{booking_name}",
            "is_fallback": {fallback_value},
            "is_emulated_run": "{get_emulation_run()}"
        }}
        """

    return None


def metrics_metadata_commit(
    correlation_id,
    run_date,
    run_by,
    dags_base_commit,
    pipelines_base_commit,
    pipelines_git_commits,
    dags_git_commits,
    start_time,
    end_time,
    pipeline_status,
    deployment_status,
    run_type,
    booking_id,
    validated_booking_ids,
    paths,
    campaign_date,
    evaluation_period,
    during_cid,
    configured_end_date,
    airflow_platform,
    additional_info
):
    """
    Publishes pipeline metadata to the metrics service.

    Creates a PipelineMetadata event with all run details and publishes it to the
    metrics service for monitoring and tracking purposes.

    Args:
        correlation_id (str): Unique identifier for the pipeline run
        run_date (str): Date of the pipeline execution
        run_by (str): AWS user who initiated the pipeline
        dags_base_commit (str): Base git commit hash for DAGs (first 7 chars)
        pipelines_base_commit (str): Base git commit hash for pipelines (first 7 chars)
        pipelines_git_commits (str): JSON list of all pipelines git commit hashes
        dags_git_commits (str): JSON list of all DAGs git commit hashes
        start_time (str): Pipeline start timestamp
        end_time (str): Pipeline end timestamp (None if still running)
        pipeline_status (str): Status of the pipeline ('started' or 'completed')
        deployment_status (str): Deployment approval status
        run_type (str): Type of pipeline run (e.g., 'DTP', 'Pollen')
        booking_id (str): Configured campaign booking ID or job bag number
        validated_booking_ids (str): JSON list of validated booking IDs that passed validation
        paths (str): JSON object containing all S3 paths used in the pipeline
        campaign_date (str): JSON object with campaign start and end dates
        evaluation_period (str): Evaluation phase ('during' or 'post')
        during_cid (str): Correlation ID from the during-period run (for post-period runs only)
        configured_end_date (str): Campaign or post-period end date
        airflow_platform (str): Platform where Airflow is running ('docker' or 'ec2')
        additional_info (str): JSON string with additional metadata (for post-period runs)

    Returns:
        str: Success message indicating metadata was published to metrics

    """

    publisher = MetricsPublisher(topic_arn=topic_arns.metrics_topic_arn())

    metrics_commit = PipelineMetadata(
        correlation_id=correlation_id,  # Already rendered!
        name=DAGSMetrics.PIPELINES_METADATA.value,
        run_date=run_date,
        run_by=run_by,
        dags_base_commit=dags_base_commit,
        pipelines_base_commit=pipelines_base_commit,
        pipelines_git_hashes=pipelines_git_commits,
        dags_git_hashes=dags_git_commits,
        start_time=start_time,
        end_time=end_time,
        pipeline_status=pipeline_status,
        deployment_status=deployment_status,
        run_type=run_type,
        booking_id=booking_id,
        validated_booking_id=validated_booking_ids,
        paths=paths,
        campaign_date=campaign_date,
        evaluation_period=evaluation_period,
        during_correlation_id=during_cid,
        campaign_end_date=configured_end_date,
        airflow_platform=airflow_platform,
        additional_metadata=additional_info
    )

    publisher.publish_event(
        message_subject="Metadata Commit Event",
        event=metrics_commit
    )

    return "published metadata to metrics"


def configure_fallback_metadata(
    pipeline_stage: str,
    experiment_config: ExperimentConfig,
) -> tuple[PythonOperator | None, str | None]:
    if pipeline_stage != 'completed' or experiment_config is not None:
        return None, None

    fallback_metadata_reader = PythonOperator(
        task_id='read_fallback_metadata',
        python_callable=read_fallback_metadata,
        op_kwargs={
            'fallback_metadata_path': get_path(
                'incrementality_fallback_metadata'),
            'correlation_id': get_ci(),
        },
    )
    fallback_xcom = (
        '{{ task_instance.xcom_pull(task_ids="' + fallback_metadata_reader.task_id + '") | tojson }}'
    )
    return fallback_metadata_reader, fallback_xcom


def read_fallback_metadata(
    fallback_metadata_path: str,
    correlation_id: str,
) -> bool:
    # TODO: Add helper for reading s3 in the dags repo
    bucket, key = split_s3_path(fallback_metadata_path)
    s3_hook = S3Hook()
    prefix = key.rstrip('/') + '/'
    part_keys = [
        part_key for part_key in (s3_hook.list_keys(bucket_name=bucket, prefix=prefix) or [])
        if part_key.endswith('.json')
    ]
    if not part_keys:
        raise FileNotFoundError(
            f"Fallback metadata not found at {fallback_metadata_path}")

    records = [
        json.loads(line)
        for part_key in sorted(part_keys)
        for line in s3_hook.read_key(key=part_key, bucket_name=bucket).splitlines()
        if line.strip()
    ]
    if len(records) != 1:
        raise ValueError('Fallback metadata must contain exactly one row')

    metadata = records[0]
    if not isinstance(metadata, dict):
        raise ValueError('Fallback metadata must contain a JSON object')
    if metadata.get('correlation_id') != correlation_id:
        raise ValueError(
            'Fallback metadata correlation ID does not match this pipeline run')
    if not isinstance(metadata.get('is_fallback'), bool):
        raise ValueError(
            'Fallback metadata must contain a boolean is_fallback value')

    return metadata['is_fallback']
