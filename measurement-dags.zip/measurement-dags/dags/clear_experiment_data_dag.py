from datetime import datetime

from airflow.sdk import dag

from helpers.aws import clear_experiment_data
from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import (
    get_stage,
    get_table
)
from helpers.dag_param import DagParams


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule=None,
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
    },
    params={
        "experiment_data_correlation_id": DagParams.experiment_data_correlation_id
    }
)
def clear_experimental_data_dag():
    """
    DAG to remove experimental datasets from the S3 experiment bucket for a given correlation ID.

    """

    clear_experiment_data(correlation_id="{{ params.experiment_data_correlation_id }}")


clear_experimental_data_dag()
