dynamodb_table = "terraform-locks"
bucket         = "measurement-dev-terraform-state"
key            = "dev/terraform.tfstate"
region         = "eu-west-1"
encrypt        = true
