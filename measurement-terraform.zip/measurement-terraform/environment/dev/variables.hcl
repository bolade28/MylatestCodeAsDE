tags = {
  owner              = "Measurement"
  email              = "measurement@sainsburys.co.uk"
  costcentre         = "PD8634"
  project            = "measurement"
  dataClassification = "highlySensitive"
  environment        = "dev"
  live               = "no"
  dataRetention      = "1-month"
  servicename        = "Nectar 360 Measurement"
  servicecatalogueID = "001071675"
}
account_number          = "277707132387"
deploy_role             = "arn:aws:iam::277707132387:role/dev-deploy-role"
ec2_key_name            = "measurement-dev-key"
env                     = "dev"
slack_courier_name      = "measurement-courier-dev"
snowflake_user          = "SU_NONPROD_ETL_MEASUREMENT"
snowflake_external_id   = "SAINSBURYS_SFCRole=16578_KI6N8Bu9SJjUqWh0gLxSKGePA/U="
exp_snowflake_external_id = "SAINSBURYS_SFCRole=16578_1rN4woodBXUrmx5h6GJe9RR5b3k="

# Measurement Core Network
vpc_cidr_measurement   = "10.77.0.0/16"
# AZ-A
sn_pvt_reserved_a_cidr = "10.77.0.0/20"
sn_pvt_emr_a_cidr      = "10.77.16.0/20"
sn_pvt_gen_a_cidr      = "10.77.32.0/20"
sn_pub_web_a_cidr      = "10.77.48.0/20"

# AZ-B
sn_pvt_reserved_b_cidr = "10.77.64.0/20"
sn_pvt_emr_b_cidr      = "10.77.80.0/20"
sn_pvt_gen_b_cidr      = "10.77.96.0/20"
sn_pub_web_b_cidr      = "10.77.112.0/20"

# AZ-C
sn_pvt_reserved_c_cidr = "10.77.128.0/20"
sn_pvt_emr_c_cidr      = "10.77.144.0/20"
sn_pvt_gen_c_cidr      = "10.77.160.0/20"
sn_pub_web_c_cidr      = "10.77.176.0/20"

grafana_root_url       = "https://metrics.measurementdev.com"
private_hosted_zone_id = "Z0971192IOE363XX2NOX"

metrics_instance_desired_capacity = 1
metrics_instance_max_size         = 2
metrics_instance_min_size         = 1

permissions_boundary              = "arn:aws:iam::277707132387:policy/ccoe/js-developer"

# Commercial Team's confluent cloud cluster connectivity via Transit Gateway

lifecycle_expiration_default = 30
lifecycle_expiration_extended = 180


# Rhubarb secret and kms access
rhubarb_account_id = "383109991409"
rhubarb_aws_secret_name = "snowflake/prod/SU_NONPROD_ETL_MEASUREMENT"
rhubarb_kms_key_alias = "alias/snowflake/prod/SU_NONPROD_ETL_MEASUREMENT"

