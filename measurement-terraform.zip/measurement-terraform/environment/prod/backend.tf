dynamodb_table = "terraform-locks"
bucket         = "measurement-prod-terraform-state"
key            = "prod/terraform.tfstate"
region         = "eu-west-1"
encrypt        = true
