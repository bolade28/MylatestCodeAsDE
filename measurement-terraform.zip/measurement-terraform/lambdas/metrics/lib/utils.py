import boto3
import json
import psycopg2


def get_secret(secret_key):
    secret_name = "metrics/rds-secrets"
    region_name = "eu-west-1"

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except Exception as error:
        print(f'unable to retrive secret {error}')
    else:
        if 'SecretString' in get_secret_value_response:
            return json.loads(get_secret_value_response['SecretString'])[secret_key]


def conn_to_postgres(
    database: str,
    user: str,
    password: str,
    host: str,
    port: str
) -> psycopg2:

    try:
        conn = psycopg2.connect(
            database=database,
            user=user,
            password=password,
            host=host,
            port=port
        )
        return conn
    except (Exception, psycopg2.DatabaseError) as error:
        print(f'unable to connect {error}')
