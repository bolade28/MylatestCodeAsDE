import psycopg2
from psycopg2 import sql
from psycopg2.extras import Json
import json
from typing import Dict
from datetime import datetime, timezone
from collections import OrderedDict
import os

EXCEPTION_LOG_TABLE = 'exception_log'
EXCEPTION_LOG_SCHEMA = OrderedDict({'load_timestamp': 'timestamp', 'comment': 'text', 'lambda_function': 'text', 'message': 'json', 'sqs_message': 'json'})
SCHEMA_NAME = 'metrics'
METRICS_DB = 'metrics'

env = os.getenv('env')

LAMBDA = f'measurement-{env}-metrics-handler'

exception_message = {}


def get_timestamp():
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'


def get_column_cast(col_name, table_schema):
    """Return appropriate SQL cast based on column type"""
    if col_name not in table_schema:
        return sql.Placeholder(col_name)

    col_type = table_schema[col_name]

    if col_type in ['timestamp', 'timestamp without time zone']:
        return sql.SQL("{}::timestamp").format(sql.Placeholder(col_name))
    elif col_type in ['numeric', 'decimal']:
        return sql.SQL("{}::numeric").format(sql.Placeholder(col_name))
    elif col_type in ['bigint', 'integer']:
        return sql.SQL("{}::bigint").format(sql.Placeholder(col_name))
    elif col_type in ['jsonb', 'json']:
        return sql.SQL("{}::jsonb").format(sql.Placeholder(col_name))
    else:
        return sql.Placeholder(col_name)


def upsert_metric(
    conn: psycopg2,
    table_name: str,
    schema_name: str,
    event: Dict,
    table_schema: Dict,
    commit: bool,
    failed_messags: Dict,
    event_message: Dict
):

    if not table_exists(conn=conn, schema_name=schema_name, table_name=table_name, event_message=event_message):
        create_table(
            conn=conn,
            schema_name=schema_name,
            table_name=table_name,
            table_schema=table_schema,
            commit=True,
            id_column='metric_id',
            event_message=event_message
        )

    try:
        event['load_timestamp'] = get_timestamp()
        insert_cols = list(event.keys())
        update_clauses = []
        for col in insert_cols:
            if col != 'correlation_id' and col != 'name':  # Skip correlation_id and name since they're used in the ON clause
                update_clauses.append(f"{col} = s.{col}")

        source_values = ", ".join(f"s.{col}" for col in insert_cols)
        update_set_string = ",\n".join(update_clauses)

        upsert_sql = sql.SQL("""
            MERGE INTO {} AS t
            USING (VALUES ({})) AS s({})
            ON t.correlation_id = s.correlation_id
            and t.name = s.name
            WHEN MATCHED THEN
                UPDATE SET
                {}
            WHEN NOT MATCHED THEN
                INSERT ({})
                VALUES ({});
        """).format(
            sql.Identifier(schema_name, table_name),
            sql.SQL(", ").join(get_column_cast(col, table_schema) for col in event.keys()),  # Use type casting
            sql.SQL(", ").join(sql.Identifier(col) for col in insert_cols),
            sql.SQL(update_set_string),
            sql.SQL(", ").join(sql.Identifier(col) for col in insert_cols),
            sql.SQL(source_values)
        )

        with conn.cursor() as cursor:
            cursor.execute(upsert_sql, event)
            conn.commit() if commit else conn.rollback()

    except Exception as error:
        print(f"Error: {error}")
        conn.rollback()
        exception_message['comment'] = f'failed to upsert metric with table name {table_name}'
        exception_message['message'] = json.dumps(failed_messags)
        insert_exception_log(
            conn=conn,
            data=exception_message,
            event_message=event_message
        )


def create_table(
    conn: psycopg2,
    table_name: str,
    schema_name: str,
    table_schema: Dict,
    commit: bool,
    id_column: str,
    event_message: Dict
):

    try:
        cursor = conn.cursor()
        gen_table_sql = sql.SQL("CREATE TABLE IF NOT EXISTS {} ({} {}, {} {})").format(
            sql.Identifier(schema_name, table_name),
            sql.Identifier(id_column),
            sql.SQL('UUID  NOT  NULL DEFAULT gen_random_uuid()'),
            sql.SQL(", ").join(sql.Identifier(col) + sql.SQL(' ') + sql.SQL(type) for col, type in table_schema.items()),
            sql.SQL(', CONSTRAINT {}_CONSTRAINT PRIMARY KEY ({})').format(
                sql.SQL(table_name),
                sql.SQL(id_column)
            )
        )
        cursor.execute(gen_table_sql)
        conn.commit() if commit else conn.rollback()
        cursor.close()
    except Exception as error:
        print(f"Error: {error}")
        conn.rollback()
        exception_message['comment'] = f'unable to create table {table_name}'
        insert_exception_log(
            conn=conn,
            data=exception_message,
            event_message=event_message
        )


def table_exists(
    conn: psycopg2,
    schema_name: str,
    table_name: str,
    event_message: Dict
):

    param = {'table_name': table_name, 'schema_name': schema_name}

    try:

        cursor = conn.cursor()
        table_exists_sql = """
            SELECT EXISTS(
                SELECT 1 FROM information_schema.tables
                WHERE table_name = %(table_name)s
                AND table_schema = %(schema_name)s
                )
            """
        cursor.execute(table_exists_sql, param)
        conn.commit()
        result = cursor.fetchone()[0]
        cursor.close()
    except Exception as error:
        print(f"Error: {error}")
        conn.rollback()
        exception_message['comment'] = f'unable to check if table {table_name} exists'
        insert_exception_log(
            conn=conn,
            data=exception_message,
            commit=True,
            event_message=event_message
        )
    return result


def insert_exception_log(
    conn: psycopg2,
    data: Dict,
    event_message: Dict,
    commit: bool = True

):

    try:
        table_name = EXCEPTION_LOG_TABLE
        schema_name = SCHEMA_NAME
        table_schema = EXCEPTION_LOG_SCHEMA
        data['load_timestamp'] = get_timestamp()
        data['lambda_function'] = LAMBDA
        data['sqs_message'] = Json(event_message)
        insert_cols = list(table_schema.keys())
        insert_data = {col: data.get(col) for col in insert_cols}

        cursor = conn.cursor()
        insert_event_sql = sql.SQL("INSERT INTO {} ({}) VALUES ({})").format(
            sql.Identifier(schema_name, table_name),
            sql.SQL(", ").join(sql.Identifier(col) for col in insert_cols),
            sql.SQL(", ").join(sql.Placeholder(col) for col in insert_cols)
        )
        cursor.execute(insert_event_sql, insert_data)
        conn.commit() if commit else conn.rollback()
        cursor.close()
    except Exception as error:
        print(f"Error: {error}")
        print('******** printing exception log ********')
        print(data)


def insert_metric(
    conn: psycopg2,
    table_name: str,
    schema_name: str,
    event: Dict,
    table_schema: Dict,
    commit: bool,
    failed_messags: Dict,
    event_message: Dict
):
    if not table_exists(conn=conn, schema_name=schema_name, table_name=table_name, event_message=event_message):
        create_table(
            conn=conn,
            schema_name=schema_name,
            table_name=table_name,
            table_schema=table_schema,
            commit=True,
            id_column='metric_id',
            event_message=event_message
        )

    try:
        event['load_timestamp'] = get_timestamp()
        cursor = conn.cursor()
        insert_event_sql = sql.SQL("INSERT INTO {} ({}) VALUES ({})").format(
            sql.Identifier(schema_name, table_name),
            sql.SQL(", ").join(sql.Identifier(col) for col in event.keys()),
            sql.SQL(", ").join(sql.Placeholder(col) for col in event.keys())
        )

        cursor.execute(insert_event_sql, event)
        conn.commit() if commit else conn.rollback()
        cursor.close()
    except Exception as error:
        print(f"Error: {error}")
        conn.rollback()
        exception_message['comment'] = f'failed to insert metric with table name {table_name}'
        exception_message['message'] = json.dumps(failed_messags)
        insert_exception_log(
            conn=conn,
            data=exception_message,
            event_message=event_message
        )


def update_metric(
    conn: psycopg2,
    table_name: str,
    schema_name: str,
    correlation_id: str,
    name: str,
    updates: Dict,
    table_schema: Dict,
    commit: bool,
    failed_messags: Dict,
    event_message: Dict
):
    if not correlation_id or not name:
        comment = f'Error: update message missing correlation_id or name for table {table_name}'
        print(comment)
        exception_message['comment'] = comment
        exception_message['message'] = json.dumps(failed_messags)
        insert_exception_log(
            conn=conn,
            data=exception_message,
            event_message=event_message
        )
        return

    try:
        updates['load_timestamp'] = get_timestamp()

        set_clause = sql.SQL(", ").join(
            sql.SQL("{} = {}").format(sql.Identifier(col), get_column_cast(col, table_schema))
            for col in updates.keys()
        )
        params = {**updates, 'correlation_id': correlation_id, 'name': name}

        update_sql = sql.SQL(
            "UPDATE {} SET {} WHERE correlation_id = %(correlation_id)s AND name = %(name)s"
        ).format(
            sql.Identifier(schema_name, table_name),
            set_clause
        )

        with conn.cursor() as cursor:
            cursor.execute(update_sql, params)
            updated_rows = cursor.rowcount
            conn.commit() if commit else conn.rollback()

        if updated_rows == 0:
            print(f'no matching record found to update for correlation_id={correlation_id}, name={name}')

    except Exception as error:
        print(f"Error: {error}")
        conn.rollback()
        exception_message['comment'] = f'failed to update metric with table name {table_name}'
        exception_message['message'] = json.dumps(failed_messags)
        insert_exception_log(
            conn=conn,
            data=exception_message,
            event_message=event_message
        )
