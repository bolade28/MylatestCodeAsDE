import json
from lib.utils import get_secret, conn_to_postgres
from lib.db_ops import (
    EXCEPTION_LOG_TABLE,
    EXCEPTION_LOG_SCHEMA,
    SCHEMA_NAME,
    METRICS_DB,
)
from psycopg2.extras import Json as Psycopg2Json
from lib.db_ops import (
    upsert_metric,
    insert_metric,
    create_table,
    update_metric,
)


def handler(event, context):
    """
    TODO: Printing various values below to be removed. These are kept here to monito cloudwatch logs
    """
    messages = {}
    failed_messags = {}

    print('event value: ')
    print(event)
    print('context value: ')
    print(context)

    rds_username = get_secret(secret_key='username')
    rds_password = get_secret(secret_key='password')
    rds_port = get_secret(secret_key='port')
    rds_endpoint = get_secret(secret_key='host')
    database = METRICS_DB

    rds_conn = conn_to_postgres(
        database=database,
        user=rds_username,
        password=rds_password,
        host=rds_endpoint,
        port=rds_port
    )

    for record in event['Records']:
        message_body = json.loads(record['body'])
        message_id = message_body['MessageId']
        message = json.loads(message_body['Message'])
        messages[message_id] = message

    create_table(
        conn=rds_conn,
        table_name=EXCEPTION_LOG_TABLE,
        schema_name=SCHEMA_NAME,
        table_schema=EXCEPTION_LOG_SCHEMA,
        commit=True,
        id_column='exception_id',
        event_message=json.dumps(event)
    )

    for message_id, message in messages.items():

        failed_messags['message'] = json.dumps(message)

        table_name = message['event_schema']['table_name']
        schema = message['event_schema']['schema']
        table_schema = message['event_schema']['table_schema']
        write_operation = message['event_schema']['write_operation']

        del message['event_schema']

        # Convert dict/list fields to Json objects for JSONB columns
        for key, value in message.items():
            if isinstance(value, (dict, list)):
                message[key] = Psycopg2Json(value)

        print(message)
        if write_operation == 'upsert':
            upsert_metric(
                conn=rds_conn,
                table_name=table_name,
                schema_name=schema,
                event=message,
                table_schema=table_schema,
                commit=True,
                failed_messags=failed_messags,
                event_message=json.dumps(event)
            )
        elif write_operation == 'insert':
            insert_metric(
                conn=rds_conn,
                table_name=table_name,
                schema_name=schema,
                event=message,
                table_schema=table_schema,
                commit=True,
                failed_messags=failed_messags,
                event_message=json.dumps(event)
            )
        elif write_operation == 'update':
            correlation_id = message.pop('correlation_id', None)
            name = message.pop('name', None)
            update_metric(
                conn=rds_conn,
                table_name=table_name,
                schema_name=schema,
                correlation_id=correlation_id,
                name=name,
                updates=message,
                table_schema=table_schema,
                commit=True,
                failed_messags=failed_messags,
                event_message=json.dumps(event)
            )
    rds_conn.close()
