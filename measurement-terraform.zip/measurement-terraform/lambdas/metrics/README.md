# Metrics Lambda

Consumes SQS events and writes pipeline metrics to the `metrics` Postgres database. Each SQS
record's `Message` body must include an `event_schema` block describing where and how to write
the metric, plus the metric fields themselves:

```json
{
  "event_schema": {
    "table_name": "campaign_metrics",
    "schema": "metrics",
    "table_schema": {"correlation_id": "text", "name": "text", "value": "decimal"},
    "write_operation": "insert | upsert | update"
  },
  "correlation_id": "...",
  "name": "...",
  "value": 1.23
}
```

`table_name`/`schema`/`table_schema` come from the publishing schema class (see
`spark_pipeline/utils/metrics_schema.py` in `measurement-pipelines`), and the lambda auto-creates
the table via `create_table` if it doesn't already exist.

## `name` / `correlation_id` convention

Metrics are keyed by `correlation_id` + `name`, and `upsert`/`update` operations match existing
rows on these two columns. Any new schema should follow the
`correlation_id` + `name` convention unless there's a specific reason to diverge, to keep
`upsert_metric`/`update_metric` behaviour consistent.

## Write operations

- **`insert`**: Adds a new row. Used when multiple rows can share the same `correlation_id`
  (e.g. `measurement_campaign_reporting`, one row per campaign dimension combination).
- **`upsert`**: Inserts a new row, or updates it in place if a row with the same
  `correlation_id` + `name` already exists. This is the default for most metrics and is what
  makes pipeline reruns idempotent.
- **`update`**: Updates specific fields on an already-published metric without needing the full
  original payload. The message must include `correlation_id` and `name` (or `cluster_id` for
  `ClusterMetrics`-style tables) plus only the columns to change; these are passed to
  `update_metric` as `updates`. If no row matches, the update is a no-op (logged, not treated as
  an error).

## Failure handling

Any failure in `insert_metric`/`upsert_metric`/`update_metric` is caught, the transaction is
rolled back, and a row is written to `metrics.exception_log` with the failing table, message and
raw SQS event for debugging.
