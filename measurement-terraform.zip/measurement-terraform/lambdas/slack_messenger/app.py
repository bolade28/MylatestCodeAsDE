import json
import os
import boto3
from urllib3 import PoolManager, Retry
from urllib3.exceptions import HTTPError

channel_map = {
    "Measurement Operations": "measurement-ops-prod",
    "Airflow": "measurement-prod-alerts",
}
heading_map = {
    "Operations": "Pipeline Event",
    "Campaign": "Campaign Event",
    "Cluster": "Cluster Event",
    "Airflow": "Airflow Event",
}


def get_pool_manager(total=3, read=3, connect=3, backoff_factor=4, status_forcelist=[500, 502, 504]):
    retry = Retry(total=total, read=read, connect=connect, backoff_factor=backoff_factor,
                  status_forcelist=status_forcelist)
    http = PoolManager(retries=retry, timeout=10.0)
    return http


def get_heading(event_type: str) -> str:
    """Returns a specific event name if it is provided in heading_map, otherwise
    just returns the given event_type"""
    env = os.getenv('env')
    if env == 'prod':
        return heading_map.get(event_type, event_type)
    else:
        return event_type + " Event"


def get_channel(event_type: str) -> str:
    """Returns a specific slack channel if it is given in channel_map, otherwise
    just returns measurement-ops-dev"""
    env = os.getenv('env')
    if env == 'prod':
        return channel_map.get(event_type, "measurement-ops-prod")
    else:
        return "measurement-ops-dev"


def text_block(incoming_text: str) -> dict:

    return {
        "type": "section",
        "text": {
            "type": "plain_text",
            "text": incoming_text + "\n",
            "emoji": True,
        }
    }


def data_block(incoming_data: dict) -> dict:
    return {
        "type": "section",
        "text": {
            "type": "mrkdwn",
            "text": "\n".join([f"*{str(key)}*: {str(val)}"
                               for key, val in incoming_data.items()]),
        }
    }


def context_block(correlation_id: str) -> dict:
    return {
        "type": "context",
        "elements": [
            {
                "type": "plain_text",
                "emoji": False,
                "text": "No correlation_id provided" if correlation_id is None else f"correlation_id: {correlation_id}"
            }
        ]
    }


def get_bot_auth_token() -> str:
    secret_name = os.environ['SLACK_SECRET_ARN']
    secrets_manager = boto3.client("secretsmanager")
    secret_value = secrets_manager.get_secret_value(SecretId=secret_name)
    return json.loads(secret_value['SecretString'])["botAuthTokenValue"]


def handler(event, context) -> dict:
    """
    Sends Slack messages through relevant channels
    :param event: Dict
    :param event: Measurement pipeline events from piped through SNS.
    :param context: Required by AWS Lambda service.
    """
    incoming_event = json.loads(event['Records'][0]['Sns']['Message'])
    bot_auth = get_bot_auth_token()
    slack_channel = get_channel(incoming_event['eventType'])
    slack_endpoint = "https://slack.com/api/chat.postMessage"
    heading = get_heading(incoming_event['eventType'])

    headers = {
        'Authorization': f'Bearer {bot_auth}',
        'Content-type': 'application/json'
    }

    body = lambda_handler_dev(slack_channel, heading, incoming_event)

    pm = get_pool_manager()

    try:
        response = pm.request("POST", slack_endpoint, body=json.dumps(body), headers=headers)
        response = json.loads(response.data.decode("utf-8"))

        if response['ok']:
            print("Sending message success!")
        else:
            print(f"Failed to send slack message, here is the response received: {json.dumps(response)}")
    except HTTPError as e:
        print(f"Failed to send message to slack: {str(e)}")


def lambda_handler_dev(slack_channel: str, heading: str, incoming_event: dict) -> dict:
    """
    Sends Slack event through to the relevant channel
    :return:
    """
    body = {
        'channel': slack_channel,
        "blocks": [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": heading,
                    "emoji": False
                }
            },
            {
                "type": "divider"
            },
        ]
    }

    if incoming_event.get("text") is not None:
        body["blocks"].append(text_block(incoming_event["text"]))

    if incoming_event.get("data") is not None:
        body["blocks"].append(data_block(incoming_event["data"]))
    body["blocks"].append(context_block(incoming_event.get("correlation_id", None)))
    return body
