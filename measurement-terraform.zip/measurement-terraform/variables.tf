variable "region" {
  default     = "eu-west-1"
  description = "Our AWS region"
}

variable "deploy_role" {}
variable "tags" {}
variable "env" {}
variable "account_number" {}

variable "slack_courier_name" {}
variable "vpc_cidr_measurement" {}
variable "sn_pub_web_a_cidr" { description = "Public subnet CIDR range in AZ A for resources that need web exposure" }
variable "sn_pub_web_b_cidr" { description = "Public subnet CIDR range in AZ B for resources that need web exposure" }
variable "sn_pub_web_c_cidr" { description = "Public subnet CIDR range in AZ C for resources that need web exposure" }
variable "sn_pvt_emr_a_cidr" { description = "Private subnet CIDR range in AZ A for EMR related resources" }
variable "sn_pvt_emr_b_cidr" { description = "Private subnet CIDR range in AZ B for EMR related resources" }
variable "sn_pvt_emr_c_cidr" { description = "Private subnet CIDR range in AZ C for EMR related resources" }
variable "sn_pvt_gen_a_cidr" { description = "Private subnet CIDR range in AZ A for general resources" }
variable "sn_pvt_gen_b_cidr" { description = "Private subnet CIDR range in AZ B for general resources" }
variable "sn_pvt_gen_c_cidr" { description = "Private subnet CIDR range in AZ C for general resources" }
variable "sn_pvt_reserved_a_cidr" { description = "Reserved subnets for future use" }
variable "sn_pvt_reserved_b_cidr" { description = "Reserved subnets for future use" }
variable "sn_pvt_reserved_c_cidr" { description = "Reserved subnets for future use" }
variable "subnet_a_az_name" { default = "eu-west-1a" }
variable "subnet_b_az_name" { default = "eu-west-1b" }
variable "subnet_c_az_name" { default = "eu-west-1c" }
variable "lifecycle_expiration_default" { description = "Lifecycle expiration default in days" }
variable "lifecycle_expiration_extended" { description = "Lifecycle expiration extended in days" }
variable "snowflake_user" { description = "Login user for airflow instances' access to Snowflake" }
variable "permissions_boundary" { description = "The permissions boundary of IAM roles." }
variable "grafana_root_url" { description = "Root URL for the Grafana instance" }
variable "metrics_instance_desired_capacity" {
  description = "Desired capacity for the metrics instance"
  default     = 1
}
variable "private_hosted_zone_id" {
  description = "The ID of the private hosted zone for internal DNS resolution"
  type        = string
}
variable "snowflake_external_id" {
  description = "The AWS external ID that must be used when assuming the Snowflake unload role."
  type        = string
}
variable "exp_snowflake_external_id" {
  type        = string
  description = "The AWS external ID that must be used when assuming the Snowflake unload role for experimentation."
  default     = null
}

variable "metrics_instance_max_size" {}
variable "metrics_instance_min_size" {}
#
# ---- Global vars
#
# these define global variables that do not change between dev and prod, but may be used in multiple places
variable "dev_account_number" {
  default     = "277707132387"
  description = "When you need the dev AWS account number in prod infra"
}
variable "prod_account_number" {
  default     = "626635410130"
  description = "When you need the prod AWS account number in dev infra"
}
variable "ami_bastion_instance" {
  default     = "ami-062a8901a5ddcf280"
  description = "AMI ID for the bastion instance"
}

variable "vpce_sf_service_id" {
  default     = "vpce-svc-03594486c11f7955a"
  description = "Service ID for Snowflake PrivateLink"
}
variable "airflow_db_name" { default = "airflow" }
variable "ec2_key_name" {}
variable "ami_airflow_instance" { default = "ami-09c20105c9b62f893" }
# Note Grafana and MLflow use kernel version 6.12 instead of 6.1 for their Amazon Linux 2023 AMI
# In general 6.1 is more stable but 6.12 has more features and better performance
variable "ami_grafana_instance" { default = "ami-0b1161e6982092e4d" }
variable "ami_mlflow" { default = "ami-0b1161e6982092e4d" }

variable "airflow_instance_type" { default = "t3.xlarge" }
variable "grafana_ec2_instance_type" { default = "t3.large" }
variable "grafana_rds_engine_version" { default = "17.4" }
variable "metrics_rds_engine_version" { default = "17.4" }
variable "grafana_rds_instance_class" { default = "db.t3.micro" }
variable "metrics_rds_instance_class" { default = "db.t3.micro" }
variable "rds_username" { default = "airflow_rds_user" }

variable "rhubarb_account_id" { description = "The account ID of the Rhubarb account." }
variable "rhubarb_aws_secret_name" { description = "The secret that was provided by Rhubarb to allow for credential rotation of Snowflake credentials." }
variable "rhubarb_kms_key_alias" { description = "This allows for the decryption of the Secret from Rhubarb." }
