import base64
import stat
import sys
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock
from urllib.error import HTTPError, URLError

import pytest


# I included hyphen in the path to the snowflake-provisioning module, so this resolves that
SNOWFLAKE_PROVISIONING_DIR = (
    Path(__file__).resolve().parents[1] / "module" / "grafana" / "snowflake-provisioning"
)
sys.path.insert(0, str(SNOWFLAKE_PROVISIONING_DIR))

import snowflake_datasource_provision as provisioner


def config() -> provisioner.ProvisioningConfig:
    """Create a complete provisioning configuration for unit tests."""
    return provisioner.ProvisioningConfig(
        region="eu-west-1",
        account="account",
        login="grafana-user",
        warehouse="warehouse",
        database="database",
        schema="schema",
        role="role",
        private_key_arn="private-key-secret",
        private_key_role_arn="key-access-role",
        grafana_admin_user="admin",
        environment="dev"
    )


def encoded_pem(der: bytes) -> str:
    """Create the base64-encoded PEM representation stored in Secrets Manager."""
    pem = (
        "-----BEGIN PRIVATE KEY-----\n"
        f"{base64.b64encode(der).decode('ascii')}\n"
        "-----END PRIVATE KEY-----\n"
    )
    return base64.b64encode(pem.encode("utf-8")).decode("ascii")


def test_config_requires_all_environment_variables():
    with pytest.raises(RuntimeError, match="SNOWFLAKE_PROVISION_REGION"):
        provisioner.ProvisioningConfig.from_environment({})


def test_load_private_key_uses_a_scoped_assumed_role_session(monkeypatch):
    sts_client = MagicMock()
    sts_client.assume_role.return_value = {
        "Credentials": {
            "AccessKeyId": "access-key",
            "SecretAccessKey": "secret-key",
            "SessionToken": "session-token",
        }
    }
    secrets_client = MagicMock()
    secrets_client.get_secret_value.return_value = {"SecretString": '{"private_key": "encoded-pem"}'}
    assumed_session = MagicMock()
    assumed_session.client.return_value = secrets_client
    session_factory = MagicMock(return_value=assumed_session)
    boto3_client = MagicMock(return_value=sts_client)
    monkeypatch.setattr(provisioner.boto3, "client", boto3_client)
    monkeypatch.setattr(provisioner.boto3.session, "Session", session_factory)

    assert provisioner.load_private_key(config()) == "encoded-pem"
    boto3_client.assert_called_once_with("sts", region_name="eu-west-1")
    sts_client.assume_role.assert_called_once_with(
        RoleArn="key-access-role",
        RoleSessionName="MeasurementGrafanaSnowflakeSetup",
    )
    session_factory.assert_called_once_with(
        aws_access_key_id="access-key",
        aws_secret_access_key="secret-key",
        aws_session_token="session-token",
        region_name="eu-west-1",
    )
    assumed_session.client.assert_called_once_with("secretsmanager", region_name="eu-west-1")
    secrets_client.get_secret_value.assert_called_once_with(SecretId="private-key-secret")


def test_grafana_private_key_converts_pem_to_urlsafe_der_base64():
    der = b"DER bytes with / and + candidates \xfb\xff"
    private_key_secret = encoded_pem(der)

    expected = base64.urlsafe_b64encode(der).decode("ascii")
    assert provisioner.grafana_private_key(private_key_secret) == expected
    assert provisioner.grafana_private_key(f"{private_key_secret[:10]}\n{private_key_secret[10:]}") == (
        expected
    )


def test_datasource_yaml_safely_quotes_connection_values():
    provisioning_config = replace(config(), login='user"\nvalue')

    content = provisioner.datasource_yaml(provisioning_config, "private-key")

    print (content)

    assert "  - name: dev-snowflake" in content
    assert "    uid: dev-snowflake" in content
    assert content.count('database: "UNIFIED_PLATFORM_DEV"') == 1
    assert content.count('username: "user\\\"\\nvalue"') == 1
    assert content.count('privateKey: "private-key"') == 1
    assert 'username: "user\\\"\\nvalue"' in content
    assert content.count("authenticationType: keypair") == 1


def test_write_datasource_file_sets_grafana_group_and_permissions(tmp_path, monkeypatch):
    target = tmp_path / "snowflake.yaml"
    ownership_calls = []
    monkeypatch.setattr(provisioner.grp, "getgrnam", lambda _: SimpleNamespace(gr_gid=1234))
    monkeypatch.setattr(
        provisioner.os,
        "chown",
        lambda path, uid, gid: ownership_calls.append((Path(path), uid, gid)),
    )

    provisioner.write_datasource_file("datasource content\n", target)

    assert target.read_text() == "datasource content\n"
    assert stat.S_IMODE(target.stat().st_mode) == 0o640
    assert len(ownership_calls) == 1
    temporary_path, uid, gid = ownership_calls[0]
    assert temporary_path.parent == target.parent
    assert temporary_path.name.startswith(".snowflake.yaml.")
    assert (uid, gid) == (0, 1234)


def test_reload_grafana_datasources_uses_local_admin_api_without_logging_credentials(monkeypatch, capsys):
    response = MagicMock()
    response.__enter__.return_value = response
    urlopen = MagicMock(return_value=response)
    monkeypatch.setattr(provisioner, "urlopen", urlopen)

    # Ensure the function call expects admin-password as the password
    monkeypatch.setattr(
        provisioner,
        "get_default_admin_password",
        lambda secret_id, config: "admin-password",
    )

    provisioning_config = config()
    provisioner.reload_grafana_datasources(provisioning_config)

    request = urlopen.call_args.args[0]
    expected_credentials = base64.b64encode(b"admin:admin-password").decode("ascii")

    assert request.full_url == provisioner.GRAFANA_DATASOURCE_RELOAD_URL
    assert request.get_method() == "POST"
    assert request.get_header("Authorization") == f"Basic {expected_credentials}"
    assert urlopen.call_args.kwargs["timeout"] == provisioner.GRAFANA_RELOAD_TIMEOUT_SECONDS
    output = capsys.readouterr().out
    assert "admin-password" not in output
    assert expected_credentials not in output


def test_reload_grafana_datasources_retries_when_grafana_is_starting(monkeypatch):
    response = MagicMock()
    response.__enter__.return_value = response
    urlopen = MagicMock(side_effect=[URLError("connection refused"), response])
    sleep = MagicMock()
    monkeypatch.setattr(provisioner, "urlopen", urlopen)
    monkeypatch.setattr(provisioner.time, "sleep", sleep)

    monkeypatch.setattr(
        provisioner,
        "get_default_admin_password",
        lambda secret_id, config: "admin-password",
    )

    provisioner.reload_grafana_datasources(config())

    assert urlopen.call_count == 2
    sleep.assert_called_once_with(provisioner.GRAFANA_RELOAD_RETRY_DELAY_SECONDS)


def test_reload_grafana_datasources_retries_when_grafana_returns_service_unavailable(monkeypatch):
    response = MagicMock()
    response.__enter__.return_value = response
    urlopen = MagicMock(
        side_effect=[HTTPError("http://127.0.0.1", 503, "Unavailable", {}, None), response]
    )
    sleep = MagicMock()
    monkeypatch.setattr(provisioner, "urlopen", urlopen)
    monkeypatch.setattr(provisioner.time, "sleep", sleep)
    monkeypatch.setattr(
        provisioner,
        "get_default_admin_password",
        lambda secret_id, config: "admin-password",
    )

    provisioner.reload_grafana_datasources(config())

    assert urlopen.call_count == 2
    sleep.assert_called_once_with(provisioner.GRAFANA_RELOAD_RETRY_DELAY_SECONDS)


def test_reload_grafana_datasources_reports_http_errors_without_credentials(monkeypatch):
    urlopen = MagicMock(side_effect=HTTPError("http://127.0.0.1", 403, "Forbidden", {}, None))
    monkeypatch.setattr(provisioner, "urlopen", urlopen)
    monkeypatch.setattr(
        provisioner,
        "get_default_admin_password",
        lambda secret_id, config: "admin-password",
    )

    with pytest.raises(RuntimeError, match="HTTP status 403") as error:
        provisioner.reload_grafana_datasources(config())

    assert "admin-password" not in str(error.value)
