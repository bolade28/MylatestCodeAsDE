import json
import os
from unittest import mock

from urllib3 import PoolManager, Retry

from lambdas.slack_messenger.app import (
    lambda_handler_dev,
    get_channel,
    get_heading,
    get_pool_manager,
    handler,
)


@mock.patch.dict(os.environ, {"env": "prod"})
def test_heading_not_found():
    assert get_heading('Budget') == 'Budget'


@mock.patch.dict(os.environ, {"env": "prod"})
def test_heading_prod():
    assert get_heading('Airflow') == 'Airflow Event'


@mock.patch.dict(os.environ, {"env": "dev"})
def test_heading_dev():
    assert get_heading('Measurement Operations Test') == 'Measurement Operations Test Event'


@mock.patch.dict(os.environ, {"env": "prod"})
def test_channel():
    assert get_channel('Measurement Operations') == 'measurement-ops-prod'


@mock.patch.dict(os.environ, {"env": "dev"})
def test_channel_dev():
    assert get_channel('Measurement Operations') == 'measurement-ops-dev'


def test_lambda_handler_dev():
    slack_channel = 'slack channel name'
    heading = 'Redemption Rate Event'

    incoming_event = {
        "text": "event text",
        "event_type": "event type",
        "data": {
            "data_1": "data_val_1",
            "data_2": "data_val_2"
        }
    }

    return_body = {
        "blocks": [
            {
                "text": {
                    "emoji": False,
                    "text": "Redemption Rate Event",
                    "type": "plain_text"
                },
                "type": "header"
            },
            {
                "type": "divider"
            },
            {
                "text": {
                    "emoji": True,
                    "text": "event text\n",
                    "type": "plain_text"
                },
                "type": "section"
            },
            {
                "text": {
                    "text": "*data_1*: data_val_1\n*data_2*: data_val_2",
                    "type": "mrkdwn"
                },
                "type": "section"
            },
            {
                "elements": [
                    {
                        "emoji": False,
                        "text": "No correlation_id provided",
                        "type": "plain_text"
                    }
                ],
                "type": "context"
            }
        ],
        "channel": "slack channel name"
    }
    assert lambda_handler_dev(slack_channel, heading, incoming_event) == return_body


# urllib3 API tests
# These tests verify that the urllib3 version in use still exposes the exact
# classes, constructor arguments, and method signatures that app.py relies on.

def test_urllib3_pool_manager_instantiates():
    """PoolManager must still accept a 'retries' kwarg and a 'timeout' kwarg."""
    retry = Retry(total=1, read=1, connect=1, backoff_factor=0, status_forcelist=[500])
    pm = PoolManager(retries=retry, timeout=5.0)
    assert isinstance(pm, PoolManager)


def test_urllib3_retry_instantiates():
    """Retry must still accept total/read/connect/backoff_factor/status_forcelist kwargs."""
    retry = Retry(total=3, read=3, connect=3, backoff_factor=4, status_forcelist=[500, 502, 504])
    assert isinstance(retry, Retry)


def test_get_pool_manager_returns_pool_manager():
    """get_pool_manager() must return a PoolManager with the expected defaults."""
    pm = get_pool_manager()
    assert isinstance(pm, PoolManager)


def test_pool_manager_has_request_method():
    """PoolManager must still expose a .request() method."""
    pm = get_pool_manager()
    assert callable(getattr(pm, "request", None))


def test_urllib3_httperror_importable():
    """urllib3.exceptions.HTTPError must still be importable (used in handler)."""
    from urllib3.exceptions import HTTPError  # noqa: F401


def test_handler_success(monkeypatch):
    """handler() posts to Slack and prints success when response['ok'] is True."""
    mock_response = mock.MagicMock()
    mock_response.data = json.dumps({"ok": True}).encode("utf-8")

    # Mock the pool manager to return the mock response when .request() is called
    mock_pm = mock.MagicMock()
    mock_pm.request.return_value = mock_response

    monkeypatch.setenv("env", "dev")
    monkeypatch.setenv("SLACK_SECRET_ARN", "arn:aws:secretsmanager:eu-west-1:123456789012:secret:slack/measurement-courier-auth-token")

    mock_sm_client = mock.MagicMock()
    mock_sm_client.get_secret_value.return_value = {
        "SecretString": json.dumps({"botAuthTokenValue": "super-secret-fake-token"})
    }

    with mock.patch("lambdas.slack_messenger.app.get_pool_manager", return_value=mock_pm), \
        mock.patch("lambdas.slack_messenger.app.boto3.client", return_value=mock_sm_client), \
        mock.patch("builtins.print") as mock_print:

        sns_event = {
            "Records": [{
                "Sns": {
                    "Message": json.dumps({
                        "eventType": "Measurement Operations",
                        "text": "pipeline started",
                        "data": {"job": "etl"},
                        "correlation_id": "1234-5678-9012"
                    })
                }
            }]
        }
        handler(sns_event, None)

    mock_pm.request.assert_called_once()
    call_kwargs = mock_pm.request.call_args

    assert call_kwargs[0][0] == "POST"
    assert "slack.com" in call_kwargs[0][1]
    mock_print.assert_called_with("Sending message success!")


def test_handler_slack_error(monkeypatch):
    """handler() logs a failure message when Slack returns ok=False."""
    mock_response = mock.MagicMock()
    mock_response.data = json.dumps({"ok": False, "error": "invalid_auth"}).encode("utf-8")

    mock_pm = mock.MagicMock()
    mock_pm.request.return_value = mock_response

    monkeypatch.setenv("env", "dev")
    monkeypatch.setenv("SLACK_SECRET_ARN", "arn:aws:secretsmanager:eu-west-1:123456789012:secret:slack/measurement-courier-auth-token")

    mock_sm_client = mock.MagicMock()
    mock_sm_client.get_secret_value.return_value = {
        "SecretString": json.dumps({"botAuthTokenValue": "super-secret-fake-token"})
    }

    with mock.patch("lambdas.slack_messenger.app.get_pool_manager", return_value=mock_pm), \
        mock.patch("lambdas.slack_messenger.app.boto3.client", return_value=mock_sm_client), \
        mock.patch("builtins.print") as mock_print:

        sns_event = {
            "Records": [{
                "Sns": {
                    "Message": json.dumps({
                        "eventType": "Measurement Operations",
                        "text": "pipeline failed",
                    })
                }
            }]
        }
        handler(sns_event, None)

    printed_msg = mock_print.call_args[0][0]
    assert "Failed to send slack message" in printed_msg


def test_handler_http_error(monkeypatch):
    """handler() catches urllib3.exceptions.HTTPError and logs it."""
    from urllib3.exceptions import HTTPError

    mock_pm = mock.MagicMock()
    mock_pm.request.side_effect = HTTPError("connection refused")

    monkeypatch.setenv("env", "dev")
    monkeypatch.setenv("SLACK_SECRET_ARN", "arn:aws:secretsmanager:eu-west-1:123456789012:secret:slack/measurement-courier-auth-token")

    mock_sm_client = mock.MagicMock()
    mock_sm_client.get_secret_value.return_value = {
        "SecretString": json.dumps({"botAuthTokenValue": "super-secret-fake-token"})
    }

    with mock.patch("lambdas.slack_messenger.app.get_pool_manager", return_value=mock_pm), \
         mock.patch("lambdas.slack_messenger.app.boto3.client", return_value=mock_sm_client), \
         mock.patch("builtins.print") as mock_print:

        sns_event = {
            "Records": [{
                "Sns": {
                    "Message": json.dumps({
                        "eventType": "Measurement Operations",
                        "text": "pipeline failed",
                    })
                }
            }]
        }
        handler(sns_event, None)

    printed_msg = mock_print.call_args[0][0]
    assert "Failed to send message to slack" in printed_msg
