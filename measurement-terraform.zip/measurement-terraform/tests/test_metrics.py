from unittest.mock import MagicMock
from unittest import mock
from psycopg2 import sql
from lambdas.metrics.lib.db_ops import (
    upsert_metric,
    update_metric,
)


class FakeConn:
    def get_dsn_parameters(self):
        return {}

    def rollback(self):
        pass

    def commit(self):
        pass

    def cursor(self):
        class FakeCursor:
            def execute(self, *args, **kwargs):
                pass

            def close(self):
                pass
        return FakeCursor()


def test_upsert_metric():
    # Mock connection and parameters

    conn = MagicMock()  # Replace with actual connection mock
    table_name = 'test_table'
    schema_name = 'test_schema'
    event = {
        'correlation_id': '12345',
        'name': 'Test Metric',
        'value': 100.0,
        'type': 'engagement',
        'create_timestamp': '2023-10-01T00:00:00Z',
        'load_timestamp': '2023-10-01T00:00:00Z'
    }
    table_schema = {
        'correlation_id': 'text',
        'name': 'text',
        'value': 'decimal',
        'type': 'text',
        'create_timestamp': 'timestamp',
        'load_timestamp': 'timestamp'
    }
    commit = True
    failed_messages = {}
    event_message = {}
    fake_conn = FakeConn()

    # Call the function to test
    with mock.patch('lambdas.metrics.lib.db_ops.table_exists') as mock_create_table:
        with mock.patch('psycopg2.sql.Composed.as_string', return_value="MOCKED SQL"):
            mock_create_table.return_value = True
            upsert_metric(
                conn=fake_conn,
                table_name=table_name,
                schema_name=schema_name,
                event=event,
                table_schema=table_schema,
                commit=commit,
                failed_messags=failed_messages,
                event_message=event_message
            )

    # Add assertions to verify the expected behavior

def test_update_metric():
    conn = MagicMock()
    table_name = 'test_table'
    schema_name = 'test_schema'
    correlation_id = '12345'
    name = 'Test Metric'
    updates = {'deployment_status': 'deleted'}
    table_schema = {'deployment_status': 'text'}
    failed_messages = {}
    event_message = {}

    update_metric(
        conn=conn,
        table_name=table_name,
        schema_name=schema_name,
        correlation_id=correlation_id,
        name=name,
        updates=updates,
        table_schema=table_schema,
        commit=True,
        failed_messags=failed_messages,
        event_message=event_message
    )

    mock_cursor = conn.cursor.return_value.__enter__.return_value
    mock_cursor.execute.assert_called_once()

    executed_params = mock_cursor.execute.call_args[0][1]
    assert executed_params['correlation_id'] == correlation_id
    assert executed_params['name'] == name
    assert executed_params['deployment_status'] == 'deleted'
    conn.commit.assert_called_once()
