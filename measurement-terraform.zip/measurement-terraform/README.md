# measurement-terraform

## Installing instructions
### Mac

We recommend using [tfenv](https://github.com/tfutils/tfenv), a Terraform version manager, to install the required Terraform version as specified in main.tf(currently using 1.11.3).

To install and use the correct version, follow these steps:

Install tfenv using Homebrew:

```zsh
brew install tfenv
```
```zsh
tfenv install [version]
```

```zsh
tfenv use [version]
```

## Running Terraform commands on all modules

If you're running these commands in, e.g., the dev environment
```zsh
export ENV=dev
export AWS_PROFILE=measurement-dev
```

### Plan

```zsh
make plan
```

### Apply

```zsh
make apply
```

### Destroy

```zsh
make destroy
```

## Running Terraform commands on a specific module

If you're running these commands in, e.g., the dev environment and working on the airflow-instance module
```zsh
export ENV=dev
export AWS_PROFILE=measurement-dev
export MODULE=airflow-instance
```

### Plan

```zsh
make plan
```

### Apply

```zsh
make apply
```

### Destroy

```zsh
make destroy
```

## Other commands

### Code formatting/linting

You can use the following to nicely format your Terraform source code files:

```
terraform fmt -recursive
```

### Graph
Will create a .svg image, which contains a graph of the current terraform state (if there is one in .terraform)
```zsh
make graph
```
NB: Requires Graphviz to run. To obtain Graphviz through brew, simply run
```zsh
brew install graphviz
```

### Connect to Airflow through the bastion

First, ensure that you have the right ssh key in your `~/.ssh` folder. Also ensure you have
the following config in your `~/.ssh/config` file:

```
Host *
    UseKeychain yes
    AddKeysToAgent yes
```

After this, use `aws-azure-login` to log in to dev or prod as usual. Then:

```bash
export AWS_REGION=eu-west-1
export AWS_PROFILE=measurement-dev

cd bastion-access

./airflow-ui-port-forward.sh ~/.ssh/measurement-dev-key
```

After this, simply navigate to https://localhost:8080/ to see the Airflow GUI. 

To connect to prod Airflow, change `dev` to `prod` in the steps above.

Alternatively, you can use make command as below to connect to the Airflow instance.

```bash
make connect_to_airflow ENV=dev
```
