resource "aws_vpc" "measurement_vpc" {
  cidr_block           = var.vpc_cidr_measurement
  enable_dns_hostnames = true

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-vpc"
  })
}
