
resource "aws_route_table" "measurement_web_rt" {
  vpc_id = aws_vpc.measurement_vpc.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.measurement_igw.id
  }

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-public-rt-az-abc"
  })
}

resource "aws_route_table" "measurement_private_rt_a" {
  vpc_id = aws_vpc.measurement_vpc.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.measurement_vpc_nat_gw_a.id
  }

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-private-rt-az-a"
  })
}

resource "aws_route_table" "measurement_private_rt_b" {
  vpc_id = aws_vpc.measurement_vpc.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.measurement_vpc_nat_gw_b.id
  }

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-private-rt-az-b"
  })
}

resource "aws_route_table" "measurement_private_rt_c" {
  vpc_id = aws_vpc.measurement_vpc.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.measurement_vpc_nat_gw_c.id
  }

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-private-rt-az-c"
  })
}

resource "aws_route_table_association" "subnet_association_web_a" {
  subnet_id      = aws_subnet.sn_pub_web_a.id
  route_table_id = aws_route_table.measurement_web_rt.id
}

resource "aws_route_table_association" "subnet_association_web_b" {
  subnet_id      = aws_subnet.sn_pub_web_b.id
  route_table_id = aws_route_table.measurement_web_rt.id
}

resource "aws_route_table_association" "subnet_association_web_c" {
  subnet_id      = aws_subnet.sn_pub_web_c.id
  route_table_id = aws_route_table.measurement_web_rt.id
}

resource "aws_route_table_association" "subnet_association_pvt_gen_a" {
  subnet_id      = aws_subnet.sn_pvt_gen_a.id
  route_table_id = aws_route_table.measurement_private_rt_a.id
}

resource "aws_route_table_association" "subnet_association_pvt_gen_b" {
  subnet_id      = aws_subnet.sn_pvt_gen_b.id
  route_table_id = aws_route_table.measurement_private_rt_b.id
}

resource "aws_route_table_association" "subnet_association_pvt_gen_c" {
  subnet_id      = aws_subnet.sn_pvt_gen_c.id
  route_table_id = aws_route_table.measurement_private_rt_c.id
}

resource "aws_route_table_association" "subnet_association_pvt_emr_a" {
  subnet_id      = aws_subnet.sn_pvt_emr_a.id
  route_table_id = aws_route_table.measurement_private_rt_a.id
}

resource "aws_route_table_association" "subnet_association_pvt_emr_b" {
  subnet_id      = aws_subnet.sn_pvt_emr_b.id
  route_table_id = aws_route_table.measurement_private_rt_b.id
}

resource "aws_route_table_association" "subnet_association_pvt_emr_c" {
  subnet_id      = aws_subnet.sn_pvt_emr_c.id
  route_table_id = aws_route_table.measurement_private_rt_c.id
}
