
# Associating shared DNS resolver rule for us to resolve commercial team's confluent cluster

# data "aws_route53_resolver_rule" "commercial_team_cc_resolver_rules" {
#   domain_name = var.commercial_cc_domain
#   rule_type   = "FORWARD"
# }

# resource "aws_route53_resolver_rule_association" "confluent_cloud_commercial_team_dns_resolver" {
#   name             = "commercial-shared-services-confluent-cloud-resolver-${var.env}"
#   resolver_rule_id = data.aws_route53_resolver_rule.commercial_team_cc_resolver_rules.id
#   vpc_id           = aws_vpc.measurement_vpc.id
# }

# Private link to connect our AWS account with Snowflake's
resource "aws_route53_zone" "snowflake-privatelink" {
  name    = "${var.region}.privatelink.snowflakecomputing.com"
  comment = aws_vpc.measurement_vpc.id
  vpc {
    vpc_id = aws_vpc.measurement_vpc.id
  }
  tags = var.tags
}

resource "aws_route53_record" "snowflake-privatelink" {
  zone_id = aws_route53_zone.snowflake-privatelink.zone_id
  name    = "*.${aws_route53_zone.snowflake-privatelink.name}"
  type    = "CNAME"
  ttl     = "300"
  records = [aws_vpc_endpoint.snowflake-privatelink.dns_entry[0].dns_name]
}
