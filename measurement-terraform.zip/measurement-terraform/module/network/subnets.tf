resource "aws_subnet" "sn_pvt_emr_a" {
  vpc_id                  = aws_vpc.measurement_vpc.id
  availability_zone       = var.subnet_a_az_name
  map_public_ip_on_launch = false
  cidr_block              = var.sn_pvt_emr_a_cidr
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-emr-private-a"
    tier = "measurement-emr"
  })
}

resource "aws_subnet" "sn_pvt_emr_b" {
  vpc_id                  = aws_vpc.measurement_vpc.id
  availability_zone       = var.subnet_b_az_name
  map_public_ip_on_launch = false
  cidr_block              = var.sn_pvt_emr_b_cidr
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-emr-private-b"
    tier = "measurement-emr"
  })
}

resource "aws_subnet" "sn_pvt_emr_c" {
  vpc_id                  = aws_vpc.measurement_vpc.id
  availability_zone       = var.subnet_c_az_name
  map_public_ip_on_launch = false
  cidr_block              = var.sn_pvt_emr_c_cidr
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-emr-private-c"
    tier = "measurement-emr"
  })
}
resource "aws_subnet" "sn_pvt_gen_a" {
  vpc_id                  = aws_vpc.measurement_vpc.id
  availability_zone       = var.subnet_a_az_name
  map_public_ip_on_launch = false
  cidr_block              = var.sn_pvt_gen_a_cidr
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-general-private-a"
    tier = "measurement-general"
  })
}


resource "aws_subnet" "sn_pvt_gen_b" {
  vpc_id                  = aws_vpc.measurement_vpc.id
  availability_zone       = var.subnet_b_az_name
  map_public_ip_on_launch = false
  cidr_block              = var.sn_pvt_gen_b_cidr
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-general-private-b"
    tier = "measurement-general"
  })
}

resource "aws_subnet" "sn_pvt_gen_c" {
  vpc_id                  = aws_vpc.measurement_vpc.id
  availability_zone       = var.subnet_c_az_name
  map_public_ip_on_launch = false
  cidr_block              = var.sn_pvt_gen_c_cidr
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-general-private-c"
    tier = "measurement-general"
  })
}

resource "aws_subnet" "sn_pub_web_a" {
  vpc_id                  = aws_vpc.measurement_vpc.id
  availability_zone       = var.subnet_a_az_name
  map_public_ip_on_launch = true
  cidr_block              = var.sn_pub_web_a_cidr
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-public-a"
    tier = "measurement-public"
  })
}

resource "aws_subnet" "sn_pub_web_b" {
  vpc_id                  = aws_vpc.measurement_vpc.id
  availability_zone       = var.subnet_b_az_name
  map_public_ip_on_launch = true
  cidr_block              = var.sn_pub_web_b_cidr

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-public-b"
    tier = "measurement-public"
  })
}

resource "aws_subnet" "sn_pub_web_c" {
  vpc_id                  = aws_vpc.measurement_vpc.id
  availability_zone       = var.subnet_c_az_name
  map_public_ip_on_launch = true
  cidr_block              = var.sn_pub_web_c_cidr
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-public-c"
    tier = "measurement-public"
  })
}


data "aws_subnets" "measurement_web" {
  filter {
    name   = "tag:tier"
    values = ["measurement-public"]
  }
}

data "aws_subnets" "measurement_emr" {
  filter {
    name   = "tag:tier"
    values = ["measurement-emr"]
  }
}

data "aws_subnets" "measurement_general" {
  filter {
    name   = "tag:tier"
    values = ["measurement-general"]
  }
}
