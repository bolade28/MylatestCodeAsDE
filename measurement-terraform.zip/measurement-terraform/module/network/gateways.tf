resource "aws_internet_gateway" "measurement_igw" {
  vpc_id = aws_vpc.measurement_vpc.id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-igw-eu-west-1"
  })
}

resource "aws_nat_gateway" "measurement_vpc_nat_gw_a" {
  allocation_id     = aws_eip.nat_gw_a.id
  connectivity_type = "public"
  subnet_id         = aws_subnet.sn_pub_web_a.id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-nat-gw-a"
  })

  depends_on = [aws_internet_gateway.measurement_igw]
}

resource "aws_nat_gateway" "measurement_vpc_nat_gw_b" {
  allocation_id     = aws_eip.nat_gw_b.id
  connectivity_type = "public"
  subnet_id         = aws_subnet.sn_pub_web_b.id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-nat-gw-b"
  })

  depends_on = [aws_internet_gateway.measurement_igw]
}

resource "aws_nat_gateway" "measurement_vpc_nat_gw_c" {
  allocation_id     = aws_eip.nat_gw_c.id
  connectivity_type = "public"
  subnet_id         = aws_subnet.sn_pub_web_c.id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-nat-gw-c"
  })

  depends_on = [aws_internet_gateway.measurement_igw]
}


resource "aws_eip" "nat_gw_a" {
  domain      = "vpc"
  depends_on = [aws_internet_gateway.measurement_igw]
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-eip-nat-gw-a"
  })

}

resource "aws_eip" "nat_gw_b" {
  domain      = "vpc"
  depends_on = [aws_internet_gateway.measurement_igw]
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-eip-nat-gw-b"
  })

}

resource "aws_eip" "nat_gw_c" {
  domain      = "vpc"
  depends_on = [aws_internet_gateway.measurement_igw]
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-eip-nat-gw-c"
  })

}
