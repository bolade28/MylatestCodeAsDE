

resource "aws_security_group" "snowflake-privatelink" {
  name   = "snowflake-privatelink-${aws_vpc.measurement_vpc.id}"
  vpc_id = aws_vpc.measurement_vpc.id

  ingress {
    from_port = 80
    to_port   = 80
    protocol  = "tcp"
    cidr_blocks = [
      var.sn_pvt_gen_a_cidr,
      var.sn_pvt_gen_b_cidr,
      var.sn_pvt_emr_a_cidr,
      var.sn_pvt_emr_b_cidr,
      var.sn_pvt_emr_c_cidr,
      var.sn_pvt_gen_c_cidr,
    ]
  }

  ingress {
    from_port = 443
    to_port   = 443
    protocol  = "tcp"
    cidr_blocks = [
      var.sn_pvt_gen_a_cidr,
      var.sn_pvt_gen_b_cidr,
      var.sn_pvt_emr_a_cidr,
      var.sn_pvt_emr_b_cidr,
      var.sn_pvt_emr_c_cidr,
      var.sn_pvt_gen_c_cidr,
    ]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = merge(var.tags, { Name = "measurement-${var.env}-snowflake-privatelink-security-group" })
}
