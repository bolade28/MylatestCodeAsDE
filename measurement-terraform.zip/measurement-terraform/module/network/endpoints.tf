resource "aws_vpc_endpoint" "s3-gw-endpoint" {
  vpc_id          = aws_vpc.measurement_vpc.id
  service_name    = "com.amazonaws.eu-west-1.s3"
  route_table_ids = [aws_route_table.measurement_private_rt_a.id, aws_route_table.measurement_private_rt_b.id, aws_route_table.measurement_private_rt_c.id]
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-s3-endpoint"
  })
}

resource "aws_vpc_endpoint" "snowflake-privatelink" {
  vpc_id = aws_vpc.measurement_vpc.id
  subnet_ids = [
    aws_subnet.sn_pvt_gen_a.id,
    aws_subnet.sn_pvt_gen_b.id,
    aws_subnet.sn_pvt_gen_c.id,
  ]
  service_name      = "com.amazonaws.vpce.${var.region}.${var.vpce_sf_service_id}"
  vpc_endpoint_type = "Interface"

  security_group_ids = [
    aws_security_group.snowflake-privatelink.id
  ]
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-snowflake-privatelink"
  })
}
