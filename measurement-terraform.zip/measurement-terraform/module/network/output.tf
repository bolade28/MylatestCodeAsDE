output "measurement_emr_subnet_ids" { value = data.aws_subnets.measurement_emr.ids }
output "measurement_general_subnet_ids" { value = data.aws_subnets.measurement_general.ids }
output "measurement_vpc" { value = aws_vpc.measurement_vpc.id }
output "measurement_web_subnet_ids" { value = data.aws_subnets.measurement_web.ids }
output "sn_pub_web_a" { value = aws_subnet.sn_pub_web_a.id }
output "sn_pub_web_b" { value = aws_subnet.sn_pub_web_b.id }
output "sn_pub_web_c" { value = aws_subnet.sn_pub_web_c.id }
output "sn_pvt_emr_a" { value = aws_subnet.sn_pvt_emr_a.id }
output "sn_pvt_emr_b" { value = aws_subnet.sn_pvt_emr_b.id }
output "sn_pvt_emr_c" { value = aws_subnet.sn_pvt_emr_c.id }
output "sn_pvt_gen_a" { value = aws_subnet.sn_pvt_gen_a.id }
output "sn_pvt_gen_a_arn" { value = aws_subnet.sn_pvt_gen_a.arn }
output "sn_pvt_gen_b" { value = aws_subnet.sn_pvt_gen_b.id }
output "sn_pvt_gen_b_arn" { value = aws_subnet.sn_pvt_gen_b.arn }
output "sn_pvt_gen_c" { value = aws_subnet.sn_pvt_gen_c.id }
output "sn_pvt_gen_c_arn" { value = aws_subnet.sn_pvt_gen_c.arn }
# output "snowflake_privatelink_security_group_id" { value = aws_security_group.snowflake-privatelink.id }

