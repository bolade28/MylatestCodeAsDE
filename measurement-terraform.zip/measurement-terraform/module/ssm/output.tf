
output "ssm_kms_key_arn" {
  value       = aws_kms_key.ssm_kms_key.arn
  description = "ARN of the KMS Key for SSM"
}
