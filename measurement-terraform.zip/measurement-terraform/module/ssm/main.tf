resource "aws_kms_key" "ssm_kms_key" {
  description = "Key for encrypting and decrypting SSMCloud Watch Logs"
  policy = data.aws_iam_policy_document.ssm_kms_key_policy_document.json
}


data "aws_iam_policy_document" "ssm_kms_key_policy_document" {

  # ----  KMS Key for encrypting and decrypting SSM CloudWatch Logs ----

  statement {

      actions = ["kms:*"]
      effect  = "Allow"
      principals {
        type        = "AWS"
        identifiers = ["arn:aws:iam::${var.account_number}:root"]
      }
    resources = [
      "*"
    ]
  }
  statement {

    actions = [
        "kms:Encrypt*",
        "kms:Decrypt*",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:Describe*"
      ]
    effect  = "Allow"
    resources = [
      "*"
    ]
    principals {
        type        = "Service"
        identifiers = ["logs.eu-west-1.amazonaws.com"]
    }
     condition {
        test     = "ArnEquals"
        variable = "kms:EncryptionContext:aws:logs:arn"
        values   = ["arn:aws:logs:eu-west-1:${var.account_number}:log-group:measurement-${var.env}-ssm-log-group"]
      }
  }
}


resource "aws_kms_alias" "airflow_key_alias" {
  name          = "alias/measurement-${var.env}-ssm-key"
  target_key_id = aws_kms_key.ssm_kms_key.key_id
}

# Create the CloudWatch Log Group with encryption enforced by the existing KMS key.
resource "aws_cloudwatch_log_group" "ssm_ec2_log_group" {
  name              = "measurement-${var.env}-ssm-log-group"
  retention_in_days = var.env == "dev" ? 30 : 90
  kms_key_id        = aws_kms_key.ssm_kms_key.arn
  tags              = var.tags
}

# Update the SSM Session Manager Run Shell document to use the new CloudWatch Log Group and KMS key.
# This is not ideal, way to update the document but it helps keep the shell file clean to get ssm session manager.
locals {
  ssm_session_manager_run_shell_document = jsonencode(
    {
      schemaVersion                 = "1.0"
      description                   = "Document to hold regional settings for Session Manager"
      sessionType                   = "Standard_Stream"
      inputs = {
        cloudWatchLogGroupName      = aws_cloudwatch_log_group.ssm_ec2_log_group.name     # Cloud watch log group name for the SSM Sessions
        cloudWatchEncryptionEnabled = true                                                # Enable encryption for CloudWatch logs
        idleSessionTimeout          = "20"                                                # Timeout limit for idle sessions
        cloudWatchStreamingEnabled  = true                                                # Send the CloudWatch logs to Log Group from active SSM sessions in real-time
        kmsKeyId                    = aws_kms_key.ssm_kms_key.key_id                      # KMS key ID for encrypting the CloudWatch logs
      }
    })
}

resource "null_resource" "update_ssm_session_manager_run_shell_document" {
  provisioner "local-exec" {
    command = <<EOT
      CURRENT_CONTENT=$(aws ssm get-document --name "SSM-SessionManagerRunShell" --document-version "\$LATEST" --query "Content" --output text)
      NEW_CONTENT=$(echo '${local.ssm_session_manager_run_shell_document}' | jq -c .)

      if [ "$CURRENT_CONTENT" != "$NEW_CONTENT" ]; then
        echo "Updating AWS managed SSM manager run shell document as it has changed"
        aws ssm update-document --name "SSM-SessionManagerRunShell" --content "$NEW_CONTENT" --document-version "\$LATEST" &&
        LATEST_VERSION=$(aws ssm list-document-versions --name "SSM-SessionManagerRunShell" --query "DocumentVersions[-1].DocumentVersion" --output text) &&
        aws ssm update-document-default-version --name "SSM-SessionManagerRunShell" --document-version "$LATEST_VERSION"
      else
        echo "No changes detected. Document content is the same."
      fi
    EOT
  }
}