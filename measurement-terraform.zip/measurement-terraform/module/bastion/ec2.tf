resource "aws_instance" "bastion" {
  ami           = var.ami_id
  instance_type = "t3.small"
  key_name      = var.ec2_key_name
  subnet_id     = var.subnet_id
  metadata_options {
    http_tokens                 = "required"
    http_put_response_hop_limit = "1"
  }
  vpc_security_group_ids = [aws_security_group.bastion_security_group.id]
  iam_instance_profile   = aws_iam_instance_profile.bastion_profile.name
  user_data              = <<-EOT
    #!/usr/bin/env bash
    sudo yum update -y
    sudo yum install -y nc
  EOT

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-bastion"
  })

  root_block_device {
    tags = merge(var.tags, { Name = "measurement-${var.env}-bastion-ebs" })
  }

  depends_on = [aws_security_group.bastion_security_group]
}

resource "aws_iam_instance_profile" "bastion_profile" {
  name = "measurement-${var.env}-bastion-instance-profile"
  role = aws_iam_role.bastion_role.name
}

resource "aws_iam_role" "bastion_role" {
  name                 = "measurement-${var.env}-bastion-iam-role"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Action": "sts:AssumeRole",
      "Principal": {
        "Service": "ec2.amazonaws.com"
      },
      "Effect": "Allow",
      "Sid": ""
    }
  ]
}
EOF

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-bastion-iam-role"
  })
}

# Minimal IAM policy for bastion SSM access
data "aws_iam_policy_document" "bastion_minimal_ssm_policy" {
  statement {
    effect = "Allow"
    actions = [
      "ssm:GetDocument",
      "ssm:DescribeDocument",
      "ssm:GetManifest",
      "ssm:ListInstanceAssociations",
      "ssm:PutInventory",
      "ssm:PutComplianceItems",
      "ssm:PutConfigurePackageResult",
      "ssm:UpdateInstanceAssociationStatus",
      "ssm:UpdateInstanceInformation",
      "ssmmessages:CreateControlChannel",
      "ssmmessages:CreateDataChannel",
      "ssmmessages:OpenControlChannel",
      "ssmmessages:OpenDataChannel",
    ]
    resources = ["*"]
  }
}

resource "aws_iam_policy" "bastion_minimal_ssm_policy" {
  name        = "measurement-${var.env}-bastion-minimal-ssm-policy"
  path        = "/"
  description = "Minimal IAM policy for bastion SSM access"
  policy      = data.aws_iam_policy_document.bastion_minimal_ssm_policy.json
}

# Attach the minimal SSM policy
resource "aws_iam_role_policy_attachment" "bastion_minimal_ssm_policy_attachment" {
  role       = aws_iam_role.bastion_role.name
  policy_arn = aws_iam_policy.bastion_minimal_ssm_policy.arn
}

resource "aws_security_group" "bastion_security_group" {
  description = "Security group for developer access to bastion instance"
  name        = "Bastion Security Group"
  vpc_id      = var.vpc_id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-bastion-sg"
  })
}
