variable "account_number" {}
variable "ami_id" {}
variable "ec2_key_name" {}
variable "env" {}
variable "subnet_id" {}
variable "tags" {}
variable "vpc_id" {}
