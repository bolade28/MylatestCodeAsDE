variable "env" {
  description = "The name of the environment."
  type        = string
}

variable "tags" {
  description = "A map of tags to assign to resources."
  type        = map(string)
  default     = {}
}

variable "dev_account_number" {
  type        = string
  description = "AWS development environment account number."
}

variable "lifecycle_expiration" {
  description = "S3 lifecycle expiration in days."
  type        = number
}

variable "lifecycle_expiration_extended" {
  description = "S3 lifecycle expiration in extended days, used for longer term buckets in prod."
  type        = number
}

variable "prod_account_number" {
  description = "AWS prod environment account number."
  type        = string
  default     = ""
}
