module "snowflake_unload_s3_bucket" {
  source = "../../module/s3"

  bucket_name               = "measurement-${var.env}-snowflake-unload"
  dev_account_number        = var.dev_account_number
  enable_dev_read_access    = true
  env                       = var.env
  lifecycle_expiration      = "Enabled"
  # lifecycle_expiration_days = var.lifecycle_expiration
  # Temporarily reducing data retention to 20 days to reduce s3 cost.
  # Will revert this to default retention of 30 days to facilitate debugging once pipeline is stable.
  lifecycle_expiration_days = var.env == "dev" ? 20 : var.lifecycle_expiration
  tags                      = var.tags
  versioning                = "Suspended"
}
