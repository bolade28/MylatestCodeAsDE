module "during_artefacts_bucket" {
  source = "../../module/s3"

  bucket_name             = "measurement-${var.env}-during-artefacts"
  dev_account_number      = var.dev_account_number
  prod_account_number     = var.prod_account_number
  enable_dev_read_access  = true
  env                     = var.env
  tags                    = var.tags
  lifecycle_expiration      = "Enabled"
  lifecycle_expiration_days = var.env == "dev" ? 180 : var.lifecycle_expiration_extended
  lifecycle_to_ia           = var.env == "prod" ? "Enabled" : "Disabled"
  lifecycle_to_ia_days      = 90 # this setting will only be applied to prod since the transition to IA rule wont be enabled in dev (in dev objects are expired after 30 days)
  versioning              = "Suspended"
}
