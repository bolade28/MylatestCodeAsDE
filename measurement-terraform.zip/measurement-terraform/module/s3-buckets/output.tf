output "ab_testing_bucket_arn" {
  value       = module.ab_testing_bucket.arn
  description = "The ARN of the A/B testing S3 bucket."
}

output "etl_output_bucket_arn" {
  value       = module.etl_output_bucket.arn
  description = "The ARN of the ETL output S3 bucket."
}

output "snowflake_unload_s3_bucket_arn" {
  value       = module.snowflake_unload_s3_bucket.arn
  description = "The ARN of the ETL output S3 bucket."
}

output "mlflow_artifacts_bucket" {
    value = {
    arn = module.mlflow_artifacts_bucket.arn,
    name = module.mlflow_artifacts_bucket.name
  }
  description = "The name and arn of the MLflow artifacts S3 bucket."
}
