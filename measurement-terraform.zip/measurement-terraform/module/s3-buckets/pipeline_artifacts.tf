module "pipeline_artefact_bucket" {
  source = "../../module/s3"

  bucket_name             = "measurement-${var.env}-artefacts"
  dev_account_number      = var.dev_account_number
  prod_account_number     = var.prod_account_number
  enable_dev_read_access  = true
  env                     = var.env
  tags                    = var.tags
  versioning              = "Enabled"
}
