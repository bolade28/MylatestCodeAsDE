module "etl_output_bucket" {
  source = "../../module/s3"

  bucket_name               = "measurement-${var.env}-etl-output"
  dev_account_number        = var.dev_account_number
  env                       = var.env
  tags                      = var.tags
  enable_dev_read_access    = true
  lifecycle_expiration      = "Enabled"
  # lifecycle_expiration_days = var.lifecycle_expiration
  # Temporarily reducing data retention to 20 days to reduce s3 cost.
  # Will revert this to default retention of 30 days to facilitate debugging once pipeline is stable.
  lifecycle_expiration_days = var.env == "dev" ? 20 : var.lifecycle_expiration
  lifecycle_to_ia           = var.env == "prod" ? "Enabled" : "Disabled"
  lifecycle_to_ia_days      = 30 # this setting will only be applied to prod since the transition to IA rule wont be enabled in dev (in dev objects are expired after 30 days)
}
