module "experiment_bucket" {
  source                  = "../../module/s3"
  count                   = var.env == "dev" ? 1 : 0
  bucket_name             = "measurement-${var.env}-experiment"
  dev_account_number      = var.dev_account_number
  lifecycle_expiration_days =  60
  env                     = var.env
  tags                    = var.tags
  versioning              = "Suspended"
}
