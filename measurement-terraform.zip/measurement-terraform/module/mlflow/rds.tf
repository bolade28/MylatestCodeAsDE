resource "aws_db_instance" "mlflow_rds_instance" {
  allocated_storage           = 50
  allow_major_version_upgrade = false
  apply_immediately           = true
  backup_retention_period     = 30
  backup_window               = "02:00-02:59"
  copy_tags_to_snapshot       = true
  db_name                     = jsondecode(data.aws_secretsmanager_secret_version.mlflow_secrets.secret_string)["db_name"]
  db_subnet_group_name        = aws_db_subnet_group.mlflow_rds_subnet_group.name
  delete_automated_backups    = false
  deletion_protection         = true
  engine                      = "postgres"
  engine_version              = "17.9"
  final_snapshot_identifier   = "measurement-${var.env}-mlflow-final-snapshot"
  identifier                  = "measurement-${var.env}-mlflow"
  instance_class              = "db.t3.micro"
  maintenance_window          = "Fri:03:00-Fri:04:00"
  multi_az                    = var.env == "prod" ? true : false
  password                    = jsondecode(data.aws_secretsmanager_secret_version.mlflow_secrets.secret_string)["password"]
  skip_final_snapshot         = false
  # snapshot_identifier         = var.env == "prod" ? "snapshot-for-terraform-migration-2023-07-14" : "final-snapshot-2023-07-12"
  storage_type                = "gp2"
  username                    = jsondecode(data.aws_secretsmanager_secret_version.mlflow_secrets.secret_string)["username"]
  vpc_security_group_ids      = [aws_security_group.mlflow_rds_security_group.id]

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-mlflow-rds-instance"
  })
}


resource "aws_db_subnet_group" "mlflow_rds_subnet_group" {
  name        = "measurement-${var.env}-mlflow-rds-subnet-group"
  description = "Subnet Group for MLflow RDS"
  subnet_ids  = var.subnet_group

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-mlflow-rds-subnet-group"
  })
}

resource "aws_security_group" "mlflow_rds_security_group" {
  description = "Security Group for MLflow RDS instance"
  name        = "MLflow RDS Security Group"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-mlflow-rds-sg"
  })

  egress {
    from_port   = 0
    protocol    = "-1"
    to_port     = 0
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port       = 5432
    protocol        = "tcp"
    to_port         = 5432
    security_groups = [aws_security_group.mlflow_security_group.id]
  }
}
