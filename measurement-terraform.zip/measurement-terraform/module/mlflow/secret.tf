data "aws_secretsmanager_secret_version" "mlflow_secrets" {
  secret_id = var.mlflow_secrets_id
}
