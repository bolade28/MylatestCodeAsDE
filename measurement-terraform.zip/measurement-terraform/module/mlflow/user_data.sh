#!/usr/bin/env bash

exec > >(tee /var/log/user-data.log | logger -t mlflow-user-data -s 2>/dev/console) 2>&1


sudo su

sudo yum update -y
yum install httpd-tools -y
yum install nginx -y

export NGINX_CONFIG=/etc/nginx/nginx.conf
sudo htpasswd -cb /etc/nginx/.htpasswd admin admin
echo "copying nginx config from S3"
aws s3 cp s3://${mlflow_artifacts_s3_bucket}/config/nginx/nginx.conf $NGINX_CONFIG
sudo nginx -t
sudo systemctl restart nginx


groupadd -g ${mlflow_instance_user_gid} ${mlflow_instance_user_group}
useradd ${mlflow_instance_user_name} -u ${mlflow_instance_user_uid}  -g ${mlflow_instance_user_gid} -m -s /bin/bash

# Now we will use the mlflow user and install dependencies into a venv
su - mlflow

sudo mkdir -p /var/log/mlflow
sudo chown -R ${mlflow_instance_user_gid}:${mlflow_instance_user_group} /var/log/mlflow

sudo yum update -y
sudo yum install python3.11  python3-pip -y
# sudo yum install python3-pip -y
sudo python3.11 -m venv /opt/python3.11/venv

sudo chown -R ${mlflow_instance_user_gid}:${mlflow_instance_user_group} /opt/python3.11/venv
sudo chown -R ${mlflow_instance_user_gid}:${mlflow_instance_user_group} /home/mlflow
sudo chown -R mlflow:mlflow /home/mlflow
source /opt/python3.11/venv/bin/activate
python3 -m pip install --upgrade pip
python3 -m pip install mlflow==3.10.0 boto3 psycopg2-binary
export MLFLOW_DB_URI=postgresql://${mlflow_database_user}:${mlflow_database_password}@${mlflow_database_host}/${mlflow_database_name}
export MLFLOW_ARTEFACTS_S3_BUCKET="s3://${mlflow_artifacts_s3_bucket}/artefacts/"

# this only needs to be run once, when the DB is created
# /opt/python3.11/venv/bin/mlflow db upgrade $MLFLOW_DB_URI
## ROOT USER ##

sudo su -

: '
    ---- Define environment variables for MLflow service ----

    Creates environment file used by the system service
    definitions below for the mlflow service.

'
cat <<EOF > /etc/sysconfig/mlflow
# Environment variables for MLflow service
MLFLOW_DB_URI="postgresql://${mlflow_database_user}:${mlflow_database_password}@${mlflow_database_host}/${mlflow_database_name}"
MLFLOW_ARTEFACTS_S3_BUCKET="s3://${mlflow_artifacts_s3_bucket}/artefacts/"
EOF

: '
    ---- Create mlflow service ----

    Creates a systemd service for the mlflow
    process. systemd is an init system
    and system manager. The mlflow service is
    started when the instance boots up or is
    rebooted.

'
cat << EOF > /etc/systemd/system/mlflow.service
[Unit]
Description=MLflow tracking server
After=network.target

[Service]
EnvironmentFile=/etc/sysconfig/mlflow
User=mlflow
Group=mlflow_ug
Type=simple
WorkingDirectory=/home/mlflow
ExecStart=/opt/python3.11/venv/bin/mlflow server --backend-store-uri $MLFLOW_DB_URI --default-artifact-root $MLFLOW_ARTEFACTS_S3_BUCKET --host 0.0.0.0 --port 5000
StandardOutput=append:/var/log/mlflow/mlflow.log
StandardError=append:/var/log/mlflow/mlflow.err
Restart=always
RestartSec=10s

[Install]
WantedBy=multi-user.target
EOF


# unset environment variables to avoid conflicts
unset $(grep -v '^#' /etc/sysconfig/mlflow | sed -E 's/(.*)=.*/\1/' | xargs)

: '
    ---- Enable and start mlflow service ----

    Enables the mlflow service to start on boot
    and starts it immediately.
'
echo "Enabling and starting mlflow service..."
systemctl daemon-reload
systemctl enable mlflow
systemctl start mlflow
