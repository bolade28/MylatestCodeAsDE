variable "account_number" {}
variable "ami_id" {}
variable "ec2_key_name" {}
variable "env" {}
variable "subnet_id" {}
variable "tags" {}
variable "vpc_id" {}
variable "mlflow_secrets_id" {}
variable "subnet_group" {}
variable "mlflow_artifacts_bucket_name" {}
variable "mlflow_artifacts_bucket_arn" {}
variable "bastion_security_group" {}
variable "mlflow_instance_user_gid" { default = "1001" }
variable "mlflow_instance_user_group" { default = "mlflow_ug" }
variable "mlflow_instance_user_name" { default = "mlflow" }
variable "mlflow_instance_user_uid" { default = "1001" }
variable "private_hosted_zone_id" {
  description = "The ID of the private hosted zone for internal DNS resolution"
  type        = string
}
