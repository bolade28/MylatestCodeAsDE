resource "aws_instance" "mlflow" {
  ami           = var.ami_id
  instance_type = "t3.small"
  key_name      = var.ec2_key_name
  subnet_id     = var.subnet_id
  metadata_options {
    http_tokens                 = "required"
    http_put_response_hop_limit = "1"
  }
  vpc_security_group_ids = [aws_security_group.mlflow_security_group.id]
  iam_instance_profile   = aws_iam_instance_profile.mlflow_profile.name
  user_data_base64       = base64encode(templatefile(
    "${path.module}/user_data.sh",
    {
      mlflow_artifacts_s3_bucket      = var.mlflow_artifacts_bucket_name
      mlflow_database_type            = "postgres"
      mlflow_database_host            = aws_db_instance.mlflow_rds_instance.endpoint
      mlflow_database_port            = 5432
      mlflow_database_name            = jsondecode(data.aws_secretsmanager_secret_version.mlflow_secrets.secret_string)["db_name"]
      mlflow_database_user            = jsondecode(data.aws_secretsmanager_secret_version.mlflow_secrets.secret_string)["username"]
      mlflow_database_password        = jsondecode(data.aws_secretsmanager_secret_version.mlflow_secrets.secret_string)["password"]
      mlflow_instance_user_gid        = var.mlflow_instance_user_gid
      mlflow_instance_user_group      = var.mlflow_instance_user_group
      mlflow_instance_user_name       = var.mlflow_instance_user_name
      mlflow_instance_user_uid        = var.mlflow_instance_user_uid

    }
  ))
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-mlflow"
  })

  root_block_device {
    tags = merge(var.tags, { Name = "measurement-${var.env}-mlflow-ebs" })
  }

  depends_on = [aws_security_group.mlflow_security_group]
}

resource "aws_iam_instance_profile" "mlflow_profile" {
  name = "measurement-${var.env}-mlflow-instance-profile"
  role = aws_iam_role.mlflow_role.name
}


resource "aws_security_group" "mlflow_security_group" {
  description = "Security group for developer access to MLflow instance"
  name        = "MLflow Security Group"
  vpc_id      = var.vpc_id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    from_port   = 5000
    to_port     = 5000
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    from_port       = 22
    to_port         = 22
    protocol        = "tcp"
    security_groups = [var.bastion_security_group]
  }

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-mlflow-sg"
  })
}

locals {
  nginx_config_rendered = base64encode(templatefile(
    "${path.module}/nginx.conf",
    {
      password = jsondecode(data.aws_secretsmanager_secret_version.mlflow_secrets.secret_string)["password"]
    }
  ))
}

resource "aws_s3_object" "nginx_config" {
  acl                    = "private"
  bucket                 = "measurement-${var.env}-mlflow"
  key                    = "config/nginx/nginx.conf"
  content_base64         = local.nginx_config_rendered
  source_hash            = md5(local.nginx_config_rendered)
  server_side_encryption = "AES256"
}

resource "aws_route53_record" "mlflow" {
  zone_id = var.private_hosted_zone_id
  name    = "mlflow.${var.env}.measurement.internal"
  type    = "A"
  ttl     = 300
  records = [aws_instance.mlflow.private_ip]  # Use instance private IP instead

  depends_on = [aws_instance.mlflow]

}
