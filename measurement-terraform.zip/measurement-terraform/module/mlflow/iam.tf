resource "aws_iam_role" "mlflow_role" {
  name                 = "measurement-${var.env}-mlflow-iam-role"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Action": "sts:AssumeRole",
      "Principal": {
        "Service": "ec2.amazonaws.com"
      },
      "Effect": "Allow",
      "Sid": ""
    }
  ]
}
EOF

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-mlflow-iam-role"
  })
}

data "aws_iam_policy_document" "mlflow_ec2_instance_policy_document" {
    statement {
        actions = [
          "s3:GetObject",
          "s3:PutObject"
        ]
        resources = ["${var.mlflow_artifacts_bucket_arn}/*"]
    }

    statement {
        actions = ["s3:ListBucket"]
        resources = ["${var.mlflow_artifacts_bucket_arn}"]
    }
}

resource "aws_iam_policy" "mlflow_ec2_instance_policy" {
  name        = "measurement-${var.env}-mlflow-ec2-instance-policy"
  path        = "/"
  description = "TBD"
  policy      = data.aws_iam_policy_document.mlflow_ec2_instance_policy_document.json
}

resource "aws_iam_role_policy_attachment" "mlflow_ec2_instance_policy_attachment" {
  role       = aws_iam_role.mlflow_role.name
  policy_arn = aws_iam_policy.mlflow_ec2_instance_policy.arn
}

/*
We currently don't need this, it flags as exessive permissions, but we may need it in the future.
resource "aws_iam_role_policy_attachment" "mlflow_role_ssm_policy_attach" {
  role       = aws_iam_role.mlflow_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}
*/
