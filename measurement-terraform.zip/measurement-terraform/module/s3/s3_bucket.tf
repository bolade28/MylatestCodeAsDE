resource "aws_s3_bucket" "bucket" {
  bucket        = var.bucket_name
  force_destroy = var.force_destroy
  tags          = var.tags
}

resource "aws_s3_bucket_versioning" "bucket_versioning_configuration" {
  bucket = aws_s3_bucket.bucket.id
  count  = var.versioning == "Enabled" || var.versioning == "Suspended" ? 1 : 0

  versioning_configuration {
    status     = var.versioning
    mfa_delete = var.mfa_delete
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "bucket_lifecycle_config" {

  bucket = aws_s3_bucket.bucket.id

  rule {
    id = "transition_to_ia"
    # Empty filter required: https://github.com/hashicorp/terraform-provider-aws/issues/41710
    filter {
      prefix = ""
    }
    transition {
      days          = var.lifecycle_to_ia_days
      storage_class = "STANDARD_IA"
    }
    status = var.lifecycle_to_ia
  }

  rule {
    id = "transition_to_glacier"
    filter {
      prefix = ""
    }
    transition {
      days          = var.lifecycle_to_glacier_days
      storage_class = "GLACIER"
    }
    status = var.lifecycle_to_glacier
  }

  rule {
    id = "expire_objects"
    filter {
      prefix = ""
    }
    expiration {
      days = var.lifecycle_expiration_days
    }
    status = var.lifecycle_expiration
  }

}

resource "aws_s3_bucket_public_access_block" "bucket" {
  bucket = aws_s3_bucket.bucket.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "bucket_encryption_config" {
  bucket = aws_s3_bucket.bucket.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_ownership_controls" "etl_output_bucket_ownership_controls" {
  bucket = aws_s3_bucket.bucket.id
  rule {
    object_ownership = "BucketOwnerEnforced"
  }
}


resource "aws_s3_bucket_policy" "allow_read_access_from_dev_account" {
  bucket = aws_s3_bucket.bucket.id
  # for buckets in prod that we want to be able to read from dev (default is false to read from dev)
  policy = data.aws_iam_policy_document.s3_bucket_policy.json
}

data "aws_iam_policy_document" "s3_bucket_policy" {

  statement {
    sid = "AllowSSLRequestsOnly"

    principals {
      identifiers = ["*"]
      type        = "*"
    }
    actions = ["s3:*"]
    effect  = "Deny"

    condition {
      test     = "Bool"
      values   = [false]
      variable = "aws:SecureTransport"
    }

    resources = [
      aws_s3_bucket.bucket.arn,
      "${aws_s3_bucket.bucket.arn}/*",
    ]
  }

  dynamic "statement" {
    # This statement is only included for prod buckets where we need to be able to read from dev
    for_each = var.env == "prod" && var.enable_dev_read_access ? [1] : []

    content {
      sid = "allowReadAccessFromDevAccount"
      principals {
        type        = "AWS"
        identifiers = ["arn:aws:iam::${var.dev_account_number}:root"]
      }

      actions = [
        "s3:GetObject",
        "s3:ListBucket",
      ]

      resources = [
        aws_s3_bucket.bucket.arn,
        "${aws_s3_bucket.bucket.arn}/*",
      ]
    }
  }

  dynamic "statement" {
    # This statement is only included for dev buckets where we need to be able to read from prod
    # example: the ab-testing bucket
    for_each = var.env == "dev" && var.enable_prod_read_access ? [1] : []

    content {
      sid = "allowReadAccessFromProdAccount"
      principals {
        type        = "AWS"
        identifiers = ["arn:aws:iam::${var.prod_account_number}:root"]
      }

      actions = [
        "s3:GetObject",
        "s3:ListBucket",
        "s3:GetObjectTagging"
      ]

      resources = [
        aws_s3_bucket.bucket.arn,
        "${aws_s3_bucket.bucket.arn}/*",
      ]
    }
  }

}

