variable "bucket_name" {
  description = "The globally unique bucket name."
}

variable "bucket_acl" {
  description = "Canned ACL to provide default access control lists"
  default     = "private"
}

variable "dev_account_number" {
  description = "The account number for measurement-dev. Used to allow read access to certain buckets"
}

variable "prod_account_number" {
  description = "The account number for measurement-prod. Used to allow read access to certain buckets"
  default     = ""
}

variable "enable_dev_read_access" {
  description = "Allows this bucket in prod to be read from the dev account"
  default     = false
}

variable "enable_prod_read_access" {
  description = "Allows this bucket in dev to be read from the prod account - this is usually helpful for manual deployments."
  default     = false
}

variable "env" {
  description = "dev or prod environment. When creating some buckets in prod applies some extra bucket policies to allow read access from dev"
}

variable "force_destroy" {
  description = "Allows terraform to destroy the bucket and lose the data."
  default     = false
}

variable "versioning" {
  description = "Should the bucket have object versioning enabled."
  default     = "Disabled"
}

variable "mfa_delete" {
  description = "Require MFA to change versioning state/permanently delete object versions"
  default     = "Disabled"
}

variable "lifecycle_to_ia" {
  description = "Transition bucket object to S3 IA"
  default     = "Disabled"
}

variable "lifecycle_to_ia_days" {
  description = "Days until transition of bucket object to S3 IA"
  default     = 90
}

variable "lifecycle_to_glacier" {
  description = "Transition bucket object to Glacier"
  default     = "Disabled"
}

variable "lifecycle_to_glacier_days" {
  description = "Days until transition of bucket object to Glacier"
  default     = 120
}

variable "lifecycle_expiration" {
  description = "Permanently delete bucket object"
  default     = "Disabled"
}

variable "lifecycle_expiration_extended" {
  description = "Permanently delete bucket object after extended period"
  default     = "Disabled"
}

variable "lifecycle_expiration_days" {
  description = "Days until permanent deletion of bucket object"
  default     = 365
}

variable "tags" {}
