output "arn" {
  value       = aws_s3_bucket.bucket.arn
  description = "The ARN of the S3 Bucket"
}

output "name" {
  value       = aws_s3_bucket.bucket.bucket
  description = "The name of the S3 Bucket"
}
