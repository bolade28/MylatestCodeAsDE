resource "aws_iam_role" "snowflake_unload_role" {
  name                 = "measurement-${var.env}-snowflake-unload-role"
  description          = "Grants access to Snowflake to access s3 unload bucket."
  path                 = "/"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"
  tags                 = var.tags
  assume_role_policy   = data.aws_iam_policy_document.snowflake_unload_trust_policy_document.json
}

data "aws_iam_policy_document" "snowflake_unload_trust_policy_document" {

  # ----  Allowing snowflake unload role to be able to read and write to s3 bucket ----

  statement {

      actions = ["sts:AssumeRole"]
      effect  = "Allow"
      principals {
        type        = "AWS"
        identifiers = ["${var.snowflake_principal_arn}"]
      }
      condition {
        test     = "StringEquals"
        variable = "sts:ExternalId"
        values = [
          var.snowflake_external_id
        ]
      }
      dynamic "condition" {
      for_each = var.env == "dev" ? [1] : []
      content {
        test     = "StringEquals"
        variable = "sts:ExternalId"
        values   = [var.exp_snowflake_external_id]
      }
      }
  }
}


data "aws_iam_policy_document" "snowflake_unload_role_policy_document" {

  # ----  Allowing snowflake unload role to be able to read and write to s3 bucket ----

  statement {

    actions = [
        "s3:PutObject",
        "s3:GetObject",
        "s3:GetObjectVersion",
        "s3:DeleteObject",
        "s3:DeleteObjectVersion"
      ]
    effect  = "Allow"
    resources = concat(
      ["arn:aws:s3:::measurement-${var.env}-snowflake-unload/*"],
      var.env == "dev" ? ["arn:aws:s3:::measurement-${var.env}-experiment/*"] : []
      )
  }
   statement {

    actions = ["s3:ListBucket"]
    effect  = "Allow"
    resources = concat(
      ["arn:aws:s3:::measurement-${var.env}-snowflake-unload"],
       var.env == "dev" ? ["arn:aws:s3:::measurement-${var.env}-experiment"] : []
    )
  }
}

resource "aws_iam_policy" "snowflake_unload_policy" {
  name   = "measurement-${var.env}-snowflake-unload-policy"
  policy = data.aws_iam_policy_document.snowflake_unload_role_policy_document.json
}

resource "aws_iam_role_policy_attachment" "snowflake_unload_policy_attachment" {
  policy_arn = aws_iam_policy.snowflake_unload_policy.arn
  role       = aws_iam_role.snowflake_unload_role.name
}
