resource "aws_iam_role" "snowflake_temp_stage_role" {
  name                 = "measurement-${var.env}-snowflake-temp-stage-role"
  description          = "Grants access to Snowflake to access s3 temp stage bucket."
  path                 = "/"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"
  tags                 = var.tags
  assume_role_policy   = data.aws_iam_policy_document.snowflake_temp_trust_policy_document.json
}

data "aws_iam_policy_document" "snowflake_temp_trust_policy_document" {

  # ----  Allowing snowflake temp role to be able to read and write to s3 bucket ----

  statement {

      actions = ["sts:AssumeRole"]
      effect  = "Allow"
      principals {
        type        = "AWS"
        identifiers = ["${var.snowflake_principal_arn}"]
      }
      condition {
        test     = "StringEquals"
        variable = "sts:ExternalId"
        values = [
          "SAINSBURYS_SFCRole=16578_pp8AqQuFp1oZVCBG/O8iKHmiUDw="
        ]
      }
  }
}


data "aws_iam_policy_document" "snowflake_temp_role_policy_document" {

  # ----  Allowing snowflake temp role to be able to read and write to s3 bucket ----

  statement {

    actions = [
        "s3:PutObject",
        "s3:GetObject",
        "s3:GetObjectVersion",
        "s3:DeleteObject",
        "s3:DeleteObjectVersion"
      ]
    effect  = "Allow"
    resources = [
      "arn:aws:s3:::measurement-${var.env}-temp/*"
    ]
  }
   statement {

    actions = ["s3:ListBucket"]
    effect  = "Allow"
    resources = [
      "arn:aws:s3:::measurement-${var.env}-temp"
    ]
  }
}

resource "aws_iam_policy" "snowflake_temp_policy" {
  name   = "measurement-${var.env}-snowflake-temp-policy"
  policy = data.aws_iam_policy_document.snowflake_temp_role_policy_document.json
}

resource "aws_iam_role_policy_attachment" "snowflake_temp_policy_attachment" {
  policy_arn = aws_iam_policy.snowflake_temp_policy.arn
  role       = aws_iam_role.snowflake_temp_stage_role.name
}
