#
#
#     ---- Authorise access to Rhubarb's secret for the Measurement snowflake service user for Airflow ----
#     see some related documentation at
#         https://secret-management.docs.aspire.js-devops.co.uk/user_guide/REQUEST_SNOWFLAKE_SERVICE_USER/
#
#


#
#     --- 1. Create a role for the Measurement snowflake service user ---
#

# Create a policy document to allow the role to assume the role
# You have to add the ARNs for the roles that you wish to access the secret with
data "aws_iam_policy_document" "instance_assume_role_policy" {
  statement {
    sid     = "AllowAssumeRoleForOtherServices"
    actions = ["sts:AssumeRole"]
    effect  = "Allow"

    principals {
      type = "AWS"
      identifiers = var.env == "prod" ? [
        "arn:aws:iam::${var.account_number}:role/measurement-${var.env}-airflow-instance-role",
        "arn:aws:iam::${var.account_number}:role/measurement-${var.env}-grafana-instance-role",
        "arn:aws:iam::${var.account_number}:role/EMR_EC2_DefaultRole"
        ] : [
        "arn:aws:iam::${var.account_number}:role/measurement-${var.env}-airflow-instance-role",
        "arn:aws:iam::${var.account_number}:role/measurement-${var.env}-grafana-instance-role",
        "arn:aws:iam::${var.account_number}:role/ccoe/developer",
        "arn:aws:iam::${var.account_number}:role/EMR_EC2_DefaultRole"
      ]
    }
  }
}

resource "aws_iam_role" "measurement_rhubarb_secret_access_role" {
  name                 = "measurement-rhubarb-secret-access-role-${var.env}"
  tags                 = var.tags
  assume_role_policy   = data.aws_iam_policy_document.instance_assume_role_policy.json
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"
}


#
#     ---- 2. Create a policy for the Rhubarb secret ----
#
data "aws_iam_policy_document" "rhubarb_trusted_policy_document" {
  #
  # ----  Secrets     ----
  #
  statement {
    sid       = "AllowRhubarbSecretAccess"
    effect    = "Allow"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = ["arn:aws:secretsmanager:${var.region}:${var.rhubarb_account_id}:secret:${var.rhubarb_aws_secret_name}-*"]
  }

  #
  # ----    KMS     ----
  #
  statement {
    sid    = "AllowAccessToRhubarbSecretKmsKey"
    effect = "Allow"
    actions = [
      "kms:Encrypt",
      "kms:Decrypt",
      "kms:ReEncrypt*",
      "kms:GenerateDataKey*",
      "kms:DescribeKey"
    ]
    resources = ["arn:aws:kms:${var.region}:${var.rhubarb_account_id}:key/*"]

    condition {
      test     = "ForAnyValue:StringEquals"
      values   = [var.rhubarb_kms_key_alias]
      variable = "kms:ResourceAliases"
    }
  }
}

# Create a policy using the document from above
resource "aws_iam_policy" "rhubarb_secret_for_snowflake_service_user_policy" {
  name        = "measurement-${var.env}-rhubarb-secret-for-snowflake-service-user-policy"
  description = "Allow for key rotation for the Snowflake Service User."
  tags        = var.tags
  policy      = data.aws_iam_policy_document.rhubarb_trusted_policy_document.json
}

#
#     ---- 4. Attach the policies to the relevant roles ----
#

# Attach the policy to the airflow instance role
resource "aws_iam_role_policy_attachment" "deploy-policy-attachment-tf-airflow" {
  role       = aws_iam_role.measurement_rhubarb_secret_access_role.name
  policy_arn = aws_iam_policy.rhubarb_secret_for_snowflake_service_user_policy.arn
}
