variable "account_number" {}

variable "prod_account_number" {}

variable "tags" {}

variable "env" {}

variable "region" {}

# variable "secret_piano_campaign_api_key" {}

variable "rhubarb_account_id" { description = "Rhubarb account ID" }

variable "rhubarb_aws_secret_name" { description = "The secret that was provided by Rhubarb to allow for credential rotation of Snowflake credentials." }

variable "rhubarb_kms_key_alias" { description = "This allows for the decryption of the Secret from Rhubarb." }

variable "snowflake_external_id" {
  description = "The AWS external ID that must be used when assuming the Snowflake unload role."
  type        = string
}

variable "exp_snowflake_external_id" {
  type        = string
  description = "The AWS external ID that must be used when assuming the Snowflake unload role for experimentation."
}


variable "snowflake_principal_arn" {
  description = "The ARN of the AWS principal that is allowed to assume the Snowflake unload role."
  type        = string
  default     = "arn:aws:iam::520339422657:user/uznh-s-iess0104"
}

# variable "sagemaker_key_alias" {}

# variable "sagemaker_model_output_key_arn" {
#   description = "The KMS key used to encrypt the Sagemaker model output file"
#   type        = string
#   default     = ""
# }

# variable "secret_new_relic_api_key" {}

# variable "secret_servicenow_api_key" {}

# variable "secret_snow_utils_deploy_key" {}
