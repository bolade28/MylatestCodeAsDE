USE role RL_PROD_UP_ENGINEER;

USE warehouse WHS_PROD_UP_LARGE;

call snowflake_administration.stored_procedures.create_storage_integration_v1_0(
        'MEASUREMENT_DEV_INTEGRATION', -- integration name for dev
        'arn:aws:iam::277707132387:role/measurement-dev-snowflake-unload-role', -- role will remain static
        '("s3://measurement-dev-snowflake-unload/")',
        '(("RL_PROD_UP_ENGINEER"),("RL_PROD_UP_ETL"),("RL_DEV_UP_ETL"),("RL_DEV_UP_ENGINEER"))',
        'dev',
        'measurement@sainsburys.co.uk',
        '("measurement@sainsburys.co.uk")',
        'true',
        '9999-12-31',
        '9999-12-31',
        'RL_PROD_UP_ENGINEER,RL_PROD_UP_ETL,RL_DEV_UP_ETL'
);

describe integration MEASUREMENT_DEV_INTEGRATION;

USE DATABASE UNIFIED_PLATFORM_PROD;
use SCHEMA ADW_UNIFIED_PLATFORM_TACTICAL;
-- new file format created as it didn't exists in the database. This only needed to be created once.
create file format measurement_parquet_file_format type = 'parquet';

CREATE STAGE MEASUREMENT_DEV_STAGE
        URL='s3://measurement-dev-snowflake-unload/'
        STORAGE_INTEGRATION = MEASUREMENT_DEV_INTEGRATION
        FILE_FORMAT = MEASUREMENT_PARQUET_FILE_FORMAT
        ;
