#!/usr/bin/env bash

# Run as root
sudo su
# Make shell scripts fail fast on any error, unset variable, or failed pipe command
set -euo pipefail

yum update -y

# Python 3.9 comes pre-installed on Amazon Linux 2023.
sudo yum install libXrender fontconfig freetype initscripts urw-fonts wget unzip -y
echo "Install Packages successfully!!"

# This creates a "grafana" user and group, and sets up the necessary directories for Grafana to run.
sudo yum install -y https://dl.grafana.com/oss/release/grafana-12.0.2-1.x86_64.rpm
sudo yum clean packages
echo "Install Grafana successfully!!"

export GRAFANA_HOME=/etc/grafana
export GRAFANA_CONFIG=$GRAFANA_HOME/grafana.ini
# Setup for the provisioning script to run in a dedicated virtual environment with its own requirements file
export SNOWFLAKE_PROVISION_VENV=/opt/grafana-snowflake-provision-venv
export SNOWFLAKE_PROVISION_REQUIREMENTS=/usr/local/libexec/snowflake_datasource_provision_requirements.txt

###  Copy Grafana config from S3  ###
aws s3 cp s3://${grafana_artifacts_bucket}/${grafana_config_s3_key} $GRAFANA_CONFIG

###  Install Plugins  ###
plugin_archive="/tmp/measurement-snowflake-grafana-datasource.zip"
aws s3 cp "s3://${grafana_artifacts_bucket}/plugins/measurement-snowflake-grafana-datasource.zip" "$plugin_archive"

sudo rm -rf /var/lib/grafana/plugins/michelin-snowflake-datasource
sudo unzip -q "$plugin_archive" -d /var/lib/grafana/plugins
sudo chown -R grafana:grafana /var/lib/grafana/plugins/
rm -f "$plugin_archive"

echo "Install Grafana Plugins successfully!!"

### Configure Snowflake Grafana datasource provisioning ###
# Ensure directory exists for where we want to put the Snowflake Grafana datasource provisioning script
sudo install -d -m 0755 /usr/local/libexec

sudo python3 -m venv "$SNOWFLAKE_PROVISION_VENV"

# Copy the Snowflake Grafana datasource provisioning script and environment file from S3 to the appropriate locations
aws s3 cp s3://${grafana_artifacts_bucket}/${snowflake_provision_python_s3_key} /usr/local/libexec/snowflake_datasource_provision.py
aws s3 cp s3://${grafana_artifacts_bucket}/${snowflake_provision_environment_s3_key} /etc/grafana/snowflake-datasource-provision.env

printf '%s' '${snowflake_provision_requirements_base64}' | base64 --decode | sudo tee "$SNOWFLAKE_PROVISION_REQUIREMENTS" > /dev/null
sudo "$SNOWFLAKE_PROVISION_VENV/bin/python" -m pip install --upgrade pip
sudo "$SNOWFLAKE_PROVISION_VENV/bin/python" -m pip install --requirement "$SNOWFLAKE_PROVISION_REQUIREMENTS"

# Create systemd service and timer unit files for the Snowflake Grafana datasource provisioning script, tee reads from stdin and writes to the specified file, > /dev/null discards the output of tee command
printf '%s' '${snowflake_provision_service_base64}' | base64 --decode | sudo tee /etc/systemd/system/grafana-snowflake-datasource-provision.service > /dev/null
printf '%s' '${snowflake_provision_timer_base64}' | base64 --decode | sudo tee /etc/systemd/system/grafana-snowflake-datasource-provision.timer > /dev/null

# This isn't strictly necessary, but it makes the file permissions more explicit.
# Explicitly set permissions for the Snowflake Grafana datasource provisioning script, environment file, and systemd unit files
sudo chown -R root:root "$SNOWFLAKE_PROVISION_VENV"
sudo chmod -R go-w "$SNOWFLAKE_PROVISION_VENV"

sudo chown root:root /usr/local/libexec/snowflake_datasource_provision.py
sudo chmod 0700 /usr/local/libexec/snowflake_datasource_provision.py

sudo chown root:root "$SNOWFLAKE_PROVISION_REQUIREMENTS"
sudo chmod 0600 "$SNOWFLAKE_PROVISION_REQUIREMENTS"

sudo chown root:root /etc/grafana/snowflake-datasource-provision.env
sudo chmod 0600 /etc/grafana/snowflake-datasource-provision.env

sudo chmod 0644 /etc/systemd/system/grafana-snowflake-datasource-provision.service
sudo chmod 0644 /etc/systemd/system/grafana-snowflake-datasource-provision.timer

###  Start Grafana Server
sudo systemctl daemon-reload

# Start Grafana first; the provisioner reloads datasource YAML via its local Admin API.
sudo systemctl enable --now grafana-server

# Write and reload the initial datasource, then schedule subsequent key-rotation refreshes.
sudo systemctl start grafana-snowflake-datasource-provision.service
sudo systemctl enable --now grafana-snowflake-datasource-provision.timer

echo "Start Grafana Server successfully!!"
