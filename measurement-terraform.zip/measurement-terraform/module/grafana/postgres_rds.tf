
resource "aws_db_instance" "grafana_rds_instance" {
  allocated_storage           = 50
  allow_major_version_upgrade = true
  apply_immediately           = true
  backup_retention_period     = 30
  copy_tags_to_snapshot       = true
  db_name                     = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["db_name"]
  db_subnet_group_name        = aws_db_subnet_group.grafana_subnet.name
  delete_automated_backups    = true
  deletion_protection         = true
  engine                      = "postgres"
  final_snapshot_identifier   = "measurement-${var.env}-grafana-final-snapshot"
  identifier                  = "measurement-${var.env}-grafana"
  instance_class              = var.grafana_rds_instance_class
  maintenance_window          = "Fri:03:00-Fri:04:00"
  multi_az                    = var.env == "prod" ? true : false
  password                    = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["db_password"]
  skip_final_snapshot         = false
  storage_type                = "gp2"
  username                    = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["db_user"]
  vpc_security_group_ids      = [aws_security_group.grafana_rds_security_group.id]

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-grafana-rds-instance"
  })

  lifecycle {
    create_before_destroy = true
    ignore_changes        = [db_name, password, username]
  }

}

resource "aws_db_subnet_group" "grafana_subnet" {
  name        = "grafana_subnet_group"
  description = "Subnet Group for Grafana RDS"
  subnet_ids  = var.grafana_subnet_group

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-grafana-subnet-group"
  })
}

resource "aws_security_group" "grafana_rds_security_group" {
  description = "Security Group for Grafana RDS instance"
  name        = "Grafana RDS Security Group"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-grafana-rds-sg"
  })

  egress {
    from_port   = 0
    protocol    = "-1"
    to_port     = 0
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port       = 5432
    protocol        = "tcp"
    to_port         = 5432
    security_groups = [aws_security_group.grafana_instance_security_group.id]
  }
}
