data "aws_iam_policy_document" "grafana_access_role" {
  statement {
    actions = [
      "sts:AssumeRole"
    ]
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "grafana_access_role" {
  name                 = "measurement-${var.env}-grafana-instance-role"
  path                 = "/"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"
  assume_role_policy   = data.aws_iam_policy_document.grafana_access_role.json

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-grafana-role"
  })
}

data "aws_iam_policy_document" "grafana_ec2_instance_policy" {
    statement {
        actions = [
          "s3:GetObject",
          "s3:PutObject"
        ]
        resources = ["${module.s3-grafana-artifacts.arn}/*"]
    }

    statement {
        actions = ["s3:ListBucket"]
        resources = ["${module.s3-grafana-artifacts.arn}"]
    }
}

resource "aws_iam_policy" "grafana_ec2_instance_policy" {
  name        = "measurement-${var.env}-grafana-ec2-instance-policy"
  path        = "/"
  description = "TBD"
  policy      = data.aws_iam_policy_document.grafana_ec2_instance_policy.json
}

data "aws_iam_policy_document" "grafana_ec2_instance_cloudwatch_policy" {
    statement {
        actions = [
        "cloudwatch:GetMetricData",
        "cloudwatch:GetMetricStatistics",
        "cloudwatch:ListMetrics",
        "ec2:DescribeTags"
        ]
        resources = ["*"]
    }
}

resource "aws_iam_policy" "grafana_ec2_instance_cloudwatch_policy" {
  name        = "measurement-${var.env}-grafana-ec2-instance-cloudwatch-policy"
  path        = "/"
  description = "TBD"
  policy      = data.aws_iam_policy_document.grafana_ec2_instance_cloudwatch_policy.json
}

# Minimal IAM policy for grafana SSM access
data "aws_iam_policy_document" "grafana_minimal_ssm_policy" {
  statement {
    effect = "Allow"
    actions = [
      "ssm:GetDocument",
      "ssm:DescribeDocument",
      "ssm:GetManifest",
      "ssm:PutInventory",
      "ssm:PutConfigurePackageResult",
      "ssmmessages:CreateControlChannel",
      "ssmmessages:CreateDataChannel",
      "ssmmessages:OpenControlChannel",
      "ssmmessages:OpenDataChannel",
    ]
    resources = ["*"]  # ssm:GetDocument and ssmmessages require * as the resource, as they are not resource-specific actions.
  }
}

resource "aws_iam_policy" "grafana_minimal_ssm_policy" {
  name        = "measurement-${var.env}-grafana-minimal-ssm-policy"
  path        = "/"
  description = "Minimal IAM policy for grafana SSM access"
  policy      = data.aws_iam_policy_document.grafana_minimal_ssm_policy.json
}

resource "aws_iam_role_policy_attachment" "grafana_ec2_instance_policy_attachment" {
  role       = aws_iam_role.grafana_access_role.name
  policy_arn = aws_iam_policy.grafana_ec2_instance_policy.arn
}

resource "aws_iam_role_policy_attachment" "grafana_ec2_instance_cloudwatch_policy_attachment" {
  role       = aws_iam_role.grafana_access_role.name
  policy_arn = aws_iam_policy.grafana_ec2_instance_cloudwatch_policy.arn
}

# Attach the minimal SSM policy
resource "aws_iam_role_policy_attachment" "grafana_minimal_ssm_policy_attachment" {
  role       = aws_iam_role.grafana_access_role.name
  policy_arn = aws_iam_policy.grafana_minimal_ssm_policy.arn
}

resource "aws_iam_instance_profile" "grafana_instance_profile" {
  name = "measurement-${var.env}-grafana-instance-profile"
  role = aws_iam_role.grafana_access_role.name
}

# ---------------------------------------------------------------------------
# Snowflake datasource provisioning
# ---------------------------------------------------------------------------
data "aws_iam_policy_document" "grafana_secret_policy" {
  # Allow reading the Grafana connection secret so we can get the admin password for the Snowflake datasource provisioning script.
  statement {
    sid       = "AllowReadGrafanaConnectionSecret"
    effect    = "Allow"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [var.grafana_secrets_id]
  }
}

data "aws_iam_policy_document" "grafana_snowflake_policy" {
  # Allow reading the shared Snowflake connection secret (host, login, extra, etc.) for datasource auto-provisioning.
  statement {
    sid       = "AllowReadSnowflakeConnectionSecret"
    effect    = "Allow"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [var.snowflake_connection_secret_arn]
  }
}

resource "aws_iam_policy" "grafana_secret_policy" {
  name        = "measurement-${var.env}-grafana-secret-policy"
  path        = "/"
  description = "Allows Grafana EC2 instance to read the Grafana connection secret for datasource auto-provisioning."
  policy      = data.aws_iam_policy_document.grafana_secret_policy.json
}

resource "aws_iam_role_policy_attachment" "grafana_secret_policy_attachment" {
  role       = aws_iam_role.grafana_access_role.name
  policy_arn = aws_iam_policy.grafana_secret_policy.arn
}