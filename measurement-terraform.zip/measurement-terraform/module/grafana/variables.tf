variable "account_number" {}
variable "ami_id" {}
variable "bastion_security_group" {}
variable "dev_account_number" {}
variable "ec2_key_name" {}
variable "env" {}
variable "grafana_root_url" {}
variable "grafana_ec2_instance_type" {}
variable "grafana_rds_engine_version" {}
variable "grafana_rds_instance_class" {}
variable "metrics_instance_desired_capacity" {}
variable "metrics_instance_max_size" {}
variable "metrics_instance_min_size" {}
variable "region" {}
variable "grafana_secrets_id" {}
variable "snowflake_connection_secret_arn" {
  description = "ARN of the shared Snowflake connection secret used to auto-provision the Michelin Snowflake Grafana datasource."
  type        = string
}
variable "grafana_subnet_group" {}
variable "sn_pvt_gen_a" {}
variable "sn_pvt_gen_b" {}
variable "sn_pvt_gen_c" {}
variable "sn_pub_web_a" {}
variable "sn_pub_web_b" {}
variable "sn_pub_web_c" {}
variable "tags" {}
variable "vpc_id" {}
