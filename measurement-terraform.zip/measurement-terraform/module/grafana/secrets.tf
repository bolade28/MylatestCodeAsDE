data "aws_secretsmanager_secret_version" "grafana_secrets" {
  secret_id = var.grafana_secrets_id
}

data "aws_secretsmanager_secret_version" "snowflake_connection" {
  secret_id = var.snowflake_connection_secret_arn
}

locals {
  sf_conn_raw = (
    jsondecode(data.aws_secretsmanager_secret_version.snowflake_connection.secret_string)
  )

  # Try to resolve extra as either a JSON string or an object. If neither works, default to an empty object.
  sf_conn_extra = try(
    jsondecode(local.sf_conn_raw["extra"]),
    lookup(local.sf_conn_raw, "extra", {}),
    {}
  )

  sf_host      = try(local.sf_conn_raw["host"], "")
  sf_login     = try(local.sf_conn_raw["login"], "")
  sf_schema    = "ADW_UNIFIED_PLATFORM_TACTICAL"  # hard-coded for now; could be made configurable if needed
  sf_warehouse = try(local.sf_conn_extra["warehouse"], "")
  sf_database  = try(local.sf_conn_extra["database"], "")
  sf_role      = try(local.sf_conn_extra["role"], "")
  sf_pk_arn    = try(local.sf_conn_extra["private_key_arn"], "")
}

