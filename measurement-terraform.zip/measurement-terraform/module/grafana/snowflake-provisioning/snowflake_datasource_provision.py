#!/usr/bin/env python3
import base64
import grp
import json
import os
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import boto3
from botocore.exceptions import BotoCoreError, ClientError


# Manage snowflake data source in Grafana by adding YAML configuration files in the provisioning/datasources directory.
DATASOURCE_PATH = Path("/etc/grafana/provisioning/datasources/snowflake.yaml")
# Call the admin API to reload the provisioning files after writing the new datasource YAML.
GRAFANA_DATASOURCE_RELOAD_URL = "http://localhost:3000/api/admin/provisioning/datasources/reload"
GRAFANA_RELOAD_TIMEOUT_SECONDS = 10
GRAFANA_RELOAD_RETRY_DELAY_SECONDS = 2
GRAFANA_RELOAD_MAX_ATTEMPTS = 5

# We don't control this key, so allow multiple lookup keys for the private key value in case of change.
PRIVATE_KEY_FIELDS = ("privateKey", "private_key", "private_key_content", "value")

# The dev database is not stored in a secret, so it is temporarily hardcoded here.
DEVELOPMENT_DATABASE = "UNIFIED_PLATFORM_DEV"

GRAFANA_SECRET_ID= "grafana/service_secrets"


@dataclass(frozen=True)
class ProvisioningConfig:
    """
    Format Snowflake and AWS settings supplied by the launch-template user data into
    an easy format for provisioning the Grafana datasource YAML.
    """

    region: str
    account: str
    login: str
    warehouse: str
    database: str
    schema: str
    role: str
    private_key_arn: str
    private_key_role_arn: str
    grafana_admin_user: str
    environment: str

    @classmethod
    def from_environment(cls, environment: Mapping[str, str]) -> "ProvisioningConfig":
        """Build configuration from the required Snowflake and Grafana provisioner variables."""
        variables = {
            "region": "SNOWFLAKE_PROVISION_REGION",
            "account": "SNOWFLAKE_PROVISION_ACCOUNT",
            "login": "SNOWFLAKE_PROVISION_LOGIN",
            "warehouse": "SNOWFLAKE_PROVISION_WAREHOUSE",
            "database": "SNOWFLAKE_PROVISION_DATABASE",
            "schema": "SNOWFLAKE_PROVISION_SCHEMA",
            "role": "SNOWFLAKE_PROVISION_ROLE",
            "private_key_arn": "SNOWFLAKE_PROVISION_PK_ARN",
            "private_key_role_arn": "SNOWFLAKE_PROVISION_PK_ROLE_ARN",
            "grafana_admin_user": "GRAFANA_PROVISION_ADMIN_USER",
            "environment": "SNOWFLAKE_PROVISION_ENVIRONMENT",
        }
        values = {field: environment.get(name, "").strip() for field, name in variables.items()}
        missing = [name for field, name in variables.items() if not values[field]]
        if missing:
            raise RuntimeError(f"Missing required environment variables: {', '.join(missing)}")
        return cls(**values)


def get_default_admin_password(secret_id: str, config: ProvisioningConfig) -> str:
    """
    Retrieve the default admin password field from an AWS Secrets Manager secret.
    Needed to refresh the Grafana datasource.

    Our secret is expected to be a JSON object such as:
    {
        "default_admin_password": "super-secret-password-for-owls"
    }

    Args:
        secret_id: The name or ARN of the AWS Secrets Manager secret. The secret
            must contain a JSON object with a string field named 'default_admin_password'

        config: The ProvisioningConfig object containing the AWS region and other settings.

    Returns:
        The value of the ``default_admin_password`` field.

    Raises:
        RuntimeError: If the secret cannot be retrieved, is not valid JSON,
            or does not contain a string field named ``default_admin_password``.
    """
    if not secret_id.strip():
        raise RuntimeError("Secret id must not be empty.")

    # boto3 automatically creates a default session for us.
    # Since we're running on an EC2 instance, the default session will use the instance's IAM role credentials.a
    client = boto3.client(
        "secretsmanager",
        region_name=config.region,
    )

    try:
        # Retrieve the secret value from AWS Secrets Manager.
        secret_value = client.get_secret_value(SecretId=secret_id)
    except Exception as error:
        raise RuntimeError(
            f"Unable to retrieve secret '{secret_id}' from AWS Secrets Manager."
        ) from error

    # Secrets stored as text are returned in the SecretString field.
    secret_string = secret_value.get("SecretString")
    if not isinstance(secret_string, str):
        raise RuntimeError(
            f"Secret '{secret_id}' did not contain a SecretString payload."
        )

    try:
        secret = json.loads(secret_string)
    except json.JSONDecodeError as error:
        raise RuntimeError(
            f"Secret '{secret_id}' does not contain valid JSON."
        ) from error

    if not isinstance(secret, dict):
        raise RuntimeError(
            f"Secret '{secret_id}' must contain a JSON object."
        )

    # Extract the specific field we need.
    password = secret.get("default_admin_password")
    if not isinstance(password, str):
        raise RuntimeError(
            f"Secret '{secret_id}' does not contain a string field 'default_admin_password'."
        )

    return password


def private_key_secret_session(config: ProvisioningConfig) -> boto3.session.Session:
    """Assume the key-access role (rhubarb) and return a session limited to secret retrieval."""

    try:
        sts_client = boto3.client("sts", region_name=config.region)
        assumed_role =  sts_client.assume_role(
            RoleArn=config.private_key_role_arn,
            RoleSessionName="MeasurementGrafanaSnowflakeSetup",
        )
        credentials = assumed_role["Credentials"]

        return boto3.session.Session(
            aws_access_key_id=credentials["AccessKeyId"],
            aws_secret_access_key=credentials["SecretAccessKey"],
            aws_session_token=credentials["SessionToken"],
            region_name=config.region,
        )
    except (BotoCoreError, ClientError, KeyError, TypeError) as error:
        raise RuntimeError("Unable to assume the Snowflake private-key access role.") from error


def load_private_key(config: ProvisioningConfig) -> str:
    """Assume the key-access role and return the base64-encoded PEM secret value."""
    print("[snowflake_datasource_provision] Assuming role to read private key secret...")
    try:
        session = private_key_secret_session(config)
        client = session.client(
            "secretsmanager",
            region_name=config.region
        )
        secret_value = client.get_secret_value(SecretId=config.private_key_arn)
        secret_json = secret_value["SecretString"]

    except (BotoCoreError, ClientError, KeyError, TypeError) as error:
        raise RuntimeError("Unable to retrieve the Snowflake private key secret.") from error

    try:
        secret = json.loads(secret_json)
    except json.JSONDecodeError as error:
        raise RuntimeError("Snowflake private key secret must contain a JSON object.") from error

    for field in PRIVATE_KEY_FIELDS:
        value = secret.get(field) if isinstance(secret, dict) else None
        if isinstance(value, str) and value.strip():
            return value.strip()

    raise RuntimeError(f"Snowflake private key secret is missing one of: {', '.join(PRIVATE_KEY_FIELDS)}.")


def grafana_private_key(encoded_pem: str) -> str:
    """Convert base64-encoded PEM to the URL-safe base64 DER expected by Grafana."""
    try:
        # Decode the base64-encoded PEM string to a UTF-8 string.
        pem = base64.b64decode("".join(encoded_pem.split()), validate=True).decode("utf-8")

        # Remove BEGIN PRIVATE KEY and END PRIVATE KEY marker lines.
        # Decode PEM body to DER bytes for Grafana.
        der = base64.b64decode(
            "".join(line.strip() for line in pem.splitlines() if "-----" not in line),
            validate=True,
        )
    except (UnicodeDecodeError, ValueError) as error:
        raise RuntimeError("Snowflake private key is not a valid base64-encoded PEM.") from error
    if not der:
        raise RuntimeError("Snowflake private key PEM does not contain key data.")

    # Return as URL-safe base64-encoded DER, since gosnowflake's DSN parser calls base64.URLEncoding.DecodeString(privateKey),
    return base64.urlsafe_b64encode(der).decode("ascii")


def yaml_value(value: str) -> str:
    """Return a JSON string, which is also safely quoted YAML."""
    return json.dumps(value)


def datasource_yaml(config: ProvisioningConfig, private_key: str) -> str:
    """Build production and development Grafana datasource YAML without logging secrets."""
    settings = {
        "account": config.account,
        "username": config.login,
        "warehouse": config.warehouse,
        "schema": config.schema,
        "role": config.role,
    }

    def datasource(name: str, database: str) -> str:
        datasource_settings = {**settings, "database": database}
        json_data = "".join(
            f"      {key}: {yaml_value(value)}\n" for key, value in datasource_settings.items()
        )
        return (
            f"  - name: {name}\n"
            "    type: michelin-snowflake-datasource\n"
            f"    uid: {name}\n"
            "    orgId: 1\n"
            "    isDefault: false\n"
            "    editable: false\n"
            "    jsonData:\n"
            f"{json_data}"
            "      authenticationType: keypair\n"
            "    secureJsonData:\n"
            f"      privateKey: {yaml_value(private_key)}\n"
        )

    name = f'{config.environment}-snowflake-{str(config.role).lower()}'

    if config.environment.lower() != 'prod':
        return (
            "apiVersion: 1\n"
            "datasources:\n"
            f"{datasource(name, DEVELOPMENT_DATABASE)}"
        )
    else:
        return (
            "apiVersion: 1\n"
            "datasources:\n"
            f"{datasource(name, config.database)}"
        )


def write_datasource_file(content: str, target: Path = DATASOURCE_PATH) -> None:
    """Atomically write a root-owned, Grafana-group-readable datasource file."""
    try:
        grafana_gid = grp.getgrnam("grafana").gr_gid
    except KeyError as error:
        raise RuntimeError("The grafana group does not exist.") from error

    target.parent.mkdir(parents=True, exist_ok=True)
    temporary_path: Optional[Path] = None

    try:
        # Create a unique temporary file in the same directory as the target file to ensure atomic replacement.
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=target.parent, prefix=f".{target.name}.", delete=False
        ) as temporary_file:
            temporary_file.write(content)
            temporary_path = Path(temporary_file.name)
        if temporary_path is None:
            raise RuntimeError("Unable to create a temporary datasource file.")

        # Handles file permissions, giving the group read access
        os.chmod(temporary_path, 0o640)
        # Assign it to the Grafana group, which has read access on this file
        os.chown(temporary_path, 0, grafana_gid)
        # Replace the current file with the completed new yaml file
        os.replace(temporary_path, target)
    finally:
        # If the temporary path exists delete it
        if temporary_path and os.path.exists(temporary_path):
            os.remove(temporary_path)


def remove_datasource_file(target: Path = DATASOURCE_PATH) -> None:
    """Delete the datasource provisioning file after Grafana has loaded it."""
    try:
        target.unlink()
        print("[snowflake_datasource_provision] Provisioning file removed successfully.")
    except FileNotFoundError:
        pass
    except OSError as error:
        raise RuntimeError(f"Failed to remove provisioning file: {target}") from error


def reload_grafana_datasources(config: ProvisioningConfig) -> None:
    """Ask the running Grafana server to reread datasource provisioning files."""
    # Lookup sensitive password data directly from AWS Secrets Manager, since we don't want to store it in the environment or in a file.
    grafana_admin_password = get_default_admin_password(GRAFANA_SECRET_ID, config)

    credentials = base64.b64encode(
        f"{config.grafana_admin_user}:{grafana_admin_password}".encode("utf-8")
    ).decode("ascii")

    # Basic authentication header for Grafana admin user, it's enabled by default in the grafana.ini config
    request = Request(
        GRAFANA_DATASOURCE_RELOAD_URL,
        headers={"Authorization": f"Basic {credentials}"},
        method="POST",
    )

    for attempt in range(1, GRAFANA_RELOAD_MAX_ATTEMPTS + 1):
        try:
            with urlopen(request, timeout=GRAFANA_RELOAD_TIMEOUT_SECONDS):
                print("[snowflake_datasource_provision] Grafana datasource provisioning reloaded successfully.")
                return
        except HTTPError as error:
            if error.code in (502, 503, 504) and attempt < GRAFANA_RELOAD_MAX_ATTEMPTS:
                time.sleep(GRAFANA_RELOAD_RETRY_DELAY_SECONDS)
                continue
            raise RuntimeError(
                f"Grafana datasource provisioning reload failed with HTTP status {error.code}."
            ) from error
        except (URLError, TimeoutError) as error:
            if attempt == GRAFANA_RELOAD_MAX_ATTEMPTS:
                raise RuntimeError("Grafana did not become available for datasource provisioning reload.") from error
            time.sleep(GRAFANA_RELOAD_RETRY_DELAY_SECONDS)


def provision_datasource(config: ProvisioningConfig, target: Path = DATASOURCE_PATH) -> None:
    """Fetch, transform, persist, and reload the Snowflake datasource configuration."""
    private_key = grafana_private_key(load_private_key(config))
    write_datasource_file(datasource_yaml(config, private_key), target)
    print("[snowflake_datasource_provision] Provisioning file written successfully.")
    reload_grafana_datasources(config)
    remove_datasource_file(target)


def main() -> None:
    """Run provisioning using the environment injected by Terraform user data."""
    provision_datasource(ProvisioningConfig.from_environment(os.environ))


if __name__ == "__main__":
    main()

