output "grafana_ec2_instance_profile" {
  value = aws_iam_instance_profile.grafana_instance_profile.name
}

output "grafana_root_url" {
  value = var.grafana_root_url
}

output "grafana_security_group_id" {
  value = aws_security_group.grafana_instance_security_group.id
}

output "target_group_arn" {
  value = aws_lb_target_group.grafana_target_group.arn
}

output "grafana_load_balancer_security_group" {
  value = aws_security_group.grafana_public_alb_security_group.id
}

output "grafana_config" {
  value = aws_s3_object.grafana_config.key
}

output "grafana_rds_endpoint" {
  value = aws_db_instance.grafana_rds_instance.endpoint
}
