module "s3-grafana-artifacts" {
  source = "../../module/s3"

  bucket_name        = "measurement-${var.env}-grafana-artifacts"
  dev_account_number = var.dev_account_number
  env                = var.env
  tags               = var.tags
  versioning         = "Suspended"
}

locals {
  grafana_ini_rendered = base64encode(templatefile(
    "${path.module}/grafana.ini",
    {
      hostname                        = "measurement_grafana"
      auth_url                        = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["OAuth_authorisation_endpoint"]
      token_url                       = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["OAuth_token_endpoint"]
      client_id                       = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["OAuth_client_id"]
      client_secret                   = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["OAuth_client_secret"]
      allowed_organizations_tenant_id = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["allowed_organizations_tenant_id"]
      root_url                        = var.grafana_root_url
      default_admin_password          = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["default_admin_password"]
      db_user                         = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["db_user"]
      db_password                     = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["db_password"]
      db_name                         = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["db_name"]
      grafana_rds_endpoint            = aws_db_instance.grafana_rds_instance.endpoint
    }
  ))
  snowflake_datasource_environment_rendered = templatefile(
    "${path.module}/snowflake-provisioning/snowflake-datasource-provision.env.tftpl",
    {
      region               = var.region
      account              = local.sf_host
      login                = local.sf_login
      warehouse            = local.sf_warehouse
      database             = local.sf_database
      schema               = local.sf_schema
      role                 = local.sf_role
      private_key_arn      = local.sf_pk_arn
      private_key_role_arn = "arn:aws:iam::${var.account_number}:role/measurement-rhubarb-secret-access-role-${var.env}"
      # TODO: Replace the shared interactive server-admin account with a dedicated provisioner account.
      grafana_admin_user   = "admin"
      environment          = var.env
    }
  )
}

resource "aws_s3_object" "grafana_config" {
  acl                    = "private"
  bucket                 = module.s3-grafana-artifacts.name
  key                    = "config/grafana.ini"
  content_base64         = local.grafana_ini_rendered
  source_hash            = md5(local.grafana_ini_rendered)
  server_side_encryption = "AES256"
}

# Store the Snowflake provisioner and environment in S3 for the Grafana EC2 instance.
resource "aws_s3_object" "snowflake_datasource_provision_python" {
  acl                    = "private"
  bucket                 = module.s3-grafana-artifacts.name
  key                    = "scripts/snowflake_datasource_provision.py"
  source                 = "${path.module}/snowflake-provisioning/snowflake_datasource_provision.py"
  source_hash            = filemd5("${path.module}/snowflake-provisioning/snowflake_datasource_provision.py")
  server_side_encryption = "AES256"
}

resource "aws_s3_object" "snowflake_datasource_environment" {
  acl                    = "private"
  bucket                 = module.s3-grafana-artifacts.name
  key                    = "config/snowflake-datasource-provision.env"
  content                = local.snowflake_datasource_environment_rendered
  source_hash            = md5(local.snowflake_datasource_environment_rendered)
  server_side_encryption = "AES256"
}



