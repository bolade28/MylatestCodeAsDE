resource "aws_lb" "grafana_alb_public" {
  name               = "grafana-public-alb"
  internal           = false
  load_balancer_type = "application"
  ip_address_type    = "ipv4"
  security_groups    = [aws_security_group.grafana_public_alb_security_group.id]
  subnets            = [var.sn_pub_web_a, var.sn_pub_web_b, var.sn_pub_web_c]

  enable_deletion_protection = false

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-application_load_balancer"
  })
}

resource "aws_lb_target_group" "grafana_target_group" {
  name     = "grafana-lb-tg"
  port     = 3000
  protocol = "HTTP"
  vpc_id   = var.vpc_id

  health_check {
    path     = "/login"
    protocol = "HTTP"
  }
}

resource "aws_lb_listener" "grafana_front_end" {
  load_balancer_arn = aws_lb.grafana_alb_public.arn
  port              = "443"
  protocol          = "HTTPS"

  ssl_policy      = "ELBSecurityPolicy-2016-08"
  certificate_arn = jsondecode(data.aws_secretsmanager_secret_version.grafana_secrets.secret_string)["grafana_metrics_certificate_arn"]

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.grafana_target_group.arn

  }

}

resource "aws_security_group" "grafana_public_alb_security_group" {
  description = "Security group for Grafana Application Load Balancer"
  name        = "Grafana ALB Security Group"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-grafana-sg-public-alb"
  })

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
