resource "aws_launch_template" "grafana_instance" {
  name          = "grafana_instance"
  image_id      = var.ami_id
  instance_type = var.grafana_ec2_instance_type
  key_name      = var.ec2_key_name
  user_data = base64encode(templatefile(
    "${path.module}/user_data.sh",
    {
      # Grafana configuration provisioning
      grafana_artifacts_bucket                = module.s3-grafana-artifacts.name
      grafana_config_s3_key                   = aws_s3_object.grafana_config.key
      # Snowflake datasource provisioning
      snowflake_provision_python_s3_key       = aws_s3_object.snowflake_datasource_provision_python.key
      snowflake_provision_environment_s3_key  = aws_s3_object.snowflake_datasource_environment.key
      snowflake_provision_requirements_base64 = base64encode(file("${path.module}/snowflake-provisioning/requirements.txt"))
      snowflake_provision_service_base64      = base64encode(file("${path.module}/snowflake-provisioning/grafana-snowflake-datasource-provision.service"))
      snowflake_provision_timer_base64        = base64encode(file("${path.module}/snowflake-provisioning/grafana-snowflake-datasource-provision.timer"))
    }
  ))

  update_default_version = true

  tag_specifications {
    resource_type = "instance"
    tags          = merge(var.tags, { Name = "measurement-${var.env}-grafana-instance" })
  }

  tag_specifications {
    resource_type = "volume"
    tags          = merge(var.tags, { Name = "measurement-${var.env}-grafana-vol" })
  }

  tags = merge(var.tags, { Name = "measurement-${var.env}-grafana-lt" })


  iam_instance_profile {
    name = aws_iam_instance_profile.grafana_instance_profile.name
  }

  network_interfaces {
    security_groups = [aws_security_group.grafana_instance_security_group.id]
  }

  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 1
    instance_metadata_tags      = "enabled"
  }

}

resource "aws_autoscaling_group" "grafana_asg" {
  name                = "measurement-${var.env}-grafana_asg"
  vpc_zone_identifier = [var.sn_pvt_gen_a, var.sn_pvt_gen_b, var.sn_pvt_gen_c]
  desired_capacity    = var.metrics_instance_desired_capacity
  max_size            = var.metrics_instance_max_size
  min_size            = var.metrics_instance_min_size

  target_group_arns = [aws_lb_target_group.grafana_target_group.arn]

  launch_template {
    id      = aws_launch_template.grafana_instance.id
    version = aws_launch_template.grafana_instance.latest_version
  }

  instance_refresh {
    strategy = "Rolling"
    preferences {
      min_healthy_percentage = 50
    }
  }

  dynamic "tag" {
    for_each = merge(var.tags, {
      Name = "measurement-${var.env}-grafana"
    })

    content {
      key                 = tag.key
      value               = tag.value
      propagate_at_launch = true
    }
  }
}

resource "aws_security_group" "grafana_instance_security_group" {
  description = "Security group for Grafana EC2 instance"
  name        = "Grafana instance Security Group"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-grafana-instance-sg"
  })

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port       = 3000
    to_port         = 3000
    protocol        = "tcp"
    security_groups = [aws_security_group.grafana_public_alb_security_group.id]
  }
  ingress {
    from_port       = 22
    to_port         = 22
    protocol        = "tcp"
    security_groups = [var.bastion_security_group]
  }

}
