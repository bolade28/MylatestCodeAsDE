data "aws_iam_policy_document" "service_now_policy_document" {

  # ----  Service Now API Access for reporting changes (for prod only)  ----
  statement {
    sid = "SecretmanagerServiceNow"
    actions = [
      "secretsmanager:GetSecretValue"
    ]
    resources = [
      "arn:aws:secretsmanager:${var.region}:${var.account_number}:secret:prod-DTP---Digital-Trading-Platform-626635410130-*",
      "arn:aws:secretsmanager:${var.region}:${var.account_number}:secret:service_now_base_url-*",
    ]
    effect = "Allow"
  }
}


data "aws_iam_policy_document" "github_actions_terraform_repo_policy_document" {

  statement {
    sid = "DynamoDBLockState"
    actions = [
      "dynamodb:PutItem",
      "dynamodb:DeleteItem",
      "dynamodb:GetItem",
      "s3:ListBucket"
    ]
    resources = [
      "arn:aws:s3:::measurement-${var.env}-terraform-state",
      "arn:aws:dynamodb:eu-west-1:${var.account_number}:table/terraform-locks"
    ]
    effect = "Allow"
  }
  statement {
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject"
    ]
    resources = [
      "arn:aws:s3:::measurement-${var.env}-terraform-state/*",
    ]
    effect = "Allow"
  }
  statement {
    actions = [
      "s3:ListBucket"
    ]
    resources = [
      "arn:aws:s3:::measurement-${var.env}-terraform-state",
    ]
    effect = "Allow"
  }
  statement {
    sid = "OIDCProviderAccess"
    actions = [
      "iam:GetOpenIDConnectProvider",
      "iam:UpdateOpenIDConnectProviderThumbprint"
    ]
    resources = [
      "arn:aws:iam::${var.account_number}:oidc-provider/oidc.eks.eu-west-1.amazonaws.com/id/*"
    ]
    effect = "Allow"
  }
  # ----  Service now API key access only for prod ----
  source_policy_documents = var.env == "prod" ? [
    data.aws_iam_policy_document.service_now_policy_document.json
  ] : []
}

data "aws_iam_policy_document" "github_actions_dags_repo_policy_document" {

  # ----  data sync permission to list and execute tasks  ----
  statement {
    sid = "AllowDataSyncTaskList"
    actions = [
      "datasync:ListTasks",
      "datasync:StartTaskExecution",
      "datasync:DescribeTaskExecution"
    ]
    resources = ["arn:aws:datasync:${var.region}:${var.account_number}:*"]
    effect    = "Allow"
  }
  statement {
    sid = "EC2DescribeNetworkInterfaces"
    actions = [
      "ec2:DescribeNetworkInterfaces"
    ]
    resources = ["*"]
    effect    = "Allow"
  }
  statement {
    actions = [
      "s3:PutObject",
      "s3:DeleteObject"
    ]
    resources = [
      "arn:aws:s3:::measurement-${var.env}-dags/*",
      "arn:aws:s3:::measurement-${var.env}-airflow-artefacts/requirements/*"
    ]
    effect = "Allow"
  }
  statement {
    actions = [
      "s3:ListBucket"
    ]
    resources = [
      "arn:aws:s3:::measurement-${var.env}-dags",
      "arn:aws:s3:::measurement-${var.env}-airflow-artefacts"
    ]
    effect = "Allow"
  }
  # ----  Service now API key access only for prod ----
  source_policy_documents = var.env == "prod" ? [
    data.aws_iam_policy_document.service_now_policy_document.json
  ] : []
}

data "aws_iam_policy_document" "github_actions_pipelines_repo_policy_document" {

  statement {
    actions = [
      "s3:PutObject",
      "s3:DeleteObject"
    ]
    resources = [
      "arn:aws:s3:::measurement-${var.env}-artefacts/*"
    ]
    effect = "Allow"
  }
  statement {
    actions = [
      "s3:ListBucket"
    ]
    resources = [
      "arn:aws:s3:::measurement-${var.env}-artefacts"
    ]
    effect = "Allow"
  }

  statement {
    sid = "SSMParameterAccess"
    actions = [
      "ssm:PutParameter",
      "ssm:GetParameter"
    ]
    resources = [
      "arn:aws:ssm:${var.region}:${var.account_number}:parameter/measurement/${var.env}/pipelines/*"
    ]
    effect = "Allow"
  }

  # ----  Service now API key access only for prod ----
  source_policy_documents = var.env == "prod" ? [
    data.aws_iam_policy_document.service_now_policy_document.json
  ] : []
}

# Create a policy using the document from above
resource "aws_iam_policy" "github_actions_terraform_repo_policy" {
  name        = "measurement-${var.env}-github-actions-terraform-repo-policy"
  description = "Allow GitHub Actions to deploy to AWS"
  tags        = var.tags
  policy      = data.aws_iam_policy_document.github_actions_terraform_repo_policy_document.json
}


resource "aws_iam_policy" "github_actions_dags_repo_policy" {
  name        = "measurement-${var.env}-github-actions-dags-repo-policy"
  description = "Allow GitHub Actions to deploy to AWS"
  tags        = var.tags
  policy      = data.aws_iam_policy_document.github_actions_dags_repo_policy_document.json
}

resource "aws_iam_policy" "github_actions_pipelines_repo_policy" {
  name        = "measurement-${var.env}-github-actions-pipelines-repo-policy"
  description = "Allow GitHub Actions to deploy to AWS"
  tags        = var.tags
  policy      = data.aws_iam_policy_document.github_actions_pipelines_repo_policy_document.json
}
