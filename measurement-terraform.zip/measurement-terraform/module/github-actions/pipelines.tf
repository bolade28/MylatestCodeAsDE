data "aws_iam_policy_document" "oidc_pipelines_github_workflow_policy_document" {

  # ----  Granting Github Actions Workflows access to AWS platform in dev and prod ----
  # ----  Measurement Pipelines Repository only                                               ----

  dynamic "statement" {
    for_each = var.env == "dev" ? [1] : []
    content {

      actions = ["sts:AssumeRoleWithWebIdentity"]
      effect  = "Allow"

      principals {
        type        = "Federated"
        identifiers = ["arn:aws:iam::${var.account_number}:oidc-provider/token.actions.githubusercontent.com"]
      }
      condition {
        test     = "StringEquals"
        variable = "token.actions.githubusercontent.com:aud"
        values   = ["sts.amazonaws.com"]
      }
      condition {
        test     = "StringLike"
        variable = "token.actions.githubusercontent.com:sub"
        values   = ["repo:sainsburys-tech/measurement-pipelines:*"] # in dev any branch can deploy to dev
      }
    }
  }

  dynamic "statement" {
    for_each = var.env == "prod" ? [1] : []
    content {

      actions = ["sts:AssumeRoleWithWebIdentity"]
      effect  = "Allow"

      principals {
        type        = "Federated"
        identifiers = ["arn:aws:iam::${var.account_number}:oidc-provider/token.actions.githubusercontent.com"]
      }
      condition {
        test     = "StringEquals"
        variable = "token.actions.githubusercontent.com:aud"
        values   = ["sts.amazonaws.com"]
      }
      # In prod only main branch can deploy
      condition {
        test     = "StringEquals"
        variable = "token.actions.githubusercontent.com:sub"
        values   = ["repo:sainsburys-tech/measurement-pipelines:ref:refs/heads/main"]
      }
    }
  }
}

resource "aws_iam_role" "github_actions_pipelines_repo_role" {
  name                 = "measurement-${var.env}-github-actions-pipelines-repo-role"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"
  tags                 = var.tags
  assume_role_policy   = data.aws_iam_policy_document.oidc_pipelines_github_workflow_policy_document.json
}

resource "aws_iam_role_policy_attachment" "github_actions_pipelines_repo_policy_attachment" {
  role       = aws_iam_role.github_actions_pipelines_repo_role.name
  policy_arn = aws_iam_policy.github_actions_pipelines_repo_policy.arn
}
