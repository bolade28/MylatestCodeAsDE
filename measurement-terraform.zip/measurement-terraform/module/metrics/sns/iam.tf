
resource "aws_iam_role" "metrics_sns_role" {
  name                 = "measurement-${var.env}-metrics-sns-role"
  path                 = "/"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"
  assume_role_policy   = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "sns.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-metrics-sns-role"
  })
}

resource "aws_iam_policy" "sns_couldwatch_log_policy" {
  name        = "measurement-${var.env}-sns-cloudwatch-log-policy"
  path        = "/"
  description = "TBD"
  policy      = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents"
            ],
            "Resource": "*"
        }
    ]
}
EOF
}


resource "aws_iam_role_policy_attachment" "sns_couldwatch_log_policy" {
  role       = aws_iam_role.metrics_sns_role.name
  policy_arn = aws_iam_policy.sns_couldwatch_log_policy.arn
}

