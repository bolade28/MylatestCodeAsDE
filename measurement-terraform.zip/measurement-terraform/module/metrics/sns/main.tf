resource "aws_sns_topic" "metrics_sns" {
  name = "measurement-${var.env}-metrics-topic"
  tags = var.tags
}

resource "aws_sns_topic_subscription" "metrics_sqs_target" {
  topic_arn = aws_sns_topic.metrics_sns.arn
  protocol  = "sqs"
  endpoint  = var.metrics_sqs_arn
}
