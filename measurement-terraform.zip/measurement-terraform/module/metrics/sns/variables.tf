variable "tags" {}

variable "account_number" {}

variable "env" {}

variable "metrics_sqs_arn" {}
