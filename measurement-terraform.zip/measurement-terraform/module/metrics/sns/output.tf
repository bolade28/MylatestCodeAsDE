output "metrics_sns_arn" {
  value = aws_sns_topic.metrics_sns.arn
}
