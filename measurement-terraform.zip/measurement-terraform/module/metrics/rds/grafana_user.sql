CREATE ROLE grafana_read_only;

GRANT CONNECT ON DATABASE metrics TO grafana_read_only;

GRANT USAGE ON SCHEMA metrics TO grafana_read_only;

GRANT SELECT ON ALL TABLES IN SCHEMA metrics TO grafana_read_only;

ALTER DEFAULT PRIVILEGES IN SCHEMA metrics GRANT SELECT ON TABLES TO grafana_read_only;

CREATE USER grafana_user WITH PASSWORD 'check secrets manager';

GRANT grafana_read_only TO grafana_user;
