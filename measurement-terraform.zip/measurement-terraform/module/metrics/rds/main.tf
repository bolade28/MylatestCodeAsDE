data "aws_secretsmanager_secret_version" "metrics_rds_secrets" {
  secret_id = var.metrics_secrets_id
}

resource "aws_db_instance" "metrics_rds_instance" {
  allocated_storage           = 50
  allow_major_version_upgrade = true
  apply_immediately           = true
  backup_retention_period     = 30
  backup_window               = "04:30-05:30"
  copy_tags_to_snapshot       = true
  db_name                     = "metrics"
  db_subnet_group_name        = aws_db_subnet_group.metrics_sg.name
  delete_automated_backups    = false
  deletion_protection         = true
  engine                      = "postgres"
  final_snapshot_identifier   = "${var.db_identifier}-final-snapshot-${formatdate("YYYYMMDD-hhmmss", timestamp())}"
  identifier                  = var.db_identifier
  instance_class              = var.rds_instance_class
  maintenance_window          = "Fri:03:00-Fri:04:00"
  multi_az                    = var.env == "prod" ? true : false
  //noinspection HILUnresolvedReference
  password                    = jsondecode(data.aws_secretsmanager_secret_version.metrics_rds_secrets.secret_string)["password"]
  skip_final_snapshot         = false
  # snapshot_identifier         = data.aws_db_snapshot.latest_snapshot.id
  storage_type                = "gp2"
  //noinspection HILUnresolvedReference
  username                    = jsondecode(data.aws_secretsmanager_secret_version.metrics_rds_secrets.secret_string)["username"]
  vpc_security_group_ids      = [aws_security_group.metrics_rds_security_group.id]

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-metrics-rds-instance"
  })

    lifecycle {
    ignore_changes = [
      snapshot_identifier,
      final_snapshot_identifier,
    ]
  }
}

# data "aws_db_snapshot" "latest_snapshot" {
#   db_instance_identifier = var.db_identifier
#   most_recent            = true
# }

resource "aws_db_subnet_group" "metrics_sg" {
  name        = "metrics_subnet_group"
  description = "Subnet Group for Metrics RDS"
  subnet_ids  = var.subnet_group

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-metrics-subnet-group"
  })
}

resource "aws_security_group" "metrics_rds_security_group" {
  description = "Security group for Metrics RDS instance"
  name        = "Metrics RDS Security Group"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-metrics-rds-sg"
  })

  egress {
    from_port   = 0
    protocol    = "-1"
    to_port     = 0
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port       = 5432
    protocol        = "tcp"
    to_port         = 5432
    security_groups = [
      var.grafana_security_group_id,
      var.bastion_security_group_id,
      var.metrics_lambda_sg,
      # var.metrics_dl_lambda_sg
    ]
  }
}
