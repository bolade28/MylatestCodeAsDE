variable "env" {}
variable "bastion_security_group_id" {}
variable "grafana_security_group_id" {}
variable "db_identifier" {}
# variable "metrics_dl_lambda_sg" {}
variable "metrics_lambda_sg" {}
variable "rds_engine_version" {}
variable "rds_instance_class" {}
variable "metrics_secrets_id" {}
variable "subnet_group" {}
variable "tags" {}
variable "vpc_id" {}
