output "rds_address" {
  value = aws_db_instance.metrics_rds_instance.address
}

output "rds_arn" {
  value = aws_db_instance.metrics_rds_instance.arn
}

output "rds_secuirty_group" {
  value = aws_security_group.metrics_rds_security_group.id
}

output "metrics_subnet" {
  value = aws_db_subnet_group.metrics_sg.name
}
