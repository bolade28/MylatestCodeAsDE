variable "account_number" {}

variable "tags" {}

variable "env" {}

variable "rds_arn" {}

variable "rds_address" {}

variable "sn_pvt_gen_a" {}

variable "sn_pvt_gen_b" {}

variable "sn_pvt_gen_c" {}

variable "vpc_id" {}

variable "metrics_sqs_arn" {}

variable "metrics_secrets" {}
