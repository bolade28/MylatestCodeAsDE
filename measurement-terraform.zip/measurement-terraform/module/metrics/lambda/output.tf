output "metrics_lambda_sg" {
  value = aws_security_group.metrics_lambda_security_group.id
}

output "metrics_lambda_arn" {
  value = aws_lambda_function.metrics_lambda.arn
}
