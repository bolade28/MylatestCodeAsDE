resource "aws_ecr_repository" "metrics_ecr_repo" {
  name                 = "measurement-${var.env}-metrics"
  tags                 = var.tags
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }
}
