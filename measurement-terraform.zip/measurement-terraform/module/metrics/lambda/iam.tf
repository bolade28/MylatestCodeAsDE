data "aws_iam_policy" "aws_managed_lambda_vpc_access" {
  arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole"
}


resource "aws_iam_role" "metrics_lambda_role" {
  name                 = "measurement-${var.env}-metrics-lambda-role"
  path                 = "/"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"
  assume_role_policy   = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "lambda.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-metrics-lambda-role"
  })
}

data "aws_iam_policy_document" "metrics_lambda_policy" {
    statement {
        actions = [
        "s3:Get*",
        "s3:List*",
        "s3-object-lambda:Get*",
        "s3-object-lambda:List*"
        ]

        resources = ["*"]
    }

    statement {
        actions = [
        "sqs:ReceiveMessage",
        "sqs:DeleteMessage",
        "sqs:GetQueueAttributes",
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
        ]

        resources = [
        var.metrics_sqs_arn
        ]
    }

    statement {
        actions = [
        "s3:GetObject",
        "s3:PutObject",
        "secretsmanager:GetSecretValue"
        ]

        resources = [
        "arn:aws:s3:::measurement-dev-grafana-artifacts/*",
        var.metrics_secrets
        ]
    }
}
resource "aws_iam_policy" "metrics_lambda_policy" {
  name        = "measurement-${var.env}-metrics-lambda-policy"
  path        = "/"
  description = "TBD"
  policy      = data.aws_iam_policy_document.metrics_lambda_policy.json
}


resource "aws_iam_role_policy_attachment" "lambda_policy_attachment" {
  role       = aws_iam_role.metrics_lambda_role.name
  policy_arn = aws_iam_policy.metrics_lambda_policy.arn
}


resource "aws_iam_role_policy_attachment" "lambda-vpc-access-policy" {
  role       = aws_iam_role.metrics_lambda_role.name
  policy_arn = data.aws_iam_policy.aws_managed_lambda_vpc_access.arn

}
