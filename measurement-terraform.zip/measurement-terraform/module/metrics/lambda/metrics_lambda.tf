resource "aws_lambda_function" "metrics_lambda" {
  package_type  = "Image"
  image_uri     = "${var.account_number}.dkr.ecr.eu-west-1.amazonaws.com/measurement-${var.env}-metrics:latest"
  function_name = "measurement-${var.env}-metrics"
  role          = aws_iam_role.metrics_lambda_role.arn
  memory_size   = 512
  timeout       = 15
  environment {
    variables = {
      env          = var.env
    }
  }
  vpc_config {
    subnet_ids         = [var.sn_pvt_gen_a, var.sn_pvt_gen_b, var.sn_pvt_gen_c]
    security_group_ids = [aws_security_group.metrics_lambda_security_group.id]
  }

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-metrics-lambda"
  })

}

resource "aws_security_group" "metrics_lambda_security_group" {
  description = "Security group for metrics lambda"
  name        = "Metrics lambda Security Group"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-metrics-lambda-sg"
  })

  egress {
    from_port   = 0
    protocol    = "-1"
    to_port     = 0
    cidr_blocks = ["0.0.0.0/0"]
  }

  depends_on = [aws_iam_role_policy_attachment.lambda-vpc-access-policy]

  lifecycle {
    create_before_destroy = true
  }
}


resource "aws_lambda_event_source_mapping" "metrics_sqs_lambda_mapping" {
  event_source_arn                   = var.metrics_sqs_arn
  function_name                      = aws_lambda_function.metrics_lambda.arn
  maximum_batching_window_in_seconds = 60
}
