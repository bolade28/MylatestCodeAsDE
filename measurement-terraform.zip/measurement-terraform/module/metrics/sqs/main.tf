
resource "aws_sqs_queue" "metrics_sqs" {
  name = "measurement-${var.env}-metrics-queue"
  tags = var.tags
  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.metrics_deadletter_queue.arn
    maxReceiveCount     = 4
  })
}

resource "aws_sqs_queue" "metrics_deadletter_queue" {
  name = "measurement-${var.env}-metrics-dead-letter-queue"
  tags = var.tags
}

resource "aws_sqs_queue_policy" "metrics_sqs" {
  queue_url = aws_sqs_queue.metrics_sqs.id

  policy = <<POLICY
{
  "Version": "2012-10-17",
  "Id": "sqspolicy",
  "Statement": [
    {
      "Sid": "First",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "sqs:SendMessage",
      "Resource": "${aws_sqs_queue.metrics_sqs.arn}",
      "Condition": {
        "ArnEquals": {
          "aws:SourceArn": "${var.metrics_sns_arn}"
        }
      }
    }
  ]
}
POLICY
}

