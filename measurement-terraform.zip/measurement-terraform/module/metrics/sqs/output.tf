output "metrics_sqs_arn" {
  value = aws_sqs_queue.metrics_sqs.arn
}

output "metrics_dl_sqs_arn" {
  value = aws_sqs_queue.metrics_deadletter_queue.arn
}
