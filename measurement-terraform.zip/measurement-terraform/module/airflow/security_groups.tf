resource "aws_security_group" "airflow_rds_security_group" {
  description = "Security group for Airflow RDS instance"
  name        = "Airflow RDS Security Group"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-airflow-rds-sg"
  })

  egress {
    from_port   = 0
    protocol    = "-1"
    to_port     = 0
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port       = 5432
    protocol        = "tcp"
    to_port         = 5432
    security_groups = [aws_security_group.airflow_instance_security_group.id, var.bastion_security_group]
  }
}

resource "aws_security_group" "airflow_instance_security_group" {
  description = "Security group for Airflow EC2 instance"
  name        = "Airflow instance Security Group"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-airflow-instance"
  })

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port       = 22
    to_port         = 22
    protocol        = "tcp"
    security_groups = [var.bastion_security_group]
  }

  ingress {
    from_port = 0
    to_port   = 0
    protocol  = "-1"
    self      = true
  }

  # ingress {
  #   from_port       = 8080
  #   to_port         = 8080
  #   protocol        = "tcp"
  #   security_groups = [var.airflow_health_monitoring_sg]
  #   description     = "airflow health monitoring sg"
  # }
}