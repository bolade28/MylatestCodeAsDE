output "airflow_cloudwatch_log_group" { value = aws_cloudwatch_log_group.airflow_log_group.arn }
output "airflow_ec2_instance_profile" { value = aws_iam_instance_profile.airflow_instance_profile.name }
output "airflow_efs_dns_name" { value = aws_efs_file_system.airflow_efs.dns_name }
output "airflow_efs_mount_target_arn" { value = aws_efs_mount_target.airflow_efs_mount_target.file_system_arn }
output "airflow_instance_address" { value = aws_instance.airflow_instance.private_dns }
output "airflow_instance_security_group_arn" { value = aws_security_group.airflow_instance_security_group.arn }
output "airflow_instance_security_group_id" { value = aws_security_group.airflow_instance_security_group.id }
output "airflow_instance_subnet_id" { value = aws_instance.airflow_instance.subnet_id }
output "datasync_task_role_arn" { value = aws_iam_role.datasync_copy_dags_task_role.arn }
output "airflow_instance_role_name" { value = aws_iam_role.airflow_instance_role.name }
output "airflow_instance_role_arn" { value = aws_iam_role.airflow_instance_role.arn }
output "airflow_iam_policy_document" {
  value = aws_iam_policy.airflow_instance_policy.arn
}
