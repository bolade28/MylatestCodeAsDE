data "aws_s3_object" "airflow_requirements" {
  depends_on           = [module.s3-airflow-artefacts.aws_s3_bucket]
  bucket = "measurement-${var.env}-airflow-artefacts"
  key    = "requirements/latest/requirements.txt"
}

resource "aws_instance" "airflow_instance" {
  ami                  = var.ami_id
  iam_instance_profile = aws_iam_instance_profile.airflow_instance_profile.name
  instance_type        = var.airflow_instance_type
  key_name             = var.ec2_key_name
  user_data_base64     = base64encode(templatefile(
    "${path.module}/user_data.sh",
    {
      airflow_artifacts_bucket    = module.s3-airflow-artefacts.name
      airflow_config_s3_key       = aws_s3_object.airflow_config.key
      airflow_home_directory      = var.airflow_home_directory
      airflow_instance_user_gid   = var.airflow_instance_user_gid
      airflow_instance_user_group = var.airflow_instance_user_group
      airflow_instance_user_name  = var.airflow_instance_user_name
      airflow_instance_user_uid   = var.airflow_instance_user_uid
      airflow_requirements_key    = data.aws_s3_object.airflow_requirements.key
      db_endpoint                 = aws_db_instance.airflow_rds_instance.endpoint
      airflow_jwt_secret_key      = random_password.airflow_jwt_secret_key.result
      db_name                     = var.airflow_db_name
      db_pass                     = jsondecode(data.aws_secretsmanager_secret_version.airflow_rds_secrets.secret_string)["password"]
      db_user                     = var.rds_username
      efs_access_point_id         = aws_efs_access_point.airflow_efs_access_point.id
      # efs_dns                     = aws_efs_mount_target.airflow_efs_mount_target.dns_name
      efs_id                      = aws_efs_file_system.airflow_efs.id
      env                         = var.env
      airflow_platform            = var.airflow_platform
      github_deploy_key           = data.aws_secretsmanager_secret_version.github_repo_js_snowflake_providers_deploy_key.arn
      slack_token                 = jsondecode(data.aws_secretsmanager_secret_version.slack_api_key.secret_string)["botAuthTokenValue"]
      snowflake_extra             = jsondecode(data.aws_secretsmanager_secret_version.snowflake_secrets.secret_string)["extra"]
      snowflake_host              = jsondecode(data.aws_secretsmanager_secret_version.snowflake_secrets.secret_string)["host"]
      snowflake_login             = var.snowflake_user
    }
  ))
  vpc_security_group_ids = [aws_security_group.airflow_instance_security_group.id]
  subnet_id              = var.ec2_subnet_id

  user_data_replace_on_change = true

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-airflow"
  })

  metadata_options {
    http_tokens                 = "required"
    http_put_response_hop_limit = "2"
    http_endpoint               = "enabled"
  }

  root_block_device {
    volume_size = 100
    tags = merge(var.tags, {
      Name = "measurement-${var.env}-airflow-volume"
    })
  }

}
