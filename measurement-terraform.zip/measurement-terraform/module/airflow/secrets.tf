# The resources for these secrets are defined in shared_secrets module to
# avoid circular dependencies by multiple modules potentially using them.

data "aws_secretsmanager_secret_version" "github_repo_js_snowflake_providers_deploy_key" {
  secret_id = var.secret_js_snowflake_prov_git_repo_deploy_key_id
}

data "aws_secretsmanager_secret_version" "slack_api_key" {
  secret_id = var.secret_slack_api_key_id
}

data "aws_secretsmanager_secret_version" "snowflake_secrets" {
  secret_id = var.secret_snowflake_secrets_id
}

# New secret for airflow RDS connection details - migrate to this after importing old secret
resource "aws_secretsmanager_secret" "airflow_rds_secrets" {
  description             = "Airflow RDS metadata DB connection details"
  name                    = "airflow/rds"
  recovery_window_in_days = 30
  tags = merge(
    var.tags,
    {
      Name      = "airflow/rds"
      ManagedBy = "measurement-terraform/${path.module}"
    }
  )
}

resource "aws_secretsmanager_secret" "airflow_fernet_key" {
  description             = "Fernet key for decrypting encrypted connections in airflow DB"
  name                    = "airflow/fernet-key"
  recovery_window_in_days = 30
  tags = merge(
    var.tags,
    {
      Name      = "airflow/fernet-key"
      ManagedBy = "measurement-terraform-${path.module}"
    }
  )
}

# TODO: Point data sources to new secrets
data "aws_secretsmanager_secret_version" "airflow_rds_secrets" {
  secret_id = aws_secretsmanager_secret.airflow_rds_secrets.id
}

data "aws_secretsmanager_secret_version" "airflow_fernet_key" {
  secret_id = aws_secretsmanager_secret.airflow_fernet_key.id
}
