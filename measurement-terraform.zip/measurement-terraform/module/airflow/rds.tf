resource "aws_db_instance" "airflow_rds_instance" {
  allocated_storage           = 50
  allow_major_version_upgrade = false
  apply_immediately           = true
  backup_retention_period     = 30
  backup_window               = "02:00-02:59"
  copy_tags_to_snapshot       = true
  db_name                     = var.airflow_db_name
  db_subnet_group_name        = aws_db_subnet_group.airflow_rds_subnet_group.name
  delete_automated_backups    = false
  deletion_protection         = true
  engine                      = "postgres"
  engine_version              = "17.9"
  final_snapshot_identifier   = "measurement-${var.env}-airflow-final-snapshot"
  identifier                  = "measurement-${var.env}-airflow-rds"
  instance_class              = "db.t3.medium"
  maintenance_window          = "Fri:03:00-Fri:04:00"
  multi_az                    = var.env == "prod" ? true : false
  password                    = jsondecode(data.aws_secretsmanager_secret_version.airflow_rds_secrets.secret_string)["password"]
  skip_final_snapshot         = false
  # snapshot_identifier         = var.env == "prod" ? "snapshot-for-terraform-migration-2023-07-14" : "rds:measurement-dev-airflow-rds-2025-08-05-02-05"
  storage_type                = "gp2"
  username                    = var.rds_username
  vpc_security_group_ids      = [aws_security_group.airflow_rds_security_group.id]

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-airflow-rds-instance"
  })
}

resource "aws_db_subnet_group" "airflow_rds_subnet_group" {
  name        = "measurement-${var.env}-airflow-rds-subnet-group"
  description = "Subnet Group for Airflow RDS"
  subnet_ids  = var.subnet_group

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-airflow-rds-subnet-group"
  })
}
