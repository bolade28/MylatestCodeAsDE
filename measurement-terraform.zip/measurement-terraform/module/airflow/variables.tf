variable "ab_testing_bucket_arn" { description = "The ARN of the S3 Bucket used for A/B test inputs." }
variable "account_number" {}
variable "airflow_db_name" {}
# variable "airflow_health_monitoring_sg" { description = "Security group for airflow health monitoring lambda" }
variable "airflow_home_directory" { default = "/home/airflow" }
variable "airflow_instance_type" {}
variable "airflow_instance_user_gid" { default = "1001" }
variable "airflow_instance_user_group" { default = "airflow" }
variable "airflow_instance_user_name" { default = "airflow" }
variable "airflow_instance_user_uid" { default = "1001" }
variable "airflow_log_group_name" {}
variable "ami_id" {}
variable "bastion_security_group" {}
variable "dev_account_number" {}
variable "ec2_key_name" {}
variable "ec2_subnet_arn" {}
variable "ec2_subnet_id" {}
variable "env" {}
variable "etl_bucket" {}
variable "rds_username" {}
variable "secret_js_snowflake_prov_git_repo_deploy_key_id" {}
variable "secret_slack_api_key_id" {}
variable "secret_snowflake_secrets_id" {}
variable "snowflake_unload_bucket" { description = "The ARN of the S3 Bucket used for Snowflake unloading" }
variable "snowflake_user" {}
variable "subnet_group" {}
variable "tags" {}
variable "vpc_id" {}
variable "airflow_ssm_kms_key_arn" {}
variable "region" {}
variable "airflow_platform" { default = "ec2" }
