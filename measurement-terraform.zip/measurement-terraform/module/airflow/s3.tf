module "s3-dags" {
  source = "../../module/s3"

  bucket_name        = "measurement-${var.env}-dags"
  dev_account_number = var.dev_account_number
  env                = var.env
  tags               = var.tags
  versioning         = "Suspended"
}

module "s3-airflow-logs" {
  source = "../../module/s3"

  bucket_name               = "measurement-${var.env}-airflow-logs"
  dev_account_number        = var.dev_account_number
  env                       = var.env
  lifecycle_expiration      = "Enabled"
  lifecycle_expiration_days = 730
  tags                      = var.tags
  versioning                = "Suspended"
}

module "s3-airflow-artefacts" {
  source = "../../module/s3"

  bucket_name        = "measurement-${var.env}-airflow-artefacts"
  dev_account_number = var.dev_account_number
  env                = var.env
  tags               = var.tags
  versioning         = "Suspended"
}


resource "random_password" "airflow_webserver_secret_key" {
  length           = 24
  special          = true
  override_special = "-_=+*!$"
}

resource "random_password" "airflow_jwt_secret_key" {
  length           = 24
  special          = true
  override_special = "-_=+*!$"
}


locals {
  airflow_config_rendered = base64encode(templatefile(
    "${path.module}/airflow.cfg",
    {
      airflow_logs_bucket          = module.s3-airflow-logs.name
      airflow_jwt_secret_key       = random_password.airflow_jwt_secret_key.result
      airflow_webserver_secret_key = random_password.airflow_webserver_secret_key.result
      airflow_instance_name        = "measurement-${var.env}-aws"
      airflow_theme_hue = var.env == "prod" ? 27 : 260
    }
  ))
}

resource "aws_s3_object" "airflow_config" {
  acl                    = "private"
  bucket                 = module.s3-airflow-artefacts.name
  key                    = "config/airflow.cfg"
  content_base64         = local.airflow_config_rendered
  source_hash            = md5(local.airflow_config_rendered)
  server_side_encryption = "AES256"
}
