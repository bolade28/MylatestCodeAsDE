#
#
#    ----    Airflow Instance    ----
#
#

# Allow role to be assumed by ec2 instance profiles
data "aws_iam_policy_document" "airflow_instance_assume_role_policy" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      identifiers = ["ec2.amazonaws.com"]
      type        = "Service"
    }
    effect = "Allow"
  }
}

# Create the role
resource "aws_iam_role" "airflow_instance_role" {
  name                 = "measurement-${var.env}-airflow-instance-role"
  path                 = "/"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"
  assume_role_policy   = data.aws_iam_policy_document.airflow_instance_assume_role_policy.json

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-airflow-role"
  })

  provisioner "local-exec" {
    # This sleep is because when we create a role and immediately add it into
    # the trust policy of a resource (EFS) it can fail due to eventual consistency.
    # see https://docs.aws.amazon.com/IAM/latest/UserGuide/troubleshoot_general.html#troubleshoot_general_eventual-consistency
    command = "sleep 10s"
  }
}

# Create the IAM document that defines the actions the Airflow instance can take
data "aws_iam_policy_document" "airflow_ec2_instance_policy_document" {

  #
  # ----    CloudWatch    ----
  #
  statement {
    actions = [
      "logs:GetLogEvents",
      "logs:DescribeLogStreams"
    ]
    resources = [
      aws_cloudwatch_log_group.airflow_log_group.arn,
      "arn:aws:logs:eu-west-1:${var.account_number}:log-group:/aws/sagemaker/TrainingJobs:*"
    ]
    effect = "Allow"
  }

  #
  # ----    EMR    ----
  #
  statement {
    # When Airflow creates a cluster it is allowed to assign this role to the cluster
    actions = ["iam:PassRole"]
    resources = [
      "arn:aws:iam::${var.account_number}:role/EMR_EC2_DefaultRole",
      "arn:aws:iam::${var.account_number}:role/EMR_DefaultRole"
    ]
    effect = "Allow"
  }

# --- SSM permissions ---
  statement {
    actions = [
        "ssm:GetDocument",
        "ssm:DescribeDocument",
        "ssm:GetManifest",
        "ssm:ListInstanceAssociations",
        "ssm:PutInventory",
        "ssm:PutComplianceItems",
        "ssm:PutConfigurePackageResult",
        "ssm:UpdateInstanceAssociationStatus",
        "ssm:UpdateInstanceInformation",
        "ssmmessages:CreateControlChannel",
        "ssmmessages:CreateDataChannel",
        "ssmmessages:OpenControlChannel",
        "ssmmessages:OpenDataChannel",
        "ssm:ExecuteAPI",
        "ssm:GetExecutionPreview",
        "ssm:StartExecutionPreview",
    ]
    resources = ["*"]
    effect    = "Allow"
  }


  statement {
    actions = [
      "elasticmapreduce:AddJobFlowSteps",
      "elasticmapreduce:AddTags",
      "elasticmapreduce:CancelSteps",
      "elasticmapreduce:DescribeCluster",
      "elasticmapreduce:DescribeJobFlows",
      "elasticmapreduce:DescribeStep",
      "elasticmapreduce:ModifyCluster",
      "elasticmapreduce:RunJobFlow",
      "elasticmapreduce:TerminateJobFlows",
      "elasticmapreduce:ListClusters"
    ]
    resources = ["*"]
    effect    = "Allow"
  }

  #
  # ----    S3    ----
  #
  # Actions required for reading and writing files to s3 bucket
  statement {
    actions = [
      "s3:ListBucket",
      "s3:PutObject",
      "s3:PutObjectAcl",
      "s3:PutObjectTagging",
      "s3:GetObjectTagging",
      "s3:GetObjectVersion",
      "s3:GetObjectVersionTagging"
    ]
    resources = [
      var.etl_bucket,
      "${var.etl_bucket}/*",
    ]
    effect = "Allow"
  }
  statement {
    actions = [
      "s3:ListBucket",
      "s3:GetObject"
    ]
    resources = [
      "${module.s3-airflow-artefacts.arn}/*",
      "${module.s3-airflow-logs.arn}/*",
      "${module.s3-dags.arn}/*",
      "${var.ab_testing_bucket_arn}/*",
      "${var.etl_bucket}/*",
      "${var.snowflake_unload_bucket}/*",
      "arn:aws:s3:::measurement-${var.env}-temp/*",
      "arn:aws:s3:::measurement-${var.env}-temp",
      "arn:aws:s3:::measurement-${var.env}-artefacts",
      "arn:aws:s3:::measurement-${var.env}-artefacts/*",
      module.s3-airflow-artefacts.arn,
      module.s3-airflow-logs.arn,
      module.s3-dags.arn,
      var.ab_testing_bucket_arn,
      var.etl_bucket,
      var.snowflake_unload_bucket,
    ]
    effect = "Allow"
  }
  statement {
    actions = [
      "s3:PutObject"
    ]
    resources = [
      "${module.s3-airflow-artefacts.arn}/*",
      "${module.s3-airflow-logs.arn}/*",
      "${var.etl_bucket}/*",
      "${var.snowflake_unload_bucket}/*",
      "arn:aws:s3:::measurement-${var.env}-temp/*",
    ]
    effect = "Allow"
  }

  #
  # ----    SecretsManager    ----
  #
  statement {
    actions = ["secretsmanager:GetSecretValue"]
    resources = [
      data.aws_secretsmanager_secret_version.airflow_fernet_key.arn,
      data.aws_secretsmanager_secret_version.airflow_rds_secrets.arn,
      data.aws_secretsmanager_secret_version.github_repo_js_snowflake_providers_deploy_key.arn,
    ]
  }

    statement {
    sid = "AllowKMSKeyAccessForSSMSessions"
    actions = [
      "kms:*"
    ]
    resources = [var.airflow_ssm_kms_key_arn]
    effect    = "Allow"
  }

  statement {
    sid = "SSMParameterAccess"
    actions = [
      "ssm:GetParameter"
    ]
    resources = [
      "arn:aws:ssm:${var.region}:${var.account_number}:parameter/measurement/${var.env}/pipelines/*"
    ]
    effect = "Allow"
  }

    statement {
    sid = "SNSPublishAccess"
    actions = [
      "sns:Publish"
    ]
    resources = [
      "arn:aws:sns:${var.region}:${var.account_number}:measurement-${var.env}-metrics-topic"
    ]
    effect = "Allow"
  }

}

# Create a policy using the document from above
resource "aws_iam_policy" "airflow_instance_policy" {
  name   = "measurement-${var.env}-airflow-instance-policy"
  policy = data.aws_iam_policy_document.airflow_ec2_instance_policy_document.json
}

# Attach the instance policy to the role
resource "aws_iam_role_policy_attachment" "airflow_ec2_instance_policy_attachment" {
  policy_arn = aws_iam_policy.airflow_instance_policy.arn
  role       = aws_iam_role.airflow_instance_role.name
}

# This is an AWS-managed policy attached to the instance role
resource "aws_iam_role_policy_attachment" "airflow_role_ssm_ec2_policy_attach" {
  role       = aws_iam_role.airflow_instance_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedEC2InstanceDefaultPolicy"
}

# Create an instance profile to be used by the Airflow EC2 instance which will assume the role created above
resource "aws_iam_instance_profile" "airflow_instance_profile" {
  name = "measurement-${var.env}-airflow-instance-profile"
  role = aws_iam_role.airflow_instance_role.name
}

#
#
#    ----    DataSync    ----
#
#
data "aws_iam_policy_document" "datasync_task_assume_role_policy" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      identifiers = ["datasync.amazonaws.com"]
      type        = "Service"
    }
    effect = "Allow"
  }
}

resource "aws_iam_role" "datasync_copy_dags_task_role" {
  name                 = "measurement-${var.env}-datasync-copy-dags-task-role"
  path                 = "/"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"
  assume_role_policy   = data.aws_iam_policy_document.datasync_task_assume_role_policy.json

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-datasync-copy-dags-task-role"
  })
}

data "aws_iam_policy_document" "copy_dags_datasync_task" {
  statement {
    actions = [
      "s3:AbortMultipartUpload",
      "s3:DeleteObject",
      "s3:GetBucketLocation",
      "s3:GetObject",
      "s3:GetObjectTagging",
      "s3:HeadBucket",
      "s3:ListBucket",
      "s3:ListBucketMultipartUploads",
      "s3:ListMultipartUploadParts",
      "s3:PutObject",
      "s3:PutObjectTagging",
    ]
    resources = [
      module.s3-dags.arn,
      "${module.s3-dags.arn}/*"
    ]
    effect = "Allow"
  }
}
resource "aws_iam_policy" "dags_bucket_access_policy" {
  name        = "measurement-${var.env}-dags-bucket-access-policy"
  path        = "/"
  description = "Dags data sync task access policy"
  policy      = data.aws_iam_policy_document.copy_dags_datasync_task.json
}

resource "aws_iam_role_policy_attachment" "datasync_copy_dags_task_dags_bucket_access_policy_attachment" {
  role       = aws_iam_role.datasync_copy_dags_task_role.name
  policy_arn = aws_iam_policy.dags_bucket_access_policy.arn
}

data "aws_iam_policy_document" "datasync-log-publishing-policy" {
  statement {
    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents",
      "logs:PutLogEventsBatch",
    ]

    resources = ["arn:aws:logs:*"]

    principals {
      identifiers = ["datasync.amazonaws.com"]
      type        = "Service"
    }
  }
}

resource "aws_cloudwatch_log_resource_policy" "datasync-log-publishing-policy" {
  policy_document = data.aws_iam_policy_document.datasync-log-publishing-policy.json
  policy_name     = "datasync-log-publishing-policy"
}

