resource "aws_datasync_location_s3" "datasync_copy_dags_task_source" {
  s3_bucket_arn = module.s3-dags.arn
  subdirectory  = "/latest/"

  s3_config {
    bucket_access_role_arn = aws_iam_role.datasync_copy_dags_task_role.arn
  }

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-copy-dags-task-s3-source"
  })
}

resource "aws_datasync_location_efs" "datasync_copy_dags_task_destination" {
  access_point_arn            = aws_efs_access_point.airflow_efs_access_point.arn
  efs_file_system_arn         = aws_efs_file_system.airflow_efs.arn
  in_transit_encryption       = "TLS1_2"
  subdirectory                = "/airflow/dags/"
  file_system_access_role_arn = aws_iam_role.datasync_copy_dags_task_role.arn

  ec2_config {
    security_group_arns = [aws_security_group.airflow_instance_security_group.arn]
    subnet_arn          = var.ec2_subnet_arn
  }

  tags = merge(var.tags, {
    Name = "measurement-${var.env}-copy-dags-task-efs-destination"
  })
}

resource "aws_datasync_task" "datasync_copy_dags_task" {
  name                     = "measurement-${var.env}-copy-dags-from-S3-to-EFS-task"
  source_location_arn      = aws_datasync_location_s3.datasync_copy_dags_task_source.arn
  destination_location_arn = aws_datasync_location_efs.datasync_copy_dags_task_destination.arn
  cloudwatch_log_group_arn = aws_cloudwatch_log_group.airflow_log_group.arn
  options {
    preserve_deleted_files = "REMOVE"
    verify_mode            = "NONE" # Perform data integrity checks during file transfer
    transfer_mode          = "CHANGED"
    overwrite_mode         = "ALWAYS"
    log_level              = "TRANSFER"
    gid                    = "NONE"
    uid                    = "NONE"
    mtime                  = "NONE"
    atime                  = "NONE"

  }
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-copy-dags-from-S3-to-EFS-task"
  })
}
