resource "aws_kms_key" "airflow_key" {
  description = "Key for encrypting and decrypting Airflow Cloud Watch Logs"
  policy      = <<EOT
    {
       "Version": "2012-10-17",
          "Id": "airflow-cloudwatch-key",
          "Statement": [
              {
                  "Sid": "Enable IAM User Permissions",
                  "Effect": "Allow",
                  "Principal": {
                      "AWS": "arn:aws:iam::${var.account_number}:root"
                  },
                  "Action": "kms:*",
                  "Resource": "*"
              },
              {
                  "Effect": "Allow",
                  "Principal": {
                      "Service": "logs.eu-west-1.amazonaws.com"
                  },
                  "Action": [
                      "kms:Encrypt*",
                      "kms:Decrypt*",
                      "kms:ReEncrypt*",
                      "kms:GenerateDataKey*",
                      "kms:Describe*"
                  ],
                  "Resource": "*",
                  "Condition": {
                      "ArnEquals": {
                          "kms:EncryptionContext:aws:logs:arn": "arn:aws:logs:eu-west-1:${var.account_number}:log-group:${var.airflow_log_group_name}"
                      }
                  }
              }
          ]
    }
  EOT
}

resource "aws_kms_alias" "airflow_key_alias" {
  name          = "alias/airflow_log_group"
  target_key_id = aws_kms_key.airflow_key.key_id
}

resource "aws_cloudwatch_log_group" "airflow_log_group" {

  name              = var.airflow_log_group_name
  kms_key_id        = aws_kms_key.airflow_key.arn
  retention_in_days = 30
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-airflow-cloud-watch-log-group"
  })
}

