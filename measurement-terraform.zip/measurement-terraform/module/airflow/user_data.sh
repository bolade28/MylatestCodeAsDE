#!/bin/bash -x

exec > >(tee /var/log/user-data.log | logger -t airflow-user-data -s 2>/dev/console) 2>&1

## Run the following commands as root user ##
sudo su

# retry in case ssm causing issues with rpm when installing packages at boot-time
while true; do
  yum install -y amazon-efs-utils postgresql15 python3-pip git && break;
done


: '
    ---- Mount EFS volume ----

    Mounts an elastic file store volume at /home/airflow/.
    The dags folder in the measurement-dags repo is synced to this
    EFS filesystem via a DataSync task whenever a push happens
    (on a branch) or a merge to master (in prod). This is how
    the ec2 instance has the latest version of DAGs code.

'
mkdir ${airflow_home_directory} && cd ${airflow_home_directory}
mount -t efs -o tls,iam,accesspoint=${efs_access_point_id} ${efs_id}: /home/airflow/
# auto mount the efs volume if the airflow instance is rebooted from the console
echo "${efs_id}:/ /home/airflow/ efs _netdev,tls,accesspoint=${efs_access_point_id} 0 0" >> /etc/fstab


: '
    ---- Create airflow user and group ----

    The EFS system automatically makes all files in the filesystem
    owned by a POSIX user with user gid 1001 and group gid of 1001.
    We add this group and call it airflow and a user with this gid
    also called airflow.

'
groupadd -g ${airflow_instance_user_gid} ${airflow_instance_user_group}
useradd ${airflow_instance_user_name} -u ${airflow_instance_user_uid}  -g ${airflow_instance_user_gid} -m -s /bin/bash



# Now we will use the airflow user and install dependencies into a venv
su - airflow

: '
    ---- Github SSH Key ----

    Adds an SSH key that has been set up as a read-only deploy
    key on the JSainsburysPLC/js-snowflake-provider repository.

'
aws secretsmanager get-secret-value --secret-id ${github_deploy_key} | jq --raw-output '.SecretString' > ~/.ssh/github_ed25519
chmod 0600 ~/.ssh/github_ed25519
ssh-keyscan github.com >> ~/.ssh/known_hosts
cat << EOT > ~/.ssh/config
Host github.com
    HostName github.com
    User git
    IdentityFile ~/.ssh/github_ed25519
    ForwardAgent yes
EOT

: '
    ---- Install Python 3.12 ----

    Download and install Python 3.12 for
    use by the airflow scheduler and webserver services

'
# Update packages and install dependencies
sudo dnf update -y

sudo dnf install -y python3.12

# Verify installation
python3.12 --version

: '
    ---- Create Python venv ----

    Creates a venv to install packages that will be
    used by the airflow schdeuler and webserver services

'
sudo python3.12 -m venv /opt/python3.12/venv
sudo chown -R ${airflow_instance_user_gid}:${airflow_instance_user_group} /opt/python3.12/venv
source /opt/python3.12/venv/bin/activate


: '
    ---- Setup airflow for initial setup ----

    Sets some env vars, and downloads and installs
    the latest requirements.txt from the
    s3://measurement-[env]-airflow-artifacts bucket

'
## Airflow env variables ##
export AIRFLOW_HOME=${airflow_home_directory}/airflow
export AIRFLOW_CONFIG=$AIRFLOW_HOME/airflow.cfg
export AIRFLOW_REQUIREMENTS=$AIRFLOW_HOME/requirements.txt
export AIRFLOW__CORE__FERNET_KEY=$(aws --region eu-west-1 secretsmanager get-secret-value --secret-id airflow/fernet-key --query 'SecretString' | jq -r '. | fromjson."fernet-key"')
export AIRFLOW__DATABASE__SQL_ALCHEMY_CONN="postgresql+psycopg2://${db_user}:${db_pass}@${db_endpoint}/${db_name}"
export AIRFLOW__SCHEDULER__ENABLE_HEALTH_CHECK="true"
export AIRFLOW__CORE__AUTH_MANAGER="airflow.providers.fab.auth_manager.fab_auth_manager.FabAuthManager"
export AIRFLOW__CORE__EXECUTION_API_SERVER_URL="http://localhost:8080/execution"
export AIRFLOW__API_AUTH__JWT_SECRET="${airflow_jwt_secret_key}"
export AIRFLOW_CONN_AWS_DEFAULT='{"conn_type": "aws"}'

#export PATH=$PATH:/usr/local/bin
aws s3 cp s3://${airflow_artifacts_bucket}/${airflow_config_s3_key} $AIRFLOW_CONFIG
aws s3 cp s3://${airflow_artifacts_bucket}/${airflow_requirements_key} $AIRFLOW_REQUIREMENTS
python3 -m pip install --upgrade pip
python3 -m pip install -r $AIRFLOW_REQUIREMENTS  # this is pip-compiled from the requirements.in in measurement-dags

export BUILD_HASH=$(md5sum $AIRFLOW_REQUIREMENTS | cut -c1-8)

### The DB already exists - this upgrade is needed when upgrading airflow versions
airflow db migrate

### This is the airflow user in the airflow application (as opposed to the airflow ec2 instance user).
### This user is only required to be created if the airflow DB is reset
# airflow users create -u admin -p admin -r Admin -f admin -l admin -e measurement@sainsburys.co.uk

# To solve Internal Server Errors caused by DB connections being dropped after 1hr of inactivity
# See https://airflow.apache.org/docs/apache-airflow/stable/configurations-ref.html#sql-alchemy-engine-options for more details on these settings
# this is because of Airflow 3.1.7 with 3.2.0
# AIRFLOW__DATABASE__SQL_ALCHEMY_POOL_PRE_PING="true"
# AIRFLOW__DATABASE__SQL_ALCHEMY_POOL_RECYCLE="1800"
# once this issue is fixed in the next airflow update, remove these two settings and the airflow db migrate command above, and run terraform apply again to update the instance with the new settings

## ROOT USER ##
sudo su -

: '
    ---- Define environment variables for Airflow services ----

    Creates environment file used by the system service
    definitions below for the scheduler and the webserver.
    The space between << and EOF is super important here
    for expanding value of  var AIRFLOW__CORE__FERNET_KEY
    in this HEREDOC whilst not expecting terraform to
    template it.

'

cat <<EOF > /etc/sysconfig/airflow
AIRFLOW__DATABASE__SQL_ALCHEMY_CONN="postgresql+psycopg2://${db_user}:${db_pass}@${db_endpoint}/${db_name}"
AIRFLOW_CONFIG=/home/airflow/airflow/airflow.cfg
AIRFLOW_HOME=/home/airflow/airflow
AIRFLOW__CORE__FERNET_KEY=$${AIRFLOW__CORE__FERNET_KEY}
AWS_DEFAULT_REGION="eu-west-1"
AIRFLOW_CONN_AWS_DEFAULT='{"conn_type": "aws"}'
DAGS_FOLDER=/home/airflow/airflow/dags
MEASUREMENT_ENVIRONMENT=${env}
AIRFLOW_PLATFORM=${airflow_platform}
BUILD_HASH=$${BUILD_HASH}
SCHEDULER_RUNS=10
AIRFLOW__SCHEDULER__ENABLE_HEALTH_CHECK="true"
AIRFLOW__CORE__AUTH_MANAGER="airflow.providers.fab.auth_manager.fab_auth_manager.FabAuthManager"
AIRFLOW__CORE__EXECUTION_API_SERVER_URL="http://localhost:8080/execution"
AIRFLOW__API_AUTH__JWT_SECRET="${airflow_jwt_secret_key}"
AIRFLOW__LOGGING__REMOTE_LOG_CONN_ID="aws_default"
AIRFLOW__DATABASE__SQL_ALCHEMY_POOL_PRE_PING="true"
AIRFLOW__DATABASE__SQL_ALCHEMY_POOL_RECYCLE="1800"
NO_PROXY="127.0.0.1,::1,localhost"
EOF

: '
    ---- Create airflow scheduler service ----

    Creates a systemd service for the airflow
    scheduler process. systemd is an init system
    and system manager. The scheduler service is
    started when the instance boots up or is
    rebooted.
'
cat << EOF > /etc/systemd/system/scheduler.service
[Unit]
Description=Airflow scheduler daemon
After=network.target

[Service]
EnvironmentFile=/etc/sysconfig/airflow
User=airflow
Group=airflow
Type=simple
ExecStart=/opt/python3.12/venv/bin/airflow scheduler
Restart=always
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF


: '
    ---- Create airflow api-server service ----

    Creates a systemd service for the airflow
    api-server process.

'
cat << EOF > /etc/systemd/system/airflow-apiserver.service
[Unit]
Description=Airflow API server daemon
After=network.target

[Service]
RuntimeDirectory=airflow
RuntimeDirectoryMode=0775
EnvironmentFile=/etc/sysconfig/airflow
User=airflow
Group=airflow
Type=simple
ExecStart=/opt/python3.12/venv/bin/airflow api-server
Restart=on-failure
RestartSec=5s
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

: '
    ---- Create airflow dag-processor service ----

    Creates a systemd service for the airflow
    dag-processor process.

'
cat << EOF > /etc/systemd/system/dag-processor.service
[Unit]
Description=Airflow dag-processor daemon
After=network.target

[Service]
RuntimeDirectory=airflow
RuntimeDirectoryMode=0775
EnvironmentFile=/etc/sysconfig/airflow
User=airflow
Group=airflow
Type=simple
ExecStart=/opt/python3.12/venv/bin/airflow dag-processor
Restart=on-failure
RestartSec=5s
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

: '
    ---- Create airflow triggerer service ----

    Creates a systemd service for the airflow
    triggerer process. The triggerer handles
    deferrable operators and async tasks.

'
cat << EOF > /etc/systemd/system/triggerer.service
[Unit]
Description=Airflow triggerer daemon
After=network.target

[Service]
RuntimeDirectory=airflow
RuntimeDirectoryMode=0775
EnvironmentFile=/etc/sysconfig/airflow
User=airflow
Group=airflow
Type=simple
ExecStart=/opt/python3.12/venv/bin/airflow triggerer
Restart=on-failure
RestartSec=5s
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF


mkdir -p $AIRFLOW_HOME/dags
chown -R airflow:airflow /home/airflow
echo "D /run/airflow 0755 airflow airflow" > /etc/tmpfiles.d/airflow.conf

mkdir -p $AIRFLOW_HOME/logs

###  SSH ACCESS  ###
mkdir -p /home/airflow/.ssh/
chmod 0700 /home/airflow/.ssh/
cp /home/ec2-user/.ssh/* /home/airflow/.ssh/
chown -R airflow:airflow /home/airflow/.ssh/


# export all these env variables so the initial set up of airflow works correctly
export $(grep -v '^#' /etc/sysconfig/airflow | xargs)

# add variables to airflow variable store
airflow variables set MEASUREMENT_ENVIRONMENT "${env}"
airflow variables set AIRFLOW_PLATFORM "${airflow_platform}"
airflow variables set BUILD_HASH "$BUILD_HASH"

# remove existing connections
airflow connections list -o json | jq -c .[].conn_id | xargs -L 1 airflow connections delete

# add required connections
airflow connections add \
  --conn-description "Connection to send alerts to slack" \
  --conn-password "${slack_token}" \
  --conn-type "slack" \
  slack_api_default


airflow connections add \
  --conn-description "Connection over PrivateLink between airflow and Snowflake DWH" \
  --conn-host "${snowflake_host}" \
  --conn-login "${snowflake_login}" \
  --conn-schema ADW_UNIFIED_PLATFORM_TACTICAL \
  --conn-port 443 \
  --conn-extra '${snowflake_extra}' \
  --conn-type snowflake_key_arn \
  snowflake_conn

# Remove all airflow environment variables from this shell session
unset $(grep -v '^#' /etc/sysconfig/airflow | sed -E 's/(.*)=.*/\1/' | xargs)

###  START SERVICES  ###
systemctl enable scheduler
systemctl start scheduler
systemctl enable airflow-apiserver
systemctl start airflow-apiserver
systemctl enable dag-processor
systemctl start dag-processor
systemctl enable triggerer
systemctl start triggerer
