resource "aws_efs_file_system" "airflow_efs" {
  encrypted = true
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-airflow-instance-efs"
  })
}

# Allows EFS to be mounted in the airflow instance subnet and
# only clients in the airflow instance security group can access
resource "aws_efs_mount_target" "airflow_efs_mount_target" {
  file_system_id  = aws_efs_file_system.airflow_efs.id
  subnet_id       = var.ec2_subnet_id
  security_groups = [aws_security_group.airflow_instance_security_group.id]
}

# Creates an access point on the EFS. This enforces all files to have the POSIX permissions that match
# the airflow user
resource "aws_efs_access_point" "airflow_efs_access_point" {
  file_system_id = aws_efs_file_system.airflow_efs.id
  posix_user {
    gid = var.airflow_instance_user_gid
    uid = var.airflow_instance_user_uid
  }
  root_directory {
    creation_info {
      owner_gid   = var.airflow_instance_user_uid
      owner_uid   = var.airflow_instance_user_uid
      permissions = 0755
    }
    path = var.airflow_home_directory
  }
  tags = merge(var.tags, {
    Name = "measurement-${var.env}-airflow-efs-access-point"
  })
}

# grants permission to the airflow instance and data sync copy role to use the efs access point
data "aws_iam_policy_document" "efs_policy" {
  statement {
    sid    = "AirflowInstanceAccessToEFSAccessPoint"
    effect = "Allow"

    principals {
      type = "AWS"
      identifiers = [
        aws_iam_role.airflow_instance_role.arn,
        aws_iam_role.datasync_copy_dags_task_role.arn
      ]
    }

    actions = ["elasticfilesystem:Client*"]

    resources = [aws_efs_file_system.airflow_efs.arn]

    condition {
      test     = "StringEquals"
      variable = "elasticfilesystem:AccessPointArn"
      values   = [aws_efs_access_point.airflow_efs_access_point.arn]
    }

    condition {
      test     = "Bool"
      values   = ["true"]
      variable = "aws:SecureTransport"
    }
  }
}

# Sets the policy document above as the policy enforced on the EFS file system
resource "aws_efs_file_system_policy" "policy" {
  file_system_id = aws_efs_file_system.airflow_efs.id
  policy         = data.aws_iam_policy_document.efs_policy.json
}
