data "aws_iam_policy" "lambda-execution-policy" {
  arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

data "aws_iam_policy_document" "sns-read-only-policy-document" {
  statement {
    actions = [
      "sns:GetTopicAttributes",
      "sns:List*",
    ]
    resources = [aws_sns_topic.slack_messenger_sns.arn]
  }
}

resource "aws_iam_policy" "sns-read-only-policy" {
  policy = data.aws_iam_policy_document.sns-read-only-policy-document.json
}

data "aws_iam_policy_document" "secrets-manager-read-policy-document" {
  statement {
    actions = [
      "secretsmanager:GetSecretValue",
    ]
    resources = [var.secret_slack_api_key_arn]
  }
}

resource "aws_iam_policy" "secrets-manager-read-policy" {
  policy = data.aws_iam_policy_document.secrets-manager-read-policy-document.json
}

data "aws_iam_policy_document" "slack-messenger-lambda-trust-policy" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "slack-messenger-lambda-role" {
  name                 = "measurement-${var.env}-slack-messenger-role"
  permissions_boundary = "arn:aws:iam::${var.account_number}:policy/ccoe/js-developer"
  assume_role_policy   = data.aws_iam_policy_document.slack-messenger-lambda-trust-policy.json
}

resource "aws_iam_role_policy_attachment" "sns-policy-attachment" {
  role       = aws_iam_role.slack-messenger-lambda-role.name
  policy_arn = aws_iam_policy.sns-read-only-policy.arn
}

resource "aws_iam_role_policy_attachment" "lambda-execution-policy-attachment" {
  role       = aws_iam_role.slack-messenger-lambda-role.name
  policy_arn = data.aws_iam_policy.lambda-execution-policy.arn
}

resource "aws_iam_role_policy_attachment" "secrets-manager-policy-attachment" {
  role       = aws_iam_role.slack-messenger-lambda-role.name
  policy_arn = aws_iam_policy.secrets-manager-read-policy.arn
}

resource "aws_lambda_function" "slack_messenger_lambda" {

  package_type     = "Image"
  image_uri        = "${var.account_number}.dkr.ecr.eu-west-1.amazonaws.com/measurement-${var.env}-slack-messenger:latest"
  function_name    = "measurement_${var.env}_slack_messenger"
  role             = aws_iam_role.slack-messenger-lambda-role.arn
  memory_size      = 128
  timeout          = 10
  tags             = var.tags
  environment {
    variables = {
      env              = var.env
      SLACK_SECRET_ARN = var.secret_slack_api_key_arn
    }
  }
}

resource "aws_sns_topic_subscription" "messenger_lambda_trigger" {
  topic_arn = aws_sns_topic.slack_messenger_sns.arn
  protocol  = "lambda"
  endpoint  = aws_lambda_function.slack_messenger_lambda.arn
}

resource "aws_lambda_permission" "with_sns" {
  statement_id  = "AllowExecutionFromSNS"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.slack_messenger_lambda.arn
  principal     = "sns.amazonaws.com"
  source_arn    = aws_sns_topic.slack_messenger_sns.arn
}

resource "aws_ecr_repository" "slack_ecr_repo" {
  name                 = "measurement-${var.env}-slack-messenger"
  tags                 = var.tags
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }
}

resource "aws_sns_topic" "slack_messenger_sns" {
  name         = "measurement-${var.env}-slack-messenger-topic"
  tags         = var.tags
}
