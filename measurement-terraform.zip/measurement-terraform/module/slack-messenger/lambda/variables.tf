variable "account_number" {
  description = "AWS account number"
  type        = string
}

variable "env" {
  description = "prod or dev"
  type        = string
}

variable "secret_slack_api_key_arn" {
  description = "Secret Manager ARN for Slack API Key"
  type        = string
}

# variable "sns_arn" {
#   description = "ARN of the SNS trigger topic"
#   type        = string
# }

variable "tags" {
  description = "Labels assigned to resource"
  type        = map(string)
}
