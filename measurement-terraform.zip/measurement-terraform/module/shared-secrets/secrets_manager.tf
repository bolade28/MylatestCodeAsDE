resource "aws_secretsmanager_secret" "git_repo_deploy_key_js_snowflake_provider" {
  description             = "Deploy key to allow resources to pull the js-snowflake-providers Github repository"
  name                    = "github/deploy-keys/js-snowflake-providers"
  recovery_window_in_days = 30
  tags = merge(
    var.tags,
    {
      Name      = "github/deploy-keys/js-snowflake-providers"
      ManagedBy = "terraform-${path.module}"
    }
  )
}

resource "aws_secretsmanager_secret" "slack_measurement_courier_auth_token" {
  description             = "An authorisation token used by the Measurement Courier application to send messages to Slack"
  name                    = "slack/measurement-courier-auth-token"
  recovery_window_in_days = 7
  tags = merge(
    var.tags,
    {
      Name = "slack/measurement-courier-auth-token"
      ManagedBy = "terraform-${path.module}"
    }
  )
}
resource "aws_secretsmanager_secret" "snowflake_connection" {
  description             = "Snowflake connection secrets"
  name                    = "snowflake/connection-secrets"
  recovery_window_in_days = 30
  tags = merge(
    var.tags,
    {
      Name      = "snowflake/connection-secrets"
      ManagedBy = "terraform-${path.module}"
    }
  )
}

resource "aws_secretsmanager_secret" "metrics_rds_secrets" {
  description             = "Metrics RDS secrets"
  name                    = "metrics/rds-secrets"
  recovery_window_in_days = 30
  tags = merge(
    var.tags,
    {
      Name      = "metrics/rds-secrets"
      ManagedBy = "terraform-${path.module}"
    }
  )
}

resource "aws_secretsmanager_secret" "grafana_secrets" {
  description             = "Secrets for Grafana UI and service backend (RDS, ALB)"
  name                    = "grafana/service_secrets"
  recovery_window_in_days = 30
  tags = merge(
    var.tags,
    {
      Name = "measurement-${var.env}-grafana-secrets"
      ManagedBy = "terraform-${path.module}"
    }
  )
}

resource "aws_secretsmanager_secret" "mlflow_secrets" {
  description             = "Secrets for MLflow"
  name                    = "mlflow/service_secrets"
  recovery_window_in_days = 30
  tags = merge(
    var.tags,
    {
      Name = "measurement-${var.env}-mlflow-secrets"
      ManagedBy = "terraform-${path.module}"
    }
  )
}
