output "snowflake_connection" {
  value = {
    arn  = aws_secretsmanager_secret.snowflake_connection.arn,
    id   = aws_secretsmanager_secret.snowflake_connection.id,
    name = aws_secretsmanager_secret.snowflake_connection.name,
  }
}


output "github_repo_js_snowflake_provider_deploy_key" {
  value = {
    arn = aws_secretsmanager_secret.git_repo_deploy_key_js_snowflake_provider.arn,
    id = aws_secretsmanager_secret.git_repo_deploy_key_js_snowflake_provider.id,
    name = aws_secretsmanager_secret.git_repo_deploy_key_js_snowflake_provider.name
  }
}


# There are two secrets for the change api in dev (the dev and uat service now endpoints)
# so we need to output both of them, e.g { "uat" : {"arn" : "some_arn" ...}, "dev" : {"arn" : "some_other_arn" ...} }
# When it comes to using these you can use a for_each that resolve to "prod" in prod and "uat" in dev. The DEV servicenow
# instance is not really used beyond people who actually work on this api in the service now team.
# data "aws_secretsmanager_secret_version" "service-now-change-api-key" {
#  secret_id = var.env == "prod" : var.secret_servicenow_api_secrets_id.prod.id ? var.secret_servicenow_api_secrets_id.uat.id
#}
# output "servicenow_change_request_api_key" {
#   value     = {
#     for k, key in aws_secretsmanager_secret.service_now_change_api_key : k => {
#       arn = key.arn,
#       id = key.id,
#       name = key.name
#     }
#   }
# }

output "slack_measurement_courier_auth_token" {
  value = {
    arn = aws_secretsmanager_secret.slack_measurement_courier_auth_token.arn,
    id = aws_secretsmanager_secret.slack_measurement_courier_auth_token.id,
    name = aws_secretsmanager_secret.slack_measurement_courier_auth_token.name
  }
}

output "metrics_secrets" {
  value = {
    arn = aws_secretsmanager_secret.metrics_rds_secrets.arn,
    id = aws_secretsmanager_secret.metrics_rds_secrets.id,
    name = aws_secretsmanager_secret.metrics_rds_secrets.name
  }
}

output "grafana_secrets" {
  value = {
    arn = aws_secretsmanager_secret.grafana_secrets.arn,
    id = aws_secretsmanager_secret.grafana_secrets.id,
    name = aws_secretsmanager_secret.grafana_secrets.name
  }
}

output "mlflow_secrets" {
  value = {
    arn = aws_secretsmanager_secret.mlflow_secrets.arn,
    id = aws_secretsmanager_secret.mlflow_secrets.id,
    name = aws_secretsmanager_secret.mlflow_secrets.name
  }
}
