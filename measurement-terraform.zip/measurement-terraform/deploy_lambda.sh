#!/bin/bash

set -e

APP_NAME=$1
IMAGE_TAG=$2

echo $ENV
[[ $AWS_PROFILE == 'measurement-prod' ]] && ACCOUNT="626635410130" || ACCOUNT="277707132387"

cd lambdas/$APP_NAME

# Replace underscores with dashes in APP_NAME
APP_NAME="${APP_NAME//_/-}"

# Authenticate to ECR
aws ecr get-login-password --region eu-west-1 --profile $AWS_PROFILE | \
  docker login --username AWS --password-stdin $ACCOUNT.dkr.ecr.eu-west-1.amazonaws.com

# Build and push directly - no local tagging
docker buildx build \
  --platform linux/amd64 \
  --provenance=false \
  --sbom=false \
  --push \
  -t $ACCOUNT.dkr.ecr.eu-west-1.amazonaws.com/measurement-$ENV-$APP_NAME:$IMAGE_TAG \
  .
