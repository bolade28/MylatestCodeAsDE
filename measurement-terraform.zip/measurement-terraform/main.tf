terraform {
  required_version = "= 1.11.3"
    required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "6.0.0"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region = var.region
  assume_role {
    role_arn = var.deploy_role
  }
  default_tags {
    tags = var.tags
  }
}

resource "aws_ebs_encryption_by_default" "lets_encrypt" {
  enabled = true
}


module "network" {
  source = "./module/network"
  env    = var.env
  region = var.region
  tags   = var.tags

  # Measurement Core Network
  sn_pub_web_a_cidr       = var.sn_pub_web_a_cidr
  sn_pub_web_b_cidr       = var.sn_pub_web_b_cidr
  sn_pub_web_c_cidr       = var.sn_pub_web_c_cidr
  sn_pvt_emr_a_cidr       = var.sn_pvt_emr_a_cidr
  sn_pvt_emr_b_cidr       = var.sn_pvt_emr_b_cidr
  sn_pvt_emr_c_cidr       = var.sn_pvt_emr_c_cidr
  sn_pvt_gen_a_cidr       = var.sn_pvt_gen_a_cidr
  sn_pvt_gen_b_cidr       = var.sn_pvt_gen_b_cidr
  sn_pvt_gen_c_cidr       = var.sn_pvt_gen_c_cidr
  subnet_a_az_name        = var.subnet_a_az_name
  subnet_b_az_name        = var.subnet_b_az_name
  subnet_c_az_name        = var.subnet_c_az_name
  vpc_cidr_measurement    = var.vpc_cidr_measurement

  # # Snowflake PrivateLink
  vpce_sf_service_id     = var.vpce_sf_service_id
  # commercial_cc_domain = var.commercial_cc_domain


  }

  module "github-actions" {
  source         = "./module/github-actions"
  account_number = var.account_number
  env            = var.env
  region         = var.region
  tags           = var.tags
}

module "bastion" {
  source         = "./module/bastion"
  env            = var.env
  ec2_key_name   = var.ec2_key_name
  vpc_id         = module.network.measurement_vpc
  subnet_id      = module.network.sn_pub_web_a
  tags           = var.tags
  account_number = var.account_number
  ami_id         = var.ami_bastion_instance
}

module "airflow" {
  source                                          = "./module/airflow"
  ab_testing_bucket_arn                           = module.s3-storage.ab_testing_bucket_arn
  account_number                                  = var.account_number
  airflow_db_name                                 = var.airflow_db_name
  airflow_instance_type                           = var.airflow_instance_type
  airflow_log_group_name                          = "airflow-log-group"
  ami_id                                          = var.ami_airflow_instance
  bastion_security_group                          = module.bastion.bastion_security_group_id
  dev_account_number                              = var.dev_account_number
  ec2_key_name                                    = var.ec2_key_name
  ec2_subnet_arn                                  = module.network.sn_pvt_gen_a_arn
  ec2_subnet_id                                   = module.network.sn_pvt_gen_a
  env                                             = var.env
  etl_bucket                                      = module.s3-storage.etl_output_bucket_arn
  rds_username                                    = var.rds_username
  secret_js_snowflake_prov_git_repo_deploy_key_id = module.shared-secrets.github_repo_js_snowflake_provider_deploy_key.id
  secret_slack_api_key_id                         = module.shared-secrets.slack_measurement_courier_auth_token.id
  secret_snowflake_secrets_id                     = module.shared-secrets.snowflake_connection.id
  snowflake_unload_bucket                         = module.s3-storage.snowflake_unload_s3_bucket_arn
  snowflake_user                                  = var.snowflake_user
  subnet_group                                    = module.network.measurement_general_subnet_ids
  tags                                            = var.tags
  vpc_id                                          = module.network.measurement_vpc
  airflow_ssm_kms_key_arn                         = module.ssm.ssm_kms_key_arn
  region                                          = var.region
}

module "s3-storage" {
  source                        = "./module/s3-buckets"
  env                           = var.env
  tags                          = var.tags
  dev_account_number            = var.dev_account_number
  prod_account_number           = var.prod_account_number
  lifecycle_expiration          = var.lifecycle_expiration_default
  lifecycle_expiration_extended = var.lifecycle_expiration_extended
}


module "shared-secrets" {
  source              = "./module/shared-secrets"
  account_number      = var.account_number
  env                 = var.env
  tags                = var.tags
}


module "mlflow" {
  source                       = "./module/mlflow"
  account_number               = var.account_number
  mlflow_secrets_id            = module.shared-secrets.mlflow_secrets.id
  mlflow_artifacts_bucket_name  = module.s3-storage.mlflow_artifacts_bucket.name
  mlflow_artifacts_bucket_arn   = module.s3-storage.mlflow_artifacts_bucket.arn
  subnet_group                  = [module.network.sn_pvt_gen_a, module.network.sn_pvt_gen_b]
  ami_id                        = var.ami_mlflow
  private_hosted_zone_id        = var.private_hosted_zone_id
  bastion_security_group        = module.bastion.bastion_security_group_id
  subnet_id                     = module.network.sn_pvt_gen_a
  ec2_key_name                  = var.ec2_key_name
  env                           = var.env
  tags                          = var.tags
  vpc_id                        = module.network.measurement_vpc
}


module "iam_role" {
  source                         = "./module/iam"
  account_number                 = var.account_number
  env                            = var.env
  prod_account_number            = var.prod_account_number
  region                         = var.region
  rhubarb_account_id             = var.rhubarb_account_id
  rhubarb_aws_secret_name        = var.rhubarb_aws_secret_name
  rhubarb_kms_key_alias          = var.rhubarb_kms_key_alias
  snowflake_external_id          = var.snowflake_external_id
  exp_snowflake_external_id      = var.exp_snowflake_external_id
  tags                           = var.tags
}

module "slack-messenger" {
  source                   = "./module/slack-messenger/lambda"
  account_number           = var.account_number
  env                      = var.env
  secret_slack_api_key_arn = module.shared-secrets.slack_measurement_courier_auth_token.arn
  tags                     = var.tags
}

module "metrics-rds" {
  source                    = "./module/metrics/rds"
  env                       = var.env
  bastion_security_group_id = module.bastion.bastion_security_group_id
  db_identifier             = "measurement-${var.env}-metrics"
  grafana_security_group_id = module.grafana.grafana_security_group_id
  metrics_lambda_sg         = module.metrics-lambda.metrics_lambda_sg
  rds_instance_class        = var.metrics_rds_instance_class
  rds_engine_version        = var.metrics_rds_engine_version
  metrics_secrets_id        = module.shared-secrets.metrics_secrets.id
  subnet_group              = [module.network.sn_pvt_gen_a, module.network.sn_pvt_gen_b]
  tags                      = var.tags
  vpc_id                    = module.network.measurement_vpc
}

module "grafana" {
  source                             = "./module/grafana"
  account_number                     = var.account_number
  ami_id                             = var.ami_grafana_instance
  bastion_security_group             = module.bastion.bastion_security_group_id
  dev_account_number                 = var.dev_account_number
  ec2_key_name                       = var.ec2_key_name
  env                                = var.env
  grafana_root_url                   = var.grafana_root_url
  grafana_secrets_id                 = module.shared-secrets.grafana_secrets.id
  grafana_ec2_instance_type          = var.grafana_ec2_instance_type
  grafana_rds_engine_version         = var.grafana_rds_engine_version
  grafana_rds_instance_class         = var.grafana_rds_instance_class
  metrics_instance_desired_capacity  = var.metrics_instance_desired_capacity
  metrics_instance_max_size          = var.metrics_instance_max_size
  metrics_instance_min_size          = var.metrics_instance_min_size
  region                             = var.region
  snowflake_connection_secret_arn    = module.shared-secrets.snowflake_connection.arn
  grafana_subnet_group               = [module.network.sn_pvt_gen_a, module.network.sn_pvt_gen_b]
  sn_pvt_gen_a                       = module.network.sn_pvt_gen_a
  sn_pvt_gen_b                       = module.network.sn_pvt_gen_b
  sn_pvt_gen_c                       = module.network.sn_pvt_gen_c
  sn_pub_web_a                       = module.network.sn_pub_web_a
  sn_pub_web_b                       = module.network.sn_pub_web_b
  sn_pub_web_c                       = module.network.sn_pub_web_c
  tags                               = var.tags
  vpc_id                             = module.network.measurement_vpc
}


module "metrics-lambda" {
  source             = "./module/metrics/lambda"
  account_number     = var.account_number
  env                = var.env
  tags               = var.tags
  rds_arn            = module.metrics-rds.rds_arn
  rds_address        = module.metrics-rds.rds_address
  vpc_id             = module.network.measurement_vpc
  sn_pvt_gen_a       = module.network.sn_pvt_gen_a
  sn_pvt_gen_b       = module.network.sn_pvt_gen_b
  sn_pvt_gen_c       = module.network.sn_pvt_gen_c
  metrics_sqs_arn    = module.metrics-sqs.metrics_sqs_arn
  metrics_secrets    = module.shared-secrets.metrics_secrets.arn
}

module "metrics-sns" {
  source          = "./module/metrics/sns"
  tags            = var.tags
  env             = var.env
  account_number  = var.account_number
  metrics_sqs_arn = module.metrics-sqs.metrics_sqs_arn
}

module "metrics-sqs" {
  source          = "./module/metrics/sqs"
  tags            = var.tags
  env             = var.env
  account_number  = var.account_number
  metrics_sns_arn = module.metrics-sns.metrics_sns_arn
}

module "ssm" {
  source          = "./module/ssm"
  tags            = var.tags
  env             = var.env
  account_number  = var.account_number
}
