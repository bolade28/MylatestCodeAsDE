#!/usr/bin/env bash

[[ -z $1 ]] && echo "Usage: ./metrics-db-ssh-tunnel.sh ~/path/to/ssh/key.pem" && exit
[[ -z $AWS_PROFILE ]] && echo "AWS_PROFILE not set!" && exit

SSH_KEY_LOCATION=$1

STATUS=$(aws rds describe-db-instances --db-instance-identifier $AWS_PROFILE-metrics --query 'DBInstances[0].DBInstanceStatus' | jq --raw-output '.')
[[ $STATUS == 'null' ]] && echo "RDS instance not available." && exit


RDS_ENDPOINT=$(aws rds describe-db-instances --db-instance-identifier $AWS_PROFILE-metrics | jq --raw-output '.DBInstances[0].Endpoint.Address')
RDS_PORT=$(aws rds describe-db-instances --db-instance-identifier $AWS_PROFILE-metrics | jq --raw-output '.DBInstances[0].Endpoint.Port')
BASTION_PUBLIC_DNS=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=$AWS_PROFILE-bastion" "Name=instance-state-name,Values=running" | jq --raw-output '.Reservations[0].Instances[0].PublicDnsName')

[[ $RDS_ENDPOINT == 'null' ]] && echo 'RDS endpoint not found.' && exit
[[ $BASTION_PUBLIC_DNS == 'null' ]] && echo 'Bastion not found.' && exit

MY_IP=$(curl -s ifconfig.me)

SG_ID=$(aws ec2 describe-security-groups --filters "Name=group-name,Values='Bastion Security Group'" | jq --raw-output '.SecurityGroups[0].GroupId')

[[ $SG_ID == 'null' ]] && echo "Bastion Security Group not found using profile: $AWS_PROFILE." && exit

aws ec2 authorize-security-group-ingress --group-id $SG_ID --protocol tcp --port 22 --cidr $MY_IP/32 > /dev/null 2>&1

trap "aws ec2 revoke-security-group-ingress --group-id $SG_ID --protocol tcp --port 22 --cidr $MY_IP/32 > /dev/null" SIGINT HUP INT QUIT

echo "---------------------------------------"
echo "Bastion:       ${BASTION_PUBLIC_DNS}"
echo "RDS Endpoint:  ${RDS_ENDPOINT}"
echo "My current ip: ${MY_IP}"
echo "To connect Metrics RDS Database use: localhost:5499"
echo "---------------------------------------"

ssh -o "StrictHostKeyChecking no" -i $SSH_KEY_LOCATION -NT -L 5499:$RDS_ENDPOINT:$RDS_PORT ec2-user@$BASTION_PUBLIC_DNS
