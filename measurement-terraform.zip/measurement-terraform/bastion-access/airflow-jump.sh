#!/usr/bin/env bash

[[ -z $1 ]] && echo "Usage: ./airflow-ui-port-forward.sh ~/path/to/ssh/key.pem" && exit
[[ -z $AWS_PROFILE ]] && echo "AWS_PROFILE not set!" && exit

SSH_KEY_LOCATION=$1

AIRFLOW_PRIVATE_DNS=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=$AWS_PROFILE-airflow" "Name=instance-state-name,Values=running" | jq --raw-output '.Reservations[0].Instances[0].PrivateDnsName')
BASTION_PUBLIC_DNS=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=$AWS_PROFILE-bastion" "Name=instance-state-name,Values=running" | jq --raw-output '.Reservations[0].Instances[0].PublicDnsName')

[[ $AIRFLOW_PRIVATE_DNS == 'null' ]] && echo 'Airflow not found.' && exit
[[ $BASTION_PUBLIC_DNS == 'null' ]] && echo 'Bastion not found.' && exit

MY_IP=$(curl -s -4 ifconfig.me)
echo "---------------------------------------"
echo "Bastion:       ${BASTION_PUBLIC_DNS}"
echo "Airflow:       ${AIRFLOW_PRIVATE_DNS}"
echo "My current ip: ${MY_IP}"
echo "---------------------------------------"
SG_ID=$(aws ec2 describe-security-groups --filters "Name=group-name,Values='Bastion Security Group'" | jq --raw-output '.SecurityGroups[0].GroupId')

[[ $SG_ID == 'null' ]] && echo "Bastion Security Group not found using profile: $AWS_PROFILE." && exit

aws ec2 authorize-security-group-ingress --group-id $SG_ID --protocol tcp --port 22 --cidr $MY_IP/32 > /dev/null 2>&1

trap "aws ec2 revoke-security-group-ingress --group-id $SG_ID --protocol tcp --port 22 --cidr $MY_IP/32 > /dev/null" SIGINT

ssh -o "StrictHostKeyChecking no" -A -i $SSH_KEY_LOCATION -J ec2-user@$BASTION_PUBLIC_DNS ec2-user@$AIRFLOW_PRIVATE_DNS

aws ec2 revoke-security-group-ingress --group-id $SG_ID --protocol tcp --port 22 --cidr $MY_IP/32 > /dev/null 2>&1
