# `dp-v9mj-measurement-data`

This repository contains the dbt project, configuration, and supporting operational documentation for the V9MJ Measurement Data product.

## Overview

The repository currently supports pipelines and operational guidance for:

- historic brand data
- brand data import processing
- campaign booking ID reporting
- contributor guidance for clone-based parallel working

The main dbt project is located in `dp_v9mj_measurement_data/transforms/`.

## Quick links

- [Contributing guide](CONTRIBUTING.md)
- [Booking ID approvals guide](CONTRIBUTE_BOOKING_ID_APPROVALS.md)
- [Snowflake clone creation guide (Confluence)](https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/1358201562/Snowflake+Database+Clone+-+Parallel+Working?xpis=eyJicmlkZ2UiOiJzbWFydExpbmtzIiwiaWQiOiIxNzg5NTUwODM1MDEyIiwic291cmNlIjoiY29uZmx1ZW5jZSJ9)
- [Snowflake stage runbook](migrations/snowflake-operations/STAGE_JS_BRAND_DATA_RUNBOOK.md)
- [Snowflake SIESTA upload summary runbook](migrations/snowflake-operations/JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL_RUNBOOK.md)

## Repository layout

```text
dp_v9mj_measurement_data/
├── configs/                # Pipeline configuration
├── ddl/                    # Snowflake DDL artefacts
└── transforms/             # dbt project root
	├── macros/             # Custom Jinja macros
	├── models/             # dbt models
	├── seeds/              # Seed files
	├── snapshots/          # dbt snapshots
	└── tests/              # Custom dbt tests

migrations/
└── snowflake-operations/   # Manual recovery and operational runbooks
```

## Getting started

Before making changes, make sure you have completed the GRID prerequisites and set up your local environment.

Helpful references:

- [GRID prerequisites](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/getting-started/1_pre_requisites/)
- [Connect to Snowflake](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-dbt/using-grid-dbt/3_connect_to_snowflake/)
- [GRID dbt documentation](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-dbt/about/)
- [GRID DDL documentation](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-ddl/about/)

For contributor-specific setup and standards, read [`CONTRIBUTING.md`](CONTRIBUTING.md).

## Common local workflow

The dbt project lives under `dp_v9mj_measurement_data/transforms/`, so run dbt commands from there.

```bash
cd dp_v9mj_measurement_data/transforms
dbt deps
dbt build --select your_model_name
```

For repository-wide checks:

```bash
pre-commit run --all-files
```

## Documentation and operational guides

This repository includes both contributor documentation and manual operational runbooks.

- use `CONTRIBUTING.md` for development workflow and standards
- use `migrations/snowflake-operations/` for manual Snowflake recovery procedures
- keep operational knowledge in version control where possible rather than only in tickets or chat threads

## Grid product contract

The [Grid product contract](https://data-platforms-docs.ext.prd.jspaas.uk/grid/home/product-contract/) outlines the responsibilities of Grid users and Grid support. All Grid users are expected to comply with it.

## Repository maintenance

Repository maintainers should keep the project aligned with the latest supported GRID template guidance where appropriate.

Reference:

- [Update a data product repository](https://data-platforms-docs.ext.prd.jspaas.uk/grid/grid-template/how-to-guides/update-dp-repo/)

## Further reading

The [GRID user guide](https://data-platforms-docs.ext.prd.jspaas.uk/grid) includes:

- introductions to the GRID platform and its components
- setup guidance and prerequisites
- dbt and DDL documentation
- best practices and how-to guides
- reference materials
- help and support guidance
- observability dashboards

## Contact

- **Squad:** Nectar360up
- **Email:** [gdp_nectar360up@sainsburys.co.uk](mailto:gdp_nectar360up@sainsburys.co.uk)

## License

Copyright 2026, JSainsburyPLC
