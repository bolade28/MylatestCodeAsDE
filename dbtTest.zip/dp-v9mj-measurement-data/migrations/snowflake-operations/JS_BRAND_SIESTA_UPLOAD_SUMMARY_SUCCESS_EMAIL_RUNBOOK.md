# JS Brand SIESTA upload summary success email runbook

This file is a manual reference for recreating the DEV Snowflake procedure `UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.PROC_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL` and the Snowflake task `UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL` if either object is deleted.

- Location chosen intentionally under `migrations/` as operational documentation.
- This file is **not part of dbt models, seeds, snapshots, macros, or CI/CD execution**.
- Copy and run the SQL manually in Snowflake when recovery is needed.
- Use role `RL_DEV_MADATA_ETL` when creating these objects.
- These objects are intended for the DEV implementation of the brand data import pipeline.

## Purpose

The procedure sends a success email containing a summary of the latest `STG_ITEM_BRAND_MAP` SIESTA upload and compares that upload with the previous distinct upload found in the historical SIESTA stage table. If the procedure itself fails, it attempts to send a failure notification before re-raising the original error.

The task is a wrapper around the procedure so the dbt custom task macro can trigger it with:

```sql
EXECUTE TASK ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL;
```

## Why this exists only in DEV

This procedure/task is intentionally DEV-only at the moment for the following reasons:

1. The dbt macro `dp_v9mj_measurement_data/transforms/macros/brand_data_import_success_email.sql` explicitly runs only in `dev`.
2. The same macro contains a comment stating that these procedures/tasks currently need to be owned/executed under the ETL roles, and that work with the Snowflake Admin team is still needed before enabling them in preproduction and production.
3. The current procedure body is hard-coded to DEV objects:
   - `UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.STG_ITEM_BRAND_MAP`
   - `ADW_DEV.ADW_STAGE.SIESTA_PRODUCT_ITMBRD_ITEMBRANDMAP_STAGE`
4. The success and failure email content explicitly states that the process completed or failed in `DEV`.
5. This repository currently contains the brand data import pipeline configuration under `dp_v9mj_measurement_data/configs/dv/`, with no equivalent preprod/prod config for this custom task.

If this process is ever promoted beyond DEV, the role grants, object references, environment-specific email wording, and deployment config should all be reviewed first.

## Recommended `run_after` value

Use the following in `dp_v9mj_measurement_data/configs/dv/dp_v9mj_measurement_data_brand_data_import.yaml`:

```yaml
custom_tasks:
  brand_data_import_success_email:
    macro: BRAND_DATA_IMPORT_SUCCESS_EMAIL
    run_after:
      - STG_ITEM_BRAND_MAP
```

`STG_ITEM_BRAND_MAP` is the correct dependency because the procedure reads the latest contents of `UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.STG_ITEM_BRAND_MAP` and should run only after that model has finished successfully.

## Prerequisites

Before running the recovery SQL, confirm the following:

1. You can use role `RL_DEV_MADATA_ETL` in Snowflake.
2. `UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.STG_ITEM_BRAND_MAP` exists and is populated by the DEV brand data import pipeline.
3. `ADW_DEV.ADW_STAGE.SIESTA_PRODUCT_ITMBRD_ITEMBRANDMAP_STAGE` exists and contains historical SIESTA uploads.
4. `snowflake_administration.stored_procedures.send_generic_email_notification_v1_0` exists and the role can call it.
5. Warehouse `WHS_MADATA_MEDIUM` is available.
6. The task, if recreated, is resumed after validation.

## DEV recreation steps

Use the following SQL in Snowflake when the procedure or task needs to be recreated.

```sql
USE ROLE RL_DEV_MADATA_ETL;
USE DATABASE UNIFIED_PLATFORM_DEV;
USE SCHEMA ADW_UNIFIED_PLATFORM_TACTICAL;
USE WAREHOUSE WHS_MADATA_MEDIUM;

-- Optional: suspend the task before replacing either object.
ALTER TASK IF EXISTS UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL SUSPEND;

CREATE OR REPLACE PROCEDURE UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.PROC_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL()
RETURNS VARCHAR
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'main'
COMMENT='Sends a success email containing the latest SIESTA STG_ITEM_BRAND_MAP upload summary and compares it with the previous SIESTA upload from the historical stage table. Sends a failure notification if the procedure fails.'
EXECUTE AS OWNER
AS
$$
import logging
import uuid
from datetime import date

import snowflake.snowpark as snowpark


# ============================================================
# Logger configuration
# ============================================================
logger = logging.getLogger("siesta_upload_summary_email")


# ============================================================
# Procedure and table configuration
# ============================================================
PROCEDURE_NAME = "SIESTA_UPLOAD_SUMMARY_EMAIL"

SOURCE_TABLE = (
    "UNIFIED_PLATFORM_DEV."
    "ADW_UNIFIED_PLATFORM_TACTICAL."
    "STG_ITEM_BRAND_MAP"
)

STAGE_TABLE = (
    "ADW_DEV."
    "ADW_STAGE."
    "SIESTA_PRODUCT_ITMBRD_ITEMBRANDMAP_STAGE"
)

EMAIL_PROCEDURE = (
    "snowflake_administration.stored_procedures."
    "send_generic_email_notification_v1_0"
)

SENDER_NAME = "MA Data"


# ============================================================
# Success email recipients
# ============================================================
RECIPIENTS = [
    "tanya.puthumanajosep@sainsburys.co.uk",
    "jiby.jacob@sainsburys.co.uk",
    "vignesh.PS@sainsburys.co.uk",
    "vinoth.gnanasekaran@sainsburys.co.uk",
    "diksha.joshi@sainsburys.co.uk",
    "zefi.vilanoulos@sainsburys.co.uk",
    "shabanu.mathan@sainsburys.co.uk",
    "kranthi.rayala@sainsburys.co.uk"
]


# ============================================================
# Failure notification recipients
# ============================================================
FAILURE_NOTIFICATION_RECIPIENTS = [
    "tanya.puthumanajosep@sainsburys.co.uk",
    "diksha.joshi@sainsburys.co.uk",
    "zefi.vilanoulos@sainsburys.co.uk",
    "shabanu.mathan@sainsburys.co.uk",
    "kranthi.rayala@sainsburys.co.uk"
]


# ============================================================
# Main procedure entry point
# ============================================================
def main(session: snowpark.Session):
    run_id = uuid.uuid4().hex
    run_date = date.today()

    logger.info(
        f"Starting {PROCEDURE_NAME}. "
        f"run_id={run_id}, run_date={run_date}"
    )

    processor = SiestaUploadSummaryEmailProcessor(
        session=session,
        run_id=run_id,
        run_date=run_date
    )

    try:
        result = processor.run()
        logger.info(
            f"{PROCEDURE_NAME} completed successfully. "
            f"run_id={run_id}"
        )
        return result

    except Exception as err:
        logger.exception(
            f"{PROCEDURE_NAME} failed. "
            f"run_id={run_id}, error={err}"
        )

        try:
            logger.info(
                f"Attempting to send failure notification. "
                f"run_id={run_id}"
            )
            processor.send_failure_notification(err)
            logger.info(
                f"Failure notification process completed. "
                f"run_id={run_id}"
            )
        except Exception as notification_error:
            logger.exception(
                f"Failure notification could not be sent. "
                f"run_id={run_id}, "
                f"notification_error={notification_error}"
            )

        raise


# ============================================================
# SIESTA upload summary email processor
# ============================================================
class SiestaUploadSummaryEmailProcessor:

    def __init__(self, session, run_id, run_date):
        self.session = session
        self.run_id = run_id
        self.run_date = run_date

    def run(self):
        logger.info(
            f"Fetching current SIESTA upload summary. "
            f"run_id={self.run_id}"
        )
        current_summary = self.fetch_current_summary()

        logger.info(
            f"Current upload identified as "
            f"{current_summary['source_name']}"
        )

        previous_summary = self.fetch_previous_upload(
            current_source_name=current_summary["source_name"]
        )

        comparison = self.calculate_comparison(
            current_summary,
            previous_summary
        )

        html_body = self.build_html(
            current_summary,
            previous_summary,
            comparison
        )

        latest_date = current_summary["upload_date"]
        subject = (
            f"SIESTA STG_ITEM_BRAND_MAP Upload Summary - "
            f"{latest_date}"
        )

        self.send_success_email(subject, html_body)

        logger.info(
            f"Success email sent. "
            f"run_id={self.run_id}"
        )

        return (
            "SIESTA upload summary email sent successfully. "
            f"Latest record count: {current_summary['record_count']}"
        )

    def fetch_current_summary(self):
        query = f"""
            SELECT
                MIN(DATE(technical_metadata:load_ts::timestamp)) AS upload_date,
                MIN(technical_metadata:load_ts::timestamp) AS first_load_ts,
                MAX(technical_metadata:load_ts::timestamp) AS last_load_ts,
                MAX(technical_metadata:source_name::string) AS source_name,
                MAX(technical_metadata:source_hash::string) AS source_hash,
                COUNT(*) AS record_count,
                SUM(CASE WHEN brand_coding_status = 'Approved' THEN 1 ELSE 0 END) AS approved_count,
                SUM(CASE WHEN brand_coding_status != 'Approved' OR brand_coding_status IS NULL THEN 1 ELSE 0 END) AS not_approved_count
            FROM {SOURCE_TABLE}
        """

        logger.info(f"Fetching current upload from {SOURCE_TABLE}")
        rows = self.session.sql(query).collect()

        if not rows:
            raise Exception("No data returned from STG_ITEM_BRAND_MAP.")

        row = rows[0]

        if row["RECORD_COUNT"] is None:
            raise Exception("STG_ITEM_BRAND_MAP contains no records.")

        return {
            "upload_date": row["UPLOAD_DATE"],
            "first_load_ts": row["FIRST_LOAD_TS"],
            "last_load_ts": row["LAST_LOAD_TS"],
            "source_name": row["SOURCE_NAME"],
            "source_hash": row["SOURCE_HASH"],
            "record_count": row["RECORD_COUNT"],
            "approved_count": row["APPROVED_COUNT"] or 0,
            "not_approved_count": row["NOT_APPROVED_COUNT"] or 0
        }

    def fetch_previous_upload(self, current_source_name):
        if not current_source_name:
            logger.warning(
                "Current source_name is missing. Cannot determine previous upload."
            )
            return None

        current_source_name_sql = str(current_source_name).replace("'", "''")
        logger.info(
            f"Escaped current source name for logging/reference: {current_source_name_sql}"
        )

        query = f"""
            WITH upload_files AS (
                SELECT
                    metadata:source_name::string AS source_name,
                    MIN(load_ts) AS first_load_ts,
                    MAX(load_ts) AS last_load_ts
                FROM {STAGE_TABLE}
                WHERE metadata:sheet_name::string = 'dim_item_refined'
                  AND metadata:source_name IS NOT NULL
                GROUP BY metadata:source_name::string
            ),
            ranked_uploads AS (
                SELECT
                    source_name,
                    first_load_ts,
                    last_load_ts,
                    ROW_NUMBER() OVER (ORDER BY last_load_ts DESC) AS upload_rank
                FROM upload_files
            ),
            previous_upload AS (
                SELECT
                    source_name,
                    first_load_ts,
                    last_load_ts
                FROM ranked_uploads
                WHERE upload_rank = 2
            )
            SELECT
                p.source_name,
                p.first_load_ts,
                p.last_load_ts,
                DATE(p.first_load_ts) AS upload_date,
                COUNT(s.metadata:source_name) AS record_count
            FROM previous_upload p
            JOIN {STAGE_TABLE} s
              ON s.metadata:source_name::string = p.source_name
             AND s.metadata:sheet_name::string = 'dim_item_refined'
            GROUP BY p.source_name, p.first_load_ts, p.last_load_ts
        """

        logger.info(
            "Fetching previous SIESTA upload using the second most recent distinct source_name."
        )
        rows = self.session.sql(query).collect()

        if not rows:
            logger.warning("No previous SIESTA upload found.")
            return None

        row = rows[0]
        logger.info(
            f"Previous upload found: source_name={row['SOURCE_NAME']}, "
            f"upload_date={row['UPLOAD_DATE']}, "
            f"record_count={row['RECORD_COUNT']}"
        )

        return {
            "source_name": row["SOURCE_NAME"],
            "first_load_ts": row["FIRST_LOAD_TS"],
            "last_load_ts": row["LAST_LOAD_TS"],
            "upload_date": row["UPLOAD_DATE"],
            "record_count": row["RECORD_COUNT"]
        }

    def calculate_comparison(self, current_summary, previous_summary):
        current_count = current_summary["record_count"]

        if previous_summary is None:
            previous_count = None
            difference = None
            change_status = "FIRST UPLOAD"
        else:
            previous_count = previous_summary["record_count"]
            difference = current_count - previous_count

            if difference > 0:
                change_status = "INCREASE"
            elif difference < 0:
                change_status = "DECREASE"
            else:
                change_status = "NO CHANGE"

        return {
            "current_count": current_count,
            "previous_count": previous_count,
            "difference": difference,
            "change_status": change_status
        }

    def build_html(self, current_summary, previous_summary, comparison):
        change_status = comparison["change_status"]

        if change_status == "INCREASE":
            status_colour = "#15803d"
        elif change_status == "DECREASE":
            status_colour = "#b91c1c"
        elif change_status == "NO CHANGE":
            status_colour = "#666666"
        else:
            status_colour = "#0057A8"

        latest_upload_timestamp = (
            current_summary["last_load_ts"]
            if current_summary["last_load_ts"]
            else "N/A"
        )

        previous_upload_timestamp = (
            previous_summary["last_load_ts"]
            if previous_summary
            else "N/A"
        )

        previous_count = (
            f"{comparison['previous_count']:,}"
            if comparison["previous_count"] is not None
            else "N/A"
        )

        difference = (
            f"{comparison['difference']:+,}"
            if comparison["difference"] is not None
            else "N/A"
        )

        latest_count = f"{comparison['current_count']:,}"
        approved_count = f"{current_summary['approved_count']:,}"
        not_approved_count = f"{current_summary['not_approved_count']:,}"
        source_name = current_summary["source_name"] or "N/A"

        html_body = f"""
        <html>
        <body style=\"font-family: Arial, sans-serif;\">
            <p>Hi Team,</p>
            <p>
                The <b>dp_v9mj_measurement_data_brand_data_import</b> DAG run
                <b style=\"color: #15803d;\">completed successfully</b> in DEV.
            </p>
            <p>
                Here are the results for the latest <b>STG_ITEM_BRAND_MAP</b> upload.
            </p>
            <table style=\"border-collapse: collapse; width: 700px; font-family: Arial, sans-serif;\">
                <tr>
                    <th style=\"border: 1px solid #dddddd; padding: 8px; text-align: left; background-color: #f2f2f2;\">ATTRIBUTE</th>
                    <th style=\"border: 1px solid #dddddd; padding: 8px; text-align: left; background-color: #f2f2f2;\">VALUE</th>
                </tr>
                <tr>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">Table Name</td>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">STG_ITEM_BRAND_MAP</td>
                </tr>
                <tr>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">Latest Upload Timestamp</td>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">{latest_upload_timestamp}</td>
                </tr>
                <tr>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">Previous Upload Timestamp</td>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">{previous_upload_timestamp}</td>
                </tr>
                <tr>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">Previous Upload Record Count</td>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">{previous_count}</td>
                </tr>
                <tr>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">Latest Upload Record Count</td>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">{latest_count}</td>
                </tr>
                <tr>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">Difference from Previous Upload</td>
                    <td style=\"border: 1px solid #dddddd; padding: 8px; font-weight: bold; color: {status_colour};\">{difference}</td>
                </tr>
                <tr>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">Change Status</td>
                    <td style=\"border: 1px solid #dddddd; padding: 8px; font-weight: bold; color: {status_colour};\">{change_status}</td>
                </tr>
                <tr>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">Approved in Upload</td>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">{approved_count}</td>
                </tr>
                <tr>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">Not Approved in Upload</td>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">{not_approved_count}</td>
                </tr>
                <tr>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">Latest Source File</td>
                    <td style=\"border: 1px solid #dddddd; padding: 8px;\">{source_name}</td>
                </tr>
            </table>
            <p>
                Best Regards,<br>
                MA Data Team
            </p>
        </body>
        </html>
        """

        return html_body

    def send_success_email(self, subject, html_body):
        for recipient in RECIPIENTS:
            logger.info(f"Sending success email to {recipient}")
            self.session.call(
                EMAIL_PROCEDURE,
                SENDER_NAME,
                recipient,
                subject,
                html_body
            )

    def send_failure_notification(self, error):
        subject = "FAILED - SIESTA STG_ITEM_BRAND_MAP Upload Summary Email"

        html_body = f"""
        <html>
        <body style=\"font-family: Arial, sans-serif;\">
            <p>Hi Team,</p>
            <p>
                The SIESTA <b>STG_ITEM_BRAND_MAP</b> upload summary procedure failed in DEV.
            </p>
            <p><b>Procedure:</b> {PROCEDURE_NAME}</p>
            <p><b>Run ID:</b> {self.run_id}</p>
            <p><b>Error:</b><br>{str(error)}</p>
            <p>Please check the procedure and DAG logs for further details.</p>
            <p>
                Best Regards,<br>
                MA Data Team
            </p>
        </body>
        </html>
        """

        for recipient in FAILURE_NOTIFICATION_RECIPIENTS:
            try:
                logger.info(f"Sending failure notification to {recipient}")
                self.session.call(
                    EMAIL_PROCEDURE,
                    SENDER_NAME,
                    recipient,
                    subject,
                    html_body
                )
                logger.info(f"Failure notification sent to {recipient}")
            except Exception as notification_error:
                logger.exception(
                    f"Failure notification could not be sent to {recipient}. "
                    f"Error={notification_error}"
                )
                continue
$$;

CREATE OR REPLACE TASK UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL
    WAREHOUSE = WHS_MADATA_MEDIUM
    COMMENT = 'Sends the SIESTA Brand Data upload summary email after the DEV brand data import DAG completes successfully.'
AS
    CALL UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.PROC_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL();

-- Snowflake creates tasks in a suspended state by default.
SHOW TASKS LIKE 'TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL';
ALTER TASK UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL RESUME;
```

## Validation and smoke checks

Run the following checks after recreating the objects.

```sql
SHOW PROCEDURES LIKE 'PROC_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL' IN SCHEMA UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL;
SHOW TASKS LIKE 'TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL' IN SCHEMA UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL;
DESC TASK UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL;

SELECT COUNT(*) AS current_stage_item_brand_map_count
FROM UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.STG_ITEM_BRAND_MAP;

SELECT COUNT(*) AS historical_stage_count
FROM ADW_DEV.ADW_STAGE.SIESTA_PRODUCT_ITMBRD_ITEMBRANDMAP_STAGE
WHERE metadata:sheet_name::string = 'dim_item_refined';

-- Optional manual smoke test.
-- Warning: this will send emails to the configured recipients.
CALL UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.PROC_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL();

-- Optional task execution test.
-- Warning: this also triggers emails.
EXECUTE TASK UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL;
```

## Operational checks

Use the following commands during support or investigation.

```sql
ALTER TASK UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL SUSPEND;
ALTER TASK UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL RESUME;

SELECT *
FROM TABLE(
    INFORMATION_SCHEMA.TASK_HISTORY(
        SCHEDULED_TIME_RANGE_START => DATEADD('day', -7, CURRENT_TIMESTAMP()),
        TASK_NAME => 'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL'
    )
)
ORDER BY SCHEDULED_TIME DESC;
```

## Notes

- This is a manually executed task, not a cron-scheduled task.
- The task is triggered from the dbt custom macro `BRAND_DATA_IMPORT_SUCCESS_EMAIL`.
- Keep `run_after: - STG_ITEM_BRAND_MAP` so the email runs only after the latest SIESTA-backed model is available.
- If the procedure is recreated with different recipients, keep the task definition unchanged unless the procedure name or schema changes.
