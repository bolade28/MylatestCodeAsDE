# STAGE_JS_BRAND_DATA recovery runbook

This file is a manual reference for recreating the `STAGE_JS_BRAND_DATA` external stage if it is ever dropped by mistake.

- Location chosen intentionally under `migrations/` as operational documentation.
- This file is **not part of dbt models, seeds, snapshots, macros, or CI/CD execution**.
- Copy and run the relevant section manually in Snowflake when needed.
- The SQL blocks below include comments explaining the purpose of each command.

## DEV / non-prod

Use this section when recreating the non-production stage in `UNIFIED_PLATFORM_DEV`.

```sql
-- Use the following configuration to recreate the stage in the  UNIFIED_PLATFORM_DEV database.
USE ROLE RL_DEV_MADATA_ENGINEER;
USE DATABASE UNIFIED_PLATFORM_DEV;
USE SCHEMA ADW_UNIFIED_PLATFORM_TACTICAL;
USE WAREHOUSE WHS_MADATA_XSMALL;

-- Create the stage if it does not exist, or replace it if it already exists.
-- The stage points Snowflake at the non-prod S3 bucket that holds JS Brand Data.
CREATE OR REPLACE STAGE STAGE_JS_BRAND_DATA
url='s3://ma-data-nonprod-brand-data-766696030500/'
credentials = (aws_role = 'arn:aws:iam::766696030500:role/ma-data-nonprod-snowflake-external-stage')
-- KMS key ID intentionally omitted from this runbook for security reasons.
-- Retrieve the correct non-prod KMS key from an approved secure source before running this statement.
encryption=(TYPE = 'AWS_SSE_KMS' KMS_KEY_ID = '<RETRIEVE_NONPROD_KMS_KEY_SECURELY>')
comment = 'External stage used by the MA-Data team to access JS Brand Data stored in ma-data-nonprod-brand-data-766696030500 S3.';

-- List files visible through the stage to confirm Snowflake can access the bucket.
LS @STAGE_JS_BRAND_DATA;

-- Show stages in the current schema to confirm the stage now exists.
SHOW STAGES;
```

## PROD

Use this section when recreating the production stage in `UNIFIED_PLATFORM_PROD`.

```sql
-- Use the following configuration to recreate the stage in the  UNIFIED_PLATFORM_PROD database.
USE ROLE RL_PROD_MADATA_ENGINEER;
USE DATABASE UNIFIED_PLATFORM_PROD;
USE SCHEMA ADW_UNIFIED_PLATFORM_TACTICAL;
USE WAREHOUSE WHS_MADATA_XSMALL;

-- Create the stage if it does not exist, or replace it if it already exists.
-- The stage points Snowflake at the production S3 bucket that holds JS Brand Data.
CREATE OR REPLACE STAGE STAGE_JS_BRAND_DATA
url='s3://ma-data-prod-brand-data-638969304502/'
credentials = (aws_role = 'arn:aws:iam::638969304502:role/ma-data-prod-snowflake-external-stage')
-- KMS key ID intentionally omitted from this runbook for security reasons.
-- Retrieve the correct prod KMS key from an approved secure source before running this statement.
encryption=(TYPE = 'AWS_SSE_KMS' KMS_KEY_ID = '<RETRIEVE_PROD_KMS_KEY_SECURELY>')
comment = 'External stage used by the MA-Data team to access JS Brand Data stored in ma-data-prod-brand-data-638969304502 S3.';

-- List files visible through the stage to confirm Snowflake can access the bucket.
LS @STAGE_JS_BRAND_DATA;

-- Show stages in the current schema to confirm the stage now exists.
SHOW STAGES;
```
