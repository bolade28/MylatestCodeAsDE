# JS Brand SKU delivery runbook

This file is a manual reference for creating or recreating the production Snowflake procedure `PROC_JS_BRAND_SKU_DELIVERY` and the scheduled task `TASK_JS_BRAND_SKU_DELIVERY` that runs it.

- Location chosen intentionally under `migrations/` as operational documentation.
- This file is **not part of dbt models, seeds, snapshots, macros, or CI/CD execution**.
- Copy and run the relevant SQL manually in Snowflake when needed.
- The SQL blocks below include comments explaining the purpose of each command.
- This runbook is written for `UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL` because the requested procedure and task are production objects.

## Purpose

The procedure exports the current contents of `ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_INCREMENT` to the `STAGE_JS_BRAND_DATA` stage as a single CSV file, generates a presigned download URL, emails the success notification to the agreed recipients, and sends a failure notification if any step fails.

The task runs the procedure on the following schedule:

- `USING CRON 30 4,5 * * 1-5 Europe/London`
- This means **04:30 and 05:30, Monday to Friday, Europe/London time**.

## Prerequisites

Before running the SQL in this runbook, confirm the following:

1. The external stage `STAGE_JS_BRAND_DATA` exists in `UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL`.
   - If the stage is missing, follow `migrations/snowflake-operations/STAGE_JS_BRAND_DATA_RUNBOOK.md` first.
2. The source object `ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_INCREMENT` exists and returns the expected incremental SKU dataset.
3. The named file format `CSV_COMMASEP_DBLQUOT_FORMAT` exists and is accessible from the target schema.
4. The email procedure `snowflake_administration.stored_procedures.send_generic_email_notification_v1_0` exists and the executing role can call it.
5. The executing role has permission to create procedures and tasks in `UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL`.
6. The warehouse `WHS_MADATA_MEDIUM` is available for the task.

## PROD

Use this section when creating or replacing the production procedure and task in `UNIFIED_PLATFORM_PROD`.

```sql
-- Use the production MA Data Engineering role and target schema.
USE ROLE RL_PROD_MADATA_ENGINEER;
USE DATABASE UNIFIED_PLATFORM_PROD;
USE SCHEMA ADW_UNIFIED_PLATFORM_TACTICAL;
USE WAREHOUSE WHS_MADATA_MEDIUM;

-- Optional: confirm the key supporting objects exist before deploying.
SHOW STAGES LIKE 'STAGE_JS_BRAND_DATA';
SHOW FILE FORMATS LIKE 'CSV_COMMASEP_DBLQUOT_FORMAT';
SHOW VIEWS LIKE 'ITEM_BRAND_INCREMENT';

-- Optional but recommended: suspend the task before replacing procedure/task definitions.
ALTER TASK IF EXISTS UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SKU_DELIVERY SUSPEND;

-- Create or replace the procedure that exports the incremental SKU file,
-- generates a presigned URL, and sends email notifications.
CREATE OR REPLACE PROCEDURE UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.PROC_JS_BRAND_SKU_DELIVERY()
RETURNS TABLE ()
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'main'
EXECUTE AS OWNER
AS
$$
import logging
import uuid
from datetime import date

import snowflake.snowpark as snowpark


# ============================================================
# Configuration
# ============================================================

PROCEDURE_NAME = "PROC_JS_BRAND_SKU_DELIVERY"

DATABASE_SCHEMA = "UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL"
TABLE_NAME = "ITEM_BRAND_INCREMENT"
STAGE_NAME = "STAGE_JS_BRAND_DATA"

# Presigned URL validity: 1 hours
PRESIGNED_URL_EXPIRY_SECONDS = 3600

OUTPUT_FILE_NAME = f"{TABLE_NAME}_export_{{date}}.csv"

COLUMNS = [
    "SKU",
    "ITEM_NAME",
    "OWN_LABEL_FLAG",
    "ASPIRE_ITEM_BRAND_NAME",
    "SUB_CAT_NAME",
    "CAT_MANAGER_NAME"
]


# ============================================================
# Success email recipients
# ============================================================

RECIPIENTS = [
    "tanya.puthumanajosep@sainsburys.co.uk",
    "jiby.jacob@sainsburys.co.uk",
    "vignesh.PS@sainsburys.co.uk",
    "vinoth.gnanasekaran@sainsburys.co.uk",
    "diksha.joshi@sainsburys.co.uk",
    "zefi.vilanoulos@sainsburys.co.uk",
    "shabanu.mathan@sainsburys.co.uk",
    "kranthi.rayala@sainsburys.co.uk"
]

# ============================================================
# Failure email recipients
# ============================================================

FAILURE_NOTIFICATION_RECIPIENTS = [
    "tanya.puthumanajosep@sainsburys.co.uk",
    "diksha.joshi@sainsburys.co.uk",
    "zefi.vilanoulos@sainsburys.co.uk",
    "shabanu.mathan@sainsburys.co.uk",
    "kranthi.rayala@sainsburys.co.uk"
]

# ============================================================
# Email procedure
# ============================================================

EMAIL_PROCEDURE = (
    "snowflake_administration.stored_procedures."
    "send_generic_email_notification_v1_0"
)

logger = logging.getLogger("python_logger")


# ============================================================
# Main entry point
# ============================================================

def main(session: snowpark.Session):

    run_id = uuid.uuid4().hex
    run_date = date.today()

    logger.info(
        f"{PROCEDURE_NAME} started. "
        f"run_id={run_id}, date={run_date}"
    )

    generator = BrandDataSKUDelivery(
        session=session,
        run_id=run_id,
        run_date=run_date
    )

    try:
        return generator.run()

    except Exception:
        logger.exception(
            f"{PROCEDURE_NAME} failed. "
            f"run_id={run_id}"
        )
        raise


# ============================================================
# Delivery class
# ============================================================

class BrandDataSKUDelivery:

    def __init__(self, session, run_id, run_date):

        self.session = session
        self.run_id = run_id
        self.run_date = run_date

        self.source_table = (
            f"{DATABASE_SCHEMA}.{TABLE_NAME}"
        )

        self.output_file_name = OUTPUT_FILE_NAME.format(
            date=self.run_date
        )

        self.output_path = (
            f"@{STAGE_NAME}/{self.output_file_name}"
        )

        logger.info(
            f"Initialised {PROCEDURE_NAME}. "
            f"run_id={self.run_id}, "
            f"source={self.source_table}, "
            f"output={self.output_path}"
        )


    # ========================================================
    # Step 1: Fetch incremental SKUs
    # ========================================================

    def fetch_incremental_skus(self):

        logger.info(
            f"Fetching incremental SKUs from {self.source_table}. "
            f"run_id={self.run_id}"
        )

        try:

            df = (
                self.session
                .table(self.source_table)
                .select(COLUMNS)
            )

            return df

        except Exception:

            logger.exception(
                f"Failed to fetch incremental SKUs. "
                f"run_id={self.run_id}"
            )

            raise


    # ========================================================
    # Step 2: Generate CSV
    # ========================================================

    def export_csv(self, df, record_count):

        if record_count == 0:

            logger.info(
                f"No incremental SKUs found for {self.run_date}. "
                f"CSV generation skipped. run_id={self.run_id}"
            )

            return False

        logger.info(
            f"Exporting {record_count} incremental SKUs to "
            f"{self.output_path}. run_id={self.run_id}"
        )

        try:

            copy_result = df.write.copy_into_location(
                self.output_path,
                file_format_type="csv",
                header=True,
                overwrite=True,
                single=True,
                file_format_name="CSV_COMMASEP_DBLQUOT_FORMAT",
                format_type_options={
                    "COMPRESSION": "NONE",
                    "NULL_IF": ()
                }
            )

            logger.info(
                f"CSV generated successfully. "
                f"record_count={record_count}, "
                f"result={copy_result}, "
                f"run_id={self.run_id}"
            )

            return True

        except Exception:

            logger.exception(
                f"Failed to generate CSV. "
                f"path={self.output_path}, "
                f"run_id={self.run_id}"
            )

            raise


    # ========================================================
    # Step 3: Verify output file
    # ========================================================

    def verify_output_file(self):

        logger.info(
            f"Verifying output file exists at {self.output_path}. "
            f"run_id={self.run_id}"
        )

        try:

            files = self.session.sql(
                f"LIST {self.output_path}"
            ).collect()

            if not files:

                raise Exception(
                    f"Output file was not found at "
                    f"{self.output_path}"
                )

            logger.info(
                f"Output file verified successfully. "
                f"run_id={self.run_id}"
            )

            return True

        except Exception:

            logger.exception(
                f"Output file verification failed. "
                f"path={self.output_path}, "
                f"run_id={self.run_id}"
            )

            raise


    # ========================================================
    # Step 4: Generate presigned URL
    # ========================================================

    def generate_download_link(self):

        logger.info(
            f"Generating presigned URL. "
            f"expiry={PRESIGNED_URL_EXPIRY_SECONDS} seconds, "
            f"run_id={self.run_id}"
        )

        try:

            self.verify_output_file()

            query = f"""
                SELECT GET_PRESIGNED_URL(
                    '@{STAGE_NAME}',
                    '{self.output_file_name}',
                    {PRESIGNED_URL_EXPIRY_SECONDS}
                )
            """

            result = self.session.sql(query).collect()

            if not result or not result[0][0]:

                raise Exception(
                    "GET_PRESIGNED_URL returned an empty URL"
                )

            url = result[0][0]

            logger.info(
                f"Presigned URL generated successfully. "
                f"run_id={self.run_id}"
            )

            return url

        except Exception:

            logger.exception(
                f"Failed to generate presigned URL. "
                f"run_id={self.run_id}"
            )

            raise


    # ========================================================
    # Step 5: Generate success email
    # ========================================================

    def generate_success_email(
        self,
        record_count,
        download_link
    ):

        formatted_date = self.run_date.strftime(
            "%d %B %Y"
        )

        html_body = f"""
<!DOCTYPE html>
<html>
<head>
</head>

<body>

    <p>Hi Team,</p>

    <p>
        The next set of incremental SKUs for the TCS clean-up
        process has been successfully generated and placed in
        the agreed location.
    </p>

    <p>
        Please find the details below:
    </p>

    <p>
        <strong>Status:</strong> Successful
        <br>

        <strong>File Name:</strong>
        {self.output_file_name}
        <br>

        <strong>Generated Date:</strong>
        {formatted_date}
        <br>

        <strong>Number of SKUs:</strong>
        {record_count}
        <br>

        <strong>Location:</strong>
        Agreed shared location
    </p>

    <p>
        Please download the file using the link below:
    </p>

    <p>
        <strong>
            <a href="{download_link}">
                Download Incremental SKU File
            </a>
        </strong>
    </p>

    <p>
        The download link will remain valid for 1 hour.
    </p>

    <p>
        If you have any questions or need clarification,
        please contact the MA Data Engineering team at:
        <br>
        pollen_data_engineering@sainsburys.co.uk
    </p>

    <p>
        Best Regards,
        <br>
        MA Data Team
    </p>

</body>
</html>
"""

        return html_body


    # ========================================================
    # Step 6: Send email
    # ========================================================

    def send_email(
        self,
        recipients,
        subject,
        html_body
    ):

        logger.info(
            f"Sending notification email to "
            f"{len(recipients)} recipients. "
            f"run_id={self.run_id}"
        )

        try:

            for recipient in recipients:

                logger.info(
                    f"Sending email to {recipient}. "
                    f"run_id={self.run_id}"
                )

                result = self.session.call(
                    EMAIL_PROCEDURE,
                    "MA Data",
                    recipient,
                    subject,
                    html_body
                )

                logger.info(
                    f"Email procedure completed for "
                    f"{recipient}. result={result}"
                )

        except Exception:

            logger.exception(
                f"Failed to send notification email. "
                f"run_id={self.run_id}"
            )

            # Do not swallow the exception.
            # This ensures the Snowflake task is marked as failed.
            raise


    # ========================================================
    # Step 7: Send failure notification
    # ========================================================

    def send_failure_notification(self, error):

        logger.info(
            f"Attempting to send failure notification to "
            f"{len(FAILURE_NOTIFICATION_RECIPIENTS)} recipients. "
            f"run_id={self.run_id}"
        )

        try:

            subject = (
                "ERROR: JS Brand Data SKU Delivery Failed"
            )

            body = f"""
<!DOCTYPE html>
<html>
<head>
</head>

<body>

    <p>Hi Team,</p>

    <p>
        The JS Brand Data SKU delivery procedure failed.
    </p>

    <p>
        <strong>Procedure:</strong>
        {PROCEDURE_NAME}
        <br>

        <strong>Run ID:</strong>
        {self.run_id}
        <br>

        <strong>Run Date:</strong>
        {self.run_date}
        <br>

        <strong>Source:</strong>
        {self.source_table}
        <br>

        <strong>Output:</strong>
        {self.output_path}
    </p>

    <p>
        <strong>Error:</strong>
    </p>

    <pre>{str(error)}</pre>

    <p>
        Please investigate the failure.
    </p>

    <p>
        Best Regards,
        <br>
        MA Data Team
    </p>

</body>
</html>
"""

            for recipient in FAILURE_NOTIFICATION_RECIPIENTS:

                logger.info(
                    f"Sending failure notification to "
                    f"{recipient}. "
                    f"run_id={self.run_id}"
                )

                result = self.session.call(
                    EMAIL_PROCEDURE,
                    "MA Data",
                    recipient,
                    subject,
                    body
                )

                logger.info(
                    f"Failure email procedure completed for "
                    f"{recipient}. "
                    f"result={result}"
                )

        except Exception:

            # Do not replace the original procedure failure
            # with a failure from the notification itself.
            logger.exception(
                f"Failed to send failure notification. "
                f"run_id={self.run_id}"
            )


    # ========================================================
    # Main processing flow
    # ========================================================

    def run(self):

        try:

            logger.info(
                f"Starting {PROCEDURE_NAME}. "
                f"run_id={self.run_id}"
            )


            # ------------------------------------------------
            # Step 1: Fetch SKUs
            # ------------------------------------------------

            df = self.fetch_incremental_skus()

            record_count = df.count()

            logger.info(
                f"Incremental SKU count: {record_count}. "
                f"run_id={self.run_id}"
            )


            # ------------------------------------------------
            # Step 2: Handle no-data scenario
            # ------------------------------------------------

            if record_count == 0:

                logger.info(
                    f"No incremental SKUs available for "
                    f"{self.run_date}. "
                    f"No CSV or download link will be generated. "
                    f"run_id={self.run_id}"
                )

                return df


            # ------------------------------------------------
            # Step 3: Generate CSV
            # ------------------------------------------------

            self.export_csv(
                df,
                record_count
            )


            # ------------------------------------------------
            # Step 4: Generate download link
            # ------------------------------------------------

            download_link = (
                self.generate_download_link()
            )


            # ------------------------------------------------
            # Step 5: Generate email
            # ------------------------------------------------

            subject = (
                "Incremental SKU File Generated for "
                f"TCS Clean-Up | "
                f"{self.run_date.strftime('%d %B %Y')}"
            )

            html_body = self.generate_success_email(
                record_count,
                download_link
            )

            if not html_body:

                raise Exception(
                    "Generated HTML email body is empty"
                )


            # ------------------------------------------------
            # Step 6: Send notification
            # ------------------------------------------------

            self.send_email(
                RECIPIENTS,
                subject,
                html_body
            )


            # ------------------------------------------------
            # Successful completion
            # ------------------------------------------------

            logger.info(
                f"{PROCEDURE_NAME} completed successfully. "
                f"record_count={record_count}, "
                f"run_id={self.run_id}"
            )

            return df


        except Exception as error:

            logger.exception(
                f"{PROCEDURE_NAME} failed. "
                f"run_id={self.run_id}, "
                f"error={str(error)}"
            )

            self.send_failure_notification(error)

            # IMPORTANT:
            # Re-raise so the Snowflake task records
            # the procedure execution as FAILED.
            raise


        finally:

            logger.info(
                f"{PROCEDURE_NAME} execution finished. "
                f"run_id={self.run_id}"
            )
$$;

-- Create or replace the scheduled task that runs the procedure.
-- Updated the task schedule to run at 09:00 and 10:00 IST, Monday to Friday, year-round, independent of UK daylight saving changes.
CREATE OR REPLACE TASK UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SKU_DELIVERY
    WAREHOUSE = WHS_MADATA_MEDIUM
    SCHEDULE = 'USING CRON 0 9,10 * * 1-5 Asia/Kolkata'
    SUSPEND_TASK_AFTER_NUM_FAILURES = 2
    TASK_AUTO_RETRY_ATTEMPTS = 1
AS
    CALL UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.PROC_JS_BRAND_SKU_DELIVERY();

-- Snowflake creates tasks in a suspended state by default.
-- Resume the task only after validation is complete.
SHOW TASKS LIKE 'TASK_JS_BRAND_SKU_DELIVERY';
```

## Validation and smoke checks

Run the following checks after creating or replacing the objects.

```sql
-- Confirm the procedure exists.
SHOW PROCEDURES LIKE 'PROC_JS_BRAND_SKU_DELIVERY' IN SCHEMA UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL;

-- Confirm the task exists and review its definition/state.
SHOW TASKS LIKE 'TASK_JS_BRAND_SKU_DELIVERY' IN SCHEMA UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL;
DESC TASK UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SKU_DELIVERY;

-- Confirm the source view is populated as expected.
SELECT COUNT(*) AS incremental_sku_count
FROM UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_INCREMENT;

-- Optional manual smoke test.
-- Warning: this writes a CSV to the external stage and sends notification emails.
CALL UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.PROC_JS_BRAND_SKU_DELIVERY();

-- If the manual run succeeds, check that the export file is present on the stage.
LIST @UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.STAGE_JS_BRAND_DATA;
```

## Enable the scheduled task

Resume the task after validation is complete.

```sql
ALTER TASK UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SKU_DELIVERY RESUME;
SHOW TASKS LIKE 'TASK_JS_BRAND_SKU_DELIVERY' IN SCHEMA UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL;
```

## Operational checks

Use the following commands during support or incident investigation.

```sql
-- Suspend the task to prevent scheduled execution.
ALTER TASK UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SKU_DELIVERY SUSPEND;

-- Resume the task after issue resolution.
ALTER TASK UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SKU_DELIVERY RESUME;

-- Review recent task runs.
SELECT *
FROM TABLE(
    INFORMATION_SCHEMA.TASK_HISTORY(
        SCHEDULED_TIME_RANGE_START => DATEADD('day', -7, CURRENT_TIMESTAMP()),
        TASK_NAME => 'UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SKU_DELIVERY'
    )
)
ORDER BY SCHEDULED_TIME DESC;

-- Review recent stage files created for this delivery.
LIST @UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.STAGE_JS_BRAND_DATA;
```

## Notes

- The procedure returns early with no CSV generation when `ITEM_BRAND_INCREMENT` contains zero rows.
- When the procedure fails, it re-raises the exception after attempting failure notifications so the Snowflake task run is marked as failed.
- The presigned URL is valid for 1 hour.
- The export file name follows the pattern `ITEM_BRAND_INCREMENT_export_<run_date>.csv`.
