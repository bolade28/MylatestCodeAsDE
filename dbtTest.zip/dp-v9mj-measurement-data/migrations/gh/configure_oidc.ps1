#!/usr/bin/env pwsh
$PSStyle.OutputRendering = 'PlainText'

Write-Output "Setting up OIDC for ${BLUE}Windows${END_COLOUR}..."

#Requires -Version 5.1

# You can modify this repository name if needed.
# This indicates you are not following the standard naming convention
# and should only be changed by exception.
$REPO_NAME = "dp-v9mj-measurement-data"

# ANSI color codes for terminal output
$RED = "`e[0;31m"
$GREEN = "`e[0;32m"
$ORANGE = "`e[0;33m"
$BLUE = "`e[0;34m"
$CYAN = "`e[0;36m"
$YELLOW = "`e[1;33m"
$LIGHT_PURPLE = "`e[1;34m"
$END_COLOUR = "`e[0m"

Write-Output "${CYAN}Checking GitHub CLI installation and configuration...${END_COLOUR}"

function Display-Error {
    Write-Output "${YELLOW}⚠️  Error: GitHub CLI configuration required${END_COLOUR}"
    Write-Output "${BLUE}------------------------------------------------${END_COLOUR}"
    Write-Output "${RED}To deploy DDL, you need to configure the GitHub CLI.${END_COLOUR}"
    Write-Output ""
    Write-Output "${CYAN}Manual steps required:${END_COLOUR}"
    Write-Output "${LIGHT_PURPLE}1. Install GitHub CLI: https://github.com/cli/cli#installation${END_COLOUR}"
    Write-Output "   - For macOS: ${GREEN}brew install gh${END_COLOUR}"
    Write-Output "   - For Linux: ${GREEN}sudo apt install gh${END_COLOUR}"
    Write-Output "   - For Windows: ${GREEN}choco install gh${END_COLOUR}"
    Write-Output "${LIGHT_PURPLE}2. Login to GitHub: ${GREEN}gh auth login${END_COLOUR}"
    Write-Output "   Follow the prompts to authenticate with your GitHub account"
    Write-Output ""
    Write-Output "${LIGHT_PURPLE}3. After installation and authentication, run this script again:${END_COLOUR}"
    Write-Output "   ${GREEN}.\migrations\gh\configure_oidc.ps1${END_COLOUR}"
    Write-Output "${BLUE}------------------------------------------------${END_COLOUR}"
    exit 0
}

function Display-ManualOIDC {
    Write-Output "${YELLOW}⚠️  Error: OIDC configuration failed${END_COLOUR}"
    Write-Output "${BLUE}------------------------------------------------${END_COLOUR}"
    Write-Output "${RED}The automatic OIDC configuration failed.${END_COLOUR}"
    Write-Output ""
    Write-Output "${CYAN}Please verify the repository name:${END_COLOUR}"
    Write-Output "   Current repository name: ${LIGHT_PURPLE}$REPO_NAME${END_COLOUR}"
    Write-Output ""
    Write-Output "${CYAN}If the repository name is incorrect:${END_COLOUR}"
    Write-Output "   1. Edit this script (${GREEN}.\migrations\gh\configure_oidc.ps1${END_COLOUR})"
    Write-Output "   2. Look for ${LIGHT_PURPLE}`$REPO_NAME=<value>${END_COLOUR} at the top of the file"
    Write-Output "   3. Change it to match your GitHub repository name"
    Write-Output ""
    Write-Output "${CYAN}After correcting the repository name, run this script again:${END_COLOUR}"
    Write-Output "   ${GREEN}.\migrations\gh\configure_oidc.ps1${END_COLOUR}"
    Write-Output ""
    Write-Output "${BLUE}------------------------------------------------${END_COLOUR}"
    Write-Output "${ORANGE}NOTE: Manually changing the repository name here indicates you're not following${END_COLOUR}"
    Write-Output "${ORANGE}the standard naming convention. When possible, it's recommended to:${END_COLOUR}"
    Write-Output "   - Rename your GitHub repository to match the standard format"
    Write-Output "   - OR update your project_name to follow the standard pattern"
    Write-Output ""
    Write-Output "${ORANGE}The standard naming format is: dp-xxxx-name-of-project${END_COLOUR}"
    Write-Output ""
    Write-Output "${CYAN}If you continue to encounter issues, contact Grid support ${ORANGE}#data-grid-queries${END_COLOUR}"
    Write-Output "${BLUE}------------------------------------------------${END_COLOUR}"
}

# Check if GitHub CLI is installed
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    Write-Output "${RED}❌ GitHub CLI is not installed.${END_COLOUR}"
    Display-Error
}

# Check if authenticated with GitHub
$ghAuthStatus = gh auth status 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Output "${RED}❌ Not logged in to GitHub.${END_COLOUR}"
    Display-Error
}

Write-Output "${GREEN}✅ GitHub CLI is installed and authenticated.${END_COLOUR}"

Write-Output "${CYAN}Configuring OIDC for repository: ${LIGHT_PURPLE}$REPO_NAME${END_COLOUR}"

# Configure OIDC for the repository
$oidcResult = gh api --method PUT `
    -H "Accept: application/vnd.github+json" `
    -H "X-GitHub-Api-Version: 2022-11-28" `
    "/repos/sainsburys-tech/$REPO_NAME/actions/oidc/customization/sub" `
    -F "use_default=false" `
    -f "include_claim_keys[]=repo" `
    -f "include_claim_keys[]=context" `
    -f "include_claim_keys[]=job_workflow_ref" 2>&1

if ($LASTEXITCODE -ne 0) {
    Display-ManualOIDC
    Write-Output "${RED}❌ Failed to configure OIDC for repository.${END_COLOUR}"
} else {
    Write-Output "${GREEN}✅ Successfully configured OIDC for repository: ${LIGHT_PURPLE}$REPO_NAME${END_COLOUR}"
}

# We always exit with success, as we don't want this to block the copier operation
exit 0
