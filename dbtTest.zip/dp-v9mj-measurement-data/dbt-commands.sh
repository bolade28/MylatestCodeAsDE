###  Pull in the environment variables (macOS only)
source .env

###  Check the versions of installed tools
copier --version
dbt --version
git --version

########################################################################
# The dbt commands are documented fully at:
#   https://docs.getdbt.com/reference/dbt-commands
#
# Once we migrate to dbt v1.5 (PCH-2124), we can drop --project-dir
########################################################################

###  Test that the connection to Snowflake works
dbt debug --project-dir dp_v9mj_measurement_data/transforms

###  Clean the compiled/log files
dbt clean --project-dir dp_v9mj_measurement_data/transforms

###  Install the dependencies (for authentication, use GitHub PAT)
dbt deps --project-dir dp_v9mj_measurement_data/transforms

###  Parse the project without a DB connection
dbt parse --project-dir dp_v9mj_measurement_data/transforms

###  Load in the seed files (if there are any)
dbt seed --project-dir dp_v9mj_measurement_data/transforms

###  Check the freshness of the source tables
dbt source freshness --project-dir dp_v9mj_measurement_data/transforms

###  Compile the project (not required, but included for completeness)
dbt compile --project-dir dp_v9mj_measurement_data/transforms

###  Run the models' unit tests
dbt test --select tag:unit-test --project-dir dp_v9mj_measurement_data/transforms

###  Run the data product pipeline (different criteria are shown for reference)
dbt build --full-refresh --project-dir dp_v9mj_measurement_data/transforms
dbt build --select dv    --project-dir dp_v9mj_measurement_data/transforms
dbt build --select fed   --project-dir dp_v9mj_measurement_data/transforms
dbt build --select pl    --project-dir dp_v9mj_measurement_data/transforms

###  Test the models for DQ issues
dbt test --project-dir dp_v9mj_measurement_data/transforms

###  Generate the docs
dbt docs generate          --project-dir dp_v9mj_measurement_data/transforms
dbt docs serve --port=8092 --project-dir dp_v9mj_measurement_data/transforms
