//subscribes to jquery library
//searches for elements in the site that have a table
//applies the default datatables library to these elements
document$.subscribe(function () {
  const tables = document.querySelectorAll("article table:not([class])");
  tables.forEach(function (table) {
    $(table).DataTable();
  });
});

document.body.addEventListener("themechange", function () {
  // Redraw all DataTables
  $.fn.dataTable.tables().forEach(function (table) {
    $(table).DataTable().draw();
  });
});
