ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    SET COMMENT = 'This object stores historical associations between Products (SKUs) and their corresponding Brands. It is implemented as a Type 2 table, serving as a core data product for tracking the relationship between SKUs and the Brand Hierarchy over time. The table also captures the status of each association and maintains a complete history of all changes.\n\nData for this table is sourced from:\n1.ASPIRE database : To extract newly added SKUs.\n2.Manualy updated Spreadsheet : Containing SKU-to-Brand mapping information.';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN ITEM_CD COMMENT 'Unique Item code created for a SKU';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN VALID_FROM_DT COMMENT 'Date from the record is valid.';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN VALID_UNTIL_DT COMMENT 'Date until the record is valid.';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN UNIQUE_BRAND_NAME COMMENT 'There are instances where SKUs may share the same Brand Name, but they are owned by different Brand Owners(legal entities or organisations). To accurately differentiate these instances, a Unique Brand Name is created by combining the Brand Name with the Brand Owner Name. This ensures that each Brand & Brand Owner combination is distinct and avoids ambiguity across SKUs.';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN BRAND_APPROVAL_FLAG COMMENT 'If the SKUs to Brand Hierarchy coding is accurate and approved by the Nectar360 team, then this flag would be set to TRUE else FALSE';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN BRAND_CODING_STATUS COMMENT 'Status of the SKUs to Brand Coding from the below set of values\n\nCleaned: SKUs to Brand association is completed by TCS team and ready for review by N360\nApproved: Approved by N360 post review\nCorrections: N360 team has reviewed, but Brand coding needs some corrections\nExcluded: Test or Dump SKUs which doesn''t need to be exposed to downstream\nUncodable: SKUs where an appropriate Brand coding is not possible due to missing relevant information and hence they are uncodable\nIn progress: Brand discovery is currently in progress';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN BRAND_NAME COMMENT 'A brand is the overarching identity of a company, product, or service. It includes the name, logo, values, and emotional associations that customers recognise and trust.';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN BRAND_OWNER_NAME COMMENT 'Brand Owner is the legal entity or organisation that holds the intellectual property (IP) rights to a brand, which includes ownership of the brand, name, logo, trademarks, and associated assets. There are also instances where an organisation can be licensed to produce and market a range of products within a Brand in these cases many of the responsibilities of Brand Ownership are carried out by the licensee.\n\nIn retail and product data systems, the brand owner is often used to identify the source of the brand, especially when the brand name is not explicitly listed on the product.';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN SUB_BRAND_NAME COMMENT 'A sub-brand is a product or group of products that operates under the umbrella of a parent Brand, but has its own identity, positioning, and often a target audience. It always appears in the context of the parent Brand and benefits from its reputation while offering a unique value proposition.';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN LOAD_TS COMMENT 'Timestamp showing when this record was loaded.';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN HASH_DIFF COMMENT 'Cryptographic hash computed to detect any changes in the source data';
ALTER TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    ALTER COLUMN TECHNICAL_METADATA COMMENT 'Details of the ETL pipeline technical information';
