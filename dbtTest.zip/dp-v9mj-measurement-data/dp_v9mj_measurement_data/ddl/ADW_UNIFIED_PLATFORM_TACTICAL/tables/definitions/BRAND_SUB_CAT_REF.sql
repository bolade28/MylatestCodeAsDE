-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.BRAND_SUB_CAT_REF
CREATE OR REPLACE TABLE ADW_UNIFIED_PLATFORM_TACTICAL.BRAND_SUB_CAT_REF
(
 UNIQUE_SUB_CAT_CD varchar (128) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Unique sub category code created in Aspire. There are overlapping Sub Category codes between JS Food (sourced from RMS 09),Non-Food (soured from RMS 10) and Argos, and a logic is applied in Aspire to uniquely identify a sub category across business. JS Food appended with _V9, Non Food Sub Categories _V10.',
 SUB_CAT_CD        number (38,0) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Numeric code which uniquely identifies the Sainsburys Class/Sub Category. It is also called Range/Series in Argos.',
 SUB_CAT_NAME      varchar (100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Name of Sainsburys Class/Sub Category. It is also called Range/Series in Argos.',

 CONSTRAINT PK_1 PRIMARY KEY ( UNIQUE_SUB_CAT_CD )
) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-data', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = 'v1.0.0', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@sainsburys.co.uk');
