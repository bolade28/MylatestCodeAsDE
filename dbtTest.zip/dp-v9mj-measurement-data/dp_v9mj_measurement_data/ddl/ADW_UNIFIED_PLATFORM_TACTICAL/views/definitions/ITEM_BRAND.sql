-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND
CREATE OR REPLACE VIEW ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND
 COPY GRANTS (
  OPERATING_COMPANY_CD WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Code to represent different Operating Companies\n\n1 - Sainsburys\n2 - Argos',
  ITEM_CD WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Unique Item code created for a SKU',
  ITEM_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Full Name of the SKU',
  ITEM_SHORT_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Short Name of the SKU',
  BUSINESS_UNIT_DIR_CD WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Numeric code for Business Unit Director responsible for managing the Category managers. This field is part of Trading Hierarchy.
Business Unit Director code will not change once created.',
  BUSINESS_UNIT_DIR_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Business Unit Director responsible for the Category Managers under it. This field is part of Trading Hierarchy.',
  CAT_MANAGER_CD WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Numeric code for Category Manager responsible for managing the buyers. This field is part of Trading Hierarchy.',
  CAT_MANAGER_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Category manager responsible for managing the buyers under it. This field contains the responsibility name. This field is part of Trading Hierarchy.',
  BUYER_CD WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Numeric code for buyer responsible for managing the sub-category. This field is part of Trading Hierarchy.',
  BUYER_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Buyer responsible for manging the sub-category. This field is part of Trading Hierarchy.',
  UNIQUE_SUB_CAT_CD WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),
  SUB_CAT_CD WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Numeric code which uniquely identifies the Sainsburys Class/Sub Category. It is also called Range/Series in Argos.',
  SUB_CAT_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Name of Sainsburys Class/Sub Category. It is also called Range/Series in Argos. This field is part of Merchandise and Trading Hierarchy.',
  UNIQUE_SEGMENT_CD WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Unique segment code created in Aspire. There are overlapping Segment codes between JS Food (sourced from RMS 09),Non-Food (soured from RMS 10) and with in RMS 10 system, and a logic is applied in Aspire to uniquely identify a segment across business.\n\nFor JS, Concatenation of segment_cd, sub_cat_cd and cat_cd\nFor Argos, UNIQUE_SEGMENT_CD is same as SEGMENT_CD.',
  SEGMENT_CD WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Numeric code which identifies Sainsburys Sub Class/Segment, as well as Argos segments (also known as subsection) from Mainframe.',
  SEGMENT_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Name of the Sub Class/Segment. This field is part of Merchandise and Trading Hierarchy.',
  OWN_LABEL_FLAG WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'An indicator when set to Y indicates that the Product is a Sainsburys own brand.',
  SUB_BRAND_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'A sub-brand is a product or group of products that operates under the umbrella of a parent Brand, but has its own identity, positioning, and often a target audience. It always appears in the context of the parent Brand and benefits from its reputation while offering a unique value proposition.',
  BRAND_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'A brand is the overarching identity of a company, product, or service. It includes the name, logo, values, and emotional associations that customers recognise and trust.',
  BRAND_OWNER_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Brand Owner is the legal entity or organisation that holds the intellectual property (IP) rights to a brand, which includes ownership of the brand, name, logo, trademarks, and associated assets. There are also instances where an organisation can be licensed to produce and market a range of products within a Brand in these cases many of the responsibilities of Brand Ownership are carried out by the licensee.\n\n In retail and product data systems, the brand owner is often used to identify the source of the brand, especially when the brand name is not explicitly listed on the product.',
  UNIQUE_BRAND_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'There are instances where SKUs may share the same Brand Name, but they are owned by different Brand Owners(legal entities or organisations). To accurately differentiate these instances, a Unique Brand Name is created by combining the Brand Name with the Brand Owner Name. This ensures that each Brand & Brand Owner combination is distinct and avoids ambiguity across SKUs.',
  BRAND_APPROVAL_FLAG WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'If the SKUs to Brand Hierarchy coding is accurate and approved by the Nectar360 team then this flag would be set to TRUE else FALSE',
  BRAND_CODING_STATUS WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Status of the SKUs to Brand Coding from the below set of values\n\nCleaned: SKUs to Brand association is completed by TCS team and ready for review by N360\nApproved: Approved by N360 post review\nCorrections: N360 team has reviewed, but Brand coding needs some corrections\nExcluded: Test or Dump SKUs which doesn''t need to be exposed to downstream\nUncodable: SKUs where an appropriate Brand coding is not possible due to missing relevant information and hence they are uncodable\nPending: Brand discovery is currently pending or in progress',
  SUB_CAT_APPROVAL_STATUS WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'The status column shows if the SKUs are part of a Sub Category code that is marked for inclusion or exclusion in campaign bookings by the N360 team. It has 2 distinct values EXCLUDED and INCLUDED.',
  RECORD_DELETED_FLAG WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'If the flag value is set to Y, it means the item has either been deleted from the source or the information provided is no longer accurate.\n\nThe default value for this flag is N.',
  LOAD_TS WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Date and Time when this record is created'
) WITH TAG (ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = 'v1.0.0', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-data', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@sainsburys.co.uk')
COMMENT = 'This object will provide the latest associations between Products (SKUs) and their corresponding Brands, serving as a product for all the downstream consumers who are interested in the latest information without any need to know the historical data.\n\n Any consumers of this object should take into account the below columns.\n\nSUB_CAT_APPROVAL_STATUS : It has two values ''EXCLUDED'' and ''INCLUDED'', which indicate whether the SKUs are expected to be included for Campaign Booking by the N360 team.\nRECORD_DELETED_FLAG : Only rows where this flag is set to ''N'' should be used.'
AS
Select
    DIM_ITEM.OPERATING_COMPANY_CD,
    ITEM_BRAND_HIST.ITEM_CD,
    DIM_ITEM.ITEM_NAME,
    DIM_ITEM.ITEM_SHORT_NAME,
    DIM_ITEM.BUSINESS_UNIT_DIR_CD,
    DIM_ITEM.BUSINESS_UNIT_DIR_NAME,
    DIM_ITEM.CAT_MANAGER_CD,
    DIM_ITEM.CAT_MANAGER_NAME,
    DIM_ITEM.BUYER_CD,
    DIM_ITEM.BUYER_NAME,
    DIM_ITEM.UNIQUE_SUB_CAT_CD,
    DIM_ITEM.SUB_CAT_CD,
    DIM_ITEM.SUB_CAT_NAME,
    DIM_ITEM.UNIQUE_SEGMENT_CD,
    DIM_ITEM.SEGMENT_CD,
    DIM_ITEM.SEGMENT_NAME,
    DIM_ITEM.OWN_LABEL_FLAG,
    ITEM_BRAND_HIST.SUB_BRAND_NAME,
    ITEM_BRAND_HIST.BRAND_NAME,
    ITEM_BRAND_HIST.BRAND_OWNER_NAME,
    ITEM_BRAND_HIST.UNIQUE_BRAND_NAME,
    ITEM_BRAND_HIST.BRAND_APPROVAL_FLAG,
    coalesce(ITEM_BRAND_HIST.BRAND_CODING_STATUS, 'Pending') as BRAND_CODING_STATUS,
    case when BRAND_SUB_CAT_REF.UNIQUE_SUB_CAT_CD is NULL then 'EXCLUDED' else 'INCLUDED' end as SUB_CAT_APPROVAL_STATUS,
    coalesce(ITEM_BRAND_HIST.TECHNICAL_METADATA:"record_deleted_flag",'N') as RECORD_DELETED_FLAG,
    ITEM_BRAND_HIST.LOAD_TS
from
    ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST ITEM_BRAND_HIST
    INNER JOIN ADW_PROD.ADW_PRODUCT_PL.DIM_ITEM DIM_ITEM
        ON DIM_ITEM.ITEM_CD = ITEM_BRAND_HIST.ITEM_CD
    LEFT OUTER JOIN ADW_UNIFIED_PLATFORM_TACTICAL.BRAND_SUB_CAT_REF
        ON BRAND_SUB_CAT_REF.UNIQUE_SUB_CAT_CD = DIM_ITEM.UNIQUE_SUB_CAT_CD
where
    ITEM_BRAND_HIST.VALID_UNTIL_DT = '31-DEC-9999'
;
