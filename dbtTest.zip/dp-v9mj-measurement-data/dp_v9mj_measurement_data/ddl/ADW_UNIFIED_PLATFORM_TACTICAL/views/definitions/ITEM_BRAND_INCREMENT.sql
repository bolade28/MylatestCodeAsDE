-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_INCREMENT
CREATE OR REPLACE VIEW ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_INCREMENT
 COPY GRANTS (
  SKU WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Unique Item code created for a SKU',
  ITEM_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Full Name of the SKU',
  OWN_LABEL_FLAG WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'An indicator when set to Y indicates that the Product is a Sainsburys own brand.',
  ASPIRE_ITEM_BRAND_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Brand Name that is present in the corresponding ASPIRE tables, DIM_ITEM or DIM_ITEM_HIST',
  SUB_CAT_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Name of Sainsburys Class/Sub Category. It is also called Range/Series in Argos. This field is part of Merchandise and Trading Hierarchy.',
  CAT_MANAGER_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Category manager responsible for managing the buyers under it. This field contains the responsibility name. This field is part of Trading Hierarchy.'
) WITH TAG (ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = 'v1.0.0', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-data', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@sainsburys.co.uk')
COMMENT = 'This object will provide the most recent list of incremental SKUs that need to be updated with Brand information.'
AS
WITH
LIVE_STG AS
(
    select
        try_to_number(to_varchar(record:SKU), 38, 0) as item_cd
    from
        ADW_PROD.ADW_STAGE.SIESTA_PRODUCT_ITMBRD_ITEMBRANDMAP_STAGE
    where
        metadata:source_name = (
            select top 1 lv.metadata:source_name
            from ADW_PROD.ADW_STAGE.SIESTA_PRODUCT_ITMBRD_ITEMBRANDMAP_STAGE as lv
            order by lv.load_ts desc
        )
        and upper(metadata:sheet_name) = 'DIM_ITEM_REFINED'
)
SELECT
    ITEM_BRAND.ITEM_CD AS SKU,
    ITEM_BRAND.ITEM_NAME AS ITEM_NAME,
    ITEM_BRAND.OWN_LABEL_FLAG AS OWN_LABEL_FLAG,
    ITEM_BRAND.BRAND_NAME AS ASPIRE_ITEM_BRAND_NAME,
    ITEM_BRAND.SUB_CAT_NAME AS SUB_CAT_NAME,
    ITEM_BRAND.CAT_MANAGER_NAME AS CAT_MANAGER_NAME
FROM
    ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND ITEM_BRAND
    INNER JOIN ADW_UNIFIED_PLATFORM_TACTICAL.BRAND_SUB_CAT_REF
        ON BRAND_SUB_CAT_REF.UNIQUE_SUB_CAT_CD = ITEM_BRAND.UNIQUE_SUB_CAT_CD
    LEFT OUTER JOIN LIVE_STG
        ON LIVE_STG.ITEM_CD = ITEM_BRAND.ITEM_CD
WHERE
    UPPER(coalesce(ITEM_BRAND.BRAND_CODING_STATUS,'Pending')) NOT IN ('EXCLUDED')
    AND ITEM_BRAND.RECORD_DELETED_FLAG = 'N'
    AND LIVE_STG.ITEM_CD IS NULL
;
