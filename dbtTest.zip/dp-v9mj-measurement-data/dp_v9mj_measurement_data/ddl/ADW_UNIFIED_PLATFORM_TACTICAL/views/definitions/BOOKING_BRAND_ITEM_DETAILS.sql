-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.BOOKING_BRAND_ITEM_DETAILS
CREATE OR REPLACE VIEW ADW_UNIFIED_PLATFORM_TACTICAL.BOOKING_BRAND_ITEM_DETAILS
 COPY GRANTS (
  BOOKING_ID WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'The unique ID of the Booking created in Unified Platform.  This is the Booking ID of the parent booking if linking is performed in Pollen.',
  UNIQUE_BRAND_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'There are instances where SKUs may share the same Brand Name, but they are owned by different Brand Owners(legal entities or organisations). To accurately differentiate these instances, a Unique Brand Name is created by combining the Brand Name with the Brand Owner Name. This ensures that each Brand & Brand Owner combination is distinct and avoids ambiguity across SKUs.',
  BOOKING_NAME WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Name of the booking.  This is the booking name assigned to the Parent Booking.',
  BOOKING_START_DT WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'The start date of the booking (campaign).  This is the first start date of all the media assets in the booking.',
  BOOKING_END_DT WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'The end date of the booking (campaign).  This is the last  end date of all the media assets in the booking.',
  BRAND_ITEM_REF_DT WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'The reference date used to lookup Brand SKU, which is the last item''s Added On Date in the Booking Item Cd List.  For historical records without items'' Added On Date, Booking Start Date will be used.',
  TEST_BOOKING_FLAG WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Any booking containing this attributes ‘true’ as ''Y'' will need to be excluded from MTA measurements while ‘false/null’  as ''N''  will need MTA measurement.',
  BOOKING_ITEM_CD_LIST WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'List of items selected for campaign booking.  This is the combined list of items in the Parent Booking.',
  BOOKING_OFFER_ITEM_CD_LIST WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'List of items selected for campaign booking, contains only skuId attribute in BOOKING_ITEM_CD_LIST.',
  KNOWN_OFFER_ITEM_CD_LIST WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Item Cd List for those items which item-brand data is available.',
  UNKNOWN_OFFER_ITEM_CD_LIST WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Item Cd List for those items which item-brand data is not available.',
  UNIQUE_SUB_CAT_CD_LIST WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'List of Unique Sub Cat Cd on KNOWN_OFFER_ITEM_CD_LIST',
  SUPER_CAT_CD_LIST WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'List of Super Cat Cd on KNOWN_OFFER_ITEM_CD_LIST',
  BRAND_ITEM_CD_LIST WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'SKU belongs to the same brand and unique sub cat cd(s), with respect to the Brand Item Reference Date (BRAND_ITEM_REF_DT), for brand incrementality usage in Pollen Measurement.',
  BOOKING_UNIQUE_BRAND_NAME_LIST WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'List of unique brand name, in the format of “brand_name | brand_owner_name”, derived from BOOKING_ITEM_CD_LIST and item-brand dataset managed by MA Data Team.',
  MUTLI_BRAND_FLAG WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Indicator for multi-brand booking',
  BOOKING_OFFER_ITEM_CD_CNT WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Number of items in the Booking Item Cd List',
  KNOWN_OFFER_ITEM_CD_CNT WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Count of items belongs to the unique brand name with item-brand details available',
  UNKNOWN_OFFER_ITEM_CD_CNT WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Count of items in the Booking Item Cd List with item-brand details not available',
  BRAND_ITEM_CD_CNT WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'ount of items in the BRAND_ITEM_CD_LIST'
) WITH TAG (ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = 'v.1.0.0', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'pollen_data_engineering@sainsburys.co.uk>', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-data')
COMMENT = 'Provide booking id and unique brand name level derived brand-items attributes for media agency channel reporting and pollen measurement.

Data source:
- ADW_PROD.ADW_CUSTOMER_INTERACTIONS_PL.DIM_CAMPAIGN_BOOKING_MEDIA_CHANNEL
- ADW_PROD.ADW_PRODUCT_PL.DIM_ITEM_HIST
- UNIFIED_PLATFORM_<env>.ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST

The grain of this view is BOOKING_ID & UNIQUE_BRAND_NAME.'
AS
with ITEM_BRAND_HIST as (
    /* Avoid getting multiple records per ITEM_NK1 when there is any data issue.  Exclude records without brand details. */
    select  ITEM_CD, VALID_FROM_DT, VALID_UNTIL_DT, UNIQUE_BRAND_NAME
    from    ADW_UNIFIED_PLATFORM_TACTICAL.ITEM_BRAND_HIST
    qualify row_number() over (partition by ITEM_CD, VALID_FROM_DT order by LOAD_TS DESC)=1
    and     coalesce(TECHNICAL_METADATA:RECORD_DELETED_FLAG,'N') = 'N'
    and     UNIQUE_BRAND_NAME is not null
)
, CBMC as (
    /* Extract and derive BOOKING_ID level attributes */
    select BOOKING_ID
        , BOOKING_NAME
        , BOOKING_ITEM_CD_LIST
        , TEST_BOOKING_FLAG
        , min(BOOKING_MEDIA_LIVE_START_DT) BOOKING_START_DT
        , max(BOOKING_MEDIA_LIVE_END_DT) BOOKING_END_DT
    from ADW_PROD.ADW_CUSTOMER_INTERACTIONS_PL.DIM_CAMPAIGN_BOOKING_MEDIA_CHANNEL
    group by all
)
, CBMC_ITEM as (
    /* Flatten BOOKING_ITEM_CD into BOOKING_ID & ITEM_CD */
    /* Use BOOKING_START_DT if addedOn (date) is not available. */
    /* Brand SKU Ref Date is the max of addedOn (date) in the booking, or BOOKING_START_DT id addedOn (date) is not available */
    select CB.BOOKING_ID
        , CB.BOOKING_NAME
        , CB.BOOKING_START_DT
        , CB.BOOKING_END_DT
        , CB.BOOKING_ITEM_CD_LIST
        , CB.TEST_BOOKING_FLAG
        , OUT.VALUE:skuId::NUMBER(38,0) as ITEM_CD
        , coalesce( try_to_timestamp(OUT.VALUE:addedOn::VARCHAR), to_timestamp(TRY_TO_NUMBER(OUT.VALUE:addedOn::VARCHAR),3) )::DATE ADDED_ON_DT
        , coalesce( ADDED_ON_DT, CB.BOOKING_START_DT ) as ITEM_BRAND_REF_DT
        , max(ITEM_BRAND_REF_DT) over (partition by BOOKING_ID) as BRAND_ITEM_REF_DT
    from CBMC CB,
    lateral flatten(input => CB.BOOKING_ITEM_CD_LIST, OUTER => TRUE) OUT
)
, CBMC_ITEM_BOOKING as (
    /* Derive BOOKING_OFFER_ITEM_CD_LIST in BOOKING_ID level. */
    select BOOKING_ID
        , BOOKING_NAME
        , BOOKING_ITEM_CD_LIST
        , BOOKING_START_DT
        , BOOKING_END_DT
        , BRAND_ITEM_REF_DT
        , TEST_BOOKING_FLAG
        , array_agg(distinct CB.ITEM_CD) within group (order by CB.ITEM_CD asc) as BOOKING_OFFER_ITEM_CD_LIST
    from CBMC_ITEM CB
    group by all
)
, CBMC_ITEM_BRAND as (
    /* Lookup item detail and item brand detail in BOOKING_ID & ITEM_CD level by 3 reference dates: addedOn (date), BOOKING_START_DT, BOOKGING_END_DT.
       Extract the earliest available recrod (when available) per BOOKING_ID & ITEM_CD. */
    select 
        CB.BOOKING_ID 
        , CB.BOOKING_START_DT
        , CB.BOOKING_END_DT
        , CB.BOOKING_ITEM_CD_LIST
        , CB.ITEM_BRAND_REF_DT
        , CB.ITEM_CD::NUMBER(38,0) as ITEM_CD
        , CB.BRAND_ITEM_REF_DT
        , IBH.UNIQUE_BRAND_NAME
        , IH.UNIQUE_SUB_CAT_CD
        , IH.SUPER_CAT_CD::NUMBER(38,0) as SUPER_CAT_CD
        , IBH.VALID_FROM_DT IBH_VALID_FROM_DT
        , IBH.VALID_UNTIL_DT
        , IH.VALID_FROM_DT IH_VALID_FROM_DT
        , IH.VALID_UNTIL_DT
    from CBMC_ITEM CB
    -- getting brand detail by ITEM_CD
    left join ITEM_BRAND_HIST IBH 
        on CB.ITEM_CD = IBH.ITEM_CD 
        and  (
                CB.ITEM_BRAND_REF_DT between IBH.VALID_FROM_DT and IBH.VALID_UNTIL_DT
                or CB.BOOKING_START_DT between IBH.VALID_FROM_DT and IBH.VALID_UNTIL_DT
                or CB.BOOKING_END_DT between IBH.VALID_FROM_DT and IBH.VALID_UNTIL_DT
            )
    -- getting unique_sub_cat_cd by ITEM_CD
    left join ADW_PROD.ADW_PRODUCT_PL.DIM_ITEM_HIST IH 
        on IBH.ITEM_CD = IH.item_cd 
        and (
                CB.ITEM_BRAND_REF_DT between IH.VALID_FROM_DT and IH.VALID_UNTIL_DT
                or CB.BOOKING_START_DT between IH.VALID_FROM_DT and IH.VALID_UNTIL_DT
                or CB.BOOKING_END_DT between IH.VALID_FROM_DT and IH.VALID_UNTIL_DT
            )
  qualify row_number() over (partition by CB.BOOKING_ID, CB.ITEM_CD order by IBH.VALID_FROM_DT asc, IH.VALID_FROM_DT asc)=1
)
, CBMC_ITEM_BRAND_FOUND as (
    /* For records with item brand detail found in CBMC_ITEM_BRAND and aggregate attributes in BOOKING_ID & UNIQUE_BRAND_NAME level. */
   select
        BOOKING_ID
        , UNIQUE_BRAND_NAME
        , array_agg(distinct ITEM_CD) within group (order by ITEM_CD asc) as KNOWN_OFFER_ITEM_CD_LIST 
        , array_agg(distinct UNIQUE_SUB_CAT_CD) within group (order by UNIQUE_SUB_CAT_CD asc) as UNIQUE_SUB_CAT_CD_LIST
        , array_agg(distinct SUPER_CAT_CD) within group (order by SUPER_CAT_CD asc) as SUPER_CAT_CD_LIST
    from  CBMC_ITEM_BRAND
    where UNIQUE_BRAND_NAME is not null
    group by BOOKING_ID, UNIQUE_BRAND_NAME
)
, CBMC_ITEM_BRAND_FOUND_BOOKING as (
    /* For reocrds with item brand detail found in CBMC_ITEM_BRAND and aggregate attributes in BOOKING_ID level. */
    select
        BOOKING_ID
        , array_agg(distinct UNIQUE_BRAND_NAME) within group (order by UNIQUE_BRAND_NAME asc) as BOOKING_UNIQUE_BRAND_NAME_LIST 
    from  CBMC_ITEM_BRAND
    where UNIQUE_BRAND_NAME is not null
    group by BOOKING_ID
)
, CBMC_ITEM_BRAND_FOUND_BRAND_SKU as (
    /* For reocrds with item brand detail found in CBMC_ITEM_BRAND, lookup SKU belongs to the same UNIQUE_BRAND_NAME and UNIQUE_SUB_CAT_CD, 
       by BRAND_ITEM_REF_DT.  Aggregate attributes from the result set to BOOKING_ID & UNIQUE_BRAND_NAME level.
   */
    select
        CB.BOOKING_ID
        , CB.UNIQUE_BRAND_NAME
        , CB.BRAND_ITEM_REF_DT
        , array_agg(distinct IBH.ITEM_CD::NUMBER(38,0)) within group (order by IBH.ITEM_CD::NUMBER(38,0) asc) as INT_BRAND_ITEM_CD_LIST
    from  CBMC_ITEM_BRAND CB
    -- getting ITEM_CD with the same BRAND_NAME and UNIQUE_SUB_CAT_CD
    join ITEM_BRAND_HIST IBH 
        on  CB.UNIQUE_BRAND_NAME = IBH.UNIQUE_BRAND_NAME 
        and CB.BRAND_ITEM_REF_DT between IBH.VALID_FROM_DT and IBH.VALID_UNTIL_DT
    --getting unique_sub_cat_cd by BRAND_ITEM_CD
    join ADW_PROD.ADW_PRODUCT_PL.DIM_ITEM_HIST IH 
        on  IH.item_cd = IBH.ITEM_CD 
        and CB.BRAND_ITEM_REF_DT between IH.VALID_FROM_DT and IH.VALID_UNTIL_DT
        and IH.UNIQUE_SUB_CAT_CD = CB.UNIQUE_SUB_CAT_CD
    where CB.UNIQUE_BRAND_NAME is not null
    group by all
)
--select * from CBMC_ITEM_BRAND_FOUND_BRAND_SKU_REF_DT;
, CBMC_ITEM_BRAND_NOT_FOUND as (
    /* For reocrds with item brand detail not in CBMC_ITEM_BRAND and aggregate attributes in BOOKING_ID level  */
    select
        BOOKING_ID
        , BOOKING_ITEM_CD_LIST
        , case when zeroifnull(array_size(BOOKING_ITEM_CD_LIST)) = 0 then NULL else array_agg(distinct ITEM_CD) within group (order by ITEM_CD asc) end as UNKNOWN_OFFER_ITEM_CD_LIST 
    from  CBMC_ITEM_BRAND
    where UNIQUE_BRAND_NAME is null
    group by all
)
select B.BOOKING_ID::VARCHAR(128) as BOOKING_ID
    , F.UNIQUE_BRAND_NAME::VARCHAR(203) as UNIQUE_BRAND_NAME
    , B.BOOKING_NAME
    , B.BOOKING_START_DT::DATE as BOOKING_START_DT
    , B.BOOKING_END_DT::DATE as BOOKING_END_DT
    , B.BRAND_ITEM_REF_DT::DATE as BRAND_ITEM_REF_DT
    , B.TEST_BOOKING_FLAG::VARCHAR(128) as TEST_BOOKING_FLAG
    , coalesce(B.BOOKING_ITEM_CD_LIST,ARRAY_CONSTRUCT())::ARRAY as BOOKING_ITEM_CD_LIST
    , coalesce(B.BOOKING_OFFER_ITEM_CD_LIST,ARRAY_CONSTRUCT())::ARRAY as BOOKING_OFFER_ITEM_CD_LIST
    , coalesce(F.KNOWN_OFFER_ITEM_CD_LIST,ARRAY_CONSTRUCT())::ARRAY as KNOWN_OFFER_ITEM_CD_LIST
    , coalesce(NF.UNKNOWN_OFFER_ITEM_CD_LIST,ARRAY_CONSTRUCT())::ARRAY as UNKNOWN_OFFER_ITEM_CD_LIST
    , coalesce(F.UNIQUE_SUB_CAT_CD_LIST,ARRAY_CONSTRUCT())::ARRAY as UNIQUE_SUB_CAT_CD_LIST
    , coalesce(F.SUPER_CAT_CD_LIST,ARRAY_CONSTRUCT())::ARRAY as SUPER_CAT_CD_LIST
    , ARRAY_SORT(ARRAY_DISTINCT(ARRAY_CAT(coalesce(FS.INT_BRAND_ITEM_CD_LIST,ARRAY_CONSTRUCT()),coalesce(F.KNOWN_OFFER_ITEM_CD_LIST,ARRAY_CONSTRUCT()))))::ARRAY as BRAND_ITEM_CD_LIST
    , coalesce(FB.BOOKING_UNIQUE_BRAND_NAME_LIST,ARRAY_CONSTRUCT()) as BOOKING_UNIQUE_BRAND_NAME_LIST
    , case when zeroifnull(array_size(BOOKING_UNIQUE_BRAND_NAME_LIST))>1 then 'Y' else 'N' end::VARCHAR(1) as MULTI_BRAND_FLAG
    , zeroifnull(array_size(B.BOOKING_OFFER_ITEM_CD_LIST))::NUMBER(38,0) as BOOKING_OFFER_ITEM_CD_CNT
    , zeroifnull(array_size(F.KNOWN_OFFER_ITEM_CD_LIST))::NUMBER(38,0) as KNOWN_OFFER_ITEM_CD_CNT
    , zeroifnull(array_size(NF.UNKNOWN_OFFER_ITEM_CD_LIST))::NUMBER(38,0) as UNKNOWN_OFFER_ITEM_CD_CNT
    , zeroifnull(array_size(BRAND_ITEM_CD_LIST))::NUMBER(38,0) as BRAND_ITEM_CD_CNT
from  CBMC_ITEM_BOOKING B
left join CBMC_ITEM_BRAND_FOUND F using (BOOKING_ID)
left join CBMC_ITEM_BRAND_FOUND_BOOKING FB using (BOOKING_ID)
left join CBMC_ITEM_BRAND_NOT_FOUND NF using (BOOKING_ID)
left join CBMC_ITEM_BRAND_FOUND_BRAND_SKU FS using (BOOKING_ID, UNIQUE_BRAND_NAME);
