{{ config(tags=['unit-test']) }}

{# Define a unit test for the dv__{{project_name}}_1 model #}
{% call dbt_unit_testing.test(
    'ean_br',
    'Test model ean_br for incremental skus from item brand hist table'
) %}

{% call dbt_unit_testing.mock_ref ('base_ean_br_item_hist', options={"input_format": "csv"}) %}
                RECORD_DELETED_FLAG   | ITEM_NK1 | EAN_NAME	                             | EAN_SHORT_NAME        | VALID_FROM_DT         | VALID_TO_DT     |  LOAD_TS               | EAN_NK1 | EAN_NK2 | EAN_NK3  | ITEM_NK2  | ITEM_NK3 | EFFECTIVE_FROM_TS     | EAN_SOURCE_SYSTEM_CD | PRIMARY_EAN_FLAG | BATCH_ID | JOB_NAME | HASH_DIFF | BRAND_NAME | BRAND_OWNER_NAME
                'N'                   | 3994382  | 'Doritos'	                         | 'Orig Corn'           | '2025-06-09 00:00:00' | '9999-12-31'    | '2025-06-09 00:00:00'  | null    | null    | null     |   null    | null     | '2025-06-09 00:00:00' | null                 | 0                | null     | null     | null      | null       |  null
                'N'                   | 8076879  | 'JS Berry Meringue TB 20s 40g'	     | 'JS Merry Berry Meri' | '2025-06-09 00:00:00' | '9999-12-31'    | '2025-06-09 00:00:00'  | null    | null    | null     |   null    | null     | '2025-06-09 00:00:00' | null                 | 0                | null     | null     | null      | null       |  null
                'N'                   | 8076881  | 'JS Mince Pie TB 20s 40g'	         | 'JS Mince Pie TB 20'  | '2025-06-09 00:00:00' | '9999-12-31'    | '2025-06-08 00:00:00'  | null    | null    | null     |   null    | null     | '2025-06-09 00:00:00' | null                 | 0                | null     | null     | null      | null       |  null
                'N'                   | 8076877  | 'JS chicken liver pate  pack 100g'	 | 'chicken liver pate'  | '2025-06-09 00:00:00' | '9999-12-31'    | '2025-06-09 00:00:00'  | null    | null    | null     |   null    | null     | '2025-06-09 00:00:00' | null                 | 0                | null     | null     | null      | null       |  null
                'N'                   | 8076881  | 'JS Mince Pie TB 20 40g'	             | 'JS Mince Pie TB 20'  | '2025-06-08 00:00:00' | '2025-06-08'    | '2025-06-08 00:00:00'  | null    | null    | null     |   null    | null     | '2025-06-09 00:00:00' | null                 | 0                | null     | null     | null      | null       |  null

{% endcall %}

{% call dbt_unit_testing.expect ({"input_format": "csv"}) %}
                RECORD_DELETED_FLAG   | ITEM_NK1| EAN_SHORT_NAME        | VALID_TO_DT    |  EAN_NK1             | BRAND_NAME | BRAND_OWNER_NAME
                'N'                   | 3994382 | 'Orig Corn'           | '9999-12-31'   |  null                | null       | null
                'N'                   | 8076879 | 'JS Merry Berry Meri' | '9999-12-31'   |  null                | null       | null
                'N'                   | 8076881 | 'JS Mince Pie TB 20'  | '9999-12-31'   |  null                | null       | null
                'N'                   | 8076877 | 'chicken liver pate'  | '9999-12-31'   |  null                | null       | null

{% endcall %}

{% endcall %}
