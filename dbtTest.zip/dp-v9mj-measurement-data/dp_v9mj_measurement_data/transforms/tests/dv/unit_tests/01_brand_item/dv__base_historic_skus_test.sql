{{ config(tags=['unit-test']) }}


{# Define a unit test for the dv__{{project_name}}_1 model #}
{% call dbt_unit_testing.test(
    'base_historic_skus',
     'Test model base_historic_skus for creating the base base historic skus table'
) %}

{% call dbt_unit_testing.mock_source  ('ADW_UNIFIED_PLATFORM_TACTICAL', 'ITEM_BRAND_HIST', options={"input_format": "csv"}) %}
              ITEM_CD | ITEM_NAME	                        | ITEM_SHORT_NAME       | VALID_FROM_DT         | VALID_UNTIL_DT
              3994382 | 'Doritos'	                        | 'Orig Corn'           | '2025-06-09 00:00:00' | '9999-12-31'
              8076879 | 'JS Berry Meringue TB 20s 40g'	   | 'JS Merry Berry Meri' | '2025-06-09 00:00:00' | '9999-12-31'
              8076881 | 'JS Mince Pie TB 20s 40g'	   | 'JS Mince Pie TB 20'  | '2025-06-09 00:00:00' | '9999-12-31'
              8076877 | 'JS chicken liver pate  pack 100g' | 'chicken liver pate'  | '2025-06-09 00:00:00' | '9999-12-31'
              8076886 | 'JS duck pate balsamic plum 200g'  | 'duck pate balsamic'  | '2025-06-10 00:00:00' | '9999-12-31'

{% endcall %}

{% call dbt_unit_testing.expect ({"input_format": "csv"}) %}
       ITEM_CD | INSCOPE_DT
       3994382 | '2025-06-10 00:00:00'
       8076879 | '2025-06-10 00:00:00'
       8076881 | '2025-06-10 00:00:00'
       8076877 | '2025-06-10 00:00:00'
       8076886 | '2025-06-10 00:00:00'

{% endcall %}

{% endcall %}
