{% macro ean_brand_update_macro(model) %}

{% set ean_auto_flag_set = var('automated_brand_update_flag') | int %}
    -- logs the target for automated ean brand update process
    {{ log(model, info=true) }}
{% if ean_auto_flag_set == 1 %}
    {{ log("Automated ean brand update is enabled", info=true) }}
    update {{ model }} as target
        set brand_name = source.brand_name
            , brand_owner_name = source.brand_owner_name
            , effective_from_ts = current_timestamp
        from {{ ref('TRANS_EAN_BR_BRAND_MAP_UNIQUE') }} as source
        where target.item_nk1 = source.item_cd
{% else %}
    {{ log("Automated ean brand update is disabled", info=true) }}
    select 1 from {{ model }} limit 1
{% endif %}
{% endmacro %}
