/* {#
This is a macro to output the query ID and number of rows inserted and updated.
If the table is created by dbt then the query ID is sent to stdout.
#} */

{%- macro log_sql_results(tbl_created) -%}

    {% set query %}
        {% if tbl_created == 1 %}
               select last_query_id()
        {% else %}
               select LAST_QUERY_ID(-2), * from table(result_scan(LAST_QUERY_ID(-2)))
        {% endif %}
    {% endset %}

    {% set results = run_query(query) %}

    {# -- execute is a Jinja variable that returns true when dbt is in "execute" mode, i.e. it returns True when running dbt run and returns False during dbt compile. #}
    {% if execute %}

        {% set results_list = results.columns %}
        {% set col1 = results_list[0].values()[0] %}


        {% if tbl_created == 1 %}
            {{ log(" " , info=True)}}
            {{ log("Query ID:" ~ col1 , info=True)}}
            {{ log("Model created table.", info=True)}}
            {{ log(" " , info=True)}}

        {% else %}
            {% set col2 = results_list[1].values()[0] %}

            {% if results_list|length > 2 %}
                {% set col3 = results_list[2].values()[0] %}

            {% else %}
                {% set col3 = 0 %}
            {% endif %}

            {{ log(" " , info=True)}}
            {{ log("Query ID:" ~ col1  , info=True)}}
            {{ log("The number of rows Inserted:" ~ col2 ~ " The Number of rows Updated:" ~ col3, info=True)}}
            {{ log(" " , info=True)}}

        {% endif %}

    {% endif %}

{% endmacro %}
