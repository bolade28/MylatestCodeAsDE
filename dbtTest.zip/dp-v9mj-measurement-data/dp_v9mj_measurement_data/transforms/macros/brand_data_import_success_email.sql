{% macro BRAND_DATA_IMPORT_SUCCESS_EMAIL() %}

    -- For now, these procedures need to be owned/executed under the ETL roles.
    -- We will work with the Snowflake Admin team to add the procedures/tasks
    -- to the appropriate roles in preprod and production.
    -- Therefore, this macro intentionally does nothing in preprod and production.

    {% if target.name == 'dev' %}
        {% do run_query(
            "EXECUTE TASK ADW_UNIFIED_PLATFORM_TACTICAL.TASK_JS_BRAND_SIESTA_UPLOAD_SUMMARY_SUCCESS_EMAIL"
        ) %}
    {% endif %}

{% endmacro %}
