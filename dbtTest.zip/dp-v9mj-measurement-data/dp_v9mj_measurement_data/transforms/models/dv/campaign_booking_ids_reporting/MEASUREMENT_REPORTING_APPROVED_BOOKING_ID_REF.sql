-- This model creates an environment-specific view of booking IDs and their reporting status.
-- The appropriate reporting status column is selected based on the 'env_name' variable.

with booking_ids as (
    select
        booking_id
        , case
            when '{{ var("env_name") }}' = 'dev' then cast(dev_reporting_status as varchar)
            when '{{ var("env_name") }}' = 'preprod' then cast(preprod_reporting_status as varchar)
            when '{{ var("env_name") }}' = 'prod' then cast(prod_reporting_status as varchar)
            else NULL
        end as reporting_status
    from {{ ref('MEASUREMENT_REPORTING_BOOKING_ID_SF') }}
)

select
    booking_id
    , reporting_status
from booking_ids
where reporting_status is not NULL
