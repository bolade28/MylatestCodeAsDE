{{ config(
    materialized='incremental',
    incremental_strategy='merge',
    unique_key=['hash_diff','load_ts']
) }}

select
    item_cd::number(38, 0) as item_cd
    , valid_from_dt::date as valid_from_dt
    , valid_to_dt::date as valid_until_dt
    , (case
        when item_cd is not null
            then concat(brand_name, ' | ', brand_owner_name)
    end)::varchar(203) as unique_brand_name
    , (case
        when
            brand_coding_status = 'Approved'
            and item_cd is not null
            then 'TRUE'
        when
            item_cd is null
            or brand_coding_status is null
            or (brand_name is null and brand_coding_status is null)
            then null
        else 'FALSE'
    end)::varchar(5) as brand_approval_flag
    , brand_coding_status::varchar(50) as brand_coding_status
    , brand_name::varchar(100) as brand_name
    , brand_owner_name::varchar(100) as brand_owner_name
    , sub_brand_name::varchar(100) as sub_brand_name
    , load_ts::timestamp_ntz(9) as load_ts
    , hash_key::varchar(32) as hash_diff
    , object_construct(
        'dbt_load_ts', technical_metadata:dbt_load_ts
        , 'snapshot', technical_metadata:snapshot
        , 'snapshot_source', technical_metadata:snapshot_source
        , 'inscope_item_source', technical_metadata:inscope_item_source
        , 'int_item_brand_hash_key', hash_key
        , 'stage_hash_key', technical_metadata:stage_hash_key
        , 'record_deleted_flag', technical_metadata:record_deleted_flag
        , 'updated_at_ts', technical_metadata:updated_at_ts
        , 'jira_ref', technical_metadata:jira_ref
    )::variant as technical_metadata
from {{ ref('INT_ITEM_BRAND') }}
