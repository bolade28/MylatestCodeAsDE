{{
    config(
        materialized='incremental',
        incremental_strategy='merge',
        unique_key='dbt_scd_id',
        merge_update_columns=['dbt_valid_to', 'technical_metadata'],
        on_schema_change='sync_all_columns'
    )
}}

{% set dbt_scd_id_fields = [
    'update_file.item_cd'
    , 'to_varchar(run_time.run_ts)'
] %}

with run_time as (
    select current_timestamp()::timestamp_ntz as run_ts
)

, latest_file as (
    select
        item_cd
        , brand_name
        , sub_brand_name
        , brand_owner_name
        , brand_coding_status
        , hash_key
        , technical_metadata
    from {{ ref('INT_ITEM_BRAND_MAP') }}
    qualify
        row_number() over (
            partition by item_cd order by technical_metadata desc nulls last
        ) = 1
)

, inscope_items as (
    select distinct
        item_cd
        , null as brand_name
        , null as sub_brand_name
        , null as brand_owner_name
        , null as brand_coding_status
        , {{ dbt_utils.generate_surrogate_key([
            'item_cd'
            , 'brand_name'
            , 'sub_brand_name'
            , 'brand_owner_name'
            , 'brand_coding_status'
        ]) }} as hash_key
        , technical_metadata
    from {{ ref('INT_INSCOPE_ITEM_HIST') }}
    {% if is_incremental() %}
        where not exists (
            select 1
            from {{ this }} as ibi
            where ibi.item_cd = {{ ref('INT_INSCOPE_ITEM_HIST') }}.item_cd
        )
    {% endif %}
)

, update_file_raw as (
    select
        coalesce(latest_file.item_cd, inscope_items.item_cd) as item_cd
        , latest_file.brand_name
        , latest_file.brand_owner_name
        , latest_file.sub_brand_name
        , latest_file.brand_coding_status
        , coalesce(latest_file.hash_key, inscope_items.hash_key) as hash_key
        , coalesce(
            latest_file.technical_metadata, inscope_items.technical_metadata
        ) as technical_metadata
    from latest_file
    full outer join inscope_items
        on latest_file.item_cd = inscope_items.item_cd
)

, update_file as (
    select
        item_cd
        , brand_name
        , brand_owner_name
        , sub_brand_name
        , brand_coding_status
        , hash_key
        , object_insert(
            object_insert(
                object_insert(
                    technical_metadata
                    , 'jira_ref', array_construct(), true
                )
                , 'record_deleted_flag', 'N', true
            )
            , 'updated_at_ts', '', true
        ) as technical_metadata
    from update_file_raw
    qualify row_number() over (
        partition by item_cd
        order by
            (brand_name is not null) desc, technical_metadata desc nulls last
    ) = 1
)

{% if is_incremental() %}

-- In incremental mode, we need to compare against existing active records to determine what has changed and
-- generate appropriate new versions and expirations.
    , current_file as (
        select *
        from {{ this }}
        qualify row_number() over (
            partition by item_cd
            order by dbt_updated_at desc
        ) = 1
    )

    , changed_items as (
        select update_file.item_cd
        from update_file
        inner join current_file
            on update_file.item_cd = current_file.item_cd
        where
            update_file.hash_key is distinct from current_file.hash_key
    )

    , records_to_expire_changed as (
        -- expire the *existing* active version(s)
        select
            current_file.item_cd
            , current_file.brand_name
            , current_file.brand_owner_name
            , current_file.sub_brand_name
            , current_file.brand_coding_status
            , current_file.hash_key
            , object_insert(
                current_file.technical_metadata
                , 'updated_at_ts'
                , run_time.run_ts
                , true
            ) as technical_metadata
            , current_file.dbt_scd_id
            , current_file.dbt_updated_at
            , current_file.dbt_valid_from
            , run_time.run_ts as dbt_valid_to
        from current_file
        inner join changed_items
            on current_file.item_cd = changed_items.item_cd
        cross join run_time
    )

    , new_versions_for_changed as (
        select
            update_file.item_cd
            , update_file.brand_name
            , update_file.brand_owner_name
            , update_file.sub_brand_name
            , update_file.brand_coding_status
            , update_file.hash_key
            , update_file.technical_metadata
            , {{ dbt_utils.generate_surrogate_key(dbt_scd_id_fields) }} as dbt_scd_id
            , run_time.run_ts as dbt_updated_at
            , run_time.run_ts as dbt_valid_from
            , null::timestamp as dbt_valid_to
        from update_file
        inner join changed_items
            on update_file.item_cd = changed_items.item_cd
        cross join run_time
    )

    , new_items as (
        select
            update_file.item_cd
            , update_file.brand_name
            , update_file.brand_owner_name
            , update_file.sub_brand_name
            , update_file.brand_coding_status
            , update_file.hash_key
            , update_file.technical_metadata
            , {{ dbt_utils.generate_surrogate_key(dbt_scd_id_fields) }} as dbt_scd_id
            , run_time.run_ts as dbt_updated_at
            , run_time.run_ts as dbt_valid_from
            , null::timestamp as dbt_valid_to
        from update_file
        left join current_file
            on update_file.item_cd = current_file.item_cd
        cross join run_time
        where current_file.item_cd is null
    )

    , final as (
        select * from records_to_expire_changed
        union all
        select * from new_versions_for_changed
        union all
        select * from new_items
    )

    select * from final

{% else %}

-- For full refresh, we can take the latest file records as is since we are rebuilding the entire history.
select
    update_file.item_cd
    , update_file.brand_name
    , update_file.brand_owner_name
    , update_file.sub_brand_name
    , update_file.brand_coding_status
    , update_file.hash_key
    , update_file.technical_metadata
    , {{ dbt_utils.generate_surrogate_key(dbt_scd_id_fields) }} as dbt_scd_id
    , run_time.run_ts as dbt_updated_at
    , run_time.run_ts as dbt_valid_from
    , cast(null as timestamp) as dbt_valid_to
from update_file
cross join run_time

{% endif %}
