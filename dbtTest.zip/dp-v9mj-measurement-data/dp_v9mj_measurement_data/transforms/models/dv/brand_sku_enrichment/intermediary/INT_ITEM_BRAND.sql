select
    item_cd
    , brand_name
    , brand_owner_name
    , sub_brand_name
    , brand_coding_status
    , dbt_valid_from::date as valid_from_dt
    , coalesce(
        greatest(dateadd(day, -1, dbt_valid_to::date), dbt_valid_from::date)
        , '9999-12-31'::date
    ) as valid_to_dt
    , hash_key
    , dbt_updated_at as load_ts
    , object_construct(
        'model', '{{ this.name }}'
        , 'dbt_load_ts', dbt_updated_at
        , 'snapshot', '{{ ref("INT_ITEM_BRAND_INCREMENTAL") }}'
        , 'snapshot_source', '{{ ref("INT_ITEM_BRAND_MAP") }}'
        , 'inscope_item_source', '{{ ref("INT_INSCOPE_ITEM_HIST") }}'
        , 'stage_hash_key', hash_key
        , 'dbt_snapshot_id', dbt_scd_id
        , 'record_deleted_flag', technical_metadata:record_deleted_flag
        , 'updated_at_ts', technical_metadata:updated_at_ts
        , 'jira_ref', technical_metadata:jira_ref
    ) as technical_metadata
from {{ ref('INT_ITEM_BRAND_INCREMENTAL') }}
