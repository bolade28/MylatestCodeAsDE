{#/**************************************************************************

* Objective:
    - This script is used to update ean_Br table with the information
      item_nk1, valid_from_dt, valif_until_dt from item_brand_hist..

* Business Context:
    - Currently ean_Br table offers required informations of item skus, brand and related information
       that was a one-off update from stratgeic ean_br. Now we need incremental skus from dim_item_hist to
      further unblock data science and measurement before launch.
      Skus picked from max of last valid_from_dt at this stage since both has same outcome at this stage

      The Item_Brand_Hist forms a source of truth of brands and brand owners of item skus
      1. it has unique entries at item_cd level for one-off and incremental load.
      2. For skus with sales: only latest items skus with sales after 1st Jan 2022.
      3. For non-sales skus:
      4. Any non sales skus since last 14 days prior to last record updated is considered.

* Lineage:
    Upstream:
        - Nothing here
    Downstream:
        - tba

* Confluence:
    https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/

* Owner : Tanya PuthumanaJosep

******************************************************************************/#}
{# {{ log("Creating item brand hist table table", info=True ) }} #}
-- Setting DBT Configuration Parameters
{{
    config(
        materialized='incremental'
        , incremental_strategy='merge'
        , transient=False
        , name = 'ean_br'
        , tags=['DP_V9MJ_MEASUREMENT_DATA_ETL']
        , post_hook = "{{ ean_brand_update_macro(this) }} "
    )
}}

{% set automated_brand_update_flag = var('automated_brand_update_flag') %}
{% set max_valid_to_dt = "'9999-12-31'" %}

{{ log("Creating item brand hist table table with automated_brand update flag set to " ~ automated_brand_update_flag, info=True ) }}
-- Reading inscope skus
with latest_inscope_ean_skus as (
    select * from {{ ref('TRANS_EAN_BR_ITEM') }}
)

{% if automated_brand_update_flag == 1 %}
, latest_item_brand_map as (
    select
        item_cd
        , brand_name
        , brand_owner_name
    from {{ ref('TRANS_EAN_BR_BRAND_MAP_UNIQUE') }}
)
{% endif %}

, ean_inscope_source_merged as (
    select
        les.item_cd as item_nk1
        , les.valid_from_dt
        , les.load_ts
        , les.ean_nk1
        , les.ean_nk2
        , les.ean_nk3
        , les.item_nk2
        , les.item_nk3
        , les.ean_name
        , les.ean_short_name
        , les.ean_source_system_cd
        , les.primary_ean_flag
        , les.valid_until_dt
        , les.record_deleted_flag
        , les.batch_id
        , les.job_name
        , les.hash_diff
        , current_timestamp as effective_from_ts
        {% if automated_brand_update_flag == 1 %}
        , coalesce(
            libm.brand_name
            , les.brand_name
        ) as brand_name
        , coalesce(
            libm.brand_owner_name
            , les.brand_owner_name
        ) as brand_owner_name
        {% else %}
            , null as brand_name
            , null as brand_owner_name
        {% endif %}
    from latest_inscope_ean_skus as les
    {% if automated_brand_update_flag == 1 %}
    left join latest_item_brand_map as libm
    on les.item_cd = libm.item_cd
    {% endif %}
)

{% if is_incremental() %}

    , ean_inscope_new as (
        select ean_inscope_source_merged.*
        from ean_inscope_source_merged
        where not exists (
            select 1
            from {{ this }} as latest
            where
                ean_inscope_source_merged.item_nk1 = latest.item_nk1
                and ean_inscope_source_merged.valid_until_dt = to_date(
                    {{ max_valid_to_dt }}
                )
        )
    )

    select
        item_nk1::number(38, 0) as item_nk1
        , ean_nk1::number(38, 0) as ean_nk1
        , ean_nk2::varchar as ean_nk2
        , ean_nk3::varchar as ean_nk3
        , load_ts::varchar as load_ts
        , item_nk2::varchar as item_nk2
        , item_nk3::varchar as item_nk3
        , ean_name::varchar as ean_name
        , ean_short_name::varchar as ean_short_name
        , ean_source_system_cd::varchar as ean_source_system_cd
        , valid_from_dt::varchar as valid_from_dt
        , to_date({{ max_valid_to_dt }})::varchar as valid_to_dt
        , 'N'::varchar as record_deleted_flag
        , batch_id::varchar as batch_id
        , job_name::varchar as job_name
        , hash_diff::varchar as hash_diff
        , current_timestamp::varchar as effective_from_ts
        , 0::boolean as primary_ean_flag
        , brand_name::varchar as brand_name
        , brand_owner_name::varchar as brand_owner_name
    from ean_inscope_new

{% else %}

-- Casting all columns to the datatypes
-- formats of the already existing table's
-- columns to prevent errors
select
    cast(item_nk1 as number(38, 0)) as item_nk1
    , cast(ean_nk1 as number(38, 0)) as ean_nk1
    , cast(ean_nk2 as varchar) as ean_nk2
    , cast(ean_nk3 as varchar) as ean_nk3
    , cast(load_ts as varchar) as load_ts
    , cast(item_nk2 as varchar) as item_nk2
    , cast(item_nk3 as varchar) as item_nk3
    , cast(ean_name as varchar) as ean_name
    , cast(ean_short_name as varchar) as ean_short_name
    , cast(ean_source_system_cd as varchar) as ean_source_system_cd
    , cast(valid_from_dt as varchar) as valid_from_dt
    , cast(to_date({{ max_valid_to_dt }}) as varchar) as valid_to_dt
    , cast('N' as varchar) as record_deleted_flag
    , cast(batch_id as varchar) as batch_id
    , cast(job_name as varchar) as job_name
    , cast(hash_diff as varchar) as hash_diff
    , cast(current_timestamp as varchar) as effective_from_ts
    , cast(0 as boolean) as primary_ean_flag
    , cast(brand_name as varchar) as brand_name
    , cast(brand_owner_name as varchar) as brand_owner_name
from ean_inscope_source_merged

{% endif %}
