{#/**************************************************************************

* Objective:
    - This script is used to generate the source of truth for identifying skus in scope for ean_br table
      with the information item_nk1, valid_from_dt, valid_until_dt from item_brand_hist..

* Business Context:
    - Currently ean_Br table offers required informations of item skus, brand and related information
       that was a one-off update from stratgeic ean_br. Now we need incremental skus from dim_item_hist to
      further unblock data science and measurement before launch.
      Skus picked from max of last valid_from_dt at this stage since both has same outcome at this stage

      The Item_Brand_Hist forms a source of truth of brands and brand owners of item skus
      1. it has unique entries at item_cd level for one-off and incremental load.
      2. For skus with sales: only latest items skus with sales after 1st Jan 2022.
      3. For non-sales skus:
      4. Any non sales skus since last 14 days prior to last record updated is considered.

* Lineage:
    Upstream:
        - Nothing here
    Downstream:
        - tba

* Confluence:
    https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/

* Owner : Tanya PuthumanaJosep

******************************************************************************/#}
{# {{ log("Preparing ean skus from item_brand_hist table", info=True ) }} #}
-- Setting DBT Configuration Parameters
{{
    config(
        materialized='table'
    )
}}

-- Reading inscope skus
with latest_inscope_ean_skus as (
    select
        valid_from_dt
        , valid_until_dt
        , item_cd
        , load_ts
        , null as ean_nk1
        , null as ean_nk2
        , null as ean_nk3
        , null as item_nk2
        , null as item_nk3
        , null as ean_name
        , null as ean_short_name
        , null as ean_source_system_cd
        , null as batch_id
        , null as job_name
        , null as hash_diff
        , brand_name
        , brand_owner_name
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'ITEM_BRAND_HIST') }}
    where valid_until_dt = TO_DATE('9999-12-31')
)

select
    cast(item_cd as number(38, 0)) as item_cd
    , cast(ean_nk1 as number(38, 0)) as ean_nk1
    , cast(ean_nk2 as varchar) as ean_nk2
    , cast(ean_nk3 as varchar) as ean_nk3
    , cast(load_ts as varchar) as load_ts
    , cast(item_nk2 as varchar) as item_nk2
    , cast(item_nk3 as varchar) as item_nk3
    , cast(ean_name as varchar) as ean_name
    , cast(ean_short_name as varchar) as ean_short_name
    , cast(ean_source_system_cd as varchar) as ean_source_system_cd
    , cast(valid_from_dt as varchar) as valid_from_dt
    , cast('N' as varchar) as record_deleted_flag
    , cast(batch_id as varchar) as batch_id
    , cast(job_name as varchar) as job_name
    , cast(hash_diff as varchar) as hash_diff
    , cast(current_timestamp as varchar) as effective_from_ts
    , cast(valid_until_dt as date) as valid_until_dt
    , cast(0 as boolean) as primary_ean_flag
    , cast(brand_name as varchar) as brand_name
    , cast(brand_owner_name as varchar) as brand_owner_name
from latest_inscope_ean_skus
