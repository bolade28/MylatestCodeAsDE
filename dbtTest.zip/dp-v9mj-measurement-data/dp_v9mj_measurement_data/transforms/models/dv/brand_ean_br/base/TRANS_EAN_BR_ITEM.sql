{#/**************************************************************************

* Objective:
    - An intermediate layer to transform inscope data for identifying skus in item_brand_hist and ean_br table
      with the information item_nk1, valid_from_dt, valid_until_dt from item_brand_hist..

* Business Context:
    - Currently ean_Br table offers required informations of item skus, brand and related information
       that was a one-off update from stratgeic ean_br. Now we need incremental skus from dim_item_hist to
      further unblock data science and measurement before launch.
      Skus picked from max of last valid_from_dt at this stage since both has same outcome at this stage

      The Item_Brand_Hist forms a source of truth of brands and brand owners of item skus
      1. it has unique entries at item_cd level for one-off and incremental load.
      2. For skus with sales: only latest items skus with sales after 1st Jan 2022.
      3. For non-sales skus:
      4. Any non sales skus since last 14 days prior to last record updated is considered.

* Lineage:
    Upstream:
        - Nothing here
    Downstream:
        - tba

* Confluence:
    https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/

* Owner : Tanya PuthumanaJosep

******************************************************************************/#}
{# {{ log("Preparing ean skus from item_brand_hist table", info=True ) }} #}
-- Setting DBT Configuration Parameters
{{
    config(
        materialized='table'
    )
}}

-- Reading isncope skus
select
    valid_from_dt
    , valid_until_dt
    , item_cd
    , load_ts
    , ean_nk1
    , ean_nk2
    , ean_nk3
    , effective_from_ts
    , item_nk2
    , item_nk3
    , ean_name
    , ean_short_name
    , ean_source_system_cd
    , primary_ean_flag
    , record_deleted_flag
    , batch_id
    , job_name
    , hash_diff
    , brand_name
    , brand_owner_name
from {{ ref('BASE_EAN_BR_ITEM_HIST') }}
order by 1 desc
