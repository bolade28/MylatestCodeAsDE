select
    item_cd
    , brand_name
    , brand_owner_name
    , technical_metadata
from {{ ref('INT_ITEM_BRAND_MAP') }}
where upper(brand_coding_status) in ('APPROVED', 'CLEANED', 'CORRECTIONS')
