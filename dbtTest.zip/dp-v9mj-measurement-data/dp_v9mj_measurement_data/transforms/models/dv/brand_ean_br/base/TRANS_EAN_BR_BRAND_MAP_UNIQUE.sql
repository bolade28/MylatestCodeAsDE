select
    item_cd
    , brand_name
    , brand_owner_name
from {{ ref('BASE_EAN_BR_ITEM_BRAND_MAP') }}
qualify
    row_number() over (
        partition by
            item_cd
        order by technical_metadata:load_ts::timestamp desc nulls last
    ) = 1
