{% set whitespace_pattern = "'[[:space:]]+'" %}

with sanitised as (

    -- Remove hidden/control characters from source text fields and cast columns to expected types.
    select
        replace(
            replace(
                replace(
                    replace(
                        replace(
                            replace(
                                replace(
                                    brand_name::varchar(100),
                                    chr(160), ' '       -- Non-breaking space
                                ),
                                chr(9), ' '            -- Tab
                            ),
                            chr(10), ' '              -- New line
                        ),
                        chr(13), ' '                  -- Carriage return
                    ),
                    chr(8203), ''                     -- Zero-width space
                ),
                chr(8206), ''                         -- LRM
            ),
            chr(8207), ''                             -- RLM
        ) as brand_name
        , replace(
            replace(
                replace(
                    replace(
                        replace(
                            replace(
                                replace(
                                    subbrand_name::varchar(100),
                                    chr(160), ' '       -- Non-breaking space
                                ),
                                chr(9), ' '            -- Tab
                            ),
                            chr(10), ' '              -- New line
                        ),
                        chr(13), ' '                  -- Carriage return
                    ),
                    chr(8203), ''                     -- Zero-width space
                ),
                chr(8206), ''                         -- LRM
            ),
            chr(8207), ''                             -- RLM
        ) as sub_brand_name
        , replace(
            replace(
                replace(
                    replace(
                        replace(
                            replace(
                                replace(
                                    brand_owner_name::varchar(100),
                                    chr(160), ' '       -- Non-breaking space
                                ),
                                chr(9), ' '            -- Tab
                            ),
                            chr(10), ' '              -- New line
                        ),
                        chr(13), ' '                  -- Carriage return
                    ),
                    chr(8203), ''                     -- Zero-width space
                ),
                chr(8206), ''                         -- LRM
            ),
            chr(8207), ''                             -- RLM
        ) as brand_owner_name
        , item_cd::number(38, 0) as item_cd
        , brand_coding_status::varchar(50) as brand_coding_status
        , technical_metadata

    from {{ ref('STG_ITEM_BRAND_MAP') }}
)

, cleaned as (

    -- Trim values and collapse repeated whitespace to standardise business-facing text fields.
    select
        regexp_replace(trim(brand_name), {{ whitespace_pattern }}, ' ') as brand_name
        , regexp_replace(trim(sub_brand_name), {{ whitespace_pattern }}, ' ') as sub_brand_name
        , regexp_replace(trim(brand_owner_name), {{ whitespace_pattern }}, ' ') as brand_owner_name
        , item_cd
        , brand_coding_status
        , technical_metadata

    from sanitised

)

select
    brand_name
    , sub_brand_name
    , brand_owner_name
    , item_cd
    , brand_coding_status
    , {{ dbt_utils.generate_surrogate_key([
           'item_cd'
           , 'brand_name'
           , 'sub_brand_name'
           , 'brand_owner_name'
           , 'brand_coding_status'
       ]) }} as hash_key
    , technical_metadata
from cleaned
