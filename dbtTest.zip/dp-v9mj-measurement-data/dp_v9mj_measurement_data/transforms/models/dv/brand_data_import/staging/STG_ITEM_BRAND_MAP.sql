select
    -- parse JSON into columns
    nullif(to_varchar(record:BRAND_NAME), '') as brand_name
    , nullif(to_varchar(record:SUBBRAND_NAME), '') as subbrand_name
    , nullif(to_varchar(record:BRAND_OWNER_NAME), '') as brand_owner_name
    , try_to_number(to_varchar(record:SKU), 38, 0) as item_cd
    , nullif(to_varchar(record:APPROVED), '') as brand_coding_status
    -- get technical metadata
    , object_construct(
        'run_uuid', metadata:run_uuid
        , 'sheet_name', metadata:sheet_name
        , 'source_hash', metadata:source_hash
        , 'source_name', metadata:source_name
        , 'load_ts', load_ts
        , 'source_system_cd', 'ITMBRD'
    ) as technical_metadata
from {{ source('ADW_STAGE','SIESTA_PRODUCT_ITMBRD_ITEMBRANDMAP_STAGE') }}
where
    -- filter to the latest filename based on LOAD_TS
    metadata:source_name = (
        select top 1 lv.metadata:source_name
        from {{ source('ADW_STAGE','SIESTA_PRODUCT_ITMBRD_ITEMBRANDMAP_STAGE') }} as lv
        order by lv.load_ts desc
    )
    -- filter to only the relevant sheet
    and metadata:sheet_name = 'dim_item_refined'
