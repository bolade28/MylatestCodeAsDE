-- Capture sub-category filters provided at runtime; default to an empty list for scheduled runs.
{% set manual_sub_cat_codes = var('unique_sub_cat_cd', []) %}

{{ log("Runtime sub-category filter: " ~ manual_sub_cat_codes, info=True) }}

with dim_item_hist_base as (
    select
        item_cd
        , item_name
        , valid_from_dt
        , valid_until_dt
        , load_ts
        , operating_company_cd
        , unique_sub_cat_cd
        , record_deleted_flag
        , min(valid_from_dt) over (partition by item_cd) as first_arrival_dt
    from {{ source('ADW_PRODUCT_PL', 'DIM_ITEM_HIST') }}
    qualify row_number() over (
        partition by item_cd
        order by valid_until_dt desc
    ) = 1
)

, dim_item_hist_filtered as (
    select
        item_cd
        , valid_from_dt
        , valid_until_dt
        , first_arrival_dt
        , load_ts
    from dim_item_hist_base
    where
        item_cd > 0
        and upper(item_name) not like '%DO_NOT_USE%'
        and upper(item_name) not like '%DO_NOT_DISPLAY%'
        and upper(item_name) not like '%DUMMY%'
        and item_name is not null
        and operating_company_cd = 1

        -- Use the runtime sub-category filter when supplied, else default to seeded in-scope values.
        {% if manual_sub_cat_codes | length > 0 %}
            and unique_sub_cat_cd in (
                {% for sub_cat_cd in manual_sub_cat_codes %}
                    '{{ sub_cat_cd }}'{% if not loop.last %}, {% endif %}
                {% endfor %}
            )
        {% else %}
            and unique_sub_cat_cd in (
                select brand_sub_cat.unique_sub_cat_cd
                from {{ ref('BRAND_SUB_CATEGORY_REF') }} as brand_sub_cat
            )
        {% endif %}

        and coalesce(record_deleted_flag, 'N') = 'N'
)

select
    item_cd
    , valid_from_dt
    , valid_until_dt
    , first_arrival_dt
    , load_ts
    , {{ dbt_utils.generate_surrogate_key([
                'item_cd'
                , 'load_ts'
        ]) }} as hash_key
from dim_item_hist_filtered
