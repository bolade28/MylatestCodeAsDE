with item_union as (
    select
        item_cd
        , 'INT_SALE_ITEM_INCREMENTAL' as sku_source
        , 1 as source_flag
        , last_sale_dt
        , load_ts
        , hash_key
    from {{ ref('INT_SALE_ITEM_INCREMENTAL') }}
    union all
    select
        item_cd
        , 'INT_NON_SALE_ITEM' as sku_source
        , 2 as source_flag
        , null as last_sale_dt
        , load_ts
        , hash_key
    from {{ ref('INT_NON_SALE_ITEM') }}
)

, item_dedup as (
    select
        item_cd
        , sku_source
        , last_sale_dt
        , load_ts
        , hash_key
    from item_union
    qualify row_number() over (partition by item_cd order by source_flag asc) = 1
)

select
    dih.item_cd
    , new_items.last_sale_dt
    , {{ dbt_utils.generate_surrogate_key(['dih.item_cd']) }} as hash_key
    , new_items.load_ts
    , object_construct(
        'model', '{{ this.name }}'
        , 'load_ts', new_items.load_ts
        , 'hash_key', new_items.hash_key
        , 'sales_data_item_source', '{{ source("ADW_SALES_PL", "FACT_SALE_TRANSACTION_ITEM") }}'
        , 'sales_data_basket_source', '{{ source("ADW_SALES_PL", "FACT_SALE_TRANSACTION_BASKET") }}'
        , 'inscope_item_source', '{{ ref("INT_SALE_ITEM_INCREMENTAL") }}'
        , 'dim_item_hist_skus', '{{ ref("INT_ITEM_HIST") }}'
        , 'dbt_run_id', '{{ invocation_id }}'
    ) as technical_metadata
-- We join back to the int_item_hist view to ensure we only pull in items with sales transactions that are
-- in our int_item_hist.
from {{ ref('INT_ITEM_HIST') }} as dih
inner join item_dedup as new_items
    on dih.item_cd = new_items.item_cd
