{{
    config(
        materialized = 'incremental',
        incremental_strategy = 'merge',
        unique_key = 'item_cd',
        on_schema_change = 'append_new_columns'
    )
}}

{% set min_transaction_dt = "'2022-01-01'::date" %}

-- Incremental watermark with 2-day backfill buffer
{% if is_incremental() %}
    {% set watermark %}
        (
            select dateadd(day, -2, coalesce(max(last_aspire_arrival_ts::date), {{ min_transaction_dt }}))
            from {{ this }}
        )
    {% endset %}
{% endif %}

with sales_transactions_base as (
    select
        ti.item_cd
        , tb.transaction_dt
        , tb.aspire_arrival_ts
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM') }} as ti
    inner join {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET') }} as tb
        on ti.transaction_id = tb.transaction_id
    where
        -- Filter for relevant sales channels
        tb.sales_origination_channel_cd in (14, 16, 17, 19, 20, 21, 29)

        {% if not is_incremental() %}
            and ti.transaction_dt::date >= {{ min_transaction_dt }}
            and tb.transaction_dt::date >= {{ min_transaction_dt }}
        {% endif %}

        {% if is_incremental() %}
        -- Ensure both item and basket records are incrementally aligned
            and ti.aspire_arrival_ts::date >= ({{ watermark }})
            and tb.aspire_arrival_ts::date >= ({{ watermark }})
        {% endif %}
)

, sales_transaction_agg as (
    select
        item_cd
        , max(transaction_dt) as last_sale_dt
        , max(aspire_arrival_ts) as last_aspire_arrival_ts
    from sales_transactions_base
    group by item_cd
)

select
    item_cd
    , last_sale_dt
    , last_aspire_arrival_ts
    , current_timestamp()::timestamp_ntz as load_ts
    , {{ dbt_utils.generate_surrogate_key([
        'item_cd'
    ]) }} as hash_key
    , '{{ invocation_id }}' as dbt_run_id
from sales_transaction_agg
