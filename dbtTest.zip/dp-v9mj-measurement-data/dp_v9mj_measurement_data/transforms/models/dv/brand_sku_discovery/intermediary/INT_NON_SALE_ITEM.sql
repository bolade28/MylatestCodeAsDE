with newly_stocked_items as (
    select
        item_cd
        , valid_from_dt
        , first_arrival_dt
    from {{ ref('INT_ITEM_HIST') }}

    -- When no explicit sub-category filter is passed, limit to the recent onboarding window.
    {% if var('unique_sub_cat_cd', []) | length == 0 %}
    where first_arrival_dt >= dateadd(day, -14, current_date())
    {% endif %}
)

select
    item_cd
    , valid_from_dt
    , current_timestamp()::timestamp_ntz as load_ts
    , {{ dbt_utils.generate_surrogate_key([
            'item_cd'
        ]) }} as hash_key
    , '{{ invocation_id }}' as dbt_run_id
from newly_stocked_items
