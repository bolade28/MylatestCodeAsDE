with item_union as (
    select
        item_cd
        , 'INT_ITEM_BRAND_INCREMENTAL' as sku_source
        , 1 as source_flag
    from {{ ref('INT_ITEM_BRAND_INCREMENTAL') }}
    union all
    select
        item_cd
        , 'INT_INSCOPE_ITEM_HIST' as sku_source
        , 2 as source_flag
    from {{ ref('INT_INSCOPE_ITEM_HIST') }}
)

, item_dedup as (
    select
        item_cd
        , sku_source
    from item_union
    qualify row_number() over (partition by item_cd order by source_flag asc) = 1
)

select
    item_cd
    , {{ dbt_utils.generate_surrogate_key(['item_cd']) }} as hash_key
    , object_construct(
        'model', '{{ this.name }}'
        , 'load_ts', '{{ run_started_at }}'
        , 'sku_source', sku_source
        , 'stage_file_sku_source', '{{ ref("INT_ITEM_BRAND_INCREMENTAL") }}'
        , 'inscope_item_source', '{{ ref("INT_INSCOPE_ITEM_HIST") }}'
        , 'dbt_run_id', '{{ invocation_id }}'
    ) as technical_metadata
from item_dedup
