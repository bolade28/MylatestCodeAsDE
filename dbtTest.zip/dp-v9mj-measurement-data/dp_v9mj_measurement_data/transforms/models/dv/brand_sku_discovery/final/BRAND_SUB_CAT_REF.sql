{{
    config(
        materialized='incremental',
        transient=False,
        name='brand_sub_cat_ref',
        incremental_strategy='merge',
        unique_key=['UNIQUE_SUB_CAT_CD','SUB_CAT_CD'])
}}

with sub_categories as (
    select distinct
        unique_sub_cat_cd
        , sub_cat_cd
        , sub_cat_name
    from {{ source('ADW_PRODUCT_PL', 'DIM_ITEM') }}
)

select
    sub_cat.unique_sub_cat_cd
    , item_sub_cat.sub_cat_cd
    , item_sub_cat.sub_cat_name
from {{ ref('STG_BRAND_UNQ_SUB_CAT') }} as sub_cat
inner join sub_categories as item_sub_cat
    on sub_cat.unique_sub_cat_cd = item_sub_cat.unique_sub_cat_cd
