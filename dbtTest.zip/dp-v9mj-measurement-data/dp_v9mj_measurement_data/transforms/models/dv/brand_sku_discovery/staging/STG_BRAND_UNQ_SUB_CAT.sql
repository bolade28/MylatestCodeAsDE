select distinct unique_sub_cat_cd
from {{ ref('BRAND_UNQ_SUB_CAT_SF') }}
where consider_for_brand_cleaning = 'INCLUDE'
