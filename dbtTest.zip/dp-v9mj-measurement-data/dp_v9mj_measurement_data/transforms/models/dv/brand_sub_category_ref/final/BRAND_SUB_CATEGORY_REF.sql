{{
    config(
        materialized='incremental',
        transient=False,
        name='brand_sub_category_ref',
        incremental_strategy='delete+insert'
    )
}}
select
    unique_sub_cat_cd
    , sub_cat_cd
    , sub_cat_name
from {{ ref('INT_BRAND_SUB_CATEGORY_REF') }}
