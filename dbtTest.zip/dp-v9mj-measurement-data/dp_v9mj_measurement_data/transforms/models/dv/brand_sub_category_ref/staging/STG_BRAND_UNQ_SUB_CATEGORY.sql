with latest_batch as (
    select batch_id
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'STG_BRAND_UNQ_SUB_CATG') }}
    qualify row_number() over (order by load_ts desc) = 1
)
select
    stg.message:unique_sub_cat_cd::varchar(128) as unique_sub_cat_cd
    , stg.message:consider_for_brand_cleaning::varchar(128) as consider_for_brand_cleaning
from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'STG_BRAND_UNQ_SUB_CATG') }} as stg
inner join latest_batch as lb
    on stg.batch_id = lb.batch_id
where stg.message:consider_for_brand_cleaning = 'INCLUDE'
qualify row_number() over (
    partition by stg.message:unique_sub_cat_cd::varchar, stg.message:consider_for_brand_cleaning::varchar
    order by stg.load_ts desc
) = 1
