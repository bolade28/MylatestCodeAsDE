# Contributing to `dp-v9mj-measurement-data`

Thank you for contributing to the V9MJ Measurement Data product. This guide explains how to make changes safely and consistently across dbt models, pipeline configuration, documentation, and Snowflake operational artefacts.

## 📋 Table of contents

- [What this repository contains](#what-this-repository-contains)
- [Before you start](#before-you-start)
- [Local setup](#local-setup)
- [Development workflow](#development-workflow)
- [Making changes](#making-changes)
- [Code standards](#code-standards)
- [Testing requirements](#testing-requirements)
- [Pull request process](#pull-request-process)
- [Project structure](#project-structure)
- [Getting help](#getting-help)

## 🧭 What this repository contains

This repository contains:

- dbt models and macros for measurement-data pipelines
- pipeline configuration under `dp_v9mj_measurement_data/configs/`
- generated or managed Snowflake DDL under `dp_v9mj_measurement_data/ddl/`
- operational runbooks under `migrations/snowflake-operations/`
- documentation for contributors and operators

The main dbt project lives in:

`dp_v9mj_measurement_data/transforms/`

When running dbt commands locally, run them from that directory unless you are using a wrapper script or your IDE is already configured to do so.

## 🚀 Before you start

Before contributing, make sure you have:

1. Completed the [GRID prerequisites](https://data-platforms-docs.ext.prd.jspaas.uk/grid/)
2. Set up a local Python virtual environment
3. Installed repository dependencies
4. Configured your Snowflake connection
5. Installed pre-commit hooks

## 💻 Local setup

Clone the repository and install dependencies:

```bash
git clone https://github.com/sainsburys-tech/dp-v9mj-measurement-data.git
cd dp-v9mj-measurement-data
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -r requirements-dev.txt
pre-commit install
```

Then configure your Snowflake connection using `profiles.yml` and the GRID connection guide:

- [Connect to Snowflake](https://data-platforms-docs.ext.prd.jspaas.uk/grid/grid-dbt/getting-started/connect_to_snowflake/?h=connect)

## 🔄 Development workflow

### 1. Create a branch

Use the branch naming format:

`<JIRA_TICKET_ID>-brief-description`

Examples:

- `RTD-12345-add-new-model`
- `RTD-12346-fix-data-quality-issue`
- `RTD-12347-update-documentation`

```bash
git checkout -b <JIRA_TICKET_ID>-brief-description
```

### 2. Use conventional commits

This repository follows [Conventional Commits](https://www.conventionalcommits.org/) with the Jira ticket ID as the scope.

Format:

`<type>(<JIRA_TICKET_ID>): <description>`

Common types:

- `feat` - new feature
- `fix` - bug fix
- `docs` - documentation changes
- `style` - formatting or non-functional cleanup
- `refactor` - internal refactoring
- `test` - adding or updating tests
- `chore` - maintenance work

Examples:

```text
feat(RTD-12345): add snapshot for SCD Type 2 tracking
fix(RTD-12346): correct brand_coding_status field length
docs(RTD-12347): update setup instructions
test(RTD-12348): add unit tests for staging model
refactor(RTD-12349): simplify brand history model using dbt snapshots
```

### 3. Keep changes focused

Prefer small, reviewable pull requests. If a change touches multiple areas, describe clearly why they belong together.

Examples:

- dbt model + matching `schema.yml` updates + tests
- pipeline config change + related macro change + supporting runbook
- documentation-only improvements in a dedicated PR

## 🛠️ Making changes

Choose the guidance below based on the type of change you are making.

### dbt model changes

1. Create or update the model in the correct layer.
2. Add or update documentation in the relevant `schema.yml`.
3. Add tests where appropriate.
4. Run the affected model locally.
5. Run the relevant tests locally.

Run dbt commands from `dp_v9mj_measurement_data/transforms/`:

```bash
cd dp_v9mj_measurement_data/transforms
dbt deps
dbt run --select your_model_name
dbt test --select your_model_name
```

For a combined run/test workflow:

```bash
cd dp_v9mj_measurement_data/transforms
dbt build --select your_model_name
```

### Macro changes

If you update a macro under `dp_v9mj_measurement_data/transforms/macros/`:

- validate any referenced models, tasks, procedures, or environment checks
- confirm the macro behaves correctly for each target environment it supports
- document non-obvious environment restrictions in comments or runbooks

### Pipeline config changes

If you update files under `dp_v9mj_measurement_data/configs/`:

- preserve the existing YAML structure and indentation
- ensure model names in dependencies such as `depends_on` or `run_after` match the actual dbt node names
- confirm the config still reflects the intended DAG behaviour
- validate the YAML before submitting your PR

### Documentation and runbook changes

Use documentation updates to capture operational knowledge that should not live only in tickets, chat, or personal notes.

- contributor guidance belongs in root Markdown files such as `README.md` and `CONTRIBUTING.md`
- operational recovery steps belong in `migrations/snowflake-operations/`
- runbooks should explain purpose, prerequisites, environment, recreation steps, validation, and any known limitations
- note clearly whether a document is informational only or part of deployment execution

### DDL changes

Follow the [GRID DDL guide](https://data-platforms-docs.ext.prd.jspaas.uk/grid/grid-ddl/) for managing Snowflake objects through SqlDBM.

Suggested workflow:

1. Update the definitions in SqlDBM.
2. Pull the generated changes into this repository.
3. Review the generated SQL under `dp_v9mj_measurement_data/ddl/`.
4. Confirm the change matches the intended Snowflake object definition.
5. Raise a PR with any supporting documentation needed.

## 📐 Code standards

### SQL style guide

All SQL must pass SQLFluff linting. Pre-commit hooks will check SQL files in the dbt models path.

Key standards:

- use **lowercase** for SQL keywords and function names
- indent with **4 spaces** and do not use tabs
- use **trailing commas** in `select` statements where the project style expects them
- add explicit aliases using `AS`
- prefer CTEs over deeply nested subqueries
- add descriptive comments for complex logic

Example:

```sql
-- good
with base_data as (
    select
        item_cd
        , brand_name
        , current_date as load_date
    from {{ ref('source_table') }} as src
    where item_cd is not null
)

select * from base_data

-- bad
SELECT item_cd,brand_name,CURRENT_DATE load_date
FROM {{ ref('source_table') }}
WHERE item_cd IS NOT NULL
```

### Python and formatting

This repository also uses Ruff for Python linting and formatting.

- target Python version is 3.10
- line length is 100
- spaces are used for indentation

### dbt best practices

#### Materialisation

- use `view` for lightweight transformations
- use `table` for heavier transformations or commonly queried outputs
- use `incremental` for large datasets with append/update patterns

#### Naming conventions

- models: `UPPERCASE_WITH_UNDERSCORES`
- snapshots: `lowercase_with_underscores_snapshot`
- tests: `dv__model_name_test`

#### Configuration

- add model configuration in `dbt_project.yml` or at model level when needed
- add the correct pipeline tag for the area you are working in
- keep materialisation aligned with the layer and workload

#### Documentation

- every model should have a clear description in `schema.yml`
- document important columns, especially business keys and status fields
- add data tests for critical columns such as `unique`, `not_null`, and relationships where relevant

## 🧪 Testing requirements

Before you submit a PR, run the checks that are relevant to your change.

### 1. Pre-commit checks

Run all hooks:

```bash
pre-commit run --all-files
```

For a targeted check on a specific file:

```bash
pre-commit run --files CONTRIBUTING.md
```

This typically covers:

- trailing whitespace
- end-of-file formatting
- YAML, JSON, and TOML syntax validation
- Markdown formatting
- Python formatting and linting
- SQL linting for dbt model SQL files

### 2. dbt validation

For dbt changes, run the smallest useful scope first, then widen if needed.

```bash
cd dp_v9mj_measurement_data/transforms
dbt build --select your_model_name
```

If your change affects multiple upstream or downstream nodes, consider:

```bash
cd dp_v9mj_measurement_data/transforms
dbt build --select +your_model_name+
```

### 3. Manual validation in Snowflake

If your change affects data outputs, macros, procedures, tasks, or operational behaviour:

- validate the change manually in Snowflake where appropriate
- record what you tested in your PR description
- note any environment-specific limitations

### 4. Documentation validation

For documentation-only changes:

- spell-check the content
- confirm links and file paths are correct
- make sure the guidance reflects the current repository structure

## 🔍 Pull request process

### Before creating a PR

- [ ] pre-commit hooks pass
- [ ] relevant dbt runs/tests pass locally
- [ ] manual Snowflake validation is complete where applicable
- [ ] documentation is complete and spell-checked
- [ ] the change follows the standards in this guide

### Creating the PR

1. Push your branch to GitHub.
2. Open a pull request using the [PR template](.github/pull_request_template.md).
3. Complete all relevant sections, including:
   - Jira ticket
   - summary of the change
   - testing evidence
   - any deployment or operational notes

### PR title format

Use:

`[JIRA-ID] Brief description`

Example:

`[RTD-12345] Add brand history snapshot model`

### Review expectations

- PRs require at least **one approval** from a code owner
- address review comments promptly and clearly
- ensure CI/CD checks pass
- keep your branch up to date with `main`

### After approval

Once approved and merged:

- the CI/CD pipeline will deploy to dev
- monitor the deployment in GitHub Actions
- verify the change in the dev environment

## 📁 Project structure

```text
dp_v9mj_measurement_data/
├── configs/                      # Pipeline and shared configuration
├── ddl/                          # Managed Snowflake DDL artefacts
└── transforms/                   # dbt project root
    ├── analyses/                 # Ad-hoc analysis queries
    ├── dbt_packages/             # Installed dbt packages
    ├── macros/                   # Custom Jinja macros
    ├── models/                   # dbt models
    │   ├── sources.yml           # Source definitions
    │   └── dv/                   # Data-vault-oriented models
    ├── seeds/                    # CSV seed data
    ├── snapshots/                # dbt snapshots
    └── tests/                    # Custom dbt tests

migrations/
└── snowflake-operations/         # Manual operational runbooks
```

### Model layering

Data should flow in one direction only:

`staging` -> `intermediary` -> `final`

Build the flow forward, not backward.

| Layer        | Description                                                  | Guidance                                                                             | Naming                            |
| ------------ | ------------------------------------------------------------ | ------------------------------------------------------------------------------------ | --------------------------------- |
| Staging      | Clean and refine raw source data. Keep business logic light. | Use only the required source columns. Staging models should usually be views.        | `STG_...`                         |
| Intermediary | Join, enrich, and apply reusable business logic.             | Keep the purpose specific and reusable. Use materialisation appropriate to workload. | `INT_...`                         |
| Final        | Present analytics-ready outputs for downstream consumption.  | Hide transformation complexity and optimise for consumer use.                        | Descriptive business-facing names |

## 🆘 Getting help

If you need help:

1. Review the [GRID User Guide](https://data-platforms-docs.ext.prd.jspaas.uk/grid/)
2. Review the [dbt documentation](https://docs.getdbt.com/)
3. Contact the MA Data team
4. Ask in the relevant team Slack channel

## 📞 Contact

- **Team:** MA Data team
- **Email:** pollen_data_engineering@sainsburys.co.uk
- **Jira:** [Pollen Data Engineering Board](https://sainsburys-tech.atlassian.net/jira/software/c/projects/RTD/boards/4822)

## 📄 License

This project follows Sainsbury's internal policies and is not licensed for external use.

---

Thank you for contributing. Clear, well-tested changes help keep the product reliable and easier to support.
