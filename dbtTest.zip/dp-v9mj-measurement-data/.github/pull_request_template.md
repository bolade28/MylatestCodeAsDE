## Jira

<!-- Add a link to any relevant JIRA tickets -->

[RTD-X](https://sainsburys-tech.atlassian.net/browse/RTD-X)

## Description

<!-- Please describe what you have changed or added -->

## How has this been tested?

<!-- Please describe in detail how you tested your changes. -->
<!-- Include details of your testing environment, tests ran to see how -->
<!-- your change affects other areas of the code, etc. -->

## Checklist

- [ ] Pre-commit
- [ ] Adheres to contribution.md (models, schema, ...)
- [ ] Tested locally in a clone
- [ ] Compiled code tested manually in Snowflake
- [ ] Documentation has been added and _spellchecked_

> [!CAUTION]
>
> **IMPORTANT:** If merging any DDL or dbt changes, you must test these by deploying to a test environment (e.g. Dev), and ensuring that any impacted DAGs have run successfully in Astronomer.
>
> - [ ] **I confirm that I have deployed these changes to a test environment (e.g. Dev) and confirm that any impacted DAGs ran successfully**
