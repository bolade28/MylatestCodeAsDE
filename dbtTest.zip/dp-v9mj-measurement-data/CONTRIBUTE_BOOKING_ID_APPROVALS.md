# Updating the `MEASUREMENT_REPORTING_BOOKING_ID_SF` seed

This guide explains how to add or update booking IDs used for measurement reporting approvals across environments.

## Prerequisites

To clone this repository and raise updates, you must be a member of the GitHub team:

- [`pollen-data-seeds-contributors`](https://github.com/orgs/sainsburys-tech/teams/pollen-data-seeds-contributers)

If you need access, please contact **Anton Martin** (`anton.martin@sainsburys.co.uk`). Once access has been granted, you should be able to clone the repository, create a branch, and open a pull request.

## Overview

The `MEASUREMENT_REPORTING_BOOKING_ID_SF` seed contains booking IDs used by the Analytics team to classify records as:

- **Approved**
- **Excluded**
- **Not considered** (`null` / blank)

These classifications are maintained separately for **dev**, **preprod**, and **prod**.

Each row represents a single booking ID and its reporting status by environment.

The seed is referenced by the model:

- `dp_v9mj_measurement_data/transforms/models/dv/campaign_booking_ids_reporting/MEASUREMENT_REPORTING_APPROVED_BOOKING_ID_REF.sql`

That model selects the environment-specific reporting status based on the current dbt target.

## File location

Update the seed file directly at:

`dp_v9mj_measurement_data/transforms/seeds/campaign_booking_ids_reporting/MEASUREMENT_REPORTING_BOOKING_ID_SF.csv`

Do not add the change anywhere else unless the process itself is being redesigned.

## Expected values

The seed contains the following columns:

- `BOOKING_ID`
- `DEV_REPORTING_STATUS`
- `PREPROD_REPORTING_STATUS`
- `PROD_REPORTING_STATUS`

Rules:

- `BOOKING_ID` must be populated
- `BOOKING_ID` should be stored as a string value
- reporting status columns may contain:
  - `APPROVED`
  - `EXCLUDED`
  - blank, to represent `null` / not considered

Use uppercase values consistently for reporting statuses.

## Update frequency

- The seed and its dependent reporting view are refreshed automatically in line with the pipeline schedule.
- If a change is urgent and must be reflected immediately, contact the **MA Data team** to discuss whether a manual run is required.

## How to add or update a booking ID

### 1. Update the CSV file

Add a new row or update the existing row for the booking ID in:

`dp_v9mj_measurement_data/transforms/seeds/campaign_booking_ids_reporting/MEASUREMENT_REPORTING_BOOKING_ID_SF.csv`

Make sure:

- the booking ID is entered in `BOOKING_ID`
- each environment column reflects the intended reporting behaviour
- blank values are left genuinely blank and not replaced with placeholder text such as `NULL`, `N/A`, or `NOT CONSIDERED`

### 2. Perform quick data quality checks

Before raising a PR, confirm:

- `BOOKING_ID` is populated
- only allowed values are used in reporting status columns
- no new columns have been added
- no headers have been renamed
- there are no accidental trailing spaces or formatting issues
- duplicate booking IDs have not been introduced unintentionally

### 3. Create a pull request

Once your change is ready:

1. Create a branch using the Jira ticket, for example:
   `RTD-12345-add-measurement-reporting-booking-id`
2. Commit the CSV update.
3. Open a pull request and reference the Jira ticket.
4. Include a short explanation covering:
   - which booking ID was added or updated
   - which environment statuses changed
   - why the change is needed

### 4. Notify the MA Data team

After submitting the PR, notify the **MA Data team** so the change can be reviewed and approved before merge.

## Good practices

- keep changes focused only on the booking IDs required for the ticket
- avoid reformatting unrelated rows
- preserve the existing header names and column order
- include enough PR context so reviewers do not need to trace the business reason separately

## Summary

If you are updating booking ID approvals:

1. edit `MEASUREMENT_REPORTING_BOOKING_ID_SF.csv`
2. use only `APPROVED`, `EXCLUDED`, or blank values
3. validate the row carefully
4. raise a PR with the Jira reference
5. notify the MA Data team for review
